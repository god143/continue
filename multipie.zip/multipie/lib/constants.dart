import 'package:multipie/core/utils/images_path.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class Constants {
  //Temp change
  static Map widgetShareData = Map();
  static const String ENV_DEV = "DEV";
  static const String ENV_TEST = "TEST";
  static const String ENV_ALPHA = "ALPHA";
  static const String ENV_PROD = "PROD";
  static const String ENV_DEFAULT = "PROD";

  static String BASE_URL = 'https://www.multipie.co';
  static String WEBSITE_URL = BASE_URL;
  static String AUTH_SERVER_URL = 'https://auth.multipie.co';
  static String API_AUTH_URL = '${AUTH_SERVER_URL}/api/v1';
  static int SHOW_TOP_MULTIPIE_CONTRIBUTORS_AFTER = 2;
  static int SHOW_PEOPLE_YOU_MAY_KNOW_AFTER = 4; //Show "people you may know" section in feed
  static int SHOW_TRENDING_AFTER = 8; //Show trending profile suggestion
  static int SHOW_NEWS_AFTER = 12; //Show trending profile suggestion
  static String VALUEFY_SERVER_URL = '';
  static String BROKER_CALLBACK_URL = '';
  static String LINK_5PAISA_TRANSACTION = "https://pwapps.5paisa.com/sso";
  static String ZERODHA_API_KEY = "https://pwapps.5paisa.com/sso";
  static const String GIPHY_API_KEY = "MgZuTqP4R13hjN3dTMdeoiTEy6edppV6";

  static const String API_URL_DEV = "http://10.0.2.2:3000/api/v1";
  static String API_MAIN_URL = "${BASE_URL}/api/v1";
  static String API_URL_DEFAULT = '${BASE_URL}/api/v1';
  static const String API_URL_PROD = "https://www.multipie.co/api/v1";
  static const String API_MF_IMAGE_URL = "https://assets.multipie.co";
  static const String LINK_PREVIEW_URL = "https://corsp.multipie.co/";

  static const String DART_DEFINE_ENV_STR = "environment";
  static User? currentAppUser;
  static String userNameSelectionTimeKey = "user_name_selection";

  static String localCoverPicUrl = "";

  static const String FIVE_PAISA_IDENTIFIER = "five_paisa";
  static const String LINK_FIVE_PAISA_LOGIN = "https://pwapps.5paisa.com/";
      //"https://www.5paisa.com/open-demat-account?utm_source=Partner%20Program&rcode=NTM5NzgyNDI=";

  // static const int API_PAGE_RESULT_COUNT =20;
  static int showEmailVerificationPopup = 0; //Remind user to verify email immediately, because email is mandatory now

  static String peerComparison = '';
  static String currentPricesWidgetString = '';
  static String companyStatsWidgetString = '';
  static String companyFinancialWidgetString = '';
  static String companyPromoterHoldingWidgetString = '';
  static String mfValueInfoWidgetString = '';
  static String mfPerformanceWidgetString = '';
  static String mfGraphWidgetString = '';
  static String mfAllDataWidgetString = '';

  static const String MF_FILTER_PARENT = "mf_filter_parent";
  static const String MF_FILTER_CHILDREN_LIST = "mf_filter_children_list";
}

enum FollowEvent { followed, accepted, pending, invite, invited, none }

final profileType = [ic_bull, ic_bear, ic_neutral];
final marketViewMap = {
  "bullish": ic_bull,
  "neutral": ic_neutral,
  "bearish": ic_bear,
};

final countryCodes = ['+91', '+1', '+44', '+61', '+65', '+852', '+971', '+974'];

enum OTPChannel { mobile, whatsapp }

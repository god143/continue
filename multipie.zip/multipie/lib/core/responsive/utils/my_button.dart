import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:multipie/core/ui_helper_new.dart';

import '../../ui_helper_new.dart';

class MultipieButton extends StatelessWidget {
  final String? text;
  final VoidCallback? onPressed;
  final Color? color;
  final Color? textColor;
  final double? elevation;
  final double? height;
  final double? width;
  final double? textFontSize;
  final FontWeight? textFontWeight;
  double padding;

  MultipieButton(
      {Key? key,
      this.text,
      this.onPressed,
      this.color,
      this.textColor,
      this.elevation,
      this.height,
      this.width,
      this.textFontSize,
      this.padding = 0,
      this.textFontWeight})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        padding: EdgeInsets.symmetric(horizontal: padding),
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        backgroundColor: color,
      ),
      child: Text(
        text ?? '',
        style: TextStyle(
          color: textColor,
          fontSize: textFontSize,
          fontWeight: textFontWeight,
        ),
      ),
    );
    /* return MaterialButton(
      padding: EdgeInsets.symmetric(horizontal: padding),
      height: height,
      minWidth: width,
      color: color,
      elevation: elevation,
      disabledTextColor: MultipieColor.primaryDisableText,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      onPressed: onPressed,
      child: Text(
        text ?? '',
        style: TextStyle(
          color: textColor,
          fontSize: textFontSize,
          fontWeight: textFontWeight,
        ),
      ),
    );*/
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

import 'responsive/responsive.dart';

double sWidth(double width) => SizeConfigNew.setWidth(width);

double sHeight(double height) => SizeConfigNew.setHeight(height);

double sSize(double size) => SizeConfigNew.setImageSize(size);

double sSp(double size) => SizeConfigNew.setSp(size);

//TextStyle for AppBar Title
TextStyle mpHeadLine1({
  required BuildContext context,
  Color? textColor,
}) {
  return TextStyle(
    fontWeight: FontWeight.w700,
    color: textColor ?? context.appTheme.primaryTextColor,
    fontSize: sSp(34.0),
  );
}

//TextStyle for AppBar Title
TextStyle mpHeadLine2({
  required BuildContext context,
  Color? textColor,
}) {
  return TextStyle(
    fontWeight: FontWeight.w600,
    color: textColor ?? context.appTheme.primaryTextColor,
    fontSize: sSp(24.0),
  );
}

TextStyle mpHeadLine3({
  required BuildContext context,
  Color? textColor,
  FontWeight fontWeight = FontWeight.w600,
}) {
  return TextStyle(
    fontWeight: fontWeight,
    color: textColor ?? context.appTheme.primaryTextColor,
    fontSize: sSp(20.0),
  );
}

TextStyle mpHeadLine4({
  required BuildContext context,
  Color? textColor,
  FontWeight fontWeight = FontWeight.normal,
  TextDecoration decoration = TextDecoration.none,
}) {
  return TextStyle(
    fontWeight: fontWeight,
    color: textColor ?? context.appTheme.primaryTextColor,
    decoration: decoration,
    fontSize: sSp(16.0),
  );
}

TextStyle mpHeadLine5({
  required BuildContext context,
  Color? textColor,
  FontWeight fontWeight = FontWeight.normal,
}) {
  return TextStyle(
    fontWeight: fontWeight,
    color: textColor ?? context.appTheme.primaryTextColor,
    fontSize: sSp(14.0),
  );
}

TextStyle mpHeadLine6({
  required BuildContext context,
  Color? textColor,
  FontWeight fontWeight = FontWeight.normal,
}) {
  return TextStyle(
    fontWeight: fontWeight,
    color: textColor ?? context.appTheme.primaryTextColor,
    fontSize: sSp(12.0),
  );
}

TextStyle mpHeadLine7({
  required BuildContext context,
  Color? textColor,
  FontWeight fontWeight = FontWeight.w400,
}) {
  return TextStyle(
    fontWeight: fontWeight,
    color: textColor ?? context.appTheme.primaryTextColor,
    fontSize: sSp(10.0),
  );
}

//Default Title Style
TextStyle kDefaultTitleStyle({
  required Color textColor,
}) =>
    TextStyle(
      fontSize: sSp(8),
      fontWeight: FontWeight.normal,
      color: textColor,
    );

TextStyle kDefaultLabelStyle(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.secondaryTextColor,
      fontSize: sSp(6),
      fontWeight: FontWeight.w400,
      fontStyle: FontStyle.normal,
      letterSpacing: .4,
    );

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

import 'responsive/responsive.dart';

//! SizeConfig shortcuts

// get dimensions from [ SizeConfig ]
double get sWidthMultiplier => SizeConfig.widthMultiplier;

double get sHeightMultiplier => SizeConfig.heightMultiplier;

double sWidth(double width) => SizeConfig.setWidth(width);

double sHeight(double height) => SizeConfig.setHeight(height);

double sSize(double size) => SizeConfig.setImageSize(size);

double sSp(double size) => SizeConfig.setSp(size);

//! Shadows

// shadow for large card
BoxShadow kLargeCardShadow(BuildContext context) => BoxShadow(
      blurRadius: sSp(11.0),
      offset: Offset(sSp(1.5), sSp(2.5)),
      color: context.appTheme.boxShadowColor.withOpacity(0.1),
    );

// shadow for post container on feed page
BoxShadow kPostContainerShadow(BuildContext context) => BoxShadow(
      blurRadius: sSp(5.0),
      offset: Offset(sSp(0.0), sSp(2.5)),
      color: context.appTheme.boxShadowColor.withOpacity(0.05),
    );

// shadow for white message in chat
BoxShadow kChatMessageShadow(BuildContext context) => BoxShadow(
      blurRadius: sSp(5.0),
      offset: Offset(sSp(0.0), sSp(2.5)),
      color: context.appTheme.boxShadowColor.withOpacity(0.05),
    );

//navigation bar shadow
BoxShadow kNavBarBoxShadow(BuildContext context) => BoxShadow(
    color: context.appTheme.boxShadowColor.withOpacity(0.1),
    offset: Offset(0, sSp(-2.5)),
    blurRadius: sSp(18),
    spreadRadius: 0);

//! Decorations

//chat search box decoration
InputDecoration kSearchBoxDecoration(BuildContext context) => new InputDecoration(
    border: OutlineInputBorder(),
    fillColor: context.appTheme.kActiveColor,
    focusColor: context.appTheme.kActiveColor,
    hoverColor: context.appTheme.kActiveColor,
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(
        color: context.appTheme.kInputBoxBorderColor,
        width: sSp(1.0),
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide: BorderSide(
        color: context.appTheme.kInputBoxBorderColor,
        width: sSp(1.0),
      ),
    ),
    suffixIcon: Icon(
      CupertinoIcons.search,
      color: context.appTheme.kIconColor,
    ));

//share post box decoration
InputDecoration kSharedPostDecoration = new InputDecoration(
  hintText: "Say something about this...",
  border: OutlineInputBorder(),
  // fillColor: context.appTheme.kActiveColor,
  // focusColor: context.appTheme.kActiveColor,
  // hoverColor: context.appTheme.kActiveColor,
  // enabledBorder: OutlineInputBorder(
  //   borderSide: BorderSide(
  //     color: context.appTheme.kInputBoxBorderColor,
  //     width: sSp(1.0),
  //   ),
  // ),
  // focusedBorder: OutlineInputBorder(
  //   borderSide: BorderSide(
  //     color: context.appTheme.kInputBoxBorderColor,
  //     width: sSp(1.0),
  //   ),
  // ),
);

//Navigation Bar Box decoration
BoxDecoration kNavBarBoxDecoration(BuildContext context) => new BoxDecoration(
      boxShadow: [kNavBarBoxShadow(context)],
      color: context.appTheme.kPrimaryBackGroundColor,
    );

//Input Box Decoration
BoxDecoration kInputBoxDecoration(BuildContext context) => BoxDecoration(
      color: context.appTheme.kSecondaryBackGroundColor,
      borderRadius: BorderRadius.circular(sSp(6.0)),
    );

//Input Box Decoration
BoxDecoration kContainerDecoration(BuildContext context) => BoxDecoration(
      color: context.appTheme.kSecondaryBackGroundColor,
      border: Border.all(color: context.appTheme.primaryColor, width: sWidth(2)),
      borderRadius: BorderRadius.circular(sSp(6.0)),
    );

//Post Container Box Decoration
BoxDecoration kPostContainerBoxDecoration(BuildContext context) => new BoxDecoration(
      color: context.appTheme.kPrimaryBackGroundColor,
      borderRadius: BorderRadius.circular(sWidth(4)),
      boxShadow: [
        kPostContainerShadow(context),
      ],
    );

BoxDecoration kStoriesBoxDecoration(BuildContext context) => new BoxDecoration(
      boxShadow: [kPostContainerShadow(context)],
      color: context.appTheme.kPrimaryBackGroundColor,
      shape: BoxShape.rectangle,
    );

BoxDecoration kHeaderBoxDecoration(BuildContext context) => new BoxDecoration(
      boxShadow: [kLargeCardShadow(context)],
      color: context.appTheme.kPrimaryBackGroundColor,
      shape: BoxShape.rectangle,
    );
//! Text Styles

//TextStyle for AppBar Title
TextStyle kAppBarTitle(BuildContext context) => TextStyle(
      fontFamily: "Avenir",
      fontWeight: FontWeight.w700,
      color: context.appTheme.darkTextColor,
      fontSize: sSp(11.0),
    );

//TextStyle for AppBar Title
TextStyle kAppBarLightTitle(BuildContext context) => TextStyle(
      fontFamily: "Avenir",
      fontWeight: FontWeight.w500,
      color: context.appTheme.primaryTextColor,
      fontSize: sSp(9.0),
    );

//TextStyle for Large headings
TextStyle kAppHeadline(BuildContext context) => TextStyle(
      fontWeight: FontWeight.w700,
      color: context.appTheme.primaryTextColor,
      fontSize: sSp(18.0),
    );

//For Message Font
TextStyle kMessageFont = TextStyle(
  fontSize: sSp(7.0),
);

//For List tile title
TextStyle kListTileTitle(BuildContext context) => TextStyle(
      fontSize: sSp(8.0),
      fontWeight: FontWeight.w700,
      color: context.appTheme.primaryTextColor,
    );
//For List tile title
TextStyle kPollCardTitle(BuildContext context) => TextStyle(
      fontSize: sSp(8.0),
      fontWeight: FontWeight.w700,
      color: context.appTheme.primaryTextColor,
    );

//For light subtitle
TextStyle kLightSubtitle(BuildContext context) => TextStyle(
      fontSize: sSp(5.0),
      color: context.appTheme.kSecondaryTextColor,
    );

//For title style
TextStyle kTitleStyle(BuildContext context) => TextStyle(
      fontSize: sSp(8),
      color: context.appTheme.primaryTextColor,
      fontWeight: FontWeight.w500,
    );

//Default Title Style
TextStyle kDefaultTitleStyle(BuildContext context) => TextStyle(
      fontSize: sSp(8),
      color: context.appTheme.primaryTextColor,
      fontWeight: FontWeight.normal,
    );

TextStyle kDefaultLabelStyle(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.kSecondaryTextColor,
      fontSize: sSp(6),
      fontWeight: FontWeight.w400,
      fontStyle: FontStyle.normal,
      letterSpacing: .4,
    );

TextStyle kCardSubLabelTextStyle(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.kSecondaryTextColor,
      fontSize: sSp(7),
      fontWeight: FontWeight.w400,
      fontStyle: FontStyle.normal,
      letterSpacing: .4,
    );

TextStyle kBodySkeletonTextStyle(BuildContext context) => TextStyle(
      fontFamily: 'Avenir',
      color: context.appTheme.kBodySkeletonTextColor,
      fontSize: sSp(12),
      fontWeight: FontWeight.w600,
      fontStyle: FontStyle.normal,
      letterSpacing: 0.75,
    );

TextStyle kFollowCountTextStyle(BuildContext context) => TextStyle(
      fontSize: sSp(6.0),
      fontWeight: FontWeight.w700,
      color: context.appTheme.primaryTextColor,
    );

TextStyle kFollowLabelTextStyle(BuildContext context) => TextStyle(
      fontSize: sSp(6.0),
      fontWeight: FontWeight.w700,
      color: context.appTheme.primaryTextColor,
    );

TextStyle titleStyle(BuildContext context) {
  return TextStyle(
    color: context.appTheme.primaryTextColor,
    fontSize: sSp(8),
    fontWeight: FontWeight.bold,
  );
}

TextStyle kGraphNormalHead(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.kSecondaryTextColor,
      fontSize: sSp(6),
      fontWeight: FontWeight.w400,
      fontStyle: FontStyle.normal,
    );

TextStyle kGraphSelectedHead(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.primaryColor,
      fontSize: sSp(6),
      fontWeight: FontWeight.w400,
      fontStyle: FontStyle.normal,
    );

TextStyle searchSuggestionTitle(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.primaryColor,
      fontSize: sSp(8),
      fontWeight: FontWeight.w700,
      fontStyle: FontStyle.normal,
    );

TextStyle searchSuggestionList(BuildContext context) => TextStyle(
      fontFamily: 'NunitoSans',
      color: context.appTheme.primaryTextColor,
      fontSize: sSp(7),
      fontWeight: FontWeight.w500,
      fontStyle: FontStyle.normal,
    );

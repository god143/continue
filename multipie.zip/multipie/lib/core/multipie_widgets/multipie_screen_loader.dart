import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper.dart';
import 'package:multipie/core/utils/extensions.dart';

class MultipieScreenLoader extends StatelessWidget {
  final double height;
  final double width;
  const MultipieScreenLoader({
    Key? key,
    this.height = 30,
    this.width = 30,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: Container(
        height: height,
        width: width,
        alignment: Alignment.center,
        child: Container(
          padding: EdgeInsets.all(sSize(50)),
          decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(sSize(10)))),
          child: CircularProgressIndicator(
            strokeWidth: 2,
          ),
        ),
      ),
    );
  }
}

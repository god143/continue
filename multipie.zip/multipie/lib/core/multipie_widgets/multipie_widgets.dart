import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:multipie/core/ui_helper.dart';
import 'package:multipie/core/utils/extensions.dart';

double fullWidth(BuildContext context) {
  return MediaQuery.of(context).size.width;
}

double fullHeight(BuildContext context) {
  return MediaQuery.of(context).size.height;
}

class MultipieEmptyList extends StatelessWidget {
  MultipieEmptyList(this.title, {this.subTitle = ''});

  final String subTitle;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
        height: .5 * fullHeight(context),
        child: MultipieNotifyText(
          title: title,
          subTitle: subTitle,
        ));
  }
}

class MultipieNotifyText extends StatelessWidget {
  final String subTitle;
  final String title;
  const MultipieNotifyText({Key? key, this.subTitle = '', this.title = ''}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        MultipieTitleText(title, fontSize: sSp(10), textAlign: TextAlign.center),
        SizedBox(
          height: sHeight(20),
        ),
        MultipieTitleText(
          subTitle,
          fontSize: sSp(8),
          fontWeight: FontWeight.w500,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

class MultipieTitleText extends StatelessWidget {
  final String text;
  final double fontSize;
  final Color? color;
  final FontWeight fontWeight;
  final TextAlign textAlign;
  final TextOverflow overflow;
  const MultipieTitleText(
    this.text, {
    Key? key,
    this.fontSize = 18,
    this.color,
    this.fontWeight = FontWeight.w800,
    this.textAlign = TextAlign.left,
    this.overflow = TextOverflow.visible,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: fontWeight,
        color: color ?? context.appTheme.darkTextColor,
      ),
      textAlign: textAlign,
      overflow: overflow,
    );
  }
}

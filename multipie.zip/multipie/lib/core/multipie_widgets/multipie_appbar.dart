import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

class MultipieAppBar extends StatefulWidget implements PreferredSizeWidget {
  final String? title;
  final WidgetBuilder? titleBuilder;
  final double elevation;
  final void Function()? onTap;
  final bool? centerTitle;
  List<Widget> actions;

  MultipieAppBar({
    Key? key,
    this.title,
    this.titleBuilder,
    this.elevation = 1,
    this.onTap,
    this.centerTitle,
    this.actions = const [],
  }) : super(key: key);

  @override
  Size get preferredSize => Size.fromHeight(50.0);

  @override
  _MultipieAppBarState createState() => _MultipieAppBarState();
}

class _MultipieAppBarState extends State<MultipieAppBar> {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      elevation: widget.elevation,
      titleSpacing: 0,
      leadingWidth: 48,
      leading: IconButton(
        splashRadius: 20,
        iconSize: 27.5,
        onPressed: widget.onTap == null ? () => Navigator.pop(context) : widget.onTap,
        icon: Icon(
          CupertinoIcons.chevron_back,
          color: context.appTheme.primaryColor,
        ),
      ),
      title: widget.titleBuilder != null
          ? widget.titleBuilder!(context)
          : Padding(
              padding: const EdgeInsets.only(top: 2.5),
              child: Text(
                widget.title ?? '',
                style: TextStyle(
                  color: context.appTheme.primaryColor,
                  fontFamily: 'Roboto',
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
      centerTitle: widget.centerTitle,
      actions: widget.actions,
    );
  }
}

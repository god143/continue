import 'package:flutter/material.dart' show BuildContext;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:multipie/core/theme/app_theme.dart';
import 'package:multipie/core/theme/cubit/app_theme_cubit.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:provider/src/provider.dart';

extension StringExtensions on String? {
  bool isNullOrEmpty() => this == null || this!.isEmpty;

  String capitalize() {
    if (this == null)
      return "";
    else if (this!.length >= 2) {
      return "${this![0].toUpperCase()}${this!.substring(1)}";
    } else if (this!.length == 1) {
      return this![0].toUpperCase();
    } else
      return "";
  }
}

extension StringEx on String {
  String get camelCaseToLowerUnderscore {
    var sb = StringBuffer();
    var first = true;
    runes.forEach((int rune) {
      var char = String.fromCharCode(rune);
      if (char == char.toUpperCase() && !first) {
        if (char != '_') {
          sb.write('_');
        }
        sb.write(char.toLowerCase());
      } else {
        first = false;
        sb.write(char.toLowerCase());
      }
    });
    return sb.toString();
  }

  bool get isValidEmail =>
      RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(this);

  bool get isNumeric => double.tryParse(this) != null;
}

extension DateFormatExtension on DateTime {
  String format(String pattern) => DateFormat(pattern).format(this);
}

extension ListExtensions<T> on List<T> {
  List<T> pickLast(int elements) {
    final startIndex = length - elements;
    if (startIndex < 0 || startIndex > length) {
      return this;
    } else {
      return sublist(startIndex);
    }
  }

  List<List<T>> partition(int chunkSize) {
    List<List<T>> chunks = [];
    for (var i = 0; i < length; i += chunkSize) {
      final chunk = sublist(i, i + chunkSize > length ? length : i + chunkSize);
      chunks.add(chunk);
    }
    return chunks;
  }
}

extension DoubleExtension on double {
  String formatAsCurrency({
    String? locale = 'en_IN',
    String? symbol = '',
    int? decimalDigits = 0,
  }) =>
      NumberFormat.currency(
        locale: locale,
        symbol: symbol,
        decimalDigits: decimalDigits,
      ).format(this);

  String formatAsString({
    int maxDecimals = 2,
  }) {
    final formatter = NumberFormat();
    formatter.minimumFractionDigits = 0;
    formatter.maximumFractionDigits = maxDecimals;
    return formatter.format(this);
  }
}

extension NumEx on num {
  String get shortFormat {
    final f = NumberFormat.compact(locale: "en_US");
    print(f.format(this));
    return f.format(this);
  }
}

extension BuildContextEx on BuildContext {
  AppTheme get appTheme => read<AppThemeCubit>().theme;
  bool get isDarkMode => read<AppThemeCubit>().isDarkMode;
  AppTheme get lightAppTheme => read<AppThemeCubit>().appThemeForMode(ThemeMode.light);
  AppTheme get darkAppTheme => read<AppThemeCubit>().appThemeForMode(ThemeMode.dark);
}

extension FailureEx on Failure {
  String get message {
    switch (runtimeType) {
      case ServerFailure:
        return 'Server Failure';
      case CacheFailure:
        return 'Cache Failure';
      default:
        return 'Unexpected error';
    }
  }
}

extension JsonEx on Map<String, dynamic> {
  Map<String, dynamic> get transformKeysToLowerSnakeCase {
    return Map.fromEntries(
      entries.map(
        (e) => MapEntry(e.key.camelCaseToLowerUnderscore, e.value),
      ),
    );
  }
}

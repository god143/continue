import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/features/post/presentation/provider/post_provider.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/profile_screen_bloc.dart';
import 'package:multipie/locator.dart';
import 'package:multipie/screens/splash_screen/splash_screen.dart';
import 'package:multipie/services/analytics.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> logout(BuildContext context) async {
  final prefs = await SharedPreferences.getInstance();
  BlocProvider.of<UserProfileBloc>(context).currentUser = null;
  Provider.of<PostProvider>(context, listen: false)
    ..context = context
    ..clearFeedPosts();
  await prefs.clear();
  // MPRouter.navigator.popAndPushNamed(MPRouter.loginScreen);
  locator.get<AnalyticsService>().resetUser();
  Navigator.pushAndRemoveUntil(
      context, MaterialPageRoute(builder: (_) => SplashScreen()), (route) => route is SplashScreen);
}

import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path/path.dart' as path;

class FileDownloadHandler {
  static final Dio _dio = Dio();

  static Future<Directory?> getDownloadDirectory() async {
    if (Platform.isIOS) {
      return await getApplicationDocumentsDirectory();
    }
    return await getExternalStorageDirectory();
  }

  Future<bool> _requestStoragePermission() async {
    PermissionStatus permissionStatus = await Permission.storage.status;
    if (permissionStatus != PermissionStatus.granted) {
      await Permission.storage.request();
      permissionStatus = await Permission.storage.status;
    }
    return permissionStatus == PermissionStatus.granted;
  }

  Future<Map<String, dynamic>> _startFileDownload(String url, String savePath,
      Function(int, int)? onReceiveProgress) async {
    Map<String, dynamic> result = {
      'isSuccess': false,
      'filePath': null,
      'error': null,
    };
    try {
      final response = await _dio.download(url, savePath,
          onReceiveProgress: onReceiveProgress);
      result['isSuccess'] = response.statusCode == 200;
      result['filePath'] = savePath;
      return result;
    } catch (ex) {
      result['error'] = ex.toString();
      return result;
    }
  }

  Future<Map<String, dynamic>> downloadFile(
      String url, Function(int, int) onReceiveProgress) async {
    final dir = await getDownloadDirectory();
    final isPermissionStatusGranted = await _requestStoragePermission();

    if (isPermissionStatusGranted) {
      var fileName = url.split("blob/");
      print(fileName);
      final savePath = path.join(dir!.path, fileName[0]);
      return await _startFileDownload(url, savePath, onReceiveProgress);
    } else {
      Map<String, dynamic> result = {
        'isSuccess': false,
        'filePath': null,
        'error': 'Permission not granted',
        'status': -1
      };
      return result;
    }
  }

  // Future<bool> doesFileExists()
}

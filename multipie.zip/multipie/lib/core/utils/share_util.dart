import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:multipie/core/utils/server_info.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:share/share.dart';

sharePost(String postId) {
  final eventData = {
    'Post Id': postId,
  };
  CleverTapPlugin.recordEvent('Post External Share', eventData);
  final postShareURL = '${ServerInfo.baseHost}/posts/$postId';
  final textToShare = "Hey!, Check this out on Multipie:";
  shareText(title: "Share via...", text: textToShare, url: postShareURL);
}

shareUser(User user, {required String source}) {
  final eventData = {
    'User Id': user.id,
    'User Name': user.username,
    'Source': source,
  };
  CleverTapPlugin.recordEvent('User External Share', eventData);
  final userShareURL = '${ServerInfo.baseHost}/u/${user.username}';
  final textToShare = "Check out ${user.displayname} (@${user.username}) on Multipie:";
  shareText(title: "Share via...", text: textToShare, url: userShareURL);
}

shareCompanyDashboard({
  required String companyId,
  required String companyName,
}) {
  final eventData = {
    'Company Id': companyId,
    'Company Name': companyName,
  };
  CleverTapPlugin.recordEvent('Stock External Share', eventData);
  final url = '${ServerInfo.baseHost}/companies/$companyId';
  final textToShare =
      "Hey, did you checkout $companyName's dashboard on Multipie? Signup on Multipie using code \"DASHBOARD\"";
  shareText(title: "Share via...", text: textToShare, url: url);
}

shareMutualFundDashboard({
  required String mutualFundId,
  required String mutualFundName,
}) {
  final eventData = {
    'MutualFund Id': mutualFundId,
    'MutualFund Name': mutualFundName,
  };
  CleverTapPlugin.recordEvent('MF External Share', eventData);
  final url = '${ServerInfo.baseHost}/mutual_funds/$mutualFundId';
  final textToShare = "Hey, did you checkout $mutualFundName on Multipie? Signup on Multipie";
  shareText(title: "Share via...", text: textToShare, url: url);
}

shareText({required String title, required String text, required String url}) {
  Share.share(
    text + "\n" + url,
    subject: title,
  );
}

// server exception
class ServerException implements Exception {
  // error message
  String message;

  ServerException(this.message);
}

class AuthException implements Exception {
  String message;
  AuthException(this.message);
}

class NotAllowedException implements Exception {
  String message;
  NotAllowedException(this.message);
}

// cache exception
class CacheException implements Exception {
  // error message
  String message;

  CacheException(this.message);
}

class BadRequestException extends ServerException {
  BadRequestException(String message) : super(message);
}

class UnauthorisedException extends ServerException {
  UnauthorisedException(String message) : super(message);
}

class JsonException extends ServerException {
  JsonException(String message) : super(message);
}

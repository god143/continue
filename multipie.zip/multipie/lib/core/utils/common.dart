import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/post/presentation/screens/youtube_player/youtube_player_screen.dart';
import 'package:url_launcher/url_launcher.dart';

import 'image_crop.dart';

showConfirmationDialog({
  required BuildContext context,
  required String title,
  required VoidCallback onPositiveCallBack,
}) {
  showDialog<Null>(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      backgroundColor: context.appTheme.cardBackgroundColor,
      title: Text(
        title,
        style: mpHeadLine5(context: context, textColor: context.appTheme.primaryTextColor),
      ),
      actions: <Widget>[
        FlatButton(
          child: Text(
            'No',
            style: mpHeadLine5(context: context),
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        FlatButton(
          child: Text(
            'Yes',
            style: mpHeadLine5(context: context),
          ),
          onPressed: () {
            Navigator.of(context).pop();
            onPositiveCallBack();
          },
        ),
      ],
    ),
  );
}

showSimpleInfoPopup({required BuildContext context, required String message}) {
  showDialog<Null>(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: context.appTheme.cardBackgroundColor,
      title: Text(
        message,
        style: mpHeadLine5(context: context),
      ),
      actions: <Widget>[
        FlatButton(
          child: Text(
            'Ok',
            style: mpHeadLine5(
              context: context,
              textColor: Theme.of(context).primaryColor,
            ),
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ],
    ),
  );
}

RegExp regExpForWhiteSpaceAndNewLine = RegExp(r" ");
// RegExp regExpForWhiteSpaceAndNewLine() => RegExp(r"\s");

RegExp regExpForExtraCharacterInTagging = RegExp('[.,!?;-]');

// RegExp regExpForHttpLinks() => RegExp(r'(?:(?:https?|http?):\/\/)?[\w/\-?=%.&]+\.[\w/\-?=%.+&]+');
RegExp regExpForHttpLinks = RegExp(
  r'(http|https)://[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:/~+#-]*[\w@?^=%&amp;/~+#-])?',
  caseSensitive: false,
  dotAll: true,
);

RegExp regExpForIdFromWord = RegExp(r'\/([0-9]+)(?=[^\/]*$)');

RegExp regExpForWWWLinks = RegExp(r'www.[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:/~+#-]*[\w@?^=%&amp;/~+#-])?');
RegExp regExpForYoutubeLinks = RegExp(
    r'^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$');

void launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    try {
      await launch(url);
    } catch (e) {
      print('Could not launch $url \n ${e.toString()}');
    }
  }
}

void checkForYoutubeURL({required BuildContext context, required String url, required Function elseCallback}) {
  RegExpMatch? match = regExpForYoutubeLinks.firstMatch(url);
  if (match != null && match.group(0) != null) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => YoutubePlayerScreen(
            url: url,
          ),
        )).then((value) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
    });
  } else {
    elseCallback();
  }
}

Future<String> getImage({
  bool useCamera = false,
  bool squareImage = false,
  required BuildContext context,
}) async {
  if (useCamera) {
    FocusManager.instance.primaryFocus!.unfocus();
  }
  final pickedImageFile = await ImagePicker().pickImage(source: useCamera ? ImageSource.camera : ImageSource.gallery);
  File? pickedFile = pickedImageFile != null ? File(pickedImageFile.path) : null;
  pickedFile = await cropImageUtil(pickedFile!.path, squareImage: squareImage, context: context);
  return pickedFile!.path;
}

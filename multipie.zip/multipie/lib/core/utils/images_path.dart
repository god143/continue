const mainPath = "assets/images/";
const String default_company_icon = mainPath + "companies/AshokLeyland.png";
const ic_ashok_leyland = mainPath + "companies/AshokLeyland.png";
const ic_axis = mainPath + "companies/Axis.png";
const ic_piramal = mainPath + "companies/Piramal.png";
const ic_bandhan = mainPath + "companies/Bandhan.png";

//icons as image
const ic_dropdown = "assets/icons/ic_drop_down.png";
const ic_trending_fire = "assets/icons/ic_trending_fire.png";
const ic_repost = "assets/icons/ic_repost.png";
const ic_heart = "assets/icons/ic_heart.png";
const ic_heart_selected = "assets/icons/ic_heart_selected.png";
const ic_plus = "assets/icons/ic_plus.png";
const img_multipie = "assets/images/multipie_logo.png";

//post screen svg images

const globe = "assets/icons/post_screen/globe.svg";
const followers = "assets/icons/post_screen/followers.svg";
const twitter = "assets/icons/post_screen/twitter.svg";
const gallery = "assets/icons/post_screen/gallery.svg";
const poll = "assets/icons/post_screen/poll.svg";
const gif = "assets/icons/post_screen/gif.svg";
const ic_bull = mainPath + "profile/ic_bull_profile.png";
const ic_bear = mainPath + "profile/ic_bear_profile.png";
const ic_neutral = mainPath + "profile/ic_neutral.png";

const icArrowRight = "assets/icons/ic_arrow_right.svg";

const icCreateChatGroup = "assets/icons/ic_create_chat_group.svg";
const icInfo = "assets/icons/Info_outlined.svg";

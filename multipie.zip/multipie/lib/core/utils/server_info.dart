import '../../constants.dart';

//class for getting server information
class ServerInfo {
  static String get currentEnvironment => String.fromEnvironment(
        Constants.DART_DEFINE_ENV_STR,
        defaultValue: Constants.ENV_DEFAULT,
      );

  static String get baseUrl {
    String baseurl = Constants.API_MAIN_URL;
    return baseurl;
  }

  static String get baseHost => baseUrl.split('/api')[0];
}

String getFullUrl(String url) {
  if (url.isEmpty) {
    return '';
  }
  if (url.startsWith("http")) return url;
  return ServerInfo.baseHost + url;
}

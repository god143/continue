import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import 'failures.dart';

// generic class for usecases
abstract class UseCase<Type, Params> {
  Future<Either<Failure, Type>> call(Params params);
}

// used when there are no parameters for usecases
class NoParams extends Equatable {
  @override
  List<Object> get props => [];
}

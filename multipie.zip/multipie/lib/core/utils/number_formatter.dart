import 'dart:core';
import 'dart:math';

import 'package:intl/intl.dart';
import 'package:multipie/core/utils/extensions.dart';

String percentageConverter(String value) {
  try {
    var doubleValue = double.parse(value);
    var piAsString = doubleValue.toStringAsFixed(2);
    var percentageChange = "$piAsString";

    return percentageChange + '%';
  } catch (e) {
    print(e);
    return 'N/A';
  }
}

String percentageConverterMF(Object d) {
  String value = d.toString();
  if (value == null || value.isEmpty) {
    return '-';
  }
  var doubleValue = double.parse(value);
  var piAsString = doubleValue.toStringAsFixed(2);
  var percentageChange = "$piAsString";

  return percentageChange + '%';
}

String twoDigitRoundOffConverter(String d) {
  String value = d.toString();
  var doubleValue = double.parse(value);
  var piAsString = doubleValue.toStringAsFixed(1);
  return piAsString;
}

String twoDigitRoundOffConverterPercentage(String d) {
  if (d == null || d.isEmpty) return '-';

  String value = d.toString();
  var doubleValue = double.parse(value);
  var piAsString = doubleValue.toStringAsFixed(2);
  return piAsString + "%";
}

double doubleTwoDigitRoundOffConverter(double d) {
  String value = d.toString();
  var doubleValue = double.parse(value);
  var piAsString = doubleValue.toStringAsFixed(2);
  double finalDoubleValue = double.parse(piAsString);
  return finalDoubleValue;
}

int stringToIntConverter(String s) {
  if (s == null || s.isEmpty || s == "") return 0;
  var intValue = int.parse(s);
  return intValue;
}

double stringToDoubleConverter(String s) {
  if (s == null || s.isEmpty || s == "") return 0;
  if (s.contains('%')) {
    s = s.replaceAll("%", "");
  }
  var doubleValue = double.parse(s);
  return doubleValue;
}

String timeFormatter(String time, bool day_month_year) {
  List<String> months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  //var moonLanding = DateTime.parse(time);

  var year = DateTime.parse("$time").toLocal().year;
  var month = DateTime.parse("$time").toLocal().month;
  var day = DateTime.parse("$time").toLocal().day;
  var hours = DateTime.parse("$time").toLocal().hour;
  var minuts = DateTime.parse("$time").toLocal().minute;
  var _timeZoneName = DateTime.parse("$time").toLocal().timeZoneName;

  var in12Hr = DateFormat("h:mm a").format(DateTime.parse("$time").toLocal());

  // String dateFormat =
  //     '${day.toString() + ' ' + months[month - 1] + ' ' + year.toString() + ', ' + hours.toString() + ':' + minuts.toString() + ' ' + _timeZoneName}';
  String dateFormat =
      '${day.toString() + ' ' + months[month - 1] + ' ' + year.toString() + ', ' + in12Hr.toString().toLowerCase() + ' ' + _timeZoneName}';
  String dayMonthYear =
      '${day.toString() + ' ' + months[month - 1] + ' ' + year.toString()}';

  if (day_month_year)
    return dayMonthYear;
  else
    return dateFormat.toString();
}

String currencyFormatPortfolio(String currency,
    {bool showRupeeSymbol = false}) {
  var doubleCurrency = double.parse(currency);
  final oCcy = new NumberFormat("#,##,##0", "en_IN");
  return "${showRupeeSymbol ? '₹' : ''}" + oCcy.format(doubleCurrency);
}

String currencyFormatPortfolioWithoutCurrencySymbol(String currency) {
  var doubleCurrency = double.parse(currency);
  final oCcy = new NumberFormat("#,##,##0.##", "en_IN");
  return oCcy.format(doubleCurrency);
}

String currencyFormat(String currency) {
  var doubleCurrency = double.parse(currency);
  final oCcy = new NumberFormat("#,##,##0", "en_IN");
  return oCcy.format(doubleCurrency);
}

String currencyFormatMF(String currency) {
  var doubleCurrency = double.parse(currency);
  final oCcy = new NumberFormat("#,##,##0", "en_IN");
  return '₹' + oCcy.format(doubleCurrency);
}

String currencyFormatMFCR(String currency) {
  var doubleCurrency = double.parse(currency);
  final oCcy = new NumberFormat("#,##,##0", "en_IN");
  return '₹' + oCcy.format(doubleCurrency) + ' cr';
}

// For Company Info Screen
String currencyFormatter(String currency, int decimalDigits) {
  String output;
  try {
    num mod = pow(10.00, 2);
    output = ((double.parse(currency) * mod).round().toDouble() / mod)
        .toStringAsFixed(2);
    return NumberFormat.simpleCurrency(name: '', decimalDigits: decimalDigits)
        .format(
      double.parse(output),
    );
  } catch (e) {
    print(e);
    return 'N/A';
  }
}

// For Company Financial Screen
String companyFinancialFormatter(String currency) {
  return NumberFormat.simpleCurrency(name: '', decimalDigits: 2).format(
    double.parse(currency),
  );
}

String nullReview(Object? obj, {String replaceWith = ""}) {
  if (obj == null || obj.toString() == "null") {
    return replaceWith;
  }
  return obj.toString();
}

String doubleDecimalPlaceConvert(String inputValue) {
  String output;
  try {
    num mod = pow(10.00, 2);
    output = ((double.parse(inputValue) * mod).round().toDouble() / mod)
        .toStringAsFixed(2);
  } catch (e) {
    output = "N/A";
    print(e);
  }
  return output;
}

String formatAsQuarterString(int year, int quarter) {
  return DateTime(year, quarter * 3).format('MMM-yy');
}

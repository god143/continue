class DateUtilForNotification {
  static String timeAgo(DateTime timeStamp) {
    if (timeStamp == null) return "";
    Duration diff = DateTime.now().difference(timeStamp);
    if (diff.inDays > 1) return "${diff.inDays}d";
    if (diff.inDays > 0) return "${diff.inDays}d";
    if (diff.inHours > 1) return "${diff.inHours}h";
    if (diff.inHours > 0) return "${diff.inHours}h";
    if (diff.inMinutes > 1) return "${diff.inMinutes}min";
    if (diff.inMinutes > 0) return "${diff.inMinutes}min";
    return "Now";
  }
}

class DateUtil {
  static String timeAgo(DateTime timeStamp) {
    Duration diff = DateTime.now().difference(timeStamp);
    if (diff.inDays > 1) return "${diff.inDays} days ago";
    if (diff.inDays > 0) return "${diff.inDays} day ago";
    if (diff.inHours > 1) return "${diff.inHours} hrs ago";
    if (diff.inHours > 0) return "${diff.inHours} hr ago";
    if (diff.inMinutes > 1) return "${diff.inMinutes} mins ago";
    if (diff.inMinutes > 0) return "${diff.inMinutes} min ago";
    return "Now";
  }
}

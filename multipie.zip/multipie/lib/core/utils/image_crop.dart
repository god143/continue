import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:multipie/core/utils/extensions.dart';

Future<File?> cropImageUtil(
  String imageFilePath, {
  bool compressImage = false,
  bool squareImage = false,
  required BuildContext context,
}) async {
  final croppedFile = await ImageCropper().cropImage(
      sourcePath: imageFilePath,
      compressQuality: compressImage ? 70 : 90,
      aspectRatio: squareImage ? CropAspectRatio(ratioX: 1, ratioY: 1) : null,
      aspectRatioPresets: squareImage
          ? [CropAspectRatioPreset.square]
          : [
              CropAspectRatioPreset.original,
              CropAspectRatioPreset.square,
              CropAspectRatioPreset.ratio3x2,
              CropAspectRatioPreset.ratio4x3,
              CropAspectRatioPreset.ratio5x3,
              CropAspectRatioPreset.ratio5x4,
              CropAspectRatioPreset.ratio7x5,
              CropAspectRatioPreset.ratio16x9
            ],
      androidUiSettings: AndroidUiSettings(
          toolbarTitle: 'Crop Image',
          toolbarColor: context.appTheme.primaryBackgroundColor,
          toolbarWidgetColor: Theme.of(context).primaryColor,
          activeControlsWidgetColor: Theme.of(context).primaryColor,
          //           backgroundColor: context.appTheme.kPrimaryBackGroundColor,
//            cropFrameColor: context.appTheme.kPrimaryBackGroundColor,
//            cropGridColor: context.appTheme.kPrimaryBackGroundColor,
//            dimmedLayerColor: context.appTheme.kPrimaryBackGroundColor,
          statusBarColor: Theme.of(context).primaryColor,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false),
      iosUiSettings: IOSUiSettings(
        title: 'Cropper',
      ));
  return croppedFile;
}

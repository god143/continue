import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_item_model.dart';
import 'package:multipie/features/market/domain/entities/company/promoter_share_holding.dart';

@immutable
class ShareholdingPatternChartData {
  final List<BarChartItemModel> promoterData;
  final List<BarChartItemModel> pledgedData;

  const ShareholdingPatternChartData({
    required this.promoterData,
    required this.pledgedData,
  });

  factory ShareholdingPatternChartData.fromPromoterHoldings({
    required List<PromoterHolding> data,
    int numberOfRecentQuarters = 5,
  }) {
    final recentData = data
        .sorted(
          (l, r) => DateTime(
            int.parse(l.year),
            int.parse(l.quarter),
          ).compareTo(
            DateTime(
              int.parse(r.year),
              int.parse(r.quarter),
            ),
          ),
        )
        .pickLast(numberOfRecentQuarters);
    final pledgedShareholdingChartData = recentData.mapIndexed(
      (index, e) {
        return BarChartItemModel(
          xTitle: formatAsQuarterString(int.parse(e.year), int.parse(e.quarter)),
          yTitle: '',
          yValue: double.tryParse(e.pledgeShareholding) ?? 0,
        );
      },
    ).toList(growable: false);
    final promoterShareholdingChartData = recentData.mapIndexed(
      (index, e) {
        final promoterHolding = double.tryParse(e.promoterShareholding) ?? 0;
        final pledgedHolding = double.tryParse(e.pledgeShareholding) ?? 0;
        return BarChartItemModel(
          xTitle: formatAsQuarterString(int.parse(e.year), int.parse(e.quarter)),
          yTitle: 'A: ${promoterHolding.formatAsString()}%\nP: ${pledgedHolding.formatAsString()}%',
          yValue: promoterHolding - pledgedHolding,
        );
      },
    ).toList(growable: false);
    return ShareholdingPatternChartData(
      promoterData: promoterShareholdingChartData,
      pledgedData: pledgedShareholdingChartData,
    );
  }
}

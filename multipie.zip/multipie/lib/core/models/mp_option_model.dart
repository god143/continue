class MPOptionModel {
  final String displayName;
  final String value;

  const MPOptionModel({
    required this.displayName,
    required this.value,
  });
}

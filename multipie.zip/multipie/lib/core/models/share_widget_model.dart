class ShareWidgetModel {
  final String type;
  final String? data;
  final String? statement;

  ShareWidgetModel({this.type = '', this.data = '', this.statement = ''});

  Map<String, dynamic> toJson() => <String, dynamic>{
        'type': type,
        'data': data,
        'statement': statement,
      };
}

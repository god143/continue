class ConfigResponseModel {
  String? websiteUrl;
  String? authServerUrl;
  int? showPeopleYouMayKnowAfter;
  int? showTrendingAfter;
  String? valuefyServerUrl;
  String? brokerCallbackUrl;
  String? fivePaisaPwaURL;
  String? zerodhaApiKey;

  ConfigResponseModel({
    this.websiteUrl,
    this.authServerUrl,
    this.showTrendingAfter,
    this.valuefyServerUrl,
    this.brokerCallbackUrl,
    this.fivePaisaPwaURL,
    this.zerodhaApiKey,
  });

  ConfigResponseModel.fromJson(Map<String, dynamic> json) {
    websiteUrl = json['websiteUrl'] ?? '';
    authServerUrl = json['authServerUrl'] ?? '';
    showPeopleYouMayKnowAfter = json['showPeopleYouMayKnowAfter'] as int?;
    showTrendingAfter = json['showTrendingAfter'] as int?;
    valuefyServerUrl = json['valuefyServerUrl'] ?? '';
    brokerCallbackUrl = json['brokerCallbackUrl'] ?? '';
    fivePaisaPwaURL = json['fivePaisaPwaURL'] ?? '';
    zerodhaApiKey = json['zerodhaApiKey'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['websiteUrl'] = this.websiteUrl;
    data['authServerUrl'] = this.authServerUrl;
    data['showPeopleYouMayKnowAfter'] = this.showPeopleYouMayKnowAfter;
    data['showTrendingAfter'] = this.showTrendingAfter;
    data['valuefyServerUrl'] = this.valuefyServerUrl;
    data['brokerCallbackUrl'] = this.brokerCallbackUrl;
    data['fivePaisaPwaURL'] = this.fivePaisaPwaURL;
    data['zerodhaApiKey'] = this.zerodhaApiKey;
    return data;
  }
}

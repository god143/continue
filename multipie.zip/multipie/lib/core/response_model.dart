class ResponseModel {
  int statusCode;
  String message;
  Map<String, dynamic> data;

  ResponseModel({
    required this.statusCode,
    required this.message,
    required this.data,
  });
}

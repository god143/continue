part of app_theme;

class LightAppTheme implements AppTheme {
  const LightAppTheme();

  @override
  Color get primaryColor => _AppColors.primaryLight;

  @override
  Color get primaryDisabledColor => _AppColors.mischka;

  @override
  Color get primaryTextColor => _AppColors.mineShaft;

  @override
  Color get primaryTextDisabledColor => tertiaryBackgroundColor;

  @override
  Color get secondaryColor => _AppColors.secondaryLight;

  @override
  Color get primaryBackgroundColor => _AppColors.white;

  @override
  Color get positiveGainColor => _AppColors.malachite;

  @override
  Color get negativeGainColor => _AppColors.sunsetOrange;

  @override
  Color get borderColor => _AppColors.doveGray;

  @override
  Color get cardBackgroundColor => _AppColors.white;

  @override
  Color get secondaryTextColor => _AppColors.doveGray;

  @override
  Color get boxShadowColor => _AppColors.doveGray;

  @override
  Color get tertiaryBackgroundColor => _AppColors.amethystSmoke;

  @override
  Color get searchBackground => _AppColors.silverChalice.withOpacity(0.3);

  @override
  Color get pollColor => borderColor.withOpacity(0.3);

  @override
  Color get scorpionGray => secondaryTextColor;

  @override
  Color get silver => borderColor;

  @override
  Color get kDataTableColor => _AppColors.altoGray;

  @override
  Color get kSecondaryTextColor => borderColor;

  @override
  Color get blueShadeColor => _AppColors.dodgerBlue;

  @override
  Color get kBodySkeletonTextColor => primaryBackgroundColor;

  @override
  Color get kBodySkeletonBackGroundColor => primaryBackgroundColor;

  @override
  Color get kPrimaryBackGroundColor => primaryBackgroundColor;

  @override
  Color get kSecondaryBackGroundColor => borderColor;

  @override
  Color get kOffBackGroundColor => _AppColors.altoGray;

  @override
  Color get kDialogBackGroundColor => darkTextColor;

  @override
  Color get kHighlightBackGroundColor => primaryColor;

  @override
  Color get kPrimaryButtonColor => primaryColor;

  @override
  Color get kPrimaryButtonTextColor => primaryBackgroundColor;

  @override
  Color get kActiveColor => primaryColor;

  @override
  Color get kCursorColor => secondaryColor;

  @override
  Color get kErrorColor => negativeGainColor;

  @override
  Color get kChatBoxActiveColor => primaryColor;

  @override
  Color get kChatBoxBorderColor => secondaryColor;

  @override
  Color get kChatBoxDefaultColor => primaryBackgroundColor;

  @override
  Color get kChatTextActiveColor => primaryBackgroundColor;

  @override
  Color get kChatTextDefaultColor => primaryTextColor;

  @override
  Color get kIconButtonColor => primaryBackgroundColor;

  @override
  Color get kIconColor => darkTextColor;

  @override
  Color get kIconSplashColor => primaryColor;

  @override
  Color get kInputBoxBorderColor => primaryColor;

  @override
  Color get kInputBoxTextColor => primaryColor;

  @override
  Color get chartTooltipBackgroundColor => blueShadeColor.withAlpha(30);

  @override
  Color get darkTextColor => _AppColors.black;

  @override
  Color get shimmerBaseColor => _AppColors.silverChalice;

  @override
  Color get shimmerHighlightColor => _AppColors.altoGray;

  @override
  Color get transparentColor => Colors.transparent;

  @override
  Color get postActionButtonColor => _AppColors.doveGray;

  @override
  Color get equityChartColor => primaryColor;

  @override
  Color get goldChartColor => _AppColors.supernova;

  @override
  Color get debtChartColor => _AppColors.dodgerBlue;

  @override
  Color get largeCapEquityChartColor => primaryColor;

  @override
  Color get midAndSmallCapEquityChartColor => primaryColor.withOpacity(0.6);

  @override
  Color get equityMFChartColor => primaryColor.withOpacity(0.4);

  @override
  Color get chartLabelTextColor => _AppColors.white;

  @override
  Color get goldMFAndETFChartColor => _AppColors.supernova.withOpacity(0.6);

  @override
  Color get sgbChartColor => _AppColors.supernova;

  @override
  Color get debtMFChartColor => _AppColors.dodgerBlue;

  @override
  Color get otherBondsChartColor => _AppColors.dodgerBlue.withOpacity(0.4);

  @override
  Color get neutralColor => _AppColors.supernova;

  @override
  Color get lightTextColor => _AppColors.white;

  @override
  Color get alternateRowColor => primaryColor.withOpacity(0.05);

  @override
  Color get highlightedRowColor => primaryColor;

  @override
  Color get primaryRowColor => transparentColor;

  @override
  Color get activeIndicationColor => primaryColor;

  @override
  Color get flexibleHeaderBackgroundColor => primaryColor;

  @override
  Gradient get buttonBackgroundGradient => LinearGradient(
        colors: [
          primaryColor,
          primaryColor,
        ],
      );

  @override
  Color get unreadNotificationColor => tertiaryBackgroundColor.withOpacity(0.5);

  @override
  Color get purple => _AppColors.primaryLight;

  @override
  Color get pollOptionBackgroundColor => _AppColors.amethystSmoke;

  @override
  Color get primaryButtonTextColor => primaryColor;

  @override
  Color get communityCardHeaderColor => _AppColors.mountainMeadow;

  @override
  Color get screenerCardColor => _AppColors.turquoise;

  @override
  Color get postImageBackgroundColor => _AppColors.altoGray.withOpacity(0.3);

  @override
  Color get mostBoughtSoldStocksSectionBackground => _AppColors.sail.withOpacity(0.1);

  @override
  Color get expandableTileHeaderColor => _AppColors.amethystSmoke;

  @override
  Color get progressBarColor => expandableTileHeaderColor;
}

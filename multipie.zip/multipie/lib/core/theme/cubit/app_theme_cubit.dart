import 'package:bloc/bloc.dart';
import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:multipie/core/theme/app_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

part 'app_theme_state.dart';

class AppThemeCubit extends Cubit<AppThemeState> {
  AppThemeCubit({
    required this.preferences,
  }) : super(
          AppThemeState(themeMode: ThemeMode.system),
        ) {
    _loadUserPreferredTheme();
  }

  final SharedPreferences preferences;
  static const appThemePreferenceKey = 'APP_THEME_MODE_PREFERENCE';
  static const _systemTheme = 'SYSTEM_THEME';
  static const _lightModeTheme = 'LIGHT_THEME';
  static const _darkModeTheme = 'DARK_THEME';
  static const _lightTheme = const LightAppTheme();
  static const _darkTheme = const DarkAppTheme();

  bool get isDarkMode {
    switch (state.themeMode) {
      case ThemeMode.light:
        return false;
      case ThemeMode.dark:
        return true;
      case ThemeMode.system:
        return _isSystemInDarkMode;
    }
  }

  bool get _isSystemInDarkMode => SchedulerBinding.instance.window.platformBrightness == Brightness.dark;

  AppTheme get theme => isDarkMode ? _darkTheme : _lightTheme;

  void _loadUserPreferredTheme() {
    final userPreference = preferences.getString(appThemePreferenceKey);
    final ThemeMode themeMode;
    switch (userPreference) {
      case _lightModeTheme:
        themeMode = ThemeMode.light;
        break;
      case _darkModeTheme:
        themeMode = ThemeMode.dark;
        break;
      default:
        themeMode = ThemeMode.system;
        break;
    }
    emit(
      AppThemeState(themeMode: themeMode),
    );
  }

  Future<void> setAppTheme(ThemeMode themeMode) async {
    CleverTapPlugin.recordEvent('App Theme', {
      'source': 'settings',
      'mode': themeMode == ThemeMode.system
          ? _isSystemInDarkMode
              ? ThemeMode.dark.name
              : ThemeMode.light.name
          : themeMode.name
    });

    final String preference;
    switch (themeMode) {
      case ThemeMode.light:
        preference = _lightModeTheme;
        break;
      case ThemeMode.dark:
        preference = _darkModeTheme;
        break;
      case ThemeMode.system:
        preference = _systemTheme;
        break;
    }
    await preferences.setString(appThemePreferenceKey, preference);
    emit(
      AppThemeState(themeMode: themeMode),
    );
  }

  AppTheme appThemeForMode(ThemeMode mode) {
    final AppTheme theme;
    switch (mode) {
      case ThemeMode.system:
        theme = _isSystemInDarkMode ? _darkTheme : _lightTheme;
        break;
      case ThemeMode.light:
        theme = _lightTheme;
        break;
      case ThemeMode.dark:
        theme = _darkTheme;
        break;
    }
    return theme;
  }
}

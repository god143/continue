part of app_theme;

abstract class AppTheme {
  Color get primaryColor;
  Color get primaryDisabledColor;
  Color get secondaryColor;

  Color get primaryBackgroundColor;
  Color get cardBackgroundColor;
  Color get tertiaryBackgroundColor;
  Color get flexibleHeaderBackgroundColor;

  Color get primaryTextColor;
  Color get primaryTextDisabledColor;
  Color get secondaryTextColor;
  Color get darkTextColor;
  Color get lightTextColor;

  Color get borderColor;
  Color get positiveGainColor;
  Color get negativeGainColor;
  Color get postActionButtonColor;
  Color get shimmerBaseColor;
  Color get shimmerHighlightColor;
  Color get boxShadowColor;
  Color get searchBackground;
  Color get blueShadeColor;
  Color get pollColor;
  Color get neutralColor;
  Color get pollOptionBackgroundColor;
  Color get postImageBackgroundColor;

  Color get chartLabelTextColor;
  Color get equityChartColor;
  Color get goldChartColor;
  Color get debtChartColor;
  Color get largeCapEquityChartColor;
  Color get midAndSmallCapEquityChartColor;
  Color get equityMFChartColor;
  Color get goldMFAndETFChartColor;
  Color get sgbChartColor;
  Color get debtMFChartColor;
  Color get otherBondsChartColor;

  Color get primaryRowColor;
  Color get alternateRowColor;
  Color get highlightedRowColor;

  Color get activeIndicationColor;

  Color get unreadNotificationColor;
  Color get purple;

  Gradient get buttonBackgroundGradient;

  Color get primaryButtonTextColor;

  Color get communityCardHeaderColor;

  Color get screenerCardColor;

  Color get mostBoughtSoldStocksSectionBackground;

  Color get expandableTileHeaderColor;
  Color get progressBarColor;

  //!!!: FOLLOWING ALL ARE OLDER UI BASED VARIABLES WHICH HAS GOOD ROOM OF IMPROVEMENT
  Color get scorpionGray;
  Color get silver;
  Color get kDataTableColor;
  Color get kSecondaryTextColor;
  Color get kBodySkeletonTextColor;
  Color get kBodySkeletonBackGroundColor;
  Color get kPrimaryBackGroundColor;
  Color get kSecondaryBackGroundColor;
  Color get kOffBackGroundColor;
  Color get kHighlightBackGroundColor;
  Color get kDialogBackGroundColor;
  Color get kPrimaryButtonColor;
  Color get kPrimaryButtonTextColor;
  Color get kErrorColor;
  Color get kActiveColor;
  Color get kCursorColor;
  Color get kIconColor;
  Color get kIconButtonColor;
  Color get kIconSplashColor;
  Color get kChatBoxDefaultColor;
  Color get kChatBoxActiveColor;
  Color get kChatTextDefaultColor;
  Color get kChatTextActiveColor;
  Color get kChatBoxBorderColor;
  Color get kInputBoxBorderColor;
  Color get kInputBoxTextColor;
  Color get transparentColor;
  Color get chartTooltipBackgroundColor;
}

part of app_theme;

class DarkAppTheme implements AppTheme {
  const DarkAppTheme();

  @override
  Color get primaryColor => _AppColors.primaryDark;

  @override
  Color get primaryDisabledColor => _AppColors.mineShaftLighter;

  @override
  Color get primaryTextColor => _AppColors.altoGray;

  @override
  Color get primaryTextDisabledColor => tertiaryBackgroundColor;

  @override
  Color get secondaryColor => _AppColors.secondaryDark;

  @override
  Color get primaryBackgroundColor => _AppColors.mineShaft;

  @override
  Color get positiveGainColor => _AppColors.mountainMeadow;

  @override
  Color get negativeGainColor => _AppColors.carnation;

  @override
  Color get borderColor => _AppColors.altoGray;

  @override
  Color get cardBackgroundColor => _AppColors.mineShaftLighter;

  @override
  Color get secondaryTextColor => _AppColors.silverChalice;

  @override
  Color get boxShadowColor => _AppColors.mineShaftLighter;

  @override
  Color get tertiaryBackgroundColor => _AppColors.white;

  @override
  Color get searchBackground => _AppColors.silverChalice.withOpacity(0.3);

  @override
  Color get pollColor => borderColor.withOpacity(0.3);

  @override
  Color get scorpionGray => secondaryTextColor;

  @override
  Color get silver => borderColor;

  @override
  Color get kDataTableColor => _AppColors.mineShaft;

  @override
  Color get kSecondaryTextColor => borderColor;

  @override
  Color get blueShadeColor => _AppColors.anakiwa;

  @override
  Color get kBodySkeletonTextColor => primaryBackgroundColor;

  @override
  Color get kBodySkeletonBackGroundColor => primaryBackgroundColor;

  @override
  Color get kPrimaryBackGroundColor => primaryBackgroundColor;

  @override
  Color get kSecondaryBackGroundColor => borderColor;

  @override
  Color get kOffBackGroundColor => _AppColors.doveGray;

  @override
  Color get kDialogBackGroundColor => darkTextColor;

  @override
  Color get kHighlightBackGroundColor => primaryColor;

  @override
  Color get kPrimaryButtonColor => primaryColor;

  @override
  Color get kPrimaryButtonTextColor => primaryBackgroundColor;

  @override
  Color get kActiveColor => primaryColor;

  @override
  Color get kCursorColor => secondaryColor;

  @override
  Color get kErrorColor => negativeGainColor;

  @override
  Color get kChatBoxActiveColor => primaryColor;

  @override
  Color get kChatBoxBorderColor => secondaryColor;

  @override
  Color get kChatBoxDefaultColor => primaryBackgroundColor;

  @override
  Color get kChatTextActiveColor => primaryBackgroundColor;

  @override
  Color get kChatTextDefaultColor => primaryTextColor;

  @override
  Color get kIconButtonColor => primaryBackgroundColor;

  @override
  Color get kIconColor => darkTextColor;

  @override
  Color get kIconSplashColor => primaryColor;

  @override
  Color get kInputBoxBorderColor => primaryColor;

  @override
  Color get kInputBoxTextColor => primaryColor;

  @override
  Color get chartTooltipBackgroundColor => blueShadeColor.withAlpha(30);

  @override
  Color get darkTextColor => _AppColors.white;

  @override
  Color get shimmerBaseColor => _AppColors.mineShaftLighter;

  @override
  Color get shimmerHighlightColor => _AppColors.mineShaft;

  @override
  Color get transparentColor => Colors.transparent;

  @override
  Color get postActionButtonColor => _AppColors.altoGray;

  @override
  Color get equityChartColor => _AppColors.cornflowerBlue;

  @override
  Color get goldChartColor => _AppColors.oldGold;

  @override
  Color get debtChartColor => _AppColors.turquoise;

  @override
  Color get largeCapEquityChartColor => _AppColors.cornflowerBlue;

  @override
  Color get midAndSmallCapEquityChartColor => _AppColors.eastBay;

  @override
  Color get equityMFChartColor => _AppColors.chambray;

  @override
  Color get chartLabelTextColor => _AppColors.white;

  @override
  Color get goldMFAndETFChartColor => _AppColors.mustard;

  @override
  Color get sgbChartColor => _AppColors.oldGold;

  @override
  Color get debtMFChartColor => _AppColors.turquoise;

  @override
  Color get otherBondsChartColor => _AppColors.genoa;

  @override
  Color get neutralColor => _AppColors.supernova;

  @override
  Color get lightTextColor => _AppColors.white;

  @override
  Color get alternateRowColor => cardBackgroundColor;

  @override
  Color get highlightedRowColor => activeIndicationColor.withOpacity(0.5);

  @override
  Color get primaryRowColor => transparentColor;

  @override
  Color get activeIndicationColor => _AppColors.heliotrope;

  @override
  Color get flexibleHeaderBackgroundColor => cardBackgroundColor;

  @override
  Gradient get buttonBackgroundGradient => LinearGradient(
        colors: [
          _AppColors.purpleHeart,
          _AppColors.electricViolet,
        ],
      );

  @override
  Color get unreadNotificationColor => borderColor.withOpacity(0.1);

  @override
  Color get purple => _AppColors.primaryLight;

  @override
  Color get pollOptionBackgroundColor => cardBackgroundColor;

  @override
  Color get primaryButtonTextColor => _AppColors.black;

  @override
  Color get communityCardHeaderColor => _AppColors.mountainMeadow;

  @override
  Color get screenerCardColor => _AppColors.turquoise;

  @override
  Color get postImageBackgroundColor => _AppColors.mineShaftLighter;

  @override
  Color get mostBoughtSoldStocksSectionBackground => _AppColors.sail.withOpacity(0.1);

  @override
  Color get expandableTileHeaderColor => _AppColors.amethystSmoke;

  @override
  Color get progressBarColor => expandableTileHeaderColor;
}

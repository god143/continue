part of app_theme;

class _AppColors {
  _AppColors._();

  static const primaryLight = purple;
  static const secondaryLight = pictonBlue;
  static const primaryDark = white;
  static const secondaryDark = anakiwa;

  // White variants
  static const white = Color(0xFFFFFFFF);

  // Black variants
  static const black = const Color(0xFF000000);

  // Purple variants
  static const purple = Color(0xFF4D0099);

  static const heliotrope = Color(0xFFA351F4);
  static const mischka = Color(0xFFE5DEE8);
  static const amethystSmoke = Color(0xFFA994B8);
  static const purpleHeart = Color(0xFF6E12CA);
  static const electricViolet = Color(0xFF9123FF);

  // Blue variants
  static const pictonBlue = Color(0xFF3C91E6);
  static const dodgerBlue = const Color(0xFF00B4FE);
  static const anakiwa = Color(0xFF82DAFF);
  static const cornflowerBlue = Color(0xFF6B78F1);
  static const eastBay = Color(0xFF4A508D);
  static const chambray = Color(0xFF333C83);
  static const sail = Color(0xFFB5E3FB);

  // Gray variants
  static const altoGray = const Color(0xFFE8E8E8);
  static const silverChalice = const Color(0xFFA6A6A6);
  static const doveGray = const Color(0xFF727272);
  static const mineShaft = Color(0xFF252525);
  static const mineShaftLighter = const Color(0xFF2D2D2D);

  // Red variants
  static const sunsetOrange = const Color(0xFFF64545);
  static const carnation = const Color(0xFFFB6262);

  // Green variants
  static const malachite = const Color(0xFF29E25D);
  static const mountainMeadow = const Color(0xFF1BB646);
  static const turquoise = const Color(0xFF4DD7BD);
  static const genoa = const Color(0xFF148873);

  // Orange Variants
  static const supernova = const Color(0xFFFCC90A);
  static const oldGold = const Color(0xFFC9A932);
  static const mustard = const Color(0xFFFFDB56);
}

library app_theme;

import 'package:flutter/material.dart';

part 'app_colors.dart';
part 'app_theme_interface.dart';
part 'dark_app_theme.dart';
part 'light_app_theme.dart';

ThemeData lightMaterialThemeData() {
  const background = _AppColors.white;
  return ThemeData(
    fontFamily: 'Roboto',
    scaffoldBackgroundColor: background,
    primaryColor: _AppColors.primaryLight,
    colorScheme: ColorScheme.light(
      primary: _AppColors.primaryLight,
      secondary: _AppColors.secondaryLight,
    ),
    appBarTheme: AppBarTheme(
      color: background,
      iconTheme: IconThemeData(
        color: _AppColors.primaryLight,
      ),
    ),
    unselectedWidgetColor: _AppColors.silverChalice,
  );
}

ThemeData darkMaterialThemeData() {
  const background = _AppColors.mineShaft;
  return ThemeData(
    fontFamily: 'Roboto',
    scaffoldBackgroundColor: background,
    primaryColor: _AppColors.primaryDark,
    colorScheme: ColorScheme.light(
      primary: _AppColors.primaryDark,
      secondary: _AppColors.secondaryDark,
    ),
    appBarTheme: AppBarTheme(
      color: background,
      iconTheme: IconThemeData(
        color: _AppColors.primaryDark,
      ),
    ),
    unselectedWidgetColor: _AppColors.altoGray,
  );
}

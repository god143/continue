import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class CustomIcon extends StatelessWidget {
  final CustomIconData icon;
  final Color? color;
  final double width;
  final double height;
  final String? semanticsLabel;

  CustomIcon(
    this.icon, {
    this.color,
    required this.width,
    required this.height,
    this.semanticsLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        width: width,
        height: height,
        child: SvgPicture.asset(
          this.icon.assetName,
          color: this.color,
          semanticsLabel: this.semanticsLabel,
        ),
      ),
    );
  }
}

class CustomIconData {
  final String assetName;

  const CustomIconData({required this.assetName});

  factory CustomIconData.getIcon(String assetName) {
    return CustomIconData(assetName: assetName);
  }
}

class CustomIcons {
  static const CustomIconData heart_solid = CustomIconData(assetName: 'assets/icons/ic_heart_solid.svg');
  static const CustomIconData heart_line = CustomIconData(assetName: 'assets/icons/ic_heart_line.svg');
  static const CustomIconData share = CustomIconData(assetName: 'assets/icons/ic_share_line.svg');
  static const CustomIconData share2 = CustomIconData(assetName: 'assets/icons/ic_share.svg');
  static const CustomIconData suitcase = CustomIconData(assetName: 'assets/icons/suitcase.svg');
  static const CustomIconData message = CustomIconData(assetName: 'assets/icons/Message.svg');
  static const CustomIconData messages = CustomIconData(assetName: 'assets/icons/ic_messages.svg');
  static const CustomIconData noti_selected = CustomIconData(assetName: 'assets/icons/noti_selected.svg');
  static const CustomIconData noti_not_selected = CustomIconData(assetName: 'assets/icons/noti_unselected.svg');
  static const CustomIconData ic_comment = CustomIconData(assetName: 'assets/icons/ic_comment_line.svg');
  static const CustomIconData ic_home_line = CustomIconData(assetName: 'assets/icons/nav_home_unselected.svg');
  static const CustomIconData ic_home_solid = CustomIconData(assetName: 'assets/icons/nav_home_selected.svg');
  static const CustomIconData ic_money_bag_line = CustomIconData(assetName: 'assets/icons/money_bag_line.svg');
  static const CustomIconData ic_money_bag_solid = CustomIconData(assetName: 'assets/icons/money_bag_solid.svg');
  static const CustomIconData ic_search_line = CustomIconData(assetName: 'assets/icons/nav_search_unselected.svg');
  static const CustomIconData ic_search_solid = CustomIconData(assetName: 'assets/icons/nav_search_selected.svg');
  static const CustomIconData ic_check_poll = CustomIconData(assetName: 'assets/icons/ic_check_poll.svg');
  static const CustomIconData repost = CustomIconData(assetName: 'assets/icons/ic_repost_line.svg');
  static const CustomIconData ic_arrow_up = CustomIconData(assetName: 'assets/icons/ic_arrow_up.svg');
  static const CustomIconData ic_edit_profile = CustomIconData(assetName: 'assets/icons/ic_edit_profile.svg');
  static const CustomIconData ic_camera = CustomIconData(assetName: 'assets/icons/ic_camera.svg');
  static const CustomIconData ic_text = CustomIconData(assetName: 'assets/icons/ic_text.svg');
  static const CustomIconData ic_twitter = CustomIconData(assetName: 'assets/icons/ic_twitter.svg');
  static const CustomIconData ic_invite = CustomIconData(assetName: 'assets/icons/ic_invite.svg');
  static const CustomIconData ic_linkedin = CustomIconData(assetName: 'assets/icons/ic_linkedin.svg');
  static const CustomIconData ic_reward = CustomIconData(assetName: 'assets/icons/reward_icon.svg');

  // Tab Icons
  static const CustomIconData ic_portfolio = CustomIconData(assetName: 'assets/icons/ic_portfolio.svg');
  static const CustomIconData ic_portfolio_selected =
      CustomIconData(assetName: 'assets/icons/ic_portfolio_selected.svg');
  static const CustomIconData ic_notifications = CustomIconData(assetName: 'assets/icons/ic_notifications.svg');
  static const CustomIconData ic_notifications_selected =
      CustomIconData(assetName: 'assets/icons/ic_notifications_selected.svg');
  static const CustomIconData ic_community = CustomIconData(assetName: 'assets/icons/ic_community.svg');
  static const CustomIconData ic_community_selected =
      CustomIconData(assetName: 'assets/icons/ic_community_selected.svg');
  static const CustomIconData ic_products = CustomIconData(assetName: 'assets/icons/money_bag_line.svg');
  static const CustomIconData ic_products_selected = CustomIconData(assetName: 'assets/icons/ic_products_selected.svg');
  static const CustomIconData ic_discover = CustomIconData(assetName: 'assets/icons/ic_discover.svg');
  static const CustomIconData ic_discover_selected = CustomIconData(assetName: 'assets/icons/ic_discover_selected.svg');
}

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:multipie/core/models/shareholding_pattern_chart_data.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_model.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/bar_chart.dart';

class ShareholdingPatternChart extends StatelessWidget {
  ShareholdingPatternChart({
    Key? key,
    required this.chartData,
  }) : super(key: key);

  final ShareholdingPatternChartData chartData;

  @override
  Widget build(BuildContext context) {
    final _firstChartColor = Theme.of(context).primaryColor.withOpacity(0.75);
    final _secondChartColor = context.appTheme.blueShadeColor.withOpacity(0.75);
    return MPBarChart(
      title: "",
      data: [
        BarChartModel(
          chartId: 'Actual (A)',
          data: chartData.promoterData,
          barColor: _secondChartColor,
          legendColor: _firstChartColor,
        ),
        BarChartModel(
          chartId: 'Pledged (P)',
          data: chartData.pledgedData,
          barColor: _firstChartColor,
          legendColor: _secondChartColor,
        ),
      ],
      barGroupingType: charts.BarGroupingType.groupedStacked,
    );
  }
}

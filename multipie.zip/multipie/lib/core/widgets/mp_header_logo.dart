import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:multipie/core/utils/extensions.dart';

class MPHeaderLogo extends StatelessWidget {
  const MPHeaderLogo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
      'assets/icons/ic_multipie_logo.svg',
      width: 22,
      color: context.appTheme.activeIndicationColor,
    );
  }
}

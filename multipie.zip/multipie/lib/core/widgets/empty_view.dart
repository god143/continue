import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class EmptyView extends StatelessWidget {
  final String title;
  final String subTitle;
  final Function() onRetry;

  EmptyView({
    required this.title,
    required this.subTitle,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        height: MediaQuery.of(context).size.height - 200,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: mpHeadLine2(context: context),
            ),
            SizedBox(
              height: sHeight(12),
            ),
            Text(
              subTitle,
              textAlign: TextAlign.center,
              style: mpHeadLine5(context: context),
            ),
            SizedBox(
              height: sHeight(12),
            ),
            InkWell(
              onTap: onRetry,
              child: Container(
                decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor, borderRadius: BorderRadius.all(Radius.circular(sSize(7)))),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 12),
                  child: Text(
                    "Try Again",
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.cardBackgroundColor,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

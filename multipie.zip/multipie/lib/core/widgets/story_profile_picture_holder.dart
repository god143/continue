import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class StoryProfilePictureHolder extends StatelessWidget {
  // profile image url
  final String imageUrl;

  // place holder letter
  final String holderLetter;
  final double textSize;
  final TextStyle textStyle;

  StoryProfilePictureHolder({
    Key? key,
    required this.imageUrl,
    this.holderLetter = '',
    this.textSize = 24,
    required this.textStyle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        (imageUrl.isNullOrEmpty())
            ? Padding(
                padding: const EdgeInsets.all(3.0),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: context.appTheme.primaryBackgroundColor,
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    holderLetter.toUpperCase(),
                    style: textStyle != null
                        ? textStyle
                        : mpHeadLine5(
                            context: context,
                            textColor: context.appTheme.secondaryTextColor,
                          ),
                  ),
                ),
              )
            : CircleAvatar(
                radius: 27,
                backgroundColor: context.appTheme.primaryBackgroundColor,
                backgroundImage: CachedNetworkImageProvider(imageUrl),
              ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper.dart';
import 'package:multipie/core/utils/extensions.dart';

class CustomBodySkeleton extends StatelessWidget {
  // title of the screen
  final String title;
  // leading icons
  final List<Widget> leading;
  // trailing icons
  final List<Widget> trailing;
  // body of the screen
  final Widget child;

  const CustomBodySkeleton({
    Key? key,
    required this.title,
    required this.leading,
    required this.trailing,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: context.appTheme.kHighlightBackGroundColor,
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              // custom appbar
              Padding(
                padding: EdgeInsets.only(
                  left: sWidth(10.0),
                  top: sHeight(5.0),
                  right: sWidth(10.0),
                  bottom: sHeight(8.0),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // leading icons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: leading,
                    ),
                    // title
                    Text(
                      title,
                      style: kAppBarTitle(context),
                    ),
                    // trailing icons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: trailing,
                    ),
                  ],
                ),
              ),
              // rounded container
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: context.appTheme.kPrimaryBackGroundColor,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(sHeight(20.0)),
                      topRight: Radius.circular(sHeight(20.0)),
                    ),
                  ),
                  // body of the screen
                  child: child,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:shimmer/shimmer.dart';

class DefaultImagePlaceholder extends StatelessWidget {
  const DefaultImagePlaceholder({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      child: Container(
        color: context.appTheme.cardBackgroundColor,
      ),
      baseColor: context.appTheme.shimmerBaseColor,
      highlightColor: context.appTheme.shimmerHighlightColor,
      enabled: true,
    );
  }
}

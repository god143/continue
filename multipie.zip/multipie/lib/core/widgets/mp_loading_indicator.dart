import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

class MPLoadingIndicator extends StatelessWidget {
  const MPLoadingIndicator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircularProgressIndicator(
      color: context.appTheme.activeIndicationColor,
    );
  }
}

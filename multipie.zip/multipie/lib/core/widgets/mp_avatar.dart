import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';

class MPAvatar extends StatelessWidget {
  const MPAvatar({
    Key? key,
    required this.size,
    required this.imageUrl,
    required this.placeholderText,
    this.isCircular = false,
  }) : super(key: key);

  final double size;
  final String imageUrl;
  final String placeholderText;
  final bool isCircular;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: isCircular ? BorderRadius.circular(size / 2) : null,
      ),
      clipBehavior: Clip.hardEdge,
      child: imageUrl.isEmpty
          ? _NamePlaceholder(
              size: size,
              placeholderText: placeholderText,
            )
          : CachedNetworkImage(
              imageUrl: imageUrl,
              placeholder: (_, __) => DefaultImagePlaceholder(),
              errorWidget: (_, __, ___) => _NamePlaceholder(
                size: size,
                placeholderText: placeholderText,
              ),
              fit: isCircular ? BoxFit.cover : null,
            ),
    );
  }
}

class _NamePlaceholder extends StatelessWidget {
  const _NamePlaceholder({
    Key? key,
    required this.size,
    required this.placeholderText,
  }) : super(key: key);

  final double size;
  final String placeholderText;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size / 2),
        border: Border.all(
          color: context.appTheme.borderColor,
          width: 0.5,
        ),
      ),
      child: Center(
        child: Text(
          placeholderText,
          style: mpHeadLine6(
            context: context,
            textColor: context.appTheme.activeIndicationColor,
          ),
        ),
      ),
    );
  }
}

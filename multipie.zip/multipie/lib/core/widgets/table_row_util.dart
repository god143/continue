import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper.dart';
import 'package:multipie/core/utils/extensions.dart';

class TableRowWidget extends StatelessWidget {
  final bool isBold;
  final Color? bgColor;
  final List<String> data;
  final List<Widget>? dataWidgets;
  final Function()? onTap;
  final TextStyle? textStyle;
  final MainAxisAlignment mainRowAlignment;

  TableRowWidget({
    this.bgColor,
    this.data = const [],
    this.dataWidgets,
    this.onTap,
    // this.first,
    // this.second,
    // this.third,
    this.textStyle,
    this.mainRowAlignment = MainAxisAlignment.spaceEvenly,
    this.isBold = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        color: bgColor ?? context.appTheme.cardBackgroundColor,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16.0, 0, 16, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            // If we will provide list of widgets it will show wigets or it will generate list from string data from listWidget() method
            children: dataWidgets != null ? dataWidgets! : listWidget(context),
          ),
        ),
      ),
    );
  }

  List<Widget> listWidget(BuildContext context) {
    return data
        .map((element) => Expanded(
              child: Text(
                element.toString(),
                //if text style is not provided it will have default style
                style: textStyle == null
                    ? TextStyle(
                        fontFamily: "Avenir",
                        fontSize: sSp(6),
                        color: context.appTheme.primaryTextColor,
                      )
                    : textStyle,
              ),
            ))
        .toList();
  }
}

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/widgets/profile_mode.dart';

class ProfilePictureHolder extends StatelessWidget {
  final String? imageUrl;

  // place holder letter
  final String holderLetter;
  final isParentPost;
  final double textSize;
  final TextStyle? textStyle;
  final bool fromProfile;
  final String? profileMode;
  final Color? backgroundColor;
  final bool showProfileMode;

  ProfilePictureHolder({
    Key? key,
    required this.imageUrl,
    this.profileMode,
    this.holderLetter = '',
    this.isParentPost = false,
    this.textSize = 24,
    this.fromProfile = false,
    this.textStyle,
    this.backgroundColor,
    this.showProfileMode = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        (imageUrl.isNullOrEmpty())
            ? Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: backgroundColor ?? context.appTheme.blueShadeColor.withOpacity(0.3),
                  shape: BoxShape.circle,
                ),
                child: Text(
                  holderLetter.toUpperCase(),
                  style: textStyle != null
                      ? textStyle
                      : isParentPost
                          ? mpHeadLine4(
                              context: context,
                              textColor: context.appTheme.primaryColor,
                            )
                          : mpHeadLine3(
                              context: context,
                              textColor: context.appTheme.primaryColor,
                              fontWeight: FontWeight.normal,
                            ),
                ),
              )
            : Container(
                width: double.infinity,
                height: double.infinity,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10000.0),
                  child: CachedNetworkImage(
                    imageUrl: imageUrl!,
                    fit: BoxFit.cover,
                    errorWidget: (context, url, error) {
                      return Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: context.appTheme.primaryBackgroundColor,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          holderLetter,
                          style: textStyle != null
                              ? textStyle
                              : isParentPost
                                  ? mpHeadLine6(
                                      context: context,
                                      textColor: context.appTheme.secondaryTextColor,
                                    )
                                  : mpHeadLine5(
                                      context: context,
                                      textColor: context.appTheme.secondaryTextColor,
                                    ),
                        ),
                      );
                    },
                  ),
                ),
              ),
        if (showProfileMode && !fromProfile)
          Positioned(
            right: -5,
            bottom: 0,
            child: ProfileMode(selection: profileMode ?? 'neutral'),
          ),
      ],
    );
  }
}

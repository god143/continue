import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class MPTabBar extends StatefulWidget {
  const MPTabBar({
    Key? key,
    required this.tabController,
    required this.tabsCount,
    required this.getTabTitle,
    this.isTabScrollable = false,
  }) : super(key: key);

  final TabController tabController;
  final int tabsCount;
  final String Function(int index) getTabTitle;
  final bool isTabScrollable;

  @override
  State<MPTabBar> createState() => _MPTabBarState();
}

class _MPTabBarState extends State<MPTabBar> {
  late Key _tabBarKey;

  @override
  void initState() {
    _tabBarKey = Key('${widget.tabController.index}');
    widget.tabController.addListener(_onTabScrolled);
    super.initState();
  }

  void _onTabScrolled() {
    if (widget.tabController.indexIsChanging) {
      return;
    }
    setState(() {
      _tabBarKey = Key('${widget.tabController.index}');
    });
  }

  @override
  Widget build(BuildContext context) {
    return TabBar(
      key: _tabBarKey,
      controller: widget.tabController,
      indicatorWeight: 4,
      indicatorColor: context.appTheme.activeIndicationColor,
      isScrollable: widget.isTabScrollable,
      tabs: List.generate(
        widget.tabsCount,
        (index) => _TabBarItem(
          title: widget.getTabTitle(index),
          isActive: index == widget.tabController.index,
        ),
      ).toList(),
    );
  }

  @override
  void dispose() {
    widget.tabController.removeListener(_onTabScrolled);
    super.dispose();
  }
}

class _TabBarItem extends StatelessWidget {
  const _TabBarItem({
    Key? key,
    required this.title,
    required this.isActive,
  }) : super(key: key);

  final String title;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    return Tab(
      child: Container(
        alignment: Alignment.center,
        child: Text(
          title,
          style: mpHeadLine5(
            context: context,
            textColor: isActive ? context.appTheme.primaryColor : context.appTheme.secondaryTextColor,
          ),
        ),
      ),
    );
  }
}

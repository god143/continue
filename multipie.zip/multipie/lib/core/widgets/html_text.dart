import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:html/dom.dart' as dom;
import 'package:multipie/core/theme/cubit/app_theme_cubit.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:provider/src/provider.dart';

class MPHTMLText extends StatefulWidget {
  const MPHTMLText({
    Key? key,
    required this.data,
    this.onLinkTap,
    this.bodyPadding,
    this.bodyMargin,
  }) : super(key: key);

  final String data;
  final void Function(String?, RenderContext, Map<String, String>, dom.Element?)? onLinkTap;
  final EdgeInsets? bodyPadding;
  final EdgeInsets? bodyMargin;

  @override
  State<MPHTMLText> createState() => _MPHTMLTextState();
}

class _MPHTMLTextState extends State<MPHTMLText> {
  @override
  void initState() {
    final window = WidgetsBinding.instance.window;
    window.onPlatformBrightnessChanged = () {
      final cubit = context.read<AppThemeCubit>();
      if (cubit.state.themeMode == ThemeMode.system) {
        // Force build to adopt the new theme based style
        setState(() {});
      }
    };

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Html(
      data: widget.data,
      onLinkTap: widget.onLinkTap,
      style: {
        'body': Style(
          color: context.appTheme.primaryTextColor,
          padding: widget.bodyPadding,
          margin: widget.bodyMargin,
        ),
      },
    );
  }
}

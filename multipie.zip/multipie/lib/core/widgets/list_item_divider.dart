import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

class MPListItemDivider extends StatelessWidget {
  const MPListItemDivider({
    Key? key,
    this.thickness = 0.2,
    this.height = 0.4,
  }) : super(key: key);

  final double thickness;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Divider(
      thickness: thickness,
      height: height,
      color: context.appTheme.borderColor,
    );
  }
}

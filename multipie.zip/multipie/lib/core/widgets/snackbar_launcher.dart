import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

snackbarLauncher(BuildContext context, String message) {
  //Wait till all the widgests are build
  return WidgetsBinding.instance.addPostFrameCallback((_) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        backgroundColor: context.appTheme.kHighlightBackGroundColor,
        content: Text(
          message,
          style: mpHeadLine6(
            context: context,
            textColor: context.appTheme.lightTextColor,
          ),
        ),
      ),
    );
  });
}

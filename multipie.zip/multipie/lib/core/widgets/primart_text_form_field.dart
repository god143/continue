import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class PrimaryTextFormField extends StatelessWidget {
  const PrimaryTextFormField({
    Key? key,
    required this.controller,
    this.enabled,
    this.keyboardType,
    this.maxLength,
    this.textInputAction,
    this.onChanged,
    this.validator,
    this.onFieldSubmitted,
    this.autovalidateMode,
    this.labelText,
    this.hintText,
    this.counterText,
    this.contentPadding,
    this.obscureText = false,
    this.minLines,
    this.maxLines = 1,
    this.prefixIcon,
    this.prefixIconConstraints,
    this.suffixIcon,
    this.inputFormatters,
    this.floatingLabelBehavior,
    this.textCapitalization = TextCapitalization.none,
    this.onTap,
  }) : super(key: key);

  final TextEditingController controller;
  final bool? enabled;
  final TextInputType? keyboardType;
  final int? maxLength;
  final TextInputAction? textInputAction;
  final void Function(String)? onChanged;
  final String? Function(String?)? validator;
  final String? labelText;
  final String? hintText;
  final String? counterText;
  final EdgeInsetsGeometry? contentPadding;
  final AutovalidateMode? autovalidateMode;
  final bool obscureText;
  final int? minLines;
  final int? maxLines;
  final Widget? prefixIcon;
  final BoxConstraints? prefixIconConstraints;
  final Widget? suffixIcon;
  final void Function(String)? onFieldSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final FloatingLabelBehavior? floatingLabelBehavior;
  final TextCapitalization textCapitalization;
  final void Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      enabled: enabled,
      style: TextStyle(
        color: context.appTheme.primaryTextColor,
        fontWeight: FontWeight.w400,
      ),
      cursorColor: context.appTheme.borderColor,
      textAlign: TextAlign.start,
      keyboardType: keyboardType,
      minLines: minLines,
      maxLines: maxLines,
      maxLength: maxLength,
      textAlignVertical: TextAlignVertical.center,
      textInputAction: textInputAction,
      inputFormatters: inputFormatters,
      textCapitalization: textCapitalization,
      onChanged: onChanged,
      validator: validator,
      onFieldSubmitted: onFieldSubmitted,
      autovalidateMode: autovalidateMode,
      obscureText: obscureText,
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: TextStyle(
          color: context.appTheme.secondaryTextColor,
          fontWeight: FontWeight.bold,
          fontSize: sSize(10),
        ),
        hintText: hintText,
        counterText: counterText,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: context.appTheme.borderColor),
          borderRadius: BorderRadius.circular(10),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        contentPadding: contentPadding,
        prefix: prefixIcon,
        prefixIconConstraints: prefixIconConstraints,
        suffixIcon: suffixIcon,
        floatingLabelBehavior: floatingLabelBehavior,
      ),
      onTap: onTap,
    );
  }
}

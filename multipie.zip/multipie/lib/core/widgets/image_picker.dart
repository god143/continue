import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:giphy_picker/giphy_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/image_crop.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/custom_bottom_sheet.dart';

Future<File?> pickImage(BuildContext context) async {
  final completer = Completer<File?>();
  await showCustomBottomSheet(
    context: context,
    child: Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 16, top: 8),
              child: Text(
                'Select an image',
                style: Theme.of(context).textTheme.headline6!.merge(TextStyle(
                      color: context.appTheme.secondaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: sSize(16),
                    )),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 16,
        ),
        InkWell(
          onTap: () async {
            Navigator.pop(context);
            final img = await _pickAndCropImage(
              context: context,
              imageSource: ImageSource.gallery,
            );
            completer.complete(img);
          },
          child: Row(
            children: [
              Container(
                  width: 48,
                  height: 48,
                  margin: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16),
                  child: Image.asset('assets/images/carousel/gallery.png')),
              Container(
                child: Text(
                  'Gallery',
                  style: mpHeadLine5(context: context),
                ),
              )
            ],
          ),
        ),
        InkWell(
          onTap: () async {
            Navigator.pop(context);
            final img = await _pickAndCropImage(
              context: context,
              imageSource: ImageSource.camera,
            );
            completer.complete(img);
          },
          child: Row(
            children: [
              Container(
                  width: 48,
                  height: 48,
                  margin: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16),
                  child: Image.asset('assets/images/carousel/camera.png')),
              Container(
                child: Text(
                  'Camera',
                  style: mpHeadLine5(context: context),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  return completer.future;
}

Future<File?> _pickAndCropImage({
  required BuildContext context,
  required ImageSource imageSource,
}) async {
  final pickedImageFile = await ImagePicker().pickImage(source: imageSource);
  File? pickedFile = pickedImageFile != null ? File(pickedImageFile.path) : null;
  if (pickedFile == null) {
    return null;
  }
  return cropImageUtil(pickedFile.path, context: context);
}

Future<String> getGiphy(BuildContext context) async {
  final GiphyGif? gif = await GiphyPicker.pickGif(
    context: context,
    apiKey: Constants.GIPHY_API_KEY,
    fullScreenDialog: true,
    previewType: GiphyPreviewType.previewWebp,
    decorator: GiphyDecorator(
      showAppBar: false,
      searchElevation: 4,
      giphyTheme: ThemeData.dark().copyWith(
        inputDecorationTheme: InputDecorationTheme(
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          contentPadding: EdgeInsets.zero,
        ),
      ),
    ),
  );
  return gif!.images.original!.url!;
}

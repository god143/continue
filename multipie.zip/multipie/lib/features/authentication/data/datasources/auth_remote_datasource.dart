import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/authentication/data/models/login_model.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class AuthRemoteDatasource {
  // will return [UserModel] on success
  //
  // will throw [ServerException] on failure
  Future<UserModel> getCurrentUser();

  Future<MessageResponseModel> getResponseMessageForOTPRequest(String mobile, String channel);

  Future<MessageResponseModel> getResponseMessageForSignUpOTPRequest(
      String mobile, String name, String inviteCode, String channel, bool whatsAppUpdates);

  Future<LoginModel> loginWithOTP(String mobile, String otp, String channel);

  Future<LoginModel> signUpWithOTP(String mobile, String otp);

  // will return nothing on success
  //
  // will throw [ServerException] on failure
  Future<LoginModel> loginWithUsernamePassword(String username, String password);
}

class AuthRemoteDatasourceImpl implements AuthRemoteDatasource {
  // network service
  final NetworkService networkService;

  AuthRemoteDatasourceImpl(this.networkService);

  ///getting current user auth data source
  @override
  Future<UserModel> getCurrentUser() async {
    // making request to server
    final data = await networkService.getRequest('/current_user');

    // flattening json
    final json = Japx.decode(data);

    // parsing to user model
    return UserModel.fromJson(json['data']);
  }

  @override
  Future<LoginModel> loginWithUsernamePassword(
    String username,
    String password,
  ) async {
    // making request to server
    final data = await networkService.postRequest(
      '/sign_in',
      body: {
        'username': username,
        'password': password,
      },
      isAuth: true,
    );

    // flattening json
    final json = Japx.decode(data);

    // parsing map to model
    return LoginModel.fromJson(json['data']);
  }

  @override
  Future<MessageResponseModel> getResponseMessageForOTPRequest(String mobile, String channel) async {
    String urlToSubmit = "/request_login_otp";
    final jsonApi = await networkService.postRequest2(urlToSubmit,
        body: {
          'mobile': mobile,
          'channel': channel,
        },
        isAuth: true);
    try {
      // Map<String, dynamic> json = Japx.decode(jsonApi);
      return MessageResponseModel.fromJson(jsonApi.data);
    } catch (e) {
      print(e.toString());
      throw ServerException(jsonApi.message);
    }
  }

  @override
  Future<MessageResponseModel> getResponseMessageForSignUpOTPRequest(
      String mobile, String name, String inviteCode, String channel, bool whatsAppUpdates) async {
    String urlToSubmit = "/signup_with_mobile";

    final jsonApi = await networkService.postRequest2(urlToSubmit,
        body: {
          'mobile': mobile,
          'display_name': name,
          if (inviteCode.isNotEmpty) 'invite_code': inviteCode,
          'channel': channel,
          'wa_consent': whatsAppUpdates.toString(),
        },
        isAuth: true);
    try {
      //Map<String, dynamic> json = Japx.decode(jsonApi.data);
      return MessageResponseModel.fromJson(jsonApi.data);
    } catch (e) {
      print(e.toString());
      throw ServerException(jsonApi.message);
    }
  }

  @override
  Future<LoginModel> loginWithOTP(String mobile, String otp, String channel) async {
    String urlToSubmit = "/otp_login";
    final jsonApi = await networkService.postRequest2(urlToSubmit,
        body: {
          'mobile': mobile,
          'otp': otp,
          'channel': channel,
        },
        isAuth: true);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi.data);
      return LoginModel.fromJson(json['data']);
    } catch (e) {
      print(e.toString());
      throw ServerException(jsonApi.message);
    }
  }

  @override
  Future<LoginModel> signUpWithOTP(String mobile, String otp) async {
    String urlToSubmit = "/verify_signup_mobile";
    final jsonApi = await networkService.postRequest2(urlToSubmit,
        body: {
          'mobile': mobile,
          'otp': otp,
        },
        isAuth: true);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi.data);
      return LoginModel.fromJson(json['data']);
    } catch (e) {
      print(e.toString());
      throw ServerException(jsonApi.message);
    }
  }
}

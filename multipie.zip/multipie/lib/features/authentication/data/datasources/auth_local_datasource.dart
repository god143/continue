import 'dart:convert';

import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/authentication/data/models/login_model.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

abstract class AuthLocalDatasource {
  Future<void> storeAuthData(LoginModel model);

  Future<LoginModel?> getAuthData();

  Future<void> resetAuthData();

  // will store current user locally
  //
  // will throw [CacheException] on failure
  Future<void> storeCurrentUser(UserModel user);

  // will get current user from local storage
  //
  // will throw [CacheException] on failure
  Future<UserModel> getCurrentUser();
}

class AuthLocalDatasourceImpl implements AuthLocalDatasource {
  // shared preferences
  final SharedPreferences prefs;

  AuthLocalDatasourceImpl(this.prefs);

  @override
  Future<void> storeAuthData(LoginModel model) async {
    try {
      await prefs.setString('auth', json.encode(model));
      return;
    } catch (e) {
      throw CacheException('Cannot store auth data');
    }
  }

  @override
  Future<LoginModel?> getAuthData() async {
    try {
      final auth = prefs.getString('auth');
      if (auth == null) {
        return null;
      } else {
        final data = json.decode(auth);
        return LoginModel.fromJson(data);
      }
    } catch (e) {
      throw CacheException('Cannot retrieve auth data');
    }
  }

  @override
  Future<bool> resetAuthData() async {
    try {
      final removed = await prefs.remove('auth');
      return removed;
    } catch (e) {
      throw CacheException('Cannot reset auth data');
    }
  }

  @override
  Future<UserModel> getCurrentUser() async {
    try {
      final String userString = prefs.getString('current_user') ?? '';

      return UserModel.fromJson(jsonDecode(userString));
    } catch (e) {
      throw CacheException('Could not retrieve user');
    }
  }

  @override
  Future<void> storeCurrentUser(UserModel user) async {
    try {
      final String userString = jsonEncode(user.toJson());

      await prefs.setString('current_user', userString);

      return;
    } catch (e) {
      throw CacheException('Could not save current user');
    }
  }
}

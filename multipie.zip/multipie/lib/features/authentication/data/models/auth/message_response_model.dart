import 'package:multipie/features/authentication/domain/entities/message_entity.dart';

class MessageResponseModel extends Message {
  MessageResponseModel({
    required message,
  }) : super(message: message);

  factory MessageResponseModel.fromJson(Map<String, dynamic> json) {
    return MessageResponseModel(
      message: nullReview(json['message']),
    );
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

class SuccessResponseModel extends Success {
  SuccessResponseModel({
    required message,
  }) : super(success: message);

  factory SuccessResponseModel.fromJson(Map<String, dynamic> json) {
    return SuccessResponseModel(
      message: json['success'],
    );
  }
}

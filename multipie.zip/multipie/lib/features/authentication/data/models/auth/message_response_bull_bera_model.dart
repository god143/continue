import 'package:multipie/features/authentication/domain/entities/message_entity.dart';

class UpdateBullBearResponseModel extends Message {
  UpdateBullBearResponseModel({
    required message,
  }) : super(message: message);

  factory UpdateBullBearResponseModel.fromJson(Map<String, dynamic> json) {
    return UpdateBullBearResponseModel(
      message: nullReview(json['message']),
    );
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

import 'package:multipie/features/authentication/domain/entities/login_entity.dart';

class LoginModel extends LoginEntity {
  LoginModel({
    required id,
    required type,
    required token,
    required refreshToken,
    required expiresAt,
  }) : super(
          id: id,
          type: type,
          token: token,
          refreshToken: refreshToken,
          expiresAt: expiresAt,
        );

  factory LoginModel.fromJson(Map<String, dynamic> json) {
    return LoginModel(
      id: nullReview(json['id']),
      type: nullReview(json['type']),
      token: nullReview(json['token']),
      refreshToken: nullReview(json['refresh_token']),
      expiresAt: nullReview(json['expires_at']),
    );
  }

  Map<String, String> toJson() {
    return {
      'id': id,
      'type': type,
      'token': token,
      'refresh_token': refreshToken,
      'expires_at': expiresAt,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }

  LoginModel copyWith({
    required String token,
    required String refreshToken,
    required String expiresAt,
  }) {
    return LoginModel(
      id: id,
      type: type,
      token: token,
      refreshToken: refreshToken,
      expiresAt: expiresAt,
    );
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/authentication/data/datasources/auth_local_datasource.dart';
import 'package:multipie/features/authentication/data/datasources/auth_remote_datasource.dart';
import 'package:multipie/features/authentication/data/models/login_model.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

class AuthRepositoryImpl implements AuthRepository {
  // remote datasource for authentication
  final AuthRemoteDatasource remoteDatasource;

  // local datasource for authentication
  final AuthLocalDatasource localDatasource;

  // getting network info
  final NetworkInfo networkInfo;

  AuthRepositoryImpl({
    required this.remoteDatasource,
    required this.localDatasource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, UserModel>> getCurrentUser() async {
    //Check if connected to network
    if (await networkInfo.isConnected) {
      try {
        //get current user
        final UserModel user = await remoteDatasource.getCurrentUser();

        //storing user in local storage
        await localDatasource.storeCurrentUser(user);

        return Right(user);
      } on ServerException catch (e) {
        //return server failure
        return Left(ServerFailure(e.message));
      } on CacheException catch (e) {
        return Left(CacheFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, UserModel>> getCurrentUserFromLocalStorage() async {
    try {
      //getting user from local storage
      final UserModel user = await localDatasource.getCurrentUser();

      return Right(user);
    } on CacheException catch (e) {
      return Left(CacheFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, void>> loginWithUsernamePassword(String username, String password) async {
    //Check if is connected to internet

    if (await networkInfo.isConnected) {
      try {
        //logging user in
        LoginModel data = await remoteDatasource.loginWithUsernamePassword(username, password);

        //storing token in local storage
        await localDatasource.storeAuthData(data);

        return Right(null);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      } on CacheException catch (e) {
        return Left(CacheFailure(e.message));
      }
      // return Right();
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, Message>> requestOTPForLogin(String mobile, String channel) async {
    return await _getResponseMessage(mobile, channel);
  }

  Future<Either<Failure, Message>> _getResponseMessage(mobile, channel) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDatasource.getResponseMessageForOTPRequest(mobile, channel);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, LoginEntity>> loginWithOTP(String mobile, String otp, String channel) async {
    return await _loginWithOTP(mobile, otp, channel);
  }

  Future<Either<Failure, LoginEntity>> _loginWithOTP(mobile, otp, channel) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDatasource.loginWithOTP(mobile, otp, channel);

        //storing token in local storage
        await localDatasource.storeAuthData(remoteCL);

        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, Message>> requestOTPForSignUp(
      String mobile, String name, String inviteCode, String channel, bool whatsAppUpdates) async {
    return await _getSignUpResponseMessage(mobile, name, inviteCode, channel, whatsAppUpdates);
  }

  Future<Either<Failure, Message>> _getSignUpResponseMessage(mobile, name, inviteCode, channel, whatsAppUpdates) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDatasource.getResponseMessageForSignUpOTPRequest(
            mobile, name, inviteCode, channel, whatsAppUpdates);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, LoginModel>> signUpWithOTP(String mobile, String otp) async {
    return await _signUpWithOTP(mobile, otp);
  }

  Future<Either<Failure, LoginModel>> _signUpWithOTP(mobile, otp) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDatasource.signUpWithOTP(mobile, otp);

        //storing token in local storage
        await localDatasource.storeAuthData(remoteCL);

        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/responsive/responsive.dart';

import 'login_mobile_portrait.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ScreenTypeLayout(
      // mobile UI
      mobile: OrientationLayout(
        // when device orientation is portrait
        portrait: LoginMobilePortrait(),
      ),
    );
  }
}

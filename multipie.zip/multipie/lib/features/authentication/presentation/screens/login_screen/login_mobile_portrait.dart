import 'package:flutter/material.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper.dart';
import 'package:multipie/core/ui_helper_new.dart' as newUI;
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/primart_text_form_field.dart';
import 'package:multipie/features/authentication/presentation/providers/auth_provider.dart';
import 'package:multipie/features/user_onboarding/signup/signup_mobile_portrait.dart';
import 'package:multipie/services/navigation_service.dart';
import 'package:provider/provider.dart';

class LoginMobilePortrait extends StatefulWidget {
  // controllers for text field
  @override
  _LoginMobilePortraitState createState() => _LoginMobilePortraitState();
}

class _LoginMobilePortraitState extends State<LoginMobilePortrait> {
  final TextEditingController _usernameController = TextEditingController();

  final TextEditingController _passwordController = TextEditingController();
  var _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  bool obsecureText = true;
  int selectedOption = 0;
  String selectedCountry = countryCodes[0];

  @override
  void initState() {
    super.initState();
    Provider.of<AuthProvider>(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      appBar: MultipieAppBar(
        title: '',
        elevation: 0,
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: Consumer<AuthProvider>(
          builder: (context, provider, child) {
            if (provider == null) return Container();

            if (provider.state == AuthState.Error) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _scaffoldKey.currentState?.showSnackBar(SnackBar(
                  content: Text(
                    provider != null && provider.errorMessage != null ? provider.errorMessage : '',
                    style: TextStyle(
                      color: context.appTheme.lightTextColor,
                    ),
                  ),
                ));
                provider.state = AuthState
                    .UnAuthenticated; //Adding this because when opening this screen again then snackbar showing automatically
              });
            }

            return Padding(
              padding: EdgeInsets.only(
                left: sWidth(20),
                right: sWidth(20),
                bottom: sWidth(10),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 25),
                              child: Text(
                                'Login with Password',
                                style: TextStyle(
                                  color: context.appTheme.primaryTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: sSize(11),
                                ),
                              ),
                            ),
                            Row(children: [
                              Expanded(child: loginTypeOption('Username/Email', 0)),
                              SizedBox(width: 10),
                              Expanded(child: loginTypeOption('Mobile No.', 1)),
                            ]),
                            SizedBox(height: 15),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                selectedOption == 0 ? 'Enter your username/email' : 'Enter your mobile number',
                                style: TextStyle(
                                  color: context.appTheme.scorpionGray,
                                  fontWeight: FontWeight.w400,
                                  fontSize: sSize(7),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: sWidth(7.5),
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (selectedOption == 1) ...[
                                  Container(
                                    height: 48,
                                    padding: const EdgeInsets.symmetric(horizontal: 10),
                                    child: DropdownButton(
                                      dropdownColor: context.appTheme.cardBackgroundColor,
                                      alignment: Alignment.center,
                                      underline: Container(),
                                      style: newUI.mpHeadLine6(context: context),
                                      value: selectedCountry,
                                      items: countryCodes.map((e) {
                                        return DropdownMenuItem(
                                          child: Text(
                                            e,
                                            style: newUI.mpHeadLine6(context: context),
                                          ),
                                          value: e,
                                        );
                                      }).toList(),
                                      onChanged: (newVal) {
                                        setState(() {
                                          selectedCountry = newVal.toString();
                                        });
                                      },
                                    ),
                                    decoration: BoxDecoration(
                                        border: Border.all(color: context.appTheme.scorpionGray, width: 0.7),
                                        borderRadius: BorderRadius.all(Radius.circular(10))),
                                  ),
                                  SizedBox(width: 10),
                                ],
                                Expanded(
                                  child: PrimaryTextFormField(
                                    controller: _usernameController,
                                    textInputAction: TextInputAction.go,
                                    autovalidateMode: AutovalidateMode.onUserInteraction,
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return selectedOption == 0
                                            ? 'Please enter a valid username'
                                            : 'Please enter a valid mobile no.';
                                      }
                                      return null;
                                    },
                                    labelText: selectedOption == 0 ? 'Username/ Email' : 'Mobile Number',
                                    counterText: "",
                                    contentPadding: EdgeInsets.only(
                                      bottom: sHeight(25) / 2,
                                      left: sWidth(5),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: sWidth(12.5),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Enter your password',
                                style: TextStyle(
                                  color: context.appTheme.scorpionGray,
                                  fontWeight: FontWeight.w400,
                                  fontSize: sSize(7),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: sWidth(7.5),
                            ),
                            PrimaryTextFormField(
                              controller: _passwordController,
                              textInputAction: TextInputAction.go,
                              autovalidateMode: AutovalidateMode.onUserInteraction,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter valid password';
                                }
                                return null;
                              },
                              obscureText: obsecureText,
                              labelText: 'Password',
                              counterText: "",
                              contentPadding: EdgeInsets.only(
                                bottom: sHeight(25) / 2,
                                left: sWidth(5),
                              ),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  obsecureText ? Icons.visibility_off : Icons.visibility,
                                  color: context.appTheme.borderColor,
                                ),
                                onPressed: () {
                                  setState(
                                    () {
                                      obsecureText = !obsecureText;
                                    },
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: sHeight(8),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: () {
                          Navigate.pushReplacement(
                            context,
                            SignupMobilePortrait(
                              isLogin: true,
                            ),
                          );
                        },
                        style: TextButton.styleFrom(
                          side: BorderSide(color: Theme.of(context).primaryColor, width: 1),
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5)),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: Text(
                            'Login with OTP',
                            style: TextStyle(
                              color: Theme.of(context).primaryColor,
                            ),
                          ),
                        ),
                      ),
                      TextButton(
                        style: TextButton.styleFrom(
                          primary: Theme.of(context).primaryColor,
                          backgroundColor: Theme.of(context).primaryColor,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5)),
                          ),
                        ),
                        onPressed: () async {
                          if (_formKey.currentState?.validate() == true) {
                            Provider.of<AuthProvider>(context, listen: false).loginUser(
                              context,
                              selectedOption == 0
                                  ? _usernameController.text
                                  : selectedCountry.replaceAll('+', '') + ' ' + _usernameController.text,
                              _passwordController.text,
                            );
                          }
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 25),
                          child: Text(
                            'Login',
                            style: TextStyle(
                              color: context.appTheme.kPrimaryButtonTextColor,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  loginTypeOption(String text, int value) {
    return InkWell(
      onTap: () {
        setOption(value);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          border: Border.all(
              color: selectedOption == value ? Theme.of(context).primaryColor : context.appTheme.secondaryTextColor,
              width: 1.7),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: selectedOption == value
              ? Theme.of(context).primaryColor.withAlpha(15)
              : context.appTheme.transparentColor,
        ),
        child: Row(children: [
          SizedBox(
            height: 35,
            width: 35,
            child: Radio<int>(
              value: value,
              activeColor: Theme.of(context).primaryColor,
              groupValue: selectedOption,
              onChanged: (v) {
                setOption(v);
              },
            ),
          ),
          Flexible(
              child: Text(
            text,
            style: newUI.mpHeadLine6(
              context: context,
              textColor: selectedOption == value ? Theme.of(context).primaryColor : context.appTheme.scorpionGray,
            ),
          )),
          SizedBox(
            width: 5,
          )
        ]),
      ),
    );
  }

  setOption(value) {
    setState(() {
      selectedOption = value;
    });
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';

@immutable
abstract class OTPSignUpState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends OTPSignUpState {}

class Loading extends OTPSignUpState {}

class Loaded extends OTPSignUpState {
  final LoginEntity data;
  Loaded({required this.data});

  @override
  List<Object> get props => [data];
}

class Error extends OTPSignUpState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class OTPSignUpEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class SignUpWithOTP extends OTPSignUpEvent {
  final String mobile;
  final String otp;

  SignUpWithOTP(this.mobile,this.otp);

  @override
  List<Object> get props => [mobile,otp];
}

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'dart:async';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';
import 'package:multipie/features/authentication/domain/usecases/signup_with_otp_usecase.dart';
import 'bloc.dart';

class OTPSignUpBloc extends Bloc<OTPSignUpEvent, OTPSignUpState> {
  final SignUpWithOTPUseCase otpSignUp;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  OTPSignUpState get initialState => Empty();

  OTPSignUpBloc({required SignUpWithOTPUseCase otpSignUp})
      : assert(otpSignUp != null),
        this.otpSignUp = otpSignUp,
        super(Empty());

  @override
  Stream<OTPSignUpState> mapEventToState(
    OTPSignUpEvent event,
  ) async* {
    if (event is SignUpWithOTP) {
      yield Loading();
      final failureOrSignUpOTP =
          await otpSignUp(Params(mobile: event.mobile, otp: event.otp));
      yield* _eitherLoadedOrErrorState(failureOrSignUpOTP);
    }
  }

  Stream<OTPSignUpState> _eitherLoadedOrErrorState(
    Either<Failure, LoginEntity> failureOrSignUp,
  ) async* {
    yield failureOrSignUp.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        return Loaded(data: data);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return (failure as ServerFailure).message;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

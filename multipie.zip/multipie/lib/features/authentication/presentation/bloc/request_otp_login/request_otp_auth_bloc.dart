import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/authentication/domain/usecases/request_login_otp.dart';

import 'bloc.dart';

class RequestOTPBloc extends Bloc<RequestOTPEvent, RequestOTPState> {
  final RequestLoginOTP requestOTP;
  final ReRequestLoginOTP reRequestOTP;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  RequestOTPState get initialState => Empty();

  RequestOTPBloc(
      {required RequestLoginOTP requestOTP, required ReRequestLoginOTP reRequestOTP})
      : assert(requestOTP != null),
        this.requestOTP = requestOTP,
        this.reRequestOTP = reRequestOTP,
        super(Empty());

  @override
  Stream<RequestOTPState> mapEventToState(
    RequestOTPEvent event,
  ) async* {
    if (event is RequestOTPForAuth) {
      yield Loading();
      final failureOrAuthMessage = await requestOTP(
          Params(mobile: event.mobile, channel: event.channel));
      yield* _eitherLoadedOrErrorState(failureOrAuthMessage);
    } else if (event is ReRequestOTPForAuth) {
      yield Loading();
      final failureOrAuthMessage = await requestOTP(
          Params(mobile: event.mobile, channel: event.channel));
      yield* _eitherReLoadedOrErrorState(failureOrAuthMessage);
    }
  }

  Stream<RequestOTPState> _eitherReLoadedOrErrorState(
    Either<Failure, Message> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        return Reloaded(message: data);
      },
    );
  }

  Stream<RequestOTPState> _eitherLoadedOrErrorState(
    Either<Failure, Message> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        return Loaded(message: data);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return (failure as ServerFailure).message;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class RequestOTPEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class RequestOTPForAuth extends RequestOTPEvent {
  final String mobile;
  final String channel;

  RequestOTPForAuth(this.mobile,this.channel);

  @override
  List<Object> get props => [mobile,channel];
}

class ReRequestOTPForAuth extends RequestOTPEvent {
  final String mobile;
  final String channel;

  ReRequestOTPForAuth(this.mobile,this.channel);

  @override
  List<Object> get props => [mobile,channel];
}
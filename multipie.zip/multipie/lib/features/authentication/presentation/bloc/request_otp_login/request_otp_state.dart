import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';

@immutable
abstract class RequestOTPState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends RequestOTPState {}

class Loading extends RequestOTPState {}

class Loaded extends RequestOTPState {
  final Message message;
  Loaded({required this.message});

  @override
  List<Object> get props => [message];
}

class Reloaded extends RequestOTPState {
  final Message message;
  Reloaded({required this.message});

  @override
  List<Object> get props => [message];
}

class Error extends RequestOTPState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

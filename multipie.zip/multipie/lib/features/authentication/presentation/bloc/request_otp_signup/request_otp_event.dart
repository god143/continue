import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class RequestOTPEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class RequestOTPForSignUp extends RequestOTPEvent {
  final String mobile;
  final String name;
  final String inviteCode;
  final String channel;
  final bool whatsAppUpdates;

  RequestOTPForSignUp({
    required this.mobile,
    required this.name,
    required this.inviteCode,
    required this.channel,
    required this.whatsAppUpdates,
  });

  @override
  List<Object> get props => [
        mobile,
        name,
        inviteCode,
        channel,
        whatsAppUpdates,
      ];
}

class ReRequestOTPForSignUp extends RequestOTPEvent {
  final String mobile;
  final String name;
  final String inviteCode;
  final String channel;
  final bool whatsAppUpdates;

  ReRequestOTPForSignUp({
    required this.mobile,
    required this.name,
    required this.inviteCode,
    required this.channel,
    required this.whatsAppUpdates,
  });

  @override
  List<Object> get props => [
        mobile,
        name,
        inviteCode,
        channel,
        whatsAppUpdates,
      ];
}

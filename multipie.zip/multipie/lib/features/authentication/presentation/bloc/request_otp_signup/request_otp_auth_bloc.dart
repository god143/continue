import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/authentication/domain/usecases/request_signup_otp.dart';

import 'bloc.dart';

class RequestSignUpOTPBloc extends Bloc<RequestOTPEvent, RequestOTPState> {
  final RequestSignUpOTP requestOTP;
  final ReRequestSignUpOTP reRequestOTP;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  RequestOTPState get initialState => Empty();

  RequestSignUpOTPBloc({required RequestSignUpOTP requestOTP, required ReRequestSignUpOTP reRequestSignUpOTP})
      : assert(requestOTP != null && reRequestSignUpOTP != null),
        this.requestOTP = requestOTP,
        this.reRequestOTP = reRequestSignUpOTP,
        super(Empty());

  @override
  Stream<RequestOTPState> mapEventToState(
    RequestOTPEvent event,
  ) async* {
    if (event is RequestOTPForSignUp) {
      yield Loading();
      final failureOrAuthMessage = await requestOTP(Params(
        mobile: event.mobile,
        name: event.name,
        inviteCode: event.inviteCode,
        channel: event.channel,
        whatsAppUpdates: event.whatsAppUpdates,
      ));
      yield* _eitherLoadedOrErrorState(failureOrAuthMessage);
    } else if (event is ReRequestOTPForSignUp) {
      yield Loading();
      final failureOrAuthMessage = await reRequestOTP(Params(
        mobile: event.mobile,
        name: event.name,
        inviteCode: event.inviteCode,
        channel: event.channel,
        whatsAppUpdates: event.whatsAppUpdates,
      ));
      yield* _eitherReloadedOrErrorState(failureOrAuthMessage);
    }
  }

  Stream<RequestOTPState> _eitherLoadedOrErrorState(
    Either<Failure, Message> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        return Loaded(message: data);
      },
    );
  }

  Stream<RequestOTPState> _eitherReloadedOrErrorState(
    Either<Failure, Message> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        return Reloaded(message: data);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return (failure as ServerFailure).message;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

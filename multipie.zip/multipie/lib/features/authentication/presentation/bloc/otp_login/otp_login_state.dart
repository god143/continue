import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';

@immutable
abstract class OTPRequestState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends OTPRequestState {}

class Loading extends OTPRequestState {}

class Loaded extends OTPRequestState {
  final LoginEntity loginEntity;
  Loaded({required this.loginEntity});

  @override
  List<Object> get props => [loginEntity];
}

class Error extends OTPRequestState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

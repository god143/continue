import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class OTPLoginEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class LoginWithOTP extends OTPLoginEvent {
  final String mobile;
  final String otp;
  final String channel;

  LoginWithOTP({
    required this.mobile,
    required this.otp,
    required this.channel,
  });

  @override
  List<Object> get props => [mobile, otp, channel];
}

import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';
import 'package:multipie/features/authentication/domain/usecases/login_with_otp_usecase.dart';

import 'bloc.dart';

class OTPLoginBloc extends Bloc<OTPLoginEvent, OTPRequestState> {
  final LoginWithOTPUseCase otpLogin;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  OTPRequestState get initialState => Empty();

  OTPLoginBloc({required LoginWithOTPUseCase otpLogin})
      : assert(otpLogin != null),
        this.otpLogin = otpLogin,
        super(Empty());

  @override
  Stream<OTPRequestState> mapEventToState(
    OTPLoginEvent event,
  ) async* {
    if (event is LoginWithOTP) {
      yield Loading();
      final failureOrLoginOTP = await otpLogin(Params(mobile: event.mobile, otp: event.otp, channel: event.channel));
      yield* _eitherLoadedOrErrorState(failureOrLoginOTP);
    }
  }

  Stream<OTPRequestState> _eitherLoadedOrErrorState(
    Either<Failure, LoginEntity> failureOrLogin,
  ) async* {
    yield failureOrLogin.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        return Loaded(loginEntity: data);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return (failure as ServerFailure).message;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

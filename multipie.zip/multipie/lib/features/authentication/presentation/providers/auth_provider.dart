import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/usecases/get_current_user_usecase.dart';
import 'package:multipie/features/authentication/domain/usecases/login_with_username_password_usecase.dart';
import 'package:multipie/features/config/data/repositories/fetch_config_iml.dart';
import 'package:multipie/features/config/domain/repositories/fetch_config.dart';
import 'package:multipie/locator.dart';
import 'package:multipie/screens/nav_screen/nav_mobile_portrait.dart';
import 'package:multipie/services/navigation_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AuthState { UnAuthenticated, Loading, Loaded, Error }

class AuthProvider with ChangeNotifier {
  FetchConfig fetchConfig = FetchConfigIml();
  final log = Logger("AuthProvider");
  final LoginWithUsernamePasswordUsecase loginWithUsernamePasswordUsecase;
  final GetCurrentUserUsecase getCurrentUserUsecase;

  AuthProvider({
    required this.loginWithUsernamePasswordUsecase,
    required this.getCurrentUserUsecase,
  });

  // for loading purpose
  AuthState state = AuthState.UnAuthenticated;

  String _errorMessage = '';

  // getters
  String get errorMessage => _errorMessage;

  void fetchConfigData() {
    fetchConfig.getConfigData().then((value) {
      notifyListeners();
    });
  }

  void initialiseState() {
    state = AuthState.UnAuthenticated;
    notifyListeners();
  }

  void loginUser(
    BuildContext context,
    String username,
    String password,
  ) async {
    state = AuthState.Loading;
    _errorMessage = '';
    notifyListeners();

    try {
      final response = await loginWithUsernamePasswordUsecase.call(
        Params(username: username, password: password),
      );

      response.fold(
        (l) {
          _handleFailure(l);
        },
        (r) async {
          _errorMessage = '';

          final responseTwo = await getCurrentUserUsecase.call(NoParams());

          responseTwo.fold(
            (l) {
              _handleFailure(l);
            },
            (r) {
              _errorMessage = '';
              int popupTime =
                  DateTime.now().add(Duration(days: Constants.showEmailVerificationPopup)).millisecondsSinceEpoch;
              SharedPreferences prefs = locator();
              prefs.setInt(Constants.userNameSelectionTimeKey, popupTime);
              Navigate.pushReplacement(context, NavMobilePortrait());
            },
          );
        },
      );
      state = AuthState.Loaded;
    } on AuthException catch (e) {
      _errorMessage = e.message;
      state = AuthState.Error;
    }
    notifyListeners();
  }

  void _handleFailure(Failure l) {
    if (l is InternetFailure) {
      _errorMessage = 'Not connected to internet';
      log.severe(_errorMessage);
    } else if (l is ServerFailure) {
      _errorMessage = 'Server Failure: ${l.message}';
      log.severe(_errorMessage);
    } else if (l is CacheFailure) {
      _errorMessage = 'Cache Failure: ${l.message}';
      log.severe(_errorMessage);
    }
  }
}

import 'package:equatable/equatable.dart';

class Message extends Equatable {
  final String message;

  Message({required this.message});

  @override
  List<Object> get props => [message];
}

class Success extends Equatable {
  final bool success;

  Success({required this.success});

  @override
  List<Object> get props => [success];
}

import 'package:equatable/equatable.dart';

class LoginEntity extends Equatable {
  final String id;
  final String type;
  final String token;
  final String refreshToken;
  final String expiresAt;

  LoginEntity({
    required this.id,
    required this.type,
    required this.token,
    required this.refreshToken,
    required this.expiresAt,
  });

  @override
  List<Object> get props => [
        id,
        type,
        token,
        refreshToken,
        expiresAt,
      ];
}

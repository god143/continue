import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

abstract class AuthRepository {
  // get current user
  Future<Either<Failure, User>> getCurrentUser();

  // login user using username and password
  Future<Either<Failure, void>> loginWithUsernamePassword(
    String username,
    String password,
  );

  // get current user
  Future<Either<Failure, User>> getCurrentUserFromLocalStorage();

  Future<Either<Failure, Message>> requestOTPForLogin(String mobile, String channel);

  Future<Either<Failure, Message>> requestOTPForSignUp(
      String mobile, String name, String inviteCode, String channel, bool whatsAppUpdates);

  Future<Either<Failure, LoginEntity>> loginWithOTP(String mobile, String password, String channel);

  Future<Either<Failure, LoginEntity>> signUpWithOTP(String mobile, String otp);
}

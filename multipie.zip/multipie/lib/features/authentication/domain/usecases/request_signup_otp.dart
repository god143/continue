import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';

class RequestSignUpOTP implements UseCase<void, Params> {
  final AuthRepository authRepository;

  RequestSignUpOTP(this.authRepository);

  @override
  Future<Either<Failure, Message>> call(Params params) async {
    return await authRepository.requestOTPForSignUp(
      params.mobile,
      params.name,
      params.inviteCode,
      params.channel,
      params.whatsAppUpdates,
    );
  }
}

class ReRequestSignUpOTP extends RequestSignUpOTP {
  final AuthRepository authRepository;

  ReRequestSignUpOTP(this.authRepository) : super(authRepository);
}

class Params extends Equatable {
  final String mobile;
  final String name;
  final String inviteCode;
  final String channel;
  final bool whatsAppUpdates;

  Params({
    required this.mobile,
    required this.name,
    required this.inviteCode,
    required this.channel,
    required this.whatsAppUpdates,
  });

  @override
  List<Object> get props => [
        mobile,
        name,
        inviteCode,
        channel,
        whatsAppUpdates,
      ];
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';

class LoginWithOTPUseCase implements UseCase<void, Params> {
  final AuthRepository authRepository;

  LoginWithOTPUseCase(this.authRepository);

  @override
  Future<Either<Failure, LoginEntity>> call(Params params) async {
    return await authRepository.loginWithOTP(
      params.mobile,
      params.otp,
      params.channel,
    );
  }
}

class Params extends Equatable {
  final String mobile;
  final String otp;
  final String channel;

  Params({
    required this.mobile,
    required this.otp,
    required this.channel,
  });

  @override
  List<Object> get props => [mobile, otp, channel];
}

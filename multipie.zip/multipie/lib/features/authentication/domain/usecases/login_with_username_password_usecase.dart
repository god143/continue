import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';

class LoginWithUsernamePasswordUsecase implements UseCase<void, Params> {
  // auth repository
  final AuthRepository authRepository;

  LoginWithUsernamePasswordUsecase(this.authRepository);

  @override
  Future<Either<Failure, void>> call(Params params) async {
    return await authRepository.loginWithUsernamePassword(
      params.username,
      params.password,
    );
  }
}

class Params extends Equatable {
  // username
  final String username;
  // password
  final String password;

  Params({
    required this.username,
    required this.password,
  });

  @override
  List<Object> get props => [username, password];
}

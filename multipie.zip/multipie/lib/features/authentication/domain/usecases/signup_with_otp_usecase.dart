import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/entities/login_entity.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';

class SignUpWithOTPUseCase implements UseCase<void, Params> {
  final AuthRepository authRepository;

  SignUpWithOTPUseCase(this.authRepository);

  @override
  Future<Either<Failure, LoginEntity>> call(Params params) async {
    return await authRepository.signUpWithOTP(params.mobile, params.otp);
  }
}

class Params extends Equatable {
  final String mobile;
  final String otp;

  Params({
    required this.mobile,
    required this.otp,
  });

  @override
  List<Object> get props => [mobile, otp];
}

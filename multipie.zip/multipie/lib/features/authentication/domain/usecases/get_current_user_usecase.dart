import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';
///todo remove duplicate
class GetCurrentUserUsecase implements UseCase<User, NoParams> {
  // auth repository
  final AuthRepository authRepository;

  GetCurrentUserUsecase(this.authRepository);

  @override
  Future<Either<Failure, User>> call(NoParams noParams) async {
    return await authRepository.getCurrentUser();
  }
}

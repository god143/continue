import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/authentication/domain/repositories/auth_repository.dart';

class RequestLoginOTP implements UseCase<void, Params> {
  final AuthRepository authRepository;

  RequestLoginOTP(this.authRepository);

  @override
  Future<Either<Failure, Message>> call(Params params) async {
    return await authRepository.requestOTPForLogin(
      params.mobile,
      params.channel,
    );
  }
}

class ReRequestLoginOTP implements UseCase<void, Params> {
  final AuthRepository authRepository;

  ReRequestLoginOTP(this.authRepository);

  @override
  Future<Either<Failure, void>> call(Params params) async {
    return await authRepository.requestOTPForLogin(
      params.mobile,
      params.channel,
    );
  }
}

class Params extends Equatable {
  final String mobile;
  final String channel;

  Params({
    required this.mobile,
    required this.channel,
  });

  @override
  List<Object> get props => [mobile, channel];
}

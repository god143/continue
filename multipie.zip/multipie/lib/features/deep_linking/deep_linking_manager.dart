import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:multipie/features/explore/presentation/widgets/mutual_fund_screen.dart';
import 'package:multipie/features/post/presentation/screens/post_detail_screen/post_detail_screen.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/new_profile_screen.dart';
import 'package:multipie/screens/company_screen/company_info_mobile_portrait.dart';
import 'package:multipie/services/navigation_service.dart';
import 'package:url_launcher/url_launcher.dart';

class DeepLinkingManager {
  static const String _hostName = 'multipie.co';

  /// Returns bool indicating if the deeplink uri got handled or not
  Future<bool> handleDeeplink({
    required Uri uri,
    required BuildContext context,
  }) async {
    try {
      if (!uri.host.contains(_hostName)) {
        return false;
      }
      if (uri.path.contains('/u/')) {
        final profileId = uri.toString().split('/u/')[1].split('/')[0];
        Navigate.push(
          context,
          NewProfileScreen(profileId: profileId),
        );
        return true;
      } else if (uri.path.contains('/posts/')) {
        final postId = uri.toString().split('/posts/')[1].split('/')[0];
        Navigate.push(
          context,
          PostDetailScreen(postId: postId, key: Key(postId)),
        );
        return true;
      } else if (uri.path.contains('/companies/')) {
        final companyId = uri.toString().split('/companies/')[1].split('/')[0];
        Navigate.push(
          context,
          CompanyInfoMobilePortrait(companyId: companyId),
        );
        return true;
      } else if (uri.path.contains('/mutual_funds/')) {
        final mutualfundId = uri.toString().split('/mutual_funds/')[1].split('/')[0];
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => MutualFundScreen(
                    mutualFundId: mutualfundId,
                    mutualFundName: 'Mutual Fund',
                  )),
        );
        return true;
      } else {
        launch(
          uri.toString(),
          forceSafariVC: true,
          forceWebView: true,
        );
        return false;
      }
    } on PlatformException {
      return false;
    } on FormatException catch (_) {
      return false;
    }
  }

  static bool isSupportedURL(Uri url) {
    if (url.host.contains(_hostName) &&
        (url.path.contains('/u/') ||
            url.path.contains('/posts/') ||
            url.path.contains('/companies/') ||
            url.path.contains('/mutual_funds/'))) {
      return true;
    }
    return false;
  }
}

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_item_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/chart_legend_model.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/chart_container.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/chart_legends_widget.dart';

class MPBarChart extends StatelessWidget {
  MPBarChart({
    Key? key,
    required this.title,
    required this.data,
    this.barGroupingType,
    this.chartHeight = 200,
  }) : super(key: key);

  final String title;
  final List<BarChartModel> data;
  final charts.BarGroupingType? barGroupingType;
  final double chartHeight;

  @override
  Widget build(BuildContext context) {
    final legends = data
        .map(
          (e) => ChartLegendModel(
            name: e.chartId,
            color: e.barColor,
          ),
        )
        .toList(growable: false);
    return ChartContainer(
      title: title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              left: 8,
              bottom: 8,
            ),
            child: SizedBox(
              height: chartHeight,
              child: charts.BarChart(
                data
                    .map(
                      (e) => charts.Series<BarChartItemModel, String>(
                        id: e.chartId,
                        data: e.data,
                        domainFn: (model, _) => model.xTitle,
                        measureFn: (model, _) => model.yValue,
                        fillColorFn: (_, __) => charts.ColorUtil.fromDartColor(e.barColor),
                        labelAccessorFn: (model, _) => model.yTitle,
                      ),
                    )
                    .toList(growable: false),
                domainAxis: charts.OrdinalAxisSpec(
                  renderSpec: charts.SmallTickRendererSpec(
                    labelStyle: charts.TextStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.primaryTextColor),
                    ),
                    lineStyle: charts.LineStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.borderColor),
                    ),
                  ),
                ),
                primaryMeasureAxis: charts.NumericAxisSpec(
                  renderSpec: charts.GridlineRendererSpec(
                    labelStyle: charts.TextStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.primaryTextColor),
                    ),
                  ),
                ),
                defaultRenderer: charts.BarRendererConfig<String>(
                  barGroupInnerPaddingPx: 16,
                  cornerStrategy: const charts.ConstCornerStrategy(4),
                  maxBarWidthPx: 8,
                  barRendererDecorator: charts.BarLabelDecorator(
                    labelPosition: charts.BarLabelPosition.outside,
                    outsideLabelStyleSpec: charts.TextStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.primaryTextColor),
                      fontSize: 9,
                    ),
                    unboundedWidth: true,
                  ),
                  groupingType: barGroupingType,
                ),
              ),
            ),
          ),
          if (legends.length > 1) ChartLegendsWidget(legends: legends),
        ],
      ),
    );
  }
}

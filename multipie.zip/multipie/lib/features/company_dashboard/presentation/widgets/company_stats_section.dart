import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/features/market/domain/entities/company/company_stats.dart';
import 'package:multipie/core/utils/extensions.dart';

class CompanyStatsSection extends StatelessWidget {
  const CompanyStatsSection({
    Key? key,
    this.companyStats,
  }) : super(key: key);

  final CompanyStats? companyStats;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.appTheme.cardBackgroundColor,
        border: Border.all(
          width: 0.5,
          color: Theme.of(context).primaryColor.withOpacity(0.5),
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _Header(
              title: 'VALUATION',
              padding: const EdgeInsets.only(bottom: 12),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                _Item(
                  title: 'MCAP (Rs. cr)',
                  value: companyStats?.marketCap ?? '-',
                  textAlign: TextAlign.left,
                  weight: 3,
                ),
                _Item(
                  title: 'EV (Rs. cr)',
                  value: companyStats?.enterpriseValue ?? '-',
                  textAlign: TextAlign.center,
                  weight: 3,
                ),
                _Item(
                  title: 'P/E',
                  value: companyStats?.stockPE ?? '-',
                  textAlign: TextAlign.center,
                  weight: 2,
                ),
                _Item(
                  title: 'P/B',
                  value: companyStats?.pBook ?? '-',
                  textAlign: TextAlign.right,
                  weight: 2,
                ),
              ],
            ),
            SizedBox(height: 8),
            _Header(
              title: 'KEY STATS',
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                _Item(
                  title: 'ROE',
                  value: companyStats?.roe != null ? '${companyStats!.roe}%' : '-',
                  textAlign: TextAlign.left,
                  weight: 2,
                ),
                _Item(
                  title: 'ROCE',
                  value: companyStats?.roce != null ? '${companyStats!.roce}%' : '-',
                  textAlign: TextAlign.center,
                  weight: 2,
                ),
                _Item(
                  title: 'MCAP/OP CF',
                  value: companyStats?.marketCapToCashflow ?? '-',
                  textAlign: TextAlign.center,
                  weight: 3,
                ),
                _Item(
                  title: 'DIV YIELD',
                  value: companyStats?.dividendYield != null ? '${companyStats!.dividendYield}%' : '-',
                  textAlign: TextAlign.right,
                  weight: 2,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    Key? key,
    required this.title,
    required this.padding,
  }) : super(key: key);

  final String title;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: Text(
        title,
        style: TextStyle(
          color: Theme.of(context).primaryColor,
          fontWeight: FontWeight.w700,
          fontSize: 12,
          letterSpacing: 1.11,
        ),
      ),
    );
  }
}

class _Item extends StatelessWidget {
  const _Item({
    Key? key,
    required this.title,
    required this.value,
    required this.textAlign,
    this.weight = 1,
  }) : super(key: key);

  final String title;
  final String value;
  final TextAlign textAlign;
  final int weight;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: weight,
      child: Padding(
        padding: EdgeInsets.only(
          left: textAlign == TextAlign.left ? 0 : 4,
          right: textAlign == TextAlign.right ? 0 : 4,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              textAlign: textAlign,
              style: TextStyle(
                fontSize: 12,
                height: 14 / 12,
                color: context.appTheme.scorpionGray,
              ),
            ),
            SizedBox(height: 8),
            Text(
              value,
              textAlign: textAlign,
              style: TextStyle(
                fontSize: 16,
                height: 18.75 / 16,
                color: context.appTheme.primaryTextColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

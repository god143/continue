import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/features/company_dashboard/presentation/models/chart_legend_model.dart';

class ChartLegendsWidget extends StatelessWidget {
  const ChartLegendsWidget({
    Key? key,
    required this.legends,
  }) : super(key: key);

  final List<ChartLegendModel>? legends;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 8,
      ),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 16,
        runSpacing: 12,
        children: legends!
            .map(
              (e) => Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                      color: e.color,
                      width: 8,
                      height: 8,
                    ),
                  ),
                  SizedBox(width: 6),
                  Text(
                    e.name,
                    style: mpHeadLine6(
                      context: context,
                    ),
                  ),
                ],
              ),
            )
            .toList(growable: false),
      ),
    );
  }
}

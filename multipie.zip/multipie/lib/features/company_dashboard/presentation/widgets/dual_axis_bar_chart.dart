import 'dart:math' as math;

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/company_dashboard/presentation/models/chart_legend_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/dual_axis_bar_chart_item_model.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/chart_container.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/chart_legends_widget.dart';

class MPDualAxisBarChart extends StatelessWidget {
  const MPDualAxisBarChart({
    Key? key,
    required this.primaryAxisChartId,
    required this.primaryAxisChartColor,
    required this.secondaryAxisChartId,
    required this.secondaryAxisChartColor,
    required this.title,
    required this.chartData,
    this.legends,
    this.chartHeight = 200,
  }) : super(key: key);

  final String primaryAxisChartId;
  final Color primaryAxisChartColor;
  final String secondaryAxisChartId;
  final Color secondaryAxisChartColor;
  final String title;
  final List<DualAxisBarChartItemModel> chartData;
  final List<ChartLegendModel>? legends;
  final double chartHeight;

  @override
  Widget build(BuildContext context) {
    final primaryMin = chartData.map((e) => e.primaryYValue).reduce((v, e) => math.min(v, e));
    final primaryMax = chartData.map((e) => e.primaryYValue).reduce((v, e) => math.max(v, e));
    final secondaryMin = chartData.map((e) => e.secondaryYValue).reduce((v, e) => math.min(v, e));
    final secondaryMax = chartData.map((e) => e.secondaryYValue).reduce((v, e) => math.max(v, e));
    final primaryRange = (primaryMax - primaryMin).abs();
    final secondaryRange = (secondaryMax - secondaryMin).abs();
    final secondaryMultiplier = secondaryRange != 0 ? primaryRange / secondaryRange : primaryRange;
    return ChartContainer(
      title: title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              left: 8,
              bottom: 8,
              right: 8,
            ),
            child: SizedBox(
              height: chartHeight,
              child: charts.BarChart(
                [
                  charts.Series<DualAxisBarChartItemModel, String>(
                    id: primaryAxisChartId,
                    domainFn: (model, _) => model.xTitle,
                    measureFn: (model, _) => model.primaryYValue,
                    data: chartData,
                    fillColorFn: (_, __) => charts.ColorUtil.fromDartColor(primaryAxisChartColor),
                    labelAccessorFn: (model, _) => model.primaryYTitle,
                  ),
                  charts.Series<DualAxisBarChartItemModel, String>(
                    id: primaryAxisChartId,
                    domainFn: (model, _) => model.xTitle,
                    measureFn: (model, _) => model.secondaryYValue * secondaryMultiplier,
                    data: chartData,
                    fillColorFn: (_, __) => charts.ColorUtil.fromDartColor(secondaryAxisChartColor),
                    labelAccessorFn: (model, _) => model.secondaryYTitle,
                    measureLowerBoundFn: (_, __) => primaryMin,
                    measureUpperBoundFn: (_, __) => primaryMax,
                  )..setAttribute(charts.measureAxisIdKey, 'secondaryMeasureAxisId'),
                ],
                barGroupingType: charts.BarGroupingType.grouped,
                primaryMeasureAxis: charts.NumericAxisSpec(
                  tickProviderSpec: charts.BasicNumericTickProviderSpec(desiredTickCount: 4),
                  renderSpec: charts.GridlineRendererSpec(
                    labelStyle: charts.TextStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.primaryTextColor),
                    ),
                  ),
                ),
                secondaryMeasureAxis: charts.NumericAxisSpec(
                  tickProviderSpec: charts.BasicNumericTickProviderSpec(desiredTickCount: 4),
                  renderSpec: charts.NoneRenderSpec(),
                ),
                domainAxis: charts.OrdinalAxisSpec(
                  renderSpec: charts.SmallTickRendererSpec(
                    labelStyle: charts.TextStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.primaryTextColor),
                    ),
                    lineStyle: charts.LineStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.borderColor),
                    ),
                  ),
                ),
                defaultRenderer: charts.BarRendererConfig<String>(
                  barGroupInnerPaddingPx: 16,
                  cornerStrategy: const charts.ConstCornerStrategy(4),
                  maxBarWidthPx: 8,
                  barRendererDecorator: charts.BarLabelDecorator(
                    labelPosition: charts.BarLabelPosition.outside,
                    outsideLabelStyleSpec: charts.TextStyleSpec(
                      color: charts.ColorUtil.fromDartColor(context.appTheme.primaryTextColor),
                      fontSize: 9,
                    ),
                    unboundedWidth: true,
                  ),
                ),
              ),
            ),
          ),
          if (legends != null && legends!.isNotEmpty) ChartLegendsWidget(legends: legends),
        ],
      ),
    );
  }
}

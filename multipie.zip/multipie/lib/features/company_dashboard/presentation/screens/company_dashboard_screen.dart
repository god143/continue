import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/custom_icon.dart';
import 'package:multipie/features/company_dashboard/presentation/cubit/company_dashboard_cubit.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/chart_legend_model.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/bar_chart.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/company_stats_section.dart';
import 'package:multipie/features/company_dashboard/presentation/widgets/dual_axis_bar_chart.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';
import 'package:multipie/features/market/domain/usecases/get_company_report.dart';
import 'package:multipie/locator.dart';

/// Shows Company stats & charts
class CompanyDashboardScreen extends StatelessWidget {
  CompanyDashboardScreen({
    Key? key,
    required this.companyDetails,
  }) : super(key: key);

  final CompanyDetails companyDetails;

  @override
  Widget build(BuildContext context) {
    final _firstChartColor = Theme.of(context).primaryColor.withOpacity(0.75);
    final _secondChartColor = context.appTheme.blueShadeColor.withOpacity(0.75);
    return BlocProvider<CompanyDashboardCubit>(
      create: (context) => CompanyDashboardCubit(
        companyDetails: companyDetails,
        getCompanyStats: locator(),
        getCompanyReport: locator(),
      ),
      child: Scaffold(
        appBar: MultipieAppBar(
          title: 'Stock Insights',
          centerTitle: false,
          actions: [
            _BroughtByMultipieTag(),
          ],
        ),
        body: BlocConsumer<CompanyDashboardCubit, CompanyDashboardState>(
          listener: (context, state) {},
          builder: (context, state) {
            final model = context.read<CompanyDashboardCubit>().getModelFromCurrentState();
            return CustomScrollView(
              slivers: [
                SliverList(
                  delegate: SliverChildListDelegate(
                    [
                      _ListItemContainer(
                        child: Padding(
                          padding: const EdgeInsets.only(
                            top: 16,
                            left: 4,
                            right: 4,
                          ),
                          child: _CompanyHeader(companyDetails: companyDetails),
                        ),
                      ),

                      const _LoadingIndicator(),

                      // Company Stats
                      _ListItemContainer(
                        child: CompanyStatsSection(companyStats: model.companyStats),
                      ),

                      // CHART-1: Quarterly Sales
                      if (model.quarterlySalesChartData != null)
                        _ListItemContainer(
                          child: MPBarChart(
                            title: 'Quarterly Sales (Rs. in cr)',
                            data: [
                              BarChartModel(
                                chartId: 'Sales',
                                data: model.quarterlySalesChartData!,
                                barColor: _firstChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-2: Quarterly EBITDA
                      if (model.quarterlyEBITDAChartData != null)
                        _ListItemContainer(
                          child: MPDualAxisBarChart(
                            primaryAxisChartId: 'quarterly_ebitda',
                            primaryAxisChartColor: _firstChartColor,
                            secondaryAxisChartId: 'quarterly_ebitda_margin',
                            secondaryAxisChartColor: _secondChartColor,
                            title: 'Quarterly EBITDA (Rs. in cr) with margin in %',
                            chartData: model.quarterlyEBITDAChartData!,
                            legends: [
                              ChartLegendModel(
                                name: 'EBITDA',
                                color: _firstChartColor,
                              ),
                              ChartLegendModel(
                                name: 'Margin',
                                color: _secondChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-3: Quarterly PAT
                      if (model.quarterlyPATChartData != null)
                        _ListItemContainer(
                          child: MPDualAxisBarChart(
                            primaryAxisChartId: 'quarterly_pat',
                            primaryAxisChartColor: _firstChartColor,
                            secondaryAxisChartId: 'quarterly_pat_margin',
                            secondaryAxisChartColor: _secondChartColor,
                            title: 'Quarterly PAT (Rs. in cr) with margin in %',
                            chartData: model.quarterlyPATChartData!,
                            legends: [
                              ChartLegendModel(
                                name: 'PAT',
                                color: _firstChartColor,
                              ),
                              ChartLegendModel(
                                name: 'Margin',
                                color: _secondChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-4: Annual Sales
                      if (model.annualSalesChartData != null)
                        _ListItemContainer(
                          child: MPBarChart(
                            title: 'Annual Sales (Rs. in cr)',
                            data: [
                              BarChartModel(
                                chartId: 'Sales',
                                data: model.annualSalesChartData!,
                                barColor: _firstChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-5: Annual EBITDA with Margin
                      if (model.annualEBITDAWithMarginChartData != null)
                        _ListItemContainer(
                          child: MPDualAxisBarChart(
                            primaryAxisChartId: 'annual_ebitda',
                            primaryAxisChartColor: _firstChartColor,
                            secondaryAxisChartId: 'annual_ebitda_margin',
                            secondaryAxisChartColor: _secondChartColor,
                            title: 'Annual EBITDA (Rs. in cr) with margin in %',
                            chartData: model.annualEBITDAWithMarginChartData!,
                            legends: [
                              ChartLegendModel(
                                name: 'EBITDA',
                                color: _firstChartColor,
                              ),
                              ChartLegendModel(
                                name: 'Margin',
                                color: _secondChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-6: Annual PAT with Margin
                      if (model.annualPATWithMarginChartData != null)
                        _ListItemContainer(
                          child: MPDualAxisBarChart(
                            primaryAxisChartId: 'annual_pat',
                            primaryAxisChartColor: _firstChartColor,
                            secondaryAxisChartId: 'annual_pat_margin',
                            secondaryAxisChartColor: _secondChartColor,
                            title: 'Annual PAT (Rs. in cr) with margin in %',
                            chartData: model.annualPATWithMarginChartData!,
                            legends: [
                              ChartLegendModel(
                                name: 'PAT',
                                color: _firstChartColor,
                              ),
                              ChartLegendModel(
                                name: 'Margin',
                                color: _secondChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-7: Debt / Equity
                      if (model.debtChartData != null && model.equityChartData != null)
                        _ListItemContainer(
                          child: MPBarChart(
                            title: 'Debt / Equity',
                            data: [
                              BarChartModel(
                                chartId: 'Debt',
                                data: model.debtChartData!,
                                barColor: _firstChartColor,
                              ),
                              BarChartModel(
                                chartId: 'Equity',
                                data: model.equityChartData!,
                                barColor: _secondChartColor,
                              ),
                            ],
                          ),
                        ),

                      // CHART-8: Promoter Shareholding
                      if (model.pledgedShareholdingChartData != null && model.promoterShareholdingChartData != null)
                        _ListItemContainer(
                          child: MPBarChart(
                            title: 'Promoter Shareholding with pledge',
                            data: [
                              BarChartModel(
                                chartId: 'Actual (A)',
                                data: model.promoterShareholdingChartData!,
                                barColor: _secondChartColor,
                                legendColor: _firstChartColor,
                              ),
                              BarChartModel(
                                chartId: 'Pledged (P)',
                                data: model.pledgedShareholdingChartData!,
                                barColor: _firstChartColor,
                                legendColor: _secondChartColor,
                              ),
                            ],
                            barGroupingType: charts.BarGroupingType.groupedStacked,
                          ),
                        ),

                      // CHART-9: Annual PAT with Margin
                      if (model.annualOperatingCashflowChartData != null)
                        _ListItemContainer(
                          child: MPBarChart(
                            title: 'Operating cash flow (Rs. in cr)',
                            data: [
                              BarChartModel(
                                chartId: 'Operating CF',
                                data: model.annualOperatingCashflowChartData!,
                                barColor: _firstChartColor,
                              ),
                            ],
                          ),
                        ),

                      // Spacer to avoid content behind share button & safearea
                      SizedBox(height: MediaQuery.of(context).padding.bottom + 60),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
        floatingActionButton: Builder(
          builder: (context) {
            return FloatingActionButton(
              onPressed: () => context.read<CompanyDashboardCubit>().shareUrl(),
              backgroundColor: Theme.of(context).primaryColor,
              child: CustomIcon(
                CustomIcons.share2,
                color: context.appTheme.cardBackgroundColor,
                height: 20,
                width: 20,
              ),
            );
          },
        ),
      ),
    );
  }
}

class _BroughtByMultipieTag extends StatelessWidget {
  const _BroughtByMultipieTag({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _lightAppTheme = context.lightAppTheme;
    return Padding(
      padding: const EdgeInsets.only(left: 8, right: 16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: Container(
              color: _lightAppTheme.primaryColor,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(
                  children: [
                    Text(
                      'Brought to you by',
                      style: kDefaultTitleStyle(
                        textColor: _lightAppTheme.cardBackgroundColor,
                      ),
                    ),
                    SizedBox(width: 4),
                    SvgPicture.asset(
                      'assets/icons/ic_multipie_text.svg',
                      color: _lightAppTheme.cardBackgroundColor,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CompanyHeader extends StatelessWidget {
  const _CompanyHeader({
    Key? key,
    required this.companyDetails,
  }) : super(key: key);

  final CompanyDetails companyDetails;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CompanyDashboardCubit, CompanyDashboardState>(
      listener: (_, __) {},
      builder: (context, state) {
        final isLoading = state.maybeMap(
          loading: (_) => true,
          orElse: () => false,
        );
        return Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Company Name',
                    style: mpHeadLine6(
                      context: context,
                      fontWeight: FontWeight.w400,
                      textColor: context.appTheme.secondaryTextColor,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    companyDetails.name,
                    style: mpHeadLine4(
                      context: context,
                      fontWeight: FontWeight.w500,
                      textColor: context.appTheme.primaryTextColor,
                    ),
                  ),
                ],
              ),
            ),
            IgnorePointer(
              ignoring: isLoading,
              child: _StatementToggle(
                companyDetails: companyDetails,
                currentStatementType: context.read<CompanyDashboardCubit>().getModelFromCurrentState().statementType,
                onTap: (statementType) => context.read<CompanyDashboardCubit>().switchStatementType(statementType),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _ListItemContainer extends StatelessWidget {
  const _ListItemContainer({
    Key? key,
    required this.child,
  }) : super(key: key);

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: child,
    );
  }
}

class _LoadingIndicator extends StatelessWidget {
  const _LoadingIndicator({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CompanyDashboardCubit, CompanyDashboardState>(
      builder: (_, state) {
        final showLoading = state.maybeMap(
          loading: (_) => true,
          orElse: () => false,
        );
        return AnimatedSize(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeInOut,
          child: showLoading
              ? Padding(
                  padding: const EdgeInsets.all(20),
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : SizedBox(),
        );
      },
      listener: (context, state) {},
    );
  }
}

class _StatementToggle extends StatelessWidget {
  final CompanyDetails companyDetails;
  final CompanyReportStatementType currentStatementType;
  final Function(CompanyReportStatementType selectedStatementType) onTap;

  const _StatementToggle({
    Key? key,
    required this.companyDetails,
    required this.currentStatementType,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool isConsolidated;
    bool hasMultipleStatements = companyDetails.statements.length > 1;
    switch (currentStatementType) {
      case CompanyReportStatementType.standalone:
        isConsolidated = false;
        break;
      case CompanyReportStatementType.consolidated:
        isConsolidated = true;
        break;
    }
    return GestureDetector(
      onTap: () {
        if (!hasMultipleStatements) {
          return;
        }
        final newStatementType =
            isConsolidated ? CompanyReportStatementType.standalone : CompanyReportStatementType.consolidated;
        onTap(newStatementType);
      },
      child: Container(
        height: 20,
        width: 100,
        decoration: BoxDecoration(
          color: context.appTheme.blueShadeColor.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              isConsolidated ? 'Consolidated' : 'Standalone',
              style: TextStyle(
                color: context.appTheme.blueShadeColor,
                fontFamily: 'Roboto',
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(width: 5),
            if (hasMultipleStatements)
              Image.asset(
                'assets/images/exchange.png',
                color: context.appTheme.blueShadeColor,
              )
          ],
        ),
      ),
    );
  }
}

import 'package:bloc/bloc.dart';
import 'package:collection/collection.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/core/utils/share_util.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_item_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/company_dashboard_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/dual_axis_bar_chart_item_model.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';
import 'package:multipie/features/market/domain/usecases/get_company_report.dart';
import 'package:multipie/features/market/domain/usecases/get_company_stats.dart';

part 'company_dashboard_cubit.freezed.dart';
part 'company_dashboard_state.dart';

class CompanyDashboardCubit extends Cubit<CompanyDashboardState> {
  CompanyDashboardCubit({
    required this.companyDetails,
    required this.getCompanyStats,
    required this.getCompanyReport,
  }) : super(CompanyDashboardState.initial()) {
    _fetchData();
  }

  final CompanyDetails companyDetails;
  final GetCompanyStats getCompanyStats;
  final GetCompanyReport getCompanyReport;

  String get companyId => companyDetails.id;

  void switchStatementType(CompanyReportStatementType type) {
    _switchStatementAndRefreshIfNeeded(type);
  }

  void _switchStatementAndRefreshIfNeeded(CompanyReportStatementType statementType) {
    final model = getModelFromCurrentState();
    if (model.statementType == statementType) {
      return;
    } else {
      emit(
        CompanyDashboardState.loading(
          model.copyWith(statementType: statementType),
        ),
      );
      _fetchData();
    }
  }

  Future<void> _fetchData() async {
    emit(CompanyDashboardState.loading(getModelFromCurrentState()));
    await Future.wait(
      [
        _fetchCompanyStats(),
        _fetchQuarterlyResults(),
        _fetchAnnualPNL(),
        _fetchBalanceSheet(),
        _fetchPromoterShareholding(),
        _fetchCashflow(),
      ],
    );
    emit(CompanyDashboardState.loaded(getModelFromCurrentState()));
  }

  CompanyDashboardModel getModelFromCurrentState() {
    return state.map(
      initial: (_) {
        final statementType = companyDetails.statements.contains('consolidated')
            ? CompanyReportStatementType.consolidated
            : CompanyReportStatementType.standalone;
        return CompanyDashboardModel(statementType: statementType);
      },
      loading: (state) => state.model,
      loaded: (state) => state.model,
      loadingFailed: (state) => state.model,
    );
  }

  Future<void> _fetchCompanyStats() async {
    String statementType;
    switch (getModelFromCurrentState().statementType) {
      case CompanyReportStatementType.standalone:
        statementType = 'standalone';
        break;
      case CompanyReportStatementType.consolidated:
        statementType = 'consolidated';
        break;
    }
    final result = await getCompanyStats(
      Params(id: companyId, stats: statementType),
    );
    result.fold(
      (failure) => emit(
        CompanyDashboardState.loadingFailed(
          failure,
          getModelFromCurrentState().copyWith(companyStats: null),
        ),
      ),
      (stats) => emit(
        CompanyDashboardState.loading(
          getModelFromCurrentState().copyWith(companyStats: stats),
        ),
      ),
    );
  }

  Future<void> _fetchQuarterlyResults() async {
    final result = await getCompanyReport.call(
      GetCompanyReportParams(
        companyId: companyId,
        reportType: CompanyReportType.results,
        reportStatementType: getModelFromCurrentState().statementType,
      ),
    );
    result.fold(
      (failure) => emit(
        CompanyDashboardState.loadingFailed(
          failure,
          getModelFromCurrentState().copyWith(
            quarterlySalesChartData: null,
            quarterlyEBITDAChartData: null,
            quarterlyPATChartData: null,
          ),
        ),
      ),
      (results) {
        final recentData = results
            .sorted(
              (l, r) => DateTime(l.year, l.quarter).compareTo(DateTime(r.year, r.quarter)),
            )
            .pickLast(5);
        final salesChartData = recentData.mapIndexed(
          (index, e) {
            return BarChartItemModel(
              xTitle: formatAsQuarterString(e.year, e.quarter),
              yTitle: (e.sales ?? 0).formatAsCurrency(),
              yValue: e.sales ?? 0,
            );
          },
        ).toList(growable: false);

        final ebitdaChartData = recentData.mapIndexed(
          (index, e) {
            return DualAxisBarChartItemModel(
              xTitle: formatAsQuarterString(e.year, e.quarter),
              primaryYTitle: e.ebitda.formatAsCurrency(),
              primaryYValue: e.ebitda,
              secondaryYTitle: e.ebitdaMargin.formatAsString() + '%',
              secondaryYValue: e.ebitdaMargin,
            );
          },
        ).toList(growable: false);

        final patChartData = recentData.mapIndexed(
          (index, e) {
            return DualAxisBarChartItemModel(
              xTitle: formatAsQuarterString(e.year, e.quarter),
              primaryYTitle: e.pat.formatAsCurrency(),
              primaryYValue: e.pat,
              secondaryYTitle: e.patMargin.formatAsString() + '%',
              secondaryYValue: e.patMargin,
            );
          },
        ).toList(growable: false);

        emit(
          CompanyDashboardState.loading(
            getModelFromCurrentState().copyWith(
              quarterlySalesChartData: salesChartData,
              quarterlyEBITDAChartData: ebitdaChartData,
              quarterlyPATChartData: patChartData,
            ),
          ),
        );
      },
    );
  }

  Future<void> _fetchAnnualPNL() async {
    final result = await getCompanyReport.call(
      GetCompanyReportParams(
        companyId: companyId,
        reportType: CompanyReportType.pnl,
        reportStatementType: getModelFromCurrentState().statementType,
      ),
    );
    result.fold(
      (failure) => emit(
        CompanyDashboardState.loadingFailed(
          failure,
          getModelFromCurrentState().copyWith(
            annualSalesChartData: null,
            annualEBITDAWithMarginChartData: null,
            annualPATWithMarginChartData: null,
          ),
        ),
      ),
      (results) {
        final recentData = results
            .sorted(
              (l, r) => DateTime(l.year).compareTo(DateTime(r.year)),
            )
            .pickLast(5);
        final salesChartData = recentData.mapIndexed(
          (index, e) {
            return BarChartItemModel(
              xTitle: DateTime(e.year).format('yyyy'),
              yTitle: (e.sales ?? 0).formatAsCurrency(),
              yValue: e.sales ?? 0,
            );
          },
        ).toList(growable: false);

        final ebitdaWithMarginChartData = recentData.mapIndexed(
          (index, e) {
            return DualAxisBarChartItemModel(
              xTitle: DateTime(e.year).format('yyyy'),
              primaryYTitle: e.ebitda.formatAsCurrency(),
              primaryYValue: e.ebitda,
              secondaryYTitle: e.ebitdaMargin.formatAsString() + '%',
              secondaryYValue: e.ebitdaMargin,
            );
          },
        ).toList(growable: false);

        final patWithMarginChartData = recentData.mapIndexed(
          (index, e) {
            return DualAxisBarChartItemModel(
              xTitle: DateTime(e.year).format('yyyy'),
              primaryYTitle: e.pat.formatAsCurrency(),
              primaryYValue: e.pat,
              secondaryYTitle: e.patMargin.formatAsString() + '%',
              secondaryYValue: e.patMargin,
            );
          },
        ).toList(growable: false);

        emit(
          CompanyDashboardState.loading(
            getModelFromCurrentState().copyWith(
              annualSalesChartData: salesChartData,
              annualEBITDAWithMarginChartData: ebitdaWithMarginChartData,
              annualPATWithMarginChartData: patWithMarginChartData,
            ),
          ),
        );
      },
    );
  }

  Future<void> _fetchBalanceSheet() async {
    final result = await getCompanyReport.call(
      GetCompanyReportParams(
        companyId: companyId,
        reportType: CompanyReportType.balanceSheet,
        reportStatementType: getModelFromCurrentState().statementType,
      ),
    );
    result.fold(
      (failure) => emit(
        CompanyDashboardState.loadingFailed(
          failure,
          getModelFromCurrentState().copyWith(
            debtChartData: null,
            equityChartData: null,
          ),
        ),
      ),
      (results) {
        final recentData = results
            .sorted(
              (l, r) => DateTime(l.year).compareTo(DateTime(r.year)),
            )
            .pickLast(5);
        final debtChartData = recentData.mapIndexed(
          (index, e) {
            return BarChartItemModel(
              xTitle: DateTime(e.year).format('yyyy'),
              yTitle: (e.borrowings ?? 0).formatAsCurrency(),
              yValue: e.borrowings ?? 0,
            );
          },
        ).toList(growable: false);

        final equityChartData = recentData.mapIndexed(
          (index, e) {
            final equity = (e.shareCapital ?? 0) + (e.reserves ?? 0);
            return BarChartItemModel(
              xTitle: DateTime(e.year).format('yyyy'),
              yTitle: equity.formatAsCurrency(),
              yValue: equity,
            );
          },
        ).toList(growable: false);

        emit(
          CompanyDashboardState.loading(
            getModelFromCurrentState().copyWith(
              debtChartData: debtChartData,
              equityChartData: equityChartData,
            ),
          ),
        );
      },
    );
  }

  Future<void> _fetchCashflow() async {
    final result = await getCompanyReport.call(
      GetCompanyReportParams(
        companyId: companyId,
        reportType: CompanyReportType.cashflow,
        reportStatementType: getModelFromCurrentState().statementType,
      ),
    );
    result.fold(
      (failure) => emit(
        CompanyDashboardState.loadingFailed(
          failure,
          getModelFromCurrentState().copyWith(
            annualOperatingCashflowChartData: null,
          ),
        ),
      ),
      (results) {
        final recentData = results
            .sorted(
              (l, r) => DateTime(l.year).compareTo(DateTime(r.year)),
            )
            .pickLast(5);
        final operatingCashflowChartData = recentData.mapIndexed(
          (index, e) {
            return BarChartItemModel(
              xTitle: DateTime(e.year).format('yyyy'),
              yTitle: (e.cfFromOperating ?? 0).formatAsCurrency(),
              yValue: e.cfFromOperating ?? 0,
            );
          },
        ).toList(growable: false);

        emit(
          CompanyDashboardState.loading(
            getModelFromCurrentState().copyWith(
              annualOperatingCashflowChartData: operatingCashflowChartData,
            ),
          ),
        );
      },
    );
  }

  Future<void> _fetchPromoterShareholding() async {
    final result = await getCompanyReport.call(
      GetCompanyReportParams(
        companyId: companyId,
        reportType: CompanyReportType.promoterShareHolding,
        reportStatementType: getModelFromCurrentState().statementType,
      ),
    );
    result.fold(
      (failure) => emit(
        CompanyDashboardState.loadingFailed(
          failure,
          getModelFromCurrentState().copyWith(
            pledgedShareholdingChartData: null,
            promoterShareholdingChartData: null,
          ),
        ),
      ),
      (results) {
        final recentData = results
            .sorted(
              (l, r) => DateTime(l.year, l.quarter).compareTo(DateTime(r.year, r.quarter)),
            )
            .pickLast(5);
        final pledgedShareholdingChartData = recentData.mapIndexed(
          (index, e) {
            return BarChartItemModel(
              xTitle: formatAsQuarterString(e.year, e.quarter),
              yTitle: '',
              yValue: e.pledgeShareholding ?? 0,
            );
          },
        ).toList(growable: false);
        final promoterShareholdingChartData = recentData.mapIndexed(
          (index, e) {
            return BarChartItemModel(
              xTitle: formatAsQuarterString(e.year, e.quarter),
              yTitle:
                  'A: ${(e.promoterShareholding ?? 0).formatAsString()}%\nP: ${(e.pledgeShareholding ?? 0).formatAsString()}%',
              yValue: (e.promoterShareholding ?? 0) - (e.pledgeShareholding ?? 0),
            );
          },
        ).toList(growable: false);

        emit(
          CompanyDashboardState.loading(
            getModelFromCurrentState().copyWith(
              pledgedShareholdingChartData: pledgedShareholdingChartData,
              promoterShareholdingChartData: promoterShareholdingChartData,
            ),
          ),
        );
      },
    );
  }

  void shareUrl() => shareCompanyDashboard(companyId: companyId, companyName: companyDetails.name);
}

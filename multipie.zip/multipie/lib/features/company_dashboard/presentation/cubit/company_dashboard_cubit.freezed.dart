// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'company_dashboard_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CompanyDashboardState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CompanyDashboardModel model) loading,
    required TResult Function(CompanyDashboardModel model) loaded,
    required TResult Function(Failure failure, CompanyDashboardModel model)
        loadingFailed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Loaded value) loaded,
    required TResult Function(_LoadingFailed value) loadingFailed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyDashboardStateCopyWith<$Res> {
  factory $CompanyDashboardStateCopyWith(CompanyDashboardState value,
          $Res Function(CompanyDashboardState) then) =
      _$CompanyDashboardStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$CompanyDashboardStateCopyWithImpl<$Res>
    implements $CompanyDashboardStateCopyWith<$Res> {
  _$CompanyDashboardStateCopyWithImpl(this._value, this._then);

  final CompanyDashboardState _value;
  // ignore: unused_field
  final $Res Function(CompanyDashboardState) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$CompanyDashboardStateCopyWithImpl<$Res>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, (v) => _then(v as _$_Initial));

  @override
  _$_Initial get _value => super._value as _$_Initial;
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'CompanyDashboardState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CompanyDashboardModel model) loading,
    required TResult Function(CompanyDashboardModel model) loaded,
    required TResult Function(Failure failure, CompanyDashboardModel model)
        loadingFailed,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Loaded value) loaded,
    required TResult Function(_LoadingFailed value) loadingFailed,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements CompanyDashboardState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
  $Res call({CompanyDashboardModel model});

  $CompanyDashboardModelCopyWith<$Res> get model;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$CompanyDashboardStateCopyWithImpl<$Res>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, (v) => _then(v as _$_Loading));

  @override
  _$_Loading get _value => super._value as _$_Loading;

  @override
  $Res call({
    Object? model = freezed,
  }) {
    return _then(_$_Loading(
      model == freezed
          ? _value.model
          : model // ignore: cast_nullable_to_non_nullable
              as CompanyDashboardModel,
    ));
  }

  @override
  $CompanyDashboardModelCopyWith<$Res> get model {
    return $CompanyDashboardModelCopyWith<$Res>(_value.model, (value) {
      return _then(_value.copyWith(model: value));
    });
  }
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading(this.model);

  @override
  final CompanyDashboardModel model;

  @override
  String toString() {
    return 'CompanyDashboardState.loading(model: $model)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Loading &&
            const DeepCollectionEquality().equals(other.model, model));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(model));

  @JsonKey(ignore: true)
  @override
  _$$_LoadingCopyWith<_$_Loading> get copyWith =>
      __$$_LoadingCopyWithImpl<_$_Loading>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CompanyDashboardModel model) loading,
    required TResult Function(CompanyDashboardModel model) loaded,
    required TResult Function(Failure failure, CompanyDashboardModel model)
        loadingFailed,
  }) {
    return loading(model);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
  }) {
    return loading?.call(model);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(model);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Loaded value) loaded,
    required TResult Function(_LoadingFailed value) loadingFailed,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements CompanyDashboardState {
  const factory _Loading(final CompanyDashboardModel model) = _$_Loading;

  CompanyDashboardModel get model => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  _$$_LoadingCopyWith<_$_Loading> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_LoadedCopyWith<$Res> {
  factory _$$_LoadedCopyWith(_$_Loaded value, $Res Function(_$_Loaded) then) =
      __$$_LoadedCopyWithImpl<$Res>;
  $Res call({CompanyDashboardModel model});

  $CompanyDashboardModelCopyWith<$Res> get model;
}

/// @nodoc
class __$$_LoadedCopyWithImpl<$Res>
    extends _$CompanyDashboardStateCopyWithImpl<$Res>
    implements _$$_LoadedCopyWith<$Res> {
  __$$_LoadedCopyWithImpl(_$_Loaded _value, $Res Function(_$_Loaded) _then)
      : super(_value, (v) => _then(v as _$_Loaded));

  @override
  _$_Loaded get _value => super._value as _$_Loaded;

  @override
  $Res call({
    Object? model = freezed,
  }) {
    return _then(_$_Loaded(
      model == freezed
          ? _value.model
          : model // ignore: cast_nullable_to_non_nullable
              as CompanyDashboardModel,
    ));
  }

  @override
  $CompanyDashboardModelCopyWith<$Res> get model {
    return $CompanyDashboardModelCopyWith<$Res>(_value.model, (value) {
      return _then(_value.copyWith(model: value));
    });
  }
}

/// @nodoc

class _$_Loaded implements _Loaded {
  const _$_Loaded(this.model);

  @override
  final CompanyDashboardModel model;

  @override
  String toString() {
    return 'CompanyDashboardState.loaded(model: $model)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Loaded &&
            const DeepCollectionEquality().equals(other.model, model));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(model));

  @JsonKey(ignore: true)
  @override
  _$$_LoadedCopyWith<_$_Loaded> get copyWith =>
      __$$_LoadedCopyWithImpl<_$_Loaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CompanyDashboardModel model) loading,
    required TResult Function(CompanyDashboardModel model) loaded,
    required TResult Function(Failure failure, CompanyDashboardModel model)
        loadingFailed,
  }) {
    return loaded(model);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
  }) {
    return loaded?.call(model);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(model);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Loaded value) loaded,
    required TResult Function(_LoadingFailed value) loadingFailed,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class _Loaded implements CompanyDashboardState {
  const factory _Loaded(final CompanyDashboardModel model) = _$_Loaded;

  CompanyDashboardModel get model => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  _$$_LoadedCopyWith<_$_Loaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_LoadingFailedCopyWith<$Res> {
  factory _$$_LoadingFailedCopyWith(
          _$_LoadingFailed value, $Res Function(_$_LoadingFailed) then) =
      __$$_LoadingFailedCopyWithImpl<$Res>;
  $Res call({Failure failure, CompanyDashboardModel model});

  $CompanyDashboardModelCopyWith<$Res> get model;
}

/// @nodoc
class __$$_LoadingFailedCopyWithImpl<$Res>
    extends _$CompanyDashboardStateCopyWithImpl<$Res>
    implements _$$_LoadingFailedCopyWith<$Res> {
  __$$_LoadingFailedCopyWithImpl(
      _$_LoadingFailed _value, $Res Function(_$_LoadingFailed) _then)
      : super(_value, (v) => _then(v as _$_LoadingFailed));

  @override
  _$_LoadingFailed get _value => super._value as _$_LoadingFailed;

  @override
  $Res call({
    Object? failure = freezed,
    Object? model = freezed,
  }) {
    return _then(_$_LoadingFailed(
      failure == freezed
          ? _value.failure
          : failure // ignore: cast_nullable_to_non_nullable
              as Failure,
      model == freezed
          ? _value.model
          : model // ignore: cast_nullable_to_non_nullable
              as CompanyDashboardModel,
    ));
  }

  @override
  $CompanyDashboardModelCopyWith<$Res> get model {
    return $CompanyDashboardModelCopyWith<$Res>(_value.model, (value) {
      return _then(_value.copyWith(model: value));
    });
  }
}

/// @nodoc

class _$_LoadingFailed implements _LoadingFailed {
  const _$_LoadingFailed(this.failure, this.model);

  @override
  final Failure failure;
  @override
  final CompanyDashboardModel model;

  @override
  String toString() {
    return 'CompanyDashboardState.loadingFailed(failure: $failure, model: $model)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_LoadingFailed &&
            const DeepCollectionEquality().equals(other.failure, failure) &&
            const DeepCollectionEquality().equals(other.model, model));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(failure),
      const DeepCollectionEquality().hash(model));

  @JsonKey(ignore: true)
  @override
  _$$_LoadingFailedCopyWith<_$_LoadingFailed> get copyWith =>
      __$$_LoadingFailedCopyWithImpl<_$_LoadingFailed>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CompanyDashboardModel model) loading,
    required TResult Function(CompanyDashboardModel model) loaded,
    required TResult Function(Failure failure, CompanyDashboardModel model)
        loadingFailed,
  }) {
    return loadingFailed(failure, model);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
  }) {
    return loadingFailed?.call(failure, model);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CompanyDashboardModel model)? loading,
    TResult Function(CompanyDashboardModel model)? loaded,
    TResult Function(Failure failure, CompanyDashboardModel model)?
        loadingFailed,
    required TResult orElse(),
  }) {
    if (loadingFailed != null) {
      return loadingFailed(failure, model);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Loaded value) loaded,
    required TResult Function(_LoadingFailed value) loadingFailed,
  }) {
    return loadingFailed(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
  }) {
    return loadingFailed?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Loaded value)? loaded,
    TResult Function(_LoadingFailed value)? loadingFailed,
    required TResult orElse(),
  }) {
    if (loadingFailed != null) {
      return loadingFailed(this);
    }
    return orElse();
  }
}

abstract class _LoadingFailed implements CompanyDashboardState {
  const factory _LoadingFailed(
          final Failure failure, final CompanyDashboardModel model) =
      _$_LoadingFailed;

  Failure get failure => throw _privateConstructorUsedError;
  CompanyDashboardModel get model => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  _$$_LoadingFailedCopyWith<_$_LoadingFailed> get copyWith =>
      throw _privateConstructorUsedError;
}

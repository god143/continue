part of 'company_dashboard_cubit.dart';

@freezed
class CompanyDashboardState with _$CompanyDashboardState {
  const factory CompanyDashboardState.initial() = _Initial;
  const factory CompanyDashboardState.loading(CompanyDashboardModel model) = _Loading;
  const factory CompanyDashboardState.loaded(CompanyDashboardModel model) = _Loaded;
  const factory CompanyDashboardState.loadingFailed(Failure failure, CompanyDashboardModel model) = _LoadingFailed;
}

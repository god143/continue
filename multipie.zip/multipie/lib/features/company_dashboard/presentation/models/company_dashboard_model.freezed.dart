// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'company_dashboard_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CompanyDashboardModel {
  CompanyReportStatementType get statementType =>
      throw _privateConstructorUsedError;
  CompanyStats? get companyStats => throw _privateConstructorUsedError;
  List<BarChartItemModel>? get quarterlySalesChartData =>
      throw _privateConstructorUsedError;
  List<DualAxisBarChartItemModel>? get quarterlyEBITDAChartData =>
      throw _privateConstructorUsedError;
  List<DualAxisBarChartItemModel>? get quarterlyPATChartData =>
      throw _privateConstructorUsedError;
  List<BarChartItemModel>? get annualSalesChartData =>
      throw _privateConstructorUsedError;
  List<DualAxisBarChartItemModel>? get annualEBITDAWithMarginChartData =>
      throw _privateConstructorUsedError;
  List<DualAxisBarChartItemModel>? get annualPATWithMarginChartData =>
      throw _privateConstructorUsedError;
  List<BarChartItemModel>? get annualOperatingCashflowChartData =>
      throw _privateConstructorUsedError;
  List<BarChartItemModel>? get debtChartData =>
      throw _privateConstructorUsedError;
  List<BarChartItemModel>? get equityChartData =>
      throw _privateConstructorUsedError;
  List<BarChartItemModel>? get pledgedShareholdingChartData =>
      throw _privateConstructorUsedError;
  List<BarChartItemModel>? get promoterShareholdingChartData =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CompanyDashboardModelCopyWith<CompanyDashboardModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyDashboardModelCopyWith<$Res> {
  factory $CompanyDashboardModelCopyWith(CompanyDashboardModel value,
          $Res Function(CompanyDashboardModel) then) =
      _$CompanyDashboardModelCopyWithImpl<$Res>;
  $Res call(
      {CompanyReportStatementType statementType,
      CompanyStats? companyStats,
      List<BarChartItemModel>? quarterlySalesChartData,
      List<DualAxisBarChartItemModel>? quarterlyEBITDAChartData,
      List<DualAxisBarChartItemModel>? quarterlyPATChartData,
      List<BarChartItemModel>? annualSalesChartData,
      List<DualAxisBarChartItemModel>? annualEBITDAWithMarginChartData,
      List<DualAxisBarChartItemModel>? annualPATWithMarginChartData,
      List<BarChartItemModel>? annualOperatingCashflowChartData,
      List<BarChartItemModel>? debtChartData,
      List<BarChartItemModel>? equityChartData,
      List<BarChartItemModel>? pledgedShareholdingChartData,
      List<BarChartItemModel>? promoterShareholdingChartData});
}

/// @nodoc
class _$CompanyDashboardModelCopyWithImpl<$Res>
    implements $CompanyDashboardModelCopyWith<$Res> {
  _$CompanyDashboardModelCopyWithImpl(this._value, this._then);

  final CompanyDashboardModel _value;
  // ignore: unused_field
  final $Res Function(CompanyDashboardModel) _then;

  @override
  $Res call({
    Object? statementType = freezed,
    Object? companyStats = freezed,
    Object? quarterlySalesChartData = freezed,
    Object? quarterlyEBITDAChartData = freezed,
    Object? quarterlyPATChartData = freezed,
    Object? annualSalesChartData = freezed,
    Object? annualEBITDAWithMarginChartData = freezed,
    Object? annualPATWithMarginChartData = freezed,
    Object? annualOperatingCashflowChartData = freezed,
    Object? debtChartData = freezed,
    Object? equityChartData = freezed,
    Object? pledgedShareholdingChartData = freezed,
    Object? promoterShareholdingChartData = freezed,
  }) {
    return _then(_value.copyWith(
      statementType: statementType == freezed
          ? _value.statementType
          : statementType // ignore: cast_nullable_to_non_nullable
              as CompanyReportStatementType,
      companyStats: companyStats == freezed
          ? _value.companyStats
          : companyStats // ignore: cast_nullable_to_non_nullable
              as CompanyStats?,
      quarterlySalesChartData: quarterlySalesChartData == freezed
          ? _value.quarterlySalesChartData
          : quarterlySalesChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      quarterlyEBITDAChartData: quarterlyEBITDAChartData == freezed
          ? _value.quarterlyEBITDAChartData
          : quarterlyEBITDAChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      quarterlyPATChartData: quarterlyPATChartData == freezed
          ? _value.quarterlyPATChartData
          : quarterlyPATChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      annualSalesChartData: annualSalesChartData == freezed
          ? _value.annualSalesChartData
          : annualSalesChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      annualEBITDAWithMarginChartData: annualEBITDAWithMarginChartData ==
              freezed
          ? _value.annualEBITDAWithMarginChartData
          : annualEBITDAWithMarginChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      annualPATWithMarginChartData: annualPATWithMarginChartData == freezed
          ? _value.annualPATWithMarginChartData
          : annualPATWithMarginChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      annualOperatingCashflowChartData: annualOperatingCashflowChartData ==
              freezed
          ? _value.annualOperatingCashflowChartData
          : annualOperatingCashflowChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      debtChartData: debtChartData == freezed
          ? _value.debtChartData
          : debtChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      equityChartData: equityChartData == freezed
          ? _value.equityChartData
          : equityChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      pledgedShareholdingChartData: pledgedShareholdingChartData == freezed
          ? _value.pledgedShareholdingChartData
          : pledgedShareholdingChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      promoterShareholdingChartData: promoterShareholdingChartData == freezed
          ? _value.promoterShareholdingChartData
          : promoterShareholdingChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
    ));
  }
}

/// @nodoc
abstract class _$$_CompanyDashboardModelCopyWith<$Res>
    implements $CompanyDashboardModelCopyWith<$Res> {
  factory _$$_CompanyDashboardModelCopyWith(_$_CompanyDashboardModel value,
          $Res Function(_$_CompanyDashboardModel) then) =
      __$$_CompanyDashboardModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {CompanyReportStatementType statementType,
      CompanyStats? companyStats,
      List<BarChartItemModel>? quarterlySalesChartData,
      List<DualAxisBarChartItemModel>? quarterlyEBITDAChartData,
      List<DualAxisBarChartItemModel>? quarterlyPATChartData,
      List<BarChartItemModel>? annualSalesChartData,
      List<DualAxisBarChartItemModel>? annualEBITDAWithMarginChartData,
      List<DualAxisBarChartItemModel>? annualPATWithMarginChartData,
      List<BarChartItemModel>? annualOperatingCashflowChartData,
      List<BarChartItemModel>? debtChartData,
      List<BarChartItemModel>? equityChartData,
      List<BarChartItemModel>? pledgedShareholdingChartData,
      List<BarChartItemModel>? promoterShareholdingChartData});
}

/// @nodoc
class __$$_CompanyDashboardModelCopyWithImpl<$Res>
    extends _$CompanyDashboardModelCopyWithImpl<$Res>
    implements _$$_CompanyDashboardModelCopyWith<$Res> {
  __$$_CompanyDashboardModelCopyWithImpl(_$_CompanyDashboardModel _value,
      $Res Function(_$_CompanyDashboardModel) _then)
      : super(_value, (v) => _then(v as _$_CompanyDashboardModel));

  @override
  _$_CompanyDashboardModel get _value =>
      super._value as _$_CompanyDashboardModel;

  @override
  $Res call({
    Object? statementType = freezed,
    Object? companyStats = freezed,
    Object? quarterlySalesChartData = freezed,
    Object? quarterlyEBITDAChartData = freezed,
    Object? quarterlyPATChartData = freezed,
    Object? annualSalesChartData = freezed,
    Object? annualEBITDAWithMarginChartData = freezed,
    Object? annualPATWithMarginChartData = freezed,
    Object? annualOperatingCashflowChartData = freezed,
    Object? debtChartData = freezed,
    Object? equityChartData = freezed,
    Object? pledgedShareholdingChartData = freezed,
    Object? promoterShareholdingChartData = freezed,
  }) {
    return _then(_$_CompanyDashboardModel(
      statementType: statementType == freezed
          ? _value.statementType
          : statementType // ignore: cast_nullable_to_non_nullable
              as CompanyReportStatementType,
      companyStats: companyStats == freezed
          ? _value.companyStats
          : companyStats // ignore: cast_nullable_to_non_nullable
              as CompanyStats?,
      quarterlySalesChartData: quarterlySalesChartData == freezed
          ? _value._quarterlySalesChartData
          : quarterlySalesChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      quarterlyEBITDAChartData: quarterlyEBITDAChartData == freezed
          ? _value._quarterlyEBITDAChartData
          : quarterlyEBITDAChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      quarterlyPATChartData: quarterlyPATChartData == freezed
          ? _value._quarterlyPATChartData
          : quarterlyPATChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      annualSalesChartData: annualSalesChartData == freezed
          ? _value._annualSalesChartData
          : annualSalesChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      annualEBITDAWithMarginChartData: annualEBITDAWithMarginChartData ==
              freezed
          ? _value._annualEBITDAWithMarginChartData
          : annualEBITDAWithMarginChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      annualPATWithMarginChartData: annualPATWithMarginChartData == freezed
          ? _value._annualPATWithMarginChartData
          : annualPATWithMarginChartData // ignore: cast_nullable_to_non_nullable
              as List<DualAxisBarChartItemModel>?,
      annualOperatingCashflowChartData: annualOperatingCashflowChartData ==
              freezed
          ? _value._annualOperatingCashflowChartData
          : annualOperatingCashflowChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      debtChartData: debtChartData == freezed
          ? _value._debtChartData
          : debtChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      equityChartData: equityChartData == freezed
          ? _value._equityChartData
          : equityChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      pledgedShareholdingChartData: pledgedShareholdingChartData == freezed
          ? _value._pledgedShareholdingChartData
          : pledgedShareholdingChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
      promoterShareholdingChartData: promoterShareholdingChartData == freezed
          ? _value._promoterShareholdingChartData
          : promoterShareholdingChartData // ignore: cast_nullable_to_non_nullable
              as List<BarChartItemModel>?,
    ));
  }
}

/// @nodoc

class _$_CompanyDashboardModel implements _CompanyDashboardModel {
  _$_CompanyDashboardModel(
      {required this.statementType,
      this.companyStats,
      final List<BarChartItemModel>? quarterlySalesChartData,
      final List<DualAxisBarChartItemModel>? quarterlyEBITDAChartData,
      final List<DualAxisBarChartItemModel>? quarterlyPATChartData,
      final List<BarChartItemModel>? annualSalesChartData,
      final List<DualAxisBarChartItemModel>? annualEBITDAWithMarginChartData,
      final List<DualAxisBarChartItemModel>? annualPATWithMarginChartData,
      final List<BarChartItemModel>? annualOperatingCashflowChartData,
      final List<BarChartItemModel>? debtChartData,
      final List<BarChartItemModel>? equityChartData,
      final List<BarChartItemModel>? pledgedShareholdingChartData,
      final List<BarChartItemModel>? promoterShareholdingChartData})
      : _quarterlySalesChartData = quarterlySalesChartData,
        _quarterlyEBITDAChartData = quarterlyEBITDAChartData,
        _quarterlyPATChartData = quarterlyPATChartData,
        _annualSalesChartData = annualSalesChartData,
        _annualEBITDAWithMarginChartData = annualEBITDAWithMarginChartData,
        _annualPATWithMarginChartData = annualPATWithMarginChartData,
        _annualOperatingCashflowChartData = annualOperatingCashflowChartData,
        _debtChartData = debtChartData,
        _equityChartData = equityChartData,
        _pledgedShareholdingChartData = pledgedShareholdingChartData,
        _promoterShareholdingChartData = promoterShareholdingChartData;

  @override
  final CompanyReportStatementType statementType;
  @override
  final CompanyStats? companyStats;
  final List<BarChartItemModel>? _quarterlySalesChartData;
  @override
  List<BarChartItemModel>? get quarterlySalesChartData {
    final value = _quarterlySalesChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<DualAxisBarChartItemModel>? _quarterlyEBITDAChartData;
  @override
  List<DualAxisBarChartItemModel>? get quarterlyEBITDAChartData {
    final value = _quarterlyEBITDAChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<DualAxisBarChartItemModel>? _quarterlyPATChartData;
  @override
  List<DualAxisBarChartItemModel>? get quarterlyPATChartData {
    final value = _quarterlyPATChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<BarChartItemModel>? _annualSalesChartData;
  @override
  List<BarChartItemModel>? get annualSalesChartData {
    final value = _annualSalesChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<DualAxisBarChartItemModel>? _annualEBITDAWithMarginChartData;
  @override
  List<DualAxisBarChartItemModel>? get annualEBITDAWithMarginChartData {
    final value = _annualEBITDAWithMarginChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<DualAxisBarChartItemModel>? _annualPATWithMarginChartData;
  @override
  List<DualAxisBarChartItemModel>? get annualPATWithMarginChartData {
    final value = _annualPATWithMarginChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<BarChartItemModel>? _annualOperatingCashflowChartData;
  @override
  List<BarChartItemModel>? get annualOperatingCashflowChartData {
    final value = _annualOperatingCashflowChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<BarChartItemModel>? _debtChartData;
  @override
  List<BarChartItemModel>? get debtChartData {
    final value = _debtChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<BarChartItemModel>? _equityChartData;
  @override
  List<BarChartItemModel>? get equityChartData {
    final value = _equityChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<BarChartItemModel>? _pledgedShareholdingChartData;
  @override
  List<BarChartItemModel>? get pledgedShareholdingChartData {
    final value = _pledgedShareholdingChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<BarChartItemModel>? _promoterShareholdingChartData;
  @override
  List<BarChartItemModel>? get promoterShareholdingChartData {
    final value = _promoterShareholdingChartData;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'CompanyDashboardModel(statementType: $statementType, companyStats: $companyStats, quarterlySalesChartData: $quarterlySalesChartData, quarterlyEBITDAChartData: $quarterlyEBITDAChartData, quarterlyPATChartData: $quarterlyPATChartData, annualSalesChartData: $annualSalesChartData, annualEBITDAWithMarginChartData: $annualEBITDAWithMarginChartData, annualPATWithMarginChartData: $annualPATWithMarginChartData, annualOperatingCashflowChartData: $annualOperatingCashflowChartData, debtChartData: $debtChartData, equityChartData: $equityChartData, pledgedShareholdingChartData: $pledgedShareholdingChartData, promoterShareholdingChartData: $promoterShareholdingChartData)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompanyDashboardModel &&
            const DeepCollectionEquality()
                .equals(other.statementType, statementType) &&
            const DeepCollectionEquality()
                .equals(other.companyStats, companyStats) &&
            const DeepCollectionEquality().equals(
                other._quarterlySalesChartData, _quarterlySalesChartData) &&
            const DeepCollectionEquality().equals(
                other._quarterlyEBITDAChartData, _quarterlyEBITDAChartData) &&
            const DeepCollectionEquality()
                .equals(other._quarterlyPATChartData, _quarterlyPATChartData) &&
            const DeepCollectionEquality()
                .equals(other._annualSalesChartData, _annualSalesChartData) &&
            const DeepCollectionEquality().equals(
                other._annualEBITDAWithMarginChartData,
                _annualEBITDAWithMarginChartData) &&
            const DeepCollectionEquality().equals(
                other._annualPATWithMarginChartData,
                _annualPATWithMarginChartData) &&
            const DeepCollectionEquality().equals(
                other._annualOperatingCashflowChartData,
                _annualOperatingCashflowChartData) &&
            const DeepCollectionEquality()
                .equals(other._debtChartData, _debtChartData) &&
            const DeepCollectionEquality()
                .equals(other._equityChartData, _equityChartData) &&
            const DeepCollectionEquality().equals(
                other._pledgedShareholdingChartData,
                _pledgedShareholdingChartData) &&
            const DeepCollectionEquality().equals(
                other._promoterShareholdingChartData,
                _promoterShareholdingChartData));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(statementType),
      const DeepCollectionEquality().hash(companyStats),
      const DeepCollectionEquality().hash(_quarterlySalesChartData),
      const DeepCollectionEquality().hash(_quarterlyEBITDAChartData),
      const DeepCollectionEquality().hash(_quarterlyPATChartData),
      const DeepCollectionEquality().hash(_annualSalesChartData),
      const DeepCollectionEquality().hash(_annualEBITDAWithMarginChartData),
      const DeepCollectionEquality().hash(_annualPATWithMarginChartData),
      const DeepCollectionEquality().hash(_annualOperatingCashflowChartData),
      const DeepCollectionEquality().hash(_debtChartData),
      const DeepCollectionEquality().hash(_equityChartData),
      const DeepCollectionEquality().hash(_pledgedShareholdingChartData),
      const DeepCollectionEquality().hash(_promoterShareholdingChartData));

  @JsonKey(ignore: true)
  @override
  _$$_CompanyDashboardModelCopyWith<_$_CompanyDashboardModel> get copyWith =>
      __$$_CompanyDashboardModelCopyWithImpl<_$_CompanyDashboardModel>(
          this, _$identity);
}

abstract class _CompanyDashboardModel implements CompanyDashboardModel {
  factory _CompanyDashboardModel(
      {required final CompanyReportStatementType statementType,
      final CompanyStats? companyStats,
      final List<BarChartItemModel>? quarterlySalesChartData,
      final List<DualAxisBarChartItemModel>? quarterlyEBITDAChartData,
      final List<DualAxisBarChartItemModel>? quarterlyPATChartData,
      final List<BarChartItemModel>? annualSalesChartData,
      final List<DualAxisBarChartItemModel>? annualEBITDAWithMarginChartData,
      final List<DualAxisBarChartItemModel>? annualPATWithMarginChartData,
      final List<BarChartItemModel>? annualOperatingCashflowChartData,
      final List<BarChartItemModel>? debtChartData,
      final List<BarChartItemModel>? equityChartData,
      final List<BarChartItemModel>? pledgedShareholdingChartData,
      final List<BarChartItemModel>?
          promoterShareholdingChartData}) = _$_CompanyDashboardModel;

  @override
  CompanyReportStatementType get statementType =>
      throw _privateConstructorUsedError;
  @override
  CompanyStats? get companyStats => throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get quarterlySalesChartData =>
      throw _privateConstructorUsedError;
  @override
  List<DualAxisBarChartItemModel>? get quarterlyEBITDAChartData =>
      throw _privateConstructorUsedError;
  @override
  List<DualAxisBarChartItemModel>? get quarterlyPATChartData =>
      throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get annualSalesChartData =>
      throw _privateConstructorUsedError;
  @override
  List<DualAxisBarChartItemModel>? get annualEBITDAWithMarginChartData =>
      throw _privateConstructorUsedError;
  @override
  List<DualAxisBarChartItemModel>? get annualPATWithMarginChartData =>
      throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get annualOperatingCashflowChartData =>
      throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get debtChartData =>
      throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get equityChartData =>
      throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get pledgedShareholdingChartData =>
      throw _privateConstructorUsedError;
  @override
  List<BarChartItemModel>? get promoterShareholdingChartData =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_CompanyDashboardModelCopyWith<_$_CompanyDashboardModel> get copyWith =>
      throw _privateConstructorUsedError;
}

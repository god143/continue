import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_item_model.dart';
import 'package:multipie/features/company_dashboard/presentation/models/dual_axis_bar_chart_item_model.dart';
import 'package:multipie/features/market/domain/entities/company/company_stats.dart';
import 'package:multipie/features/market/domain/usecases/get_company_report.dart';

part 'company_dashboard_model.freezed.dart';

@freezed
class CompanyDashboardModel with _$CompanyDashboardModel {
  factory CompanyDashboardModel({
    required CompanyReportStatementType statementType,
    CompanyStats? companyStats,
    List<BarChartItemModel>? quarterlySalesChartData,
    List<DualAxisBarChartItemModel>? quarterlyEBITDAChartData,
    List<DualAxisBarChartItemModel>? quarterlyPATChartData,
    List<BarChartItemModel>? annualSalesChartData,
    List<DualAxisBarChartItemModel>? annualEBITDAWithMarginChartData,
    List<DualAxisBarChartItemModel>? annualPATWithMarginChartData,
    List<BarChartItemModel>? annualOperatingCashflowChartData,
    List<BarChartItemModel>? debtChartData,
    List<BarChartItemModel>? equityChartData,
    List<BarChartItemModel>? pledgedShareholdingChartData,
    List<BarChartItemModel>? promoterShareholdingChartData,
  }) = _CompanyDashboardModel;
}

import 'package:flutter/material.dart';

/// Represents dat of bar rods group of dual axis based bar chart
@immutable
class DualAxisBarChartItemModel {
  const DualAxisBarChartItemModel({
    required this.xTitle,
    required this.primaryYTitle,
    required this.primaryYValue,
    required this.secondaryYTitle,
    required this.secondaryYValue,
  });

  final String xTitle;
  final String primaryYTitle;
  final double primaryYValue;
  final String secondaryYTitle;
  final double secondaryYValue;
}

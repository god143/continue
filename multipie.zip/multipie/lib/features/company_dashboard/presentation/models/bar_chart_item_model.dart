import 'package:flutter/material.dart';

/// Represents individual bar rod data
@immutable
class BarChartItemModel {
  const BarChartItemModel({
    required this.xTitle,
    required this.yTitle,
    required this.yValue,
  });

  final String xTitle;
  final String yTitle;
  final double yValue;
}

import 'package:flutter/material.dart';
import 'package:multipie/features/company_dashboard/presentation/models/bar_chart_item_model.dart';

/// Represents data for the bar chart
@immutable
class BarChartModel {
  final String chartId;
  final String? legendName;
  final List<BarChartItemModel> data;
  final Color barColor;
  final Color? legendColor;

  const BarChartModel({
    required this.chartId,
    required this.data,
    required this.barColor,
    this.legendName,
    this.legendColor,
  });
}

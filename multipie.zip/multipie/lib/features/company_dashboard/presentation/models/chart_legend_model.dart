import 'package:flutter/material.dart';

/// Represents data for the chart legend
@immutable
class ChartLegendModel {
  final String name;
  final Color color;

  const ChartLegendModel({
    required this.name,
    required this.color,
  });
}

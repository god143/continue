import 'package:equatable/equatable.dart';

class BrokerSettings {
  bool transactionsEnabled;
  bool transactionsEnabledMobile;
  TransactionEnabledBrokers transactionEnabledBrokers;
  TransactionEnabledBrokers transactionEnabledMobileBrokers;

  BrokerSettings({
    required this.transactionsEnabled,
    required this.transactionsEnabledMobile,
    required this.transactionEnabledBrokers,
    required this.transactionEnabledMobileBrokers,
  });

  @override
  List<Object> get props => [
        transactionsEnabled,
        transactionsEnabledMobile,
        transactionEnabledBrokers,
        transactionEnabledMobileBrokers,
      ];
}

class TransactionEnabledBrokers {
  bool cams;
  bool upstox;
  bool kotak;
  bool hdfc;
  bool motilal;
  bool axis;
  bool juliusBaer;
  bool isec;
  bool zerodha;
  bool fivePaisa;

  TransactionEnabledBrokers({
    required this.cams,
    required this.upstox,
    required this.kotak,
    required this.hdfc,
    required this.motilal,
    required this.axis,
    required this.juliusBaer,
    required this.isec,
    required this.zerodha,
    required this.fivePaisa,
  });

  @override
  List<Object> get props => [
        cams,
        upstox,
        kotak,
        hdfc,
        motilal,
        axis,
        juliusBaer,
        isec,
        zerodha,
        fivePaisa,
      ];
}

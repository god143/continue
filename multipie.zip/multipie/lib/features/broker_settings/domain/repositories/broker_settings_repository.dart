import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/broker_settings/domain/entities/broker_settings.dart';
import 'package:dartz/dartz.dart';

abstract class BrokerSettingsRepository {
  Future<Either<Failure, BrokerSettings>> getBrokerSettings();
}

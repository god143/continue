import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/broker_settings/domain/entities/broker_settings.dart';
import 'package:multipie/features/broker_settings/domain/repositories/broker_settings_repository.dart';

class GetBrokerSettingsUseCase implements UseCase<BrokerSettings, NoParams> {
  final BrokerSettingsRepository BrokerSettingsRespository;

  GetBrokerSettingsUseCase(this.BrokerSettingsRespository);
  @override
  Future<Either<Failure, BrokerSettings>> call(NoParams params) async {
    return await BrokerSettingsRespository.getBrokerSettings();
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/broker_settings/domain/entities/broker_settings.dart';

@immutable
abstract class BrokerSettingsState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends BrokerSettingsState {}

class Loading extends BrokerSettingsState {}

class HidePopup extends BrokerSettingsState {}

class LoadedBrokerSettings extends BrokerSettingsState {
  final BrokerSettings brokerSetting;
  LoadedBrokerSettings({required this.brokerSetting});

  @override
  List<Object> get props => [brokerSetting];
}

class ReadAnnouncement extends BrokerSettingsState {
  final String success;

  ReadAnnouncement({required this.success});
}

class Error extends BrokerSettingsState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

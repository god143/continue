import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/broker_settings/domain/entities/broker_settings.dart';
import 'package:multipie/features/broker_settings/domain/usecases/get_broker_settings_usecases.dart';
import 'package:multipie/features/broker_settings/presentation/bloc/bloc.dart';

class BrokerSettingsBloc extends Bloc<BrokerSettingsEvent, BrokerSettingsState> {
  final GetBrokerSettingsUseCase getBrokerSettingsUseCase;

  static const String SERVER_FAILURE_MESSAGE = 'SERVER Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  static const String INVALID_INPUT_FAILURE_MESSAGE = 'Invalid Input - The number must be a positive integer or zero.';

  @override
  BrokerSettingsState get initialState => Empty();

  BrokerSettingsBloc({
    required GetBrokerSettingsUseCase getBrokerSettingsUseCase,
  })  : getBrokerSettingsUseCase = getBrokerSettingsUseCase,
        super(Empty());

  @override
  Stream<BrokerSettingsState> mapEventToState(
      BrokerSettingsEvent event,
  ) async* {
    if (event is GetBrokerSettings) {
      yield Loading();
      final failureOrBrokerSettings = await getBrokerSettingsUseCase(NoParams());
      yield* _eitherLoadedOrErrorState(failureOrBrokerSettings);
    }

    if (event is HideAnnoucmentEvent) {
      yield HidePopup();
    }
  }

  Stream<BrokerSettingsState> _eitherLoadedOrErrorState(
    Either<Failure, BrokerSettings> failureOrBrokerSettings,
  ) async* {
    yield failureOrBrokerSettings.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (BrokerSettings) => LoadedBrokerSettings(brokerSetting: BrokerSettings),
    );
  }

  Stream<BrokerSettingsState> _eitherLoadedOrReadErrorState(
    Either<Failure, MessageResponseModel> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) {
        return Error(message: _mapFailureToMessage(failure));
      },
      (data) {
        return ReadAnnouncement(success: data.message);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

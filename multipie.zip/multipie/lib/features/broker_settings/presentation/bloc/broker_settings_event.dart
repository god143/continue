import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class BrokerSettingsEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetBrokerSettings extends BrokerSettingsEvent {}

class PostReadAnnouncement extends BrokerSettingsEvent {
  final String readId;

  PostReadAnnouncement(this.readId);

  @override
  List<Object> get props => [readId];
}

class HideAnnoucmentEvent extends BrokerSettingsEvent {}

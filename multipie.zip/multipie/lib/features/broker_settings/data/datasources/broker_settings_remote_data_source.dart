import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/broker_settings/data/models/broker_settings_model.dart';
import 'package:multipie/services/network_service.dart';
import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';

abstract class BrokerSettingsRemoteDataSource {
  Future<BrokerSettingsModel> getBrokerSettings();
}

class BrokerSettingsRemoteDataSourceImpl implements BrokerSettingsRemoteDataSource {
  final NetworkService networkService;

  BrokerSettingsRemoteDataSourceImpl({required this.networkService});

  @override
  Future<BrokerSettingsModel> getBrokerSettings() => getBrokerSettingsFromService('/my_settings');

  Future<BrokerSettingsModel> getBrokerSettingsFromService(
    String url,
  ) async {
    final jsonApi = await networkService.getRequest(url);

    try {
      BrokerSettingsModel responseModel = BrokerSettingsModel.fromJson(jsonApi);
      return responseModel;
    } catch (e) {
      print(e.toString());
      throw ServerException('Failed to get posts from data');
    }
  }
}

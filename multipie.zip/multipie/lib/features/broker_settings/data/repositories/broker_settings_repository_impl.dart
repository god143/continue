import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/broker_settings/data/datasources/broker_settings_remote_data_source.dart';
import 'package:multipie/features/broker_settings/domain/entities/broker_settings.dart';
import 'package:multipie/features/broker_settings/domain/repositories/broker_settings_repository.dart';

class BrokerSettingsRepositoryImpl implements BrokerSettingsRepository {
  final NetworkInfo networkInfo;
  final BrokerSettingsRemoteDataSource remoteDataSource;

  BrokerSettingsRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, BrokerSettings>> getBrokerSettings() async {
    return await _getBrokerSettingsFromServer();
  }

  Future<Either<Failure, BrokerSettings>> _getBrokerSettingsFromServer() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getBrokerSettings();
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

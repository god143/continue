import 'package:multipie/features/broker_settings/domain/entities/broker_settings.dart';

class BrokerSettingsModel extends BrokerSettings {
  BrokerSettingsModel({
    required transactionsEnabled,
    required transactionsEnabledMobile,
    required transactionEnabledBrokers,
    required transactionEnabledMobileBrokers,
  }) : super(
    transactionsEnabled: transactionsEnabled,
    transactionsEnabledMobile: transactionsEnabledMobile,
    transactionEnabledBrokers: transactionEnabledBrokers,
    transactionEnabledMobileBrokers: transactionEnabledMobileBrokers,
        );

  factory BrokerSettingsModel.fromJson(Map<String, dynamic> json) {
    return BrokerSettingsModel(
      transactionsEnabled: json['transactions_enabled'],
      transactionsEnabledMobile: json['transactions_enabled_mobile'],
      transactionEnabledBrokers: TransactionEnabledBrokersModel.fromJson(json['transaction_enabled_brokers']),
        transactionEnabledMobileBrokers: TransactionEnabledBrokersModel.fromJson(json['transaction_enabled_mobile_brokers']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'transactions_enabled': transactionsEnabledMobile,
      'transactions_enabled_mobile': transactionsEnabledMobile,
      'transaction_enabled_brokers': transactionEnabledBrokers,
      'transaction_enabled_mobile_brokers': transactionEnabledMobileBrokers,
    };
  }
}

class TransactionEnabledBrokersModel extends TransactionEnabledBrokers {
  TransactionEnabledBrokersModel({
    required cams,
    required upstox,
    required kotak,
    required hdfc,
    required motilal,
    required axis,
    required juliusBaer,
    required isec,
    required zerodha,
    required fivePaisa,
  }) : super(
    cams: cams,
    upstox: upstox,
    kotak: kotak,
    hdfc: hdfc,
    motilal: motilal,
    axis: axis,
    juliusBaer: juliusBaer,
    isec: isec,
    zerodha: zerodha,
    fivePaisa: fivePaisa,
  );

  factory TransactionEnabledBrokersModel.fromJson(Map<String, dynamic> json) {
    return TransactionEnabledBrokersModel(
      cams: json['cams'],
      upstox: json['upstox'],
      kotak: json['kotak'],
      hdfc: json['hdfc'],
      motilal: json['motilal'],
      axis: json['axis'],
      juliusBaer: json['julius_baer'],
      isec: json['isec'],
      zerodha: json['zerodha'],
      fivePaisa: json['five_paisa'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cams': cams,
      'upstox': upstox,
      'kotak': kotak,
      'hdfc': hdfc,
      'motilal': motilal,
      'axis': axis,
      'julius_baer': juliusBaer,
      'isec': isec,
      'zerodha': zerodha,
      'five_paisa': fivePaisa,
    };
  }
}

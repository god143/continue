import 'dart:async';
import 'dart:convert';

import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/core/utils/server_info.dart';
import 'package:multipie/locator.dart';
import 'package:multipie/services/auth_token_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ContactsUploadManager {
  const ContactsUploadManager({
    required this.authTokenService,
  });

  static const _CONTACTS_BATCH_SIZE = 100;
  static const _CONTACTS_CONCURRENCY = 5;

  final AuthTokenService authTokenService;

  // Reads contacts, then upload them to server
  Future<void> syncContacts({
    // Called when first concurrent batches group is uploaded
    VoidCallback? onFirstConcurrentBatchUploaded,
    // Called when all data uploaded
    VoidCallback? onCompletion,
  }) async {
    // PART: 1 - Read contacts & Prepare data to be uploaded.
    final Iterable<Contact> contacts = await ContactsService.getContacts(
      withThumbnails: false,
      photoHighResolution: false,
    );

    List data = [];
    for (Contact contact in contacts) {
      List mobileList = [];

      contact.phones!.map((e) {
        var formattedMobile = e.value!.replaceAll(new RegExp(r'[^0-9]'), '');

        //Ignore country code by taking only last 10 digits
        formattedMobile =
            formattedMobile.length >= 10 ? formattedMobile.substring(formattedMobile.length - 10) : formattedMobile;

        //Create mobile number list object
        final mobileObj = {
          'field_type': 'mobile',
          'field_label': nullReview(e.label),
          'field_value': nullReview(formattedMobile),
        };
        var existingItem = mobileList.firstWhere((i) => i['field_value'] == formattedMobile, orElse: () => null);
        if (existingItem == null) mobileList.add(mobileObj);
      }).toList();

      //Create email list object
      contact.emails!.map((e) {
        final emailObj = {
          'field_type': 'email',
          'field_label': nullReview(e.label),
          'field_value': nullReview(e.value),
        };
        var existingItem = mobileList.firstWhere((i) => i['field_value'] == e.value, orElse: () => null);
        if (existingItem == null) mobileList.add(emailObj);
      }).toList();

      //Create final object to send in API
      final Map<String, dynamic> jsonData = new Map<String, dynamic>();
      jsonData['display_name'] = contact.displayName;
      jsonData['nick_name'] = contact.givenName;
      if (contact.phones != null || contact.emails != null) {
        jsonData['contact_entries'] = mobileList;
      }

      //Bulk contacts to share
      data.add(jsonData);
    }

    // PART: 2 - Upload data to server
    final token = await authTokenService.getAuthToken();
    final authToken = 'Bearer $token';

    if (data.isEmpty) {
      onCompletion?.call();
      return;
    }

    CleverTapPlugin.recordEvent('Contact Upload Initiated', {});

    // Split Contacts into batch of `_CONTACTS_BATCH_SIZE`
    final chunkedContacts = data.partition(_CONTACTS_BATCH_SIZE);

    // Further split to make `_CONTACTS_CONCURRENCY` concurrent uploads with each of `_CONTACTS_BATCH_SIZE`
    final concurrentUploadChunks = chunkedContacts.partition(_CONTACTS_CONCURRENCY);
    for (int i = 0; i < concurrentUploadChunks.length; i++) {
      final chunks = concurrentUploadChunks[i];
      await Future.wait(
        chunks.map(
          (e) => _uploadContacts(
            data: e,
            authToken: authToken,
          ),
        ),
      );
      if (i == 0) {
        onFirstConcurrentBatchUploaded?.call();
      }
    }

    CleverTapPlugin.recordEvent('Contact Upload Completed', {});
    onCompletion?.call();
  }

  Future<Either<Object, bool>> _uploadContacts({
    required List data,
    required String authToken,
  }) async {
    final dio = locator<Dio>();
    try {
      var response = await dio.post(
        ServerInfo.baseUrl + "/contacts/bulk_upload",
        data: json.encode({'contacts': data}),
        options: Options(
          headers: {
            'Content-Type': 'application/json; charset=UTF-8',
            'Accept': '*/*',
            'Authorization': authToken,
          },
        ),
      );
      if (response.statusCode == 200) {
        return right(true);
      } else {
        return left(Exception('Could not upload contact!'));
      }
    } catch (e) {
      print(e);
      return left(e);
    }
  }
}

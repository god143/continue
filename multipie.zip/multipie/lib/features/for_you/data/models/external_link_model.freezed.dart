// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'external_link_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ExternalLinkModel _$ExternalLinkModelFromJson(Map<String, dynamic> json) {
  return _ExternalLinkModel.fromJson(json);
}

/// @nodoc
mixin _$ExternalLinkModel {
  String get id => throw _privateConstructorUsedError;
  String get title => throw _privateConstructorUsedError;
  String? get bannerImageUrl => throw _privateConstructorUsedError;
  String? get redirectUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ExternalLinkModelCopyWith<ExternalLinkModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ExternalLinkModelCopyWith<$Res> {
  factory $ExternalLinkModelCopyWith(
          ExternalLinkModel value, $Res Function(ExternalLinkModel) then) =
      _$ExternalLinkModelCopyWithImpl<$Res>;
  $Res call(
      {String id, String title, String? bannerImageUrl, String? redirectUrl});
}

/// @nodoc
class _$ExternalLinkModelCopyWithImpl<$Res>
    implements $ExternalLinkModelCopyWith<$Res> {
  _$ExternalLinkModelCopyWithImpl(this._value, this._then);

  final ExternalLinkModel _value;
  // ignore: unused_field
  final $Res Function(ExternalLinkModel) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? title = freezed,
    Object? bannerImageUrl = freezed,
    Object? redirectUrl = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: title == freezed
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      bannerImageUrl: bannerImageUrl == freezed
          ? _value.bannerImageUrl
          : bannerImageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      redirectUrl: redirectUrl == freezed
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
abstract class _$$_ExternalLinkModelCopyWith<$Res>
    implements $ExternalLinkModelCopyWith<$Res> {
  factory _$$_ExternalLinkModelCopyWith(_$_ExternalLinkModel value,
          $Res Function(_$_ExternalLinkModel) then) =
      __$$_ExternalLinkModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {String id, String title, String? bannerImageUrl, String? redirectUrl});
}

/// @nodoc
class __$$_ExternalLinkModelCopyWithImpl<$Res>
    extends _$ExternalLinkModelCopyWithImpl<$Res>
    implements _$$_ExternalLinkModelCopyWith<$Res> {
  __$$_ExternalLinkModelCopyWithImpl(
      _$_ExternalLinkModel _value, $Res Function(_$_ExternalLinkModel) _then)
      : super(_value, (v) => _then(v as _$_ExternalLinkModel));

  @override
  _$_ExternalLinkModel get _value => super._value as _$_ExternalLinkModel;

  @override
  $Res call({
    Object? id = freezed,
    Object? title = freezed,
    Object? bannerImageUrl = freezed,
    Object? redirectUrl = freezed,
  }) {
    return _then(_$_ExternalLinkModel(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: title == freezed
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      bannerImageUrl: bannerImageUrl == freezed
          ? _value.bannerImageUrl
          : bannerImageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      redirectUrl: redirectUrl == freezed
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ExternalLinkModel implements _ExternalLinkModel {
  _$_ExternalLinkModel(
      {required this.id,
      required this.title,
      this.bannerImageUrl,
      this.redirectUrl});

  factory _$_ExternalLinkModel.fromJson(Map<String, dynamic> json) =>
      _$$_ExternalLinkModelFromJson(json);

  @override
  final String id;
  @override
  final String title;
  @override
  final String? bannerImageUrl;
  @override
  final String? redirectUrl;

  @override
  String toString() {
    return 'ExternalLinkModel(id: $id, title: $title, bannerImageUrl: $bannerImageUrl, redirectUrl: $redirectUrl)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ExternalLinkModel &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.title, title) &&
            const DeepCollectionEquality()
                .equals(other.bannerImageUrl, bannerImageUrl) &&
            const DeepCollectionEquality()
                .equals(other.redirectUrl, redirectUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(title),
      const DeepCollectionEquality().hash(bannerImageUrl),
      const DeepCollectionEquality().hash(redirectUrl));

  @JsonKey(ignore: true)
  @override
  _$$_ExternalLinkModelCopyWith<_$_ExternalLinkModel> get copyWith =>
      __$$_ExternalLinkModelCopyWithImpl<_$_ExternalLinkModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ExternalLinkModelToJson(this);
  }
}

abstract class _ExternalLinkModel implements ExternalLinkModel {
  factory _ExternalLinkModel(
      {required final String id,
      required final String title,
      final String? bannerImageUrl,
      final String? redirectUrl}) = _$_ExternalLinkModel;

  factory _ExternalLinkModel.fromJson(Map<String, dynamic> json) =
      _$_ExternalLinkModel.fromJson;

  @override
  String get id => throw _privateConstructorUsedError;
  @override
  String get title => throw _privateConstructorUsedError;
  @override
  String? get bannerImageUrl => throw _privateConstructorUsedError;
  @override
  String? get redirectUrl => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ExternalLinkModelCopyWith<_$_ExternalLinkModel> get copyWith =>
      throw _privateConstructorUsedError;
}

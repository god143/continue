// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'external_link_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ExternalLinkModel _$$_ExternalLinkModelFromJson(Map<String, dynamic> json) =>
    _$_ExternalLinkModel(
      id: json['id'] as String,
      title: json['title'] as String,
      bannerImageUrl: json['banner_image_url'] as String?,
      redirectUrl: json['redirect_url'] as String?,
    );

Map<String, dynamic> _$$_ExternalLinkModelToJson(
        _$_ExternalLinkModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
      'banner_image_url': instance.bannerImageUrl,
      'redirect_url': instance.redirectUrl,
    };

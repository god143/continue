import 'package:freezed_annotation/freezed_annotation.dart';

part 'external_link_model.freezed.dart';
part 'external_link_model.g.dart';

@freezed
class ExternalLinkModel with _$ExternalLinkModel {
  factory ExternalLinkModel({
    required String id,
    required String title,
    String? bannerImageUrl,
    String? redirectUrl,
  }) = _ExternalLinkModel;

  factory ExternalLinkModel.fromJson(Map<String, dynamic> json) => _$ExternalLinkModelFromJson(json);
}

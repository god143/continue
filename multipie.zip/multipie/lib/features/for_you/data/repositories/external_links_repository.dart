import 'package:dartz/dartz.dart';
import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/for_you/data/models/external_link_model.dart';
import 'package:multipie/services/network_service.dart';

class ExternalLinksRepository {
  final NetworkInfo networkInfo;
  final NetworkService networkService;

  ExternalLinksRepository({
    required this.networkInfo,
    required this.networkService,
  });

  Future<Either<Failure, List<ExternalLinkModel>>> getExternalLinks() async {
    if (await networkInfo.isConnected) {
      try {
        final jsonApi = await networkService.getRequest("/external_links");
        try {
          Map<String, dynamic> json = Japx.decode(jsonApi);
          Iterable data = json['data'];
          final links = data.map((e) => ExternalLinkModel.fromJson(e)).toList();
          return Right(links);
        } catch (e) {
          throw ServerException('Failed to get data');
        }
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/for_you/data/datasources/people_remote_datasource.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

class PeopleRepository {
  final NetworkInfo networkInfo;
  final PeopleRemoteDataSource remoteDataSource;

  PeopleRepository({
    required this.networkInfo,
    required this.remoteDataSource,
  });

  Future<Either<Failure, List<UserModel>>> getLeaders({
    required String period,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getLeaders(period: period);
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, List<UserModel>>> getCelebrities({
    required int page,
    required int pageSize,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getCelebrities(page: page, pageSize: pageSize);
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, List<UserModel>>> getTopContributers({
    required int page,
    required int pageSize,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getTopContributers(page: page, pageSize: pageSize);
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

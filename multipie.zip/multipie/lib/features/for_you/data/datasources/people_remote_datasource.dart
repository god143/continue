import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/services/network_service.dart';

class PeopleRemoteDataSource {
  final NetworkService networkService;

  const PeopleRemoteDataSource({
    required this.networkService,
  });

  Future<List<UserModel>> getLeaders({
    required String period,
  }) async {
    final jsonApi = await networkService.getRequest("/leaders?period=$period");
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((e) => UserModel.fromJson(e)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  Future<List<UserModel>> getCelebrities({
    required int page,
    required int pageSize,
  }) async {
    final jsonApi = await networkService.getRequest('/celebrity_investors?page_size=$pageSize&page=$page');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((e) => UserModel.fromJson(e)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  Future<List<UserModel>> getTopContributers({
    required int page,
    required int pageSize,
  }) async {
    final jsonApi =
        await networkService.getRequest('/multicelebs?page_size=$pageSize&page=$page&sort_by=top_coin_holders');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((e) => UserModel.fromJson(e)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }
}

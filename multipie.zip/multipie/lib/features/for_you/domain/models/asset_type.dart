enum AssetType { stock, mutualFund }

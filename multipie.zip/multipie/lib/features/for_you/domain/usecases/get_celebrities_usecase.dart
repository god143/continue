import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/for_you/data/repositories/people_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class GetCelebritiesUsecase extends UseCase<List<User>, GetCelebritiesParams> {
  final PeopleRepository repository;

  GetCelebritiesUsecase(this.repository);

  @override
  Future<Either<Failure, List<User>>> call(GetCelebritiesParams params) {
    return repository.getCelebrities(page: params.page, pageSize: params.pageSize);
  }
}

class GetCelebritiesParams {
  final int page;
  final int pageSize;

  GetCelebritiesParams({
    required this.page,
    required this.pageSize,
  });
}

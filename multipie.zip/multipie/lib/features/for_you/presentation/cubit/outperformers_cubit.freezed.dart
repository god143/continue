// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'outperformers_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$OutperformersState {
  bool get isLoading => throw _privateConstructorUsedError;
  List<User> get people => throw _privateConstructorUsedError;
  String get period => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OutperformersStateCopyWith<OutperformersState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OutperformersStateCopyWith<$Res> {
  factory $OutperformersStateCopyWith(
          OutperformersState value, $Res Function(OutperformersState) then) =
      _$OutperformersStateCopyWithImpl<$Res>;
  $Res call({bool isLoading, List<User> people, String period});
}

/// @nodoc
class _$OutperformersStateCopyWithImpl<$Res>
    implements $OutperformersStateCopyWith<$Res> {
  _$OutperformersStateCopyWithImpl(this._value, this._then);

  final OutperformersState _value;
  // ignore: unused_field
  final $Res Function(OutperformersState) _then;

  @override
  $Res call({
    Object? isLoading = freezed,
    Object? people = freezed,
    Object? period = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: isLoading == freezed
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      people: people == freezed
          ? _value.people
          : people // ignore: cast_nullable_to_non_nullable
              as List<User>,
      period: period == freezed
          ? _value.period
          : period // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_OutperformersStateCopyWith<$Res>
    implements $OutperformersStateCopyWith<$Res> {
  factory _$$_OutperformersStateCopyWith(_$_OutperformersState value,
          $Res Function(_$_OutperformersState) then) =
      __$$_OutperformersStateCopyWithImpl<$Res>;
  @override
  $Res call({bool isLoading, List<User> people, String period});
}

/// @nodoc
class __$$_OutperformersStateCopyWithImpl<$Res>
    extends _$OutperformersStateCopyWithImpl<$Res>
    implements _$$_OutperformersStateCopyWith<$Res> {
  __$$_OutperformersStateCopyWithImpl(
      _$_OutperformersState _value, $Res Function(_$_OutperformersState) _then)
      : super(_value, (v) => _then(v as _$_OutperformersState));

  @override
  _$_OutperformersState get _value => super._value as _$_OutperformersState;

  @override
  $Res call({
    Object? isLoading = freezed,
    Object? people = freezed,
    Object? period = freezed,
  }) {
    return _then(_$_OutperformersState(
      isLoading: isLoading == freezed
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      people: people == freezed
          ? _value._people
          : people // ignore: cast_nullable_to_non_nullable
              as List<User>,
      period: period == freezed
          ? _value.period
          : period // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_OutperformersState implements _OutperformersState {
  _$_OutperformersState(
      {this.isLoading = false,
      final List<User> people = const [],
      required this.period})
      : _people = people;

  @override
  @JsonKey()
  final bool isLoading;
  final List<User> _people;
  @override
  @JsonKey()
  List<User> get people {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_people);
  }

  @override
  final String period;

  @override
  String toString() {
    return 'OutperformersState(isLoading: $isLoading, people: $people, period: $period)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_OutperformersState &&
            const DeepCollectionEquality().equals(other.isLoading, isLoading) &&
            const DeepCollectionEquality().equals(other._people, _people) &&
            const DeepCollectionEquality().equals(other.period, period));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(isLoading),
      const DeepCollectionEquality().hash(_people),
      const DeepCollectionEquality().hash(period));

  @JsonKey(ignore: true)
  @override
  _$$_OutperformersStateCopyWith<_$_OutperformersState> get copyWith =>
      __$$_OutperformersStateCopyWithImpl<_$_OutperformersState>(
          this, _$identity);
}

abstract class _OutperformersState implements OutperformersState {
  factory _OutperformersState(
      {final bool isLoading,
      final List<User> people,
      required final String period}) = _$_OutperformersState;

  @override
  bool get isLoading => throw _privateConstructorUsedError;
  @override
  List<User> get people => throw _privateConstructorUsedError;
  @override
  String get period => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_OutperformersStateCopyWith<_$_OutperformersState> get copyWith =>
      throw _privateConstructorUsedError;
}

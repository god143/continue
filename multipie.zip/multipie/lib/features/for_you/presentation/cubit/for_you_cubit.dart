import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/for_you/data/models/external_link_model.dart';
import 'package:multipie/features/for_you/data/repositories/external_links_repository.dart';
import 'package:multipie/features/for_you/domain/models/asset_type.dart';
import 'package:multipie/features/for_you/domain/usecases/get_celebrities_usecase.dart';
import 'package:multipie/features/market/data/models/company/company_news_model.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';
import 'package:multipie/features/market/domain/usecases/get_company_follow_suggestions.dart';
import 'package:multipie/features/market/domain/usecases/get_company_news_list.dart' as news_list_usecase;
import 'package:multipie/features/market/domain/usecases/get_top_held_mutual_funds.dart';
import 'package:multipie/features/market_indexes/domain/entities/market_index.dart';
import 'package:multipie/features/market_indexes/domain/usecases/get_market_usecases.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

part 'for_you_cubit.freezed.dart';
part 'for_you_state.dart';

class ForYouCubit extends Cubit<ForYouState> {
  ForYouCubit({
    required this.getCompaniesUsecase,
    required this.getTopHeldMutualFundsUsecase,
    required this.getMarketIndexUseCase,
    required this.getCompanyNewsListUseCase,
    required this.getCelebritiesUsecase,
    required this.externalLinksRepository,
  }) : super(ForYouState());

  final GetCompanyFollowSuggestions getCompaniesUsecase;
  final GetTopHeldMutualFundsUseCase getTopHeldMutualFundsUsecase;
  final GetMarketIndexUseCase getMarketIndexUseCase;
  final news_list_usecase.GetCompanyNewsListUseCase getCompanyNewsListUseCase;
  final GetCelebritiesUsecase getCelebritiesUsecase;
  final ExternalLinksRepository externalLinksRepository;

  final _mostTalkedStocksCount = 10;
  final _topHeldStocksCount = 50;
  final _topHeldMFsCount = 50;
  final _topMoverStocksCount = 3;
  final _mostWatchedStocksCount = 3;
  final _mostBoughtStocksCount = 5;
  final _mostSoldStocksCount = 5;
  final _newsCount = 10;

  final _mostWatchedDurations = ['5d', '1m'];
  final _mostBoughtDurations = ['1d', '5d', '1m'];
  final _mostSoldDurations = ['1d', '5d', '1m'];
  final _topMoverStocksDurations = ['1d', '5d', '1m'];

  Future<void> refresh() async {
    await Future.wait([
      _getMostTalkedStocks(),
      _getTopHeldStocks(),
      _getTopHeldMFs(),
      getTopMoverStocks(),
      _getMostWatchedStocks(),
      _getMostBoughtStocks(),
      _getMostSoldStocks(),
      _getCelebrities(),
      _getMarketIndices(),
      _getExternalLinks(),
      _getNews(),
    ]);
  }

  Future<void> _getMostTalkedStocks() async {
    emit(state.copyWith(isLoadingMostTalkedStocks: true));
    final result = await getCompaniesUsecase.call(
      Params(
        sortBy: 'top_talked',
        pageSize: _mostTalkedStocksCount,
      ),
    );
    final newState = state.copyWith(
      isLoadingMostTalkedStocks: false,
      mostTalkedStocks: result.fold((ex) => [], (stocks) => stocks),
    );
    emit(newState);
  }

  Future<void> _getTopHeldStocks() async {
    emit(state.copyWith(isLoadingTopHeldStocks: true));
    final result = await getCompaniesUsecase.call(
      Params(
        sortBy: 'top_held',
        pageSize: _topHeldStocksCount,
      ),
    );
    final newState = state.copyWith(
      isLoadingTopHeldStocks: false,
      topHeldStocks: result.fold((ex) => [], (stocks) => stocks),
    );
    emit(newState);
  }

  Future<void> _getTopHeldMFs() async {
    emit(state.copyWith(isLoadingTopHeldMFs: true));
    final result = await getTopHeldMutualFundsUsecase.call(
      MutualFundsParams(
        sortBy: 'top_held',
        count: _topHeldMFsCount,
      ),
    );
    final newState = state.copyWith(
      isLoadingTopHeldMFs: false,
      topHeldMFs: result.fold((ex) => [], (funds) => funds),
    );
    emit(newState);
  }

  Future<void> getTopMoverStocks() async {
    emit(state.copyWith(isLoadingTopMoverStocks: true));
    final result = await getCompaniesUsecase.call(
      Params(
        sortBy: 'top_mover',
        pageSize: _topMoverStocksCount,
        exchange: 'NSE',
        periodToConsider: state.topMoverStocksPeriod,
      ),
    );
    final newState = state.copyWith(
      isLoadingTopMoverStocks: false,
      topMoverStocks: result.fold((ex) => [], (stocks) => stocks),
    );
    emit(newState);
  }

  Future<void> _getMostWatchedStocks() async {
    emit(state.copyWith(isLoadingMostWatchedStocks: true));
    final result = await getCompaniesUsecase.call(
      Params(
        sortBy: 'most_watched',
        pageSize: _mostWatchedStocksCount,
        periodToConsider: state.mostWatchedStocksPeriod,
      ),
    );
    final newState = state.copyWith(
      isLoadingMostWatchedStocks: false,
      mostWatchedStocks: result.fold((ex) => [], (stocks) => stocks),
    );
    emit(newState);
  }

  Future<void> _getMostBoughtStocks() async {
    emit(state.copyWith(isLoadingMostBoughtStocks: true));
    final result = await getCompaniesUsecase.call(
      Params(
        sortBy: 'most_bought',
        pageSize: _mostBoughtStocksCount,
        periodToConsider: state.mostBoughtStocksPeriod,
      ),
    );
    final newState = state.copyWith(
      isLoadingMostBoughtStocks: false,
      mostBoughtStocks: result.fold((ex) => [], (stocks) => stocks),
    );
    emit(newState);
  }

  Future<void> _getMostSoldStocks() async {
    emit(state.copyWith(isLoadingMostSoldStocks: true));
    final result = await getCompaniesUsecase.call(
      Params(
        sortBy: 'most_sold',
        pageSize: _mostSoldStocksCount,
        periodToConsider: state.mostSoldStocksPeriod,
      ),
    );
    final newState = state.copyWith(
      isLoadingMostSoldStocks: false,
      mostSoldStocks: result.fold((ex) => [], (stocks) => stocks),
    );
    emit(newState);
  }

  Future<void> _getMarketIndices() async {
    emit(state.copyWith(isLoadingMarketIndices: true));
    final result = await getMarketIndexUseCase.call(NoParams());
    final newState = state.copyWith(
      isLoadingMarketIndices: false,
      marketIndices: result.fold((ex) => [], (indices) => indices),
    );
    emit(newState);
  }

  Future<void> _getNews() async {
    emit(state.copyWith(isLoadingNews: true));
    final result = await getCompanyNewsListUseCase.call(
      news_list_usecase.Params(id: ''),
    );
    final newState = state.copyWith(
      isLoadingNews: false,
      news: result.fold((ex) => [], (model) => (model.news ?? []).take(_newsCount).toList(growable: false)),
    );
    emit(newState);
  }

  Future<void> _getExternalLinks() async {
    final result = await externalLinksRepository.getExternalLinks();
    final newState = state.copyWith(
      externalLinks: result.fold(
        (ex) => [],
        (links) => links,
      ),
    );
    emit(newState);
  }

  Future<void> _getCelebrities() async {
    emit(state.copyWith(isLoadingCelebrities: true));
    final result = await getCelebritiesUsecase.call(GetCelebritiesParams(
      page: 1,
      pageSize: 50,
    ));
    final newState = state.copyWith(
      isLoadingCelebrities: false,
      celebrities: result.fold(
        (ex) {
          print(ex);
          return [];
        },
        (celebs) => celebs,
      ),
    );
    emit(newState);
  }

  void onTopHeldAssetTypeSelected(AssetType type) {
    if (state.selectedAssetTypeFilter == type) {
      return;
    }
    emit(state.copyWith(selectedAssetTypeFilter: type));
    switch (type) {
      case AssetType.stock:
        if (state.topHeldStocks.isEmpty) {
          _getTopHeldStocks();
        }
        break;
      case AssetType.mutualFund:
        if (state.topHeldMFs.isEmpty) {
          _getTopHeldMFs();
        }
        break;
    }
  }

  void toggleMostWatchedDuration() {
    final index = _mostWatchedDurations.indexWhere((e) => state.mostWatchedStocksPeriod == e);
    final nextDurationIndex = (index + 1) % _mostWatchedDurations.length;
    final nextDuration = _mostWatchedDurations[nextDurationIndex];
    emit(state.copyWith(mostWatchedStocksPeriod: nextDuration));
    _getMostWatchedStocks();
  }

  void toggleMostBoughtDuration() {
    final index = _mostBoughtDurations.indexWhere((e) => state.mostBoughtStocksPeriod == e);
    final nextDurationIndex = (index + 1) % _mostBoughtDurations.length;
    final nextDuration = _mostBoughtDurations[nextDurationIndex];
    emit(state.copyWith(mostBoughtStocksPeriod: nextDuration));
    _getMostBoughtStocks();
  }

  void toggleMostSoldDuration() {
    final index = _mostSoldDurations.indexWhere((e) => state.mostSoldStocksPeriod == e);
    final nextDurationIndex = (index + 1) % _mostSoldDurations.length;
    final nextDuration = _mostSoldDurations[nextDurationIndex];
    emit(state.copyWith(mostSoldStocksPeriod: nextDuration));
    _getMostSoldStocks();
  }

  void toggleTopMoverStocksDuration() {
    final index = _topMoverStocksDurations.indexWhere((e) => state.topMoverStocksPeriod == e);
    final nextDurationIndex = (index + 1) % _topMoverStocksDurations.length;
    final nextDuration = _topMoverStocksDurations[nextDurationIndex];
    emit(state.copyWith(topMoverStocksPeriod: nextDuration));
    getTopMoverStocks();
  }
}

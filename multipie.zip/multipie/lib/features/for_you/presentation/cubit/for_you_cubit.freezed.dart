// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'for_you_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ForYouState {
  bool get isLoadingMostTalkedStocks => throw _privateConstructorUsedError;
  List<Company> get mostTalkedStocks => throw _privateConstructorUsedError;
  bool get isLoadingTopHeldStocks => throw _privateConstructorUsedError;
  AssetType get selectedAssetTypeFilter => throw _privateConstructorUsedError;
  List<Company> get topHeldStocks => throw _privateConstructorUsedError;
  bool get isLoadingTopHeldMFs => throw _privateConstructorUsedError;
  List<TopHeldMutualFund> get topHeldMFs => throw _privateConstructorUsedError;
  bool get isLoadingTopMoverStocks => throw _privateConstructorUsedError;
  List<Company> get topMoverStocks => throw _privateConstructorUsedError;
  String get topMoverStocksPeriod => throw _privateConstructorUsedError;
  bool get isLoadingMostWatchedStocks => throw _privateConstructorUsedError;
  List<Company> get mostWatchedStocks => throw _privateConstructorUsedError;
  String get mostWatchedStocksPeriod => throw _privateConstructorUsedError;
  bool get isLoadingMarketIndices => throw _privateConstructorUsedError;
  List<MarketIndex> get marketIndices => throw _privateConstructorUsedError;
  bool get isLoadingNews => throw _privateConstructorUsedError;
  List<News> get news => throw _privateConstructorUsedError;
  bool get isLoadingCelebrities => throw _privateConstructorUsedError;
  List<User> get celebrities => throw _privateConstructorUsedError;
  bool get isLoadingMostBoughtStocks => throw _privateConstructorUsedError;
  List<Company> get mostBoughtStocks => throw _privateConstructorUsedError;
  String get mostBoughtStocksPeriod => throw _privateConstructorUsedError;
  bool get isLoadingMostSoldStocks => throw _privateConstructorUsedError;
  List<Company> get mostSoldStocks => throw _privateConstructorUsedError;
  String get mostSoldStocksPeriod => throw _privateConstructorUsedError;
  List<ExternalLinkModel> get externalLinks =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ForYouStateCopyWith<ForYouState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ForYouStateCopyWith<$Res> {
  factory $ForYouStateCopyWith(
          ForYouState value, $Res Function(ForYouState) then) =
      _$ForYouStateCopyWithImpl<$Res>;
  $Res call(
      {bool isLoadingMostTalkedStocks,
      List<Company> mostTalkedStocks,
      bool isLoadingTopHeldStocks,
      AssetType selectedAssetTypeFilter,
      List<Company> topHeldStocks,
      bool isLoadingTopHeldMFs,
      List<TopHeldMutualFund> topHeldMFs,
      bool isLoadingTopMoverStocks,
      List<Company> topMoverStocks,
      String topMoverStocksPeriod,
      bool isLoadingMostWatchedStocks,
      List<Company> mostWatchedStocks,
      String mostWatchedStocksPeriod,
      bool isLoadingMarketIndices,
      List<MarketIndex> marketIndices,
      bool isLoadingNews,
      List<News> news,
      bool isLoadingCelebrities,
      List<User> celebrities,
      bool isLoadingMostBoughtStocks,
      List<Company> mostBoughtStocks,
      String mostBoughtStocksPeriod,
      bool isLoadingMostSoldStocks,
      List<Company> mostSoldStocks,
      String mostSoldStocksPeriod,
      List<ExternalLinkModel> externalLinks});
}

/// @nodoc
class _$ForYouStateCopyWithImpl<$Res> implements $ForYouStateCopyWith<$Res> {
  _$ForYouStateCopyWithImpl(this._value, this._then);

  final ForYouState _value;
  // ignore: unused_field
  final $Res Function(ForYouState) _then;

  @override
  $Res call({
    Object? isLoadingMostTalkedStocks = freezed,
    Object? mostTalkedStocks = freezed,
    Object? isLoadingTopHeldStocks = freezed,
    Object? selectedAssetTypeFilter = freezed,
    Object? topHeldStocks = freezed,
    Object? isLoadingTopHeldMFs = freezed,
    Object? topHeldMFs = freezed,
    Object? isLoadingTopMoverStocks = freezed,
    Object? topMoverStocks = freezed,
    Object? topMoverStocksPeriod = freezed,
    Object? isLoadingMostWatchedStocks = freezed,
    Object? mostWatchedStocks = freezed,
    Object? mostWatchedStocksPeriod = freezed,
    Object? isLoadingMarketIndices = freezed,
    Object? marketIndices = freezed,
    Object? isLoadingNews = freezed,
    Object? news = freezed,
    Object? isLoadingCelebrities = freezed,
    Object? celebrities = freezed,
    Object? isLoadingMostBoughtStocks = freezed,
    Object? mostBoughtStocks = freezed,
    Object? mostBoughtStocksPeriod = freezed,
    Object? isLoadingMostSoldStocks = freezed,
    Object? mostSoldStocks = freezed,
    Object? mostSoldStocksPeriod = freezed,
    Object? externalLinks = freezed,
  }) {
    return _then(_value.copyWith(
      isLoadingMostTalkedStocks: isLoadingMostTalkedStocks == freezed
          ? _value.isLoadingMostTalkedStocks
          : isLoadingMostTalkedStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostTalkedStocks: mostTalkedStocks == freezed
          ? _value.mostTalkedStocks
          : mostTalkedStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      isLoadingTopHeldStocks: isLoadingTopHeldStocks == freezed
          ? _value.isLoadingTopHeldStocks
          : isLoadingTopHeldStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedAssetTypeFilter: selectedAssetTypeFilter == freezed
          ? _value.selectedAssetTypeFilter
          : selectedAssetTypeFilter // ignore: cast_nullable_to_non_nullable
              as AssetType,
      topHeldStocks: topHeldStocks == freezed
          ? _value.topHeldStocks
          : topHeldStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      isLoadingTopHeldMFs: isLoadingTopHeldMFs == freezed
          ? _value.isLoadingTopHeldMFs
          : isLoadingTopHeldMFs // ignore: cast_nullable_to_non_nullable
              as bool,
      topHeldMFs: topHeldMFs == freezed
          ? _value.topHeldMFs
          : topHeldMFs // ignore: cast_nullable_to_non_nullable
              as List<TopHeldMutualFund>,
      isLoadingTopMoverStocks: isLoadingTopMoverStocks == freezed
          ? _value.isLoadingTopMoverStocks
          : isLoadingTopMoverStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      topMoverStocks: topMoverStocks == freezed
          ? _value.topMoverStocks
          : topMoverStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      topMoverStocksPeriod: topMoverStocksPeriod == freezed
          ? _value.topMoverStocksPeriod
          : topMoverStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingMostWatchedStocks: isLoadingMostWatchedStocks == freezed
          ? _value.isLoadingMostWatchedStocks
          : isLoadingMostWatchedStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostWatchedStocks: mostWatchedStocks == freezed
          ? _value.mostWatchedStocks
          : mostWatchedStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      mostWatchedStocksPeriod: mostWatchedStocksPeriod == freezed
          ? _value.mostWatchedStocksPeriod
          : mostWatchedStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingMarketIndices: isLoadingMarketIndices == freezed
          ? _value.isLoadingMarketIndices
          : isLoadingMarketIndices // ignore: cast_nullable_to_non_nullable
              as bool,
      marketIndices: marketIndices == freezed
          ? _value.marketIndices
          : marketIndices // ignore: cast_nullable_to_non_nullable
              as List<MarketIndex>,
      isLoadingNews: isLoadingNews == freezed
          ? _value.isLoadingNews
          : isLoadingNews // ignore: cast_nullable_to_non_nullable
              as bool,
      news: news == freezed
          ? _value.news
          : news // ignore: cast_nullable_to_non_nullable
              as List<News>,
      isLoadingCelebrities: isLoadingCelebrities == freezed
          ? _value.isLoadingCelebrities
          : isLoadingCelebrities // ignore: cast_nullable_to_non_nullable
              as bool,
      celebrities: celebrities == freezed
          ? _value.celebrities
          : celebrities // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isLoadingMostBoughtStocks: isLoadingMostBoughtStocks == freezed
          ? _value.isLoadingMostBoughtStocks
          : isLoadingMostBoughtStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostBoughtStocks: mostBoughtStocks == freezed
          ? _value.mostBoughtStocks
          : mostBoughtStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      mostBoughtStocksPeriod: mostBoughtStocksPeriod == freezed
          ? _value.mostBoughtStocksPeriod
          : mostBoughtStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingMostSoldStocks: isLoadingMostSoldStocks == freezed
          ? _value.isLoadingMostSoldStocks
          : isLoadingMostSoldStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostSoldStocks: mostSoldStocks == freezed
          ? _value.mostSoldStocks
          : mostSoldStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      mostSoldStocksPeriod: mostSoldStocksPeriod == freezed
          ? _value.mostSoldStocksPeriod
          : mostSoldStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      externalLinks: externalLinks == freezed
          ? _value.externalLinks
          : externalLinks // ignore: cast_nullable_to_non_nullable
              as List<ExternalLinkModel>,
    ));
  }
}

/// @nodoc
abstract class _$$_ForYouStateCopyWith<$Res>
    implements $ForYouStateCopyWith<$Res> {
  factory _$$_ForYouStateCopyWith(
          _$_ForYouState value, $Res Function(_$_ForYouState) then) =
      __$$_ForYouStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {bool isLoadingMostTalkedStocks,
      List<Company> mostTalkedStocks,
      bool isLoadingTopHeldStocks,
      AssetType selectedAssetTypeFilter,
      List<Company> topHeldStocks,
      bool isLoadingTopHeldMFs,
      List<TopHeldMutualFund> topHeldMFs,
      bool isLoadingTopMoverStocks,
      List<Company> topMoverStocks,
      String topMoverStocksPeriod,
      bool isLoadingMostWatchedStocks,
      List<Company> mostWatchedStocks,
      String mostWatchedStocksPeriod,
      bool isLoadingMarketIndices,
      List<MarketIndex> marketIndices,
      bool isLoadingNews,
      List<News> news,
      bool isLoadingCelebrities,
      List<User> celebrities,
      bool isLoadingMostBoughtStocks,
      List<Company> mostBoughtStocks,
      String mostBoughtStocksPeriod,
      bool isLoadingMostSoldStocks,
      List<Company> mostSoldStocks,
      String mostSoldStocksPeriod,
      List<ExternalLinkModel> externalLinks});
}

/// @nodoc
class __$$_ForYouStateCopyWithImpl<$Res> extends _$ForYouStateCopyWithImpl<$Res>
    implements _$$_ForYouStateCopyWith<$Res> {
  __$$_ForYouStateCopyWithImpl(
      _$_ForYouState _value, $Res Function(_$_ForYouState) _then)
      : super(_value, (v) => _then(v as _$_ForYouState));

  @override
  _$_ForYouState get _value => super._value as _$_ForYouState;

  @override
  $Res call({
    Object? isLoadingMostTalkedStocks = freezed,
    Object? mostTalkedStocks = freezed,
    Object? isLoadingTopHeldStocks = freezed,
    Object? selectedAssetTypeFilter = freezed,
    Object? topHeldStocks = freezed,
    Object? isLoadingTopHeldMFs = freezed,
    Object? topHeldMFs = freezed,
    Object? isLoadingTopMoverStocks = freezed,
    Object? topMoverStocks = freezed,
    Object? topMoverStocksPeriod = freezed,
    Object? isLoadingMostWatchedStocks = freezed,
    Object? mostWatchedStocks = freezed,
    Object? mostWatchedStocksPeriod = freezed,
    Object? isLoadingMarketIndices = freezed,
    Object? marketIndices = freezed,
    Object? isLoadingNews = freezed,
    Object? news = freezed,
    Object? isLoadingCelebrities = freezed,
    Object? celebrities = freezed,
    Object? isLoadingMostBoughtStocks = freezed,
    Object? mostBoughtStocks = freezed,
    Object? mostBoughtStocksPeriod = freezed,
    Object? isLoadingMostSoldStocks = freezed,
    Object? mostSoldStocks = freezed,
    Object? mostSoldStocksPeriod = freezed,
    Object? externalLinks = freezed,
  }) {
    return _then(_$_ForYouState(
      isLoadingMostTalkedStocks: isLoadingMostTalkedStocks == freezed
          ? _value.isLoadingMostTalkedStocks
          : isLoadingMostTalkedStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostTalkedStocks: mostTalkedStocks == freezed
          ? _value._mostTalkedStocks
          : mostTalkedStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      isLoadingTopHeldStocks: isLoadingTopHeldStocks == freezed
          ? _value.isLoadingTopHeldStocks
          : isLoadingTopHeldStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedAssetTypeFilter: selectedAssetTypeFilter == freezed
          ? _value.selectedAssetTypeFilter
          : selectedAssetTypeFilter // ignore: cast_nullable_to_non_nullable
              as AssetType,
      topHeldStocks: topHeldStocks == freezed
          ? _value._topHeldStocks
          : topHeldStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      isLoadingTopHeldMFs: isLoadingTopHeldMFs == freezed
          ? _value.isLoadingTopHeldMFs
          : isLoadingTopHeldMFs // ignore: cast_nullable_to_non_nullable
              as bool,
      topHeldMFs: topHeldMFs == freezed
          ? _value._topHeldMFs
          : topHeldMFs // ignore: cast_nullable_to_non_nullable
              as List<TopHeldMutualFund>,
      isLoadingTopMoverStocks: isLoadingTopMoverStocks == freezed
          ? _value.isLoadingTopMoverStocks
          : isLoadingTopMoverStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      topMoverStocks: topMoverStocks == freezed
          ? _value._topMoverStocks
          : topMoverStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      topMoverStocksPeriod: topMoverStocksPeriod == freezed
          ? _value.topMoverStocksPeriod
          : topMoverStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingMostWatchedStocks: isLoadingMostWatchedStocks == freezed
          ? _value.isLoadingMostWatchedStocks
          : isLoadingMostWatchedStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostWatchedStocks: mostWatchedStocks == freezed
          ? _value._mostWatchedStocks
          : mostWatchedStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      mostWatchedStocksPeriod: mostWatchedStocksPeriod == freezed
          ? _value.mostWatchedStocksPeriod
          : mostWatchedStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingMarketIndices: isLoadingMarketIndices == freezed
          ? _value.isLoadingMarketIndices
          : isLoadingMarketIndices // ignore: cast_nullable_to_non_nullable
              as bool,
      marketIndices: marketIndices == freezed
          ? _value._marketIndices
          : marketIndices // ignore: cast_nullable_to_non_nullable
              as List<MarketIndex>,
      isLoadingNews: isLoadingNews == freezed
          ? _value.isLoadingNews
          : isLoadingNews // ignore: cast_nullable_to_non_nullable
              as bool,
      news: news == freezed
          ? _value._news
          : news // ignore: cast_nullable_to_non_nullable
              as List<News>,
      isLoadingCelebrities: isLoadingCelebrities == freezed
          ? _value.isLoadingCelebrities
          : isLoadingCelebrities // ignore: cast_nullable_to_non_nullable
              as bool,
      celebrities: celebrities == freezed
          ? _value._celebrities
          : celebrities // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isLoadingMostBoughtStocks: isLoadingMostBoughtStocks == freezed
          ? _value.isLoadingMostBoughtStocks
          : isLoadingMostBoughtStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostBoughtStocks: mostBoughtStocks == freezed
          ? _value._mostBoughtStocks
          : mostBoughtStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      mostBoughtStocksPeriod: mostBoughtStocksPeriod == freezed
          ? _value.mostBoughtStocksPeriod
          : mostBoughtStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingMostSoldStocks: isLoadingMostSoldStocks == freezed
          ? _value.isLoadingMostSoldStocks
          : isLoadingMostSoldStocks // ignore: cast_nullable_to_non_nullable
              as bool,
      mostSoldStocks: mostSoldStocks == freezed
          ? _value._mostSoldStocks
          : mostSoldStocks // ignore: cast_nullable_to_non_nullable
              as List<Company>,
      mostSoldStocksPeriod: mostSoldStocksPeriod == freezed
          ? _value.mostSoldStocksPeriod
          : mostSoldStocksPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      externalLinks: externalLinks == freezed
          ? _value._externalLinks
          : externalLinks // ignore: cast_nullable_to_non_nullable
              as List<ExternalLinkModel>,
    ));
  }
}

/// @nodoc

class _$_ForYouState implements _ForYouState {
  _$_ForYouState(
      {this.isLoadingMostTalkedStocks = false,
      final List<Company> mostTalkedStocks = const [],
      this.isLoadingTopHeldStocks = false,
      this.selectedAssetTypeFilter = AssetType.stock,
      final List<Company> topHeldStocks = const [],
      this.isLoadingTopHeldMFs = false,
      final List<TopHeldMutualFund> topHeldMFs = const [],
      this.isLoadingTopMoverStocks = false,
      final List<Company> topMoverStocks = const [],
      this.topMoverStocksPeriod = '5d',
      this.isLoadingMostWatchedStocks = false,
      final List<Company> mostWatchedStocks = const [],
      this.mostWatchedStocksPeriod = '5d',
      this.isLoadingMarketIndices = false,
      final List<MarketIndex> marketIndices = const [],
      this.isLoadingNews = false,
      final List<News> news = const [],
      this.isLoadingCelebrities = false,
      final List<User> celebrities = const [],
      this.isLoadingMostBoughtStocks = false,
      final List<Company> mostBoughtStocks = const [],
      this.mostBoughtStocksPeriod = '5d',
      this.isLoadingMostSoldStocks = false,
      final List<Company> mostSoldStocks = const [],
      this.mostSoldStocksPeriod = '5d',
      final List<ExternalLinkModel> externalLinks = const []})
      : _mostTalkedStocks = mostTalkedStocks,
        _topHeldStocks = topHeldStocks,
        _topHeldMFs = topHeldMFs,
        _topMoverStocks = topMoverStocks,
        _mostWatchedStocks = mostWatchedStocks,
        _marketIndices = marketIndices,
        _news = news,
        _celebrities = celebrities,
        _mostBoughtStocks = mostBoughtStocks,
        _mostSoldStocks = mostSoldStocks,
        _externalLinks = externalLinks;

  @override
  @JsonKey()
  final bool isLoadingMostTalkedStocks;
  final List<Company> _mostTalkedStocks;
  @override
  @JsonKey()
  List<Company> get mostTalkedStocks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_mostTalkedStocks);
  }

  @override
  @JsonKey()
  final bool isLoadingTopHeldStocks;
  @override
  @JsonKey()
  final AssetType selectedAssetTypeFilter;
  final List<Company> _topHeldStocks;
  @override
  @JsonKey()
  List<Company> get topHeldStocks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_topHeldStocks);
  }

  @override
  @JsonKey()
  final bool isLoadingTopHeldMFs;
  final List<TopHeldMutualFund> _topHeldMFs;
  @override
  @JsonKey()
  List<TopHeldMutualFund> get topHeldMFs {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_topHeldMFs);
  }

  @override
  @JsonKey()
  final bool isLoadingTopMoverStocks;
  final List<Company> _topMoverStocks;
  @override
  @JsonKey()
  List<Company> get topMoverStocks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_topMoverStocks);
  }

  @override
  @JsonKey()
  final String topMoverStocksPeriod;
  @override
  @JsonKey()
  final bool isLoadingMostWatchedStocks;
  final List<Company> _mostWatchedStocks;
  @override
  @JsonKey()
  List<Company> get mostWatchedStocks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_mostWatchedStocks);
  }

  @override
  @JsonKey()
  final String mostWatchedStocksPeriod;
  @override
  @JsonKey()
  final bool isLoadingMarketIndices;
  final List<MarketIndex> _marketIndices;
  @override
  @JsonKey()
  List<MarketIndex> get marketIndices {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_marketIndices);
  }

  @override
  @JsonKey()
  final bool isLoadingNews;
  final List<News> _news;
  @override
  @JsonKey()
  List<News> get news {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_news);
  }

  @override
  @JsonKey()
  final bool isLoadingCelebrities;
  final List<User> _celebrities;
  @override
  @JsonKey()
  List<User> get celebrities {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_celebrities);
  }

  @override
  @JsonKey()
  final bool isLoadingMostBoughtStocks;
  final List<Company> _mostBoughtStocks;
  @override
  @JsonKey()
  List<Company> get mostBoughtStocks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_mostBoughtStocks);
  }

  @override
  @JsonKey()
  final String mostBoughtStocksPeriod;
  @override
  @JsonKey()
  final bool isLoadingMostSoldStocks;
  final List<Company> _mostSoldStocks;
  @override
  @JsonKey()
  List<Company> get mostSoldStocks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_mostSoldStocks);
  }

  @override
  @JsonKey()
  final String mostSoldStocksPeriod;
  final List<ExternalLinkModel> _externalLinks;
  @override
  @JsonKey()
  List<ExternalLinkModel> get externalLinks {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_externalLinks);
  }

  @override
  String toString() {
    return 'ForYouState(isLoadingMostTalkedStocks: $isLoadingMostTalkedStocks, mostTalkedStocks: $mostTalkedStocks, isLoadingTopHeldStocks: $isLoadingTopHeldStocks, selectedAssetTypeFilter: $selectedAssetTypeFilter, topHeldStocks: $topHeldStocks, isLoadingTopHeldMFs: $isLoadingTopHeldMFs, topHeldMFs: $topHeldMFs, isLoadingTopMoverStocks: $isLoadingTopMoverStocks, topMoverStocks: $topMoverStocks, topMoverStocksPeriod: $topMoverStocksPeriod, isLoadingMostWatchedStocks: $isLoadingMostWatchedStocks, mostWatchedStocks: $mostWatchedStocks, mostWatchedStocksPeriod: $mostWatchedStocksPeriod, isLoadingMarketIndices: $isLoadingMarketIndices, marketIndices: $marketIndices, isLoadingNews: $isLoadingNews, news: $news, isLoadingCelebrities: $isLoadingCelebrities, celebrities: $celebrities, isLoadingMostBoughtStocks: $isLoadingMostBoughtStocks, mostBoughtStocks: $mostBoughtStocks, mostBoughtStocksPeriod: $mostBoughtStocksPeriod, isLoadingMostSoldStocks: $isLoadingMostSoldStocks, mostSoldStocks: $mostSoldStocks, mostSoldStocksPeriod: $mostSoldStocksPeriod, externalLinks: $externalLinks)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ForYouState &&
            const DeepCollectionEquality().equals(
                other.isLoadingMostTalkedStocks, isLoadingMostTalkedStocks) &&
            const DeepCollectionEquality()
                .equals(other._mostTalkedStocks, _mostTalkedStocks) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingTopHeldStocks, isLoadingTopHeldStocks) &&
            const DeepCollectionEquality().equals(
                other.selectedAssetTypeFilter, selectedAssetTypeFilter) &&
            const DeepCollectionEquality()
                .equals(other._topHeldStocks, _topHeldStocks) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingTopHeldMFs, isLoadingTopHeldMFs) &&
            const DeepCollectionEquality()
                .equals(other._topHeldMFs, _topHeldMFs) &&
            const DeepCollectionEquality().equals(
                other.isLoadingTopMoverStocks, isLoadingTopMoverStocks) &&
            const DeepCollectionEquality()
                .equals(other._topMoverStocks, _topMoverStocks) &&
            const DeepCollectionEquality()
                .equals(other.topMoverStocksPeriod, topMoverStocksPeriod) &&
            const DeepCollectionEquality().equals(
                other.isLoadingMostWatchedStocks, isLoadingMostWatchedStocks) &&
            const DeepCollectionEquality()
                .equals(other._mostWatchedStocks, _mostWatchedStocks) &&
            const DeepCollectionEquality().equals(
                other.mostWatchedStocksPeriod, mostWatchedStocksPeriod) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingMarketIndices, isLoadingMarketIndices) &&
            const DeepCollectionEquality()
                .equals(other._marketIndices, _marketIndices) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingNews, isLoadingNews) &&
            const DeepCollectionEquality().equals(other._news, _news) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingCelebrities, isLoadingCelebrities) &&
            const DeepCollectionEquality()
                .equals(other._celebrities, _celebrities) &&
            const DeepCollectionEquality().equals(
                other.isLoadingMostBoughtStocks, isLoadingMostBoughtStocks) &&
            const DeepCollectionEquality()
                .equals(other._mostBoughtStocks, _mostBoughtStocks) &&
            const DeepCollectionEquality()
                .equals(other.mostBoughtStocksPeriod, mostBoughtStocksPeriod) &&
            const DeepCollectionEquality().equals(
                other.isLoadingMostSoldStocks, isLoadingMostSoldStocks) &&
            const DeepCollectionEquality()
                .equals(other._mostSoldStocks, _mostSoldStocks) &&
            const DeepCollectionEquality()
                .equals(other.mostSoldStocksPeriod, mostSoldStocksPeriod) &&
            const DeepCollectionEquality()
                .equals(other._externalLinks, _externalLinks));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        const DeepCollectionEquality().hash(isLoadingMostTalkedStocks),
        const DeepCollectionEquality().hash(_mostTalkedStocks),
        const DeepCollectionEquality().hash(isLoadingTopHeldStocks),
        const DeepCollectionEquality().hash(selectedAssetTypeFilter),
        const DeepCollectionEquality().hash(_topHeldStocks),
        const DeepCollectionEquality().hash(isLoadingTopHeldMFs),
        const DeepCollectionEquality().hash(_topHeldMFs),
        const DeepCollectionEquality().hash(isLoadingTopMoverStocks),
        const DeepCollectionEquality().hash(_topMoverStocks),
        const DeepCollectionEquality().hash(topMoverStocksPeriod),
        const DeepCollectionEquality().hash(isLoadingMostWatchedStocks),
        const DeepCollectionEquality().hash(_mostWatchedStocks),
        const DeepCollectionEquality().hash(mostWatchedStocksPeriod),
        const DeepCollectionEquality().hash(isLoadingMarketIndices),
        const DeepCollectionEquality().hash(_marketIndices),
        const DeepCollectionEquality().hash(isLoadingNews),
        const DeepCollectionEquality().hash(_news),
        const DeepCollectionEquality().hash(isLoadingCelebrities),
        const DeepCollectionEquality().hash(_celebrities),
        const DeepCollectionEquality().hash(isLoadingMostBoughtStocks),
        const DeepCollectionEquality().hash(_mostBoughtStocks),
        const DeepCollectionEquality().hash(mostBoughtStocksPeriod),
        const DeepCollectionEquality().hash(isLoadingMostSoldStocks),
        const DeepCollectionEquality().hash(_mostSoldStocks),
        const DeepCollectionEquality().hash(mostSoldStocksPeriod),
        const DeepCollectionEquality().hash(_externalLinks)
      ]);

  @JsonKey(ignore: true)
  @override
  _$$_ForYouStateCopyWith<_$_ForYouState> get copyWith =>
      __$$_ForYouStateCopyWithImpl<_$_ForYouState>(this, _$identity);
}

abstract class _ForYouState implements ForYouState {
  factory _ForYouState(
      {final bool isLoadingMostTalkedStocks,
      final List<Company> mostTalkedStocks,
      final bool isLoadingTopHeldStocks,
      final AssetType selectedAssetTypeFilter,
      final List<Company> topHeldStocks,
      final bool isLoadingTopHeldMFs,
      final List<TopHeldMutualFund> topHeldMFs,
      final bool isLoadingTopMoverStocks,
      final List<Company> topMoverStocks,
      final String topMoverStocksPeriod,
      final bool isLoadingMostWatchedStocks,
      final List<Company> mostWatchedStocks,
      final String mostWatchedStocksPeriod,
      final bool isLoadingMarketIndices,
      final List<MarketIndex> marketIndices,
      final bool isLoadingNews,
      final List<News> news,
      final bool isLoadingCelebrities,
      final List<User> celebrities,
      final bool isLoadingMostBoughtStocks,
      final List<Company> mostBoughtStocks,
      final String mostBoughtStocksPeriod,
      final bool isLoadingMostSoldStocks,
      final List<Company> mostSoldStocks,
      final String mostSoldStocksPeriod,
      final List<ExternalLinkModel> externalLinks}) = _$_ForYouState;

  @override
  bool get isLoadingMostTalkedStocks => throw _privateConstructorUsedError;
  @override
  List<Company> get mostTalkedStocks => throw _privateConstructorUsedError;
  @override
  bool get isLoadingTopHeldStocks => throw _privateConstructorUsedError;
  @override
  AssetType get selectedAssetTypeFilter => throw _privateConstructorUsedError;
  @override
  List<Company> get topHeldStocks => throw _privateConstructorUsedError;
  @override
  bool get isLoadingTopHeldMFs => throw _privateConstructorUsedError;
  @override
  List<TopHeldMutualFund> get topHeldMFs => throw _privateConstructorUsedError;
  @override
  bool get isLoadingTopMoverStocks => throw _privateConstructorUsedError;
  @override
  List<Company> get topMoverStocks => throw _privateConstructorUsedError;
  @override
  String get topMoverStocksPeriod => throw _privateConstructorUsedError;
  @override
  bool get isLoadingMostWatchedStocks => throw _privateConstructorUsedError;
  @override
  List<Company> get mostWatchedStocks => throw _privateConstructorUsedError;
  @override
  String get mostWatchedStocksPeriod => throw _privateConstructorUsedError;
  @override
  bool get isLoadingMarketIndices => throw _privateConstructorUsedError;
  @override
  List<MarketIndex> get marketIndices => throw _privateConstructorUsedError;
  @override
  bool get isLoadingNews => throw _privateConstructorUsedError;
  @override
  List<News> get news => throw _privateConstructorUsedError;
  @override
  bool get isLoadingCelebrities => throw _privateConstructorUsedError;
  @override
  List<User> get celebrities => throw _privateConstructorUsedError;
  @override
  bool get isLoadingMostBoughtStocks => throw _privateConstructorUsedError;
  @override
  List<Company> get mostBoughtStocks => throw _privateConstructorUsedError;
  @override
  String get mostBoughtStocksPeriod => throw _privateConstructorUsedError;
  @override
  bool get isLoadingMostSoldStocks => throw _privateConstructorUsedError;
  @override
  List<Company> get mostSoldStocks => throw _privateConstructorUsedError;
  @override
  String get mostSoldStocksPeriod => throw _privateConstructorUsedError;
  @override
  List<ExternalLinkModel> get externalLinks =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ForYouStateCopyWith<_$_ForYouState> get copyWith =>
      throw _privateConstructorUsedError;
}

part of 'outperformers_cubit.dart';

@freezed
class OutperformersState with _$OutperformersState {
  factory OutperformersState({
    @Default(false) bool isLoading,
    @Default([]) List<User> people,
    required String period,
  }) = _OutperformersState;
}

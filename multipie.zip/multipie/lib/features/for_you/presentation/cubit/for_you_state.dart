part of 'for_you_cubit.dart';

@freezed
class ForYouState with _$ForYouState {
  factory ForYouState({
    @Default(false) bool isLoadingMostTalkedStocks,
    @Default([]) List<Company> mostTalkedStocks,
    @Default(false) bool isLoadingTopHeldStocks,
    @Default(AssetType.stock) AssetType selectedAssetTypeFilter,
    @Default([]) List<Company> topHeldStocks,
    @Default(false) bool isLoadingTopHeldMFs,
    @Default([]) List<TopHeldMutualFund> topHeldMFs,
    @Default(false) bool isLoadingTopMoverStocks,
    @Default([]) List<Company> topMoverStocks,
    @Default('5d') String topMoverStocksPeriod,
    @Default(false) bool isLoadingMostWatchedStocks,
    @Default([]) List<Company> mostWatchedStocks,
    @Default('5d') String mostWatchedStocksPeriod,
    @Default(false) bool isLoadingMarketIndices,
    @Default([]) List<MarketIndex> marketIndices,
    @Default(false) bool isLoadingNews,
    @Default([]) List<News> news,
    @Default(false) bool isLoadingCelebrities,
    @Default([]) List<User> celebrities,
    @Default(false) bool isLoadingMostBoughtStocks,
    @Default([]) List<Company> mostBoughtStocks,
    @Default('5d') String mostBoughtStocksPeriod,
    @Default(false) bool isLoadingMostSoldStocks,
    @Default([]) List<Company> mostSoldStocks,
    @Default('5d') String mostSoldStocksPeriod,
    @Default([]) List<ExternalLinkModel> externalLinks,
  }) = _ForYouState;
}

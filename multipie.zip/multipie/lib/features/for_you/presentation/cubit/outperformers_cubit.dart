import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/for_you/data/repositories/people_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

part 'outperformers_cubit.freezed.dart';
part 'outperformers_state.dart';

class OutperformersCubit extends Cubit<OutperformersState> {
  OutperformersCubit({
    required this.peopleRepository,
  }) : super(OutperformersState(period: _durations.first));

  final PeopleRepository peopleRepository;
  static const _durations = ['1d', '1w'];

  Future<void> refresh() async {
    await _getLeaders();
  }

  Future<void> _getLeaders() async {
    emit(state.copyWith(isLoading: true));
    final result = await peopleRepository.getLeaders(period: state.period);
    final newState = state.copyWith(
      isLoading: false,
      people: result.fold((ex) => [], (data) => data),
    );
    emit(newState);
  }

  Future<void> togglePeriod() async {
    final index = _durations.indexWhere((e) => state.period == e);
    final nextDurationIndex = (index + 1) % _durations.length;
    final nextDuration = _durations[nextDurationIndex];
    emit(state.copyWith(period: nextDuration));
    await refresh();
  }
}

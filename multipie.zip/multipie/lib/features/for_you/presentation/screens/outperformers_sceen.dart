import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/for_you/presentation/cubit/outperformers_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/toggle_duration_button.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/new_profile_screen.dart';
import 'package:multipie/features/profile/presentation/widgets/follow_unfollow_widget.dart';
import 'package:multipie/features/profile/presentation/widgets/user_daily_gain_widget.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/locator.dart';

class OutperformersScreen extends StatelessWidget {
  const OutperformersScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<OutperformersCubit>(
      create: (_) => locator<OutperformersCubit>()..refresh(),
      child: BlocBuilder<OutperformersCubit, OutperformersState>(
        builder: (context, state) {
          return Scaffold(
            appBar: MultipieAppBar(
              title: 'Outperformers',
              centerTitle: false,
              actions: [
                Padding(
                  padding: const EdgeInsets.only(right: 12.0),
                  child: Center(
                    child: ToggleDurationButton(
                      value: state.period,
                      onPressed: () => context.read<OutperformersCubit>().togglePeriod(),
                    ),
                  ),
                )
              ],
            ),
            body: _Body(),
          );
        },
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<OutperformersCubit, OutperformersState>(
      builder: (context, state) {
        if (state.isLoading) {
          return Center(
            child: MPLoadingIndicator(),
          );
        } else if (state.people.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Text(
                'Not Available',
                style: mpHeadLine6(context: context),
              ),
            ),
          );
        } else {
          return ListView.builder(
            itemBuilder: (context, index) => _UserTile(
              user: state.people[index],
            ),
            itemCount: state.people.length,
          );
        }
      },
    );
  }
}

class _UserTile extends StatelessWidget {
  const _UserTile({
    Key? key,
    required this.user,
  }) : super(key: key);

  final User user;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NewProfileScreen(
              userId: user.id,
            ),
          ),
        );
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 65,
                    height: 65,
                    margin: EdgeInsets.only(right: 16),
                    child: ProfilePictureHolder(
                      profileMode: user.marketView,
                      imageUrl: user.dpThumbnail,
                      textStyle: mpHeadLine2(
                        context: context,
                        textColor: context.appTheme.secondaryTextColor,
                      ),
                      holderLetter: user.displayname.isEmpty ? '' : user.displayname[0],
                    ),
                  ),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                user.displayname,
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                style: mpHeadLine5(
                                  context: context,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                "@${user.username}",
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                style: mpHeadLine5(
                                  context: context,
                                  textColor: context.appTheme.secondaryTextColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28,
                          child: FollowUnFollowButton(
                            data: user,
                            width: 110,
                            fontSize: 'mp4',
                            radius: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 90, bottom: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  user.profile?.bio ?? '',
                  textAlign: TextAlign.start,
                  overflow: TextOverflow.ellipsis,
                  style: mpHeadLine6(
                    context: context,
                    textColor: context.appTheme.secondaryTextColor,
                  ),
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    UserDailyGainWidget(user: user),
                  ],
                ),
              ],
            ),
          ),
          Divider(
            color: context.appTheme.secondaryTextColor,
          ),
        ],
      ),
    );
  }
}

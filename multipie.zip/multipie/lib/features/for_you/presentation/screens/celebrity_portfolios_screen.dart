import 'package:flutter/material.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/for_you/presentation/widgets/celebrities_list.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class CelebrityPortfoliosScreen extends StatelessWidget {
  const CelebrityPortfoliosScreen({
    Key? key,
    required this.celebrities,
  }) : super(key: key);

  final List<User> celebrities;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MultipieAppBar(
        title: 'Celebrity Portfolios',
        centerTitle: false,
      ),
      body: _Body(celebrities: celebrities),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({
    Key? key,
    required this.celebrities,
  }) : super(key: key);

  final List<User> celebrities;

  @override
  Widget build(BuildContext context) {
    if (celebrities.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Text(
            'Not Available',
            style: mpHeadLine6(context: context),
          ),
        ),
      );
    } else {
      return ListView.separated(
        itemBuilder: (context, index) => CelebrityListTile(
          celebrity: celebrities[index],
        ),
        separatorBuilder: (context, index) => Divider(
          height: 0.5,
          color: context.appTheme.borderColor.withOpacity(0.5),
        ),
        itemCount: celebrities.length,
      );
    }
  }
}

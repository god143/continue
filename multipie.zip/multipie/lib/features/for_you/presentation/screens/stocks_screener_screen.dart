import 'dart:collection';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/features/deep_linking/deep_linking_manager.dart';
import 'package:multipie/locator.dart';
import 'package:multipie/services/auth_token_service.dart';
import 'package:url_launcher/url_launcher.dart';

class StocksScreenerScreen extends StatefulWidget {
  const StocksScreenerScreen({
    Key? key,
  }) : super(key: key);

  @override
  _StocksScreenerScreenState createState() => _StocksScreenerScreenState();
}

class _StocksScreenerScreenState extends State<StocksScreenerScreen> {
  String token = '';
  bool isForYouLandingPage = true;
  double progress = 0;

  @override
  void initState() {
    super.initState();
    _getToken();
  }

  Future<void> _getToken() async {
    final authToken = await locator<AuthTokenService>().getAuthToken();
    setState(() {
      token = authToken;
    });
  }

  String get _javascriptToBeEvaluated => '''
                        window.localStorage.setItem('platform','mobile_app');
                        window.localStorage.setItem('authToken', '$token');
                      ''';

  @override
  Widget build(BuildContext context) {
    String _url = '${Constants.BASE_URL}/companies';
    const _kAppBarHeight = 56.0;
    final _kWebPadding = 180.0;
    return Scaffold(
      appBar: MultipieAppBar(
        title: 'All Stocks',
        centerTitle: false,
        elevation: 0,
      ),
      body: token.isNotEmpty
          ? Stack(
              children: [
                Positioned.fill(
                  top: _kAppBarHeight - _kWebPadding,
                  child: Padding(
                    padding: EdgeInsets.only(
                      top: MediaQuery.of(context).padding.top,
                    ),
                    child: Column(
                      children: [
                        if (!isForYouLandingPage) SizedBox(height: 20),
                        Expanded(
                          child: InAppWebView(
                            initialOptions: InAppWebViewGroupOptions(
                              crossPlatform: InAppWebViewOptions(
                                supportZoom: false,
                                useShouldOverrideUrlLoading: true,
                              ),
                              android: AndroidInAppWebViewOptions(
                                useHybridComposition: true,
                              ),
                            ),
                            initialUserScripts: Platform.isIOS
                                ? UnmodifiableListView<UserScript>([
                                    UserScript(
                                      source: _javascriptToBeEvaluated,
                                      injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                                    ),
                                  ])
                                : null,
                            initialUrlRequest: URLRequest(url: Uri.parse(_url)),
                            onLoadStart: (controller, url) async {
                              if (Platform.isAndroid) {
                                await controller.evaluateJavascript(source: _javascriptToBeEvaluated);
                              }
                            },
                            onUpdateVisitedHistory: (controller, url, androidIsReload) {
                              if (DeepLinkingManager.isSupportedURL(url!)) {
                                DeepLinkingManager().handleDeeplink(uri: url, context: context);
                                controller.goBack();
                              } else if (url.toString().contains("whatsapp.com")) {
                                controller.goBack();
                                launch(
                                  url.toString(),
                                );
                              } else {
                                setState(() {
                                  isForYouLandingPage = url.toString().endsWith("/m/explore/for_you");
                                });
                              }
                            },
                            onProgressChanged: (controller, progress) {
                              setState(() {
                                this.progress = (progress / 100);
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                progress < 1.0
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : Container(),
              ],
            )
          : Center(
              child: CircularProgressIndicator(),
            ),
    );
  }
}

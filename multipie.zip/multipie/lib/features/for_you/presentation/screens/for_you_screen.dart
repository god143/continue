import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/sliver_sized_box.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/celebrities_list.dart';
import 'package:multipie/features/for_you/presentation/widgets/community_card.dart';
import 'package:multipie/features/for_you/presentation/widgets/external_links_list.dart';
import 'package:multipie/features/for_you/presentation/widgets/knowledge_hub_section.dart';
import 'package:multipie/features/for_you/presentation/widgets/market_indices_list.dart';
import 'package:multipie/features/for_you/presentation/widgets/most_bought_sold_stocks_lists.dart';
import 'package:multipie/features/for_you/presentation/widgets/most_talked_stocks_list.dart';
import 'package:multipie/features/for_you/presentation/widgets/most_watched_stocks_list.dart';
import 'package:multipie/features/for_you/presentation/widgets/news_list.dart';
import 'package:multipie/features/for_you/presentation/widgets/outperformers_card.dart';
import 'package:multipie/features/for_you/presentation/widgets/screener_card.dart';
import 'package:multipie/features/for_you/presentation/widgets/section_header.dart';
import 'package:multipie/features/for_you/presentation/widgets/stock_discovery_ideas_section.dart';
import 'package:multipie/features/for_you/presentation/widgets/top_held_assets.dart';
import 'package:multipie/features/for_you/presentation/widgets/top_mover_stocks_list.dart';

class ForYouScreen extends StatefulWidget {
  const ForYouScreen({Key? key}) : super(key: key);

  @override
  State<ForYouScreen> createState() => _ForYouScreenState();
}

class _ForYouScreenState extends State<ForYouScreen> {
  final double _sectionGap = 24;
  final double _sectionHeaderGap = 8;
  final double _bottomBarHeight = 64;
  final double _floatingButtonPadding = 80;

  @override
  void initState() {
    super.initState();

    context.read<ForYouCubit>().refresh();
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return Scaffold(
      body: BlocBuilder<ForYouCubit, ForYouState>(
        builder: (context, state) {
          return RefreshIndicator(
            onRefresh: () => cubit.refresh(),
            color: context.appTheme.activeIndicationColor,
            child: CustomScrollView(
              slivers: [
                SliverSizedBox(height: _sectionGap / 2),
                OutperformersCard(),
                SliverSizedBox(height: _sectionGap),
                StockDiscoveryIdeasSection(),
                SliverSizedBox(height: _sectionGap),
                SectionHeader(title: 'Market Indices'),
                SliverSizedBox(height: _sectionHeaderGap),
                MarketIndicesList(),
                SliverSizedBox(height: _sectionGap),
                SectionHeader(title: 'Most Talked Stocks'),
                SliverSizedBox(height: _sectionHeaderGap),
                MostTalkedStocksList(),
                SliverSizedBox(height: _sectionGap),
                SectionHeader(title: 'Celebrity Portfolios'),
                SliverSizedBox(height: _sectionHeaderGap),
                CelebritiesList(),
                SliverSizedBox(height: _sectionGap),
                if (state.externalLinks.isNotEmpty) ...[
                  SectionHeader(title: 'Expert Opinions'),
                  SliverSizedBox(height: _sectionHeaderGap),
                  ExternalLinksList(),
                  SliverSizedBox(height: _sectionGap),
                ],
                SectionHeader(
                  title: 'Top Mover Stocks',
                  trailing: TopMoverStocksFilter(),
                ),
                SliverSizedBox(height: _sectionHeaderGap),
                TopMoverStocksList(),
                SliverSizedBox(height: _sectionGap),
                /* SectionHeader(title: 'Top held assets on Multipie'),
                SliverSizedBox(height: _sectionHeaderGap),
                TopHeldAssets(),
                SliverSizedBox(height: _sectionGap), */
                ScreenerCard(),
                SliverSizedBox(height: _sectionGap),
                /* SectionHeader(
                  title: 'Most Watched Stocks',
                  trailing: MostWatchedStocksFilter(),
                ),
                SliverSizedBox(height: _sectionHeaderGap),
                MostWatchedStocksList(),
                SliverSizedBox(height: _sectionGap), */
                MostBoughtSoldStocksLists(),
                SliverSizedBox(height: _sectionGap),
                CommunityCard(),
                SliverSizedBox(height: _sectionGap),
                SectionHeader(title: 'Knowledge hub'),
                SliverSizedBox(height: _sectionHeaderGap),
                KnowledgeHubSection(),
                SliverSizedBox(height: _sectionGap),
                SectionHeader(title: 'News for you'),
                SliverSizedBox(height: _sectionHeaderGap),
                NewsList(),
                SliverSizedBox(height: _sectionGap),
                SliverSizedBox(
                  height: MediaQuery.of(context).padding.bottom + _bottomBarHeight + _floatingButtonPadding,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

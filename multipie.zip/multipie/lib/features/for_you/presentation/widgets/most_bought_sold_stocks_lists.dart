import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/features/for_you/presentation/widgets/toggle_duration_button.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/screens/company_screen/company_info_screen.dart';
import 'package:multipie/services/navigation_service.dart';
import 'package:provider/provider.dart';

class MostBoughtSoldStocksLists extends StatelessWidget {
  const MostBoughtSoldStocksLists({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Container(
        color: context.appTheme.mostBoughtSoldStocksSectionBackground,
        child: Stack(
          children: [
            _BackgroundIllustration(),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _Heading(),
                  SizedBox(height: 24),
                  _BoughtSectionHeader(),
                  SizedBox(height: 8),
                  _MostBoughtStocksList(),
                  SizedBox(height: 24),
                  _SoldSectionHeader(),
                  SizedBox(height: 8),
                  _MostSoldStocksList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BoughtSectionHeader extends StatelessWidget {
  const _BoughtSectionHeader({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'Bought',
                  style: mpHeadLine5(
                    context: context,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              MostBoughtStocksFilter(),
            ],
          ),
        )
      ],
    );
  }
}

class MostBoughtStocksFilter extends StatelessWidget {
  const MostBoughtStocksFilter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return ToggleDurationButton(
      value: cubit.state.mostBoughtStocksPeriod,
      onPressed: () => cubit.toggleMostBoughtDuration(),
    );
  }
}

class _MostBoughtStocksList extends StatelessWidget {
  const _MostBoughtStocksList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return SizedBox(
      height: 116,
      child: Builder(
        builder: (context) {
          if (cubit.state.isLoadingMostBoughtStocks && cubit.state.mostBoughtStocks.isEmpty) {
            return _PlaceholderTiles();
          } else if (!cubit.state.isLoadingMostBoughtStocks && cubit.state.mostBoughtStocks.isEmpty) {
            return _EmptyListPlaceholder();
          } else {
            return _StocksList(
              stocks: cubit.state.mostBoughtStocks,
            );
          }
        },
      ),
    );
  }
}

class _SoldSectionHeader extends StatelessWidget {
  const _SoldSectionHeader({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'Sold',
                  style: mpHeadLine5(
                    context: context,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              MostSoldStocksFilter(),
            ],
          ),
        )
      ],
    );
  }
}

class MostSoldStocksFilter extends StatelessWidget {
  const MostSoldStocksFilter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return ToggleDurationButton(
      value: cubit.state.mostSoldStocksPeriod,
      onPressed: () => cubit.toggleMostSoldDuration(),
    );
  }
}

class _MostSoldStocksList extends StatelessWidget {
  const _MostSoldStocksList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return SizedBox(
      height: 116,
      child: Builder(
        builder: (context) {
          if (cubit.state.isLoadingMostSoldStocks && cubit.state.mostSoldStocks.isEmpty) {
            return _PlaceholderTiles();
          } else if (!cubit.state.isLoadingMostSoldStocks && cubit.state.mostSoldStocks.isEmpty) {
            return _EmptyListPlaceholder();
          } else {
            return _StocksList(
              stocks: cubit.state.mostSoldStocks,
            );
          }
        },
      ),
    );
  }
}

class _BackgroundIllustration extends StatelessWidget {
  const _BackgroundIllustration({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Image.asset(
          'assets/images/card_bg_line_illustation.png',
          fit: BoxFit.fill,
        ),
      ],
    );
  }
}

class _Heading extends StatelessWidget {
  const _Heading({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Most bought/ sold stocks',
            style: mpHeadLine4(
              context: context,
              fontWeight: FontWeight.w500,
              textColor: context.appTheme.activeIndicationColor,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Most bought and sold by the Multipie community members',
            style: mpHeadLine6(
              context: context,
              textColor: context.appTheme.secondaryTextColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _StocksList extends StatelessWidget {
  const _StocksList({
    Key? key,
    required this.stocks,
  }) : super(key: key);

  final List<Company> stocks;

  final _minTileWidth = 180.0;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (context, index) {
        final stock = stocks[index];
        return Padding(
          padding: EdgeInsets.only(
            left: index == 0 ? 16 : 8,
            right: index == stocks.length - 1 ? 16 : 8,
          ),
          child: InkWell(
            onTap: () {
              validateOnboardingCompleted(
                context: context,
                validationErrorDialogTitle: 'Want to see this?',
                onValidationSuccess: () => Navigate.push(
                  context,
                  CompanyInfoScreen(
                    companyId: stock.id,
                    companyName: stock.displayName ?? '',
                  ),
                ),
              );
            },
            child: Container(
              constraints: BoxConstraints(
                minWidth: _minTileWidth,
              ),
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                border: Border.all(
                  color: context.appTheme.borderColor.withOpacity(0.5),
                ),
                borderRadius: BorderRadius.circular(8),
                color: context.appTheme.cardBackgroundColor,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _StockLogo(
                    imageUrl: stock.iconUrl,
                    placeholderText: stock.name.characters.take(1).toString(),
                  ),
                  SizedBox(height: 8),
                  Text(
                    stock.nseTicker ?? stock.name,
                    maxLines: 1,
                    style: mpHeadLine5(
                      context: context,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    stock.lastTradedPrice != null ? '₹${stock.lastTradedPrice!}' : '-',
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.secondaryTextColor,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '${stock.change > 0 ? '+' : ''}'
                    '${stock.change == 0.0 ? '-' : stock.change}'
                    ' (${stock.percentChange == 0.0 ? '-' : stock.percentChange}%)',
                    textAlign: TextAlign.center,
                    style: mpHeadLine6(
                      context: context,
                      textColor: stock.change > 0
                          ? context.appTheme.positiveGainColor
                          : stock.change < 0
                              ? context.appTheme.negativeGainColor
                              : context.appTheme.primaryTextColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
      itemCount: stocks.length,
      scrollDirection: Axis.horizontal,
    );
  }
}

class _EmptyListPlaceholder extends StatelessWidget {
  const _EmptyListPlaceholder({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Not Available',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _PlaceholderTiles extends StatelessWidget {
  const _PlaceholderTiles({
    Key? key,
  }) : super(key: key);

  final double _tileWidth = 180;

  @override
  Widget build(BuildContext context) {
    return ListView(
      scrollDirection: Axis.horizontal,
      physics: NeverScrollableScrollPhysics(),
      children: [
        SizedBox(width: 16),
        SizedBox(
          width: _tileWidth,
          child: _PlaceholderTile(),
        ),
        SizedBox(width: 16),
        SizedBox(
          width: _tileWidth,
          child: DefaultImagePlaceholder(),
        ),
        SizedBox(width: 16),
        SizedBox(
          width: _tileWidth,
          child: DefaultImagePlaceholder(),
        ),
        SizedBox(width: 16),
      ],
    );
  }
}

class _PlaceholderTile extends StatelessWidget {
  const _PlaceholderTile({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: DefaultImagePlaceholder(),
    );
  }
}

class _StockLogo extends StatelessWidget {
  const _StockLogo({
    Key? key,
    required this.imageUrl,
    required this.placeholderText,
  }) : super(key: key);

  final String imageUrl;
  final String placeholderText;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
      ),
      clipBehavior: Clip.hardEdge,
      child: imageUrl.isEmpty
          ? _NamePlaceholder(
              placeholderText: placeholderText,
            )
          : CachedNetworkImage(
              imageUrl: imageUrl,
              placeholder: (_, __) => DefaultImagePlaceholder(),
              errorWidget: (_, __, ___) => _NamePlaceholder(
                placeholderText: placeholderText,
              ),
            ),
    );
  }
}

class _NamePlaceholder extends StatelessWidget {
  const _NamePlaceholder({
    Key? key,
    required this.placeholderText,
  }) : super(key: key);

  final String placeholderText;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: context.appTheme.borderColor.withOpacity(0.5),
        ),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          placeholderText,
          style: mpHeadLine5(
            context: context,
            textColor: context.appTheme.activeIndicationColor,
          ),
        ),
      ),
    );
  }
}

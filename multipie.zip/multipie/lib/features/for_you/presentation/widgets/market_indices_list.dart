import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_stocks_to_explore.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:provider/src/provider.dart';

class MarketIndicesList extends StatelessWidget {
  const MarketIndicesList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 132,
        child: Builder(
          builder: (context) {
            if (cubit.state.isLoadingMarketIndices && cubit.state.marketIndices.isEmpty) {
              return Center(child: MPLoadingIndicator());
            } else if (!cubit.state.isLoadingMarketIndices && cubit.state.marketIndices.isEmpty) {
              return _EmptyListPlaceholder();
            } else {
              return _IndicesList();
            }
          },
        ),
      ),
    );
  }
}

class _IndicesList extends StatelessWidget {
  const _IndicesList({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Row(
            children: buildMarketIndicesWidgets(
              cubit.state.marketIndices.take(2),
            ),
          ),
          SizedBox(height: 12),
          _ViewAllButton(),
        ],
      ),
    );
  }
}

class _EmptyListPlaceholder extends StatelessWidget {
  const _EmptyListPlaceholder({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Not Available',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _ViewAllButton extends StatelessWidget {
  const _ViewAllButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        CleverTapPlugin.recordEvent(
          'More Indices',
          {'source': 'For you'},
        );
        showModalBottomSheet(
          backgroundColor: context.appTheme.cardBackgroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(15.0)),
          ),
          context: context,
          builder: (context) {
            return DraggableScrollableSheet(
              initialChildSize: 0.95,
              maxChildSize: 0.95,
              builder: (context, controller) {
                final cubit = context.read<ForYouCubit>();
                return AllMarketIndicesList(
                  markets: cubit.state.marketIndices,
                  controller: controller,
                );
              },
              expand: false,
            );
          },
          isScrollControlled: true,
        );
      },
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                border: Border.all(
                  color: context.appTheme.secondaryColor,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'View More',
                textAlign: TextAlign.center,
                style: mpHeadLine5(
                  context: context,
                  textColor: context.appTheme.secondaryColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

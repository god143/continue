import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:url_launcher/url_launcher.dart';

class KnowledgeHubSection extends StatelessWidget {
  const KnowledgeHubSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: Row(
          children: [
            Expanded(
              child: _ItemWidget(
                title: 'Fresh from Multipie',
                subTitle: 'BLOGS',
                imageName: 'assets/images/blogs_illustration.png',
                backgroundColor: context.appTheme.positiveGainColor.withOpacity(0.1),
                onTap: () {
                  CleverTapPlugin.recordEvent('Blogs', {
                    'source': 'For you',
                  });
                  launch(
                    'https://www.multipie.co/blog/',
                    forceSafariVC: true,
                    forceWebView: true,
                  );
                },
              ),
            ),
            SizedBox(width: 24),
            Expanded(
              child: _ItemWidget(
                title: 'General Knowledge',
                subTitle: 'FAQs',
                imageName: 'assets/images/faq_illustration.png',
                backgroundColor: context.appTheme.negativeGainColor.withOpacity(0.1),
                onTap: () {
                  CleverTapPlugin.recordEvent('FAQs', {
                    'source': 'For you',
                  });
                  launch(
                    'https://faq.multipie.co/',
                    forceSafariVC: true,
                    forceWebView: true,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ItemWidget extends StatelessWidget {
  const _ItemWidget({
    Key? key,
    required this.title,
    required this.subTitle,
    required this.onTap,
    required this.imageName,
    required this.backgroundColor,
  }) : super(key: key);

  final String title;
  final String subTitle;
  final Color backgroundColor;
  final String imageName;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 120,
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          color: backgroundColor,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    subTitle,
                    style: mpHeadLine7(context: context),
                  ),
                  SizedBox(height: 4),
                  Text(
                    title,
                    style: mpHeadLine4(
                      context: context,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 2),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: SizedBox(
                width: 45,
                height: 45,
                child: Image.asset(
                  imageName,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

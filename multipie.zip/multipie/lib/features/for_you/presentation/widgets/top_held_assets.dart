import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/images_path.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/core/widgets/mp_avatar.dart';
import 'package:multipie/features/explore/presentation/screens/top_held_mf_screen.dart';
import 'package:multipie/features/explore/presentation/widgets/mutual_fund_screen.dart';
import 'package:multipie/features/for_you/domain/models/asset_type.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/features/market/presentation/screens/top_held_stocks/top_held_stocks_screen.dart';
import 'package:multipie/screens/company_screen/company_info_screen.dart';
import 'package:multipie/services/navigation_service.dart';
import 'package:provider/src/provider.dart';

class TopHeldAssets extends StatelessWidget {
  const TopHeldAssets({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    final showViewAllButton =
        (cubit.state.selectedAssetTypeFilter == AssetType.stock && cubit.state.topHeldStocks.isNotEmpty) ||
            (cubit.state.selectedAssetTypeFilter == AssetType.mutualFund && cubit.state.topHeldMFs.isNotEmpty);

    return SliverList(
      delegate: SliverChildListDelegate(
        [
          _AssetTypeSelector(),
          SizedBox(height: 12),
          _AssetsList(),
          if (showViewAllButton)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: _ViewAllAssetsButton(),
            ),
        ],
      ),
    );
  }
}

class _AssetTypeSelector extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Wrap(
        spacing: 12,
        children: [
          AssetType.stock,
          AssetType.mutualFund,
        ]
            .map(
              (e) => _AssetChoiceItem(
                assetType: e,
                isSelected: cubit.state.selectedAssetTypeFilter == e,
              ),
            )
            .toList(growable: false),
      ),
    );
  }
}

class _AssetChoiceItem extends StatelessWidget {
  const _AssetChoiceItem({
    Key? key,
    required this.assetType,
    required this.isSelected,
  }) : super(key: key);

  final AssetType assetType;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => context.read<ForYouCubit>().onTopHeldAssetTypeSelected(assetType),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? context.appTheme.primaryColor.withOpacity(0.15) : null,
          borderRadius: BorderRadius.circular(8),
          border: isSelected
              ? null
              : Border.all(
                  color: context.appTheme.borderColor,
                  width: 0.5,
                ),
        ),
        child: Text(
          title,
          style: mpHeadLine6(
            context: context,
            textColor: isSelected ? context.appTheme.primaryColor : context.appTheme.secondaryTextColor,
          ),
        ),
      ),
    );
  }

  String get title {
    switch (assetType) {
      case AssetType.stock:
        return 'Stocks';
      case AssetType.mutualFund:
        return 'Mutual Funds';
    }
  }
}

class _AssetsList extends StatelessWidget {
  const _AssetsList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 12),
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        border: Border.all(
          color: context.appTheme.borderColor,
          width: 0.5,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          if (cubit.state.selectedAssetTypeFilter == AssetType.stock)
            _StocksList()
          else if (cubit.state.selectedAssetTypeFilter == AssetType.mutualFund)
            _MutualFundsList(),
        ],
      ),
    );
  }
}

class _StocksList extends StatelessWidget {
  const _StocksList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    if (cubit.state.isLoadingTopHeldStocks && cubit.state.topHeldStocks.isEmpty) {
      return _LoadingPlaceholder();
    } else if (!cubit.state.isLoadingTopHeldStocks && cubit.state.topHeldStocks.isEmpty) {
      return _EmptyPlaceHolder();
    } else {
      return Column(
        children: cubit.state.topHeldStocks
            .take(3)
            .map(
              (e) => _ListTile(
                title: e.name,
                imageUrl: e.iconUrl,
                onTap: () {
                  validateOnboardingCompleted(
                    context: context,
                    validationErrorDialogTitle: 'Want to see this?',
                    onValidationSuccess: () => Navigate.push(
                      context,
                      CompanyInfoScreen(
                        companyId: e.id,
                        companyName: e.displayName ?? '',
                      ),
                    ),
                  );
                },
              ),
            )
            .toList(growable: false),
      );
    }
  }
}

class _MutualFundsList extends StatelessWidget {
  const _MutualFundsList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    if (cubit.state.isLoadingTopHeldMFs && cubit.state.topHeldMFs.isEmpty) {
      return _LoadingPlaceholder();
    } else if (!cubit.state.isLoadingTopHeldMFs && cubit.state.topHeldMFs.isEmpty) {
      return _EmptyPlaceHolder();
    } else {
      return Column(
        children: cubit.state.topHeldMFs
            .take(3)
            .map(
              (e) => _ListTile(
                title: e.name,
                imageUrl: '${Constants.API_MF_IMAGE_URL}${e.iconUrl}',
                onTap: () {
                  validateOnboardingCompleted(
                    context: context,
                    validationErrorDialogTitle: 'Want to see this?',
                    onValidationSuccess: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MutualFundScreen(
                          mutualFundId: e.id,
                          mutualFundName: e.name,
                        ),
                      ),
                    ),
                  );
                },
              ),
            )
            .toList(growable: false),
      );
    }
  }
}

class _ListTile extends StatelessWidget {
  const _ListTile({
    Key? key,
    required this.title,
    required this.imageUrl,
    required this.onTap,
  }) : super(key: key);

  final String title;
  final String imageUrl;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      horizontalTitleGap: 4,
      visualDensity: VisualDensity.compact,
      leading: MPAvatar(
        imageUrl: imageUrl,
        placeholderText: title.characters.take(1).toString(),
        size: 30,
      ),
      title: Text(
        title,
        style: mpHeadLine5(
          context: context,
          fontWeight: FontWeight.bold,
        ),
      ),
      trailing: SvgPicture.asset(
        icArrowRight,
        color: context.appTheme.borderColor,
      ),
      onTap: onTap,
    );
  }
}

class _EmptyPlaceHolder extends StatelessWidget {
  const _EmptyPlaceHolder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Not Available',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _LoadingPlaceholder extends StatelessWidget {
  const _LoadingPlaceholder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 150,
      child: DefaultImagePlaceholder(),
    );
  }
}

class _ViewAllAssetsButton extends StatelessWidget {
  const _ViewAllAssetsButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        validateOnboardingCompleted(
          context: context,
          validationErrorDialogTitle: 'Want to see more?',
          onValidationSuccess: () {
            final cubit = context.read<ForYouCubit>();
            switch (cubit.state.selectedAssetTypeFilter) {
              case AssetType.stock:
                CleverTapPlugin.recordEvent('Top Stocks See More Clicked', {
                  'source': 'For you text',
                });
                Navigate.push(
                  context,
                  TopHeldStockScreen(
                    listData: cubit.state.topHeldStocks,
                  ),
                );
                break;
              case AssetType.mutualFund:
                CleverTapPlugin.recordEvent('Top Mutual Funds See More Clicked', {
                  'source': 'For you text',
                });
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => TopHeldMutualFundsScreen(
                      listData: cubit.state.topHeldMFs,
                    ),
                  ),
                );
                break;
            }
          },
        );
      },
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                border: Border.all(
                  color: context.appTheme.secondaryColor,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'See all top held assets',
                textAlign: TextAlign.center,
                style: mpHeadLine5(
                  context: context,
                  textColor: context.appTheme.secondaryColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

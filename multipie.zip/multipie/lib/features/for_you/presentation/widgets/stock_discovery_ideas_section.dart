import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class StockDiscoveryIdeasSection extends StatelessWidget {
  const StockDiscoveryIdeasSection({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
      ),
      sliver: SliverToBoxAdapter(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Stock Discovery Ideas',
              style: mpHeadLine3(
                context: context,
                fontWeight: FontWeight.w500,
                textColor: context.appTheme.activeIndicationColor,
              ),
            ),
            SizedBox(height: 8),
            Text(
              "A journey of a thousand miles starts with a single step, a starting point. The Multipie Community hopes to give you that starting point, help you find your next big idea. Here's whats brewing.",
              style: mpHeadLine5(
                context: context,
                textColor: context.appTheme.primaryTextColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

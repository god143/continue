import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/core/widgets/html_text.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/market/presentation/widgets/company_news/detailed_news_item.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/custom_bottom_sheet.dart';
import 'package:provider/src/provider.dart';

class NewsList extends StatelessWidget {
  const NewsList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: _List(),
      ),
    );
  }
}

class _List extends StatelessWidget {
  const _List({Key? key}) : super(key: key);

  final _maxChars = 100;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    if (cubit.state.isLoadingNews && cubit.state.news.isEmpty) {
      return _LoadingPlaceholder();
    } else if (!cubit.state.isLoadingNews && cubit.state.news.isEmpty) {
      return _EmptyPlaceHolder();
    } else {
      return Column(
        children: cubit.state.news.take(10).map(
          (item) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                ListTile(
                  onTap: () {
                    showCustomBottomSheet(
                      child: DetailedNewsItem(item), //ToSell True
                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                      context: context,
                    );
                  },
                  title: item.heading != null
                      ? Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Text(
                            item.heading!,
                            maxLines: 2,
                            style: mpHeadLine5(
                              context: context,
                              textColor: context.appTheme.primaryTextColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        )
                      : null,
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          if (item.dATE != null)
                            Text(
                              DateTime.tryParse(item.dATE!)?.format('dd MMM').toUpperCase() ?? '',
                              style: mpHeadLine6(
                                context: context,
                                textColor: context.appTheme.secondaryTextColor,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: MPHTMLText(
                          data: (item.arttext ?? '').length < _maxChars
                              ? item.arttext ?? ''
                              : item.arttext!.substring(0, _maxChars) + "...",
                          bodyPadding: EdgeInsets.zero,
                          bodyMargin: EdgeInsets.zero,
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 2),
                Container(height: 0.5, color: context.appTheme.borderColor),
              ],
            );
          },
        ).toList(growable: false),
      );
    }
  }
}

class _EmptyPlaceHolder extends StatelessWidget {
  const _EmptyPlaceHolder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Please add some stocks to your watchlist or portfolio first!',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _LoadingPlaceholder extends StatelessWidget {
  const _LoadingPlaceholder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        3,
        (_) => ListTile(
          title: Row(
            children: [
              Container(
                width: 80,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                ),
                clipBehavior: Clip.hardEdge,
                child: DefaultImagePlaceholder(),
              ),
            ],
          ),
          subtitle: Row(
            children: [
              Container(
                width: 150,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                ),
                clipBehavior: Clip.hardEdge,
                child: DefaultImagePlaceholder(),
              ),
            ],
          ),
        ),
      ).toList(growable: false),
    );
  }
}

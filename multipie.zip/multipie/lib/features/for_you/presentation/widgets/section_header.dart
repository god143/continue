import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class SectionHeader extends StatelessWidget {
  const SectionHeader({
    Key? key,
    required this.title,
    this.trailing,
  }) : super(key: key);

  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: mpHeadLine4(
                  context: context,
                  fontWeight: FontWeight.w500,
                  textColor: context.appTheme.activeIndicationColor,
                ),
              ),
            ),
            if (trailing != null) ...[
              SizedBox(width: 12),
              trailing!,
            ]
          ],
        ),
      ),
    );
  }
}

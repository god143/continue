import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/screens/company_screen/company_info_screen.dart';
import 'package:multipie/services/navigation_service.dart';

class MostTalkedStocksList extends StatelessWidget {
  const MostTalkedStocksList({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 56,
        child: Builder(
          builder: (context) {
            if (cubit.state.isLoadingMostTalkedStocks && cubit.state.mostTalkedStocks.isEmpty) {
              return _PlaceholderTiles();
            } else if (!cubit.state.isLoadingMostTalkedStocks && cubit.state.mostTalkedStocks.isEmpty) {
              return _EmptyListPlaceholder();
            } else {
              return _StocksList();
            }
          },
        ),
      ),
    );
  }
}

class _StocksList extends StatelessWidget {
  const _StocksList({
    Key? key,
  }) : super(key: key);

  final _minTileWidth = 180.0;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return ListView.builder(
      itemBuilder: (context, index) {
        final stock = cubit.state.mostTalkedStocks[index];
        return Padding(
          padding: EdgeInsets.only(
            left: index == 0 ? 16 : 8,
            right: index == cubit.state.mostTalkedStocks.length - 1 ? 16 : 8,
          ),
          child: InkWell(
            onTap: () {
              validateOnboardingCompleted(
                context: context,
                validationErrorDialogTitle: 'Want to see this?',
                onValidationSuccess: () => Navigate.push(
                  context,
                  CompanyInfoScreen(
                    companyId: stock.id,
                    companyName: stock.displayName ?? '',
                  ),
                ),
              );
            },
            child: Container(
              constraints: BoxConstraints(
                minWidth: _minTileWidth,
              ),
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                border: Border.all(
                  color: context.appTheme.borderColor.withOpacity(0.5),
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    stock.name,
                    style: mpHeadLine5(
                      context: context,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '${stock.mentionsCount ?? 0} Post mentions',
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.secondaryTextColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
      itemCount: cubit.state.mostTalkedStocks.length,
      scrollDirection: Axis.horizontal,
    );
  }
}

class _EmptyListPlaceholder extends StatelessWidget {
  const _EmptyListPlaceholder({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Not Available',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _PlaceholderTiles extends StatelessWidget {
  const _PlaceholderTiles({
    Key? key,
  }) : super(key: key);

  final double _tileWidth = 180;

  @override
  Widget build(BuildContext context) {
    return ListView(
      scrollDirection: Axis.horizontal,
      physics: NeverScrollableScrollPhysics(),
      children: [
        SizedBox(width: 16),
        SizedBox(
          width: _tileWidth,
          child: _PlaceholderTile(),
        ),
        SizedBox(width: 16),
        SizedBox(
          width: _tileWidth,
          child: DefaultImagePlaceholder(),
        ),
        SizedBox(width: 16),
        SizedBox(
          width: _tileWidth,
          child: DefaultImagePlaceholder(),
        ),
        SizedBox(width: 16),
      ],
    );
  }
}

class _PlaceholderTile extends StatelessWidget {
  const _PlaceholderTile({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: DefaultImagePlaceholder(),
    );
  }
}

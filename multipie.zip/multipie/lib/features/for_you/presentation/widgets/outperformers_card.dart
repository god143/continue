import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/for_you/presentation/screens/outperformers_sceen.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/services/navigation_service.dart';

class OutperformersCard extends StatelessWidget {
  const OutperformersCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: IntrinsicHeight(
          child: InkWell(
            onTap: () {
              validateOnboardingCompleted(
                context: context,
                validationErrorDialogTitle: 'Want to see top outperformers?',
                onValidationSuccess: () {
                  CleverTapPlugin.recordEvent('Multipie Leaderboard', {
                    'source': 'For you',
                  });
                  Navigate.push(context, OutperformersScreen());
                },
              );
            },
            child: Container(
              decoration: BoxDecoration(
                color: context.appTheme.positiveGainColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: context.appTheme.positiveGainColor.withOpacity(0.5), width: 0.5),
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'Multipie outperformers',
                            style: mpHeadLine4(
                              context: context,
                              textColor: context.appTheme.primaryTextColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text('Discover who is crushing it.\nYou may be next!',
                              style: mpHeadLine5(
                                context: context,
                                textColor: context.appTheme.primaryTextColor,
                                fontWeight: FontWeight.normal,
                              )),
                          SizedBox(height: 12),
                          Row(
                            children: [
                              Text(
                                'SEE ALL OUTPERFORMERS',
                                style: mpHeadLine6(
                                  context: context,
                                  textColor: context.appTheme.secondaryColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(width: 4),
                              SvgPicture.asset(
                                'assets/icons/Arrow_Next.svg',
                                width: 4,
                                height: 8,
                                color: context.appTheme.secondaryColor,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: Image.asset(
                      'assets/images/outperformers_illustration.png',
                      height: 120,
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

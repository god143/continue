import 'package:flutter/material.dart';

void validateOnboardingCompleted({
  required BuildContext context,
  required String validationErrorDialogTitle,
  required VoidCallback onValidationSuccess,
}) {
  onValidationSuccess();
  return;

  /// MF-845: Don't show popup at all
  ///
  /* final currentUser = BlocProvider.of<UserProfileBloc>(context).currentUser;
  if (currentUser?.chosenUsername == false) {
    showProfileCompletionBottomSheet(
      context: context,
      child: ProfileCompletionDialog(
        title: validationErrorDialogTitle,
        text: "Let’s complete your account setup for a more personalized experience.",
        primaryFunction: () {},
        secondaryFunction: () {},
        primaryButtonText: "SURE",
      ),
    );
  } else {
    onValidationSuccess();
  } */
}

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/common.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:provider/provider.dart';

class ExternalLinksList extends StatelessWidget {
  const ExternalLinksList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 130,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: cubit.state.externalLinks.length,
          itemBuilder: (context, index) {
            final model = cubit.state.externalLinks[index];
            String? bannerUrl;
            if (model.bannerImageUrl != null) {
              bannerUrl = '${Constants.BASE_URL}${model.bannerImageUrl!}';
            }
            final isFirst = index == 0;
            final isLast = index == cubit.state.externalLinks.length - 1;
            return Padding(
              padding: EdgeInsets.only(
                left: isFirst ? 16 : 8,
                right: isLast ? 16 : 8,
              ),
              child: GestureDetector(
                onTap: () async {
                  if (model.redirectUrl != null) {
                    launchURL(model.redirectUrl!);
                  }
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 200,
                      height: 100,
                      child: bannerUrl != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: CachedNetworkImage(
                                imageUrl: bannerUrl,
                                placeholder: (_, __) => DefaultImagePlaceholder(),
                                errorWidget: (_, __, ___) => DefaultImagePlaceholder(),
                                fit: BoxFit.cover,
                              ),
                            )
                          : SizedBox(),
                    ),
                    SizedBox(height: 8),
                    Text(
                      model.title,
                      style: mpHeadLine6(
                        context: context,
                        textColor: context.appTheme.primaryTextColor,
                      ),
                      maxLines: 1,
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

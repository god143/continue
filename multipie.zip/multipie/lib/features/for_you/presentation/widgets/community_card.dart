import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/screens/nav_screen/nav_screen.dart';

class CommunityCard extends StatelessWidget {
  const CommunityCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: IntrinsicHeight(
          child: InkWell(
            onTap: () {
              validateOnboardingCompleted(
                context: context,
                validationErrorDialogTitle: 'Want to see this?',
                onValidationSuccess: () {
                  CleverTapPlugin.recordEvent('Multipie Community', {
                    'source': 'For you',
                  });
                  mainNavKey.currentState?.navigateToCommunity();
                },
              );
            },
            child: Container(
              decoration: BoxDecoration(
                color: context.appTheme.positiveGainColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: context.appTheme.positiveGainColor.withOpacity(0.5), width: 0.5),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'HERE’S A SECRET',
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.communityCardHeaderColor,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Smart investors',
                            style: mpHeadLine3(
                              context: context,
                              textColor: context.appTheme.primaryTextColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'like to hang out with other investors',
                            style: mpHeadLine5(
                              context: context,
                              textColor: context.appTheme.primaryTextColor,
                              fontWeight: FontWeight.normal,
                            ).copyWith(fontStyle: FontStyle.italic),
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Text(
                                'MULTIPIE COMMUNITY',
                                style: mpHeadLine6(
                                  context: context,
                                  textColor: context.appTheme.secondaryColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(width: 4),
                              SvgPicture.asset(
                                'assets/icons/Arrow_Next.svg',
                                width: 4,
                                height: 8,
                                color: context.appTheme.secondaryColor,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.asset(
                          'assets/images/community_card_bg_illustrations.png',
                          fit: BoxFit.cover,
                        ),
                        Center(
                          child: Image.asset(
                            'assets/images/community_card_fg_illustrations.png',
                            fit: BoxFit.contain,
                            width: 135,
                            height: 87,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/core/widgets/mp_avatar.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/screens/celebrity_portfolios_screen.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/new_profile_screen.dart';
import 'package:multipie/features/profile/presentation/widgets/follow_unfollow_widget.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:provider/src/provider.dart';

class CelebritiesList extends StatelessWidget {
  const CelebritiesList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: _List(),
      ),
    );
  }
}

class _List extends StatelessWidget {
  const _List({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    if (cubit.state.isLoadingCelebrities && cubit.state.celebrities.isEmpty) {
      return _LoadingPlaceholder();
    } else if (!cubit.state.isLoadingCelebrities && cubit.state.celebrities.isEmpty) {
      return _EmptyPlaceHolder();
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4.0),
            child: Text(
              'Find out where the Superstars are investing.',
              style: mpHeadLine6(context: context, textColor: context.appTheme.secondaryTextColor),
            ),
          ),
          ...cubit.state.celebrities.take(3).map(
            (celebrity) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CelebrityListTile(celebrity: celebrity),
                  SizedBox(height: 2),
                  Container(height: 0.5, color: context.appTheme.borderColor),
                ],
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: _ViewAllButton(),
          )
        ],
      );
    }
  }
}

class CelebrityListTile extends StatelessWidget {
  const CelebrityListTile({
    Key? key,
    required this.celebrity,
  }) : super(key: key);

  final User celebrity;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: MPAvatar(
        imageUrl: celebrity.dpThumbnail,
        placeholderText: celebrity.displayname.characters.take(1).toString(),
        size: 44,
        isCircular: true,
      ),
      title: Padding(
        padding: const EdgeInsets.only(bottom: 4.0),
        child: Text(
          celebrity.displayname,
          style: mpHeadLine5(
            context: context,
            textColor: context.appTheme.primaryColor,
          ),
        ),
      ),
      subtitle: Text(
        _formattedHoldingsWithValuation,
        style: mpHeadLine5(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
      trailing: SizedBox(
        height: 32,
        child: FollowUnFollowButton(
          data: celebrity,
          width: 110,
          fontSize: 'mp4',
          radius: 10,
        ),
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NewProfileScreen(
              userId: celebrity.id,
            ),
          ),
        );
      },
    );
  }

  String get _formattedHoldingsWithValuation {
    final valuationInCr = (celebrity.holdingsValue ?? 0) / 10000000;
    final value = currencyFormatPortfolio(valuationInCr.toString(), showRupeeSymbol: true);
    return '$value Cr | ${celebrity.holdingsCount ?? 0} Stocks';
  }
}

class _EmptyPlaceHolder extends StatelessWidget {
  const _EmptyPlaceHolder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Not Available',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _LoadingPlaceholder extends StatelessWidget {
  const _LoadingPlaceholder({Key? key}) : super(key: key);

  final _avatarSize = 36.0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        3,
        (_) => ListTile(
          leading: SizedBox(
            width: _avatarSize,
            height: _avatarSize,
            child: DefaultImagePlaceholder(),
          ),
          title: Row(
            children: [
              Container(
                width: 80,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                ),
                clipBehavior: Clip.hardEdge,
                child: DefaultImagePlaceholder(),
              ),
            ],
          ),
          subtitle: Row(
            children: [
              Container(
                width: 150,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                ),
                clipBehavior: Clip.hardEdge,
                child: DefaultImagePlaceholder(),
              ),
            ],
          ),
        ),
      ).toList(growable: false),
    );
  }
}

class _ViewAllButton extends StatelessWidget {
  const _ViewAllButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        final cubit = context.read<ForYouCubit>();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CelebrityPortfoliosScreen(
              celebrities: cubit.state.celebrities,
            ),
          ),
        );
      },
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                border: Border.all(
                  color: context.appTheme.secondaryColor,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'View More',
                textAlign: TextAlign.center,
                style: mpHeadLine5(
                  context: context,
                  textColor: context.appTheme.secondaryColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class ToggleDurationButton extends StatelessWidget {
  const ToggleDurationButton({
    Key? key,
    required this.value,
    required this.onPressed,
  }) : super(key: key);

  final String value;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all<Color>(
          context.appTheme.blueShadeColor.withOpacity(0.2),
        ),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        padding: MaterialStateProperty.all<EdgeInsets>(
          EdgeInsets.symmetric(horizontal: 20),
        ),
        shape: MaterialStateProperty.all<OutlinedBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        visualDensity: VisualDensity.compact,
      ),
      child: Row(
        children: [
          Text(
            value,
            style: mpHeadLine5(
              context: context,
              textColor: context.appTheme.blueShadeColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(width: 4),
          Image.asset(
            'assets/images/exchange.png',
            color: context.appTheme.blueShadeColor,
            width: 12,
            height: 12,
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/default_image_placeholder.dart';
import 'package:multipie/core/widgets/mp_avatar.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/features/for_you/presentation/widgets/toggle_duration_button.dart';
import 'package:multipie/screens/company_screen/company_info_screen.dart';
import 'package:multipie/services/navigation_service.dart';
import 'package:provider/src/provider.dart';

class MostWatchedStocksList extends StatelessWidget {
  const MostWatchedStocksList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: _StocksList(),
      ),
    );
  }
}

class _StocksList extends StatelessWidget {
  const _StocksList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    if (cubit.state.isLoadingMostWatchedStocks && cubit.state.mostWatchedStocks.isEmpty) {
      return _LoadingPlaceholder();
    } else if (!cubit.state.isLoadingMostWatchedStocks && cubit.state.mostWatchedStocks.isEmpty) {
      return _EmptyPlaceHolder();
    } else {
      return Column(
        children: cubit.state.mostWatchedStocks.take(3).map(
          (stock) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                ListTile(
                  horizontalTitleGap: 8,
                  visualDensity: VisualDensity.compact,
                  leading: MPAvatar(
                    imageUrl: stock.iconUrl,
                    placeholderText: stock.name.characters.take(1).toString(),
                    size: 32,
                  ),
                  title: Row(
                    children: [
                      Expanded(
                        child: Text(
                          stock.nseTicker ?? '',
                          style: mpHeadLine5(
                            context: context,
                            textColor: context.appTheme.secondaryTextColor,
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Text(
                        stock.lastTradedPrice != null ? '₹${stock.lastTradedPrice}' : '-',
                        style: mpHeadLine5(
                          context: context,
                          textColor: context.appTheme.secondaryTextColor,
                        ),
                      ),
                    ],
                  ),
                  subtitle: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          stock.displayName ?? '',
                          style: mpHeadLine5(
                            context: context,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Text(
                        '${stock.change > 0 ? '+' : ''}'
                        '${stock.change == 0.0 ? '-' : stock.change}'
                        ' (${stock.percentChange == 0.0 ? '-' : stock.percentChange}%)',
                        textAlign: TextAlign.center,
                        style: mpHeadLine5(
                          context: context,
                          textColor: stock.change > 0
                              ? context.appTheme.positiveGainColor
                              : stock.change < 0
                                  ? context.appTheme.negativeGainColor
                                  : context.appTheme.primaryTextColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  onTap: () {
                    validateOnboardingCompleted(
                      context: context,
                      validationErrorDialogTitle: 'Want to see this?',
                      onValidationSuccess: () => Navigate.push(
                        context,
                        CompanyInfoScreen(
                          companyId: stock.id,
                          companyName: stock.displayName ?? '',
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 2),
                Container(height: 0.5, color: context.appTheme.borderColor),
              ],
            );
          },
        ).toList(growable: false),
      );
    }
  }
}

class _EmptyPlaceHolder extends StatelessWidget {
  const _EmptyPlaceHolder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Not Available',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
      ),
    );
  }
}

class _LoadingPlaceholder extends StatelessWidget {
  const _LoadingPlaceholder({Key? key}) : super(key: key);

  final _avatarSize = 36.0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        3,
        (_) => ListTile(
          leading: SizedBox(
            width: _avatarSize,
            height: _avatarSize,
            child: DefaultImagePlaceholder(),
          ),
          title: Row(
            children: [
              Container(
                width: 80,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                ),
                clipBehavior: Clip.hardEdge,
                child: DefaultImagePlaceholder(),
              ),
            ],
          ),
          subtitle: Row(
            children: [
              Container(
                width: 150,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                ),
                clipBehavior: Clip.hardEdge,
                child: DefaultImagePlaceholder(),
              ),
            ],
          ),
        ),
      ).toList(growable: false),
    );
  }
}

class MostWatchedStocksFilter extends StatelessWidget {
  const MostWatchedStocksFilter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return ToggleDurationButton(
      value: cubit.state.mostWatchedStocksPeriod,
      onPressed: () => cubit.toggleMostWatchedDuration(),
    );
  }
}

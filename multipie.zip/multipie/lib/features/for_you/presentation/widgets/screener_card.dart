import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/for_you/presentation/screens/stocks_screener_screen.dart';
import 'package:multipie/features/for_you/presentation/widgets/onboarding_validator.dart';
import 'package:multipie/services/navigation_service.dart';

class ScreenerCard extends StatelessWidget {
  const ScreenerCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverToBoxAdapter(
        child: IntrinsicHeight(
          child: Container(
            decoration: BoxDecoration(
              color: context.appTheme.screenerCardColor,
              borderRadius: BorderRadius.circular(4),
            ),
            child: InkWell(
              onTap: () {
                validateOnboardingCompleted(
                  context: context,
                  validationErrorDialogTitle: 'Want to see this?',
                  onValidationSuccess: () {
                    CleverTapPlugin.recordEvent('Stock Screener', {
                      'source': 'For you',
                    });
                    Navigate.push(context, StocksScreenerScreen());
                  },
                );
              },
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 16,
                      left: 16,
                      right: 94,
                      bottom: 16,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Text(
                              'Stock Screener',
                              style: mpHeadLine4(
                                context: context,
                                textColor: context.appTheme.activeIndicationColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(width: 4),
                            SvgPicture.asset(
                              'assets/icons/Arrow_Next.svg',
                              width: 4,
                              height: 8,
                              color: context.appTheme.activeIndicationColor,
                            ),
                          ],
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Research and filter stocks based on key parameters and metrics',
                          style: mpHeadLine6(context: context),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: -12,
                    right: 0,
                    child: SizedBox(
                      width: 78,
                      height: 78,
                      child: Image.asset(
                        'assets/images/screener_illustration.png',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/invite_friends/data/datasources/invite_remote_datasource.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/features/invite_friends/domain/entities/create_invite.dart';
import 'package:multipie/features/invite_friends/domain/repository/invite_repository.dart';

class InviteRepositoryImpl implements InviteRepository {
  final NetworkInfo networkInfo;
  final InviteRemoteDataSource inviteRemoteDataSource;

  InviteRepositoryImpl(
      {required this.networkInfo, required this.inviteRemoteDataSource});

  @override
  Future<Either<Failure, CreatedInviteRes>> createInvite(
      String inviteeMobile) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL =
            await inviteRemoteDataSource.createInviteRemoteData(inviteeMobile);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<InviteItem>>> getInvite(
      int page, int size) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL =
            await inviteRemoteDataSource.getInviteRemoteData(page, size);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, SuccessResponseModel>> verifyInvite(
      String invitee_mobile) async {
    if (await networkInfo.isConnected) {
      try {
        final remotePL = await inviteRemoteDataSource
            .getVerifyInviteRemoteData(invitee_mobile);
        return Right(remotePL);
      } on UnauthorisedException catch (e) {
        return Left(AuthFailure(e.message));
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

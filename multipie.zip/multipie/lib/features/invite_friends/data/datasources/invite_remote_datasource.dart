import 'dart:developer';

import 'package:japx/japx.dart';
import 'package:logging/logging.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/invite_friends/data/models/created_invite_model.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class InviteRemoteDataSource {
  Future<CreateInviteModel> createInviteRemoteData(String inviteeMobile);
  Future<List<InviteItem>> getInviteRemoteData(int page, int size);
  Future<SuccessResponseModel> getVerifyInviteRemoteData(String inviteeMobile);
}

class InviteRemoteDataSourceImpl implements InviteRemoteDataSource {
  final NetworkService networkService;

  InviteRemoteDataSourceImpl({required this.networkService});

  @override
  Future<CreateInviteModel> createInviteRemoteData(String inviteeMobile) async {
    final params = {"invite[invitee_mobile]": inviteeMobile};

    final jsonApi = await networkService.postRequest("/invites/create_invite",
        body: params, isAuth: true);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      log("Create Invite with Japx SST>> " + json.toString());

      return CreateInviteModel.fromJson(json);
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  @override
  Future<List<InviteItem>> getInviteRemoteData(int page, int size) async {
    final jsonApi =
        await networkService.getRequest("/contacts?page_size=$size&page=$page");
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      log("Invite Suggestions Updated with Japx SST>> " + json.toString());
      Iterable data = json['data'];
      return data.map((inviteData) => InviteItem.fromJson(inviteData)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  @override
  Future<SuccessResponseModel> getVerifyInviteRemoteData(
      String inviteeMobile) async {
    var jsonApi = await networkService.getRequest(
        '/invites/verify_invite?invitee_mobile=$inviteeMobile',
        isAuth: true);
    try {
      Logger("Invite Verification Response")
          .log(Level.FINE, jsonApi.toString());
      return SuccessResponseModel.fromJson(jsonApi);
    } catch (e) {
      print(e.toString());
      throw ServerException(e.toString());
    }
  }
}

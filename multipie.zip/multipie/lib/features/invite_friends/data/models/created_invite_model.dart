import 'package:multipie/features/invite_friends/domain/entities/create_invite.dart';

class CreateInviteModel extends CreatedInviteRes {
  CreateInviteModel({data, meta}) : super(data: data, meta: meta);

  factory CreateInviteModel.fromJson(Map<String, dynamic> json) {
    return CreateInviteModel(data: CreateInviteData.fromJson(json['data']), meta: Meta.fromJson(json['meta']));
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data;
    }
    if (this.meta != null) {
      data['meta'] = this.meta;
    }
    return data;
  }
}

class CreateInviteData extends CreatedInvite {
  CreateInviteData({
    id,
    type,
    created_at,
    invite_code,
    invite_link,
    invitee_email,
    referrer_id,
    remainingInvites,
  }) : super(
          createdAt: created_at,
          id: id,
          type: type,
          inviteCode: invite_code,
          inviteLink: invite_link,
          inviteeEmail: invitee_email,
          referrerId: referrer_id,
        );

  factory CreateInviteData.fromJson(Map<String, dynamic> json) {
    return CreateInviteData(
        id: json['id'].toString(),
        type: json['type'],
        invite_code: json['invite_code'],
        referrer_id: json['referrer_id'].toString(),
        invitee_email: json['invitee_email'],
        created_at: json['created_at'],
        invite_link: json['invite_link']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['type'] = this.type;
    data['invite_code'] = this.inviteCode;
    data['referrer_id'] = this.referrerId;
    data['invitee_email'] = this.inviteeEmail;
    data['created_at'] = this.createdAt;
    data['invite_link'] = this.inviteLink;
    return data;
  }
}

class Meta extends MetaItem {
  Meta({
    remainingInvites,
  }) : super(
          remainingInvites: remainingInvites,
        );

  factory Meta.fromJson(Map<String, dynamic> json) {
    return Meta(
      remainingInvites: json['remaining_invites'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['remaining_invites'] = this.remainingInvites;
    return data;
  }
}

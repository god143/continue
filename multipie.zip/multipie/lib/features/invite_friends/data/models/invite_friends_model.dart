import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/invite_friends/domain/entities/invite_friends.dart';

class ContactEntriesModel extends ContactEntry {
  ContactEntriesModel({
    id,
    fieldType,
    fieldLabel,
    fieldValue,
    inviteLink,
  }) : super(
          id: id,
          fieldType: fieldType,
          fieldLabel: fieldLabel,
          fieldValue: fieldValue,
          inviteLink: inviteLink,
        );

  factory ContactEntriesModel.fromJson(Map<String, dynamic> json) {
    return ContactEntriesModel(
      id: json['id'],
      fieldType: nullReview(json['field_type']),
      fieldLabel: nullReview(json['field_label']),
      fieldValue: nullReview(json['field_value']),
      inviteLink: nullReview(json['invite_link']),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['field_type'] = this.fieldType;
    data['field_label'] = this.fieldLabel;
    data['field_value'] = this.fieldValue;
    data['invite_link'] = this.inviteLink;
    return data;
  }
}

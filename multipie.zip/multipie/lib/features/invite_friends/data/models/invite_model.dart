import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/invite_friends/domain/entities/invite_friends.dart';

class InviteItem extends ContactItem {
  InviteItem({
    id,
    friendsCount,
    displayName,
    nickName,
    contactEntries,
    isInvited,
  }) : super(
          id: id,
          friendsCount: friendsCount,
          displayName: displayName,
          nickName: nickName,
          contactEntries: contactEntries,
          isInvited: isInvited,
        );

  factory InviteItem.fromJson(Map<String, dynamic> json) {
    return InviteItem(
      id: json['id'].toString(),
      friendsCount: json['friends_count'].toString(),
      displayName: nullReview(json['display_name']),
      nickName: nullReview(json['nick_name']),
      contactEntries:
          json['contact_entries'].map<inviteEntriesModel>((data) => inviteEntriesModel.fromJson(data)).toList(),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['friends_count'] = this.friendsCount;
    data['display_name'] = this.displayName;
    data['nick_name'] = this.nickName;
    if (this.contactEntries != null) {
      data['contact_entries'] = this.contactEntries.map((v) => v.props).toList();
    }
    return data;
  }
}

class inviteEntriesModel extends ContactEntry {
  inviteEntriesModel({id, fieldType, fieldLabel, fieldValue, inviteLink, inviteUsedBy})
      : super(
          id: id,
          fieldType: fieldType,
          fieldLabel: fieldLabel,
          fieldValue: fieldValue,
          inviteLink: inviteLink,
        );

  factory inviteEntriesModel.fromJson(Map<String, dynamic> json) {
    var inviteJson = json['invite'];
    return inviteEntriesModel(
      id: json['id'].toString(),
      fieldType: nullReview(json['field_type']),
      fieldLabel: nullReview(json['field_label']),
      fieldValue: nullReview(json['field_value']),
      inviteLink: inviteJson != null ? inviteJson['attributes']['invite_link'] : '',
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['field_type'] = this.fieldType;
    data['field_label'] = this.fieldLabel;
    data['field_value'] = this.fieldValue;
    data['invite_link'] = this.inviteLink;

    return data;
  }
}

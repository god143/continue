import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/features/invite_friends/domain/repository/invite_repository.dart';

class GetInviteUsecase extends UseCase<void, Params> {
  final InviteRepository repository;

  GetInviteUsecase(this.repository);

  @override
  Future<Either<Failure, List<InviteItem>>> call(Params params) {
    return repository.getInvite(params.page, params.size);
  }
}

class Params extends Equatable {
  final int page;
  final int size;

  Params({required this.page, required this.size});

  @override
  List<Object> get props => [page, size];
}

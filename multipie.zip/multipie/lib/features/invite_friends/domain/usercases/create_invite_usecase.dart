import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/invite_friends/domain/entities/create_invite.dart';
import 'package:multipie/features/invite_friends/domain/repository/invite_repository.dart';

class CreateInviteUsecase extends UseCase<CreatedInviteRes, Params> {
  final InviteRepository repository;

  CreateInviteUsecase(this.repository);

  @override
  Future<Either<Failure, CreatedInviteRes>> call(Params params) {
    return repository.createInvite(params.inviteeMobile);
  }
}

class VerifyInviteUseCase implements UseCase<SuccessResponseModel, Params> {
  final InviteRepository repository;

  VerifyInviteUseCase(this.repository);

  @override
  Future<Either<Failure, SuccessResponseModel>> call(Params params) {
    return repository.verifyInvite(params.inviteeMobile);
  }
}

class Params extends Equatable {
  final String inviteeMobile;

  Params({required this.inviteeMobile});

  @override
  List<Object> get props => [inviteeMobile];
}

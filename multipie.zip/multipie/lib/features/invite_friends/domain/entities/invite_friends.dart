import 'package:equatable/equatable.dart';

class ContactItem extends Equatable {
  final String displayName;
  final String nickName;
  final String friendsCount;
  final String id;
  bool? isInvited;
  final List<ContactEntry> contactEntries;

  ContactItem({
    required this.id,
    required this.displayName,
    required this.nickName,
    required this.friendsCount,
    required this.contactEntries,
    required this.isInvited,
  });

  @override
  List<Object> get props => [id, displayName, nickName, friendsCount, contactEntries, this.isInvited!];
}

class ContactEntry extends Equatable {
  final String fieldType;
  final String fieldLabel;
  final String fieldValue;
  final String? id;
  final String? inviteLink;

  ContactEntry({
    required this.id,
    required this.fieldType,
    required this.fieldLabel,
    required this.fieldValue,
    required this.inviteLink,
  });

  @override
  List<Object> get props => [id!, fieldType, fieldLabel, fieldValue, inviteLink!];
}

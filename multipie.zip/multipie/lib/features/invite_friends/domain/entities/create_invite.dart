import 'package:equatable/equatable.dart';

class CreatedInviteRes extends Equatable {
  CreatedInvite data;
  MetaItem meta;

  CreatedInviteRes({
    required this.data,
    required this.meta,
  });

  @override
  List<Object> get props => [data, meta];
}

class CreatedInvite extends Equatable {
  String id;
  String? type;
  String inviteCode;
  String referrerId;
  String? inviteeEmail;
  String createdAt;
  String inviteLink;

  CreatedInvite({
    required this.id,
    required this.type,
    required this.inviteCode,
    required this.referrerId,
    required this.inviteeEmail,
    required this.createdAt,
    required this.inviteLink,
  });

  @override
  List<Object> get props => [id, type!, inviteCode, referrerId, inviteeEmail!, createdAt, inviteLink];
}

class MetaItem extends Equatable {
  int remainingInvites;

  MetaItem({
    required this.remainingInvites,
  });

  @override
  List<Object> get props => [remainingInvites];
}

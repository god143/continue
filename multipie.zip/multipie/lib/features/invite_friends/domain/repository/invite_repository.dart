import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/features/invite_friends/domain/entities/create_invite.dart';

abstract class InviteRepository {
  Future<Either<Failure, CreatedInviteRes>> createInvite(String inviteeMobile);

  Future<Either<Failure, List<InviteItem>>> getInvite(int page, int size);

  Future<Either<Failure, SuccessResponseModel>> verifyInvite(String invitee_mobile);
}

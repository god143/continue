import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/common.dart';
import 'package:multipie/core/utils/share_util.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/features/invite_friends/presentation/post_create_invite/bloc.dart';
import 'package:multipie/core/utils/extensions.dart';

String clickedInviteId = "";

class InviteShareButton extends StatefulWidget {
  final InviteItem data;
  final String hasInviteLink;
  final int invitesRemaining;
  final String mobileNo;
  final double width;
  final double radius;
  final String fontSize;
  final Function callback;

  const InviteShareButton({
    required this.data,
    required this.hasInviteLink,
    required this.invitesRemaining,
    required this.mobileNo,
    required this.width,
    required this.radius,
    required this.fontSize,
    required this.callback,
  });

  @override
  _InviteShareButtonState createState() => _InviteShareButtonState();
}

class _InviteShareButtonState extends State<InviteShareButton> {
  FollowEvent followEvent = FollowEvent.invite;
  String textShare = '';

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    textShare = "Hey ${widget.data.displayName}, Join me on Multipie. "
        "Get answers to all your questions on investing and tap into great insights."
        "\n\nUse your exclusive invite";

    followEvent = (widget.hasInviteLink.isNotEmpty || (widget.data.isInvited ?? false))
        ? FollowEvent.invited
        : FollowEvent.invite;

    return BlocConsumer<CreateInviteBloc, CreateInviteState>(
      builder: (context, state) => followEvent == FollowEvent.invited
          ? Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Text(
                  'Share Invite',
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: mpHeadLine7(
                    context: context,
                    textColor: context.appTheme.secondaryTextColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4.0),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          if (state is Loaded) {
                            final String urlToShare =
                                "https://wa.me/${widget.mobileNo.replaceAll(" ", '')}?text=$textShare\n${state.inviteRes.data.inviteLink}";
                            final Uri url = Uri.parse(urlToShare);
                            launchURL(url.toString());
                          } else if (widget.hasInviteLink.isNotEmpty) {
                            final String urlToShare =
                                "https://wa.me/${widget.mobileNo.replaceAll(" ", '')}?text=$textShare\n${widget.hasInviteLink}";
                            final Uri url = Uri.parse(urlToShare);
                            launchURL(url.toString());
                          }
                        },
                        icon: Image.asset(
                          'assets/images/whatsapp.png',
                          height: 24,
                          width: 24,
                        ),
                      ),
                      IconButton(
                        iconSize: 24,
                        onPressed: () {
                          if (state is Loaded) {
                            shareText(title: "Share via...", text: textShare, url: state.inviteRes.data.inviteLink);
                          } else if (widget.hasInviteLink.isNotEmpty) {
                            shareText(title: "Share via...", text: textShare, url: widget.hasInviteLink);
                          }
                        },
                        icon: Icon(
                          Icons.share_rounded,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )
          : InkWell(
              onTap: () {
                if (widget.invitesRemaining <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(
                      'Sorry, looks like you have exhausted all your invites.',
                      style: mpHeadLine6(
                        context: context,
                        textColor: context.appTheme.lightTextColor,
                      ),
                    ),
                    duration: Duration(seconds: 3),
                    backgroundColor: Theme.of(context).primaryColor,
                  ));
                  return;
                }

                //Call invite API
                clickedInviteId = widget.data.id;
                BlocProvider.of<CreateInviteBloc>(context).add(InviteCreateEvent(widget.mobileNo));
              },
              child: Container(
                width: 110,
                alignment: Alignment.center,
                padding: EdgeInsets.symmetric(vertical: 4),
                decoration: BoxDecoration(
                  // color: followEvent == FollowEvent.invite ? context.appTheme.whiteColor : Theme.of(context).primaryColor,
                  color: context.appTheme.cardBackgroundColor,
                  border: widget.invitesRemaining > 0
                      ? Border.all(color: Theme.of(context).primaryColor)
                      : Border.all(color: context.appTheme.primaryDisabledColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Invite',
                  textAlign: TextAlign.center,
                  style: mpHeadLine4(
                    context: context,
                    textColor: followEvent == FollowEvent.invite
                        ? widget.invitesRemaining > 0
                            ? Theme.of(context).primaryColor
                            : context.appTheme.primaryTextDisabledColor
                        : context.appTheme.cardBackgroundColor,
                  ),
                ),
              ),
            ),
      listener: (context, state) {
        if (state is Loaded) {
          if (clickedInviteId == widget.data.id) {
            widget.data.isInvited = true;
            widget.callback(widget.data, state.inviteRes.meta.remainingInvites);

            if (state is Loaded) {
              final String urlToShare =
                  "https://wa.me/${widget.mobileNo.replaceAll(" ", '')}?text=$textShare\n${state.inviteRes.data.inviteLink}";
              final Uri url = Uri.parse(urlToShare);
              launchURL(url.toString());
            } else if (widget.hasInviteLink.isNotEmpty) {
              final String urlToShare =
                  "https://wa.me/${widget.mobileNo.replaceAll(" ", '')}?text=$textShare\n${widget.hasInviteLink}";
              final Uri url = Uri.parse(urlToShare);
              launchURL(url.toString());
            }
          }
        }
      },
    );
  }
}

import 'dart:convert';
import 'dart:io';

import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/responsive/utils/my_button.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/features/invite_friends/domain/entities/invite_friends.dart';
import 'package:multipie/features/invite_friends/presentation/get_invite_suggestions/bloc.dart';
import 'package:multipie/features/invite_friends/presentation/widget/invite_share_widget.dart';
import 'package:multipie/features/profile/presentation/bloc/people_search/bloc.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/profile_screen_bloc.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/new_profile_screen.dart';
import 'package:multipie/features/profile/presentation/widgets/follow_unfollow_widget.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/features/user/presentation/provider/user_provider.dart';
import 'package:multipie/features/user_onboarding/personalized_feed/personalised_feed_screen.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../constants.dart';
import '../../../profile/presentation/screens/people_to_follow_screen.dart';

class InviteFriendsScreen extends StatefulWidget {
  final File? imageFile;
  final bool isFromDrawer;
  const InviteFriendsScreen({
    Key? key,
    this.imageFile,
    required this.isFromDrawer,
  }) : super(key: key);

  @override
  _InviteFriendsScreenState createState() => _InviteFriendsScreenState();
}

class _InviteFriendsScreenState extends State<InviteFriendsScreen> {
  UserProfileBloc? userBloc;
  List<InviteItem> inviteSuggestions = [];
  List<User> userSuggestions = [];
  bool isContactShared = false;
  bool hasMoreData = false;
  bool isFetchingContacts = false;
  ScrollController _scrollController = ScrollController();
  int pageSize = 10000;
  int page = 1;

  TextEditingController searchController = TextEditingController();
  List<InviteItem> _searchInviteSuggestions = [];
  List<InviteItem> _completeInviteList = [];

  int remainingInvites = 0;
  bool _showInvited = false;

  @override
  void initState() {
    super.initState();
    //Initial call, if contact access is given then show Invite suggestion else show Premium suggestions
    checkIfContactAccessGiven();

    userBloc = BlocProvider.of<UserProfileBloc>(context);

    //Pagination for Invite List
    _scrollController.addListener(() {
      if (_scrollController.position.maxScrollExtent == _scrollController.position.pixels && hasMoreData) {
        if (inviteSuggestions.length >= pageSize) page = ((inviteSuggestions.length / pageSize) + 1).toInt();

        BlocProvider.of<GetInviteBloc>(context).add(FetchInviteDataEvent(page: page, size: pageSize));
      }
    });
  }

  onSearchTextChanged(String text) async {
    _searchInviteSuggestions.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    inviteSuggestions.forEach((userDetail) {
      if (userDetail.displayName.toLowerCase().contains(text.toLowerCase())) _searchInviteSuggestions.add(userDetail);
    });

    setState(() {});
  }

  void checkIfContactAccessGiven() async {
    final PermissionStatus permission = await Permission.contacts.status;
    if (permission == PermissionStatus.granted) {
      isContactShared = true;
      fetchInviteSuggestions();
    } else {
      //Call Premium/VIP Multipie users
      BlocProvider.of<PeopleToFollowBloc>(context).add(GetPeopleToFollowResults(page: 1, size: 50));
    }

    //Get Remaining Invites to show
    final prefs = await SharedPreferences.getInstance();
    final String userString = prefs.getString('current_user') ?? '';
    remainingInvites = UserModel.fromJson(jsonDecode(userString)).remainingInvites; //.toString();
  }

  void fetchInviteSuggestions() {
    page = 1;
    inviteSuggestions.clear();

    //Fetch invite suggestions after contact upload
    BlocProvider.of<GetInviteBloc>(context).add(FetchInviteDataEvent(page: page, size: pageSize));

    //Replace Follow list with Invite Suggestion list
    setState(() {
      isFetchingContacts = false;
      isContactShared = true;
    });
  }

  //Check contacts permission
  Future<PermissionStatus> _getPermission() async {
    final PermissionStatus permission = await Permission.contacts.status;

    if (permission != PermissionStatus.granted &&
        (permission == PermissionStatus.permanentlyDenied || permission == PermissionStatus.denied)) {
      final Map<Permission, PermissionStatus> permissionStatus = await [Permission.contacts].request();
      return permissionStatus[Permission.contacts] ?? PermissionStatus.limited;
    } else {
      return permission;
    }
  }

  //Get Contacts after getting user permission
  Future<void> uploadContacts() async {
    await context.read<GetInviteBloc>().contactsUploadManager.syncContacts(
      onFirstConcurrentBatchUploaded: () {
        if (mounted) {
          fetchInviteSuggestions();
        }
      },
      onCompletion: () {
        if (mounted) {
          fetchInviteSuggestions();
          ScaffoldMessenger.of(context).hideCurrentSnackBar();
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: context.appTheme.cardBackgroundColor,
        appBar: AppBar(
          backgroundColor: context.appTheme.cardBackgroundColor,
          automaticallyImplyLeading: false,
          elevation: 0,
          titleSpacing: 0,
          leading: InkWell(
            child: Padding(
              padding: const EdgeInsets.all(17.5),
              child: SvgPicture.asset(
                'assets/icons/Arrow-Previous.svg',
                color: context.appTheme.primaryColor,
                height: 20,
                width: 20,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          title: Text(
            widget.isFromDrawer ? 'Invite Friends' : '',
            style: TextStyle(
              color: context.appTheme.primaryColor,
              fontFamily: 'Roboto',
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      'It\'s always better when you\nhave your friends around',
                      textAlign: TextAlign.center,
                      style: mpHeadLine2(context: context),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 15,
              ),
              if (isContactShared)
                Container(
                  height: 40,
                  margin: EdgeInsets.only(left: 20, right: 20),
                  padding: EdgeInsets.only(left: 16),
                  decoration: BoxDecoration(
                      color: context.appTheme.searchBackground, borderRadius: BorderRadius.all(Radius.circular(10))),
                  child: TextField(
                    maxLines: 1,
                    // autofocus: true,
                    controller: searchController,
                    onChanged: onSearchTextChanged,
                    decoration: new InputDecoration(
                        border: InputBorder.none,
                        hintText: "Search",
                        suffixIcon: IconButton(
                          onPressed: () {
                            FocusScope.of(context).unfocus();
                            searchController.clear();
                            onSearchTextChanged('');
                          },
                          icon: Icon(Icons.clear, color: context.appTheme.secondaryTextColor),
                        )),
                  ),
                ),
              if (isContactShared)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    //if (remainingInvites != null && remainingInvites.isNotEmpty && remainingInvites != "0")
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 35,
                      ),
                      child: Text(
                        remainingInvites == 1
                            ? '$remainingInvites Invite remaining'
                            : '$remainingInvites Invites remaining',
                        textAlign: TextAlign.left,
                        style: mpHeadLine4(
                          context: context,
                          fontWeight: FontWeight.bold,
                          textColor: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        child: TextButton(
                          // here toggle the bool value so that when you click
                          // on the whole item, it will reflect changes in Checkbox
                          onPressed: () {
                            setState(() {
                              _onOnlyInvitedPressed(context);
                            });
                          },
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                height: 24.0,
                                width: 24.0,
                                child: Checkbox(
                                  value: _showInvited,
                                  focusColor: Theme.of(context).primaryColor,
                                  activeColor: Theme.of(context).primaryColor,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      _onOnlyInvitedPressed(context);
                                    });
                                  },
                                ),
                              ),
                              // You can play with the width to adjust your
                              // desired spacing
                              SizedBox(width: 8.0),
                              Text(
                                'Only Invited',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  color: context.appTheme.primaryTextColor,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              Expanded(
                child: isContactShared
                    ? BlocConsumer<GetInviteBloc, GetInviteState>(
                        listener: (context, state) {
                          if (state is Loaded) {
                            inviteSuggestions.addAll(state.list);

                            //use it to reset list when user selects invited friends checkbox
                            _completeInviteList = inviteSuggestions;
                          }
                        },
                        builder: (context, state) {
                          if (state is Loading) {
                            return Center(
                              child: Column(
                                children: [
                                  CircularProgressIndicator(),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    'Please wait, while we fetch your contact list',
                                    style: TextStyle(
                                      fontSize: sSp(12.0),
                                      fontWeight: FontWeight.bold,
                                      color: context.appTheme.primaryTextColor,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }

                          //Check if list has more data to show
                          if (state is Loaded) {
                            if (state.list.length < pageSize) {
                              hasMoreData = false;
                            } else {
                              hasMoreData = true;
                            }
                          }

                          if (inviteSuggestions.length > 0) {
                            return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 25.0),
                                child: _searchInviteSuggestions.length != 0 || searchController.text.isNotEmpty
                                    ? ListView.builder(
                                        controller: _scrollController,
                                        itemCount: _searchInviteSuggestions.length, // + 1,
                                        itemBuilder: (context, index) {
                                          return InviteFriendDataItem(
                                            remainingInvites: remainingInvites,
                                            data: _searchInviteSuggestions[index],
                                            onChildCallback: (InviteItem value, int leftInvites) {
                                              setState(() {
                                                _searchInviteSuggestions[index] = value;
                                                remainingInvites = leftInvites;

                                                //Update - remaining invites
                                                Provider.of<UserProvider>(context, listen: false)
                                                    .loadCurrentUser(context: context);
                                              });
                                            },
                                          );
                                        },
                                      )
                                    : ListView.builder(
                                        controller: _scrollController,
                                        itemCount: inviteSuggestions.length + 1,
                                        itemBuilder: (context, index) {
                                          if (index == inviteSuggestions.length) {
                                            if (hasMoreData == false) return Container();
                                            return Container(
                                                height: 60,
                                                child: Center(
                                                  child: CircularProgressIndicator(),
                                                ));
                                          }
                                          return InviteFriendDataItem(
                                            remainingInvites: remainingInvites,
                                            data: inviteSuggestions[index],
                                            onChildCallback: (InviteItem value, int leftInvites) {
                                              setState(() {
                                                inviteSuggestions[index] = value;
                                                remainingInvites = leftInvites;

                                                //Update - remaining invites
                                                Provider.of<UserProvider>(context, listen: false)
                                                    .loadCurrentUser(context: context);
                                              });
                                            },
                                          );
                                        },
                                      ));
                          } else {
                            return Container(
                              child: Center(
                                child: Text(
                                  "Couldn't find any contact.",
                                  style: mpHeadLine6(context: context),
                                ),
                              ),
                            );
                          }
                        },
                      )
                    : isFetchingContacts
                        ? Center(
                            child: Column(
                              children: [
                                CircularProgressIndicator(),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  'Please wait, while we fetch your contact list',
                                  style: TextStyle(
                                    fontSize: sSp(12.0),
                                    fontWeight: FontWeight.bold,
                                    color: context.appTheme.primaryTextColor,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : BlocConsumer<PeopleToFollowBloc, PeopleToFollowState>(
                            listener: (context, state) {
                              if (state is LoadedPeople) {
                                userSuggestions.addAll(state.peopleList);
                              }
                              if (state is PeopleFollowed) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => PersonalisedFeedScreen(
                                            imageFile: widget.imageFile,
                                          )),
                                );
                              }
                            },
                            builder: (context, state) {
                              return Stack(
                                children: [
                                  state is LoadingPeople
                                      ? Center(
                                          child: CircularProgressIndicator(),
                                        )
                                      : userSuggestions.length > 0
                                          ? Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 25.0),
                                              child: ListView.builder(
                                                itemCount: userSuggestions.length,
                                                itemBuilder: (context, index) {
                                                  return PremiumFollowUserSuggestionItem(data: userSuggestions[index]);
                                                },
                                              ),
                                            )
                                          : Center(
                                              child: Text(
                                                'No Results Found.',
                                                style: mpHeadLine5(context: context),
                                              ),
                                            ),
                                  if (state is FollowingPeople)
                                    Center(
                                      child: CircularProgressIndicator(),
                                    )
                                ],
                              );
                            },
                          ),
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 50),
                height: 70,
                child: MaterialButton(
                  color: context.appTheme.tertiaryBackgroundColor,
                  padding: const EdgeInsets.all(8),
                  height: sWidth(30.0),
                  minWidth: double.infinity,
                  elevation: 0,
                  hoverElevation: 0,
                  focusElevation: 0,
                  highlightElevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(sWidth(10.0)),
                  ),
                  onPressed: () async {
                    final PermissionStatus permissionStatus = await _getPermission();

                    if (permissionStatus == PermissionStatus.granted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        duration: Duration(milliseconds: 20000),
                        backgroundColor: Theme.of(context).primaryColor,
                        content: Row(
                          children: [
                            Container(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.0,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  context.appTheme.lightTextColor,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              'Please wait while we are refreshing your contacts',
                              style: mpHeadLine7(
                                context: context,
                                textColor: context.appTheme.lightTextColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        //duration: Duration(seconds: 2),
                      ));

                      //access contacts here
                      setState(() {
                        isFetchingContacts = true;
                      });
                      uploadContacts();
                    } else {
                      //If permissions is denied show standard cupertino alert dialog
                      if (!Platform.isIOS) {
                        return showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            backgroundColor: context.appTheme.cardBackgroundColor,
                            title: Text(
                              'Permission error',
                              style: mpHeadLine5(context: context),
                            ),
                            content: Text(
                              'Please enable contact access '
                              'permission in settings.',
                              style: mpHeadLine6(context: context),
                            ),
                            actions: <Widget>[
                              TextButton(
                                child: Text(
                                  'Not now',
                                  style: mpHeadLine6(context: context),
                                ),
                                onPressed: () => Navigator.of(context).pop(),
                              ),
                              TextButton(
                                child: Text(
                                  'Settings',
                                  style: mpHeadLine6(context: context),
                                ),
                                onPressed: () => openAppSettings(),
                              ),
                            ],
                          ),
                        );
                      }

                      return showDialog(
                          context: context,
                          builder: (BuildContext context) => CupertinoAlertDialog(
                                title: Text(
                                  'Permission error',
                                  style: mpHeadLine5(context: context),
                                ),
                                content: Text(
                                  'Please enable contact access '
                                  'permission in settings.',
                                  style: mpHeadLine6(context: context),
                                ),
                                actions: <Widget>[
                                  CupertinoDialogAction(
                                    child: Text(
                                      'Not now',
                                      style: mpHeadLine6(context: context),
                                    ),
                                    onPressed: () => Navigator.of(context).pop(),
                                  ),
                                  CupertinoDialogAction(
                                    child: Text(
                                      'Settings',
                                      style: mpHeadLine6(context: context),
                                    ),
                                    onPressed: () => openAppSettings(),
                                  )
                                ],
                              ));
                    }
                  },
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'FIND MORE FRIENDS',
                        style: mpHeadLine4(
                          context: context,
                          textColor: context.appTheme.primaryButtonTextColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        isContactShared ? 'Refresh your contacts' : 'Connect your contact book',
                        style: mpHeadLine5(
                          context: context,
                          fontWeight: FontWeight.w400,
                          textColor: context.appTheme.primaryButtonTextColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              if (!widget.isFromDrawer)
                Padding(
                  padding: const EdgeInsets.only(bottom: 24.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      MaterialButton(
                        padding: const EdgeInsets.all(0.0),
                        minWidth: sWidth(115.0),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PeopleToFollowScreen(
                                      imageFile: widget.imageFile,
                                    )),
                          );
                          //To Follow Suggestions
                        },
                        child: Text(
                          'MAYBE LATER',
                          style: mpHeadLine5(
                            context: context,
                            fontWeight: FontWeight.w600,
                            textColor: Theme.of(context).primaryColor,
                          ),
                        ),
                      ),
                      MultipieButton(
                        text: "NEXT",
                        elevation: 2,
                        color: Theme.of(context).primaryColor,
                        textColor: context.appTheme.cardBackgroundColor,
                        onPressed: () {
                          //To Follow Suggestions
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PeopleToFollowScreen(
                                      imageFile: widget.imageFile,
                                    )),
                          );
                        },
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ));
  }

  void _onOnlyInvitedPressed(BuildContext context) {
    inviteSuggestions = _completeInviteList;
    FocusScope.of(context).unfocus();
    searchController.clear();
    onSearchTextChanged('');

    _showInvited = !_showInvited;

    if (_showInvited == true) {
      List<InviteItem> _invitedOnly = [];

      for (var invite in inviteSuggestions) {
        for (var entry in invite.contactEntries) {
          if (entry.inviteLink != null && entry.inviteLink!.isNotEmpty && entry.fieldType == 'mobile' ||
              invite.isInvited == true) {
            _invitedOnly.add(invite);
          }
        }
      }

      inviteSuggestions = _invitedOnly;
    } else {
      inviteSuggestions = _completeInviteList;
    }
  }
}

//Invite Widget
class InviteFriendDataItem extends StatefulWidget {
  final InviteItem data;
  final Function onChildCallback;
  final int remainingInvites;

  InviteFriendDataItem({
    required this.remainingInvites,
    required this.data,
    required this.onChildCallback,
  });

  @override
  _InviteFriendDataItemState createState() => _InviteFriendDataItemState();
}

class _InviteFriendDataItemState extends State<InviteFriendDataItem> {
  @override
  void initState() {
    super.initState();
  }

  //Find first item from mobile
  String getFirstMobile(List<ContactEntry> contactEntries) {
    return contactEntries.firstWhere((element) => element.fieldType == 'mobile').fieldValue;
  }

  String? isAlreadyInvited(List<ContactEntry> contactEntries) {
    return contactEntries
        .firstWhere((element) =>
            (element.inviteLink != null || element.inviteLink!.isNotEmpty) && element.fieldType == 'mobile')
        .inviteLink;
  }

  Widget friendsWidget() {
    int friendCount = int.parse(widget.data.friendsCount);
    if (friendCount == 0) return Container();

    var subText = '$friendCount friends on Multipie';
    if (friendCount == 1) subText = '$friendCount friend on Multipie';

    return Text(
      subText,
      textAlign: TextAlign.start,
      overflow: TextOverflow.ellipsis,
      style: mpHeadLine7(
        context: context,
        textColor: context.appTheme.secondaryTextColor,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        //handle on click event, if any.
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: sWidth(45.0),
                    height: sWidth(45.0),
                    decoration: BoxDecoration(
                      color: context.appTheme.borderColor,
                      shape: BoxShape.circle,
                    ),
                    child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: context.appTheme.borderColor,
                        shape: BoxShape.circle,
                      ),
                      padding: EdgeInsets.only(top: sWidth(2.0)),
                      child: Text(
                        widget.data.displayName == null || widget.data.displayName.isEmpty
                            ? '-'
                            : widget.data.displayName[0],
                        style: TextStyle(
                          fontSize: sSp(11.0),
                          fontWeight: FontWeight.bold,
                          color: context.appTheme.primaryTextColor,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: sWidth(6.0),
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    widget.data.displayName.isEmpty ? '--' : widget.data.displayName,
                                    textAlign: TextAlign.start,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 2,
                                    style: mpHeadLine5(
                                      context: context,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  Text(
                                    getFirstMobile(widget.data.contactEntries),
                                    textAlign: TextAlign.start,
                                    overflow: TextOverflow.ellipsis,
                                    style: mpHeadLine6(
                                      context: context,
                                      textColor: context.appTheme.secondaryTextColor,
                                    ),
                                  ),
                                  friendsWidget()
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 8,
                            ),
                            InviteShareButton(
                              data: widget.data,
                              hasInviteLink: isAlreadyInvited(widget.data.contactEntries)!,
                              invitesRemaining: widget.remainingInvites,
                              mobileNo: getFirstMobile(widget.data.contactEntries),
                              width: 110,
                              fontSize: 'mp4',
                              radius: 10,
                              callback: (InviteItem val, int leftInvites) {
                                FocusScope.of(context).unfocus();
                                //Update data locally to show share link option
                                widget.onChildCallback(val, leftInvites);
                                CleverTapPlugin.recordEvent(
                                    'Friend Invited', {"mobile": getFirstMobile(widget.data.contactEntries)});
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Divider(
            color: context.appTheme.secondaryTextColor,
          )
        ],
      ),
    );
  }
}

//Follow Widget
class PremiumFollowUserSuggestionItem extends StatefulWidget {
  final User data;

  PremiumFollowUserSuggestionItem({required this.data});

  @override
  _PremiumFollowUserSuggestionItemState createState() => _PremiumFollowUserSuggestionItemState();
}

class _PremiumFollowUserSuggestionItemState extends State<PremiumFollowUserSuggestionItem> {
  late FollowEvent followEvent;

  @override
  void initState() {
    super.initState();
    followEvent = widget.data.isFollowed != null && widget.data.isFollowed
        ? FollowEvent.followed
        : widget.data.isRequested != null && widget.data.isRequested
            ? FollowEvent.pending
            : FollowEvent.none;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NewProfileScreen(
              userId: widget.data.id,
            ),
          ),
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 65,
                    height: 65,
                    margin: EdgeInsets.only(right: 16),
                    child: ProfilePictureHolder(
                      profileMode: widget.data.marketView,
                      imageUrl: widget.data.dpThumbnail,
                      textStyle: mpHeadLine2(
                        context: context,
                        textColor: context.appTheme.secondaryTextColor,
                      ),
                      holderLetter: widget.data.displayname == null || widget.data.displayname == ''
                          ? ''
                          : widget.data.displayname[0],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    widget.data.displayname,
                                    textAlign: TextAlign.start,
                                    overflow: TextOverflow.ellipsis,
                                    style: mpHeadLine5(
                                      context: context,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  Text(
                                    "@${widget.data.username}",
                                    textAlign: TextAlign.start,
                                    overflow: TextOverflow.ellipsis,
                                    style: mpHeadLine5(
                                      context: context,
                                      textColor: context.appTheme.secondaryTextColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            FollowUnFollowButton(
                              data: widget.data,
                              width: 110,
                              fontSize: 'mp4',
                              radius: 10,
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 0.0, top: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Text(
                                  widget.data.profile!.bio != null ? widget.data.profile!.bio : '--',
                                  textAlign: TextAlign.start,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: mpHeadLine6(context: context),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Divider(
            color: context.appTheme.secondaryTextColor,
          )
        ],
      ),
    );
  }
}

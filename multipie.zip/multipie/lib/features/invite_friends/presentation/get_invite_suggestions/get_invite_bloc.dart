import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/contacts_upload/contacts_upload_manager.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';
import 'package:multipie/features/invite_friends/domain/usercases/get_invite_usecase.dart';
import 'package:multipie/features/invite_friends/presentation/get_invite_suggestions/bloc.dart';

class GetInviteBloc extends Bloc<GetInviteEvent, GetInviteState> {
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  final GetInviteUsecase getInviteUsecase;
  final ContactsUploadManager contactsUploadManager;

  GetInviteBloc({
    required GetInviteUsecase getInviteUsecase,
    required this.contactsUploadManager,
  })  : getInviteUsecase = getInviteUsecase,
        super(Empty());

  @override
  Stream<GetInviteState> mapEventToState(GetInviteEvent event) async* {
    if (event is FetchInviteDataEvent) {
      if (event.page == 1) yield Loading();
      final failureOrGetInvite = await getInviteUsecase.call(Params(page: event.page, size: event.size));
      yield* _eitherLoadedOrErrorState(failureOrGetInvite);
    }
  }

  Stream<GetInviteState> _eitherLoadedOrErrorState(
    Either<Failure, List<InviteItem>> failureOrMutualDataList,
  ) async* {
    yield failureOrMutualDataList.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (list) => Loaded(list: list),
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

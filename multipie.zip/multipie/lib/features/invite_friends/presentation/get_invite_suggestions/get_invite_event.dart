import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class GetInviteEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class FetchInviteDataEvent extends GetInviteEvent {
  final int page;
  final int size;

  FetchInviteDataEvent({required this.page, required this.size});

  @override
  List<Object> get props => [page, size];
}

import 'package:equatable/equatable.dart';
import 'package:multipie/features/invite_friends/data/models/invite_model.dart';

abstract class GetInviteState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends GetInviteState {}

class Loading extends GetInviteState {}

class Loaded extends GetInviteState {
  final List<InviteItem> list;

  Loaded({required this.list});

  @override
  List<Object> get props => [list];
}

class Error extends GetInviteState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

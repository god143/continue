import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/invite_friends/domain/entities/create_invite.dart';
import 'package:multipie/features/invite_friends/domain/usercases/create_invite_usecase.dart';
import 'package:multipie/features/invite_friends/presentation/post_create_invite/create_invite_event.dart';
import 'package:multipie/features/invite_friends/presentation/post_create_invite/create_invite_state.dart';

class CreateInviteBloc extends Bloc<CreateInviteEvent, CreateInviteState> {
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  final CreateInviteUsecase createInviteUsecase;
  final VerifyInviteUseCase verifyInviteUseCase;

  CreateInviteBloc(
      {required CreateInviteUsecase createInviteUsecase,
      required VerifyInviteUseCase verifyInviteUseCase})
      :createInviteUsecase = createInviteUsecase,
        verifyInviteUseCase = verifyInviteUseCase,
        super(Empty());

  @override
  Stream<CreateInviteState> mapEventToState(CreateInviteEvent event) async* {
    if (event is InviteCreateEvent) {
      yield Loading();
      final failureOrCreateInvite = await createInviteUsecase
          .call(Params(inviteeMobile: event.inviteeMobile));
      yield* _eitherLoadedOrErrorState(failureOrCreateInvite);
    }

    if (event is InviteVerifyEvent) {
      yield Loading();
      final failureOrMessage =
          await verifyInviteUseCase(Params(inviteeMobile: event.inviteeMobile));
      yield* _eitherLoadedOrVerifiedState(failureOrMessage);
    }
  }

  Stream<CreateInviteState> _eitherLoadedOrErrorState(
    Either<Failure, CreatedInviteRes> failureOrCreatedInvite,
  ) async* {
    yield failureOrCreatedInvite.fold(
        (failure) => Error(message: _mapFailureToMessage(failure)),
        (invited) => Loaded(inviteRes: invited));
  }

  Stream<CreateInviteState> _eitherLoadedOrVerifiedState(
    Either<Failure, SuccessResponseModel> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) {
        return Error(message: _mapFailureToMessage(failure));
      },
      (data) {
        return InviteVerified(success: data.success);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

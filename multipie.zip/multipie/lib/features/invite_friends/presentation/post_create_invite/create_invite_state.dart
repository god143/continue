import 'package:equatable/equatable.dart';
import 'package:multipie/features/invite_friends/data/models/created_invite_model.dart';
import 'package:multipie/features/invite_friends/domain/entities/create_invite.dart';

abstract class CreateInviteState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends CreateInviteState {}

class Loading extends CreateInviteState {}

class Loaded extends CreateInviteState {
  final CreatedInviteRes inviteRes;

  Loaded({required this.inviteRes});

  @override
  List<Object> get props => [inviteRes];
}

class LoadedRemaining extends CreateInviteState {
  final Meta metaRes;

  LoadedRemaining({required this.metaRes});

  @override
  List<Object> get props => [metaRes];
}

class InviteVerified extends CreateInviteState {
  final bool success;

  InviteVerified({required this.success});
}

class Error extends CreateInviteState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class CreateInviteEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class InviteCreateEvent extends CreateInviteEvent {
  final String inviteeMobile;

  InviteCreateEvent(this.inviteeMobile);

  @override
  List<Object> get props => [inviteeMobile];
}

class InviteVerifyEvent extends CreateInviteEvent {
  final String inviteeMobile;

  InviteVerifyEvent(this.inviteeMobile);

  @override
  List<Object> get props => [inviteeMobile];
}
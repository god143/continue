import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/cash_flow.dart';
import 'package:multipie/features/market/domain/usecases/get_cash_flow.dart';

import 'bloc.dart';

class CashFlowBloc extends Bloc<CashFlowEvent, CashFlowState> {
  final GetCashFlow getCashFlow;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  CashFlowState get initialState => Empty();

  CashFlowBloc({required GetCashFlow getCashFlow})
      : assert(getCashFlow != null),
        getCashFlow = getCashFlow,
        super(Empty());

  @override
  Stream<CashFlowState> mapEventToState(
    CashFlowEvent event,
  ) async* {
    if (event is GetListCashFlow) {
      yield Loading();
      final failureOrBalanceSheetList = await getCashFlow(Params(
          id: event.id, url: event.url, isConsolidated: event.isConsolidated));
      yield* _eitherLoadedOrErrorState(failureOrBalanceSheetList);
    }
  }

  Stream<CashFlowState> _eitherLoadedOrErrorState(
    Either<Failure, List<CashFlow>> failureOrQuarterlyResults,
  ) async* {
    yield failureOrQuarterlyResults.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        if (data.isEmpty) return Empty();
        return Loaded(cashFlowList: data);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

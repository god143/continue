import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/usecases/get_company_follow_suggestions.dart';
import 'package:multipie/features/market/domain/usecases/get_top_held_stocks.dart';

import 'bloc.dart';
import 'company_event.dart';
import 'company_state.dart';

class CompanyBloc extends Bloc<CompanyEvent, CompanyState> {
  final GetCompanyFollowSuggestions getCompanyFollowSuggestions;
  final GetTopHeldStockUseCase getTopHeldStockUseCase;

  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  static const String INVALID_INPUT_FAILURE_MESSAGE = 'Invalid Input - The number must be a positive integer or zero.';

  @override
  CompanyState get initialState => Empty();

  CompanyBloc({required GetCompanyFollowSuggestions companyList, required GetTopHeldStockUseCase topHeldStockList})
      : assert(companyList != null),
        getCompanyFollowSuggestions = companyList,
        getTopHeldStockUseCase = topHeldStockList,
        super(Empty());

  @override
  Stream<CompanyState> mapEventToState(
    CompanyEvent event,
  ) async* {
    if (event is GetListCompanySuggestions) {
      if (event.page == 1) yield Loading();
      final failureOrCompanyList = await getCompanyFollowSuggestions(
          Params(searchPhrase: event.searchPhrase, pageSize: event.pageSize, page: event.page));
      yield* _eitherLoadedOrErrorState(failureOrCompanyList);
    }

    if (event is GetListTopHeldStocks) {
      yield LoadingTopHeld();
      final failureOrTopStockList = await getTopHeldStockUseCase(StockParams(
        count: event.count,
      ));
      yield* _eitherLoadedTopStocksOrErrorState(failureOrTopStockList);
    }
  }

  Stream<CompanyState> _eitherLoadedOrErrorState(
    Either<Failure, List<Company>> failureOrCompanyList,
  ) async* {
    yield failureOrCompanyList.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (companies) => Loaded(companies: companies),
    );
  }

  Stream<CompanyState> _eitherLoadedTopStocksOrErrorState(
    Either<Failure, List<Company>> failureOrTopStockList,
  ) async* {
    yield failureOrTopStockList.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (topStocks) => LoadedTopHeldStocks(topHeldStocks: topStocks),
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

@immutable
abstract class CompanyState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends CompanyState {}

class Loading extends CompanyState {}

class LoadingTopHeld extends CompanyState {}

class Loaded extends CompanyState {
  final List<Company> companies;
  Loaded({required this.companies});

  @override
  List<Object> get props => [companies];
}

class LoadedTopHeldStocks extends CompanyState {
  final List<Company> topHeldStocks;
  LoadedTopHeldStocks({required this.topHeldStocks});

  @override
  List<Object> get props => [topHeldStocks];
}

class Error extends CompanyState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

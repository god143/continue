import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class CashFlowEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListCashFlow extends CashFlowEvent {
  final String id;
  final String url;
  final bool isConsolidated;

  GetListCashFlow(this.id, this.url, this.isConsolidated);

  @override
  List<Object> get props => [id, url, isConsolidated];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class CompanyEvent extends Equatable {
  @override
  List<Object> get props => [];
}

/*
class GetListCompanySuggestions extends CompanyListEvent {
  final String numberString;

  GetListCompanySuggestions(this.numberString);

  @override
  List<Object> get props => [numberString];
}
*/

class GetListCompanySuggestions extends CompanyEvent {
  final String searchPhrase;
  final int pageSize;
  final int page;
  GetListCompanySuggestions(this.searchPhrase, this.pageSize, this.page);

  @override
  List<Object> get props => [searchPhrase, pageSize, page];
}

class GetListTopHeldStocks extends CompanyEvent {
  final String sortBy;
  final int count;
  GetListTopHeldStocks(this.sortBy, this.count);

  @override
  List<Object> get props => [sortBy, count];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class QuarterlyResultsEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListQuarterlyResults extends QuarterlyResultsEvent {
  final String id;
  final String url;
  final bool isConsolidated;

  GetListQuarterlyResults(this.id, this.url, this.isConsolidated);

  @override
  List<Object> get props => [id, url, isConsolidated];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class BalanceSheetEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListBalanceSheet extends BalanceSheetEvent {
  final String id;
  final String url;
  final bool isConsolidated;

  GetListBalanceSheet(this.id, this.url, this.isConsolidated);

  @override
  List<Object> get props => [id, url, isConsolidated];
}

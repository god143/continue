import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';
import 'package:multipie/features/market/domain/usecases/get_company_details.dart';

import 'bloc.dart';

class CompanyDetailBloc extends Bloc<CompanyDetailEvent, CompanyDetailState> {
  final GetCompanyDetails getCompanyDetails;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  static const String INVALID_INPUT_FAILURE_MESSAGE = 'Invalid Input - The number must be a positive integer or zero.';

  CompanyDetailBloc({required GetCompanyDetails companyDetail})
      : assert(companyDetail != null),
        getCompanyDetails = companyDetail,
        super(Empty());

  @override
  Stream<CompanyDetailState> mapEventToState(
    CompanyDetailEvent event,
  ) async* {
    //EVENT WILL BE COMPARED BELOW
    if (event is GetDataCompanyDetails) {
      yield Loading();
      final failureOrCompanyList = await getCompanyDetails(Params(id: event.id));
      yield* _eitherLoadedOrErrorState(failureOrCompanyList);
    }
  }

  Stream<CompanyDetailState> _eitherLoadedOrErrorState(
    Either<Failure, CompanyDetails> failureOrCompanyList,
  ) async* {
    yield failureOrCompanyList.fold(
      (failure) {
        return Error(message: _mapFailureToMessage(failure));
      },
      (companyDetails) {
        return Loaded(companyDetails: companyDetails);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

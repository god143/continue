import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';

@immutable
abstract class CompanyDetailState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends CompanyDetailState {}

class Loading extends CompanyDetailState {}

class Loaded extends CompanyDetailState {
  final CompanyDetails companyDetails;
  Loaded({required this.companyDetails});

  @override
  List<Object> get props => [companyDetails];
}

class Error extends CompanyDetailState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

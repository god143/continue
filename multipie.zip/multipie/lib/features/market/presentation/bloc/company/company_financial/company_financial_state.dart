import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/market/domain/entities/company/quarterly_results.dart';

@immutable
abstract class QuarterlyResultsState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends QuarterlyResultsState {}

class Loading extends QuarterlyResultsState {}

class Loaded extends QuarterlyResultsState {
  final List<QuarterlyResults> companyFinancials;
  Loaded({required this.companyFinancials});

  @override
  List<Object> get props => [companyFinancials];
}

class Error extends QuarterlyResultsState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

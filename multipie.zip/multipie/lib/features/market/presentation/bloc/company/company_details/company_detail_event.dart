import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class CompanyDetailEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetDataCompanyDetails extends CompanyDetailEvent {
  final String id;

  GetDataCompanyDetails(this.id);
  @override
  List<Object> get props => [id];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/market/domain/entities/company/cash_flow.dart';

@immutable
abstract class CashFlowState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends CashFlowState {}

class Loading extends CashFlowState {}

class Loaded extends CashFlowState {
  final List<CashFlow> cashFlowList;
  Loaded({required this.cashFlowList});

  @override
  List<Object> get props => [cashFlowList];
}

class Error extends CashFlowState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/quarterly_results.dart';
import 'package:multipie/features/market/domain/usecases/get_quarterly_results.dart';

import 'bloc.dart';

class QuarterlyResultsBloc
    extends Bloc<QuarterlyResultsEvent, QuarterlyResultsState> {
  final GetQuarterlyResults getQuarterlyResults;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  QuarterlyResultsState get initialState => Empty();

  QuarterlyResultsBloc({required GetQuarterlyResults getQuarterlyResults})
      : assert(getQuarterlyResults != null),
        getQuarterlyResults = getQuarterlyResults,
        super(Empty());

  @override
  Stream<QuarterlyResultsState> mapEventToState(
    QuarterlyResultsEvent event,
  ) async* {
    if (event is GetListQuarterlyResults) {
      yield Loading();
      final failureOrCompanyList = await getQuarterlyResults(Params(
          id: event.id, url: event.url, isConsolidated: event.isConsolidated));
      yield* _eitherLoadedOrErrorState(failureOrCompanyList);
    }
  }

  Stream<QuarterlyResultsState> _eitherLoadedOrErrorState(
    Either<Failure, List<QuarterlyResults>> failureOrQuarterlyResults,
  ) async* {
    yield failureOrQuarterlyResults.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (companies) {
        if (companies.isEmpty) return Empty();
        return Loaded(companyFinancials: companies);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/balance_sheet.dart';
import 'package:multipie/features/market/domain/usecases/get_balance_sheet.dart';

import 'bloc.dart';

class BalanceSheetBloc extends Bloc<BalanceSheetEvent, BalanceSheetState> {
  final GetBalanceSheet getBalanceSheet;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  BalanceSheetState get initialState => Empty();

  BalanceSheetBloc({required GetBalanceSheet getBalanceSheet})
      : assert(getBalanceSheet != null),
        getBalanceSheet = getBalanceSheet,
        super(Empty());

  @override
  Stream<BalanceSheetState> mapEventToState(
    BalanceSheetEvent event,
  ) async* {
    if (event is GetListBalanceSheet) {
      yield Loading();
      final failureOrBalanceSheetList = await getBalanceSheet(Params(
          id: event.id, url: event.url, isConsolidated: event.isConsolidated));
      yield* _eitherLoadedOrErrorState(failureOrBalanceSheetList);
    }
  }

  Stream<BalanceSheetState> _eitherLoadedOrErrorState(
    Either<Failure, List<BalanceSheet>> failureOrQuarterlyResults,
  ) async* {
    yield failureOrQuarterlyResults.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (companies) {
        if (companies.isEmpty) return Empty();
        return Loaded(balanceSheetList: companies);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

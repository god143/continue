import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/market/domain/entities/company/balance_sheet.dart';

@immutable
abstract class BalanceSheetState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends BalanceSheetState {}

class Loading extends BalanceSheetState {}

class Loaded extends BalanceSheetState {
  final List<BalanceSheet> balanceSheetList;
  Loaded({required this.balanceSheetList});

  @override
  List<Object> get props => [balanceSheetList];
}

class Error extends BalanceSheetState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

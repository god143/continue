import 'package:equatable/equatable.dart';

class MFListByType extends Equatable {
  final String id;
  final String name;
  final String iconUrl;
  final String category;
  final String cap;
  final String rankInCategory;
  final String inceptionDate;
  final String amc;
  final String type;
  final String dividendSubType;
  final String fundCategory;
  final String peerReturns;
  final String factSheetUrl;
  final MFReturnsMeta mfReturnMetaInfo;

  MFListByType(
      {required this.id,
      required this.name,
      required this.iconUrl,
      required this.category,
      required this.cap,
      required this.rankInCategory,
      required this.inceptionDate,
      required this.amc,
      required this.type,
      required this.dividendSubType,
      required this.fundCategory,
      required this.peerReturns,
      required this.factSheetUrl,
      required this.mfReturnMetaInfo});

  @override
  List<Object> get props => [
        id,
        name,
        iconUrl,
        category,
        cap,
        rankInCategory,
        inceptionDate,
        amc,
        type,
        dividendSubType,
        fundCategory,
        peerReturns,
        factSheetUrl,
        mfReturnMetaInfo,
      ];
}

class MFReturnsMeta extends Equatable {
  final String mutualFundsReturnFor1Year;
  final String mutualFundsReturnFor3Year;
  final String mutualFundsReturnFor5Year;
  final String mutualFundsReturnSinceInception;

  MFReturnsMeta(
      {required this.mutualFundsReturnFor1Year,
      required this.mutualFundsReturnFor3Year,
      required this.mutualFundsReturnFor5Year,
      required this.mutualFundsReturnSinceInception});

  @override
  List<Object> get props => [
        mutualFundsReturnFor1Year,
        mutualFundsReturnFor3Year,
        mutualFundsReturnFor5Year,
        mutualFundsReturnSinceInception,
      ];
}

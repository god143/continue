import 'package:equatable/equatable.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

class MFInvestorsData extends Equatable {
  final List<UserModel> userModel;
  final int investorCount;

  MFInvestorsData({required this.userModel, required this.investorCount});

  @override
  List<Object?> get props => [userModel, investorCount];
}

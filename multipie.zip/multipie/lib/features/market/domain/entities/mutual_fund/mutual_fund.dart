import 'package:equatable/equatable.dart';

class MutualFund extends Equatable {
  final String name;
  final String id;
  final String iconUrl;
  final String returnInPercent;
  final String peopleCount;
  final String rating;
  final String type;
  bool addedToWatchlist = false;

  MutualFund({
    required this.id,
    required this.name,
    required this.iconUrl,
    required this.returnInPercent,
    required this.peopleCount,
    required this.rating,
    required this.type,
  });

  @override
  List<Object> get props => [id, name, iconUrl, returnInPercent, peopleCount, rating, type, addedToWatchlist];
}

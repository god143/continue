import 'package:equatable/equatable.dart';

class MPMutualFundCollection extends Equatable {
  final String iconUrl;
  final String title;
  final String id;
  final List listData;

  MPMutualFundCollection({
    required this.id,
    required this.title,
    required this.iconUrl,
    required this.listData,
  });

  @override
  List<Object> get props => [id, title, iconUrl, listData];
}

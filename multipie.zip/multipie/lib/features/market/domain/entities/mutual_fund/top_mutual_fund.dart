import 'package:equatable/equatable.dart';

class TopHeldMutualFund extends Equatable {
  final String name;
  final String id;
  final String iconUrl;
  final String urlSlug;
  final String investorsCount;

  TopHeldMutualFund({
    required this.id,
    required this.name,
    required this.iconUrl,
    required this.urlSlug,
    required this.investorsCount,
  });

  @override
  List<Object> get props => [id, name, iconUrl, urlSlug, investorsCount];
}

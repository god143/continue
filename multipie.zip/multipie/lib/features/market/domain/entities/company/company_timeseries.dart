import 'package:equatable/equatable.dart';

class CompanyTimeSeries extends Equatable {
  final String date;
  final String closingPrice;
  final String id;

  CompanyTimeSeries({
    required this.id,
    required this.date,
    required this.closingPrice,
  });

  @override
  List<Object> get props => [id, date, closingPrice];
}

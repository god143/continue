import 'package:equatable/equatable.dart';

class SimilarStocks extends Equatable {
  final String iconUrl;
  final String displayName;
  final String id;
  final double lastTradedPrice;
  final double openPrice;

  SimilarStocks({
    required this.id,
    required this.displayName,
    required this.iconUrl,
    required this.lastTradedPrice,
    required this.openPrice,
  });

  @override
  List<Object> get props =>
      [id, displayName, iconUrl, lastTradedPrice, openPrice];
}

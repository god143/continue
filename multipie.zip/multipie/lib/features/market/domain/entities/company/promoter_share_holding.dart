import 'package:equatable/equatable.dart';

class PromoterHolding extends Equatable {
  final String id;
  final String type;
  final String promoterShareholding;
  final String pledgeShareholding;
  final String year;
  final String quarter;

  PromoterHolding({
    required this.id,
    required this.type,
    required this.promoterShareholding,
    required this.pledgeShareholding,
    required this.year,
    required this.quarter,
  });

  @override
  List<Object> get props =>
      [id, type, promoterShareholding, pledgeShareholding, year, quarter];
}

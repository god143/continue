import 'package:equatable/equatable.dart';

class CompanyDetails extends Equatable {
  final String iconUrl;
  final String name;
  final String id;
  final List listData;
  final String bseTicker;
  final String nseTicker;
  final List<String> statements;
  final String companyBio;
  final String? instrumentId;

  CompanyDetails({
    required this.id,
    required this.name,
    required this.iconUrl,
    required this.listData,
    required this.bseTicker,
    required this.nseTicker,
    required this.statements,
    required this.companyBio,
    this.instrumentId,
  });

  @override
  List<Object> get props => [
        id,
        name,
        iconUrl,
        listData,
        bseTicker,
        nseTicker,
        statements,
        companyBio,
        if (instrumentId != null) instrumentId!,
      ];
}

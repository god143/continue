import 'package:equatable/equatable.dart';

class CashFlow extends Equatable {
  final String id;
  final String year;
  final String cfFromOperating;
  final String cfFromInvestment;
  final String cfFromFinancing;
  final String openingCce;
  final String closingCce;

  CashFlow(
      {required this.id,
      required this.year,
      required this.cfFromOperating,
      required this.cfFromInvestment,
      required this.cfFromFinancing,
      required this.openingCce,
      required this.closingCce});

  Map<String, String> toDataRow() {
    Map<String, String> dataRow = Map();
    dataRow.putIfAbsent("CF From Operating", () => cfFromOperating);
    dataRow.putIfAbsent("CF From Investment", () => cfFromInvestment);
    dataRow.putIfAbsent("CF From Financing", () => cfFromFinancing);
    dataRow.putIfAbsent("Opening CCE", () => openingCce);
    dataRow.putIfAbsent("Closing CCE", () => closingCce);
    dataRow.putIfAbsent("Year", () => year);
    return dataRow;
  }

  @override
  // TODO: implement props
  List<Object> get props => [
        id,
        year,
        cfFromOperating,
        cfFromInvestment,
        cfFromFinancing,
        openingCce,
        closingCce,
      ];
}

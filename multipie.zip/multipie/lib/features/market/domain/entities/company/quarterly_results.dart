import 'package:equatable/equatable.dart';

class QuarterlyResults extends Equatable {
  final String id;
  final String sales;
  final String operatingProfit;
  final String opmPercentage;
  final String otherIncome;
  final String interest;
  final String depreciation;
  final String profitBeforeTax;
  final String taxRate;
  final String netProfit;
  final String eps;
  final String dps;
  final String dividendPayoutPercentage;
  final String quarter;
  final String year;

  QuarterlyResults(
      {required this.sales,
      required this.operatingProfit,
      required this.opmPercentage,
      required this.otherIncome,
      required this.interest,
      required this.depreciation,
      required this.profitBeforeTax,
      required this.taxRate,
      required this.netProfit,
      required this.eps,
      required this.dps,
      required this.dividendPayoutPercentage,
      required this.quarter,
      required this.year,
      required this.id});

  Map<String, String> toDataRow() {
    Map<String, String> dataRow = Map();
    dataRow.putIfAbsent("Sales", () => sales);
    dataRow.putIfAbsent("Operating Profit", () => operatingProfit);
    dataRow.putIfAbsent("OPM Percentage", () => opmPercentage);
    dataRow.putIfAbsent("Other Income", () => otherIncome);
    dataRow.putIfAbsent("Interest", () => interest);
    dataRow.putIfAbsent("Depreciation", () => depreciation);
    dataRow.putIfAbsent("Profit Before Tax", () => profitBeforeTax);
    dataRow.putIfAbsent("Tax Rate", () => taxRate);
    dataRow.putIfAbsent("Net Profit", () => netProfit);
    dataRow.putIfAbsent("EPS", () => eps);
    dataRow.putIfAbsent("DPS", () => dps);
    dataRow.putIfAbsent(
        "Dividend Payout Percentage", () => dividendPayoutPercentage);

    return dataRow;
  }

  @override
  List<Object> get props => [
        id,
        sales,
        operatingProfit,
        opmPercentage,
        otherIncome,
        interest,
        depreciation,
        profitBeforeTax,
        taxRate,
        netProfit,
        eps,
        dps,
        dividendPayoutPercentage,
        quarter,
        year
      ];
}

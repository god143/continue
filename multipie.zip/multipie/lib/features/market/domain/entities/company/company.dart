import 'package:equatable/equatable.dart';

class Company extends Equatable {
  final String iconUrl;
  final String name;
  final String? displayName;
  final String id;
  final double? lastTradedPrice;
  final List? listData;
  final double? openPrice;
  final String? nseTicker;
  bool addedToWatchlist;
  final lastClosedPrice;
  final percentChange;
  final change;
  final investorsCount;
  final int? mentionsCount;

  Company({
    required this.id,
    required this.name,
    this.displayName,
    this.iconUrl = '',
    this.lastTradedPrice,
    this.addedToWatchlist = false,
    this.listData,
    this.openPrice,
    this.nseTicker,
    this.lastClosedPrice,
    this.percentChange,
    this.change,
    this.investorsCount,
    this.mentionsCount,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        displayName,
        iconUrl,
        lastTradedPrice,
        listData,
        openPrice,
        nseTicker,
        addedToWatchlist,
        lastClosedPrice,
        percentChange,
        change,
        investorsCount,
        mentionsCount,
      ];
}

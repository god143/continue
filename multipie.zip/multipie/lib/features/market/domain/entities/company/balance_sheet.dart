import 'package:equatable/equatable.dart';

class BalanceSheet extends Equatable {
  final String id;
  final String year;
  final String shareCapital;
  final String reserves;
  final String borrowings;
  final String otherLiabilities;
  final String totalLiabilities;
  final String fixedAssets;
  final String currentAssets;
  final String investments;
  final String otherAssets;
  final String totalAssets;

  BalanceSheet(
      {required this.id,
      required this.year,
      required this.shareCapital,
      required this.reserves,
      required this.borrowings,
      required this.otherLiabilities,
      required this.totalLiabilities,
      required this.fixedAssets,
      required this.currentAssets,
      required this.investments,
      required this.otherAssets,
      required this.totalAssets});

  Map<String, String> toDataRow() {
    Map<String, String> dataRow = Map();
    dataRow.putIfAbsent("Share Capital", () => shareCapital);
    dataRow.putIfAbsent("Reserves", () => reserves);
    dataRow.putIfAbsent("Borrowings", () => borrowings);
    dataRow.putIfAbsent("Other Liabilities", () => otherLiabilities);
    dataRow.putIfAbsent("Total Liabilities", () => totalLiabilities);
    dataRow.putIfAbsent("Year", () => year);
    dataRow.putIfAbsent("Fixed Assets", () => fixedAssets);
    dataRow.putIfAbsent("Current Assets", () => currentAssets);
    dataRow.putIfAbsent("Investments", () => investments);
    dataRow.putIfAbsent("Other Assets", () => otherAssets);
    dataRow.putIfAbsent("Total Assets", () => totalAssets);
    return dataRow;
  }

  @override
  // TODO: implement props
  List<Object> get props => [
        id,
        year,
        shareCapital,
        reserves,
        borrowings,
        otherLiabilities,
        totalLiabilities,
        fixedAssets,
        currentAssets,
        investments,
        otherAssets,
        totalAssets
      ];
}

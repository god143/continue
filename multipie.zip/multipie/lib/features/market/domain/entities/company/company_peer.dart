import 'package:equatable/equatable.dart';

class CompanyPeer extends Equatable {
  final String iconUrl;
  final String name;
  final String marketCap;
  final String id;
  final String peRatio;

  CompanyPeer({
    required this.id,
    required this.name,
    required this.iconUrl,
    required this.marketCap,
    required this.peRatio,
  });

  @override
  List<Object> get props => [id, name, iconUrl, marketCap, peRatio];
}

import 'package:equatable/equatable.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

class InvestorsData extends Equatable {
  final List<UserModel> userModel;
  final int investorCount;

  InvestorsData({required this.userModel, required this.investorCount});

  @override
  List<Object?> get props => [userModel, investorCount];
}

import 'package:equatable/equatable.dart';

class CompanyStats extends Equatable {
  final String id;
  final String marketCap;
  final String enterpriseValue;
  final String threeMonthAvgVol;
  final String stockPE;
  final String pBook;
  final String marketCapToCashflow;
  final String evEbidta;
  final String dividendYield;
  final String fiftyDayMovingAvg;
  final String salesGrowth;
  final String roce;
  final String roe;
  final String netProfitTTM;

  CompanyStats(
      {required this.id,
      required this.marketCap,
      required this.enterpriseValue,
      required this.threeMonthAvgVol,
      required this.stockPE,
      required this.pBook,
      required this.marketCapToCashflow,
      required this.evEbidta,
      required this.dividendYield,
      required this.fiftyDayMovingAvg,
      required this.salesGrowth,
      required this.roce,
      required this.roe,
      required this.netProfitTTM});

  @override
  List<Object> get props => [
        id,
        marketCap,
        enterpriseValue,
        threeMonthAvgVol,
        stockPE,
        pBook,
        marketCapToCashflow,
        evEbidta,
        dividendYield,
        fiftyDayMovingAvg,
        salesGrowth,
        roce,
        roe,
        netProfitTTM
      ];
}

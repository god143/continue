import 'package:equatable/equatable.dart';

class CurrentMarketPrice extends Equatable {
  final String lastTradedPrice;
  final String openPrice;
  final String type;
  final String id;
  final String exchange;
  final String lastClosePrice;
  final String volume;
  final String lowToday;
  final String highToday;
  final String fifty2WeekLow;
  final String fifty2WeekHigh;

  CurrentMarketPrice({
    required this.id,
    required this.type,
    required this.lastTradedPrice,
    required this.exchange,
    required this.openPrice,
    required this.lastClosePrice,
    required this.volume,
    required this.lowToday,
    required this.highToday,
    required this.fifty2WeekLow,
    required this.fifty2WeekHigh,
  });

  @override
  List<Object> get props => [
        id,
        lastTradedPrice,
        exchange,
        openPrice,
        lastClosePrice,
        volume,
        lowToday,
        fifty2WeekLow,
        fifty2WeekHigh
      ];
}

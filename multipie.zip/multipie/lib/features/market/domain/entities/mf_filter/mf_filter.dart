class MFFilter {
  late List<String> equity;
  late List<String> debt;
  late List<String> gold;

  MFFilter({
    equity,
    debt,
    gold,
  }): equity = [], debt = [], gold = [];

  MFFilter.fromJson(Map<String, dynamic> json) {
    equity = json['Equity'].cast<String>();
    debt = json['Debt'].cast<String>();
    gold = json['Gold'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Equity'] = this.equity;
    data['Debt'] = this.debt;
    data['Gold'] = this.gold;
    return data;
  }
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/company_stats.dart';
import 'package:multipie/features/market/domain/repositories/company_stats_repository.dart';

class GetCompanyStats implements UseCase<CompanyStats, Params> {
  final CompanyStatsRepository repository;

  GetCompanyStats(this.repository);

  @override
  Future<Either<Failure, CompanyStats>> call(Params params) async {
    return await repository.getCompanyStats(params.id, params.stats);
  }
}

class Params extends Equatable {
  final String id;
  final String stats;

  Params({required this.id, required this.stats});

  @override
  List<Object> get props => [id, stats];
}

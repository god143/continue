import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/balance_sheet.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetBalanceSheet implements UseCase<List<BalanceSheet>, Params> {
  final CompanyRepository repository;

  GetBalanceSheet(this.repository);

  @override
  Future<Either<Failure, List<BalanceSheet>>> call(Params params) async {
    return await repository.getBalanceSheet(
        params.id, params.url, params.isConsolidated);
  }
}

class Params extends Equatable {
  final String id;
  final String url;
  final bool isConsolidated;

  Params({required this.id, required this.url, required this.isConsolidated});

  @override
  List<Object> get props => [id, url, isConsolidated];
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/promoter_share_holding.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetPromoterHoldings implements UseCase<List<PromoterHolding>, Params> {
  final CompanyRepository repository;

  GetPromoterHoldings(this.repository);

  @override
  Future<Either<Failure, List<PromoterHolding>>> call(Params params) async {
    return await repository.getPromoterHoldings(params.id, params.url);
  }
}

class Params extends Equatable {
  final String id;
  final String url;

  Params({required this.id, required this.url});

  @override
  List<Object> get props => [id, url];
}

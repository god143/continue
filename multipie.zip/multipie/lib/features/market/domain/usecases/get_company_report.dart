import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/data/models/company/company_report.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetCompanyReport implements UseCase<List<CompanyReport>, GetCompanyReportParams> {
  final CompanyRepository repository;

  GetCompanyReport(this.repository);

  @override
  Future<Either<Failure, List<CompanyReport>>> call(GetCompanyReportParams params) => repository.getCompanyReport(
        companyId: params.companyId,
        reportType: params.reportType,
        reportStatementType: params.reportStatementType,
      );
}

enum CompanyReportType { results, pnl, balanceSheet, cashflow, promoterShareHolding }
enum CompanyReportStatementType { standalone, consolidated }

class GetCompanyReportParams extends Equatable {
  final String companyId;
  final CompanyReportType reportType;
  final CompanyReportStatementType reportStatementType;

  GetCompanyReportParams({
    required this.companyId,
    required this.reportType,
    required this.reportStatementType,
  });

  @override
  List<Object> get props => [id];
}

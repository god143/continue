import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_investor_data.dart';
import 'package:multipie/features/market/domain/repositories/mf_investor_repository.dart';

class GetMFInvestorsUsecase extends UseCase<MFInvestorsData, Params> {
  final MFInvestorRepository mfInvestorRepository;

  GetMFInvestorsUsecase(this.mfInvestorRepository);

  @override
  Future<Either<Failure, MFInvestorsData>> call(Params params) async {
    return await mfInvestorRepository.getMFInvestorsList(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

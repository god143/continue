import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/data/models/company/company_news_model.dart';
import 'package:multipie/features/market/domain/entities/company/company_peer.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetCompanyNewsListUseCase implements UseCase<CompanyNewsModel, Params> {
  final CompanyRepository repository;

  GetCompanyNewsListUseCase(this.repository);

  @override
  Future<Either<Failure, CompanyNewsModel>> call(Params params) async {
    return await repository.getCompanyNewsList(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

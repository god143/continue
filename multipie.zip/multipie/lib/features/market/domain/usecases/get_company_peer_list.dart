import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/company_peer.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetCompanyPeerList implements UseCase<List<CompanyPeer>, Params> {
  final CompanyRepository repository;

  GetCompanyPeerList(this.repository);

  @override
  Future<Either<Failure, List<CompanyPeer>>> call(Params params) async {
    return await repository.getCompanyPeerList(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

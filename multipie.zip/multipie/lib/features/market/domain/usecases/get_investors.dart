import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/investors_data.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetInvestorsList implements UseCase<InvestorsData, Params> {
  final CompanyRepository repository;

  GetInvestorsList(this.repository);

  @override
  Future<Either<Failure, InvestorsData>> call(Params params) async {
    return await repository.getInvestorsList(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mp_mf_collection.dart';
import 'package:multipie/features/market/domain/repositories/mp_mf_collection_repository.dart';

class GetMPMutualFundCollectionData
    implements UseCase<List<MPMutualFundCollection>, Params> {
  final MPMutualFundCollectionRepository repository;

  GetMPMutualFundCollectionData(this.repository);

  @override
  Future<Either<Failure, List<MPMutualFundCollection>>> call(
      Params params) async {
    return await repository.getMPMutualFundCollectionData(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

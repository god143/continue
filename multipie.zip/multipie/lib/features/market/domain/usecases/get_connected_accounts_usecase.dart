import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/connected_accounts/data/models/connected_accounts_model.dart';
import 'package:multipie/features/market/domain/repositories/company_details_repository.dart';

class GetConnectedAccountsUsecase implements UseCase<List<ConnectedAccountsModel>, void> {
  final CompanyDetailsRepository repository;

  GetConnectedAccountsUsecase(this.repository);

  @override
  Future<Either<Failure, List<ConnectedAccountsModel>>> call(void params) async {
    return await repository.getConnectedAccountsList();
  }
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';
import 'package:multipie/features/market/domain/repositories/company_details_repository.dart';

class GetCompanyDetails implements UseCase<CompanyDetails, Params> {
  final CompanyDetailsRepository repository;

  GetCompanyDetails(this.repository);

  @override
  Future<Either<Failure, CompanyDetails>> call(Params params) async {
    return await repository.getCompanyDetails(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

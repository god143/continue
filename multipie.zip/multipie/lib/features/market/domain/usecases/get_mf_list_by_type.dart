import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_list_by_type.dart';
import 'package:multipie/features/market/domain/repositories/mf_list_by_type_repository.dart';

class GetMFListByType implements UseCase<List<MFListByType>, Params> {
  final MFListByTypeRepository repository;

  GetMFListByType(this.repository);

  @override
  Future<Either<Failure, List<MFListByType>>> call(Params params) async {
    return await repository.getMFListByType(
        params.id, params.fromMutualFunds, params.strFilter, params.pageSize, params.page);
  }
}

class Params extends Equatable {
  final String? id;
  final bool fromMutualFunds;
  final String strFilter;
  final int pageSize;
  final int page;

  Params(
      {required this.id,
      required this.fromMutualFunds,
      required this.strFilter,
      required this.pageSize,
      required this.page});

  @override
  List<Object> get props => [id!];
}

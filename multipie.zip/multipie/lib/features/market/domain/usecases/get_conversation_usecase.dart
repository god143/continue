import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/repositories/company_details_repository.dart';
import 'package:multipie/features/post/data/models/post_model.dart';

class GetConversationUsecase extends UseCase<List<PostModel>, ConversationParams> {
  final CompanyDetailsRepository repository;

  GetConversationUsecase(this.repository);

  @override
  Future<Either<Failure, List<PostModel>>> call(ConversationParams params) {
    return repository.getConversationOnStock(params.companyId);
  }
}

class ConversationParams extends Equatable {
  final String companyId;

  ConversationParams({required this.companyId});

  @override
  List<Object> get props => [companyId];
}

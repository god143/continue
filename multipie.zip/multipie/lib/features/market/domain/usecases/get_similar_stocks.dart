import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/similar_stocks.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetSimilarStocksList implements UseCase<List<SimilarStocks>, Params> {
  final CompanyRepository repository;

  GetSimilarStocksList(this.repository);

  @override
  Future<Either<Failure, List<SimilarStocks>>> call(Params params) async {
    return await repository.getSimilarStocksList(params.id);
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

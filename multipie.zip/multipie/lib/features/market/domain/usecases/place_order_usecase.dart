import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/repositories/company_details_repository.dart';

class PlaceOrderUsecase implements UseCase<Map<String, dynamic>, Params> {
  final CompanyDetailsRepository repository;

  PlaceOrderUsecase(this.repository);

  @override
  Future<Either<Failure, Map<String, dynamic>>> call(Params params) async {
    return await repository.placeOrder(
      params.exchange,
      params.symbol,
      params.series,
      params.quantity,
      params.price,
      params.orderType,
      params.amo,
      params.transactionType,
      params.brokerIdentifier,
      params.averagePrice,
    );
  }
}

class Params extends Equatable {
  final String exchange;
  final String symbol;
  final String series;
  final int quantity;
  final double price;
  final String orderType;
  final String amo;
  final String transactionType;
  final String brokerIdentifier;
  final double averagePrice;

  Params(
      {required this.exchange,
      required this.symbol,
      required this.series,
      required this.quantity,
      required this.price,
      required this.orderType,
      required this.amo,
      required this.transactionType,
      required this.brokerIdentifier,
      required this.averagePrice});

  @override
  List<Object> get props => [
        exchange,
        symbol,
        series,
        quantity,
        price,
        orderType,
        amo,
        transactionType,
        brokerIdentifier,
      ];
}

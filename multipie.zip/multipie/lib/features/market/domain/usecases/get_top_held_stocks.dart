import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';
import 'package:dartz/dartz.dart';

import 'package:multipie/core/utils/failures.dart';

class GetTopHeldStockUseCase implements UseCase<List<Company>, StockParams> {
  final CompanyRepository repository;

  GetTopHeldStockUseCase(this.repository);

  @override
  Future<Either<Failure, List<Company>>> call(StockParams params) async {
    return await repository.getTopHeldStocks(params.sortBy, params.count);
  }
}

class StockParams extends Equatable {
  final String sortBy;
  final int count;
  StockParams({this.sortBy = "top_held", this.count = 50});

  @override
  List<Object> get props => [sortBy, count];
}

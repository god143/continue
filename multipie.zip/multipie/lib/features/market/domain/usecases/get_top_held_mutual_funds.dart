import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:dartz/dartz.dart';

import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';
import 'package:multipie/features/market/domain/repositories/mf_list_by_type_repository.dart';

class GetTopHeldMutualFundsUseCase implements UseCase<List<TopHeldMutualFund>, MutualFundsParams> {
  final MFListByTypeRepository repository;

  GetTopHeldMutualFundsUseCase(this.repository);

  @override
  Future<Either<Failure, List<TopHeldMutualFund>>> call(MutualFundsParams params) async {
    return await repository.getTopHeldMutualFunds(params.sortBy, params.count);
  }
}

class MutualFundsParams extends Equatable {
  final String sortBy;
  final int count;
  MutualFundsParams({this.sortBy = "top_held", this.count = 50});

  @override
  List<Object> get props => [sortBy, count];
}

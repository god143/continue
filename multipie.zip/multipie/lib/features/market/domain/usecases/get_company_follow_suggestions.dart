import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetCompanyFollowSuggestions implements UseCase<List<Company>, Params> {
  final CompanyRepository repository;

  GetCompanyFollowSuggestions(this.repository);

  @override
  Future<Either<Failure, List<Company>>> call(Params params) async {
    return await repository.getCompanyList(
      searchPhrase: params.searchPhrase,
      pageSize: params.pageSize,
      page: params.page,
      sortBy: params.sortBy,
      exchange: params.exchange,
      periodToConsider: params.periodToConsider,
    );
  }
}

class Params extends Equatable {
  final String searchPhrase;
  final int pageSize;
  final int page;
  final String? sortBy;
  final String? exchange;
  final String? periodToConsider;

  Params({
    this.searchPhrase = '',
    this.pageSize = 20,
    this.page = 1,
    this.sortBy,
    this.exchange,
    this.periodToConsider,
  });

  @override
  List<Object> get props => [searchPhrase, pageSize, page];
}

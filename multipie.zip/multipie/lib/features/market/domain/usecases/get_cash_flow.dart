import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/cash_flow.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetCashFlow implements UseCase<List<CashFlow>, Params> {
  final CompanyRepository repository;

  GetCashFlow(this.repository);

  @override
  Future<Either<Failure, List<CashFlow>>> call(Params params) async {
    return await repository.getCashFlow(
        params.id, params.url, params.isConsolidated);
  }
}

class Params extends Equatable {
  final String id;
  final String url;
  final bool isConsolidated;

  Params({required this.id, required this.url, required this.isConsolidated});

  @override
  List<Object> get props => [id, url, isConsolidated];
}

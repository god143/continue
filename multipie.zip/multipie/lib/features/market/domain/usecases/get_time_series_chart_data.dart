import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/company/company_timeseries.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetTimeSeriesChartData
    implements UseCase<List<CompanyTimeSeries>, Params> {
  final CompanyRepository repository;
  GetTimeSeriesChartData(this.repository);
  @override
  Future<Either<Failure, List<CompanyTimeSeries>>> call(Params params) async {
    return await repository.getTimeSeriesData(
        params.id, params.exchange, params.period);
  }
}

class Params extends Equatable {
  final String id;
  final String exchange;
  final String period;

  Params({required this.id, required this.exchange, required this.period});

  @override
  List<Object> get props => [id, exchange, period];
}

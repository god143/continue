import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/connected_accounts/data/models/connected_accounts_model.dart';
import 'package:multipie/features/market/domain/repositories/company_details_repository.dart';

class GetAmoUsecase implements UseCase<bool, void> {
  final CompanyDetailsRepository repository;

  GetAmoUsecase(this.repository);

  @override
  Future<Either<Failure, bool>> call(void params) async {
    return await repository.getIsAmo();
  }
}

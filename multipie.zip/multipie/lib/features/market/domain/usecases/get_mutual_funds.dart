import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';

class GetMutualFunds implements UseCase<List<MutualFund>, Params> {
  final CompanyRepository repository;

  GetMutualFunds(this.repository);

  @override
  Future<Either<Failure, List<MutualFund>>> call(Params params) async {
    return await repository.getMutualFundData(params.searchPhrase);
  }
}

class Params extends Equatable {
  final String searchPhrase;

  Params({required this.searchPhrase});

  @override
  List<Object> get props => [searchPhrase];
}

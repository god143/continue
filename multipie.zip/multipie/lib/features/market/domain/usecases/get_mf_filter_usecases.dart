import 'package:multipie/core/utils/failures.dart';
import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/market/domain/entities/mf_filter/mf_filter.dart';
import 'package:multipie/features/market/domain/repositories/mf_filter_repository.dart';

class GetMFFilterUseCase implements UseCase<MFFilter, NoParams> {
  final MFFilterRespository mfFilterRespository;

  GetMFFilterUseCase(this.mfFilterRespository);
  @override
    Future<Either<Failure, MFFilter>> call(NoParams params) async {
    return await mfFilterRespository.getMFFilterList();
  }
}
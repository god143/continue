import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/company_stats.dart';

abstract class CompanyStatsRepository {
  Future<Either<Failure, CompanyStats>> getCompanyStats(String id,String stats);

}

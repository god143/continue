import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mp_mf_collection.dart';

abstract class MPMutualFundCollectionRepository {
  Future<Either<Failure, List<MPMutualFundCollection>>>
      getMPMutualFundCollectionData(String id);
}

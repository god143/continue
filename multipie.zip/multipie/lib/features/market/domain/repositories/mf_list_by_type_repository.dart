import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_list_by_type.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';

abstract class MFListByTypeRepository {
  Future<Either<Failure, List<MFListByType>>> getMFListByType(
      String? id, bool fromMutualFunds, String strFilter, int pageSize, int page);

  Future<Either<Failure, List<TopHeldMutualFund>>> getTopHeldMutualFunds(String sortBy, int count);
}

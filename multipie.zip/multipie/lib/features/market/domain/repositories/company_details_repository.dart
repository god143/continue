import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/connected_accounts/data/models/connected_accounts_model.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';
import 'package:multipie/features/post/data/models/post_model.dart';

abstract class CompanyDetailsRepository {
  Future<Either<Failure, CompanyDetails>> getCompanyDetails(String id);

  Future<Either<Failure, List<PostModel>>> getConversationOnStock(String companyId);

  Future<Either<Failure, List<ConnectedAccountsModel>>> getConnectedAccountsList();

  Future<Either<Failure, bool>> getIsAmo();

  Future<Either<Failure, Map<String, dynamic>>> placeOrder(
    String exchange,
    String symbol,
    String series,
    int quantity,
    double price,
    String orderType,
    String amo,
    String transactionType,
    String brokerIdentifier,
    double averagePrice,
  );
}

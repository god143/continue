import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_investor_data.dart';

abstract class MFInvestorRepository {
  Future<Either<Failure, MFInvestorsData>> getMFInvestorsList(String id);
}

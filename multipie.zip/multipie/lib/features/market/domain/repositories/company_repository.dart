import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/data/models/company/company_news_model.dart';
import 'package:multipie/features/market/data/models/company/company_report.dart';
import 'package:multipie/features/market/domain/entities/company/balance_sheet.dart';
import 'package:multipie/features/market/domain/entities/company/cash_flow.dart';
import 'package:multipie/features/market/domain/entities/company/company_peer.dart';
import 'package:multipie/features/market/domain/entities/company/company_timeseries.dart';
import 'package:multipie/features/market/domain/entities/company/investors_data.dart';
import 'package:multipie/features/market/domain/entities/company/promoter_share_holding.dart';
import 'package:multipie/features/market/domain/entities/company/similar_stocks.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/market/domain/usecases/get_company_report.dart';

import '../entities/company/company.dart';
import '../entities/company/quarterly_results.dart';

abstract class CompanyRepository {
  Future<Either<Failure, List<Company>>> getCompanyList({
    required String searchPhrase,
    required int pageSize,
    required int page,
    String? sortBy,
    String? exchange,
    String? periodToConsider,
  });

  Future<Either<Failure, List<Company>>> getTopHeldStocks(String sortBy, int count);

  Future<Either<Failure, List<CompanyPeer>>> getCompanyPeerList(String id);

  Future<Either<Failure, CompanyNewsModel>> getCompanyNewsList(String id);

  Future<Either<Failure, List<SimilarStocks>>> getSimilarStocksList(String id);

  Future<Either<Failure, InvestorsData>> getInvestorsList(String id);

  Future<Either<Failure, List<QuarterlyResults>>> getQuarterlyResults(String id, String url, bool isConsolidated);

  Future<Either<Failure, List<CompanyReport>>> getCompanyReport({
    required String companyId,
    required CompanyReportType reportType,
    required CompanyReportStatementType reportStatementType,
  });

  Future<Either<Failure, List<BalanceSheet>>> getBalanceSheet(String id, String url, bool isConsolidated);

  Future<Either<Failure, List<CashFlow>>> getCashFlow(String id, String url, bool isConsolidated);

  Future<Either<Failure, List<PromoterHolding>>> getPromoterHoldings(String id, String url);

  Future<Either<Failure, List<CompanyTimeSeries>>> getTimeSeriesData(String id, String exchange, String period);

  Future<Either<Failure, List<MutualFund>>> getMutualFundData(String period);
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/mf_filter/mf_filter.dart';

abstract class MFFilterRespository {
  Future<Either<Failure, MFFilter>> getMFFilterList();
}

import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/market/data/models/mutual_fund/mf_list_by_type_model.dart';
import 'package:multipie/features/market/data/models/mutual_fund/top_mutual_fund_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class MFListByTypeRemoteDataSource {
  Future<List<MFListByTypeModel>> getMFListByTypeData(
      String? id, bool fromMutualFunds, String strFilter, int pageSize, int page);

  Future<List<TopMutualFundModel>> getTopHeldMutualFunds(String sortBy, int count);
}

class MFListByTypeRemoteDataSourceImpl implements MFListByTypeRemoteDataSource {
  final NetworkService networkService;
  MFListByTypeRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<MFListByTypeModel>> getMFListByTypeData(id, fromMutualFunds, strFilter, pageSize, page) =>
      getMFListByTypeFromService('/multi_boxes', id, fromMutualFunds, strFilter, pageSize, page);

  Future<List<MFListByTypeModel>> getMFListByTypeFromService(
      String url, String? id, bool fromMutualFunds, String strFilter, int pageSize, int page) async {
    var jsonApi;
    if (fromMutualFunds) {
      var pgParams = 'page_size=$pageSize&page=$page';
      strFilter = strFilter != null ? strFilter + '&$pgParams' : pgParams;

      jsonApi = await networkService.getRequest('/mutual_funds?$strFilter');
    } else {
      jsonApi = await networkService.getRequest('$url/$id');
    }
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);

      Iterable data = fromMutualFunds ? json['data'] : json['data']['mutual_funds'];
      return data.map((data) => MFListByTypeModel.fromJson(data)).toList();
    } catch (e) {
      print(e.toString());
      throw ServerException('Failed to get posts from data');
    }
  }

  ///mutual_funds?sort_by=top_held&page_size=3
  @override
  Future<List<TopMutualFundModel>> getTopHeldMutualFunds(sortBy, count) =>
      getTopHeldMutualFundsFromService('/mutual_funds?sort_by=$sortBy&page_size=$count');

  Future<List<TopMutualFundModel>> getTopHeldMutualFundsFromService(String url) async {
    final jsonApi = await networkService.getRequest(url);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => TopMutualFundModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get company list from data');
    }
  }
}

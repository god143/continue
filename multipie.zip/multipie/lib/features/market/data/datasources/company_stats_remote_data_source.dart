import 'dart:convert';

import 'package:japx/japx.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/market/data/models/company/company_stats_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class CompanyStatsRemoteDataSource {
  Future<CompanyStatsModel> getCompanyStats(String id, String stats);
}

class CompanyStatsRemoteDataSourceImpl implements CompanyStatsRemoteDataSource {
  final NetworkService networkService;

  CompanyStatsRemoteDataSourceImpl({required this.networkService});

  @override
  Future<CompanyStatsModel> getCompanyStats(String id, String stats) =>
      getCompanyStatsFromService('/companies', id, stats);

  Future<CompanyStatsModel> getCompanyStatsFromService(
      String url, String id, String stats) async {
    // Map<String, String> headers = {"statement": stats};
    var urlToSubmit = '$url/$id/stats?statement=$stats';

    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> jsonData = Japx.decode(jsonApi);
      Constants.companyStatsWidgetString = json.encode(jsonData['data'][0]);
      return CompanyStatsModel.fromJson(jsonData['data'][0]);
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }
}

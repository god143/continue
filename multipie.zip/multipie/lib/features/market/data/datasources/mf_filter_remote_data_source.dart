import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/market/data/models/mutual_fund/mf_filter_model.dart';
import 'package:multipie/features/market/domain/entities/mf_filter/mf_filter.dart';
import 'package:multipie/services/network_service.dart';

abstract class MFFilterRemoteDataSource {
  Future<MFFilter> getMFFilterList();
}

class MFFilterRemoteDataSourceImpl implements MFFilterRemoteDataSource {
  final NetworkService networkService;
  MFFilterRemoteDataSourceImpl({required this.networkService});

  @override
  Future<MFFilter> getMFFilterList() =>
      getMFFilterListFromService('/mutual_funds/available_filters');

  Future<MFFilter> getMFFilterListFromService(String url) async {
    final jsonApi = await networkService.getRequest(url);

    try {
      print("Normal >> " + jsonApi.toString());

      var data = MFFilterModel.fromJson(jsonApi);

      return data.data;
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }
}

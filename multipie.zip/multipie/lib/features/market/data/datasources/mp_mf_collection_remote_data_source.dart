import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/market/data/models/mutual_fund/mp_mf_collection_model.dart';
import 'package:multipie/services/network_service.dart';

///Being Used for grid on mutual fund explore screen
abstract class MPMutualFundCollectionRemoteDataSource {
  Future<List<MPMutualFundCollectionModel>> getMPMutualFundCollectionData(
      String id);
}

class MPMutualFundCollectionRemoteDataSourceImpl
    implements MPMutualFundCollectionRemoteDataSource {
  final NetworkService networkService;
  MPMutualFundCollectionRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<MPMutualFundCollectionModel>> getMPMutualFundCollectionData(id) =>
      getMPMutualFundCollectionDataFromService('/multi_boxes', id);

  Future<List<MPMutualFundCollectionModel>>
      getMPMutualFundCollectionDataFromService(String url, String id) async {
    final jsonApi = await networkService.getRequest('$url');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data
          .map((data) => MPMutualFundCollectionModel.fromJson(data))
          .toList();
      //return MPMutualFundCollectionModel.fromJson(json['data']);
    } catch (e) {
      print(e.toString());
      throw ServerException('Failed to get posts from data');
    }
  }
}

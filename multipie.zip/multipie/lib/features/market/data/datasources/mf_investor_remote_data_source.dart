import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_investor_data.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class MFInvestorRemoteDataSource {
  Future<MFInvestorsData> getMFInvestorsList(String id);
}

class MFInvestorRemoteDataSourceImpl implements MFInvestorRemoteDataSource {
  final NetworkService networkService;

  MFInvestorRemoteDataSourceImpl({required this.networkService});

  @override
  Future<MFInvestorsData> getMFInvestorsList(String id) => getInvestorsFromService('/mutual_funds', id);

  Future<MFInvestorsData> getInvestorsFromService(String path, String id) async {
    String urlToSubmit = "$path/$id/investors";
    final jsonApi = await networkService.getRequest(urlToSubmit);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return MFInvestorsData(
          userModel: data.map((post) => UserModel.fromJson(post)).toList(),
          investorCount: jsonApi['meta']['investors_count']);
    } catch (e) {
      throw ServerException('Failed to get investors data');
    }
  }
}

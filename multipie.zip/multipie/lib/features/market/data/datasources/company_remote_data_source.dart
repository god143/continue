import 'dart:convert';

import 'package:japx/japx.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/market/data/models/company/balance_sheet_model.dart';
import 'package:multipie/features/market/data/models/company/cash_flow_model.dart';
import 'package:multipie/features/market/data/models/company/company_model.dart';
import 'package:multipie/features/market/data/models/company/company_news_model.dart';
import 'package:multipie/features/market/data/models/company/company_peer_model.dart';
import 'package:multipie/features/market/data/models/company/company_report.dart';
import 'package:multipie/features/market/data/models/company/company_time_series_model.dart';
import 'package:multipie/features/market/data/models/company/promoter_holding_model.dart';
import 'package:multipie/features/market/data/models/company/quarterly_results_model.dart';
import 'package:multipie/features/market/data/models/company/similar_stocks_model.dart';
import 'package:multipie/features/market/data/models/mutual_fund/mutual_fund_model.dart';
import 'package:multipie/features/market/domain/entities/company/investors_data.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class CompanyRemoteDataSource {
  Future<List<CompanyModel>> getCompanyList({
    required String searchPhrase,
    required int pageSize,
    required int page,
    String? sortBy,
    String? exchange,
    String? periodToConsider,
  });

  Future<List<CompanyModel>> getTopHeldStocks(String sortby, int count);

  Future<List<QuarterlyResultsModel>> getQuarterlyResults(String id, String url, bool isConsolidated);

  Future<List<CompanyPeerModel>> getCompanyPeerList(String id);

  Future<CompanyNewsModel> getCompanyNewsList(String id);

  Future<List<SimilarStocksModel>> getSimilarStocksList(String id);

  Future<List<BalanceSheetModel>> getBalanceSheet(String id, String url, bool isConsolidated);

  Future<List<CashFlowModel>> getCashFlow(String id, String url, bool isConsolidated);

  Future<InvestorsData> getInvestorsList(String id);

  Future<List<PromoterHoldingModel>> getPromoterHoldings(String id, String url);

  Future<List<CompanyTimeSeriesModel>> getTimeSeriesData(String id, String exchange, String period);

  Future<List<MutualFund>> getMutualFundData(String period);

  Future<List<CompanyReport>> getCompanyReport({
    required String id,
    required String reportType,
    required String statementType,
  });
}

class CompanyRemoteDataSourceImpl implements CompanyRemoteDataSource {
  final NetworkService networkService;

  CompanyRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<CompanyModel>> getCompanyList({
    required String searchPhrase,
    required int pageSize,
    required int page,
    String? sortBy,
    String? exchange,
    String? periodToConsider,
  }) =>
      getCompanyListFromService(
        '/companies?page_size=$pageSize&page=$page' +
            '${searchPhrase.isEmpty ? '' : '&search_phrase=' + searchPhrase}' +
            '${sortBy == null ? '' : '&sort_by=' + sortBy}' +
            '${exchange == null ? '' : '&exchange=' + exchange}' +
            '${periodToConsider == null ? '' : '&period_to_consider=' + periodToConsider}',
      );

  Future<List<CompanyModel>> getCompanyListFromService(String url) async {
    final jsonApi = await networkService.getRequest(url);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => CompanyModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get company list from data');
    }
  }

//getTopHeldStocksFromService('/companies?sort_by=top_held&page_size=3');
  @override
  Future<List<CompanyModel>> getTopHeldStocks(sortBy, count) =>
      getTopHeldStocksFromService('/top_held_stocks?sort_by=$sortBy&page_size=$count');

  Future<List<CompanyModel>> getTopHeldStocksFromService(String url) async {
    final jsonApi = await networkService.getRequest(url);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => CompanyModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get company list from data');
    }
  }

  @override
  Future<List<QuarterlyResultsModel>> getQuarterlyResults(String id, String url, bool isConsolidated) =>
      _getQuarterlyResultsFromService('/companies', id, url, isConsolidated);

  Future<List<QuarterlyResultsModel>> _getQuarterlyResultsFromService(
      String path, String id, String url, bool isConsolidated) async {
    String urlToSubmit = "$path/$id/$url?" + "statement=" + (isConsolidated ? "consolidated" : "standalone");
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => QuarterlyResultsModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get quarterly result data');
    }
  }

  @override
  Future<List<BalanceSheetModel>> getBalanceSheet(String id, String url, bool isConsolidated) =>
      _getBalanceSheetFromService('/companies', id, url, isConsolidated);

  Future<List<BalanceSheetModel>> _getBalanceSheetFromService(
      String path, String id, String url, bool isConsolidated) async {
    String urlToSubmit = "$path/$id/$url?" + "statement=" + (isConsolidated ? "consolidated" : "standalone");
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => BalanceSheetModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to Balance sheet data');
    }
  }

  @override
  Future<List<CashFlowModel>> getCashFlow(String id, String url, bool isConsolidated) =>
      _getCashFlowFromService('/companies', id, url, isConsolidated);

  Future<List<CashFlowModel>> _getCashFlowFromService(String path, String id, String url, bool isConsolidated) async {
    String urlToSubmit = "$path/$id/$url?" + "statement=" + (isConsolidated ? "consolidated" : "standalone");
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => CashFlowModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get cashflow data');
    }
  }

  @override
  Future<List<PromoterHoldingModel>> getPromoterHoldings(String id, String url) =>
      _getDataFromService('/companies', id, url);

  Future<List<PromoterHoldingModel>> _getDataFromService(String path, String id, String url) async {
    String urlToSubmit = "$path/$id/$url";
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> jsonData = Japx.decode(jsonApi);
      Constants.companyPromoterHoldingWidgetString = json.encode(jsonData['data']);
      Iterable data = jsonData['data'];
      return data.map((post) => PromoterHoldingModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get promoted holding data');
    }
  }

  @override
  Future<List<CompanyPeerModel>> getCompanyPeerList(String id) => _getCompanyPeersFromService('/companies', id);

  Future<List<CompanyPeerModel>> _getCompanyPeersFromService(String path, String id) async {
    String urlToSubmit = "$path/$id/peers";
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> jsonData = Japx.decode(jsonApi);

      // String str = json.encode(jsonData); // JSON.encode(data) in Dart 1.x
      Constants.peerComparison = json.encode(jsonData).replaceFirst("data", "peers");
      Iterable data = jsonData['data'];
      return data.map((post) => CompanyPeerModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get company peer data');
    }
  }

  @override
  Future<CompanyNewsModel> getCompanyNewsList(String id) {
    final String path;
    if (id.isEmpty) {
      path = '/companies_news';
    } else {
      path = '/companies/$id/news';
    }
    return _getCompanyNewsListFromServer(path);
  }

  Future<CompanyNewsModel> _getCompanyNewsListFromServer(String urlToSubmit) async {
    final jsonApi = await networkService.getRequest(urlToSubmit);
    try {
      return CompanyNewsModel.fromJson(jsonApi);
    } catch (e) {
      throw ServerException('Failed to get company news data');
    }
  }

  @override
  Future<List<SimilarStocksModel>> getSimilarStocksList(String id) => _getSimilarStocksFromService('/companies', id);

  Future<List<SimilarStocksModel>> _getSimilarStocksFromService(String path, String id) async {
    String urlToSubmit = "$path/$id/peers";
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => SimilarStocksModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get company peer data');
    }
  }

  @override
  Future<InvestorsData> getInvestorsList(String id) => _getInvestorsFromService('/companies', id);

  Future<InvestorsData> _getInvestorsFromService(String path, String id) async {
    String urlToSubmit = "$path/$id/investors";
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return InvestorsData(
          userModel: data.map((post) => UserModel.fromJson(post)).toList(),
          investorCount: jsonApi['meta']['investors_count']);
    } catch (e) {
      throw ServerException('Failed to get investors data');
    }
  }

  @override
  Future<List<CompanyTimeSeriesModel>> getTimeSeriesData(String id, String exchange, String period) =>
      _getTimeSeriesDataFromService('/companies', id, exchange, period);

  Future<List<CompanyTimeSeriesModel>> _getTimeSeriesDataFromService(
      String path, String id, String exchange, String period) async {
    String urlToSubmit = "$path/$id/price_time_series?exchange=$exchange&period=$period";

    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => CompanyTimeSeriesModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get time series data');
    }
  }

  @override
  Future<List<MutualFund>> getMutualFundData(String searchPhrase) =>
      _getMutualFundDataFromService('/mutual_funds', searchPhrase);

  Future<List<MutualFund>> _getMutualFundDataFromService(String path, String searchPhrase) async {
    String urlToSubmit = "$path/?search_phrase=$searchPhrase";
    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);

      Iterable data = json['data'];
      return data.map((data) => MutualFundModel.fromJson(data)).toList();
    } catch (e) {
      throw ServerException('Failed to get mutual funds from data');
    }
  }

  @override
  Future<List<CompanyReport>> getCompanyReport({
    required String id,
    required String reportType,
    required String statementType,
  }) async {
    var urlToSubmit = '/companies/$id/$reportType?statement=$statementType';

    final jsonApi = await networkService.getRequest(urlToSubmit);

    try {
      Map<String, dynamic> jsonData = Japx.decode(jsonApi);
      final data = List.from(jsonData['data']);
      return data.map((j) => CompanyReport.fromJson(j)).toList();
    } catch (e) {
      throw ServerException('Failed to get company report from data');
    }
  }
}

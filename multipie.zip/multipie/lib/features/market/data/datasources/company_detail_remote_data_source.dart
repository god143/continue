import 'dart:convert';

import 'package:japx/japx.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/connected_accounts/data/models/connected_accounts_model.dart';
import 'package:multipie/features/market/data/models/company/company_detail_model.dart';
import 'package:multipie/features/post/data/models/post_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class CompanyDetailRemoteDataSource {
  Future<CompanyDetailsModel> getCompanyDetails(String id);

  Future<List<PostModel>> getConversationOnStock(String companyId);

  Future<List<ConnectedAccountsModel>> getConnectedAccountsList();

  Future<bool> getIsAmo();

  Future<Map<String, dynamic>> placeOrder(
    String exchange,
    String symbol,
    String series,
    int quantity,
    double price,
    String orderType,
    String amo,
    String transactionType,
    String brokerIdentifier,
    double averagePrice,
  );
}

class CompanyDetailRemoteDataSourceImpl implements CompanyDetailRemoteDataSource {
  final NetworkService networkService;

  CompanyDetailRemoteDataSourceImpl({required this.networkService});

  @override
  Future<CompanyDetailsModel> getCompanyDetails(String id) => getCompanyDetailsFromService('/companies', id);

  Future<CompanyDetailsModel> getCompanyDetailsFromService(String url, id) async {
    final jsonApi = await networkService.getRequest('$url/$id');
    try {
      String? instrumentId;
      try {
        instrumentId = jsonApi['data']['relationships']['instrument']['data']['id'] as String;
      } catch (_) {
        instrumentId = null;
      }

      Map<String, dynamic> jsonData = Japx.decode(jsonApi);
      Constants.currentPricesWidgetString = json
          .encode(jsonData)
          .replaceFirst("data", "company")
          .replaceAll("fifty2_wk_low", "fifty_2_wk_low")
          .replaceAll("fifty2_wk_high", "fifty_2_wk_high");
      jsonData['data']['instrument_id'] = instrumentId;
      Constants.companyFinancialWidgetString = json.encode({"company_slug": id, "statement": "standalone"});
      return CompanyDetailsModel.fromJson(jsonData['data']);
    } catch (e) {
      print(e.toString());
      throw ServerException('Failed to get posts from data');
    }
  }

  @override
  Future<List<PostModel>> getConversationOnStock(String companyId) async {
    final jsonApi = await networkService.getRequest('/companies/$companyId/conversations');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => PostModel.fromJson(post)).toList();
    } on ServerException catch (e) {
      throw e;
    } catch (e) {
      throw JsonException('Failed to get conversation from data');
    }
  }

  @override
  Future<List<ConnectedAccountsModel>> getConnectedAccountsList() async {
    final jsonApi = await networkService.getRequest('/connected_accounts');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => ConnectedAccountsModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get connected accounts from data');
    }
  }

  @override
  Future<bool> getIsAmo() async {
    final jsonApi = await networkService.getRequest('/transactions/amo');
    try {
      return jsonApi['amo'];
    } catch (e) {
      throw ServerException('Failed to get amo data');
    }
  }

  @override
  Future<Map<String, dynamic>> placeOrder(
    String exchange,
    String symbol,
    String series,
    int quantity,
    double price,
    String orderType,
    String amo,
    String transactionType,
    String brokerIdentifier,
    double averagePrice,
  ) async {
    var params = {
      'exchange': exchange,
      'tradingsymbol': symbol,
      'series': series,
      'quantity': quantity,
      'price': price,
      'orderType': orderType,
      'variety': amo,
      'transactionType': transactionType,
      'brokerIdentifier': brokerIdentifier,
    };
    if (orderType == 'LIMIT') params['averagePrice'] = averagePrice;
    final jsonApi = await networkService.postRequest('/orders', body: params, isUrlEncoded: true);
    return jsonApi;
  }
}

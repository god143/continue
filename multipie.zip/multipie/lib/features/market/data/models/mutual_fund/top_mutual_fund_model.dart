import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';

class TopMutualFundModel extends TopHeldMutualFund {
  TopMutualFundModel({
    required id,
    required name,
    required iconUrl,
    required urlSlug,
    required investorsCount,
  }) : super(
          id: id,
          name: name,
          iconUrl: iconUrl,
          urlSlug: urlSlug,
          investorsCount: investorsCount,
        );

  factory TopMutualFundModel.fromJson(Map<String, dynamic> json) {
    return TopMutualFundModel(
      id: nullReview(json['id']),
      name: nullReview(json['display_name']),
      iconUrl: nullReview(json['logo_url']),
      urlSlug: nullReview(json['url_slug']),
      investorsCount: nullReview(json['investors_count'])
    );
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

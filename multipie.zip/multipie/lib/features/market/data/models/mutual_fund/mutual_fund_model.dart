import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';

class MutualFundModel extends MutualFund {
  MutualFundModel({
    required id,
    required name,
    required type,
    required rating,
    required peopleCount,
    required returnInPercent,
    required iconUrl,
  }) : super(
          id: id,
          name: name,
          iconUrl: iconUrl,
          returnInPercent: returnInPercent,
          peopleCount: peopleCount,
          rating: rating,
          type: type,
        );

  factory MutualFundModel.fromJson(Map<String, dynamic> json) {
    return MutualFundModel(
      id: nullReview(json['id']),
      name: nullReview(json['display_name']),
      type: nullReview(json['category_level1']),
      peopleCount: nullReview(json['people_count']),
      rating: nullReview(json['rating']),
      returnInPercent: nullReview(json['return_in_percent']),
      iconUrl: nullReview(json['logo_url']),
    );
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

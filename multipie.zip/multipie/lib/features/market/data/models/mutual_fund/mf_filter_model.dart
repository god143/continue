import 'package:multipie/features/market/domain/entities/mf_filter/mf_filter.dart';

class MFFilterModel extends MFFilter {
  late MFFilter data;

  MFFilterModel({required this.data});

  MFFilterModel.fromJson(Map<String, dynamic> json) {
    data = new MFFilter.fromJson(json['data']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

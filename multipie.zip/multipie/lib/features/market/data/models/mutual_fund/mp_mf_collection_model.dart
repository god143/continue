import 'package:multipie/features/market/domain/entities/mutual_fund/mp_mf_collection.dart';

class MPMutualFundCollectionModel extends MPMutualFundCollection {
  MPMutualFundCollectionModel({
    required id,
    required title,
    required iconUrl,
    listData,
  }) : super(
          id: id,
          title: title,
          iconUrl: iconUrl,
          listData: listData,
        );

  factory MPMutualFundCollectionModel.fromJson(Map<String, dynamic> json) {
    return MPMutualFundCollectionModel(
      id: nullReview(json['id']),
      iconUrl: nullReview(json['logo_url']),
      title: nullReview(json['name']),
      // listData: json['current_prices']
      //     .map((post) => CurrentMarketPriceModel.fromJson(post))
      //     .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': title,
      'icon_url': iconUrl,
      'current_prices': listData,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

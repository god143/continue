import 'package:multipie/features/market/domain/entities/mutual_fund/mf_list_by_type.dart';

class MFListByTypeModel extends MFListByType {
  MFListByTypeModel({
    required id,
    required name,
    required iconUrl,
    required category,
    required cap,
    required rankInCategory,
    required inceptionDate,
    required amc,
    required type,
    required dividendSubType,
    required fundCategory,
    required peerReturns,
    required factSheetUrl,
    required mfReturnMetaInfo,
  }) : super(
            id: id,
            name: name,
            iconUrl: iconUrl,
            category: category,
            cap: cap,
            rankInCategory: rankInCategory,
            inceptionDate: inceptionDate,
            amc: amc,
            type: type,
            dividendSubType: dividendSubType,
            fundCategory: fundCategory,
            peerReturns: peerReturns,
            factSheetUrl: factSheetUrl,
            mfReturnMetaInfo: mfReturnMetaInfo);

  factory MFListByTypeModel.fromJson(Map<String, dynamic> json) {
    return MFListByTypeModel(
      id: nullReview(json['id']),
      name: nullReview(json['display_name']),
      iconUrl: nullReview(json['logo_url']),
      category: nullReview(json['category_level1']),
      cap: nullReview(json['cap']),
      rankInCategory: nullReview(json['rank_in_category']),
      inceptionDate: nullReview(json['inception_date']),
      amc: nullReview(json['amc']),
      type: nullReview(json['type']),
      dividendSubType: nullReview(json['dividend_sub_type']),
      fundCategory: nullReview(json['fund_category']),
      peerReturns: nullReview(json['peer_returns']),
      factSheetUrl: nullReview(json['fact_sheet_url']),
      mfReturnMetaInfo: json['meta_info'] is Map ? MFReturnsMetaModel.fromJson(json['meta_info']['returns']) : {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'icon_url': iconUrl,
      'category': category,
      'cap': cap,
      'rankInCategory': rankInCategory,
      'inceptionDate': inceptionDate,
      'amc': amc,
      'type': type,
      'dividendSubType': dividendSubType,
      'fundCategory': fundCategory,
      'peerReturns': peerReturns,
      'factSheetUrl': factSheetUrl,
      'meta_info': mfReturnMetaInfo,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

class MFReturnsMetaModel extends MFReturnsMeta {
  MFReturnsMetaModel({
    required mutualFundsReturnFor1Year,
    required mutualFundsReturnFor3Year,
    required mutualFundsReturnFor5Year,
    required mutualFundsReturnSinceInception,
  }) : super(
          mutualFundsReturnFor1Year: mutualFundsReturnFor1Year,
          mutualFundsReturnFor3Year: mutualFundsReturnFor3Year,
          mutualFundsReturnFor5Year: mutualFundsReturnFor5Year,
          mutualFundsReturnSinceInception: mutualFundsReturnSinceInception,
        );

  factory MFReturnsMetaModel.fromJson(Map<String, dynamic> json) {
    return MFReturnsMetaModel(
      mutualFundsReturnFor1Year: nullReview(json['mutualFundsReturnFor1Year']),
      mutualFundsReturnFor3Year: nullReview(json['mutualFundsReturnFor3Year']),
      mutualFundsReturnFor5Year: nullReview(json['mutualFundsReturnFor5Year']),
      mutualFundsReturnSinceInception: nullReview(json['mutualFundsReturnSinceInception']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'mutualFundsReturnFor1Year': mutualFundsReturnFor1Year,
      'mutualFundsReturnFor3Year': mutualFundsReturnFor3Year,
      'mutualFundsReturnFor5Year': mutualFundsReturnFor5Year,
      'mutualFundsReturnSinceInception': mutualFundsReturnSinceInception,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

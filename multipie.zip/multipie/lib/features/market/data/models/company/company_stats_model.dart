import 'dart:math';

import 'package:multipie/features/market/domain/entities/company/company_stats.dart';
import 'package:multipie/core/utils/extensions.dart';

class CompanyStatsModel extends CompanyStats {
  CompanyStatsModel({
    required id,
    required marketCap,
    required enterpriseValue,
    required threeMonthAvgVol,
    required stockPE,
    required pBook,
    required marketCapToCashflow,
    required evEbidta,
    required dividendYield,
    required fiftyDayMovingAvg,
    required salesGrowth,
    required roce,
    required roe,
    required netProfitTTM,
  }) : super(
            id: id,
            marketCap: marketCap,
            enterpriseValue: enterpriseValue,
            threeMonthAvgVol: threeMonthAvgVol,
            stockPE: stockPE,
            pBook: pBook,
            marketCapToCashflow: marketCapToCashflow,
            evEbidta: evEbidta,
            dividendYield: dividendYield,
            fiftyDayMovingAvg: fiftyDayMovingAvg,
            salesGrowth: salesGrowth,
            roce: roce,
            roe: roe,
            netProfitTTM: netProfitTTM);

  factory CompanyStatsModel.fromJson(Map<String, dynamic> json) {
    return CompanyStatsModel(
        id: json['id'].toString(),
        marketCap: (json['mcap'] as double? ?? 0).formatAsCurrency(),
        enterpriseValue: (json['entp_value'] as double? ?? json['entpValue'] as double? ?? 0).formatAsCurrency(),
        //todo to change parameter.
        threeMonthAvgVol: json['threeMonthAvgVol'] == null
            ? ""
            : doubleDecimalPlaceConvert(json['threeMonthAvgVol'].toString()),
        stockPE: doubleDecimalPlaceConvert(
            (json['pe_ratio'] ?? json['peRatio']).toString()),
        pBook: doubleDecimalPlaceConvert(
            (json['pb_ratio'] ?? json['pbRatio']).toString()),
        marketCapToCashflow: doubleDecimalPlaceConvert(
            (json['mcap_to_cashflow'] ?? json['mcapToCashflow']).toString()),
        evEbidta: doubleDecimalPlaceConvert(
            (json['ev_ebitda_ratio'] ?? json['evEbitdaRatio']).toString()),
        dividendYield: doubleDecimalPlaceConvert(
            (json['dividend_yield'] ?? json['dividendYield']).toString()),
        fiftyDayMovingAvg: doubleDecimalPlaceConvert(
            (json['fifty_day_ma'] ?? json['fiftyDayMa']).toString()),
        salesGrowth: (json['sales_growth_last3years'] ??
                json['sales_growth_last_3_years'])
            .toString(),
        roce: doubleDecimalPlaceConvert(
            (json['roce_ttm'] ?? json['roceTtm']).toString()),
        roe: doubleDecimalPlaceConvert(
            (json['roe_ttm'] ?? json['roeTtm']).toString()),
        netProfitTTM: doubleDecimalPlaceConvert((json['net_profit_ttm'] ?? json['netProfitTtm']).toString()));
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'mcap': marketCap,
      'entp_value': enterpriseValue,
      'threeMonthAvgVol': threeMonthAvgVol,
      'pe_ratio': stockPE,
      'pb_ratio': pBook,
      'mcap_to_cashflow': marketCapToCashflow,
      'ev_ebitda_ratio': evEbidta,
      'dividend_yield': dividendYield,
      'fifty_day_ma': fiftyDayMovingAvg,
      'sales_growth_last3years': salesGrowth,
      'roce_ttm': roce,
      'roe_ttm': roe,
      'net_profit_ttm': netProfitTTM,
    };
  }

  static String doubleDecimalPlaceConvert(String inputValue) {
    num mod = pow(10.0, 2);
    return ((double.parse(inputValue) * mod).round().toDouble() / mod)
        .toString();
  }
}

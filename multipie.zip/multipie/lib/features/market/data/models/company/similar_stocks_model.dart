import 'package:multipie/constants.dart';
import 'package:multipie/features/market/domain/entities/company/similar_stocks.dart';

class SimilarStocksModel extends SimilarStocks {
  SimilarStocksModel(
      {required id,
      required iconUrl,
      required displayName,
      lastTradedPrice,
      openPrice})
      : super(
            id: id,
            iconUrl: iconUrl,
            displayName: displayName,
            openPrice: openPrice,
            lastTradedPrice: lastTradedPrice);

  factory SimilarStocksModel.fromJson(Map<String, dynamic> json) {
    return SimilarStocksModel(
        id: json['id'],
        displayName: json['display_name'],
        openPrice: json['current_prices'] != null &&
                json['current_prices'].length > 1 &&
                json['current_prices'][1] != null &&
                json['current_prices'][1]['open_price'] != null
            ? json['current_prices'][1]['open_price']
            : 0.0,
        lastTradedPrice: json['current_prices'] != null &&
                json['current_prices'].length > 1 &&
                json['current_prices'][1] != null &&
                json['current_prices'][1]['last_traded_price'] != null
            ? json['current_prices'][1]['last_traded_price']
            : 0.0,
        iconUrl: json['logo_url'] == null
            ? ""
            : Constants.API_MF_IMAGE_URL + json['logo_url']);
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'display_name': displayName,
      'icon_url': iconUrl,
    };
  }
}

import 'package:multipie/features/market/domain/entities/company/quarterly_results.dart';

class QuarterlyResultsModel extends QuarterlyResults {
  QuarterlyResultsModel(
      {required sales,
      required operatingProfit,
      required opmPercentage,
      required otherIncome,
      required interest,
      required depreciation,
      required profitBeforeTax,
      required taxRate,
      required netProfit,
      required eps,
      required dps,
      required dividendPayoutPercentage,
      required quarter,
      required year,
      required id})
      : super(
            sales: sales,
            operatingProfit: operatingProfit,
            opmPercentage: opmPercentage,
            otherIncome: otherIncome,
            interest: interest,
            depreciation: depreciation,
            profitBeforeTax: profitBeforeTax,
            taxRate: taxRate,
            netProfit: netProfit,
            eps: eps,
            dps: dps,
            dividendPayoutPercentage: dividendPayoutPercentage,
            quarter: quarter,
            year: year,
            id: id);

  factory QuarterlyResultsModel.fromJson(Map<String, dynamic> json) {
    return QuarterlyResultsModel(
        sales: nullReview(json['sales']),
        operatingProfit: nullReview(json['operating_profit']),
        opmPercentage: nullReview(json['opm_percentage']),
        otherIncome: nullReview(json['other_income']),
        interest: nullReview(json['interest']),
        depreciation: nullReview(json['depreciation']),
        profitBeforeTax: nullReview(json['profit_before_tax']),
        taxRate: nullReview(json['tax_rate']),
        netProfit: nullReview(json['net_profit']),
        eps: nullReview(json['eps']),
        dps: nullReview(json['dps']),
        dividendPayoutPercentage:
            nullReview(json['dividend_payout_percentage']),
        quarter: nullReview(json['quarter']),
        year: nullReview(json['year']),
        id: nullReview(json['id']));
  }

  Map<String, dynamic> toJson() {
    return {
      'sales': sales,
      'operating_profit': operatingProfit,
      'opm_percentage': opmPercentage,
      'other_income': otherIncome,
      'interest': interest,
      'depreciation': depreciation,
      'profit_before_tax': profitBeforeTax,
      'tax_rate': taxRate,
      'net_profit': netProfit,
      'eps': eps,
      'dps': dps,
      'dividend_payout_percentage': dividendPayoutPercentage,
      'quarter': quarter,
      'year': year,
      'id': id,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

import 'package:multipie/constants.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/market/data/models/company/current_market_price_model.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

class CompanyModel extends Company {
  CompanyModel({
    required id,
    required name,
    required iconUrl,
    displayName,
    lastTradedPrice,
    listData,
    openPrice,
    addedToWatchlist,
    nseTicker,
    lastClosedPrice,
    percentChange,
    change,
    investorsCount,
    mentionsCount,
  }) : super(
          id: id,
          name: name,
          iconUrl: iconUrl,
          displayName: displayName,
          openPrice: openPrice,
          lastTradedPrice: lastTradedPrice,
          addedToWatchlist: addedToWatchlist,
          listData: listData,
          nseTicker: nseTicker,
          lastClosedPrice: lastClosedPrice,
          percentChange: percentChange,
          change: change,
          investorsCount: investorsCount,
          mentionsCount: mentionsCount,
        );

  factory CompanyModel.fromJson(Map<String, dynamic> json) {
    var lastTradedPrice = json['latest_price'] != null && json['latest_price']['last_traded_price'] != null
        ? json['latest_price']['last_traded_price']
        : 0.0;

    double getLastClosedPrice() {
      double lastClosedPrice = 0.0;
      if (json['current_prices'] != null && json['current_prices'].length > 0 && json['current_prices'][0] != null) {
        var currentPrice = json['current_prices'] as List;
        List<CurrentPrice> currentPriceList =
            currentPrice.map((currentPriceJson) => CurrentPrice.fromJson(currentPriceJson)).toList();
        CurrentPrice cp =
            currentPriceList.firstWhere((element) => element.exchange == 'nse', orElse: () => currentPriceList[0]);
        lastClosedPrice = cp.lastClosePrice;
        lastTradedPrice = cp.lastTradedPrice;
      }
      return lastClosedPrice;
    }

    var lastClosePrice = getLastClosedPrice();
    final closePrice = json['close_price'] as double?;
    final initialPrice = closePrice ?? lastClosePrice;

    double getChange() {
      return doubleTwoDigitRoundOffConverter(lastTradedPrice - initialPrice);
    }

    var change = getChange();

    double percentChange() {
      double percentChange = ((change * 100) / initialPrice);
      percentChange = doubleTwoDigitRoundOffConverter(percentChange);
      if (percentChange.isNaN) percentChange = 0.0;
      return percentChange;
    }

    return CompanyModel(
      id: json['id'],
      name: json['name'] ?? '',
      displayName: json['display_name'],
      addedToWatchlist: false,
      nseTicker: json['nse_ticker'],
      openPrice: json['latest_price'] != null && json['latest_price']['open_price'] != null
          ? json['latest_price']['open_price']
          : 0.0,
      lastTradedPrice: lastTradedPrice,
      listData: json['current_prices'] != null && json['current_prices'].length > 0 && json['current_prices'][0] != null
          ? json['current_prices'].map((post) => CurrentMarketPriceModel.fromJson(post)).toList()
          : null,
      iconUrl: json['logo_url'] == null ? "" : Constants.API_MF_IMAGE_URL + json['logo_url'],
      lastClosedPrice: lastClosePrice,
      percentChange: percentChange(),
      change: change,
      investorsCount: nullReview(json['investors_count']),
      mentionsCount: json['mentions_count'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'display_name': displayName,
      'icon_url': iconUrl,
      'nse_ticker': nseTicker,
      'investors_count': investorsCount
    };
  }
}

class CurrentPrice {
  double lastClosePrice;
  double lastTradedPrice;
  String exchange;

  CurrentPrice({required this.lastClosePrice, required this.lastTradedPrice, required this.exchange});

  factory CurrentPrice.fromJson(Map<String, dynamic> json) {
    return CurrentPrice(
        lastClosePrice: json['last_close_price'] ?? 0.0,
        lastTradedPrice: json['last_traded_price'] ?? 0.0,
        exchange: json['exchange'] ?? '');
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['last_close_price'] = this.lastClosePrice;
    data['last_traded_price'] = this.lastTradedPrice;
    return data;
  }
}

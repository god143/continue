import 'package:multipie/constants.dart';
import 'package:multipie/features/market/domain/entities/company/company_peer.dart';

class CompanyPeerModel extends CompanyPeer {
  CompanyPeerModel(
      {required id,
      required name,
      required iconUrl,
      required marketCap,
      required peRatio})
      : super(
            id: id,
            name: name,
            iconUrl: iconUrl,
            marketCap: marketCap,
            peRatio: peRatio);

  factory CompanyPeerModel.fromJson(Map<String, dynamic> json) {
    return CompanyPeerModel(
        id: json['id'],
        name: json['display_name'] ?? json['displayName'] ?? '',
        marketCap: json['latest_stat'] == null
            ? json['latestStat'] != null
                ? json['latestStat']["mcap"].toString()
                : ""
            : json['latest_stat']["mcap"].toString() ,
        peRatio: json['latest_stat'] == null
            ? json['latestStat'] != null
                ? json['latestStat']["pe_ratio"].toString()
                : ""
            : json['latest_stat']["pe_ratio"].toString(),
        iconUrl: json['logo_url'] == null
            ? ""
            : Constants.API_MF_IMAGE_URL + json['logo_url']);
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'display_name': name,
      'logo_url': iconUrl,
      'latest_stat': marketCap,
      'pe_ratio': peRatio,
    };
  }
}

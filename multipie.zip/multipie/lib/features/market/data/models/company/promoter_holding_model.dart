import 'package:multipie/features/market/domain/entities/company/promoter_share_holding.dart';

class PromoterHoldingModel extends PromoterHolding {
  PromoterHoldingModel(
      {required id,
      required type,
      required promoterShareholding,
      required pledgeShareholding,
      required year,
      required quarter})
      : super(
            id: id,
            type: type,
            promoterShareholding: promoterShareholding,
            pledgeShareholding: pledgeShareholding,
            year: year,
            quarter: quarter);

  factory PromoterHoldingModel.fromJson(Map<String, dynamic> json) {
    return PromoterHoldingModel(
        id: nullReview(json['id']),
        type: nullReview(json['type']),
        promoterShareholding: nullReview(json['promoter_shareholding']),
        pledgeShareholding: nullReview(json['pledge_shareholding']),
        year: nullReview(json['year']),
        quarter: nullReview(json['quarter']));
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'promoter_shareholding': promoterShareholding,
      'pledge_shareholding': pledgeShareholding,
      'year': year,
      'quarter': quarter
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

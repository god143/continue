import 'package:multipie/features/market/domain/entities/company/company_details.dart';

import 'current_market_price_model.dart';

class CompanyDetailsModel extends CompanyDetails {
  CompanyDetailsModel({
    required id,
    required name,
    required iconUrl,
    required listData,
    required bseTicker,
    required nseTicker,
    required statements,
    required companyBio,
    required instrumentId,
  }) : super(
          id: id,
          name: name,
          iconUrl: iconUrl,
          listData: listData,
          bseTicker: bseTicker,
          nseTicker: nseTicker,
          statements: statements,
          companyBio: companyBio,
          instrumentId: instrumentId,
        );

  factory CompanyDetailsModel.fromJson(Map<String, dynamic> json) {
    return CompanyDetailsModel(
      id: nullReview(json['id']),
      iconUrl: nullReview(json['logo_url']),
      name: nullReview(json['name']),
      listData: json['current_prices'].map((post) => CurrentMarketPriceModel.fromJson(post)).toList(),
      bseTicker: nullReview(json['bse_ticker']),
      nseTicker: nullReview(json['nse_ticker']),
      statements: json['statements'].cast<String>(),
      companyBio: json['meta_info']['company_bio'] ?? '',
      instrumentId: json['instrument_id'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'icon_url': iconUrl,
      'current_prices': listData,
      'statements': statements,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

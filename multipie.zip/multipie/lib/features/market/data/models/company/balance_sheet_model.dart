import 'package:multipie/features/market/domain/entities/company/balance_sheet.dart';

class BalanceSheetModel extends BalanceSheet {
  BalanceSheetModel({
    required id,
    required year,
    required shareCapital,
    required reserves,
    required borrowings,
    required otherLiabilities,
    required totalLiabilities,
    required fixedAssets,
    required currentAssets,
    required investments,
    required otherAssets,
    required totalAssets,
  }) : super(
            id: id,
            year: year,
            shareCapital: shareCapital,
            reserves: reserves,
            borrowings: borrowings,
            otherLiabilities: otherLiabilities,
            totalLiabilities: totalLiabilities,
            fixedAssets: fixedAssets,
            currentAssets: currentAssets,
            investments: investments,
            otherAssets: otherAssets,
            totalAssets: totalAssets);

  factory BalanceSheetModel.fromJson(Map<String, dynamic> json) {
    return BalanceSheetModel(
        id: nullReview(json['id']),
        year: nullReview(json['year']),
        shareCapital: nullReview(json['share_capital']),
        reserves: nullReview(json['reserves']),
        borrowings: nullReview(json['borrowings']),
        otherLiabilities: nullReview(json['other_liabilities']),
        totalLiabilities: nullReview(json['total_liabilities']),
        fixedAssets: nullReview(json['fixed_assets']),
        currentAssets: nullReview(json['current_assets']),
        investments: nullReview(json['investments']),
        otherAssets: nullReview(json['other_assets']),
        totalAssets: nullReview(json['total_assets']));
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'year': year,
      'share_capital': shareCapital,
      'reserves': reserves,
      'borrowings': borrowings,
      'other_liabilities': otherLiabilities,
      'total_liabilities': totalLiabilities,
      'fixed_assets': fixedAssets,
      'current_assets': currentAssets,
      'investments': investments,
      'otherAssets': otherAssets,
      'totalAssets': totalAssets
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

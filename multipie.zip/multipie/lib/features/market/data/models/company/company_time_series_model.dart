import 'package:multipie/features/market/domain/entities/company/company_timeseries.dart';

class CompanyTimeSeriesModel extends CompanyTimeSeries {
  CompanyTimeSeriesModel({required id, required date, required closingPrice})
      : super(id: id, date: date, closingPrice: closingPrice);

  factory CompanyTimeSeriesModel.fromJson(Map<String, dynamic> json) {
    return CompanyTimeSeriesModel(
        id: json['id'],
        date: json['price_at'],
        closingPrice: json['value'].toString());
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'on_date': date,
      'close': closingPrice,
    };
  }
}

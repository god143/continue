import 'package:multipie/features/market/domain/entities/company/current_market_price.dart';

class CurrentMarketPriceModel extends CurrentMarketPrice {
  CurrentMarketPriceModel({
    required id,
    required lastTradedPrice,
    required exchange,
    required type,
    required openPrice,
    required lastClosePrice,
    required volume,
    required lowToday,
    required highToday,
    required fifty2WeekLow,
    required fifty2WeekHigh,
  }) : super(
            id: id,
            lastTradedPrice: lastTradedPrice,
            exchange: exchange,
            type: type,
            openPrice: openPrice,
            lastClosePrice: lastClosePrice,
            volume: volume,
            lowToday: lowToday,
            highToday: highToday,
            fifty2WeekLow: fifty2WeekLow,
            fifty2WeekHigh: fifty2WeekHigh);

  factory CurrentMarketPriceModel.fromJson(Map<String, dynamic> json) {
    return CurrentMarketPriceModel(
        id: nullReview(json['id']),
        lastTradedPrice: nullReview(json['last_traded_price']),
        exchange: nullReview(json['exchange']),
        type: nullReview(json['type']),
        openPrice: nullReview(json['open_price']),
        lastClosePrice: nullReview(json['last_close_price']),
        volume: nullReview(json['volume']),
        lowToday: nullReview(json['low_today']),
        highToday: nullReview(json['high_today']),
        fifty2WeekLow: nullReview(json['fifty2_wk_low'] ?? json['fifty_2_wk_low']),
        fifty2WeekHigh: nullReview(json['fifty2_wk_high'] ?? json['fifty_2_wk_high']));
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'last_traded_price': lastTradedPrice,
      'exchange': exchange,
      'type': type,
      'open_price': openPrice,
      'last_close_price': lastClosePrice,
      'volume': volume,
      'low_today': lowToday,
      'high_today': highToday,
      'fifty2_wk_low': fifty2WeekLow,
      'fifty2_wk_high': fifty2WeekHigh,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

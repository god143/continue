import 'package:multipie/features/market/domain/entities/company/cash_flow.dart';

class CashFlowModel extends CashFlow {
  CashFlowModel(
      {required id,
      required year,
      required cfFromOperating,
      required cfFromInvestment,
      required cfFromFinancing,
      required openingCce,
      required closingCce})
      : super(
          id: id,
          year: year,
          cfFromOperating: cfFromOperating,
          cfFromInvestment: cfFromInvestment,
          cfFromFinancing: cfFromFinancing,
          openingCce: openingCce,
          closingCce: closingCce,
        );

  factory CashFlowModel.fromJson(Map<String, dynamic> json) {
    return CashFlowModel(
      id: nullReview(json['id']),
      year: nullReview(json['year']),
      cfFromOperating: nullReview(json['cf_from_operating']),
      cfFromInvestment: nullReview(json['cf_from_investment']),
      cfFromFinancing: nullReview(json['cf_from_financing']),
      openingCce: nullReview(json['opening_cce']),
      closingCce: nullReview(json['closing_cce']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'year': year,
      'cf_from_operating': cfFromOperating,
      'cf_from_investment': cfFromInvestment,
      'cf_from_financing': cfFromFinancing,
      'opening_cce': openingCce,
      'closing_cce': closingCce,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

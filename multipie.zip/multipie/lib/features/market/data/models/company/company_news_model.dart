class CompanyNewsModel {
  int? companyScopeCount;
  List<News>? news;

  CompanyNewsModel({this.companyScopeCount, required this.news});

  CompanyNewsModel.fromJson(Map<String, dynamic> json) {
    companyScopeCount = json['company_scope_count'];
    if (json['news'] != null) {
      news = [];
      json['news'].forEach((v) {
        news!.add(new News.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['company_scope_count'] = this.companyScopeCount;
    if (this.news != null) {
      data['news'] = this.news!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class News {
  int? sno;
  String? dATE;
  String? time;
  String? heading;
  String? caption;
  String? arttext;
  int? coCode;
  String? iSIN;

  News({this.sno, this.dATE, this.time, this.heading, this.caption, this.arttext, this.coCode, this.iSIN});

  News.fromJson(Map<String, dynamic> json) {
    sno = json['sno'];
    dATE = json['DATE'];
    time = json['time'];
    heading = json['heading'];
    caption = json['caption'];
    arttext = json['arttext'];
    coCode = json['co_code'];
    iSIN = json['ISIN'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sno'] = this.sno;
    data['DATE'] = this.dATE;
    data['time'] = this.time;
    data['heading'] = this.heading;
    data['caption'] = this.caption;
    data['arttext'] = this.arttext;
    data['co_code'] = this.coCode;
    data['ISIN'] = this.iSIN;
    return data;
  }
}

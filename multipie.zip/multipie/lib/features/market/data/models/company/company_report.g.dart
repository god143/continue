// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'company_report.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CompanyReport _$CompanyReportFromJson(Map<String, dynamic> json) =>
    CompanyReport(
      id: json['id'] as String,
      year: json['year'] as int,
      quarter: json['quarter'] as int? ?? 4,
      sales: (json['sales'] as num?)?.toDouble(),
      depreciation: (json['depreciation'] as num?)?.toDouble(),
      interest: (json['interest'] as num?)?.toDouble(),
      netProfit: (json['net_profit'] as num?)?.toDouble(),
      operatingProfit: (json['operating_profit'] as num?)?.toDouble(),
      cfFromOperating: (json['cf_from_operating'] as num?)?.toDouble(),
      borrowings: (json['borrowings'] as num?)?.toDouble(),
      shareCapital: (json['share_capital'] as num?)?.toDouble(),
      reserves: (json['reserves'] as num?)?.toDouble(),
      pledgeShareholding: (json['pledge_shareholding'] as num?)?.toDouble(),
      promoterShareholding: (json['promoter_shareholding'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$CompanyReportToJson(CompanyReport instance) =>
    <String, dynamic>{
      'id': instance.id,
      'year': instance.year,
      'quarter': instance.quarter,
      'sales': instance.sales,
      'operating_profit': instance.operatingProfit,
      'interest': instance.interest,
      'depreciation': instance.depreciation,
      'net_profit': instance.netProfit,
      'cf_from_operating': instance.cfFromOperating,
      'borrowings': instance.borrowings,
      'share_capital': instance.shareCapital,
      'reserves': instance.reserves,
      'pledge_shareholding': instance.pledgeShareholding,
      'promoter_shareholding': instance.promoterShareholding,
    };

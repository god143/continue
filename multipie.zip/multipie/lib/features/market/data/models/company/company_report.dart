import 'package:json_annotation/json_annotation.dart';

part 'company_report.g.dart';

@JsonSerializable()
class CompanyReport {
  const CompanyReport({
    required this.id,
    required this.year,
    required this.quarter,
    this.sales,
    this.depreciation,
    this.interest,
    this.netProfit,
    this.operatingProfit,
    this.cfFromOperating,
    this.borrowings,
    this.shareCapital,
    this.reserves,
    this.pledgeShareholding,
    this.promoterShareholding,
  });

  final String id;
  final int year;

  @JsonKey(defaultValue: 4)
  final int quarter;

  final double? sales,
      operatingProfit,
      interest,
      depreciation,
      netProfit,
      cfFromOperating,
      borrowings,
      shareCapital,
      reserves,
      pledgeShareholding,
      promoterShareholding;

  factory CompanyReport.fromJson(Map<String, dynamic> json) => _$CompanyReportFromJson(json);

  Map<String, dynamic> toJson() => _$CompanyReportToJson(this);

  double get ebitda => operatingProfit ?? 0;
  double get ebitdaMargin {
    final _sales = sales ?? 0;
    return _sales != 0 ? (ebitda / _sales) * 100.0 : 0.0;
  }

  double get pat => netProfit ?? 0;
  double get patMargin {
    final _sales = sales ?? 0;
    return _sales != 0 ? (pat / _sales) * 100.0 : 0.0;
  }
}

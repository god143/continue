import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/market/data/datasources/company_stats_remote_data_source.dart';
import 'package:multipie/features/market/domain/entities/company/company_stats.dart';
import 'package:multipie/features/market/domain/repositories/company_stats_repository.dart';

class CompanyStatsRepositoryImpl implements CompanyStatsRepository {
  final NetworkInfo networkInfo;
  final CompanyStatsRemoteDataSource remoteDataSource;

  CompanyStatsRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, CompanyStats>> getCompanyStats(String id, String stats) async {
    return await _getCompanyStatsFromServer(id, stats);
  }

  Future<Either<Failure, CompanyStats>> _getCompanyStatsFromServer(String id, String stats) async {
    if (await networkInfo.isConnected) {
      try {
        //todo implement remote data source
        final remoteCS = await remoteDataSource.getCompanyStats(id, stats);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

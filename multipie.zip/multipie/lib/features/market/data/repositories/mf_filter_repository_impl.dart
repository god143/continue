import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/market/data/datasources/mf_filter_remote_data_source.dart';
import 'package:multipie/features/market/domain/entities/mf_filter/mf_filter.dart';
import 'package:multipie/features/market/domain/repositories/mf_filter_repository.dart';

class MFFilterRepositoryImpl implements MFFilterRespository {
  final NetworkInfo networkInfo;
  final MFFilterRemoteDataSource remoteDataSource;

  MFFilterRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, MFFilter>> getMFFilterList() async {
    return await _getMFFilterListFromServer();
  }

  Future<Either<Failure, MFFilter>> _getMFFilterListFromServer() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getMFFilterList();
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/market/data/datasources/mp_mf_collection_remote_data_source.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mp_mf_collection.dart';
import 'package:multipie/features/market/domain/repositories/mp_mf_collection_repository.dart';

class MPMutualFundCollectionRepositoryImpl implements MPMutualFundCollectionRepository {
  final NetworkInfo networkInfo;
  final MPMutualFundCollectionRemoteDataSource remoteDataSource;

  MPMutualFundCollectionRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, List<MPMutualFundCollection>>> getMPMutualFundCollectionData(id) async {
    return await _getMPMutualFundCollectionDataFromServer(id);
  }

  Future<Either<Failure, List<MPMutualFundCollection>>> _getMPMutualFundCollectionDataFromServer(String id) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteMFL = await remoteDataSource.getMPMutualFundCollectionData(id);
        return Right(remoteMFL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

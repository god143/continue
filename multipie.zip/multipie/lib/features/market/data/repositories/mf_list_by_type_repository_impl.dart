import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/market/data/datasources/mf_list_by_type_remote_data_source.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_list_by_type.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';
import 'package:multipie/features/market/domain/repositories/mf_list_by_type_repository.dart';

class MFListByTypeRepositoryImpl implements MFListByTypeRepository {
  final NetworkInfo networkInfo;
  final MFListByTypeRemoteDataSource remoteDataSource;

  MFListByTypeRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, List<MFListByType>>> getMFListByType(id, fromMutualFunds, strFilter, pageSize, page) async {
    return await _getMFListByTypeFromServer(id, fromMutualFunds, strFilter, pageSize, page);
  }

  Future<Either<Failure, List<MFListByType>>> _getMFListByTypeFromServer(
      String? id, bool fromMutualFunds, String strFilter, int pageSize, int page) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteMFL = await remoteDataSource.getMFListByTypeData(id, fromMutualFunds, strFilter, pageSize, page);
        return Right(remoteMFL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<TopHeldMutualFund>>> getTopHeldMutualFunds(String sortBy, int count) async {
    return await _getTopHeldStocksFromServer(sortBy, count);
  }

  Future<Either<Failure, List<TopHeldMutualFund>>> _getTopHeldStocksFromServer(String sortBy, int count) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTopHeldMutualFunds(sortBy, count);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

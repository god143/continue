import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/connected_accounts/data/models/connected_accounts_model.dart';
import 'package:multipie/features/market/data/datasources/company_detail_remote_data_source.dart';
import 'package:multipie/features/market/domain/entities/company/company_details.dart';
import 'package:multipie/features/market/domain/repositories/company_details_repository.dart';
import 'package:multipie/features/post/data/models/post_model.dart';

class CompanyDetailsRepositoryImpl implements CompanyDetailsRepository {
  final NetworkInfo networkInfo;
  final CompanyDetailRemoteDataSource remoteDataSource;

  CompanyDetailsRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, CompanyDetails>> getCompanyDetails(String id) async {
    return await _getCompanyDetailsFromServer(id);
  }

  Future<Either<Failure, CompanyDetails>> _getCompanyDetailsFromServer(String id) async {
    if (await networkInfo.isConnected) {
      try {
        //todo implement remote data source
        final remoteCS = await remoteDataSource.getCompanyDetails(id);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<PostModel>>> getConversationOnStock(String companyId) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getConversationOnStock(companyId);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<ConnectedAccountsModel>>> getConnectedAccountsList() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getConnectedAccountsList();
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, bool>> getIsAmo() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getIsAmo();
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, Map<String, dynamic>>> placeOrder(
      String exchange,
      String symbol,
      String series,
      int quantity,
      double price,
      String orderType,
      String amo,
      String transactionType,
      String brokerIdentifier,
      double averagePrice) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.placeOrder(
          exchange,
          symbol,
          series,
          quantity,
          price,
          orderType,
          amo,
          transactionType,
          brokerIdentifier,
          averagePrice,
        );
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/market/data/datasources/company_remote_data_source.dart';
import 'package:multipie/features/market/data/models/company/company_news_model.dart';
import 'package:multipie/features/market/data/models/company/company_report.dart';
import 'package:multipie/features/market/domain/entities/company/balance_sheet.dart';
import 'package:multipie/features/market/domain/entities/company/cash_flow.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/entities/company/company_peer.dart';
import 'package:multipie/features/market/domain/entities/company/company_timeseries.dart';
import 'package:multipie/features/market/domain/entities/company/investors_data.dart';
import 'package:multipie/features/market/domain/entities/company/promoter_share_holding.dart';
import 'package:multipie/features/market/domain/entities/company/quarterly_results.dart';
import 'package:multipie/features/market/domain/entities/company/similar_stocks.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/market/domain/repositories/company_repository.dart';
import 'package:multipie/features/market/domain/usecases/get_company_report.dart';

class CompanyRepositoryImpl implements CompanyRepository {
  final NetworkInfo networkInfo;
  final CompanyRemoteDataSource remoteDataSource;

  CompanyRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, List<Company>>> getCompanyList({
    required String searchPhrase,
    required int pageSize,
    required int page,
    String? sortBy,
    String? exchange,
    String? periodToConsider,
  }) async {
    return await _getCompanyListFromServer(
      searchPhrase: searchPhrase,
      pageSize: pageSize,
      page: page,
      sortBy: sortBy,
      exchange: exchange,
      periodToConsider: periodToConsider,
    );
  }

  Future<Either<Failure, List<Company>>> _getCompanyListFromServer({
    required String searchPhrase,
    required int pageSize,
    required int page,
    String? sortBy,
    String? exchange,
    String? periodToConsider,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getCompanyList(
          searchPhrase: searchPhrase,
          pageSize: pageSize,
          page: page,
          sortBy: sortBy,
          exchange: exchange,
          periodToConsider: periodToConsider,
        );
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<Company>>> getTopHeldStocks(String sortBy, int count) async {
    return await _getTopHeldStocksFromServer(sortBy, count);
  }

  Future<Either<Failure, List<Company>>> _getTopHeldStocksFromServer(String sortBy, int count) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTopHeldStocks(sortBy, count);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<CompanyPeer>>> getCompanyPeerList(String id) async {
    return await _getCompanyPeerListFromServer(id);
  }

  Future<Either<Failure, List<CompanyPeer>>> _getCompanyPeerListFromServer(id) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getCompanyPeerList(id);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, CompanyNewsModel>> getCompanyNewsList(String id) async {
    return await _getCompanyNewsList(id);
  }

  Future<Either<Failure, CompanyNewsModel>> _getCompanyNewsList(id) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getCompanyNewsList(id);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<SimilarStocks>>> getSimilarStocksList(String id) async {
    return await _getSimilarStocksListFromServer(id);
  }

  Future<Either<Failure, List<SimilarStocks>>> _getSimilarStocksListFromServer(id) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getSimilarStocksList(id);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, InvestorsData>> getInvestorsList(String id) async {
    return await _getInvestorsListFromServer(id);
  }

  Future<Either<Failure, InvestorsData>> _getInvestorsListFromServer(id) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getInvestorsList(id);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<QuarterlyResults>>> getQuarterlyResults(
      String id, String url, bool isConsolidated) async {
    return await _getQuarterlyResultsFromServer(id, url, isConsolidated);
  }

  Future<Either<Failure, List<QuarterlyResults>>> _getQuarterlyResultsFromServer(
      String id, String url, bool isConsolidated) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getQuarterlyResults(id, url, isConsolidated);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<BalanceSheet>>> getBalanceSheet(String id, String url, bool isConsolidated) async {
    return await _getBalanceSheetFromServer(id, url, isConsolidated);
  }

  Future<Either<Failure, List<BalanceSheet>>> _getBalanceSheetFromServer(
      String id, String url, bool isConsolidated) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getBalanceSheet(id, url, isConsolidated);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<CashFlow>>> getCashFlow(String id, String url, bool isConsolidated) async {
    return await _getCashFlowFromServer(id, url, isConsolidated);
  }

  Future<Either<Failure, List<CashFlow>>> _getCashFlowFromServer(String id, String url, bool isConsolidated) async {
    if (await networkInfo.isConnected) {
      try {
        //todo implement remote data source
        final remoteCS = await remoteDataSource.getCashFlow(id, url, isConsolidated);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<PromoterHolding>>> getPromoterHoldings(String id, String url) async {
    return await _getPromoterHoldingsFromServer(id, url);
  }

  Future<Either<Failure, List<PromoterHolding>>> _getPromoterHoldingsFromServer(String id, String url) async {
    if (await networkInfo.isConnected) {
      try {
        //todo implement remote data source
        final remoteCS = await remoteDataSource.getPromoterHoldings(id, url);
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<CompanyTimeSeries>>> getTimeSeriesData(id, exchange, period) async {
    return await _getCompanyTimeSeriesFromServer(id, exchange, period);
  }

  Future<Either<Failure, List<CompanyTimeSeries>>> _getCompanyTimeSeriesFromServer(
      String id, String exchange, String period) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTimeSeriesData(id, exchange, period);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<MutualFund>>> getMutualFundData(searchPhrase) async {
    return await _getMutualFundsFromServer(searchPhrase);
  }

  Future<Either<Failure, List<MutualFund>>> _getMutualFundsFromServer(String searchPhrase) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getMutualFundData(searchPhrase);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<CompanyReport>>> getCompanyReport({
    required String companyId,
    required CompanyReportType reportType,
    required CompanyReportStatementType reportStatementType,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        String reportTypeValue;
        switch (reportType) {
          case CompanyReportType.results:
            reportTypeValue = 'results';
            break;
          case CompanyReportType.pnl:
            reportTypeValue = 'pnl';
            break;
          case CompanyReportType.balanceSheet:
            reportTypeValue = 'balance_sheet';
            break;
          case CompanyReportType.cashflow:
            reportTypeValue = 'cash_flow';
            break;
          case CompanyReportType.promoterShareHolding:
            reportTypeValue = 'promoter_shareholding';
            break;
        }
        String reportStatementTypeValue;
        switch (reportStatementType) {
          case CompanyReportStatementType.standalone:
            reportStatementTypeValue = 'standalone';
            break;
          case CompanyReportStatementType.consolidated:
            reportStatementTypeValue = 'consolidated';
            break;
        }
        final results = await remoteDataSource.getCompanyReport(
          id: companyId,
          reportType: reportTypeValue,
          statementType: reportStatementTypeValue,
        );
        return Right(results);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/market/data/datasources/mf_investor_remote_data_source.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_investor_data.dart';
import 'package:multipie/features/market/domain/repositories/mf_investor_repository.dart';

class MFInvestorRepositoryImpl implements MFInvestorRepository {
  final NetworkInfo networkInfo;
  final MFInvestorRemoteDataSource mfInvestorRemoteDataSource;

  MFInvestorRepositoryImpl(
      {required this.networkInfo, required this.mfInvestorRemoteDataSource});

  @override
  Future<Either<Failure, MFInvestorsData>> getMFInvestorsList(String id) async {
    return await _getInvestorsListFromServer(id);
  }

  Future<Either<Failure, MFInvestorsData>> _getInvestorsListFromServer(id) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL =
            await mfInvestorRemoteDataSource.getMFInvestorsList(id);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

import 'package:dio/dio.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/models/ConfigResponseModel.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/server_info.dart';
import 'package:multipie/features/config/domain/repositories/fetch_config.dart';

import '../../../../locator.dart';

class FetchConfigIml extends FetchConfig {
  @override
  Future<void> getConfigData() async {
    Dio dio = locator();
    try {
      var response = await dio.get(ServerInfo.baseUrl + "/app_config");
      try {
        ConfigResponseModel responseModel = ConfigResponseModel.fromJson(response.data);
        await setData(responseModel);
      } catch (e) {
        throw ServerException('Failed to get posts from data');
      }
    } catch (e) {
      throw Exception('Failed to load post');
    }
  }

  Future<void> setData(ConfigResponseModel responseModel) async {
    Constants.AUTH_SERVER_URL = responseModel.authServerUrl!;
    Constants.BASE_URL = responseModel.websiteUrl!;
    Constants.WEBSITE_URL = responseModel.websiteUrl!;
    Constants.API_MAIN_URL = responseModel.websiteUrl! + '/api/v1';
    Constants.API_AUTH_URL = Constants.AUTH_SERVER_URL + '/api/v1';
    if (responseModel.showPeopleYouMayKnowAfter != null) {
      Constants.SHOW_PEOPLE_YOU_MAY_KNOW_AFTER = responseModel.showPeopleYouMayKnowAfter!;
    }
    if (responseModel.showTrendingAfter != null) {
      Constants.SHOW_TRENDING_AFTER = responseModel.showTrendingAfter!;
    }
    Constants.VALUEFY_SERVER_URL = responseModel.valuefyServerUrl!;
    Constants.BROKER_CALLBACK_URL = responseModel.brokerCallbackUrl!;
    Constants.LINK_5PAISA_TRANSACTION = responseModel.fivePaisaPwaURL!;
    Constants.ZERODHA_API_KEY = responseModel.zerodhaApiKey!;
  }
}

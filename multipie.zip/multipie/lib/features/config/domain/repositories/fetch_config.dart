abstract class FetchConfig {
  Future<void> getConfigData();
}

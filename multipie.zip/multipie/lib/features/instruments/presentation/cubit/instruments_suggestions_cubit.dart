import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';
import 'package:multipie/features/instruments/domain/get_instruments_suggestions_usecase.dart';

part 'instruments_suggestions_cubit.freezed.dart';
part 'instruments_suggestions_state.dart';

class InstrumentsSuggestionsCubit extends Cubit<InstrumentsSuggestionsState> {
  InstrumentsSuggestionsCubit({
    required GetInstrumentsSuggestionsUsecase getInstrumentsSuggestionsUsecase,
  })  : _getInstrumentsSuggestionsUsecase = getInstrumentsSuggestionsUsecase,
        super(InstrumentsSuggestionsState());

  final GetInstrumentsSuggestionsUsecase _getInstrumentsSuggestionsUsecase;

  static const _page = 1;
  static const _pageSize = 50;

  Future<void> getSuggestions(String input) async {
    emit(state.copyWith(isLoadingSuggestions: true));
    final result = await _getInstrumentsSuggestionsUsecase(
      Params(
        searchPhrase: input,
        pageSize: _pageSize,
        page: _page,
      ),
    );
    final suggestions = result.fold<List<Instrument>>(
      (_) => [],
      (list) => list,
    );
    emit(state.copyWith(
      isLoadingSuggestions: false,
      suggestions: suggestions,
    ));
  }
}

part of 'instruments_suggestions_cubit.dart';

@freezed
class InstrumentsSuggestionsState with _$InstrumentsSuggestionsState {
  factory InstrumentsSuggestionsState({
    @Default([]) List<Instrument> suggestions,
    @Default(false) bool isLoadingSuggestions,
  }) = _InstrumentsSuggestionsState;
}

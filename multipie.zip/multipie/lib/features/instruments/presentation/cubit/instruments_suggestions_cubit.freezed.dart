// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'instruments_suggestions_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$InstrumentsSuggestionsState {
  List<Instrument> get suggestions => throw _privateConstructorUsedError;
  bool get isLoadingSuggestions => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $InstrumentsSuggestionsStateCopyWith<InstrumentsSuggestionsState>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InstrumentsSuggestionsStateCopyWith<$Res> {
  factory $InstrumentsSuggestionsStateCopyWith(
          InstrumentsSuggestionsState value,
          $Res Function(InstrumentsSuggestionsState) then) =
      _$InstrumentsSuggestionsStateCopyWithImpl<$Res>;
  $Res call({List<Instrument> suggestions, bool isLoadingSuggestions});
}

/// @nodoc
class _$InstrumentsSuggestionsStateCopyWithImpl<$Res>
    implements $InstrumentsSuggestionsStateCopyWith<$Res> {
  _$InstrumentsSuggestionsStateCopyWithImpl(this._value, this._then);

  final InstrumentsSuggestionsState _value;
  // ignore: unused_field
  final $Res Function(InstrumentsSuggestionsState) _then;

  @override
  $Res call({
    Object? suggestions = freezed,
    Object? isLoadingSuggestions = freezed,
  }) {
    return _then(_value.copyWith(
      suggestions: suggestions == freezed
          ? _value.suggestions
          : suggestions // ignore: cast_nullable_to_non_nullable
              as List<Instrument>,
      isLoadingSuggestions: isLoadingSuggestions == freezed
          ? _value.isLoadingSuggestions
          : isLoadingSuggestions // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
abstract class _$$_InstrumentsSuggestionsStateCopyWith<$Res>
    implements $InstrumentsSuggestionsStateCopyWith<$Res> {
  factory _$$_InstrumentsSuggestionsStateCopyWith(
          _$_InstrumentsSuggestionsState value,
          $Res Function(_$_InstrumentsSuggestionsState) then) =
      __$$_InstrumentsSuggestionsStateCopyWithImpl<$Res>;
  @override
  $Res call({List<Instrument> suggestions, bool isLoadingSuggestions});
}

/// @nodoc
class __$$_InstrumentsSuggestionsStateCopyWithImpl<$Res>
    extends _$InstrumentsSuggestionsStateCopyWithImpl<$Res>
    implements _$$_InstrumentsSuggestionsStateCopyWith<$Res> {
  __$$_InstrumentsSuggestionsStateCopyWithImpl(
      _$_InstrumentsSuggestionsState _value,
      $Res Function(_$_InstrumentsSuggestionsState) _then)
      : super(_value, (v) => _then(v as _$_InstrumentsSuggestionsState));

  @override
  _$_InstrumentsSuggestionsState get _value =>
      super._value as _$_InstrumentsSuggestionsState;

  @override
  $Res call({
    Object? suggestions = freezed,
    Object? isLoadingSuggestions = freezed,
  }) {
    return _then(_$_InstrumentsSuggestionsState(
      suggestions: suggestions == freezed
          ? _value._suggestions
          : suggestions // ignore: cast_nullable_to_non_nullable
              as List<Instrument>,
      isLoadingSuggestions: isLoadingSuggestions == freezed
          ? _value.isLoadingSuggestions
          : isLoadingSuggestions // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$_InstrumentsSuggestionsState implements _InstrumentsSuggestionsState {
  _$_InstrumentsSuggestionsState(
      {final List<Instrument> suggestions = const [],
      this.isLoadingSuggestions = false})
      : _suggestions = suggestions;

  final List<Instrument> _suggestions;
  @override
  @JsonKey()
  List<Instrument> get suggestions {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_suggestions);
  }

  @override
  @JsonKey()
  final bool isLoadingSuggestions;

  @override
  String toString() {
    return 'InstrumentsSuggestionsState(suggestions: $suggestions, isLoadingSuggestions: $isLoadingSuggestions)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_InstrumentsSuggestionsState &&
            const DeepCollectionEquality()
                .equals(other._suggestions, _suggestions) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingSuggestions, isLoadingSuggestions));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_suggestions),
      const DeepCollectionEquality().hash(isLoadingSuggestions));

  @JsonKey(ignore: true)
  @override
  _$$_InstrumentsSuggestionsStateCopyWith<_$_InstrumentsSuggestionsState>
      get copyWith => __$$_InstrumentsSuggestionsStateCopyWithImpl<
          _$_InstrumentsSuggestionsState>(this, _$identity);
}

abstract class _InstrumentsSuggestionsState
    implements InstrumentsSuggestionsState {
  factory _InstrumentsSuggestionsState(
      {final List<Instrument> suggestions,
      final bool isLoadingSuggestions}) = _$_InstrumentsSuggestionsState;

  @override
  List<Instrument> get suggestions => throw _privateConstructorUsedError;
  @override
  bool get isLoadingSuggestions => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_InstrumentsSuggestionsStateCopyWith<_$_InstrumentsSuggestionsState>
      get copyWith => throw _privateConstructorUsedError;
}

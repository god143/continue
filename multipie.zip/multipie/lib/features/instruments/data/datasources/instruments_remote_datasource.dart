import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';
import 'package:multipie/services/network_service.dart';

class InstrumentsRemoteDatasource {
  final NetworkService networkService;

  const InstrumentsRemoteDatasource({
    required this.networkService,
  });

  Future<List<Instrument>> getInstruments({
    required String searchPhrase,
    required int pageSize,
    required int page,
  }) async {
    final jsonApi = await networkService.getRequest(
      '/instruments/search?page_size=$pageSize&page=$page' +
          '${searchPhrase.isEmpty ? '' : ('&search_phrase=' + searchPhrase)}',
    );
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((d) => Instrument.fromJson(d)).toList();
    } catch (e) {
      throw ServerException('Failed to get instruments list from data');
    }
  }
}

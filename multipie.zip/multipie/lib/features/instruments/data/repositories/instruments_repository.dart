import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/instruments/data/datasources/instruments_remote_datasource.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';

class InstrumentsRepository {
  final NetworkInfo networkInfo;
  final InstrumentsRemoteDatasource remoteDataSource;

  const InstrumentsRepository({
    required this.networkInfo,
    required this.remoteDataSource,
  });

  Future<Either<Failure, List<Instrument>>> getInstruments({
    required String searchPhrase,
    required int pageSize,
    required int page,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getInstruments(
          searchPhrase: searchPhrase,
          pageSize: pageSize,
          page: page,
        );
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

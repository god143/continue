import 'package:freezed_annotation/freezed_annotation.dart';
part 'instrument.freezed.dart';
part 'instrument.g.dart';

@JsonEnum()
enum InstrumentType {
  @JsonValue('MarketIndex')
  marketIndex,
  @JsonValue('Fund')
  fund,
  @JsonValue('Stock')
  stock
}

@freezed
class Instrument with _$Instrument {
  factory Instrument({
    required int id,
    required String displayName,
    InstrumentType? type,
    int? ownerId,
  }) = _Instrument;

  factory Instrument.fromJson(Map<String, dynamic> json) => _$InstrumentFromJson(json);
}

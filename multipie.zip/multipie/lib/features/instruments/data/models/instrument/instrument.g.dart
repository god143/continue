// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'instrument.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Instrument _$$_InstrumentFromJson(Map<String, dynamic> json) =>
    _$_Instrument(
      id: json['id'] as int,
      displayName: json['display_name'] as String,
      type: $enumDecodeNullable(_$InstrumentTypeEnumMap, json['type']),
      ownerId: json['owner_id'] as int?,
    );

Map<String, dynamic> _$$_InstrumentToJson(_$_Instrument instance) =>
    <String, dynamic>{
      'id': instance.id,
      'display_name': instance.displayName,
      'type': _$InstrumentTypeEnumMap[instance.type],
      'owner_id': instance.ownerId,
    };

const _$InstrumentTypeEnumMap = {
  InstrumentType.marketIndex: 'MarketIndex',
  InstrumentType.fund: 'Fund',
  InstrumentType.stock: 'Stock',
};

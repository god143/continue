// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'instrument.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Instrument _$InstrumentFromJson(Map<String, dynamic> json) {
  return _Instrument.fromJson(json);
}

/// @nodoc
mixin _$Instrument {
  int get id => throw _privateConstructorUsedError;
  String get displayName => throw _privateConstructorUsedError;
  InstrumentType? get type => throw _privateConstructorUsedError;
  int? get ownerId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $InstrumentCopyWith<Instrument> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InstrumentCopyWith<$Res> {
  factory $InstrumentCopyWith(
          Instrument value, $Res Function(Instrument) then) =
      _$InstrumentCopyWithImpl<$Res>;
  $Res call({int id, String displayName, InstrumentType? type, int? ownerId});
}

/// @nodoc
class _$InstrumentCopyWithImpl<$Res> implements $InstrumentCopyWith<$Res> {
  _$InstrumentCopyWithImpl(this._value, this._then);

  final Instrument _value;
  // ignore: unused_field
  final $Res Function(Instrument) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? displayName = freezed,
    Object? type = freezed,
    Object? ownerId = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      type: type == freezed
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as InstrumentType?,
      ownerId: ownerId == freezed
          ? _value.ownerId
          : ownerId // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
abstract class _$$_InstrumentCopyWith<$Res>
    implements $InstrumentCopyWith<$Res> {
  factory _$$_InstrumentCopyWith(
          _$_Instrument value, $Res Function(_$_Instrument) then) =
      __$$_InstrumentCopyWithImpl<$Res>;
  @override
  $Res call({int id, String displayName, InstrumentType? type, int? ownerId});
}

/// @nodoc
class __$$_InstrumentCopyWithImpl<$Res> extends _$InstrumentCopyWithImpl<$Res>
    implements _$$_InstrumentCopyWith<$Res> {
  __$$_InstrumentCopyWithImpl(
      _$_Instrument _value, $Res Function(_$_Instrument) _then)
      : super(_value, (v) => _then(v as _$_Instrument));

  @override
  _$_Instrument get _value => super._value as _$_Instrument;

  @override
  $Res call({
    Object? id = freezed,
    Object? displayName = freezed,
    Object? type = freezed,
    Object? ownerId = freezed,
  }) {
    return _then(_$_Instrument(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      type: type == freezed
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as InstrumentType?,
      ownerId: ownerId == freezed
          ? _value.ownerId
          : ownerId // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Instrument implements _Instrument {
  _$_Instrument(
      {required this.id, required this.displayName, this.type, this.ownerId});

  factory _$_Instrument.fromJson(Map<String, dynamic> json) =>
      _$$_InstrumentFromJson(json);

  @override
  final int id;
  @override
  final String displayName;
  @override
  final InstrumentType? type;
  @override
  final int? ownerId;

  @override
  String toString() {
    return 'Instrument(id: $id, displayName: $displayName, type: $type, ownerId: $ownerId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Instrument &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality()
                .equals(other.displayName, displayName) &&
            const DeepCollectionEquality().equals(other.type, type) &&
            const DeepCollectionEquality().equals(other.ownerId, ownerId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(displayName),
      const DeepCollectionEquality().hash(type),
      const DeepCollectionEquality().hash(ownerId));

  @JsonKey(ignore: true)
  @override
  _$$_InstrumentCopyWith<_$_Instrument> get copyWith =>
      __$$_InstrumentCopyWithImpl<_$_Instrument>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_InstrumentToJson(this);
  }
}

abstract class _Instrument implements Instrument {
  factory _Instrument(
      {required final int id,
      required final String displayName,
      final InstrumentType? type,
      final int? ownerId}) = _$_Instrument;

  factory _Instrument.fromJson(Map<String, dynamic> json) =
      _$_Instrument.fromJson;

  @override
  int get id => throw _privateConstructorUsedError;
  @override
  String get displayName => throw _privateConstructorUsedError;
  @override
  InstrumentType? get type => throw _privateConstructorUsedError;
  @override
  int? get ownerId => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_InstrumentCopyWith<_$_Instrument> get copyWith =>
      throw _privateConstructorUsedError;
}

// get_instruments_usecase
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';
import 'package:multipie/features/instruments/data/repositories/instruments_repository.dart';

class GetInstrumentsSuggestionsUsecase implements UseCase<List<Instrument>, Params> {
  final InstrumentsRepository repository;

  GetInstrumentsSuggestionsUsecase(this.repository);

  @override
  Future<Either<Failure, List<Instrument>>> call(Params params) async {
    return await repository.getInstruments(
      searchPhrase: params.searchPhrase,
      pageSize: params.pageSize,
      page: params.page,
    );
  }
}

class Params extends Equatable {
  final String searchPhrase;
  final int pageSize;
  final int page;
  const Params({
    this.searchPhrase = '',
    this.pageSize = 20,
    this.page = 1,
  });

  @override
  List<Object> get props => [searchPhrase, pageSize, page];
}

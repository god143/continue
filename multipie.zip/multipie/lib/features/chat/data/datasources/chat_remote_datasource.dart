import 'dart:io';

import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/services/network_service.dart';
import 'package:multipie/services/socket_service.dart';

class ChatRemoteDataSource {
  final NetworkService networkService;
  final SocketService socketService;

  const ChatRemoteDataSource({
    required this.networkService,
    required this.socketService,
  });

  Future<int> getUnreadMessagesCount() async {
    final jsonApi = await networkService.getRequest('/chat_rooms/messages/unreadCount');
    try {
      return jsonApi['unreadMessageCount'] as int;
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  Future<List<ChatRoom>> getChatRooms({
    required int page,
    required int size,
  }) async {
    final jsonApi = await networkService.getRequest('/chat_rooms?page=$page&page_size=$size');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      final data = json['data'] as List? ?? [];
      return data.map((e) => ChatRoom.fromJson(e)).toList(growable: false);
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  Future<List<ChatMessage>> getChatMessages({
    required String chatRoomId,
    required int page,
    required int size,
  }) async {
    final jsonApi = await networkService.getRequest('/chat_rooms/$chatRoomId/messages?page=$page&page_size=$size');
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      final data = json['data'] as List? ?? [];
      return data.map((e) => ChatMessage.fromJson(e)).toList(growable: false);
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  Future<ChatRoom> createChatRoom({
    required String recipientId,
  }) async {
    final Map<String, dynamic> jsonApi = await networkService.postRequest(
      '/chat_rooms',
      body: {
        'recipient_id': recipientId,
        'group_chat': false,
      },
      isUrlEncoded: true,
    );

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      final data = Map<String, dynamic>.from(json['data'] as Map? ?? {});
      return ChatRoom.fromJson(data);
    } catch (e) {
      throw ServerException('Could not create Chat Room!');
    }
  }

  Future<ChatRoom> createChatGroup({
    required String name,
    required List<String> memberIds,
  }) async {
    final Map<String, dynamic> jsonApi = await networkService.postRequest(
      '/chat_rooms',
      body: {
        'name': name,
        'member_ids': memberIds,
        'group_chat': true,
      },
      isUrlEncoded: true,
    );

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      final data = Map<String, dynamic>.from(json['data'] as Map? ?? {});
      return ChatRoom.fromJson(data);
    } catch (e) {
      throw ServerException('Could not create Chat Group!');
    }
  }

  Future<bool> updateChatGroupName({
    required String groupId,
    required String name,
  }) async {
    try {
      await networkService.patchRequest(
        '/chat_rooms/$groupId',
        body: {
          'name': name,
        },
        isUrlEncoded: true,
      );
    } catch (e) {
      print(e);
    }
    return true;
  }

  Future<bool> addMember({
    required String groupId,
    required String userId,
  }) async {
    await networkService.postRequest(
      '/chat_rooms/$groupId/add_members',
      body: {
        'member_ids': '${[userId]}',
      },
      isUrlEncoded: true,
    );
    return true;
  }

  Future<bool> removeMember({
    required String groupId,
    required String userId,
  }) async {
    await networkService.postRequest(
      '/chat_rooms/$groupId/remove_member',
      body: {
        'member_id': userId,
      },
      isUrlEncoded: true,
    );
    return true;
  }

  Future<bool> makeOrRevokeAdmin({
    required String groupId,
    required String userId,
    required bool makeAdmin,
  }) async {
    await networkService.postRequest(
      "/chat_rooms/$groupId/members/${userId}/${makeAdmin ? 'make_admin' : 'revoke_admin'}",
      isUrlEncoded: true,
    );
    return true;
  }

  Future<ChatMessage?> sendChatMessage({
    required String chatRoomId,
    required String text,
    File? attachment,
    String? mediaUrl,
  }) async {
    final endPoint = '/chat_rooms/$chatRoomId/messages';
    final params = {
      'message_content': text,
      if (mediaUrl != null) 'media_url': mediaUrl,
    };
    if (attachment != null) {
      final Map<String, dynamic> jsonApi =
          await networkService.postMultipartRequest(endPoint, attachment, fields: params);
      try {
        Map<String, dynamic> json = Japx.decode(jsonApi);
        final data = Map<String, dynamic>.from(json['data'] as Map? ?? {});
        return ChatMessage.fromJson(data);
      } catch (e) {
        throw ServerException('Failed to get data');
      }
    } else {
      socketService.emitData('message', text, chatRoomId, mediaUrl: mediaUrl);
    }
  }
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'chat_message.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ChatMessage _$ChatMessageFromJson(Map<String, dynamic> json) {
  return _ChatMessage.fromJson(json);
}

/// @nodoc
mixin _$ChatMessage {
  String get id => throw _privateConstructorUsedError;
  int get fromId => throw _privateConstructorUsedError;
  String get messageContent => throw _privateConstructorUsedError;
  DateTime get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _parseChatRoomId)
  int? get chatRoomId => throw _privateConstructorUsedError;
  String? get mediaUrl => throw _privateConstructorUsedError;
  DateTime? get createdAt => throw _privateConstructorUsedError;
  UserModel? get user => throw _privateConstructorUsedError;
  List<UserMention>? get taggedUsers => throw _privateConstructorUsedError;
  List<HashTagModel>? get taggedTopics => throw _privateConstructorUsedError;
  List<CompanyModel>? get taggedCompanies => throw _privateConstructorUsedError;
  List<Instrument>? get taggedInstruments => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ChatMessageCopyWith<ChatMessage> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatMessageCopyWith<$Res> {
  factory $ChatMessageCopyWith(
          ChatMessage value, $Res Function(ChatMessage) then) =
      _$ChatMessageCopyWithImpl<$Res>;
  $Res call(
      {String id,
      int fromId,
      String messageContent,
      DateTime updatedAt,
      @JsonKey(fromJson: _parseChatRoomId) int? chatRoomId,
      String? mediaUrl,
      DateTime? createdAt,
      UserModel? user,
      List<UserMention>? taggedUsers,
      List<HashTagModel>? taggedTopics,
      List<CompanyModel>? taggedCompanies,
      List<Instrument>? taggedInstruments});
}

/// @nodoc
class _$ChatMessageCopyWithImpl<$Res> implements $ChatMessageCopyWith<$Res> {
  _$ChatMessageCopyWithImpl(this._value, this._then);

  final ChatMessage _value;
  // ignore: unused_field
  final $Res Function(ChatMessage) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? fromId = freezed,
    Object? messageContent = freezed,
    Object? updatedAt = freezed,
    Object? chatRoomId = freezed,
    Object? mediaUrl = freezed,
    Object? createdAt = freezed,
    Object? user = freezed,
    Object? taggedUsers = freezed,
    Object? taggedTopics = freezed,
    Object? taggedCompanies = freezed,
    Object? taggedInstruments = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      fromId: fromId == freezed
          ? _value.fromId
          : fromId // ignore: cast_nullable_to_non_nullable
              as int,
      messageContent: messageContent == freezed
          ? _value.messageContent
          : messageContent // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: updatedAt == freezed
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      chatRoomId: chatRoomId == freezed
          ? _value.chatRoomId
          : chatRoomId // ignore: cast_nullable_to_non_nullable
              as int?,
      mediaUrl: mediaUrl == freezed
          ? _value.mediaUrl
          : mediaUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: createdAt == freezed
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      user: user == freezed
          ? _value.user
          : user // ignore: cast_nullable_to_non_nullable
              as UserModel?,
      taggedUsers: taggedUsers == freezed
          ? _value.taggedUsers
          : taggedUsers // ignore: cast_nullable_to_non_nullable
              as List<UserMention>?,
      taggedTopics: taggedTopics == freezed
          ? _value.taggedTopics
          : taggedTopics // ignore: cast_nullable_to_non_nullable
              as List<HashTagModel>?,
      taggedCompanies: taggedCompanies == freezed
          ? _value.taggedCompanies
          : taggedCompanies // ignore: cast_nullable_to_non_nullable
              as List<CompanyModel>?,
      taggedInstruments: taggedInstruments == freezed
          ? _value.taggedInstruments
          : taggedInstruments // ignore: cast_nullable_to_non_nullable
              as List<Instrument>?,
    ));
  }
}

/// @nodoc
abstract class _$$_ChatMessageCopyWith<$Res>
    implements $ChatMessageCopyWith<$Res> {
  factory _$$_ChatMessageCopyWith(
          _$_ChatMessage value, $Res Function(_$_ChatMessage) then) =
      __$$_ChatMessageCopyWithImpl<$Res>;
  @override
  $Res call(
      {String id,
      int fromId,
      String messageContent,
      DateTime updatedAt,
      @JsonKey(fromJson: _parseChatRoomId) int? chatRoomId,
      String? mediaUrl,
      DateTime? createdAt,
      UserModel? user,
      List<UserMention>? taggedUsers,
      List<HashTagModel>? taggedTopics,
      List<CompanyModel>? taggedCompanies,
      List<Instrument>? taggedInstruments});
}

/// @nodoc
class __$$_ChatMessageCopyWithImpl<$Res> extends _$ChatMessageCopyWithImpl<$Res>
    implements _$$_ChatMessageCopyWith<$Res> {
  __$$_ChatMessageCopyWithImpl(
      _$_ChatMessage _value, $Res Function(_$_ChatMessage) _then)
      : super(_value, (v) => _then(v as _$_ChatMessage));

  @override
  _$_ChatMessage get _value => super._value as _$_ChatMessage;

  @override
  $Res call({
    Object? id = freezed,
    Object? fromId = freezed,
    Object? messageContent = freezed,
    Object? updatedAt = freezed,
    Object? chatRoomId = freezed,
    Object? mediaUrl = freezed,
    Object? createdAt = freezed,
    Object? user = freezed,
    Object? taggedUsers = freezed,
    Object? taggedTopics = freezed,
    Object? taggedCompanies = freezed,
    Object? taggedInstruments = freezed,
  }) {
    return _then(_$_ChatMessage(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      fromId: fromId == freezed
          ? _value.fromId
          : fromId // ignore: cast_nullable_to_non_nullable
              as int,
      messageContent: messageContent == freezed
          ? _value.messageContent
          : messageContent // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: updatedAt == freezed
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      chatRoomId: chatRoomId == freezed
          ? _value.chatRoomId
          : chatRoomId // ignore: cast_nullable_to_non_nullable
              as int?,
      mediaUrl: mediaUrl == freezed
          ? _value.mediaUrl
          : mediaUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: createdAt == freezed
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      user: user == freezed
          ? _value.user
          : user // ignore: cast_nullable_to_non_nullable
              as UserModel?,
      taggedUsers: taggedUsers == freezed
          ? _value._taggedUsers
          : taggedUsers // ignore: cast_nullable_to_non_nullable
              as List<UserMention>?,
      taggedTopics: taggedTopics == freezed
          ? _value._taggedTopics
          : taggedTopics // ignore: cast_nullable_to_non_nullable
              as List<HashTagModel>?,
      taggedCompanies: taggedCompanies == freezed
          ? _value._taggedCompanies
          : taggedCompanies // ignore: cast_nullable_to_non_nullable
              as List<CompanyModel>?,
      taggedInstruments: taggedInstruments == freezed
          ? _value._taggedInstruments
          : taggedInstruments // ignore: cast_nullable_to_non_nullable
              as List<Instrument>?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$_ChatMessage implements _ChatMessage {
  _$_ChatMessage(
      {required this.id,
      required this.fromId,
      required this.messageContent,
      required this.updatedAt,
      @JsonKey(fromJson: _parseChatRoomId) this.chatRoomId,
      this.mediaUrl,
      this.createdAt,
      this.user,
      final List<UserMention>? taggedUsers,
      final List<HashTagModel>? taggedTopics,
      final List<CompanyModel>? taggedCompanies,
      final List<Instrument>? taggedInstruments})
      : _taggedUsers = taggedUsers,
        _taggedTopics = taggedTopics,
        _taggedCompanies = taggedCompanies,
        _taggedInstruments = taggedInstruments;

  factory _$_ChatMessage.fromJson(Map<String, dynamic> json) =>
      _$$_ChatMessageFromJson(json);

  @override
  final String id;
  @override
  final int fromId;
  @override
  final String messageContent;
  @override
  final DateTime updatedAt;
  @override
  @JsonKey(fromJson: _parseChatRoomId)
  final int? chatRoomId;
  @override
  final String? mediaUrl;
  @override
  final DateTime? createdAt;
  @override
  final UserModel? user;
  final List<UserMention>? _taggedUsers;
  @override
  List<UserMention>? get taggedUsers {
    final value = _taggedUsers;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<HashTagModel>? _taggedTopics;
  @override
  List<HashTagModel>? get taggedTopics {
    final value = _taggedTopics;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<CompanyModel>? _taggedCompanies;
  @override
  List<CompanyModel>? get taggedCompanies {
    final value = _taggedCompanies;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Instrument>? _taggedInstruments;
  @override
  List<Instrument>? get taggedInstruments {
    final value = _taggedInstruments;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'ChatMessage(id: $id, fromId: $fromId, messageContent: $messageContent, updatedAt: $updatedAt, chatRoomId: $chatRoomId, mediaUrl: $mediaUrl, createdAt: $createdAt, user: $user, taggedUsers: $taggedUsers, taggedTopics: $taggedTopics, taggedCompanies: $taggedCompanies, taggedInstruments: $taggedInstruments)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatMessage &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.fromId, fromId) &&
            const DeepCollectionEquality()
                .equals(other.messageContent, messageContent) &&
            const DeepCollectionEquality().equals(other.updatedAt, updatedAt) &&
            const DeepCollectionEquality()
                .equals(other.chatRoomId, chatRoomId) &&
            const DeepCollectionEquality().equals(other.mediaUrl, mediaUrl) &&
            const DeepCollectionEquality().equals(other.createdAt, createdAt) &&
            const DeepCollectionEquality().equals(other.user, user) &&
            const DeepCollectionEquality()
                .equals(other._taggedUsers, _taggedUsers) &&
            const DeepCollectionEquality()
                .equals(other._taggedTopics, _taggedTopics) &&
            const DeepCollectionEquality()
                .equals(other._taggedCompanies, _taggedCompanies) &&
            const DeepCollectionEquality()
                .equals(other._taggedInstruments, _taggedInstruments));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(fromId),
      const DeepCollectionEquality().hash(messageContent),
      const DeepCollectionEquality().hash(updatedAt),
      const DeepCollectionEquality().hash(chatRoomId),
      const DeepCollectionEquality().hash(mediaUrl),
      const DeepCollectionEquality().hash(createdAt),
      const DeepCollectionEquality().hash(user),
      const DeepCollectionEquality().hash(_taggedUsers),
      const DeepCollectionEquality().hash(_taggedTopics),
      const DeepCollectionEquality().hash(_taggedCompanies),
      const DeepCollectionEquality().hash(_taggedInstruments));

  @JsonKey(ignore: true)
  @override
  _$$_ChatMessageCopyWith<_$_ChatMessage> get copyWith =>
      __$$_ChatMessageCopyWithImpl<_$_ChatMessage>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ChatMessageToJson(this);
  }
}

abstract class _ChatMessage implements ChatMessage {
  factory _ChatMessage(
      {required final String id,
      required final int fromId,
      required final String messageContent,
      required final DateTime updatedAt,
      @JsonKey(fromJson: _parseChatRoomId) final int? chatRoomId,
      final String? mediaUrl,
      final DateTime? createdAt,
      final UserModel? user,
      final List<UserMention>? taggedUsers,
      final List<HashTagModel>? taggedTopics,
      final List<CompanyModel>? taggedCompanies,
      final List<Instrument>? taggedInstruments}) = _$_ChatMessage;

  factory _ChatMessage.fromJson(Map<String, dynamic> json) =
      _$_ChatMessage.fromJson;

  @override
  String get id => throw _privateConstructorUsedError;
  @override
  int get fromId => throw _privateConstructorUsedError;
  @override
  String get messageContent => throw _privateConstructorUsedError;
  @override
  DateTime get updatedAt => throw _privateConstructorUsedError;
  @override
  @JsonKey(fromJson: _parseChatRoomId)
  int? get chatRoomId => throw _privateConstructorUsedError;
  @override
  String? get mediaUrl => throw _privateConstructorUsedError;
  @override
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @override
  UserModel? get user => throw _privateConstructorUsedError;
  @override
  List<UserMention>? get taggedUsers => throw _privateConstructorUsedError;
  @override
  List<HashTagModel>? get taggedTopics => throw _privateConstructorUsedError;
  @override
  List<CompanyModel>? get taggedCompanies => throw _privateConstructorUsedError;
  @override
  List<Instrument>? get taggedInstruments => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ChatMessageCopyWith<_$_ChatMessage> get copyWith =>
      throw _privateConstructorUsedError;
}

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_room.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ChatRoom _$$_ChatRoomFromJson(Map<String, dynamic> json) => _$_ChatRoom(
      id: json['id'] as String,
      name: json['name'] as String?,
      description: json['description'] as String?,
      identifier: json['identifier'] as String,
      groupChat: json['group_chat'] as bool,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      lastMessage: json['last_message'] == null
          ? null
          : ChatMessage.fromJson(json['last_message'] as Map<String, dynamic>),
      chatRoomMembers: (json['chat_room_members'] as List<dynamic>)
          .map((e) => ChatRoomMember.fromJson(e as Map<String, dynamic>))
          .toList(),
      users: (json['users'] as List<dynamic>)
          .map((e) => UserModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      unreadMessageCount: json['unread_message_count'] as int?,
      dpFile: json['file'] == null
          ? null
          : Attachment.fromJson(json['file'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_ChatRoomToJson(_$_ChatRoom instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'description': instance.description,
      'identifier': instance.identifier,
      'group_chat': instance.groupChat,
      'created_at': instance.createdAt.toIso8601String(),
      'updated_at': instance.updatedAt.toIso8601String(),
      'last_message': instance.lastMessage?.toJson(),
      'chat_room_members':
          instance.chatRoomMembers.map((e) => e.toJson()).toList(),
      'users': instance.users.map((e) => e.toJson()).toList(),
      'unread_message_count': instance.unreadMessageCount,
      'file': instance.dpFile?.toJson(),
    };

_$_Attachment _$$_AttachmentFromJson(Map<String, dynamic> json) =>
    _$_Attachment(
      id: json['id'] as String,
      filePath: json['filePath'] as String,
      fileType: json['fileType'] as String,
    );

Map<String, dynamic> _$$_AttachmentToJson(_$_Attachment instance) =>
    <String, dynamic>{
      'id': instance.id,
      'filePath': instance.filePath,
      'fileType': instance.fileType,
    };

import 'package:freezed_annotation/freezed_annotation.dart';

part 'chat_room_member.freezed.dart';
part 'chat_room_member.g.dart';

@freezed
class ChatRoomMember with _$ChatRoomMember {
  @JsonSerializable(explicitToJson: true)
  factory ChatRoomMember({
    required int userId,
    required int chatRoomId,
    int? lastReadMessageId,
    required bool isAdmin,
  }) = _ChatRoomMember;

  factory ChatRoomMember.fromJson(Map<String, dynamic> json) => _$ChatRoomMemberFromJson(json);
}

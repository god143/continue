// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'chat_room_member.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ChatRoomMember _$ChatRoomMemberFromJson(Map<String, dynamic> json) {
  return _ChatRoomMember.fromJson(json);
}

/// @nodoc
mixin _$ChatRoomMember {
  int get userId => throw _privateConstructorUsedError;
  int get chatRoomId => throw _privateConstructorUsedError;
  int? get lastReadMessageId => throw _privateConstructorUsedError;
  bool get isAdmin => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ChatRoomMemberCopyWith<ChatRoomMember> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatRoomMemberCopyWith<$Res> {
  factory $ChatRoomMemberCopyWith(
          ChatRoomMember value, $Res Function(ChatRoomMember) then) =
      _$ChatRoomMemberCopyWithImpl<$Res>;
  $Res call({int userId, int chatRoomId, int? lastReadMessageId, bool isAdmin});
}

/// @nodoc
class _$ChatRoomMemberCopyWithImpl<$Res>
    implements $ChatRoomMemberCopyWith<$Res> {
  _$ChatRoomMemberCopyWithImpl(this._value, this._then);

  final ChatRoomMember _value;
  // ignore: unused_field
  final $Res Function(ChatRoomMember) _then;

  @override
  $Res call({
    Object? userId = freezed,
    Object? chatRoomId = freezed,
    Object? lastReadMessageId = freezed,
    Object? isAdmin = freezed,
  }) {
    return _then(_value.copyWith(
      userId: userId == freezed
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      chatRoomId: chatRoomId == freezed
          ? _value.chatRoomId
          : chatRoomId // ignore: cast_nullable_to_non_nullable
              as int,
      lastReadMessageId: lastReadMessageId == freezed
          ? _value.lastReadMessageId
          : lastReadMessageId // ignore: cast_nullable_to_non_nullable
              as int?,
      isAdmin: isAdmin == freezed
          ? _value.isAdmin
          : isAdmin // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
abstract class _$$_ChatRoomMemberCopyWith<$Res>
    implements $ChatRoomMemberCopyWith<$Res> {
  factory _$$_ChatRoomMemberCopyWith(
          _$_ChatRoomMember value, $Res Function(_$_ChatRoomMember) then) =
      __$$_ChatRoomMemberCopyWithImpl<$Res>;
  @override
  $Res call({int userId, int chatRoomId, int? lastReadMessageId, bool isAdmin});
}

/// @nodoc
class __$$_ChatRoomMemberCopyWithImpl<$Res>
    extends _$ChatRoomMemberCopyWithImpl<$Res>
    implements _$$_ChatRoomMemberCopyWith<$Res> {
  __$$_ChatRoomMemberCopyWithImpl(
      _$_ChatRoomMember _value, $Res Function(_$_ChatRoomMember) _then)
      : super(_value, (v) => _then(v as _$_ChatRoomMember));

  @override
  _$_ChatRoomMember get _value => super._value as _$_ChatRoomMember;

  @override
  $Res call({
    Object? userId = freezed,
    Object? chatRoomId = freezed,
    Object? lastReadMessageId = freezed,
    Object? isAdmin = freezed,
  }) {
    return _then(_$_ChatRoomMember(
      userId: userId == freezed
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      chatRoomId: chatRoomId == freezed
          ? _value.chatRoomId
          : chatRoomId // ignore: cast_nullable_to_non_nullable
              as int,
      lastReadMessageId: lastReadMessageId == freezed
          ? _value.lastReadMessageId
          : lastReadMessageId // ignore: cast_nullable_to_non_nullable
              as int?,
      isAdmin: isAdmin == freezed
          ? _value.isAdmin
          : isAdmin // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$_ChatRoomMember implements _ChatRoomMember {
  _$_ChatRoomMember(
      {required this.userId,
      required this.chatRoomId,
      this.lastReadMessageId,
      required this.isAdmin});

  factory _$_ChatRoomMember.fromJson(Map<String, dynamic> json) =>
      _$$_ChatRoomMemberFromJson(json);

  @override
  final int userId;
  @override
  final int chatRoomId;
  @override
  final int? lastReadMessageId;
  @override
  final bool isAdmin;

  @override
  String toString() {
    return 'ChatRoomMember(userId: $userId, chatRoomId: $chatRoomId, lastReadMessageId: $lastReadMessageId, isAdmin: $isAdmin)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatRoomMember &&
            const DeepCollectionEquality().equals(other.userId, userId) &&
            const DeepCollectionEquality()
                .equals(other.chatRoomId, chatRoomId) &&
            const DeepCollectionEquality()
                .equals(other.lastReadMessageId, lastReadMessageId) &&
            const DeepCollectionEquality().equals(other.isAdmin, isAdmin));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(userId),
      const DeepCollectionEquality().hash(chatRoomId),
      const DeepCollectionEquality().hash(lastReadMessageId),
      const DeepCollectionEquality().hash(isAdmin));

  @JsonKey(ignore: true)
  @override
  _$$_ChatRoomMemberCopyWith<_$_ChatRoomMember> get copyWith =>
      __$$_ChatRoomMemberCopyWithImpl<_$_ChatRoomMember>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ChatRoomMemberToJson(this);
  }
}

abstract class _ChatRoomMember implements ChatRoomMember {
  factory _ChatRoomMember(
      {required final int userId,
      required final int chatRoomId,
      final int? lastReadMessageId,
      required final bool isAdmin}) = _$_ChatRoomMember;

  factory _ChatRoomMember.fromJson(Map<String, dynamic> json) =
      _$_ChatRoomMember.fromJson;

  @override
  int get userId => throw _privateConstructorUsedError;
  @override
  int get chatRoomId => throw _privateConstructorUsedError;
  @override
  int? get lastReadMessageId => throw _privateConstructorUsedError;
  @override
  bool get isAdmin => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ChatRoomMemberCopyWith<_$_ChatRoomMember> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/models/chat_room_member.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

part 'chat_room.freezed.dart';
part 'chat_room.g.dart';

@freezed
class ChatRoom with _$ChatRoom {
  @JsonSerializable(explicitToJson: true)
  factory ChatRoom({
    required String id,
    String? name,
    String? description,
    required String identifier,
    required bool groupChat,
    required DateTime createdAt,
    required DateTime updatedAt,
    ChatMessage? lastMessage,
    required List<ChatRoomMember> chatRoomMembers,
    required List<UserModel> users,
    int? unreadMessageCount,
    @JsonKey(name: 'file') Attachment? dpFile,
  }) = _ChatRoom;

  factory ChatRoom.fromJson(Map<String, dynamic> json) => _$ChatRoomFromJson(json);
}

@freezed
class Attachment with _$Attachment {
  @JsonSerializable(
    explicitToJson: true,
    fieldRename: FieldRename.none,
  )
  factory Attachment({
    required String id,
    required String filePath,
    required String fileType,
  }) = _Attachment;

  factory Attachment.fromJson(Map<String, dynamic> json) => _$AttachmentFromJson(json);
}

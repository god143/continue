// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'chat_room.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ChatRoom _$ChatRoomFromJson(Map<String, dynamic> json) {
  return _ChatRoom.fromJson(json);
}

/// @nodoc
mixin _$ChatRoom {
  String get id => throw _privateConstructorUsedError;
  String? get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String get identifier => throw _privateConstructorUsedError;
  bool get groupChat => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  DateTime get updatedAt => throw _privateConstructorUsedError;
  ChatMessage? get lastMessage => throw _privateConstructorUsedError;
  List<ChatRoomMember> get chatRoomMembers =>
      throw _privateConstructorUsedError;
  List<UserModel> get users => throw _privateConstructorUsedError;
  int? get unreadMessageCount => throw _privateConstructorUsedError;
  @JsonKey(name: 'file')
  Attachment? get dpFile => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ChatRoomCopyWith<ChatRoom> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatRoomCopyWith<$Res> {
  factory $ChatRoomCopyWith(ChatRoom value, $Res Function(ChatRoom) then) =
      _$ChatRoomCopyWithImpl<$Res>;
  $Res call(
      {String id,
      String? name,
      String? description,
      String identifier,
      bool groupChat,
      DateTime createdAt,
      DateTime updatedAt,
      ChatMessage? lastMessage,
      List<ChatRoomMember> chatRoomMembers,
      List<UserModel> users,
      int? unreadMessageCount,
      @JsonKey(name: 'file') Attachment? dpFile});

  $ChatMessageCopyWith<$Res>? get lastMessage;
  $AttachmentCopyWith<$Res>? get dpFile;
}

/// @nodoc
class _$ChatRoomCopyWithImpl<$Res> implements $ChatRoomCopyWith<$Res> {
  _$ChatRoomCopyWithImpl(this._value, this._then);

  final ChatRoom _value;
  // ignore: unused_field
  final $Res Function(ChatRoom) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? description = freezed,
    Object? identifier = freezed,
    Object? groupChat = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? lastMessage = freezed,
    Object? chatRoomMembers = freezed,
    Object? users = freezed,
    Object? unreadMessageCount = freezed,
    Object? dpFile = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: name == freezed
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: description == freezed
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      identifier: identifier == freezed
          ? _value.identifier
          : identifier // ignore: cast_nullable_to_non_nullable
              as String,
      groupChat: groupChat == freezed
          ? _value.groupChat
          : groupChat // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: createdAt == freezed
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: updatedAt == freezed
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastMessage: lastMessage == freezed
          ? _value.lastMessage
          : lastMessage // ignore: cast_nullable_to_non_nullable
              as ChatMessage?,
      chatRoomMembers: chatRoomMembers == freezed
          ? _value.chatRoomMembers
          : chatRoomMembers // ignore: cast_nullable_to_non_nullable
              as List<ChatRoomMember>,
      users: users == freezed
          ? _value.users
          : users // ignore: cast_nullable_to_non_nullable
              as List<UserModel>,
      unreadMessageCount: unreadMessageCount == freezed
          ? _value.unreadMessageCount
          : unreadMessageCount // ignore: cast_nullable_to_non_nullable
              as int?,
      dpFile: dpFile == freezed
          ? _value.dpFile
          : dpFile // ignore: cast_nullable_to_non_nullable
              as Attachment?,
    ));
  }

  @override
  $ChatMessageCopyWith<$Res>? get lastMessage {
    if (_value.lastMessage == null) {
      return null;
    }

    return $ChatMessageCopyWith<$Res>(_value.lastMessage!, (value) {
      return _then(_value.copyWith(lastMessage: value));
    });
  }

  @override
  $AttachmentCopyWith<$Res>? get dpFile {
    if (_value.dpFile == null) {
      return null;
    }

    return $AttachmentCopyWith<$Res>(_value.dpFile!, (value) {
      return _then(_value.copyWith(dpFile: value));
    });
  }
}

/// @nodoc
abstract class _$$_ChatRoomCopyWith<$Res> implements $ChatRoomCopyWith<$Res> {
  factory _$$_ChatRoomCopyWith(
          _$_ChatRoom value, $Res Function(_$_ChatRoom) then) =
      __$$_ChatRoomCopyWithImpl<$Res>;
  @override
  $Res call(
      {String id,
      String? name,
      String? description,
      String identifier,
      bool groupChat,
      DateTime createdAt,
      DateTime updatedAt,
      ChatMessage? lastMessage,
      List<ChatRoomMember> chatRoomMembers,
      List<UserModel> users,
      int? unreadMessageCount,
      @JsonKey(name: 'file') Attachment? dpFile});

  @override
  $ChatMessageCopyWith<$Res>? get lastMessage;
  @override
  $AttachmentCopyWith<$Res>? get dpFile;
}

/// @nodoc
class __$$_ChatRoomCopyWithImpl<$Res> extends _$ChatRoomCopyWithImpl<$Res>
    implements _$$_ChatRoomCopyWith<$Res> {
  __$$_ChatRoomCopyWithImpl(
      _$_ChatRoom _value, $Res Function(_$_ChatRoom) _then)
      : super(_value, (v) => _then(v as _$_ChatRoom));

  @override
  _$_ChatRoom get _value => super._value as _$_ChatRoom;

  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? description = freezed,
    Object? identifier = freezed,
    Object? groupChat = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? lastMessage = freezed,
    Object? chatRoomMembers = freezed,
    Object? users = freezed,
    Object? unreadMessageCount = freezed,
    Object? dpFile = freezed,
  }) {
    return _then(_$_ChatRoom(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: name == freezed
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: description == freezed
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      identifier: identifier == freezed
          ? _value.identifier
          : identifier // ignore: cast_nullable_to_non_nullable
              as String,
      groupChat: groupChat == freezed
          ? _value.groupChat
          : groupChat // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: createdAt == freezed
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: updatedAt == freezed
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastMessage: lastMessage == freezed
          ? _value.lastMessage
          : lastMessage // ignore: cast_nullable_to_non_nullable
              as ChatMessage?,
      chatRoomMembers: chatRoomMembers == freezed
          ? _value._chatRoomMembers
          : chatRoomMembers // ignore: cast_nullable_to_non_nullable
              as List<ChatRoomMember>,
      users: users == freezed
          ? _value._users
          : users // ignore: cast_nullable_to_non_nullable
              as List<UserModel>,
      unreadMessageCount: unreadMessageCount == freezed
          ? _value.unreadMessageCount
          : unreadMessageCount // ignore: cast_nullable_to_non_nullable
              as int?,
      dpFile: dpFile == freezed
          ? _value.dpFile
          : dpFile // ignore: cast_nullable_to_non_nullable
              as Attachment?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$_ChatRoom implements _ChatRoom {
  _$_ChatRoom(
      {required this.id,
      this.name,
      this.description,
      required this.identifier,
      required this.groupChat,
      required this.createdAt,
      required this.updatedAt,
      this.lastMessage,
      required final List<ChatRoomMember> chatRoomMembers,
      required final List<UserModel> users,
      this.unreadMessageCount,
      @JsonKey(name: 'file') this.dpFile})
      : _chatRoomMembers = chatRoomMembers,
        _users = users;

  factory _$_ChatRoom.fromJson(Map<String, dynamic> json) =>
      _$$_ChatRoomFromJson(json);

  @override
  final String id;
  @override
  final String? name;
  @override
  final String? description;
  @override
  final String identifier;
  @override
  final bool groupChat;
  @override
  final DateTime createdAt;
  @override
  final DateTime updatedAt;
  @override
  final ChatMessage? lastMessage;
  final List<ChatRoomMember> _chatRoomMembers;
  @override
  List<ChatRoomMember> get chatRoomMembers {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_chatRoomMembers);
  }

  final List<UserModel> _users;
  @override
  List<UserModel> get users {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_users);
  }

  @override
  final int? unreadMessageCount;
  @override
  @JsonKey(name: 'file')
  final Attachment? dpFile;

  @override
  String toString() {
    return 'ChatRoom(id: $id, name: $name, description: $description, identifier: $identifier, groupChat: $groupChat, createdAt: $createdAt, updatedAt: $updatedAt, lastMessage: $lastMessage, chatRoomMembers: $chatRoomMembers, users: $users, unreadMessageCount: $unreadMessageCount, dpFile: $dpFile)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatRoom &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.name, name) &&
            const DeepCollectionEquality()
                .equals(other.description, description) &&
            const DeepCollectionEquality()
                .equals(other.identifier, identifier) &&
            const DeepCollectionEquality().equals(other.groupChat, groupChat) &&
            const DeepCollectionEquality().equals(other.createdAt, createdAt) &&
            const DeepCollectionEquality().equals(other.updatedAt, updatedAt) &&
            const DeepCollectionEquality()
                .equals(other.lastMessage, lastMessage) &&
            const DeepCollectionEquality()
                .equals(other._chatRoomMembers, _chatRoomMembers) &&
            const DeepCollectionEquality().equals(other._users, _users) &&
            const DeepCollectionEquality()
                .equals(other.unreadMessageCount, unreadMessageCount) &&
            const DeepCollectionEquality().equals(other.dpFile, dpFile));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(name),
      const DeepCollectionEquality().hash(description),
      const DeepCollectionEquality().hash(identifier),
      const DeepCollectionEquality().hash(groupChat),
      const DeepCollectionEquality().hash(createdAt),
      const DeepCollectionEquality().hash(updatedAt),
      const DeepCollectionEquality().hash(lastMessage),
      const DeepCollectionEquality().hash(_chatRoomMembers),
      const DeepCollectionEquality().hash(_users),
      const DeepCollectionEquality().hash(unreadMessageCount),
      const DeepCollectionEquality().hash(dpFile));

  @JsonKey(ignore: true)
  @override
  _$$_ChatRoomCopyWith<_$_ChatRoom> get copyWith =>
      __$$_ChatRoomCopyWithImpl<_$_ChatRoom>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ChatRoomToJson(this);
  }
}

abstract class _ChatRoom implements ChatRoom {
  factory _ChatRoom(
      {required final String id,
      final String? name,
      final String? description,
      required final String identifier,
      required final bool groupChat,
      required final DateTime createdAt,
      required final DateTime updatedAt,
      final ChatMessage? lastMessage,
      required final List<ChatRoomMember> chatRoomMembers,
      required final List<UserModel> users,
      final int? unreadMessageCount,
      @JsonKey(name: 'file') final Attachment? dpFile}) = _$_ChatRoom;

  factory _ChatRoom.fromJson(Map<String, dynamic> json) = _$_ChatRoom.fromJson;

  @override
  String get id => throw _privateConstructorUsedError;
  @override
  String? get name => throw _privateConstructorUsedError;
  @override
  String? get description => throw _privateConstructorUsedError;
  @override
  String get identifier => throw _privateConstructorUsedError;
  @override
  bool get groupChat => throw _privateConstructorUsedError;
  @override
  DateTime get createdAt => throw _privateConstructorUsedError;
  @override
  DateTime get updatedAt => throw _privateConstructorUsedError;
  @override
  ChatMessage? get lastMessage => throw _privateConstructorUsedError;
  @override
  List<ChatRoomMember> get chatRoomMembers =>
      throw _privateConstructorUsedError;
  @override
  List<UserModel> get users => throw _privateConstructorUsedError;
  @override
  int? get unreadMessageCount => throw _privateConstructorUsedError;
  @override
  @JsonKey(name: 'file')
  Attachment? get dpFile => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ChatRoomCopyWith<_$_ChatRoom> get copyWith =>
      throw _privateConstructorUsedError;
}

Attachment _$AttachmentFromJson(Map<String, dynamic> json) {
  return _Attachment.fromJson(json);
}

/// @nodoc
mixin _$Attachment {
  String get id => throw _privateConstructorUsedError;
  String get filePath => throw _privateConstructorUsedError;
  String get fileType => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AttachmentCopyWith<Attachment> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AttachmentCopyWith<$Res> {
  factory $AttachmentCopyWith(
          Attachment value, $Res Function(Attachment) then) =
      _$AttachmentCopyWithImpl<$Res>;
  $Res call({String id, String filePath, String fileType});
}

/// @nodoc
class _$AttachmentCopyWithImpl<$Res> implements $AttachmentCopyWith<$Res> {
  _$AttachmentCopyWithImpl(this._value, this._then);

  final Attachment _value;
  // ignore: unused_field
  final $Res Function(Attachment) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? filePath = freezed,
    Object? fileType = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      filePath: filePath == freezed
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      fileType: fileType == freezed
          ? _value.fileType
          : fileType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_AttachmentCopyWith<$Res>
    implements $AttachmentCopyWith<$Res> {
  factory _$$_AttachmentCopyWith(
          _$_Attachment value, $Res Function(_$_Attachment) then) =
      __$$_AttachmentCopyWithImpl<$Res>;
  @override
  $Res call({String id, String filePath, String fileType});
}

/// @nodoc
class __$$_AttachmentCopyWithImpl<$Res> extends _$AttachmentCopyWithImpl<$Res>
    implements _$$_AttachmentCopyWith<$Res> {
  __$$_AttachmentCopyWithImpl(
      _$_Attachment _value, $Res Function(_$_Attachment) _then)
      : super(_value, (v) => _then(v as _$_Attachment));

  @override
  _$_Attachment get _value => super._value as _$_Attachment;

  @override
  $Res call({
    Object? id = freezed,
    Object? filePath = freezed,
    Object? fileType = freezed,
  }) {
    return _then(_$_Attachment(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      filePath: filePath == freezed
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      fileType: fileType == freezed
          ? _value.fileType
          : fileType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true, fieldRename: FieldRename.none)
class _$_Attachment implements _Attachment {
  _$_Attachment(
      {required this.id, required this.filePath, required this.fileType});

  factory _$_Attachment.fromJson(Map<String, dynamic> json) =>
      _$$_AttachmentFromJson(json);

  @override
  final String id;
  @override
  final String filePath;
  @override
  final String fileType;

  @override
  String toString() {
    return 'Attachment(id: $id, filePath: $filePath, fileType: $fileType)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Attachment &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.filePath, filePath) &&
            const DeepCollectionEquality().equals(other.fileType, fileType));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(filePath),
      const DeepCollectionEquality().hash(fileType));

  @JsonKey(ignore: true)
  @override
  _$$_AttachmentCopyWith<_$_Attachment> get copyWith =>
      __$$_AttachmentCopyWithImpl<_$_Attachment>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AttachmentToJson(this);
  }
}

abstract class _Attachment implements Attachment {
  factory _Attachment(
      {required final String id,
      required final String filePath,
      required final String fileType}) = _$_Attachment;

  factory _Attachment.fromJson(Map<String, dynamic> json) =
      _$_Attachment.fromJson;

  @override
  String get id => throw _privateConstructorUsedError;
  @override
  String get filePath => throw _privateConstructorUsedError;
  @override
  String get fileType => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_AttachmentCopyWith<_$_Attachment> get copyWith =>
      throw _privateConstructorUsedError;
}

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_message.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ChatMessage _$$_ChatMessageFromJson(Map<String, dynamic> json) =>
    _$_ChatMessage(
      id: json['id'] as String,
      fromId: json['from_id'] as int,
      messageContent: json['message_content'] as String,
      updatedAt: DateTime.parse(json['updated_at'] as String),
      chatRoomId: _parseChatRoomId(json['chat_room_id']),
      mediaUrl: json['media_url'] as String?,
      createdAt: json['created_at'] == null
          ? null
          : DateTime.parse(json['created_at'] as String),
      user: json['user'] == null
          ? null
          : UserModel.fromJson(json['user'] as Map<String, dynamic>),
      taggedUsers: (json['tagged_users'] as List<dynamic>?)
          ?.map((e) => UserMention.fromJson(e as Map<String, dynamic>))
          .toList(),
      taggedTopics: (json['tagged_topics'] as List<dynamic>?)
          ?.map((e) => HashTagModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      taggedCompanies: (json['tagged_companies'] as List<dynamic>?)
          ?.map((e) => CompanyModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      taggedInstruments: (json['tagged_instruments'] as List<dynamic>?)
          ?.map((e) => Instrument.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_ChatMessageToJson(_$_ChatMessage instance) =>
    <String, dynamic>{
      'id': instance.id,
      'from_id': instance.fromId,
      'message_content': instance.messageContent,
      'updated_at': instance.updatedAt.toIso8601String(),
      'chat_room_id': instance.chatRoomId,
      'media_url': instance.mediaUrl,
      'created_at': instance.createdAt?.toIso8601String(),
      'user': instance.user?.toJson(),
      'tagged_users': instance.taggedUsers?.map((e) => e.toJson()).toList(),
      'tagged_topics': instance.taggedTopics?.map((e) => e.toJson()).toList(),
      'tagged_companies':
          instance.taggedCompanies?.map((e) => e.toJson()).toList(),
      'tagged_instruments':
          instance.taggedInstruments?.map((e) => e.toJson()).toList(),
    };

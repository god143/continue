// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_room_member.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ChatRoomMember _$$_ChatRoomMemberFromJson(Map<String, dynamic> json) =>
    _$_ChatRoomMember(
      userId: json['user_id'] as int,
      chatRoomId: json['chat_room_id'] as int,
      lastReadMessageId: json['last_read_message_id'] as int?,
      isAdmin: json['is_admin'] as bool,
    );

Map<String, dynamic> _$$_ChatRoomMemberToJson(_$_ChatRoomMember instance) =>
    <String, dynamic>{
      'user_id': instance.userId,
      'chat_room_id': instance.chatRoomId,
      'last_read_message_id': instance.lastReadMessageId,
      'is_admin': instance.isAdmin,
    };

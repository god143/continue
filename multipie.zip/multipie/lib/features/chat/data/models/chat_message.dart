import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/explore/data/models/hash_tag_model.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';
import 'package:multipie/features/market/data/models/company/company_model.dart';
import 'package:multipie/features/mention/data/models/mention.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

part 'chat_message.freezed.dart';
part 'chat_message.g.dart';

int? _parseChatRoomId(dynamic json) {
  if (json is String) {
    return int.parse(json);
  } else if (json is int) {
    return json;
  } else {
    return null;
  }
}

@freezed
class ChatMessage with _$ChatMessage {
  @JsonSerializable(explicitToJson: true)
  factory ChatMessage({
    required String id,
    required int fromId,
    required String messageContent,
    required DateTime updatedAt,
    @JsonKey(fromJson: _parseChatRoomId) int? chatRoomId,
    String? mediaUrl,
    DateTime? createdAt,
    UserModel? user,
    List<UserMention>? taggedUsers,
    List<HashTagModel>? taggedTopics,
    List<CompanyModel>? taggedCompanies,
    List<Instrument>? taggedInstruments,
  }) = _ChatMessage;

  factory ChatMessage.fromJson(Map<String, dynamic> json) => _$ChatMessageFromJson(json);

  factory ChatMessage.fromSocketJson(Map<String, dynamic> json) {
    final userJson = json['fromUser'];
    final user = UserModel.fromJson(userJson);
    return ChatMessage(
      id: '${json['messageId']}',
      chatRoomId: int.parse(json['chatRoomId']),
      fromId: int.parse(user.id),
      user: user,
      messageContent: json['data'],
      mediaUrl: json['mediaUrl'],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      taggedUsers: (json['tagged_users'] as List<dynamic>?)
          ?.map((e) => UserMention.fromJson(e as Map<String, dynamic>))
          .toList(),
      taggedTopics: (json['tagged_topics'] as List<dynamic>?)
          ?.map((e) => HashTagModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      taggedCompanies: (json['tagged_companies'] as List<dynamic>?)
          ?.map((e) => CompanyModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      taggedInstruments: (json['tagged_instruments'] as List<dynamic>?)
          ?.map((e) => Instrument.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

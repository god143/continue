import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/chat/data/datasources/chat_remote_datasource.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/file_upload/repositories/file_upload_repository.dart';

class ChatRepository {
  final NetworkInfo networkInfo;
  final ChatRemoteDataSource remoteDataSource;
  final FileUploadRepository fileUploadRepository;

  const ChatRepository({
    required this.networkInfo,
    required this.remoteDataSource,
    required this.fileUploadRepository,
  });

  Future<Either<Failure, int>> getUnreadMessagesCount() async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getUnreadMessagesCount();
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, List<ChatRoom>>> getChatRooms({
    required int page,
    required int size,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getChatRooms(page: page, size: size);
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, List<ChatMessage>>> getChatMessages({
    required String chatRoomId,
    required int page,
    required int size,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getChatMessages(
          chatRoomId: chatRoomId,
          page: page,
          size: size,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, ChatRoom>> createChatRoom({
    required String recipientId,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.createChatRoom(
          recipientId: recipientId,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, ChatRoom>> createChatGroup({
    required String name,
    required List<String> memberIds,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.createChatGroup(
          name: name,
          memberIds: memberIds,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, bool>> updateChatGroupName({
    required String groupId,
    required String name,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.updateChatGroupName(
          groupId: groupId,
          name: name,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, Attachment>> updateChatGroupDP({
    required String groupId,
    required File dpFile,
  }) async {
    final result = await fileUploadRepository.uploadFile(
      attachableType: 'ChatRoom',
      attachableId: groupId,
      file: dpFile,
    );

    return result.fold(
      (l) => left(l),
      (r) => right(
        Attachment(
          id: r.recordId.toString(),
          filePath: r.filePath,
          fileType: r.fileType,
        ),
      ),
    );
  }

  Future<Either<Failure, bool>> addMember({
    required String groupId,
    required String userId,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.addMember(
          groupId: groupId,
          userId: userId,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, bool>> removeMember({
    required String groupId,
    required String userId,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.removeMember(
          groupId: groupId,
          userId: userId,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, bool>> makeOrRevokeAdmin({
    required String groupId,
    required String userId,
    required bool makeAdmin,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.makeOrRevokeAdmin(
          groupId: groupId,
          userId: userId,
          makeAdmin: makeAdmin,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, ChatMessage?>> sendChatMessage({
    required String chatRoomId,
    required String text,
    File? attachment,
    String? mediaUrl,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.sendChatMessage(
          chatRoomId: chatRoomId,
          text: text,
          attachment: attachment,
          mediaUrl: mediaUrl,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

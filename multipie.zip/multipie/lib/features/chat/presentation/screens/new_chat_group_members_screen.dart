import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/chat/presentation/cubit/new_chat_group_members/cubit/new_chat_group_members_cubit.dart';
import 'package:multipie/features/chat/presentation/screens/create_chat_group_screen.dart';
import 'package:multipie/locator.dart';
import 'package:provider/provider.dart';

class NewChatGroupMembersScreen extends StatelessWidget {
  const NewChatGroupMembersScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Provider(
        create: (context) => NewChatGroupMembersCubit(
          getFriendsUsecase: locator(),
        ),
        child: Scaffold(
          appBar: MultipieAppBar(
            title: 'New Chat',
            actions: [
              BlocBuilder<NewChatGroupMembersCubit, NewChatGroupMembersState>(
                builder: (context, state) {
                  final enabled = state.selectedMembers.isNotEmpty;
                  return TextButton(
                    onPressed: enabled
                        ? () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => CreateChatGroupScreen(),
                                settings: RouteSettings(
                                  arguments: {
                                    'members': state.selectedMembers,
                                  },
                                ),
                              ),
                            );
                          }
                        : null,
                    child: Text(
                      'Next',
                      style: mpHeadLine5(
                        context: context,
                        fontWeight: FontWeight.w700,
                        textColor:
                            enabled ? context.appTheme.primaryColor : context.appTheme.borderColor.withOpacity(0.5),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
          body: _Body(),
        ),
      ),
    );
  }
}

class _Body extends StatefulWidget {
  const _Body({Key? key}) : super(key: key);

  @override
  State<_Body> createState() => _BodyState();
}

class _BodyState extends State<_Body> {
  late ScrollController _scrollController;

  @override
  void initState() {
    _scrollController = ScrollController();
    context.read<NewChatGroupMembersCubit>().getInitialSuggestions();
    _scrollController.addListener(_onScroll);
    super.initState();
  }

  void _onScroll() {
    if (_scrollController.offset >= _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      context.read<NewChatGroupMembersCubit>().getMoreSuggestions();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SearchBar(),
        _SelectedMembersList(),
        Expanded(
          child: CustomScrollView(
            controller: _scrollController,
            slivers: [
              SliverToBoxAdapter(), // PATCH to make the slivers work
              _MemebersList(),
              _LoadingMoreMembersIndicator(),
            ],
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    super.dispose();
  }
}

class _SearchBar extends StatefulWidget {
  const _SearchBar({Key? key}) : super(key: key);

  @override
  State<_SearchBar> createState() => _SearchBarState();
}

class _SearchBarState extends State<_SearchBar> {
  late TextEditingController _searchController;

  @override
  void initState() {
    _searchController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      padding: EdgeInsets.only(left: 16),
      decoration: BoxDecoration(
        color: context.appTheme.searchBackground,
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
      child: TextField(
        controller: _searchController,
        maxLines: 1,
        style: mpHeadLine4(
          context: context,
          textColor: context.appTheme.primaryTextColor,
        ),
        decoration: new InputDecoration(
          border: InputBorder.none,
          hintText: "Search",
          hintStyle: mpHeadLine4(
            context: context,
            textColor: context.appTheme.secondaryTextColor,
          ),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  onPressed: _clear,
                  icon: Icon(Icons.clear),
                )
              : null,
        ),
        onChanged: (text) => setState(
          () {
            context.read<NewChatGroupMembersCubit>().onSearchPhraseChanged(text);
          },
        ),
      ),
    );
  }

  void _clear() {
    FocusScope.of(context).requestFocus(FocusNode());
    setState(() => _searchController.clear());
    context.read<NewChatGroupMembersCubit>().onSearchPhraseChanged('');
  }
}

class _SelectedMembersList extends StatelessWidget {
  const _SelectedMembersList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<NewChatGroupMembersCubit, NewChatGroupMembersState>(
      builder: (context, state) {
        return state.selectedMembers.isNotEmpty
            ? Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: SizedBox(
                  height: 80,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: state.selectedMembers.length,
                    itemBuilder: (context, index) {
                      final member = state.selectedMembers[index];
                      return Padding(
                        padding: EdgeInsets.only(
                          left: 16,
                          right: index == state.selectedMembers.length - 1 ? 16 : 0,
                        ),
                        child: Stack(
                          children: [
                            Column(
                              children: [
                                SizedBox(
                                  width: 56,
                                  height: 56,
                                  child: ProfilePictureHolder(
                                    showProfileMode: false,
                                    imageUrl: member.dpThumbnail,
                                    textStyle: mpHeadLine2(
                                      context: context,
                                      textColor: context.appTheme.secondaryTextColor,
                                    ),
                                    holderLetter: member.displayname.isEmpty ? '' : member.displayname[0],
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  member.displayname,
                                  style: mpHeadLine7(context: context),
                                  maxLines: 1,
                                ),
                              ],
                            ),
                            Positioned(
                              top: -12,
                              right: -12,
                              child: IconButton(
                                onPressed: () => context.read<NewChatGroupMembersCubit>().toggleMemberSelection(member),
                                icon: Icon(
                                  Icons.do_disturb_on_rounded,
                                  color: context.appTheme.negativeGainColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              )
            : SizedBox();
      },
    );
  }
}

class _MemebersList extends StatelessWidget {
  const _MemebersList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<NewChatGroupMembersCubit, NewChatGroupMembersState>(
      builder: (context, state) {
        if (state.members.isEmpty) {
          return SliverFillRemaining(
            child: Center(
              child: state.isSearching
                  ? MPLoadingIndicator()
                  : Text(
                      'No Results',
                      style: mpHeadLine5(context: context),
                    ),
            ),
          );
        } else {
          final cubit = context.read<NewChatGroupMembersCubit>();
          return SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final member = state.members[index];
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 24),
                      child: IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              width: 65,
                              height: 65,
                              margin: EdgeInsets.only(right: 16),
                              child: ProfilePictureHolder(
                                showProfileMode: false,
                                imageUrl: member.dpThumbnail,
                                textStyle: mpHeadLine2(
                                  context: context,
                                  textColor: context.appTheme.secondaryTextColor,
                                ),
                                holderLetter: member.displayname.isEmpty ? '' : member.displayname[0],
                              ),
                            ),
                            Expanded(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Text(
                                          member.displayname,
                                          textAlign: TextAlign.start,
                                          overflow: TextOverflow.ellipsis,
                                          style: mpHeadLine5(
                                            context: context,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        SizedBox(height: 2),
                                        Text(
                                          "@${member.username}",
                                          textAlign: TextAlign.start,
                                          overflow: TextOverflow.ellipsis,
                                          style: mpHeadLine5(
                                            context: context,
                                            textColor: context.appTheme.secondaryTextColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Checkbox(
                                    value: cubit.selectedMemberIds.contains(member.id),
                                    activeColor: context.appTheme.activeIndicationColor,
                                    onChanged: (_) => cubit.toggleMemberSelection(member),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Divider(
                      color: context.appTheme.secondaryTextColor,
                    )
                  ],
                );
              },
              childCount: state.members.length,
            ),
          );
        }
      },
    );
  }
}

class _LoadingMoreMembersIndicator extends StatelessWidget {
  const _LoadingMoreMembersIndicator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<NewChatGroupMembersCubit, NewChatGroupMembersState>(
      builder: (context, state) {
        return SliverToBoxAdapter(
          child: state.isSearching && state.members.isNotEmpty
              ? SizedBox(
                  height: 100,
                  child: Center(
                    child: MPLoadingIndicator(),
                  ),
                )
              : SizedBox(),
        );
      },
    );
  }
}

import 'package:dartz/dartz.dart' hide State;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/custom_icon.dart';
import 'package:multipie/core/widgets/image_picker.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/core/widgets/primart_text_form_field.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_group_editor.dart/cubit/chat_group_editor_cubit.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/features/chat/presentation/cubit/new_chat_group_members/cubit/new_chat_group_members_cubit.dart';
import 'package:multipie/features/chat/presentation/widgets/room_avatar_widget.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/custom_bottom_sheet.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/profile_screen_bloc.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/locator.dart';
import 'package:provider/provider.dart';

class ChatGroupEditorScreen extends StatelessWidget {
  const ChatGroupEditorScreen({
    Key? key,
    required this.room,
    required this.onChatRoomUpdated,
  }) : super(key: key);

  final ChatRoom room;
  final ValueChanged<ChatRoom> onChatRoomUpdated;

  @override
  Widget build(BuildContext context) {
    return Provider<ChatGroupEditorCubit>(
      create: (context) => ChatGroupEditorCubit(
        chatRoom: room,
        currentUserId: context.read<UserProfileBloc>().currentUser!.id,
        chatRepository: locator(),
        onChatRoomUpdated: onChatRoomUpdated,
        chatRoomsCubit: context.read<ChatRoomsCubit>(),
        searchMembersCubit: NewChatGroupMembersCubit(
          getFriendsUsecase: locator(),
        ),
      ),
      dispose: (_, cubit) => cubit.dispose(),
      child: Scaffold(
        appBar: MultipieAppBar(
          title: 'Chat Information',
          actions: [
            _SaveNameButton(),
          ],
        ),
        body: _Body(),
      ),
    );
  }
}

class _SaveNameButton extends StatelessWidget {
  const _SaveNameButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        if (!state.isSavingName) {
          final enableButton = cubit.nameError == null && cubit.hasPendingNameChanges;
          return TextButton(
            onPressed: enableButton
                ? () async {
                    FocusScope.of(context).unfocus();
                    final result = await context.read<ChatGroupEditorCubit>().updateChatGroupName();
                    result.fold(
                      (errMessage) => ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            errMessage,
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.lightTextColor,
                            ),
                          ),
                        ),
                      ),
                      (_) {},
                    );
                  }
                : null,
            child: Text(
              'Save',
              style: mpHeadLine5(
                context: context,
                fontWeight: FontWeight.w700,
                textColor: enableButton ? context.appTheme.primaryColor : context.appTheme.borderColor.withOpacity(0.5),
              ),
            ),
          );
        } else {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Center(
              child: SizedBox(
                width: 30,
                height: 30,
                child: MPLoadingIndicator(),
              ),
            ),
          );
        }
      },
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        return CustomScrollView(
          slivers: [
            _Header(),
            SliverPadding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              sliver: _Divider(),
            ),
            if (cubit.isGroupEditable) _UsersSearchBar(),
            if (!state.isSearchActive) ...[
              _MembersListHeading(),
              _MembersList(),
            ] else
              _SearchedUsersList(),
          ],
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        return SliverPadding(
          padding: const EdgeInsets.only(top: 16, left: 16, right: 16),
          sliver: SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: _GroupAvatar(),
                ),
                SizedBox(height: 8),
                if (cubit.isGroupEditable)
                  _GroupNameField()
                else
                  Center(
                    child: Text(
                      state.room.name ?? '',
                      style: mpHeadLine5(
                        context: context,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _GroupAvatar extends StatelessWidget {
  const _GroupAvatar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        final enableEditing = cubit.isGroupEditable && !state.isUploadingDP;
        return GestureDetector(
          onTap: enableEditing
              ? () async {
                  final pickedImage = await pickImage(context);
                  if (pickedImage != null) {
                    final result = await cubit.updateChatGroupDP(pickedImage);
                    result.fold(
                      (errMessage) => ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            errMessage,
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.lightTextColor,
                            ),
                          ),
                        ),
                      ),
                      (_) {},
                    );
                  }
                }
              : null,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Opacity(
                opacity: state.isUploadingDP ? 0.5 : 1,
                child: RoomAvatarWidget(
                  room: state.room,
                  size: 64,
                ),
              ),
              if (enableEditing)
                Positioned(
                  right: -10,
                  bottom: 0,
                  child: SvgPicture.asset(
                    CustomIcons.ic_camera.assetName,
                    height: 24,
                    width: 24,
                    color: context.appTheme.activeIndicationColor,
                  ),
                ),
              if (state.isUploadingDP)
                SizedBox(
                  width: 64,
                  height: 64,
                  child: Center(
                    child: SizedBox(
                      width: 24,
                      height: 24,
                      child: MPLoadingIndicator(),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _GroupNameField extends StatefulWidget {
  const _GroupNameField({Key? key}) : super(key: key);

  @override
  State<_GroupNameField> createState() => __GroupNameFieldState();
}

class __GroupNameFieldState extends State<_GroupNameField> {
  late TextEditingController _nameController;

  @override
  void initState() {
    final cubit = context.read<ChatGroupEditorCubit>();
    _nameController = TextEditingController(text: cubit.state.room.name);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PrimaryTextFormField(
              controller: _nameController,
              labelText: 'Name',
              onChanged: (text) => cubit.onNameChanged(text),
            ),
            if (cubit.nameError != null) ...[
              SizedBox(height: 4),
              Text(
                cubit.nameError!,
                style: mpHeadLine6(context: context, textColor: context.appTheme.negativeGainColor),
              ),
            ]
          ],
        );
      },
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Container(
        color: context.appTheme.borderColor.withOpacity(0.5),
        height: 0.5,
      ),
    );
  }
}

class _MembersListHeading extends StatelessWidget {
  const _MembersListHeading({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text(
            'Members',
            style: mpHeadLine5(
              context: context,
              fontWeight: FontWeight.w700,
              textColor: context.appTheme.activeIndicationColor,
            ),
          ),
        ),
      ),
    );
  }
}

class _MembersList extends StatelessWidget {
  const _MembersList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        return SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              final member = cubit.sortedGroupMembers[index];
              final user = cubit.getUserForUserId(member.userId.toString());
              if (user == null) {
                return SizedBox();
              }
              final isGroupAdmin = cubit.isUserGroupAdmin(user.id);
              final isSelf = user.id == cubit.currentUserId;
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 24),
                    child: IntrinsicHeight(
                      child: Row(
                        children: [
                          Expanded(
                            child: _UserTile(
                              user: user,
                              isGroupAdmin: isGroupAdmin,
                            ),
                          ),
                          if (cubit.isGroupEditable && !isSelf)
                            IconButton(
                              onPressed: () {
                                showCustomBottomSheet(
                                  context: context,
                                  padding: EdgeInsets.symmetric(vertical: 20),
                                  child: Column(
                                    children: [
                                      ListTile(
                                        onTap: () {
                                          Navigator.of(context).pop();
                                          cubit.removeMember(user);
                                        },
                                        title: Text(
                                          'Remove from group',
                                          style: mpHeadLine5(context: context),
                                        ),
                                      ),
                                      ListTile(
                                        onTap: () {
                                          Navigator.of(context).pop();
                                          cubit.makeOrRevokeAdmin(
                                            user: user,
                                            makeAdmin: !isGroupAdmin,
                                          );
                                        },
                                        title: Text(
                                          isGroupAdmin ? 'Revoke Admin' : 'Make Admin',
                                          style: mpHeadLine5(context: context),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                              icon: Icon(
                                Icons.more_vert,
                                color: context.appTheme.activeIndicationColor,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  Divider(
                    color: context.appTheme.secondaryTextColor,
                  ),
                ],
              );
            },
            childCount: state.room.chatRoomMembers.length,
          ),
        );
      },
    );
  }
}

class _UserTile extends StatelessWidget {
  const _UserTile({
    Key? key,
    required this.user,
    required this.isGroupAdmin,
  }) : super(key: key);

  final User user;
  final bool isGroupAdmin;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          width: 44,
          height: 44,
          margin: EdgeInsets.only(right: 16),
          child: ProfilePictureHolder(
            showProfileMode: false,
            imageUrl: user.dpThumbnail,
            textStyle: mpHeadLine2(
              context: context,
              textColor: context.appTheme.secondaryTextColor,
            ),
            holderLetter: user.displayname.isEmpty ? '' : user.displayname[0],
          ),
        ),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              RichText(
                text: TextSpan(
                  text: user.displayname,
                  style: mpHeadLine5(
                    context: context,
                    fontWeight: FontWeight.w500,
                  ),
                  children: [
                    if (isGroupAdmin)
                      TextSpan(
                        text: '   • Group Admin',
                        style: mpHeadLine6(
                          context: context,
                          fontWeight: FontWeight.w500,
                          textColor: context.appTheme.activeIndicationColor,
                        ),
                      ),
                  ],
                ),
                textAlign: TextAlign.start,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 2),
              Text(
                "@${user.username}",
                textAlign: TextAlign.start,
                overflow: TextOverflow.ellipsis,
                style: mpHeadLine5(
                  context: context,
                  textColor: context.appTheme.secondaryTextColor,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _UsersSearchBar extends StatefulWidget {
  const _UsersSearchBar({Key? key}) : super(key: key);

  @override
  State<_UsersSearchBar> createState() => _UsersSearchBarState();
}

class _UsersSearchBarState extends State<_UsersSearchBar> {
  late TextEditingController _searchController;

  @override
  void initState() {
    _searchController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      pinned: true,
      titleSpacing: 0,
      leadingWidth: 0,
      leading: SizedBox(),
      title: Container(
        height: 40,
        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        padding: EdgeInsets.only(left: 16),
        decoration: BoxDecoration(
          color: context.appTheme.searchBackground,
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
        ),
        child: TextField(
          controller: _searchController,
          maxLines: 1,
          style: mpHeadLine4(
            context: context,
            textColor: context.appTheme.primaryTextColor,
          ),
          decoration: new InputDecoration(
            border: InputBorder.none,
            hintText: 'Add or remove friends',
            hintStyle: mpHeadLine4(
              context: context,
              textColor: context.appTheme.secondaryTextColor,
            ),
            suffixIcon: _searchController.text.isNotEmpty
                ? IconButton(
                    onPressed: _clear,
                    icon: Icon(Icons.clear),
                  )
                : null,
          ),
          onChanged: (text) => setState(
            () {
              context.read<ChatGroupEditorCubit>().searchMembersCubit.onSearchPhraseChanged(text);
            },
          ),
        ),
      ),
    );
  }

  void _clear() {
    FocusScope.of(context).requestFocus(FocusNode());
    setState(() => _searchController.clear());
    context.read<ChatGroupEditorCubit>().searchMembersCubit.onSearchPhraseChanged('');
  }
}

class _SearchedUsersList extends StatelessWidget {
  const _SearchedUsersList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatGroupEditorCubit, ChatGroupEditorState>(
      builder: (context, state) {
        final cubit = context.read<ChatGroupEditorCubit>();
        return SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              final user = state.searchedMembers[index];
              final isGroupAdmin = cubit.isUserGroupAdmin(user.id);
              final isGroupMember = cubit.isGroupMember(user.id);
              final isSelf = user.id == cubit.currentUserId;

              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 24),
                    child: IntrinsicHeight(
                      child: Row(
                        children: [
                          Expanded(
                            child: _UserTile(
                              user: user,
                              isGroupAdmin: isGroupAdmin,
                            ),
                          ),
                          if (!isSelf)
                            MaterialButton(
                              color: context.appTheme.activeIndicationColor,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onPressed: () async {
                                Either<String, bool> result;
                                if (isGroupMember) {
                                  result = await cubit.removeMember(user);
                                } else {
                                  result = await cubit.addMember(user);
                                }
                                result.fold(
                                  (message) => ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        message,
                                        style: mpHeadLine5(
                                          context: context,
                                          textColor: context.appTheme.lightTextColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                  (_) => null,
                                );
                              },
                              child: Text(
                                isGroupMember ? 'Remove' : 'Add',
                                style: mpHeadLine6(
                                  context: context,
                                  textColor: context.appTheme.lightTextColor,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  Divider(
                    color: context.appTheme.secondaryTextColor,
                  ),
                ],
              );
            },
            childCount: state.searchedMembers.length,
          ),
        );
      },
    );
  }
}

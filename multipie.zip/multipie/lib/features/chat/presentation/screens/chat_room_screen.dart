import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:collection/src/iterable_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/images_path.dart';
import 'package:multipie/core/widgets/image_picker.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/domain/usecases/get_chat_messages_usecase.dart';
import 'package:multipie/features/chat/domain/usecases/send_chat_message_usecase.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_room/chat_room_cubit.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/features/chat/presentation/screens/chat_group_editor_screen.dart';
import 'package:multipie/features/chat/presentation/widgets/chat_message_widget.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/image_post_widget.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/profile_screen_bloc.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/flutter_mentions/flutter_mentions.dart';
import 'package:multipie/locator.dart';
import 'package:multipie/services/socket_service.dart';
import 'package:provider/provider.dart';

class ChatRoomScreen extends StatelessWidget {
  const ChatRoomScreen({
    Key? key,
    required this.room,
  }) : super(key: key);

  final ChatRoom room;

  @override
  Widget build(BuildContext context) {
    return Provider<ChatRoomCubit>(
      create: (_) => ChatRoomCubit(
        room: room,
        chatRoomsCubit: context.read<ChatRoomsCubit>(),
        getChatMessagesUsecase: locator<GetChatMessagesUsecase>(),
        sendChatMessageUsecase: locator<SendChatMessageUsecase>(),
        socketService: locator<SocketService>(),
      )..refresh(),
      dispose: (_, cubit) => cubit.dispose(),
      child: _Scaffold(),
    );
  }
}

class _Scaffold extends StatelessWidget {
  const _Scaffold({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currentUser = context.read<UserProfileBloc>().currentUser!;
    final user = types.User(
      id: currentUser.id,
      firstName: currentUser.displayname,
      imageUrl: currentUser.dpUrl,
    );
    final cubit = context.read<ChatRoomCubit>();
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: MultipieAppBar(
          titleBuilder: (context) => _ScreenTitleWidget(),
          centerTitle: false,
          actions: [
            if (cubit.state.room.groupChat)
              IconButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<ChatGroupEditorScreen>(
                      builder: (context) => ChatGroupEditorScreen(
                        room: cubit.state.room,
                        onChatRoomUpdated: cubit.updateChatRoom,
                      ),
                    ),
                  );
                },
                icon: SvgPicture.asset(
                  icInfo,
                  color: context.appTheme.activeIndicationColor,
                  width: 32,
                  height: 32,
                ),
              ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: _ChatRoomBodyWidget(user: user),
            ),
            _InputWidget(),
          ],
        ),
      ),
    );
  }
}

class _ScreenTitleWidget extends StatelessWidget {
  const _ScreenTitleWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatRoomCubit, ChatRoomState>(
      builder: (context, state) {
        if (state.room.groupChat) {
          return Text(
            state.room.name ?? '',
            style: mpHeadLine4(
              context: context,
              textColor: context.appTheme.primaryColor,
              fontWeight: FontWeight.w500,
            ),
          );
        } else {
          final currentUserId = context.read<UserProfileBloc>().currentUser!.id;
          final otherUser = state.room.users.firstWhereOrNull((e) => e.id != currentUserId);
          if (otherUser != null) {
            return RichText(
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              text: TextSpan(
                text: otherUser.displayname,
                children: [
                  TextSpan(
                    text: ' @${otherUser.username}',
                    style: mpHeadLine5(
                      context: context,
                      textColor: context.appTheme.secondaryTextColor,
                    ),
                  ),
                ],
                style: mpHeadLine4(
                  context: context,
                  textColor: context.appTheme.primaryColor,
                  fontWeight: FontWeight.w600,
                ),
              ),
            );
          } else {
            return SizedBox();
          }
        }
      },
    );
  }
}

class _ChatRoomBodyWidget extends StatelessWidget {
  const _ChatRoomBodyWidget({
    Key? key,
    required this.user,
  }) : super(key: key);

  final types.User user;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatRoomCubit, ChatRoomState>(
      builder: (context, state) {
        final dateFormatPattern = 'dd/MM/y';
        final primaryColor = context.appTheme.activeIndicationColor;
        final secondaryColor = context.appTheme.alternateRowColor;
        return NotificationListener<ScrollEndNotification>(
          onNotification: (notification) {
            if (notification.metrics.pixels < 10) {
              context.read<ChatRoomCubit>().onLastMessageVisible();
            }
            return true;
          },
          child: Chat(
            bubbleBuilder: (
              child, {
              required types.Message message,
              required bool nextMessageInGroup,
            }) =>
                _MessageBubble(
              child: child,
              isFromCurrentUser: user.id == message.author.id,
              nextMessageInGroup: nextMessageInGroup,
            ),
            messages: _mapToMessages(
              chatMessages: state.messages,
              users: state.room.users,
            ),
            onSendPressed: (text) {},
            user: user,
            customBottomWidget: SizedBox(),
            showUserAvatars: state.room.groupChat,
            emptyState: Center(
              child: state.isLoadingMessages
                  ? MPLoadingIndicator()
                  : Text(
                      'No Messages',
                      style: mpHeadLine5(context: context),
                    ),
            ),
            onEndReached: () => context.read<ChatRoomCubit>().fetchMore(),
            theme: DefaultChatTheme(
              backgroundColor: context.appTheme.transparentColor,
              primaryColor: primaryColor,
              secondaryColor: secondaryColor,
              messageBorderRadius: 8,
              dateDividerTextStyle: mpHeadLine6(
                context: context,
                textColor: context.appTheme.secondaryTextColor,
                fontWeight: FontWeight.w500,
              ),
              userAvatarNameColors: [
                context.appTheme.primaryColor.withOpacity(0.3),
              ],
              userAvatarTextStyle: mpHeadLine5(
                context: context,
                textColor: context.appTheme.primaryColor,
                fontWeight: FontWeight.normal,
              ),
            ),
            dateHeaderThreshold: 86400000, // 1 Day
            customDateHeaderText: (date) {
              final formattedDate = date.format(dateFormatPattern);
              final now = DateTime.now().toUtc();
              if (now.format(dateFormatPattern) == formattedDate) {
                return 'Today';
              } else if (now.subtract(Duration(days: 1)).format(dateFormatPattern) == formattedDate) {
                return 'Yesterday';
              } else {
                return formattedDate;
              }
            },
            dateFormat: DateFormat(dateFormatPattern),
            timeFormat: DateFormat('hh:mm a'),
            customMessageBuilder: (
              message, {
              required int messageWidth,
            }) {
              final chatMessage = message.metadata!['message'] as ChatMessage;
              return ChatMessageWidget(
                message: chatMessage,
                showUserName: state.room.groupChat,
                isSentByCurrentUser: message.author.id == user.id,
                width: messageWidth,
              );
            },
          ),
        );
      },
    );
  }

  List<types.Message> _mapToMessages({
    required List<ChatMessage> chatMessages,
    required List<User> users,
  }) {
    return chatMessages.map(
      (message) {
        final user = users.firstWhereOrNull((user) => user.id == '${message.fromId}');
        return types.CustomMessage(
          id: message.id,
          author: types.User(
            id: '${message.fromId}',
            firstName: user?.displayname,
            imageUrl: user?.dpUrl,
          ),
          metadata: {'message': message},
          createdAt: message.createdAt!.millisecondsSinceEpoch,
          updatedAt: message.updatedAt.millisecondsSinceEpoch,
        );
      },
    ).toList(growable: false);
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    Key? key,
    required this.child,
    required this.isFromCurrentUser,
    required this.nextMessageInGroup,
  }) : super(key: key);

  final Widget child;
  final bool isFromCurrentUser;
  final bool nextMessageInGroup;

  @override
  Widget build(BuildContext context) {
    final borderRadius = 12.0;
    final showBottomLeftNip = nextMessageInGroup ? false : !isFromCurrentUser;
    final showBottomRightNip = nextMessageInGroup ? false : isFromCurrentUser;
    return Container(
      decoration: BoxDecoration(
        color: isFromCurrentUser ? context.appTheme.activeIndicationColor : context.appTheme.cardBackgroundColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(borderRadius),
          topRight: Radius.circular(borderRadius),
          bottomLeft: showBottomLeftNip ? Radius.zero : Radius.circular(borderRadius),
          bottomRight: showBottomRightNip ? Radius.zero : Radius.circular(borderRadius),
        ),
        border: !isFromCurrentUser ? Border.all(color: context.appTheme.borderColor, width: 0.5) : null,
      ),
      child: child,
    );
  }
}

class _InputWidget extends StatefulWidget {
  const _InputWidget({
    Key? key,
  }) : super(key: key);

  @override
  State<_InputWidget> createState() => _InputWidgetState();
}

class _InputWidgetState extends State<_InputWidget> {
  late AnnotationEditingController textController;
  File? _attachment;
  String? _gifUrl;

  @override
  void initState() {
    textController = AnnotationEditingController({});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatRoomCubit, ChatRoomState>(
      builder: (context, state) {
        final isAttachmentButtonsEnabled = _attachment == null && _gifUrl == null;
        final isSendEnabled =
            (textController.markupText.trim().isNotEmpty || !isAttachmentButtonsEnabled) && !state.isSendingMessage;
        final cubit = context.read<ChatRoomCubit>();
        return IgnorePointer(
          ignoring: state.isSendingMessage,
          child: Opacity(
            opacity: state.isSendingMessage ? 0.75 : 1,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 0.5,
                  color: context.appTheme.borderColor,
                ),
                if (_attachment != null)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Stack(
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ViewImageScreen(
                                      imagePath: [_attachment!.path],
                                    ),
                                  ),
                                );
                              },
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: Image.file(
                                  _attachment!,
                                  width: 100,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Positioned(
                              top: -4,
                              right: -4,
                              child: IconButton(
                                onPressed: () => setState(() => _attachment = null),
                                visualDensity: VisualDensity.compact,
                                icon: Icon(
                                  Icons.close,
                                  color: context.appTheme.lightTextColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                else if (_gifUrl != null)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: CachedNetworkImage(
                                imageUrl: _gifUrl!,
                                width: 100,
                                fit: BoxFit.cover,
                                placeholder: (context, url) => Center(child: CircularProgressIndicator()),
                                errorWidget: (context, url, error) => Icon(Icons.error),
                              ),
                            ),
                            Positioned(
                              top: -4,
                              right: -4,
                              child: IconButton(
                                onPressed: () => setState(() => _gifUrl = null),
                                visualDensity: VisualDensity.compact,
                                icon: Icon(
                                  Icons.close,
                                  color: context.appTheme.lightTextColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: isAttachmentButtonsEnabled
                              ? () async {
                                  final image = await pickImage(context);
                                  if (image != null) {
                                    setState(() => _attachment = image);
                                  }
                                }
                              : null,
                          icon: SvgPicture.asset(
                            gallery,
                            color: isAttachmentButtonsEnabled
                                ? context.appTheme.primaryColor
                                : context.appTheme.secondaryTextColor,
                          ),
                        ),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: () async {
                            final gif = await getGiphy(context);
                            if (!gif.isNullOrEmpty()) {
                              setState(() => _gifUrl = gif);
                            }
                          },
                          icon: SvgPicture.asset(
                            gif,
                            color: isAttachmentButtonsEnabled
                                ? context.appTheme.primaryColor
                                : context.appTheme.secondaryTextColor,
                          ),
                        ),
                        Expanded(
                          child: FlutterMentions(
                            suggestionPosition: SuggestionPosition.Top,
                            controller: textController,
                            autofocus: false,
                            maxLines: 5,
                            minLines: 1,
                            onMarkupChanged: (text) => setState(() {}),
                            decoration: InputDecoration(
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: context.appTheme.borderColor,
                                ),
                              ),
                              hintText: 'Send a message',
                              hintStyle: mpHeadLine6(
                                context: context,
                                textColor: context.appTheme.secondaryTextColor,
                              ),
                              counterText: '',
                            ),
                            textCapitalization: TextCapitalization.sentences,
                            mentions: [
                              Mention(
                                trigger: '@',
                                style: TextStyle(
                                  color: context.appTheme.secondaryColor,
                                ),
                                matchAll: true,
                              ),
                              Mention(
                                trigger: '#',
                                style: TextStyle(
                                  color: context.appTheme.secondaryColor,
                                ),
                                matchAll: true,
                              ),
                              Mention(
                                trigger: '\$',
                                style: TextStyle(
                                  color: context.appTheme.secondaryColor,
                                ),
                                matchAll: true,
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: IconButton(
                            visualDensity: VisualDensity.compact,
                            onPressed: isSendEnabled
                                ? () async {
                                    final sent = await cubit.sendMessage(
                                      text: textController.markupText.trim(),
                                      attachment: _attachment,
                                      mediaUrl: _gifUrl,
                                    );
                                    if (sent) {
                                      setState(() {
                                        textController.clear();
                                        _attachment = null;
                                        _gifUrl = null;
                                      });
                                    }
                                  }
                                : null,
                            icon: state.isSendingMessage
                                ? MPLoadingIndicator()
                                : Icon(
                                    Icons.send,
                                    color: isSendEnabled
                                        ? context.appTheme.activeIndicationColor
                                        : context.appTheme.secondaryTextColor,
                                  ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

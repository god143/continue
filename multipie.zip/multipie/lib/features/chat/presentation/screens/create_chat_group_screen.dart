import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/core/widgets/primart_text_form_field.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/features/chat/presentation/cubit/create_chat_group/cubit/create_chat_group_cubit.dart';
import 'package:multipie/features/chat/presentation/screens/chat_room_screen.dart';
import 'package:multipie/features/chat/presentation/screens/chat_rooms_screen.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/locator.dart';
import 'package:provider/provider.dart';

class CreateChatGroupScreen extends StatelessWidget {
  const CreateChatGroupScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Provider(
        create: (_) {
          final args = ModalRoute.of(context)!.settings.arguments as Map;
          final members = args['members'] as List<User>;
          return CreateChatGroupCubit(
            members: members,
            chatRepository: locator(),
          );
        },
        child: Scaffold(
          appBar: MultipieAppBar(
            title: 'New Group Name',
            actions: [
              _CreateGroupButton(),
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _GroupNameField(),
                  SizedBox(height: 32),
                  _MembersList(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CreateGroupButton extends StatelessWidget {
  const _CreateGroupButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CreateChatGroupCubit, CreateChatGroupState>(
      builder: (context, state) {
        final cubit = context.read<CreateChatGroupCubit>();
        if (!state.isCreating) {
          return TextButton(
            onPressed: cubit.isFormValid
                ? () async {
                    FocusScope.of(context).unfocus();
                    final result = await context.read<CreateChatGroupCubit>().createGroup();
                    result.fold(
                      (errMessage) => ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            errMessage,
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.lightTextColor,
                            ),
                          ),
                        ),
                      ),
                      (room) {
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute<ChatRoomScreen>(
                            builder: (_) => ChatRoomScreen(room: room),
                          ),
                          (route) => route is MaterialPageRoute<ChatRoomsScreen>,
                        );
                        context.read<ChatRoomsCubit>().refresh();
                      },
                    );
                  }
                : null,
            child: Text(
              'Create',
              style: mpHeadLine5(
                context: context,
                fontWeight: FontWeight.w700,
                textColor:
                    cubit.isFormValid ? context.appTheme.primaryColor : context.appTheme.borderColor.withOpacity(0.5),
              ),
            ),
          );
        } else {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Center(
              child: SizedBox(
                width: 30,
                height: 30,
                child: MPLoadingIndicator(),
              ),
            ),
          );
        }
      },
    );
  }
}

class _GroupNameField extends StatefulWidget {
  const _GroupNameField({Key? key}) : super(key: key);

  @override
  State<_GroupNameField> createState() => _GroupNameFieldState();
}

class _GroupNameFieldState extends State<_GroupNameField> {
  late TextEditingController _nameController;

  @override
  void initState() {
    _nameController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CreateChatGroupCubit, CreateChatGroupState>(
      builder: (context, state) {
        final cubit = context.read<CreateChatGroupCubit>();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PrimaryTextFormField(
              controller: _nameController,
              labelText: 'Name',
              onChanged: (text) => cubit.onNameChanged(text),
            ),
            if (cubit.nameError != null) ...[
              SizedBox(height: 4),
              Text(
                cubit.nameError!,
                style: mpHeadLine6(context: context, textColor: context.appTheme.negativeGainColor),
              ),
            ]
          ],
        );
      },
    );
  }
}

class _MembersList extends StatelessWidget {
  const _MembersList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CreateChatGroupCubit, CreateChatGroupState>(
      builder: (context, state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Participants',
              style: mpHeadLine4(
                context: context,
                textColor: context.appTheme.activeIndicationColor,
              ),
            ),
            SizedBox(height: 12),
            Wrap(
              runSpacing: 16,
              spacing: 16,
              children: state.members
                  .map(
                    (member) => SizedBox(
                      width: 56,
                      height: 56,
                      child: ProfilePictureHolder(
                        showProfileMode: false,
                        imageUrl: member.dpThumbnail,
                        textStyle: mpHeadLine2(
                          context: context,
                          textColor: context.appTheme.secondaryTextColor,
                        ),
                        holderLetter: member.displayname.isEmpty ? '' : member.displayname[0],
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ],
        );
      },
    );
  }
}

import 'package:cached_network_image/cached_network_image.dart';
import 'package:collection/src/iterable_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_parsed_text/flutter_parsed_text.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/date_util.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/images_path.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/features/chat/presentation/cubit/search_friends/search_friends_cubit.dart';
import 'package:multipie/features/chat/presentation/screens/chat_room_screen.dart';
import 'package:multipie/features/chat/presentation/screens/new_chat_group_members_screen.dart';
import 'package:multipie/features/chat/presentation/widgets/room_avatar_widget.dart';
import 'package:multipie/features/chat/presentation/widgets/unread_messages_badge.dart';
import 'package:multipie/features/mention/presentation/matchers.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/bloc.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/locator.dart';

class ChatRoomsScreen extends StatefulWidget {
  const ChatRoomsScreen({Key? key}) : super(key: key);

  @override
  State<ChatRoomsScreen> createState() => _ChatRoomsScreenState();
}

class _ChatRoomsScreenState extends State<ChatRoomsScreen> {
  bool _isSearchActive = false;
  late final TextEditingController _textEditingController;
  late final ScrollController _scrollController;

  @override
  void initState() {
    _textEditingController = TextEditingController();
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
    context.read<ChatRoomsCubit>().refresh();
    super.initState();
  }

  void _onScroll() {
    if (_scrollController.offset >= _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      context.read<ChatRoomsCubit>().fetchMore();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: BlocProvider<SearchFriendsCubit>(
        create: (_) => SearchFriendsCubit(getFriendsUsecase: locator()),
        child: Scaffold(
          appBar: MultipieAppBar(
            title: 'Messages',
            centerTitle: false,
            actions: [
              IconButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => NewChatGroupMembersScreen(),
                  ),
                ),
                icon: SvgPicture.asset(
                  icCreateChatGroup,
                  color: context.appTheme.primaryTextColor,
                ),
                iconSize: 44,
              ),
            ],
          ),
          body: SafeArea(
            top: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _SearchReciepientsWidget(
                  textEditingController: _textEditingController,
                  onSearchMode: (isInSearchMode) => setState(() => _isSearchActive = isInSearchMode),
                ),
                Expanded(
                  child: _isSearchActive
                      ? _SearchedReciepientsList(
                          onRecipientSelected: (recipient) async {
                            FocusScope.of(context).unfocus();
                            _textEditingController.clear();
                            final room = await context.read<ChatRoomsCubit>().createChatRoom(recipient: recipient);
                            if (room != null) {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ChatRoomScreen(room: room),
                                ),
                              );
                            }
                          },
                        )
                      : _ChatRoomsList(scrollController: _scrollController),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    super.dispose();
  }
}

class _SearchReciepientsWidget extends StatefulWidget {
  const _SearchReciepientsWidget({
    Key? key,
    required this.textEditingController,
    required this.onSearchMode,
  }) : super(key: key);

  final TextEditingController textEditingController;
  final ValueChanged<bool> onSearchMode;

  @override
  _SearchReciepientsWidgetState createState() => _SearchReciepientsWidgetState();
}

class _SearchReciepientsWidgetState extends State<_SearchReciepientsWidget> {
  bool _isClearButtonVisible = false;

  @override
  void initState() {
    widget.textEditingController.addListener(_onTextChanged);
    super.initState();
  }

  void _onTextChanged() {
    final text = widget.textEditingController.text.trim();
    setState(() => _isClearButtonVisible = text.isNotEmpty);
    if (text.length >= 2) {
      widget.onSearchMode(true);
      context.read<SearchFriendsCubit>().search(text);
    } else {
      widget.onSearchMode(false);
    }
  }

  void _clear() {
    FocusScope.of(context).requestFocus(FocusNode());
    setState(() => widget.textEditingController.clear());
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      padding: EdgeInsets.only(left: 16),
      decoration: BoxDecoration(
        color: context.appTheme.searchBackground,
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
      child: TextField(
        controller: widget.textEditingController,
        maxLines: 1,
        style: mpHeadLine4(
          context: context,
          textColor: context.appTheme.primaryTextColor,
        ),
        decoration: new InputDecoration(
          border: InputBorder.none,
          hintText: "Search",
          hintStyle: mpHeadLine4(
            context: context,
            textColor: context.appTheme.secondaryTextColor,
          ),
          suffixIcon: _isClearButtonVisible
              ? IconButton(
                  onPressed: _clear,
                  icon: Icon(Icons.clear),
                )
              : null,
        ),
      ),
    );
  }

  @override
  void dispose() {
    widget.textEditingController.removeListener(_onTextChanged);
    super.dispose();
  }
}

class _ChatRoomsList extends StatelessWidget {
  const _ChatRoomsList({
    Key? key,
    required this.scrollController,
  }) : super(key: key);

  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatRoomsCubit, ChatRoomsState>(
      builder: (context, state) {
        if (state.rooms.isNotEmpty) {
          return ListView.separated(
            controller: scrollController,
            physics: AlwaysScrollableScrollPhysics(),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            itemBuilder: (context, index) {
              if (index == state.rooms.length) {
                if (state.isLoadingRooms) {
                  return SizedBox(
                    child: Center(
                      child: MPLoadingIndicator(),
                    ),
                    height: 100,
                  );
                } else {
                  return SizedBox();
                }
              }
              final room = state.rooms[index];
              return _ChatRoomTile(
                room: room,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ChatRoomScreen(room: room),
                  ),
                ),
              );
            },
            separatorBuilder: (context, index) {
              return Container(
                height: 0.5,
                color: context.appTheme.borderColor,
              );
            },
            itemCount: state.rooms.length + 1,
          );
        } else if (state.isLoadingRooms) {
          return Center(
            child: MPLoadingIndicator(),
          );
        } else {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                'No chats available!',
                style: mpHeadLine4(context: context),
              ),
            ),
          );
        }
      },
    );
  }
}

class _ChatRoomTile extends StatelessWidget {
  const _ChatRoomTile({
    Key? key,
    required this.room,
    required this.onTap,
  }) : super(key: key);

  final ChatRoom room;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final unreadMessagesCount = (room.unreadMessageCount ?? 0);
    final String unreadMessagesText;
    if (unreadMessagesCount >= 10) {
      unreadMessagesText = '9+';
    } else if (unreadMessagesCount > 0) {
      unreadMessagesText = '$unreadMessagesCount';
    } else {
      unreadMessagesText = '';
    }
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(
          top: 8,
          bottom: 8,
          left: 8,
          right: 12,
        ),
        child: Row(
          children: [
            unreadMessagesText.isNotEmpty
                ? UnreadMessagesBadge(unreadMessages: unreadMessagesText)
                : SizedBox(width: 16),
            const SizedBox(width: 8),
            RoomAvatarWidget(room: room),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: _RoomNameWidget(room: room)),
                      if (room.lastMessage?.updatedAt != null) ...[
                        SizedBox(width: 8),
                        Text(
                          DateUtil.timeAgo(room.lastMessage!.updatedAt),
                          style: mpHeadLine7(
                            context: context,
                            textColor: context.appTheme.secondaryTextColor,
                          ),
                        ),
                      ]
                    ],
                  ),
                  const SizedBox(height: 8),
                  _LastMessageContent(room: room),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoomNameWidget extends StatelessWidget {
  const _RoomNameWidget({
    Key? key,
    required this.room,
  }) : super(key: key);

  final ChatRoom room;

  @override
  Widget build(BuildContext context) {
    final String name;
    String? suffixName;
    if (room.groupChat) {
      name = room.name ?? 'Unknown';
    } else {
      final currentUserId = context.read<UserProfileBloc>().currentUser!.id;
      final otherUser = room.users.firstWhereOrNull((e) => e.id != currentUserId);
      name = otherUser?.displayname ?? 'Unknown';
      if (otherUser != null) {
        suffixName = otherUser.username;
      }
    }

    return RichText(
      text: TextSpan(
        text: name,
        style: mpHeadLine5(
          context: context,
          textColor: context.appTheme.primaryColor,
          fontWeight: FontWeight.w600,
        ),
        children: [
          if (suffixName != null)
            TextSpan(
              text: ' @$suffixName',
              style: mpHeadLine5(
                context: context,
                textColor: context.appTheme.secondaryTextColor,
                fontWeight: FontWeight.w400,
              ),
            ),
        ],
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

class _LastMessageContent extends StatelessWidget {
  const _LastMessageContent({
    Key? key,
    required this.room,
  }) : super(key: key);

  final ChatRoom room;

  @override
  Widget build(BuildContext context) {
    final message = room.lastMessage;
    if (message == null) {
      return SizedBox();
    }
    final String messageText;
    if (room.groupChat) {
      messageText = '@:lastMessageUser/${message.fromId} ${message.messageContent}';
    } else {
      messageText = message.messageContent;
    }
    return ParsedText(
      text: messageText,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: mpHeadLine6(context: context),
      parse: [
        getMatcherForLastMessageUser(
          context: context,
          getUser: (userId) => room.users.firstWhereOrNull((e) => e.id == userId),
        ),
        getMatcherForUserMention(
          context: context,
          getUserMention: (userId) => message.taggedUsers?.firstWhereOrNull((e) => e.id == userId),
        ),
        getMatcherForHashTagMention(
          context: context,
          getHashTag: (id) => message.taggedTopics?.firstWhereOrNull((e) => e.id == id),
        ),
        getMatcherForCompanyMention(
          context: context,
          getCompany: (companyId) => message.taggedCompanies?.firstWhereOrNull((e) => e.id == companyId),
        ),
        getMatcherForInstrumentMention(
          context: context,
          getInstrument: (instrumentId) => message.taggedInstruments?.firstWhereOrNull((e) => e.id == instrumentId),
        ),
        getMatcherForUrl(context: context),
      ],
    );
  }
}

class _SearchedReciepientsList extends StatelessWidget {
  const _SearchedReciepientsList({
    Key? key,
    required this.onRecipientSelected,
  }) : super(key: key);

  final ValueChanged<User> onRecipientSelected;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SearchFriendsCubit, SearchFriendsState>(
      builder: (context, state) {
        if (state.friends.isNotEmpty) {
          return ListView.separated(
            itemBuilder: (context, index) {
              final recipient = state.friends[index];
              return _RecipientTile(
                user: recipient,
                onTap: () => onRecipientSelected(recipient),
              );
            },
            separatorBuilder: (context, index) => Container(
              height: 0.5,
              color: context.appTheme.borderColor,
            ),
            itemCount: state.friends.length,
          );
        } else if (state.isSearching) {
          return Center(
            child: MPLoadingIndicator(),
          );
        } else {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                'No friends found!',
                style: mpHeadLine4(context: context),
              ),
            ),
          );
        }
      },
    );
  }
}

class _RecipientTile extends StatelessWidget {
  const _RecipientTile({
    Key? key,
    required this.user,
    required this.onTap,
  }) : super(key: key);

  final User user;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 8,
          horizontal: 12,
        ),
        child: Row(
          children: [
            _RecipientAvatarWidget(user: user),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: RichText(
                          text: TextSpan(
                            text: user.displayname,
                            style: mpHeadLine5(
                              context: context,
                              textColor: context.appTheme.primaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                            children: [
                              TextSpan(
                                text: ' @${user.username}',
                                style: mpHeadLine5(
                                  context: context,
                                  textColor: context.appTheme.secondaryTextColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RecipientAvatarWidget extends StatelessWidget {
  const _RecipientAvatarWidget({
    Key? key,
    required this.user,
  }) : super(key: key);

  final User user;

  final double _size = 46;

  @override
  Widget build(BuildContext context) {
    final url = user.dpUrl;
    final firstLetter = user.displayname.characters.firstOrNull;
    if (url.isNotEmpty) {
      return SizedBox(
        height: _size,
        width: _size,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(_size / 2),
          child: CachedNetworkImage(
            imageUrl: url,
            fit: BoxFit.cover,
          ),
        ),
      );
    } else {
      return Container(
        height: _size,
        width: _size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: context.appTheme.primaryColor.withOpacity(0.3),
          shape: BoxShape.circle,
        ),
        child: Text(
          firstLetter?.toUpperCase() ?? '',
          style: mpHeadLine3(
            context: context,
            textColor: context.appTheme.primaryColor,
            fontWeight: FontWeight.normal,
          ),
        ),
      );
    }
  }
}

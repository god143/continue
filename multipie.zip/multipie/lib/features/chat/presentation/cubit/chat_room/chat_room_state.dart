part of 'chat_room_cubit.dart';

@freezed
class ChatRoomState with _$ChatRoomState {
  factory ChatRoomState({
    required ChatRoom room,
    @Default(false) bool isLoadingMessages,
    @Default(false) bool isSendingMessage,
    @Default([]) List<ChatMessage> messages,
  }) = _ChatRoomState;
}

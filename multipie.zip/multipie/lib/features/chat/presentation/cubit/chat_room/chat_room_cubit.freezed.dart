// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'chat_room_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ChatRoomState {
  ChatRoom get room => throw _privateConstructorUsedError;
  bool get isLoadingMessages => throw _privateConstructorUsedError;
  bool get isSendingMessage => throw _privateConstructorUsedError;
  List<ChatMessage> get messages => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ChatRoomStateCopyWith<ChatRoomState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatRoomStateCopyWith<$Res> {
  factory $ChatRoomStateCopyWith(
          ChatRoomState value, $Res Function(ChatRoomState) then) =
      _$ChatRoomStateCopyWithImpl<$Res>;
  $Res call(
      {ChatRoom room,
      bool isLoadingMessages,
      bool isSendingMessage,
      List<ChatMessage> messages});

  $ChatRoomCopyWith<$Res> get room;
}

/// @nodoc
class _$ChatRoomStateCopyWithImpl<$Res>
    implements $ChatRoomStateCopyWith<$Res> {
  _$ChatRoomStateCopyWithImpl(this._value, this._then);

  final ChatRoomState _value;
  // ignore: unused_field
  final $Res Function(ChatRoomState) _then;

  @override
  $Res call({
    Object? room = freezed,
    Object? isLoadingMessages = freezed,
    Object? isSendingMessage = freezed,
    Object? messages = freezed,
  }) {
    return _then(_value.copyWith(
      room: room == freezed
          ? _value.room
          : room // ignore: cast_nullable_to_non_nullable
              as ChatRoom,
      isLoadingMessages: isLoadingMessages == freezed
          ? _value.isLoadingMessages
          : isLoadingMessages // ignore: cast_nullable_to_non_nullable
              as bool,
      isSendingMessage: isSendingMessage == freezed
          ? _value.isSendingMessage
          : isSendingMessage // ignore: cast_nullable_to_non_nullable
              as bool,
      messages: messages == freezed
          ? _value.messages
          : messages // ignore: cast_nullable_to_non_nullable
              as List<ChatMessage>,
    ));
  }

  @override
  $ChatRoomCopyWith<$Res> get room {
    return $ChatRoomCopyWith<$Res>(_value.room, (value) {
      return _then(_value.copyWith(room: value));
    });
  }
}

/// @nodoc
abstract class _$$_ChatRoomStateCopyWith<$Res>
    implements $ChatRoomStateCopyWith<$Res> {
  factory _$$_ChatRoomStateCopyWith(
          _$_ChatRoomState value, $Res Function(_$_ChatRoomState) then) =
      __$$_ChatRoomStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {ChatRoom room,
      bool isLoadingMessages,
      bool isSendingMessage,
      List<ChatMessage> messages});

  @override
  $ChatRoomCopyWith<$Res> get room;
}

/// @nodoc
class __$$_ChatRoomStateCopyWithImpl<$Res>
    extends _$ChatRoomStateCopyWithImpl<$Res>
    implements _$$_ChatRoomStateCopyWith<$Res> {
  __$$_ChatRoomStateCopyWithImpl(
      _$_ChatRoomState _value, $Res Function(_$_ChatRoomState) _then)
      : super(_value, (v) => _then(v as _$_ChatRoomState));

  @override
  _$_ChatRoomState get _value => super._value as _$_ChatRoomState;

  @override
  $Res call({
    Object? room = freezed,
    Object? isLoadingMessages = freezed,
    Object? isSendingMessage = freezed,
    Object? messages = freezed,
  }) {
    return _then(_$_ChatRoomState(
      room: room == freezed
          ? _value.room
          : room // ignore: cast_nullable_to_non_nullable
              as ChatRoom,
      isLoadingMessages: isLoadingMessages == freezed
          ? _value.isLoadingMessages
          : isLoadingMessages // ignore: cast_nullable_to_non_nullable
              as bool,
      isSendingMessage: isSendingMessage == freezed
          ? _value.isSendingMessage
          : isSendingMessage // ignore: cast_nullable_to_non_nullable
              as bool,
      messages: messages == freezed
          ? _value._messages
          : messages // ignore: cast_nullable_to_non_nullable
              as List<ChatMessage>,
    ));
  }
}

/// @nodoc

class _$_ChatRoomState with DiagnosticableTreeMixin implements _ChatRoomState {
  _$_ChatRoomState(
      {required this.room,
      this.isLoadingMessages = false,
      this.isSendingMessage = false,
      final List<ChatMessage> messages = const []})
      : _messages = messages;

  @override
  final ChatRoom room;
  @override
  @JsonKey()
  final bool isLoadingMessages;
  @override
  @JsonKey()
  final bool isSendingMessage;
  final List<ChatMessage> _messages;
  @override
  @JsonKey()
  List<ChatMessage> get messages {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_messages);
  }

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ChatRoomState(room: $room, isLoadingMessages: $isLoadingMessages, isSendingMessage: $isSendingMessage, messages: $messages)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ChatRoomState'))
      ..add(DiagnosticsProperty('room', room))
      ..add(DiagnosticsProperty('isLoadingMessages', isLoadingMessages))
      ..add(DiagnosticsProperty('isSendingMessage', isSendingMessage))
      ..add(DiagnosticsProperty('messages', messages));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatRoomState &&
            const DeepCollectionEquality().equals(other.room, room) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingMessages, isLoadingMessages) &&
            const DeepCollectionEquality()
                .equals(other.isSendingMessage, isSendingMessage) &&
            const DeepCollectionEquality().equals(other._messages, _messages));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(room),
      const DeepCollectionEquality().hash(isLoadingMessages),
      const DeepCollectionEquality().hash(isSendingMessage),
      const DeepCollectionEquality().hash(_messages));

  @JsonKey(ignore: true)
  @override
  _$$_ChatRoomStateCopyWith<_$_ChatRoomState> get copyWith =>
      __$$_ChatRoomStateCopyWithImpl<_$_ChatRoomState>(this, _$identity);
}

abstract class _ChatRoomState implements ChatRoomState {
  factory _ChatRoomState(
      {required final ChatRoom room,
      final bool isLoadingMessages,
      final bool isSendingMessage,
      final List<ChatMessage> messages}) = _$_ChatRoomState;

  @override
  ChatRoom get room => throw _privateConstructorUsedError;
  @override
  bool get isLoadingMessages => throw _privateConstructorUsedError;
  @override
  bool get isSendingMessage => throw _privateConstructorUsedError;
  @override
  List<ChatMessage> get messages => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ChatRoomStateCopyWith<_$_ChatRoomState> get copyWith =>
      throw _privateConstructorUsedError;
}

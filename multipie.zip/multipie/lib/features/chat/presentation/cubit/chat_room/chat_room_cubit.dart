import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/domain/usecases/get_chat_messages_usecase.dart';
import 'package:multipie/features/chat/domain/usecases/send_chat_message_usecase.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/services/socket_service.dart';

part 'chat_room_cubit.freezed.dart';
part 'chat_room_state.dart';

class ChatRoomCubit extends Cubit<ChatRoomState> {
  ChatRoomCubit({
    required ChatRoom room,
    required this.chatRoomsCubit,
    required this.getChatMessagesUsecase,
    required this.sendChatMessageUsecase,
    required this.socketService,
  }) : super(ChatRoomState(room: room)) {
    socketService.addlistener(_socketChannelMessage, _onSocketMessage);
  }

  final ChatRoomsCubit chatRoomsCubit;
  final GetChatMessagesUsecase getChatMessagesUsecase;
  final SendChatMessageUsecase sendChatMessageUsecase;
  final SocketService socketService;
  static const _socketChannelMessage = 'message';

  static final _initialPage = 1;
  int _page = _initialPage;
  final int _itemsPerPage = 25;
  ValueChanged<String>? onFetchFailed;
  ValueChanged<String>? onSendMessageFailed;

  bool _reportedLastReadMessageFirstTime = false;

  Future<void> refresh() async {
    _page = _initialPage;
    await _fetchMessages();
  }

  Future<void> fetchMore() async {
    if (state.isLoadingMessages) {
      return;
    }
    _page += 1;
    await _fetchMessages();
  }

  Future<void> _fetchMessages() async {
    emit(state.copyWith(isLoadingMessages: true));
    final result = await getChatMessagesUsecase.call(
      Params(
        chatRoomId: state.room.id,
        pageSize: _itemsPerPage,
        pageNumber: _page,
      ),
    );
    result.fold(
      (failure) {
        onFetchFailed?.call(failure.message);
        emit(state.copyWith(isLoadingMessages: false));
      },
      (fetchedMessages) {
        final List<ChatMessage> messages;
        if (_page == _initialPage) {
          messages = fetchedMessages;
        } else {
          messages = [];
          messages.addAll([...state.messages, ...fetchedMessages]);
        }
        emit(
          state.copyWith(
            isLoadingMessages: false,
            messages: messages,
          ),
        );
        if (!_reportedLastReadMessageFirstTime) {
          _reportedLastReadMessageFirstTime = true;
          onLastMessageVisible();
        }
      },
    );
  }

  Future<bool> sendMessage({
    required String text,
    File? attachment,
    String? mediaUrl,
  }) async {
    emit(state.copyWith(isSendingMessage: true));
    final result = await sendChatMessageUsecase.call(
      SendChatMessageUsecaseParams(
        chatRoomId: state.room.id,
        text: text,
        attachment: attachment,
        mediaUrl: mediaUrl,
      ),
    );
    return result.fold(
      (failure) {
        onSendMessageFailed?.call(failure.message);
        emit(state.copyWith(isSendingMessage: false));
        return false;
      },
      (message) {
        if (message != null) {
          emit(
            state.copyWith(
              messages: [message, ...state.messages],
              isSendingMessage: false,
            ),
          );
          chatRoomsCubit.refresh();
        } else {
          emit(state.copyWith(isSendingMessage: false));
        }
        return true;
      },
    );
  }

  void _onSocketMessage(dynamic json) {
    try {
      ChatMessage message = ChatMessage.fromSocketJson(json);
      final roomUser = state.room.users.firstWhereOrNull((e) => e.id == '${message.fromId}');
      if (roomUser != null) {
        message = message.copyWith(user: roomUser);
      }
      if (message.chatRoomId?.toString() == state.room.id) {
        emit(
          state.copyWith(
            messages: [message, ...state.messages],
          ),
        );
      }
    } catch (ex) {
      debugPrint(ex.toString());
    }
  }

  Future<void> onLastMessageVisible() async {
    try {
      final message = state.messages.firstOrNull;
      if (message != null) {
        await socketService.emitData('lastReadMessage', message.id, state.room.id);
        chatRoomsCubit.onLastMessageReadForRoom(state.room.id);
      }
    } catch (ex) {
      debugPrint(ex.toString());
    }
  }

  void updateChatRoom(ChatRoom chatRoom) {
    emit(state.copyWith(room: chatRoom));
  }

  void dispose() {
    socketService.removelistener(_socketChannelMessage, _onSocketMessage);
  }
}

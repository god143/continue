import 'dart:async';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:collection/collection.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/data/models/chat_room_member.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/features/chat/presentation/cubit/new_chat_group_members/cubit/new_chat_group_members_cubit.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

part 'chat_group_editor_cubit.freezed.dart';
part 'chat_group_editor_state.dart';

class ChatGroupEditorCubit extends Cubit<ChatGroupEditorState> {
  ChatGroupEditorCubit({
    required ChatRoom chatRoom,
    required this.currentUserId,
    required this.chatRepository,
    required this.onChatRoomUpdated,
    required this.chatRoomsCubit,
    required this.searchMembersCubit,
  }) : super(ChatGroupEditorState(room: chatRoom)) {
    _searchStateStreamSubscription = searchMembersCubit.stream.listen(
      (searchState) {
        final isSearchActive = searchState.searchPhrase.trim().isNotEmpty;
        emit(
          state.copyWith(
            isSearchActive: isSearchActive,
            searchedMembers: isSearchActive ? searchState.members : [],
          ),
        );
      },
    );
  }

  final String currentUserId;
  final ChatRepository chatRepository;
  final ValueChanged<ChatRoom> onChatRoomUpdated;
  final ChatRoomsCubit chatRoomsCubit;
  final NewChatGroupMembersCubit searchMembersCubit;
  StreamSubscription? _searchStateStreamSubscription;

  List<ChatRoomMember> get sortedGroupMembers {
    return state.room.chatRoomMembers.sorted((a, b) => b.isAdmin ? 1 : -1);
  }

  bool get isGroupEditable =>
      state.room.groupChat &&
      state.room.chatRoomMembers.where((e) => currentUserId == e.userId.toString() && e.isAdmin).isNotEmpty;

  User? getUserForUserId(String id) {
    return state.room.users.firstWhereOrNull((e) => e.id == id);
  }

  ChatRoomMember? _getMemberForUserId(String id) {
    return state.room.chatRoomMembers.firstWhereOrNull((element) => element.userId.toString() == id);
  }

  bool isUserGroupAdmin(String userId) {
    return _getMemberForUserId(userId)?.isAdmin ?? false;
  }

  bool isGroupMember(String userId) {
    return _getMemberForUserId(userId) != null;
  }

  String? get nameError {
    if (state.nameChanges != null && state.nameChanges!.trim().isEmpty) {
      return 'Required!';
    } else {
      return null;
    }
  }

  bool get hasPendingNameChanges => state.nameChanges != null && state.room.name != state.nameChanges;

  void onNameChanged(String name) {
    emit(state.copyWith(nameChanges: name));
  }

  Future<Either<String, bool>> updateChatGroupName() async {
    emit(state.copyWith(isSavingName: true));
    final nameToBeUpdated = state.nameChanges!;
    final result = await chatRepository.updateChatGroupName(
      groupId: state.room.id,
      name: nameToBeUpdated,
    );
    emit(state.copyWith(isSavingName: false));
    return result.fold(
      (_) => left('Could not save the name!'),
      (r) {
        emit(
          state.copyWith(
            room: state.room.copyWith(name: nameToBeUpdated),
            nameChanges: null,
          ),
        );
        _reportChatRoomUpdated(state.room);
        return right(r);
      },
    );
  }

  Future<Either<String, bool>> updateChatGroupDP(File dpFile) async {
    emit(state.copyWith(isUploadingDP: true));
    final result = await chatRepository.updateChatGroupDP(groupId: state.room.id, dpFile: dpFile);
    emit(state.copyWith(isUploadingDP: false));
    return result.fold(
      (_) => left('Could not update the picture!'),
      (attachment) {
        emit(state.copyWith.room(dpFile: attachment));
        _reportChatRoomUpdated(state.room);
        return right(true);
      },
    );
  }

  Future<Either<String, bool>> addMember(User user) async {
    final result = await chatRepository.addMember(
      groupId: state.room.id,
      userId: user.id,
    );
    return result.fold(
      (_) => left('Could not add the member!'),
      (_) {
        emit(
          state.copyWith.room(
            chatRoomMembers: [
              ...state.room.chatRoomMembers,
              ChatRoomMember(
                userId: int.parse(user.id),
                chatRoomId: int.parse(state.room.id),
                isAdmin: false,
              ),
            ],
            users: [...state.room.users, user as UserModel],
          ),
        );
        _reportChatRoomUpdated(state.room);
        return right(true);
      },
    );
  }

  Future<Either<String, bool>> removeMember(User user) async {
    final result = await chatRepository.removeMember(
      groupId: state.room.id,
      userId: user.id,
    );
    return result.fold(
      (_) => left('Could not remove the member!'),
      (_) {
        emit(
          state.copyWith.room(
            chatRoomMembers: state.room.chatRoomMembers
                .where((element) => element.userId.toString() != user.id)
                .toList(growable: false),
            users: state.room.users.where((element) => element.id != user.id).toList(growable: false),
          ),
        );
        _reportChatRoomUpdated(state.room);
        return right(true);
      },
    );
  }

  Future<Either<String, bool>> makeOrRevokeAdmin({
    required User user,
    required bool makeAdmin,
  }) async {
    final result = await chatRepository.makeOrRevokeAdmin(
      groupId: state.room.id,
      userId: user.id,
      makeAdmin: makeAdmin,
    );
    return result.fold(
      (_) => left('Could not make the admin!'),
      (_) {
        emit(
          state.copyWith.room(
            chatRoomMembers: state.room.chatRoomMembers
                .map(
                  (element) => element.userId.toString() != user.id ? element : element.copyWith(isAdmin: makeAdmin),
                )
                .toList(growable: false),
          ),
        );
        _reportChatRoomUpdated(state.room);
        return right(true);
      },
    );
  }

  void _reportChatRoomUpdated(ChatRoom updatedChatRoom) {
    onChatRoomUpdated(state.room);
    chatRoomsCubit.updateChatRoom(state.room);
  }

  void dispose() {
    _searchStateStreamSubscription?.cancel();
  }
}

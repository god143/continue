part of 'chat_group_editor_cubit.dart';

@freezed
class ChatGroupEditorState with _$ChatGroupEditorState {
  factory ChatGroupEditorState({
    required ChatRoom room,
    String? nameChanges,
    @Default(false) bool isSavingName,
    @Default(false) bool isUploadingDP,
    @Default(false) bool isSearchActive,
    @Default([]) List<User> searchedMembers,
  }) = _ChatGroupEditorState;
}

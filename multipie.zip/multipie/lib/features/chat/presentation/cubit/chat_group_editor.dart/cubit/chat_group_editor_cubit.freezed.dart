// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'chat_group_editor_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ChatGroupEditorState {
  ChatRoom get room => throw _privateConstructorUsedError;
  String? get nameChanges => throw _privateConstructorUsedError;
  bool get isSavingName => throw _privateConstructorUsedError;
  bool get isUploadingDP => throw _privateConstructorUsedError;
  bool get isSearchActive => throw _privateConstructorUsedError;
  List<User> get searchedMembers => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ChatGroupEditorStateCopyWith<ChatGroupEditorState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatGroupEditorStateCopyWith<$Res> {
  factory $ChatGroupEditorStateCopyWith(ChatGroupEditorState value,
          $Res Function(ChatGroupEditorState) then) =
      _$ChatGroupEditorStateCopyWithImpl<$Res>;
  $Res call(
      {ChatRoom room,
      String? nameChanges,
      bool isSavingName,
      bool isUploadingDP,
      bool isSearchActive,
      List<User> searchedMembers});

  $ChatRoomCopyWith<$Res> get room;
}

/// @nodoc
class _$ChatGroupEditorStateCopyWithImpl<$Res>
    implements $ChatGroupEditorStateCopyWith<$Res> {
  _$ChatGroupEditorStateCopyWithImpl(this._value, this._then);

  final ChatGroupEditorState _value;
  // ignore: unused_field
  final $Res Function(ChatGroupEditorState) _then;

  @override
  $Res call({
    Object? room = freezed,
    Object? nameChanges = freezed,
    Object? isSavingName = freezed,
    Object? isUploadingDP = freezed,
    Object? isSearchActive = freezed,
    Object? searchedMembers = freezed,
  }) {
    return _then(_value.copyWith(
      room: room == freezed
          ? _value.room
          : room // ignore: cast_nullable_to_non_nullable
              as ChatRoom,
      nameChanges: nameChanges == freezed
          ? _value.nameChanges
          : nameChanges // ignore: cast_nullable_to_non_nullable
              as String?,
      isSavingName: isSavingName == freezed
          ? _value.isSavingName
          : isSavingName // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadingDP: isUploadingDP == freezed
          ? _value.isUploadingDP
          : isUploadingDP // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearchActive: isSearchActive == freezed
          ? _value.isSearchActive
          : isSearchActive // ignore: cast_nullable_to_non_nullable
              as bool,
      searchedMembers: searchedMembers == freezed
          ? _value.searchedMembers
          : searchedMembers // ignore: cast_nullable_to_non_nullable
              as List<User>,
    ));
  }

  @override
  $ChatRoomCopyWith<$Res> get room {
    return $ChatRoomCopyWith<$Res>(_value.room, (value) {
      return _then(_value.copyWith(room: value));
    });
  }
}

/// @nodoc
abstract class _$$_ChatGroupEditorStateCopyWith<$Res>
    implements $ChatGroupEditorStateCopyWith<$Res> {
  factory _$$_ChatGroupEditorStateCopyWith(_$_ChatGroupEditorState value,
          $Res Function(_$_ChatGroupEditorState) then) =
      __$$_ChatGroupEditorStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {ChatRoom room,
      String? nameChanges,
      bool isSavingName,
      bool isUploadingDP,
      bool isSearchActive,
      List<User> searchedMembers});

  @override
  $ChatRoomCopyWith<$Res> get room;
}

/// @nodoc
class __$$_ChatGroupEditorStateCopyWithImpl<$Res>
    extends _$ChatGroupEditorStateCopyWithImpl<$Res>
    implements _$$_ChatGroupEditorStateCopyWith<$Res> {
  __$$_ChatGroupEditorStateCopyWithImpl(_$_ChatGroupEditorState _value,
      $Res Function(_$_ChatGroupEditorState) _then)
      : super(_value, (v) => _then(v as _$_ChatGroupEditorState));

  @override
  _$_ChatGroupEditorState get _value => super._value as _$_ChatGroupEditorState;

  @override
  $Res call({
    Object? room = freezed,
    Object? nameChanges = freezed,
    Object? isSavingName = freezed,
    Object? isUploadingDP = freezed,
    Object? isSearchActive = freezed,
    Object? searchedMembers = freezed,
  }) {
    return _then(_$_ChatGroupEditorState(
      room: room == freezed
          ? _value.room
          : room // ignore: cast_nullable_to_non_nullable
              as ChatRoom,
      nameChanges: nameChanges == freezed
          ? _value.nameChanges
          : nameChanges // ignore: cast_nullable_to_non_nullable
              as String?,
      isSavingName: isSavingName == freezed
          ? _value.isSavingName
          : isSavingName // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadingDP: isUploadingDP == freezed
          ? _value.isUploadingDP
          : isUploadingDP // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearchActive: isSearchActive == freezed
          ? _value.isSearchActive
          : isSearchActive // ignore: cast_nullable_to_non_nullable
              as bool,
      searchedMembers: searchedMembers == freezed
          ? _value._searchedMembers
          : searchedMembers // ignore: cast_nullable_to_non_nullable
              as List<User>,
    ));
  }
}

/// @nodoc

class _$_ChatGroupEditorState implements _ChatGroupEditorState {
  _$_ChatGroupEditorState(
      {required this.room,
      this.nameChanges,
      this.isSavingName = false,
      this.isUploadingDP = false,
      this.isSearchActive = false,
      final List<User> searchedMembers = const []})
      : _searchedMembers = searchedMembers;

  @override
  final ChatRoom room;
  @override
  final String? nameChanges;
  @override
  @JsonKey()
  final bool isSavingName;
  @override
  @JsonKey()
  final bool isUploadingDP;
  @override
  @JsonKey()
  final bool isSearchActive;
  final List<User> _searchedMembers;
  @override
  @JsonKey()
  List<User> get searchedMembers {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchedMembers);
  }

  @override
  String toString() {
    return 'ChatGroupEditorState(room: $room, nameChanges: $nameChanges, isSavingName: $isSavingName, isUploadingDP: $isUploadingDP, isSearchActive: $isSearchActive, searchedMembers: $searchedMembers)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatGroupEditorState &&
            const DeepCollectionEquality().equals(other.room, room) &&
            const DeepCollectionEquality()
                .equals(other.nameChanges, nameChanges) &&
            const DeepCollectionEquality()
                .equals(other.isSavingName, isSavingName) &&
            const DeepCollectionEquality()
                .equals(other.isUploadingDP, isUploadingDP) &&
            const DeepCollectionEquality()
                .equals(other.isSearchActive, isSearchActive) &&
            const DeepCollectionEquality()
                .equals(other._searchedMembers, _searchedMembers));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(room),
      const DeepCollectionEquality().hash(nameChanges),
      const DeepCollectionEquality().hash(isSavingName),
      const DeepCollectionEquality().hash(isUploadingDP),
      const DeepCollectionEquality().hash(isSearchActive),
      const DeepCollectionEquality().hash(_searchedMembers));

  @JsonKey(ignore: true)
  @override
  _$$_ChatGroupEditorStateCopyWith<_$_ChatGroupEditorState> get copyWith =>
      __$$_ChatGroupEditorStateCopyWithImpl<_$_ChatGroupEditorState>(
          this, _$identity);
}

abstract class _ChatGroupEditorState implements ChatGroupEditorState {
  factory _ChatGroupEditorState(
      {required final ChatRoom room,
      final String? nameChanges,
      final bool isSavingName,
      final bool isUploadingDP,
      final bool isSearchActive,
      final List<User> searchedMembers}) = _$_ChatGroupEditorState;

  @override
  ChatRoom get room => throw _privateConstructorUsedError;
  @override
  String? get nameChanges => throw _privateConstructorUsedError;
  @override
  bool get isSavingName => throw _privateConstructorUsedError;
  @override
  bool get isUploadingDP => throw _privateConstructorUsedError;
  @override
  bool get isSearchActive => throw _privateConstructorUsedError;
  @override
  List<User> get searchedMembers => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ChatGroupEditorStateCopyWith<_$_ChatGroupEditorState> get copyWith =>
      throw _privateConstructorUsedError;
}

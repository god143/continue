// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'search_friends_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$SearchFriendsState {
  List<User> get friends => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SearchFriendsStateCopyWith<SearchFriendsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SearchFriendsStateCopyWith<$Res> {
  factory $SearchFriendsStateCopyWith(
          SearchFriendsState value, $Res Function(SearchFriendsState) then) =
      _$SearchFriendsStateCopyWithImpl<$Res>;
  $Res call({List<User> friends, bool isSearching});
}

/// @nodoc
class _$SearchFriendsStateCopyWithImpl<$Res>
    implements $SearchFriendsStateCopyWith<$Res> {
  _$SearchFriendsStateCopyWithImpl(this._value, this._then);

  final SearchFriendsState _value;
  // ignore: unused_field
  final $Res Function(SearchFriendsState) _then;

  @override
  $Res call({
    Object? friends = freezed,
    Object? isSearching = freezed,
  }) {
    return _then(_value.copyWith(
      friends: friends == freezed
          ? _value.friends
          : friends // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isSearching: isSearching == freezed
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
abstract class _$$_SearchFriendsStateCopyWith<$Res>
    implements $SearchFriendsStateCopyWith<$Res> {
  factory _$$_SearchFriendsStateCopyWith(_$_SearchFriendsState value,
          $Res Function(_$_SearchFriendsState) then) =
      __$$_SearchFriendsStateCopyWithImpl<$Res>;
  @override
  $Res call({List<User> friends, bool isSearching});
}

/// @nodoc
class __$$_SearchFriendsStateCopyWithImpl<$Res>
    extends _$SearchFriendsStateCopyWithImpl<$Res>
    implements _$$_SearchFriendsStateCopyWith<$Res> {
  __$$_SearchFriendsStateCopyWithImpl(
      _$_SearchFriendsState _value, $Res Function(_$_SearchFriendsState) _then)
      : super(_value, (v) => _then(v as _$_SearchFriendsState));

  @override
  _$_SearchFriendsState get _value => super._value as _$_SearchFriendsState;

  @override
  $Res call({
    Object? friends = freezed,
    Object? isSearching = freezed,
  }) {
    return _then(_$_SearchFriendsState(
      friends: friends == freezed
          ? _value._friends
          : friends // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isSearching: isSearching == freezed
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$_SearchFriendsState
    with DiagnosticableTreeMixin
    implements _SearchFriendsState {
  _$_SearchFriendsState(
      {final List<User> friends = const [], this.isSearching = false})
      : _friends = friends;

  final List<User> _friends;
  @override
  @JsonKey()
  List<User> get friends {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_friends);
  }

  @override
  @JsonKey()
  final bool isSearching;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'SearchFriendsState(friends: $friends, isSearching: $isSearching)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'SearchFriendsState'))
      ..add(DiagnosticsProperty('friends', friends))
      ..add(DiagnosticsProperty('isSearching', isSearching));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_SearchFriendsState &&
            const DeepCollectionEquality().equals(other._friends, _friends) &&
            const DeepCollectionEquality()
                .equals(other.isSearching, isSearching));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_friends),
      const DeepCollectionEquality().hash(isSearching));

  @JsonKey(ignore: true)
  @override
  _$$_SearchFriendsStateCopyWith<_$_SearchFriendsState> get copyWith =>
      __$$_SearchFriendsStateCopyWithImpl<_$_SearchFriendsState>(
          this, _$identity);
}

abstract class _SearchFriendsState implements SearchFriendsState {
  factory _SearchFriendsState(
      {final List<User> friends,
      final bool isSearching}) = _$_SearchFriendsState;

  @override
  List<User> get friends => throw _privateConstructorUsedError;
  @override
  bool get isSearching => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_SearchFriendsStateCopyWith<_$_SearchFriendsState> get copyWith =>
      throw _privateConstructorUsedError;
}

part of 'search_friends_cubit.dart';

@freezed
class SearchFriendsState with _$SearchFriendsState {
  factory SearchFriendsState({
    @Default([]) List<User> friends,
    @Default(false) bool isSearching,
  }) = _SearchFriendsState;
}

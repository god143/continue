import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/find_friends/domain/usecases/get_friends_usecase.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

part 'search_friends_cubit.freezed.dart';
part 'search_friends_state.dart';

class SearchFriendsCubit extends Cubit<SearchFriendsState> {
  SearchFriendsCubit({
    required this.getFriendsUsecase,
  }) : super(SearchFriendsState());

  final GetFriendsUsecase getFriendsUsecase;

  static final _initialPage = 1;
  final int _itemsPerPage = 25;
  ValueChanged<String>? onFetchFailed;

  Timer? _debounce;

  Future<void> search(String phrase) async {
    if (_debounce?.isActive ?? false) {
      _debounce?.cancel();
    }
    _debounce = Timer(
      const Duration(milliseconds: 300),
      () async {
        emit(state.copyWith(isSearching: true));
        final result = await getFriendsUsecase.call(
          GetFriendsUsecaseParams(
            searchPhrase: phrase,
            size: _itemsPerPage,
            page: _initialPage,
          ),
        );
        result.fold(
          (failure) {
            onFetchFailed?.call(failure.message);
            emit(state.copyWith(isSearching: false));
          },
          (friends) {
            emit(
              state.copyWith(
                isSearching: false,
                friends: friends,
              ),
            );
          },
        );
      },
    );
  }

  void dispose() {
    _debounce?.cancel();
  }
}

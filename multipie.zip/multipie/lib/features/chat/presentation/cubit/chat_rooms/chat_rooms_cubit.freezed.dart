// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'chat_rooms_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ChatRoomsState {
  List<ChatRoom> get rooms => throw _privateConstructorUsedError;
  bool get isLoadingRooms => throw _privateConstructorUsedError;
  int get unreadMessagesCount => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ChatRoomsStateCopyWith<ChatRoomsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatRoomsStateCopyWith<$Res> {
  factory $ChatRoomsStateCopyWith(
          ChatRoomsState value, $Res Function(ChatRoomsState) then) =
      _$ChatRoomsStateCopyWithImpl<$Res>;
  $Res call(
      {List<ChatRoom> rooms, bool isLoadingRooms, int unreadMessagesCount});
}

/// @nodoc
class _$ChatRoomsStateCopyWithImpl<$Res>
    implements $ChatRoomsStateCopyWith<$Res> {
  _$ChatRoomsStateCopyWithImpl(this._value, this._then);

  final ChatRoomsState _value;
  // ignore: unused_field
  final $Res Function(ChatRoomsState) _then;

  @override
  $Res call({
    Object? rooms = freezed,
    Object? isLoadingRooms = freezed,
    Object? unreadMessagesCount = freezed,
  }) {
    return _then(_value.copyWith(
      rooms: rooms == freezed
          ? _value.rooms
          : rooms // ignore: cast_nullable_to_non_nullable
              as List<ChatRoom>,
      isLoadingRooms: isLoadingRooms == freezed
          ? _value.isLoadingRooms
          : isLoadingRooms // ignore: cast_nullable_to_non_nullable
              as bool,
      unreadMessagesCount: unreadMessagesCount == freezed
          ? _value.unreadMessagesCount
          : unreadMessagesCount // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
abstract class _$$_ChatRoomsStateCopyWith<$Res>
    implements $ChatRoomsStateCopyWith<$Res> {
  factory _$$_ChatRoomsStateCopyWith(
          _$_ChatRoomsState value, $Res Function(_$_ChatRoomsState) then) =
      __$$_ChatRoomsStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {List<ChatRoom> rooms, bool isLoadingRooms, int unreadMessagesCount});
}

/// @nodoc
class __$$_ChatRoomsStateCopyWithImpl<$Res>
    extends _$ChatRoomsStateCopyWithImpl<$Res>
    implements _$$_ChatRoomsStateCopyWith<$Res> {
  __$$_ChatRoomsStateCopyWithImpl(
      _$_ChatRoomsState _value, $Res Function(_$_ChatRoomsState) _then)
      : super(_value, (v) => _then(v as _$_ChatRoomsState));

  @override
  _$_ChatRoomsState get _value => super._value as _$_ChatRoomsState;

  @override
  $Res call({
    Object? rooms = freezed,
    Object? isLoadingRooms = freezed,
    Object? unreadMessagesCount = freezed,
  }) {
    return _then(_$_ChatRoomsState(
      rooms: rooms == freezed
          ? _value._rooms
          : rooms // ignore: cast_nullable_to_non_nullable
              as List<ChatRoom>,
      isLoadingRooms: isLoadingRooms == freezed
          ? _value.isLoadingRooms
          : isLoadingRooms // ignore: cast_nullable_to_non_nullable
              as bool,
      unreadMessagesCount: unreadMessagesCount == freezed
          ? _value.unreadMessagesCount
          : unreadMessagesCount // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_ChatRoomsState implements _ChatRoomsState {
  _$_ChatRoomsState(
      {final List<ChatRoom> rooms = const [],
      this.isLoadingRooms = false,
      this.unreadMessagesCount = 0})
      : _rooms = rooms;

  final List<ChatRoom> _rooms;
  @override
  @JsonKey()
  List<ChatRoom> get rooms {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_rooms);
  }

  @override
  @JsonKey()
  final bool isLoadingRooms;
  @override
  @JsonKey()
  final int unreadMessagesCount;

  @override
  String toString() {
    return 'ChatRoomsState(rooms: $rooms, isLoadingRooms: $isLoadingRooms, unreadMessagesCount: $unreadMessagesCount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatRoomsState &&
            const DeepCollectionEquality().equals(other._rooms, _rooms) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingRooms, isLoadingRooms) &&
            const DeepCollectionEquality()
                .equals(other.unreadMessagesCount, unreadMessagesCount));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_rooms),
      const DeepCollectionEquality().hash(isLoadingRooms),
      const DeepCollectionEquality().hash(unreadMessagesCount));

  @JsonKey(ignore: true)
  @override
  _$$_ChatRoomsStateCopyWith<_$_ChatRoomsState> get copyWith =>
      __$$_ChatRoomsStateCopyWithImpl<_$_ChatRoomsState>(this, _$identity);
}

abstract class _ChatRoomsState implements ChatRoomsState {
  factory _ChatRoomsState(
      {final List<ChatRoom> rooms,
      final bool isLoadingRooms,
      final int unreadMessagesCount}) = _$_ChatRoomsState;

  @override
  List<ChatRoom> get rooms => throw _privateConstructorUsedError;
  @override
  bool get isLoadingRooms => throw _privateConstructorUsedError;
  @override
  int get unreadMessagesCount => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ChatRoomsStateCopyWith<_$_ChatRoomsState> get copyWith =>
      throw _privateConstructorUsedError;
}

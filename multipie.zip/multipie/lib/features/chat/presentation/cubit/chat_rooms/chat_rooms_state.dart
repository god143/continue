part of 'chat_rooms_cubit.dart';

@freezed
class ChatRoomsState with _$ChatRoomsState {
  factory ChatRoomsState({
    @Default([]) List<ChatRoom> rooms,
    @Default(false) bool isLoadingRooms,
    @Default(0) int unreadMessagesCount,
  }) = _ChatRoomsState;
}

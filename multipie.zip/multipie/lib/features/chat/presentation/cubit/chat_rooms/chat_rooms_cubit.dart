import 'package:bloc/bloc.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/domain/usecases/create_chat_room_usecase.dart';
import 'package:multipie/features/chat/domain/usecases/get_chat_rooms_usecase.dart';
import 'package:multipie/features/chat/domain/usecases/get_unread_messages_count_usecase.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/services/socket_service.dart';

part 'chat_rooms_cubit.freezed.dart';
part 'chat_rooms_state.dart';

class ChatRoomsCubit extends Cubit<ChatRoomsState> {
  ChatRoomsCubit({
    required this.socketService,
    required this.getChatRoomsUsecase,
    required this.getUnreadMessagesCountUsecase,
    required this.createChatRoomUsecase,
  }) : super(ChatRoomsState()) {
    socketService.addlistener('message', _onSocketMessage);
    socketService.addlistener('chatRoomCreated', _onSocketNewRoomCreated);
  }

  final SocketService socketService;
  final GetChatRoomsUsecase getChatRoomsUsecase;
  final GetUnreadMessagesCountUsecase getUnreadMessagesCountUsecase;
  final CreateChatRoomUsecase createChatRoomUsecase;

  static final _initialPage = 1;
  int _page = _initialPage;
  final int _itemsPerPage = 25;
  ValueChanged<String>? onFetchFailed;

  /// Fetches Rooms from initial page
  Future<void> refresh() async {
    _page = _initialPage;
    await Future.wait([
      _fetchChatRooms(),
      _fetchUnreadMessagesCount(),
    ]);
  }

  /// Fetches next page Rooms
  Future<void> fetchMore() async {
    if (state.isLoadingRooms) {
      return;
    }
    _page += 1;
    await _fetchChatRooms();
  }

  Future<void> _fetchUnreadMessagesCount() async {
    final result = await getUnreadMessagesCountUsecase.call(NoParams());
    result.fold(
      (failure) => null,
      (count) => emit(state.copyWith(unreadMessagesCount: count)),
    );
  }

  Future<void> _fetchChatRooms() async {
    emit(state.copyWith(isLoadingRooms: true));
    final result = await getChatRoomsUsecase.call(Params(pageSize: _itemsPerPage, pageNumber: _page));
    result.fold(
      (failure) {
        onFetchFailed?.call(failure.message);
        emit(state.copyWith(isLoadingRooms: false));
      },
      (fetchedRooms) {
        final List<ChatRoom> rooms;
        if (_page == _initialPage) {
          rooms = fetchedRooms;
        } else {
          rooms = [];
          final sortedAllRooms = _sortedRooms([...state.rooms, ...fetchedRooms]);
          final Set<String> addedItems = {};
          for (final room in sortedAllRooms) {
            if (!addedItems.contains(room.id)) {
              rooms.add(room);
              addedItems.add(room.id);
            }
          }
        }
        emit(
          state.copyWith(
            isLoadingRooms: false,
            rooms: rooms,
          ),
        );
      },
    );
  }

  Future<ChatRoom?> createChatRoom({required User recipient}) async {
    final result = await createChatRoomUsecase.call(
      CreateChatRoomUsecaseParams(recipientId: recipient.id),
    );
    return result.fold(
      (failure) => null,
      (room) => room,
    );
  }

  List<ChatRoom> _sortedRooms(List<ChatRoom> rooms) => rooms.sorted((l, r) => r.updatedAt.compareTo(l.updatedAt));

  void _onSocketMessage(dynamic json) => refresh();

  void _onSocketNewRoomCreated(dynamic json) => refresh();

  void onLastMessageReadForRoom(String roomId) {
    final rooms = state.rooms
        .map(
          (e) => e.id == roomId ? e.copyWith(unreadMessageCount: 0) : e,
        )
        .toList(growable: false);
    emit(state.copyWith(rooms: rooms));
    _fetchUnreadMessagesCount();
  }

  void updateChatRoom(ChatRoom room) {
    emit(
      state.copyWith(
        rooms: state.rooms.map<ChatRoom>((e) => e.id == room.id ? room : e).toList(),
      ),
    );
  }
}

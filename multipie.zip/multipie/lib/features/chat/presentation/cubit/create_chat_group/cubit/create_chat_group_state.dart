part of 'create_chat_group_cubit.dart';

@freezed
class CreateChatGroupState with _$CreateChatGroupState {
  factory CreateChatGroupState({
    @Default('') String groupName,
    @Default(false) bool isCreating,
    required List<User> members,
  }) = _CreateChatGroupState;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'create_chat_group_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CreateChatGroupState {
  String get groupName => throw _privateConstructorUsedError;
  bool get isCreating => throw _privateConstructorUsedError;
  List<User> get members => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CreateChatGroupStateCopyWith<CreateChatGroupState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CreateChatGroupStateCopyWith<$Res> {
  factory $CreateChatGroupStateCopyWith(CreateChatGroupState value,
          $Res Function(CreateChatGroupState) then) =
      _$CreateChatGroupStateCopyWithImpl<$Res>;
  $Res call({String groupName, bool isCreating, List<User> members});
}

/// @nodoc
class _$CreateChatGroupStateCopyWithImpl<$Res>
    implements $CreateChatGroupStateCopyWith<$Res> {
  _$CreateChatGroupStateCopyWithImpl(this._value, this._then);

  final CreateChatGroupState _value;
  // ignore: unused_field
  final $Res Function(CreateChatGroupState) _then;

  @override
  $Res call({
    Object? groupName = freezed,
    Object? isCreating = freezed,
    Object? members = freezed,
  }) {
    return _then(_value.copyWith(
      groupName: groupName == freezed
          ? _value.groupName
          : groupName // ignore: cast_nullable_to_non_nullable
              as String,
      isCreating: isCreating == freezed
          ? _value.isCreating
          : isCreating // ignore: cast_nullable_to_non_nullable
              as bool,
      members: members == freezed
          ? _value.members
          : members // ignore: cast_nullable_to_non_nullable
              as List<User>,
    ));
  }
}

/// @nodoc
abstract class _$$_CreateChatGroupStateCopyWith<$Res>
    implements $CreateChatGroupStateCopyWith<$Res> {
  factory _$$_CreateChatGroupStateCopyWith(_$_CreateChatGroupState value,
          $Res Function(_$_CreateChatGroupState) then) =
      __$$_CreateChatGroupStateCopyWithImpl<$Res>;
  @override
  $Res call({String groupName, bool isCreating, List<User> members});
}

/// @nodoc
class __$$_CreateChatGroupStateCopyWithImpl<$Res>
    extends _$CreateChatGroupStateCopyWithImpl<$Res>
    implements _$$_CreateChatGroupStateCopyWith<$Res> {
  __$$_CreateChatGroupStateCopyWithImpl(_$_CreateChatGroupState _value,
      $Res Function(_$_CreateChatGroupState) _then)
      : super(_value, (v) => _then(v as _$_CreateChatGroupState));

  @override
  _$_CreateChatGroupState get _value => super._value as _$_CreateChatGroupState;

  @override
  $Res call({
    Object? groupName = freezed,
    Object? isCreating = freezed,
    Object? members = freezed,
  }) {
    return _then(_$_CreateChatGroupState(
      groupName: groupName == freezed
          ? _value.groupName
          : groupName // ignore: cast_nullable_to_non_nullable
              as String,
      isCreating: isCreating == freezed
          ? _value.isCreating
          : isCreating // ignore: cast_nullable_to_non_nullable
              as bool,
      members: members == freezed
          ? _value._members
          : members // ignore: cast_nullable_to_non_nullable
              as List<User>,
    ));
  }
}

/// @nodoc

class _$_CreateChatGroupState implements _CreateChatGroupState {
  _$_CreateChatGroupState(
      {this.groupName = '',
      this.isCreating = false,
      required final List<User> members})
      : _members = members;

  @override
  @JsonKey()
  final String groupName;
  @override
  @JsonKey()
  final bool isCreating;
  final List<User> _members;
  @override
  List<User> get members {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_members);
  }

  @override
  String toString() {
    return 'CreateChatGroupState(groupName: $groupName, isCreating: $isCreating, members: $members)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CreateChatGroupState &&
            const DeepCollectionEquality().equals(other.groupName, groupName) &&
            const DeepCollectionEquality()
                .equals(other.isCreating, isCreating) &&
            const DeepCollectionEquality().equals(other._members, _members));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(groupName),
      const DeepCollectionEquality().hash(isCreating),
      const DeepCollectionEquality().hash(_members));

  @JsonKey(ignore: true)
  @override
  _$$_CreateChatGroupStateCopyWith<_$_CreateChatGroupState> get copyWith =>
      __$$_CreateChatGroupStateCopyWithImpl<_$_CreateChatGroupState>(
          this, _$identity);
}

abstract class _CreateChatGroupState implements CreateChatGroupState {
  factory _CreateChatGroupState(
      {final String groupName,
      final bool isCreating,
      required final List<User> members}) = _$_CreateChatGroupState;

  @override
  String get groupName => throw _privateConstructorUsedError;
  @override
  bool get isCreating => throw _privateConstructorUsedError;
  @override
  List<User> get members => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_CreateChatGroupStateCopyWith<_$_CreateChatGroupState> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

part 'create_chat_group_cubit.freezed.dart';
part 'create_chat_group_state.dart';

class CreateChatGroupCubit extends Cubit<CreateChatGroupState> {
  CreateChatGroupCubit({
    required List<User> members,
    required this.chatRepository,
  }) : super(CreateChatGroupState(members: members));

  final ChatRepository chatRepository;

  String? get nameError {
    if (state.groupName.trim().isEmpty) {
      return 'Required!';
    } else {
      return null;
    }
  }

  bool get isFormValid => [nameError].map((e) => e == null).reduce((value, element) => value && element);

  Future<Either<String, ChatRoom>> createGroup() async {
    emit(state.copyWith(isCreating: true));
    final result = await chatRepository.createChatGroup(
      name: state.groupName,
      memberIds: state.members.map((e) => e.id).toList(growable: false),
    );
    emit(state.copyWith(isCreating: false));
    return result.fold(
      (_) => left('Could not create Chat Group!'),
      (r) => right(r),
    );
  }

  void onNameChanged(String name) {
    emit(state.copyWith(groupName: name));
  }
}

import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/find_friends/domain/usecases/get_friends_usecase.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

part 'new_chat_group_members_cubit.freezed.dart';
part 'new_chat_group_members_state.dart';

class NewChatGroupMembersCubit extends Cubit<NewChatGroupMembersState> {
  NewChatGroupMembersCubit({
    required this.getFriendsUsecase,
  }) : super(NewChatGroupMembersState());

  final GetFriendsUsecase getFriendsUsecase;

  static final _initialPage = 1;
  final int _itemsPerPage = 25;
  int _page = _initialPage;
  ValueChanged<String>? onFetchFailed;

  Timer? _debounce;

  Set<String> get selectedMemberIds => state.selectedMembers.map((e) => e.id).toSet();

  Future<void> getInitialSuggestions() async {
    _page = _initialPage;
    await _search();
  }

  Future<void> getMoreSuggestions() async {
    if (state.isSearching) {
      return;
    }
    _page += 1;
    await _search();
  }

  Future<void> _search() async {
    if (_debounce?.isActive ?? false) {
      _debounce?.cancel();
    }
    _debounce = Timer(
      const Duration(milliseconds: 300),
      () async {
        emit(state.copyWith(isSearching: true));
        final page = _page;
        final result = await getFriendsUsecase.call(
          GetFriendsUsecaseParams(
            searchPhrase: state.searchPhrase,
            size: _itemsPerPage,
            page: _initialPage,
          ),
        );
        result.fold(
          (failure) {
            onFetchFailed?.call(failure.message);
            emit(state.copyWith(isSearching: false));
          },
          (members) {
            emit(
              state.copyWith(
                isSearching: false,
                members: page == _initialPage ? members : [...state.members, ...members],
              ),
            );
          },
        );
      },
    );
  }

  void toggleMemberSelection(User member) {
    if (selectedMemberIds.contains(member.id)) {
      final newState = state.copyWith(
        selectedMembers: state.selectedMembers.where((e) => e.id != member.id).toList(growable: false),
      );
      emit(newState);
    } else {
      final newState = state.copyWith(
        selectedMembers: [...state.selectedMembers, member],
      );
      emit(newState);
    }
  }

  void onSearchPhraseChanged(String phrase) {
    emit(state.copyWith(searchPhrase: phrase));
    getInitialSuggestions();
  }

  void dispose() {
    _debounce?.cancel();
  }
}

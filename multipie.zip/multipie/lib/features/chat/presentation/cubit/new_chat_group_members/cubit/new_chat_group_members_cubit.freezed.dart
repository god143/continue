// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'new_chat_group_members_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NewChatGroupMembersState {
  String get searchPhrase => throw _privateConstructorUsedError;
  List<User> get members => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;
  List<User> get selectedMembers => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $NewChatGroupMembersStateCopyWith<NewChatGroupMembersState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewChatGroupMembersStateCopyWith<$Res> {
  factory $NewChatGroupMembersStateCopyWith(NewChatGroupMembersState value,
          $Res Function(NewChatGroupMembersState) then) =
      _$NewChatGroupMembersStateCopyWithImpl<$Res>;
  $Res call(
      {String searchPhrase,
      List<User> members,
      bool isSearching,
      List<User> selectedMembers});
}

/// @nodoc
class _$NewChatGroupMembersStateCopyWithImpl<$Res>
    implements $NewChatGroupMembersStateCopyWith<$Res> {
  _$NewChatGroupMembersStateCopyWithImpl(this._value, this._then);

  final NewChatGroupMembersState _value;
  // ignore: unused_field
  final $Res Function(NewChatGroupMembersState) _then;

  @override
  $Res call({
    Object? searchPhrase = freezed,
    Object? members = freezed,
    Object? isSearching = freezed,
    Object? selectedMembers = freezed,
  }) {
    return _then(_value.copyWith(
      searchPhrase: searchPhrase == freezed
          ? _value.searchPhrase
          : searchPhrase // ignore: cast_nullable_to_non_nullable
              as String,
      members: members == freezed
          ? _value.members
          : members // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isSearching: isSearching == freezed
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedMembers: selectedMembers == freezed
          ? _value.selectedMembers
          : selectedMembers // ignore: cast_nullable_to_non_nullable
              as List<User>,
    ));
  }
}

/// @nodoc
abstract class _$$_NewChatGroupMembersStateCopyWith<$Res>
    implements $NewChatGroupMembersStateCopyWith<$Res> {
  factory _$$_NewChatGroupMembersStateCopyWith(
          _$_NewChatGroupMembersState value,
          $Res Function(_$_NewChatGroupMembersState) then) =
      __$$_NewChatGroupMembersStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {String searchPhrase,
      List<User> members,
      bool isSearching,
      List<User> selectedMembers});
}

/// @nodoc
class __$$_NewChatGroupMembersStateCopyWithImpl<$Res>
    extends _$NewChatGroupMembersStateCopyWithImpl<$Res>
    implements _$$_NewChatGroupMembersStateCopyWith<$Res> {
  __$$_NewChatGroupMembersStateCopyWithImpl(_$_NewChatGroupMembersState _value,
      $Res Function(_$_NewChatGroupMembersState) _then)
      : super(_value, (v) => _then(v as _$_NewChatGroupMembersState));

  @override
  _$_NewChatGroupMembersState get _value =>
      super._value as _$_NewChatGroupMembersState;

  @override
  $Res call({
    Object? searchPhrase = freezed,
    Object? members = freezed,
    Object? isSearching = freezed,
    Object? selectedMembers = freezed,
  }) {
    return _then(_$_NewChatGroupMembersState(
      searchPhrase: searchPhrase == freezed
          ? _value.searchPhrase
          : searchPhrase // ignore: cast_nullable_to_non_nullable
              as String,
      members: members == freezed
          ? _value._members
          : members // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isSearching: isSearching == freezed
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedMembers: selectedMembers == freezed
          ? _value._selectedMembers
          : selectedMembers // ignore: cast_nullable_to_non_nullable
              as List<User>,
    ));
  }
}

/// @nodoc

class _$_NewChatGroupMembersState
    with DiagnosticableTreeMixin
    implements _NewChatGroupMembersState {
  _$_NewChatGroupMembersState(
      {this.searchPhrase = '',
      final List<User> members = const [],
      this.isSearching = false,
      final List<User> selectedMembers = const []})
      : _members = members,
        _selectedMembers = selectedMembers;

  @override
  @JsonKey()
  final String searchPhrase;
  final List<User> _members;
  @override
  @JsonKey()
  List<User> get members {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_members);
  }

  @override
  @JsonKey()
  final bool isSearching;
  final List<User> _selectedMembers;
  @override
  @JsonKey()
  List<User> get selectedMembers {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_selectedMembers);
  }

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'NewChatGroupMembersState(searchPhrase: $searchPhrase, members: $members, isSearching: $isSearching, selectedMembers: $selectedMembers)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'NewChatGroupMembersState'))
      ..add(DiagnosticsProperty('searchPhrase', searchPhrase))
      ..add(DiagnosticsProperty('members', members))
      ..add(DiagnosticsProperty('isSearching', isSearching))
      ..add(DiagnosticsProperty('selectedMembers', selectedMembers));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_NewChatGroupMembersState &&
            const DeepCollectionEquality()
                .equals(other.searchPhrase, searchPhrase) &&
            const DeepCollectionEquality().equals(other._members, _members) &&
            const DeepCollectionEquality()
                .equals(other.isSearching, isSearching) &&
            const DeepCollectionEquality()
                .equals(other._selectedMembers, _selectedMembers));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(searchPhrase),
      const DeepCollectionEquality().hash(_members),
      const DeepCollectionEquality().hash(isSearching),
      const DeepCollectionEquality().hash(_selectedMembers));

  @JsonKey(ignore: true)
  @override
  _$$_NewChatGroupMembersStateCopyWith<_$_NewChatGroupMembersState>
      get copyWith => __$$_NewChatGroupMembersStateCopyWithImpl<
          _$_NewChatGroupMembersState>(this, _$identity);
}

abstract class _NewChatGroupMembersState implements NewChatGroupMembersState {
  factory _NewChatGroupMembersState(
      {final String searchPhrase,
      final List<User> members,
      final bool isSearching,
      final List<User> selectedMembers}) = _$_NewChatGroupMembersState;

  @override
  String get searchPhrase => throw _privateConstructorUsedError;
  @override
  List<User> get members => throw _privateConstructorUsedError;
  @override
  bool get isSearching => throw _privateConstructorUsedError;
  @override
  List<User> get selectedMembers => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_NewChatGroupMembersStateCopyWith<_$_NewChatGroupMembersState>
      get copyWith => throw _privateConstructorUsedError;
}

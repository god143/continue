part of 'new_chat_group_members_cubit.dart';

@freezed
class NewChatGroupMembersState with _$NewChatGroupMembersState {
  factory NewChatGroupMembersState({
    @Default('') String searchPhrase,
    @Default([]) List<User> members,
    @Default(false) bool isSearching,
    @Default([]) List<User> selectedMembers,
  }) = _NewChatGroupMembersState;
}

import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class UnreadMessagesBadge extends StatelessWidget {
  const UnreadMessagesBadge({
    Key? key,
    required this.unreadMessages,
    this.width,
    this.height,
  }) : super(key: key);

  final String unreadMessages;
  final double? width;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: width,
      width: height,
      decoration: BoxDecoration(
        color: context.appTheme.negativeGainColor,
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(4.0),
          child: Text(
            unreadMessages,
            style: mpHeadLine7(
              context: context,
              textColor: context.appTheme.lightTextColor,
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:cached_network_image/cached_network_image.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_parsed_text/flutter_parsed_text.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/mention/presentation/matchers.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/image_post_widget.dart';

class ChatMessageWidget extends StatelessWidget {
  const ChatMessageWidget({
    Key? key,
    required this.message,
    required this.isSentByCurrentUser,
    required this.showUserName,
    required this.width,
  }) : super(key: key);

  final ChatMessage message;
  final bool showUserName;
  final bool isSentByCurrentUser;
  final int width;

  @override
  Widget build(BuildContext context) {
    final textColor = isSentByCurrentUser ? context.appTheme.lightTextColor : context.appTheme.primaryTextColor;
    String? imageUrl;
    if (message.mediaUrl != null) {
      if (message.mediaUrl!.startsWith('http')) {
        imageUrl = message.mediaUrl!;
      } else {
        imageUrl = '${Constants.BASE_URL}${message.mediaUrl!}';
      }
    }
    return SizedBox(
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (showUserName && message.user != null) ...[
                  Text(
                    message.user!.displayname,
                    style: mpHeadLine6(
                      context: context,
                      textColor: textColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 6),
                ],
                if (message.messageContent.trim().isNotEmpty)
                  ParsedText(
                    text: message.messageContent,
                    style: mpHeadLine5(
                      context: context,
                      textColor: textColor,
                    ),
                    parse: [
                      getMatcherForUserMention(
                        context: context,
                        getUserMention: (userId) => message.taggedUsers?.firstWhereOrNull((e) => e.id == userId),
                      ),
                      getMatcherForHashTagMention(
                        context: context,
                        getHashTag: (id) => message.taggedTopics?.firstWhereOrNull((e) => e.id == id),
                      ),
                      getMatcherForCompanyMention(
                        context: context,
                        getCompany: (companyId) => message.taggedCompanies?.firstWhereOrNull((e) => e.id == companyId),
                      ),
                      getMatcherForInstrumentMention(
                        context: context,
                        getInstrument: (instrumentId) =>
                            message.taggedInstruments?.firstWhereOrNull((e) => e.id == instrumentId),
                      ),
                      getMatcherForUrl(context: context),
                    ],
                  ),
                if (imageUrl != null) ...[
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ViewImageScreen(
                            imagePath: [imageUrl!],
                          ),
                        ),
                      );
                    },
                    child: CachedNetworkImage(
                      imageUrl: imageUrl,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => SizedBox(),
                    ),
                  ),
                ],
                const SizedBox(
                  height: 18,
                  width: 50,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 8,
            right: isSentByCurrentUser ? 12 : null,
            left: isSentByCurrentUser ? null : 12,
            child: Text(
              message.updatedAt.toLocal().format('hh:mm a'),
              textAlign: TextAlign.right,
              style: mpHeadLine7(
                context: context,
                textColor: textColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

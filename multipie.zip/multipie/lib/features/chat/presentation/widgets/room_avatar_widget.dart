import 'package:cached_network_image/cached_network_image.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/profile_screen_bloc.dart';

class RoomAvatarWidget extends StatelessWidget {
  const RoomAvatarWidget({
    Key? key,
    required this.room,
    this.size = 46,
  }) : super(key: key);

  final ChatRoom room;
  final double size;

  @override
  Widget build(BuildContext context) {
    final String? url;
    final String firstLetter;
    if (room.groupChat) {
      final filePath = room.dpFile?.filePath;
      url = filePath != null ? Constants.BASE_URL + filePath : null;
      firstLetter = room.name?.characters.firstOrNull ?? 'U';
    } else {
      final currentUserId = context.read<UserProfileBloc>().currentUser!.id;
      final otherUser = room.users.firstWhereOrNull((e) => e.id != currentUserId);
      url = otherUser?.dpUrl;
      firstLetter = otherUser?.displayname.characters.firstOrNull ?? 'U';
    }
    if (url != null) {
      return SizedBox(
        height: size,
        width: size,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(size / 2),
          child: CachedNetworkImage(
            imageUrl: url,
            errorWidget: (_, __, ___) => _InitialLetterWidget(
              size: size,
              firstLetter: firstLetter,
            ),
            fit: BoxFit.cover,
          ),
        ),
      );
    } else {
      return _InitialLetterWidget(
        size: size,
        firstLetter: firstLetter,
      );
    }
  }
}

class _InitialLetterWidget extends StatelessWidget {
  const _InitialLetterWidget({
    Key? key,
    required double size,
    required this.firstLetter,
  })  : _size = size,
        super(key: key);

  final double _size;
  final String firstLetter;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: _size,
      width: _size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: context.appTheme.primaryColor.withOpacity(0.3),
        shape: BoxShape.circle,
      ),
      child: Text(
        firstLetter.toUpperCase(),
        style: mpHeadLine3(
          context: context,
          textColor: context.appTheme.primaryColor,
          fontWeight: FontWeight.normal,
        ),
      ),
    );
  }
}

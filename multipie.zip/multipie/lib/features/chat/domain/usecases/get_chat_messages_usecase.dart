import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';

class GetChatMessagesUsecase implements UseCase<List<ChatMessage>, Params> {
  final ChatRepository repository;

  const GetChatMessagesUsecase(this.repository);

  @override
  Future<Either<Failure, List<ChatMessage>>> call(Params params) => repository.getChatMessages(
        chatRoomId: params.chatRoomId,
        page: params.pageNumber,
        size: params.pageSize,
      );
}

class Params extends Equatable {
  final String chatRoomId;
  final int pageSize;
  final int pageNumber;

  const Params({
    required this.chatRoomId,
    required this.pageSize,
    required this.pageNumber,
  });

  @override
  List<Object> get props => [pageSize, pageNumber];
}

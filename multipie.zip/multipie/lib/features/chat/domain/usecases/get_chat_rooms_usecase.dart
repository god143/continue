import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';

class GetChatRoomsUsecase implements UseCase<List<ChatRoom>, Params> {
  final ChatRepository repository;

  const GetChatRoomsUsecase(this.repository);

  @override
  Future<Either<Failure, List<ChatRoom>>> call(Params params) => repository.getChatRooms(
        page: params.pageNumber,
        size: params.pageSize,
      );
}

class Params extends Equatable {
  final int pageSize;
  final int pageNumber;

  const Params({
    required this.pageSize,
    required this.pageNumber,
  });

  @override
  List<Object> get props => [pageSize, pageNumber];
}

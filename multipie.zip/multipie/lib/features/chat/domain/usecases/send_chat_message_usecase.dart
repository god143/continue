import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/chat/data/models/chat_message.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';

class SendChatMessageUsecase implements UseCase<ChatMessage?, SendChatMessageUsecaseParams> {
  final ChatRepository repository;

  const SendChatMessageUsecase(this.repository);

  @override
  Future<Either<Failure, ChatMessage?>> call(SendChatMessageUsecaseParams params) => repository.sendChatMessage(
        chatRoomId: params.chatRoomId,
        text: params.text,
        attachment: params.attachment,
        mediaUrl: params.mediaUrl,
      );
}

class SendChatMessageUsecaseParams extends Equatable {
  final String chatRoomId;
  final String text;
  final File? attachment;
  final String? mediaUrl;

  const SendChatMessageUsecaseParams({
    required this.chatRoomId,
    required this.text,
    this.attachment,
    this.mediaUrl,
  });

  @override
  List<Object> get props => [
        chatRoomId,
        text,
        if (attachment != null) attachment!,
        if (mediaUrl != null) mediaUrl!,
      ];
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';

class GetUnreadMessagesCountUsecase implements UseCase<int, NoParams> {
  final ChatRepository repository;

  const GetUnreadMessagesCountUsecase(this.repository);

  @override
  Future<Either<Failure, int>> call(NoParams params) => repository.getUnreadMessagesCount();
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/chat/data/models/chat_room.dart';
import 'package:multipie/features/chat/data/repositories/chat_repository.dart';

class CreateChatRoomUsecase implements UseCase<ChatRoom, CreateChatRoomUsecaseParams> {
  final ChatRepository repository;

  const CreateChatRoomUsecase(this.repository);

  @override
  Future<Either<Failure, ChatRoom>> call(CreateChatRoomUsecaseParams params) =>
      repository.createChatRoom(recipientId: params.recipientId);
}

class CreateChatRoomUsecaseParams extends Equatable {
  final String recipientId;

  const CreateChatRoomUsecaseParams({required this.recipientId});

  @override
  List<Object> get props => [recipientId];
}

import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/holdings_comparision/models/holdings_comparision_model.dart';
import 'package:multipie/services/network_service.dart';

class HoldingsService {
  final NetworkService networkService;

  const HoldingsService({
    required this.networkService,
  });

  Future<List<HoldingsComparisionModel>> getSuperstarHoldingsComparisions() async {
    final jsonApi = await networkService.getRequest("/celebrity_investors/holdings_comparison");
    try {
      Iterable data = jsonApi['data']['attributes'];
      return data.map((e) => HoldingsComparisionModel.fromJson(e)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }
}

import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/holdings_comparision/models/celebrity_challenge_result.dart';
import 'package:multipie/services/network_service.dart';

class CelebrityChallengeService {
  final NetworkService networkService;

  const CelebrityChallengeService({
    required this.networkService,
  });

  Future<CelebrityChallengeResult> getChallengeResult({
    required String celebrityId,
  }) async {
    final jsonApi = await networkService.getRequest("/celebrity_investors/$celebrityId/challenge");
    try {
      return CelebrityChallengeResult.fromJson(jsonApi);
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }
}

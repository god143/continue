import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/holdings_comparision/models/celebrity_challenge_result.dart';
import 'package:multipie/features/holdings_comparision/repositories/celebrity_challenge_repository.dart';

part 'celebrity_challenge_cubit.freezed.dart';
part 'celebrity_challenge_state.dart';

class CelebrityChallengeCubit extends Cubit<CelebrityChallengeState> {
  CelebrityChallengeCubit({
    required this.celebrityUserId,
    required this.repository,
  }) : super(CelebrityChallengeState());

  final String celebrityUserId;
  final CelebrityChallengeRepository repository;

  Future<void> fetchResult() async {
    emit(state.copyWith(isLoading: true));
    final result = await repository.getChallengeResult(celebrityId: celebrityUserId);

    result.fold(
      (_) => emit(
        state.copyWith(isLoading: false),
      ),
      (challengeResult) {
        emit(
          state.copyWith(
            isLoading: false,
            challengeResult: challengeResult,
          ),
        );
      },
    );
  }

  void togglePeriod() {
    emit(
      state.copyWith(
        selectedPeriod: state.selectedPeriod == '1d' ? '1w' : '1d',
      ),
    );
  }

  List<TopGainHoldingItem> get userHoldings =>
      (state.selectedPeriod == '1d'
          ? state.challengeResult?.userDailyTopGainHoldings
          : state.challengeResult?.userWeeklyTopGainHoldings) ??
      [];

  List<TopGainHoldingItem> get celebHoldings =>
      (state.selectedPeriod == '1d'
          ? state.challengeResult?.celebDailyTopGainHoldings
          : state.challengeResult?.celebWeeklyTopGainHoldings) ??
      [];
}

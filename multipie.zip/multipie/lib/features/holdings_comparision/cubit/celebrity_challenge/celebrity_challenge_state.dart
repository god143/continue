part of 'celebrity_challenge_cubit.dart';

@freezed
class CelebrityChallengeState with _$CelebrityChallengeState {
  factory CelebrityChallengeState({
    @Default(false) bool isLoading,
    @Default('1d') String selectedPeriod,
    CelebrityChallengeResult? challengeResult,
  }) = _CelebrityChallengeState;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'celebrity_challenge_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CelebrityChallengeState {
  bool get isLoading => throw _privateConstructorUsedError;
  String get selectedPeriod => throw _privateConstructorUsedError;
  CelebrityChallengeResult? get challengeResult =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CelebrityChallengeStateCopyWith<CelebrityChallengeState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CelebrityChallengeStateCopyWith<$Res> {
  factory $CelebrityChallengeStateCopyWith(CelebrityChallengeState value,
          $Res Function(CelebrityChallengeState) then) =
      _$CelebrityChallengeStateCopyWithImpl<$Res>;
  $Res call(
      {bool isLoading,
      String selectedPeriod,
      CelebrityChallengeResult? challengeResult});

  $CelebrityChallengeResultCopyWith<$Res>? get challengeResult;
}

/// @nodoc
class _$CelebrityChallengeStateCopyWithImpl<$Res>
    implements $CelebrityChallengeStateCopyWith<$Res> {
  _$CelebrityChallengeStateCopyWithImpl(this._value, this._then);

  final CelebrityChallengeState _value;
  // ignore: unused_field
  final $Res Function(CelebrityChallengeState) _then;

  @override
  $Res call({
    Object? isLoading = freezed,
    Object? selectedPeriod = freezed,
    Object? challengeResult = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: isLoading == freezed
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedPeriod: selectedPeriod == freezed
          ? _value.selectedPeriod
          : selectedPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      challengeResult: challengeResult == freezed
          ? _value.challengeResult
          : challengeResult // ignore: cast_nullable_to_non_nullable
              as CelebrityChallengeResult?,
    ));
  }

  @override
  $CelebrityChallengeResultCopyWith<$Res>? get challengeResult {
    if (_value.challengeResult == null) {
      return null;
    }

    return $CelebrityChallengeResultCopyWith<$Res>(_value.challengeResult!,
        (value) {
      return _then(_value.copyWith(challengeResult: value));
    });
  }
}

/// @nodoc
abstract class _$$_CelebrityChallengeStateCopyWith<$Res>
    implements $CelebrityChallengeStateCopyWith<$Res> {
  factory _$$_CelebrityChallengeStateCopyWith(_$_CelebrityChallengeState value,
          $Res Function(_$_CelebrityChallengeState) then) =
      __$$_CelebrityChallengeStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {bool isLoading,
      String selectedPeriod,
      CelebrityChallengeResult? challengeResult});

  @override
  $CelebrityChallengeResultCopyWith<$Res>? get challengeResult;
}

/// @nodoc
class __$$_CelebrityChallengeStateCopyWithImpl<$Res>
    extends _$CelebrityChallengeStateCopyWithImpl<$Res>
    implements _$$_CelebrityChallengeStateCopyWith<$Res> {
  __$$_CelebrityChallengeStateCopyWithImpl(_$_CelebrityChallengeState _value,
      $Res Function(_$_CelebrityChallengeState) _then)
      : super(_value, (v) => _then(v as _$_CelebrityChallengeState));

  @override
  _$_CelebrityChallengeState get _value =>
      super._value as _$_CelebrityChallengeState;

  @override
  $Res call({
    Object? isLoading = freezed,
    Object? selectedPeriod = freezed,
    Object? challengeResult = freezed,
  }) {
    return _then(_$_CelebrityChallengeState(
      isLoading: isLoading == freezed
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedPeriod: selectedPeriod == freezed
          ? _value.selectedPeriod
          : selectedPeriod // ignore: cast_nullable_to_non_nullable
              as String,
      challengeResult: challengeResult == freezed
          ? _value.challengeResult
          : challengeResult // ignore: cast_nullable_to_non_nullable
              as CelebrityChallengeResult?,
    ));
  }
}

/// @nodoc

class _$_CelebrityChallengeState implements _CelebrityChallengeState {
  _$_CelebrityChallengeState(
      {this.isLoading = false,
      this.selectedPeriod = '1d',
      this.challengeResult});

  @override
  @JsonKey()
  final bool isLoading;
  @override
  @JsonKey()
  final String selectedPeriod;
  @override
  final CelebrityChallengeResult? challengeResult;

  @override
  String toString() {
    return 'CelebrityChallengeState(isLoading: $isLoading, selectedPeriod: $selectedPeriod, challengeResult: $challengeResult)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CelebrityChallengeState &&
            const DeepCollectionEquality().equals(other.isLoading, isLoading) &&
            const DeepCollectionEquality()
                .equals(other.selectedPeriod, selectedPeriod) &&
            const DeepCollectionEquality()
                .equals(other.challengeResult, challengeResult));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(isLoading),
      const DeepCollectionEquality().hash(selectedPeriod),
      const DeepCollectionEquality().hash(challengeResult));

  @JsonKey(ignore: true)
  @override
  _$$_CelebrityChallengeStateCopyWith<_$_CelebrityChallengeState>
      get copyWith =>
          __$$_CelebrityChallengeStateCopyWithImpl<_$_CelebrityChallengeState>(
              this, _$identity);
}

abstract class _CelebrityChallengeState implements CelebrityChallengeState {
  factory _CelebrityChallengeState(
          {final bool isLoading,
          final String selectedPeriod,
          final CelebrityChallengeResult? challengeResult}) =
      _$_CelebrityChallengeState;

  @override
  bool get isLoading => throw _privateConstructorUsedError;
  @override
  String get selectedPeriod => throw _privateConstructorUsedError;
  @override
  CelebrityChallengeResult? get challengeResult =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_CelebrityChallengeStateCopyWith<_$_CelebrityChallengeState>
      get copyWith => throw _privateConstructorUsedError;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'holdings_comparision_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$HoldingsComparisionState {
  bool get isLoading => throw _privateConstructorUsedError;
  List<HoldingsComparisionModel> get holdings =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $HoldingsComparisionStateCopyWith<HoldingsComparisionState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HoldingsComparisionStateCopyWith<$Res> {
  factory $HoldingsComparisionStateCopyWith(HoldingsComparisionState value,
          $Res Function(HoldingsComparisionState) then) =
      _$HoldingsComparisionStateCopyWithImpl<$Res>;
  $Res call({bool isLoading, List<HoldingsComparisionModel> holdings});
}

/// @nodoc
class _$HoldingsComparisionStateCopyWithImpl<$Res>
    implements $HoldingsComparisionStateCopyWith<$Res> {
  _$HoldingsComparisionStateCopyWithImpl(this._value, this._then);

  final HoldingsComparisionState _value;
  // ignore: unused_field
  final $Res Function(HoldingsComparisionState) _then;

  @override
  $Res call({
    Object? isLoading = freezed,
    Object? holdings = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: isLoading == freezed
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      holdings: holdings == freezed
          ? _value.holdings
          : holdings // ignore: cast_nullable_to_non_nullable
              as List<HoldingsComparisionModel>,
    ));
  }
}

/// @nodoc
abstract class _$$_HoldingsComparisionStateCopyWith<$Res>
    implements $HoldingsComparisionStateCopyWith<$Res> {
  factory _$$_HoldingsComparisionStateCopyWith(
          _$_HoldingsComparisionState value,
          $Res Function(_$_HoldingsComparisionState) then) =
      __$$_HoldingsComparisionStateCopyWithImpl<$Res>;
  @override
  $Res call({bool isLoading, List<HoldingsComparisionModel> holdings});
}

/// @nodoc
class __$$_HoldingsComparisionStateCopyWithImpl<$Res>
    extends _$HoldingsComparisionStateCopyWithImpl<$Res>
    implements _$$_HoldingsComparisionStateCopyWith<$Res> {
  __$$_HoldingsComparisionStateCopyWithImpl(_$_HoldingsComparisionState _value,
      $Res Function(_$_HoldingsComparisionState) _then)
      : super(_value, (v) => _then(v as _$_HoldingsComparisionState));

  @override
  _$_HoldingsComparisionState get _value =>
      super._value as _$_HoldingsComparisionState;

  @override
  $Res call({
    Object? isLoading = freezed,
    Object? holdings = freezed,
  }) {
    return _then(_$_HoldingsComparisionState(
      isLoading: isLoading == freezed
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      holdings: holdings == freezed
          ? _value._holdings
          : holdings // ignore: cast_nullable_to_non_nullable
              as List<HoldingsComparisionModel>,
    ));
  }
}

/// @nodoc

class _$_HoldingsComparisionState implements _HoldingsComparisionState {
  _$_HoldingsComparisionState(
      {this.isLoading = false,
      final List<HoldingsComparisionModel> holdings = const []})
      : _holdings = holdings;

  @override
  @JsonKey()
  final bool isLoading;
  final List<HoldingsComparisionModel> _holdings;
  @override
  @JsonKey()
  List<HoldingsComparisionModel> get holdings {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_holdings);
  }

  @override
  String toString() {
    return 'HoldingsComparisionState(isLoading: $isLoading, holdings: $holdings)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HoldingsComparisionState &&
            const DeepCollectionEquality().equals(other.isLoading, isLoading) &&
            const DeepCollectionEquality().equals(other._holdings, _holdings));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(isLoading),
      const DeepCollectionEquality().hash(_holdings));

  @JsonKey(ignore: true)
  @override
  _$$_HoldingsComparisionStateCopyWith<_$_HoldingsComparisionState>
      get copyWith => __$$_HoldingsComparisionStateCopyWithImpl<
          _$_HoldingsComparisionState>(this, _$identity);
}

abstract class _HoldingsComparisionState implements HoldingsComparisionState {
  factory _HoldingsComparisionState(
          {final bool isLoading,
          final List<HoldingsComparisionModel> holdings}) =
      _$_HoldingsComparisionState;

  @override
  bool get isLoading => throw _privateConstructorUsedError;
  @override
  List<HoldingsComparisionModel> get holdings =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_HoldingsComparisionStateCopyWith<_$_HoldingsComparisionState>
      get copyWith => throw _privateConstructorUsedError;
}

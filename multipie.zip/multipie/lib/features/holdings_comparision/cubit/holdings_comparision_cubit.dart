import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/holdings_comparision/models/holdings_comparision_model.dart';
import 'package:multipie/features/holdings_comparision/repositories/holdings_repository.dart';

part 'holdings_comparision_cubit.freezed.dart';
part 'holdings_comparision_state.dart';

class HoldingsComparisionCubit extends Cubit<HoldingsComparisionState> {
  HoldingsComparisionCubit({
    required this.holdingsRepository,
  }) : super(HoldingsComparisionState()) {
    _fetchHoldingComparisions();
  }

  final HoldingsRepository holdingsRepository;

  Future<void> _fetchHoldingComparisions() async {
    emit(state.copyWith(isLoading: true));
    final result = await holdingsRepository.getSuperstarHoldingsComparisions();
    final data = result.fold((ex) => <HoldingsComparisionModel>[], (d) => d);
    emit(
      state.copyWith(isLoading: false, holdings: data),
    );
  }
}

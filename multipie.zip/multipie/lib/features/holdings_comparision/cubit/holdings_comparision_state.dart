part of 'holdings_comparision_cubit.dart';

@freezed
class HoldingsComparisionState with _$HoldingsComparisionState {
  factory HoldingsComparisionState({
    @Default(false) bool isLoading,
    @Default([]) List<HoldingsComparisionModel> holdings,
  }) = _HoldingsComparisionState;
}

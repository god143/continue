import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/holdings_comparision/models/holdings_comparision_model.dart';
import 'package:multipie/features/holdings_comparision/services/holdings_service.dart';

class HoldingsRepository {
  final NetworkInfo networkInfo;
  final HoldingsService service;

  HoldingsRepository({
    required this.networkInfo,
    required this.service,
  });

  Future<Either<Failure, List<HoldingsComparisionModel>>> getSuperstarHoldingsComparisions() async {
    if (await networkInfo.isConnected) {
      try {
        final response = await service.getSuperstarHoldingsComparisions();
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

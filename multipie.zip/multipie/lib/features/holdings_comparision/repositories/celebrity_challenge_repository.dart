import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/holdings_comparision/models/celebrity_challenge_result.dart';
import 'package:multipie/features/holdings_comparision/services/celebrity_challenge_service.dart';

class CelebrityChallengeRepository {
  final NetworkInfo networkInfo;
  final CelebrityChallengeService service;

  CelebrityChallengeRepository({
    required this.networkInfo,
    required this.service,
  });

  Future<Either<Failure, CelebrityChallengeResult>> getChallengeResult({
    required String celebrityId,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await service.getChallengeResult(celebrityId: celebrityId);
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

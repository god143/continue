// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'holdings_comparision_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

HoldingsComparisionModel _$HoldingsComparisionModelFromJson(
    Map<String, dynamic> json) {
  return _HoldingsComparisionModel.fromJson(json);
}

/// @nodoc
mixin _$HoldingsComparisionModel {
  String? get name => throw _privateConstructorUsedError;
  int get userId => throw _privateConstructorUsedError;
  String get username => throw _privateConstructorUsedError;
  String get displayName => throw _privateConstructorUsedError;
  String? get displayPic => throw _privateConstructorUsedError;
  double get percentageMatch => throw _privateConstructorUsedError;
  List<CommonCompanyModel> get commonCompanies =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HoldingsComparisionModelCopyWith<HoldingsComparisionModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HoldingsComparisionModelCopyWith<$Res> {
  factory $HoldingsComparisionModelCopyWith(HoldingsComparisionModel value,
          $Res Function(HoldingsComparisionModel) then) =
      _$HoldingsComparisionModelCopyWithImpl<$Res>;
  $Res call(
      {String? name,
      int userId,
      String username,
      String displayName,
      String? displayPic,
      double percentageMatch,
      List<CommonCompanyModel> commonCompanies});
}

/// @nodoc
class _$HoldingsComparisionModelCopyWithImpl<$Res>
    implements $HoldingsComparisionModelCopyWith<$Res> {
  _$HoldingsComparisionModelCopyWithImpl(this._value, this._then);

  final HoldingsComparisionModel _value;
  // ignore: unused_field
  final $Res Function(HoldingsComparisionModel) _then;

  @override
  $Res call({
    Object? name = freezed,
    Object? userId = freezed,
    Object? username = freezed,
    Object? displayName = freezed,
    Object? displayPic = freezed,
    Object? percentageMatch = freezed,
    Object? commonCompanies = freezed,
  }) {
    return _then(_value.copyWith(
      name: name == freezed
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      userId: userId == freezed
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      username: username == freezed
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      displayPic: displayPic == freezed
          ? _value.displayPic
          : displayPic // ignore: cast_nullable_to_non_nullable
              as String?,
      percentageMatch: percentageMatch == freezed
          ? _value.percentageMatch
          : percentageMatch // ignore: cast_nullable_to_non_nullable
              as double,
      commonCompanies: commonCompanies == freezed
          ? _value.commonCompanies
          : commonCompanies // ignore: cast_nullable_to_non_nullable
              as List<CommonCompanyModel>,
    ));
  }
}

/// @nodoc
abstract class _$$_HoldingsComparisionModelCopyWith<$Res>
    implements $HoldingsComparisionModelCopyWith<$Res> {
  factory _$$_HoldingsComparisionModelCopyWith(
          _$_HoldingsComparisionModel value,
          $Res Function(_$_HoldingsComparisionModel) then) =
      __$$_HoldingsComparisionModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {String? name,
      int userId,
      String username,
      String displayName,
      String? displayPic,
      double percentageMatch,
      List<CommonCompanyModel> commonCompanies});
}

/// @nodoc
class __$$_HoldingsComparisionModelCopyWithImpl<$Res>
    extends _$HoldingsComparisionModelCopyWithImpl<$Res>
    implements _$$_HoldingsComparisionModelCopyWith<$Res> {
  __$$_HoldingsComparisionModelCopyWithImpl(_$_HoldingsComparisionModel _value,
      $Res Function(_$_HoldingsComparisionModel) _then)
      : super(_value, (v) => _then(v as _$_HoldingsComparisionModel));

  @override
  _$_HoldingsComparisionModel get _value =>
      super._value as _$_HoldingsComparisionModel;

  @override
  $Res call({
    Object? name = freezed,
    Object? userId = freezed,
    Object? username = freezed,
    Object? displayName = freezed,
    Object? displayPic = freezed,
    Object? percentageMatch = freezed,
    Object? commonCompanies = freezed,
  }) {
    return _then(_$_HoldingsComparisionModel(
      name: name == freezed
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      userId: userId == freezed
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      username: username == freezed
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      displayPic: displayPic == freezed
          ? _value.displayPic
          : displayPic // ignore: cast_nullable_to_non_nullable
              as String?,
      percentageMatch: percentageMatch == freezed
          ? _value.percentageMatch
          : percentageMatch // ignore: cast_nullable_to_non_nullable
              as double,
      commonCompanies: commonCompanies == freezed
          ? _value._commonCompanies
          : commonCompanies // ignore: cast_nullable_to_non_nullable
              as List<CommonCompanyModel>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_HoldingsComparisionModel implements _HoldingsComparisionModel {
  _$_HoldingsComparisionModel(
      {this.name,
      required this.userId,
      required this.username,
      required this.displayName,
      this.displayPic,
      required this.percentageMatch,
      required final List<CommonCompanyModel> commonCompanies})
      : _commonCompanies = commonCompanies;

  factory _$_HoldingsComparisionModel.fromJson(Map<String, dynamic> json) =>
      _$$_HoldingsComparisionModelFromJson(json);

  @override
  final String? name;
  @override
  final int userId;
  @override
  final String username;
  @override
  final String displayName;
  @override
  final String? displayPic;
  @override
  final double percentageMatch;
  final List<CommonCompanyModel> _commonCompanies;
  @override
  List<CommonCompanyModel> get commonCompanies {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_commonCompanies);
  }

  @override
  String toString() {
    return 'HoldingsComparisionModel(name: $name, userId: $userId, username: $username, displayName: $displayName, displayPic: $displayPic, percentageMatch: $percentageMatch, commonCompanies: $commonCompanies)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HoldingsComparisionModel &&
            const DeepCollectionEquality().equals(other.name, name) &&
            const DeepCollectionEquality().equals(other.userId, userId) &&
            const DeepCollectionEquality().equals(other.username, username) &&
            const DeepCollectionEquality()
                .equals(other.displayName, displayName) &&
            const DeepCollectionEquality()
                .equals(other.displayPic, displayPic) &&
            const DeepCollectionEquality()
                .equals(other.percentageMatch, percentageMatch) &&
            const DeepCollectionEquality()
                .equals(other._commonCompanies, _commonCompanies));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(name),
      const DeepCollectionEquality().hash(userId),
      const DeepCollectionEquality().hash(username),
      const DeepCollectionEquality().hash(displayName),
      const DeepCollectionEquality().hash(displayPic),
      const DeepCollectionEquality().hash(percentageMatch),
      const DeepCollectionEquality().hash(_commonCompanies));

  @JsonKey(ignore: true)
  @override
  _$$_HoldingsComparisionModelCopyWith<_$_HoldingsComparisionModel>
      get copyWith => __$$_HoldingsComparisionModelCopyWithImpl<
          _$_HoldingsComparisionModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_HoldingsComparisionModelToJson(this);
  }
}

abstract class _HoldingsComparisionModel implements HoldingsComparisionModel {
  factory _HoldingsComparisionModel(
          {final String? name,
          required final int userId,
          required final String username,
          required final String displayName,
          final String? displayPic,
          required final double percentageMatch,
          required final List<CommonCompanyModel> commonCompanies}) =
      _$_HoldingsComparisionModel;

  factory _HoldingsComparisionModel.fromJson(Map<String, dynamic> json) =
      _$_HoldingsComparisionModel.fromJson;

  @override
  String? get name => throw _privateConstructorUsedError;
  @override
  int get userId => throw _privateConstructorUsedError;
  @override
  String get username => throw _privateConstructorUsedError;
  @override
  String get displayName => throw _privateConstructorUsedError;
  @override
  String? get displayPic => throw _privateConstructorUsedError;
  @override
  double get percentageMatch => throw _privateConstructorUsedError;
  @override
  List<CommonCompanyModel> get commonCompanies =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_HoldingsComparisionModelCopyWith<_$_HoldingsComparisionModel>
      get copyWith => throw _privateConstructorUsedError;
}

CommonCompanyModel _$CommonCompanyModelFromJson(Map<String, dynamic> json) {
  return _CommonCompanyModel.fromJson(json);
}

/// @nodoc
mixin _$CommonCompanyModel {
  String get name => throw _privateConstructorUsedError;
  String? get icon => throw _privateConstructorUsedError;
  int get instrumentId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CommonCompanyModelCopyWith<CommonCompanyModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CommonCompanyModelCopyWith<$Res> {
  factory $CommonCompanyModelCopyWith(
          CommonCompanyModel value, $Res Function(CommonCompanyModel) then) =
      _$CommonCompanyModelCopyWithImpl<$Res>;
  $Res call({String name, String? icon, int instrumentId});
}

/// @nodoc
class _$CommonCompanyModelCopyWithImpl<$Res>
    implements $CommonCompanyModelCopyWith<$Res> {
  _$CommonCompanyModelCopyWithImpl(this._value, this._then);

  final CommonCompanyModel _value;
  // ignore: unused_field
  final $Res Function(CommonCompanyModel) _then;

  @override
  $Res call({
    Object? name = freezed,
    Object? icon = freezed,
    Object? instrumentId = freezed,
  }) {
    return _then(_value.copyWith(
      name: name == freezed
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      icon: icon == freezed
          ? _value.icon
          : icon // ignore: cast_nullable_to_non_nullable
              as String?,
      instrumentId: instrumentId == freezed
          ? _value.instrumentId
          : instrumentId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
abstract class _$$_CommonCompanyModelCopyWith<$Res>
    implements $CommonCompanyModelCopyWith<$Res> {
  factory _$$_CommonCompanyModelCopyWith(_$_CommonCompanyModel value,
          $Res Function(_$_CommonCompanyModel) then) =
      __$$_CommonCompanyModelCopyWithImpl<$Res>;
  @override
  $Res call({String name, String? icon, int instrumentId});
}

/// @nodoc
class __$$_CommonCompanyModelCopyWithImpl<$Res>
    extends _$CommonCompanyModelCopyWithImpl<$Res>
    implements _$$_CommonCompanyModelCopyWith<$Res> {
  __$$_CommonCompanyModelCopyWithImpl(
      _$_CommonCompanyModel _value, $Res Function(_$_CommonCompanyModel) _then)
      : super(_value, (v) => _then(v as _$_CommonCompanyModel));

  @override
  _$_CommonCompanyModel get _value => super._value as _$_CommonCompanyModel;

  @override
  $Res call({
    Object? name = freezed,
    Object? icon = freezed,
    Object? instrumentId = freezed,
  }) {
    return _then(_$_CommonCompanyModel(
      name: name == freezed
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      icon: icon == freezed
          ? _value.icon
          : icon // ignore: cast_nullable_to_non_nullable
              as String?,
      instrumentId: instrumentId == freezed
          ? _value.instrumentId
          : instrumentId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_CommonCompanyModel implements _CommonCompanyModel {
  _$_CommonCompanyModel(
      {required this.name, this.icon, required this.instrumentId});

  factory _$_CommonCompanyModel.fromJson(Map<String, dynamic> json) =>
      _$$_CommonCompanyModelFromJson(json);

  @override
  final String name;
  @override
  final String? icon;
  @override
  final int instrumentId;

  @override
  String toString() {
    return 'CommonCompanyModel(name: $name, icon: $icon, instrumentId: $instrumentId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CommonCompanyModel &&
            const DeepCollectionEquality().equals(other.name, name) &&
            const DeepCollectionEquality().equals(other.icon, icon) &&
            const DeepCollectionEquality()
                .equals(other.instrumentId, instrumentId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(name),
      const DeepCollectionEquality().hash(icon),
      const DeepCollectionEquality().hash(instrumentId));

  @JsonKey(ignore: true)
  @override
  _$$_CommonCompanyModelCopyWith<_$_CommonCompanyModel> get copyWith =>
      __$$_CommonCompanyModelCopyWithImpl<_$_CommonCompanyModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CommonCompanyModelToJson(this);
  }
}

abstract class _CommonCompanyModel implements CommonCompanyModel {
  factory _CommonCompanyModel(
      {required final String name,
      final String? icon,
      required final int instrumentId}) = _$_CommonCompanyModel;

  factory _CommonCompanyModel.fromJson(Map<String, dynamic> json) =
      _$_CommonCompanyModel.fromJson;

  @override
  String get name => throw _privateConstructorUsedError;
  @override
  String? get icon => throw _privateConstructorUsedError;
  @override
  int get instrumentId => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_CommonCompanyModelCopyWith<_$_CommonCompanyModel> get copyWith =>
      throw _privateConstructorUsedError;
}

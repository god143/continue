import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:json_annotation/json_annotation.dart';

part 'celebrity_challenge_result.freezed.dart';
part 'celebrity_challenge_result.g.dart';

@freezed
class CelebrityChallengeResult with _$CelebrityChallengeResult {
  @JsonSerializable(fieldRename: FieldRename.none)
  factory CelebrityChallengeResult({
    required CelebrityProfile celebrityProfile,
    @JsonKey(defaultValue: 0) required double userDailyPortfolioGainPercentage,
    @JsonKey(defaultValue: 0) required double userWeeklyPortfolioGainPercentage,
    @JsonKey(defaultValue: 0) required double celebDailyPortfolioGainPercentage,
    @JsonKey(defaultValue: 0) required double celebWeeklyPortfolioGainPercentage,
    @JsonKey(defaultValue: []) required List<TopGainHoldingItem> userDailyTopGainHoldings,
    @JsonKey(defaultValue: []) required List<TopGainHoldingItem> userWeeklyTopGainHoldings,
    @JsonKey(defaultValue: []) required List<TopGainHoldingItem> celebDailyTopGainHoldings,
    @JsonKey(defaultValue: []) required List<TopGainHoldingItem> celebWeeklyTopGainHoldings,
  }) = _CelebrityChallengeResult;

  factory CelebrityChallengeResult.fromJson(Map<String, dynamic> json) => _$CelebrityChallengeResultFromJson(json);
}

@freezed
class CelebrityProfile with _$CelebrityProfile {
  @JsonSerializable(fieldRename: FieldRename.none)
  factory CelebrityProfile({
    required String displayName,
    required String username,
    String? dpThumbnail,
  }) = _CelebrityProfile;

  factory CelebrityProfile.fromJson(Map<String, dynamic> json) => _$CelebrityProfileFromJson(json);
}

@freezed
class TopGainHoldingItem with _$TopGainHoldingItem {
  @JsonSerializable(fieldRename: FieldRename.none)
  factory TopGainHoldingItem({
    @JsonKey(name: 'company_id') required int companyId,
    required String displayName,
    String? logoUrl,
  }) = _TopGainHoldingItem;

  factory TopGainHoldingItem.fromJson(Map<String, dynamic> json) => _$TopGainHoldingItemFromJson(json);
}

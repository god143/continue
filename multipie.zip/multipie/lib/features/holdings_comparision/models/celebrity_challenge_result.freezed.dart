// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'celebrity_challenge_result.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

CelebrityChallengeResult _$CelebrityChallengeResultFromJson(
    Map<String, dynamic> json) {
  return _CelebrityChallengeResult.fromJson(json);
}

/// @nodoc
mixin _$CelebrityChallengeResult {
  CelebrityProfile get celebrityProfile => throw _privateConstructorUsedError;
  @JsonKey(defaultValue: 0)
  double get userDailyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: 0)
  double get userWeeklyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: 0)
  double get celebDailyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: 0)
  double get celebWeeklyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get userDailyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get userWeeklyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get celebDailyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get celebWeeklyTopGainHoldings =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CelebrityChallengeResultCopyWith<CelebrityChallengeResult> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CelebrityChallengeResultCopyWith<$Res> {
  factory $CelebrityChallengeResultCopyWith(CelebrityChallengeResult value,
          $Res Function(CelebrityChallengeResult) then) =
      _$CelebrityChallengeResultCopyWithImpl<$Res>;
  $Res call(
      {CelebrityProfile celebrityProfile,
      @JsonKey(defaultValue: 0)
          double userDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          double userWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          double celebDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          double celebWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> userDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> userWeeklyTopGainHoldings,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> celebDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> celebWeeklyTopGainHoldings});

  $CelebrityProfileCopyWith<$Res> get celebrityProfile;
}

/// @nodoc
class _$CelebrityChallengeResultCopyWithImpl<$Res>
    implements $CelebrityChallengeResultCopyWith<$Res> {
  _$CelebrityChallengeResultCopyWithImpl(this._value, this._then);

  final CelebrityChallengeResult _value;
  // ignore: unused_field
  final $Res Function(CelebrityChallengeResult) _then;

  @override
  $Res call({
    Object? celebrityProfile = freezed,
    Object? userDailyPortfolioGainPercentage = freezed,
    Object? userWeeklyPortfolioGainPercentage = freezed,
    Object? celebDailyPortfolioGainPercentage = freezed,
    Object? celebWeeklyPortfolioGainPercentage = freezed,
    Object? userDailyTopGainHoldings = freezed,
    Object? userWeeklyTopGainHoldings = freezed,
    Object? celebDailyTopGainHoldings = freezed,
    Object? celebWeeklyTopGainHoldings = freezed,
  }) {
    return _then(_value.copyWith(
      celebrityProfile: celebrityProfile == freezed
          ? _value.celebrityProfile
          : celebrityProfile // ignore: cast_nullable_to_non_nullable
              as CelebrityProfile,
      userDailyPortfolioGainPercentage: userDailyPortfolioGainPercentage ==
              freezed
          ? _value.userDailyPortfolioGainPercentage
          : userDailyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      userWeeklyPortfolioGainPercentage: userWeeklyPortfolioGainPercentage ==
              freezed
          ? _value.userWeeklyPortfolioGainPercentage
          : userWeeklyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      celebDailyPortfolioGainPercentage: celebDailyPortfolioGainPercentage ==
              freezed
          ? _value.celebDailyPortfolioGainPercentage
          : celebDailyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      celebWeeklyPortfolioGainPercentage: celebWeeklyPortfolioGainPercentage ==
              freezed
          ? _value.celebWeeklyPortfolioGainPercentage
          : celebWeeklyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      userDailyTopGainHoldings: userDailyTopGainHoldings == freezed
          ? _value.userDailyTopGainHoldings
          : userDailyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
      userWeeklyTopGainHoldings: userWeeklyTopGainHoldings == freezed
          ? _value.userWeeklyTopGainHoldings
          : userWeeklyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
      celebDailyTopGainHoldings: celebDailyTopGainHoldings == freezed
          ? _value.celebDailyTopGainHoldings
          : celebDailyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
      celebWeeklyTopGainHoldings: celebWeeklyTopGainHoldings == freezed
          ? _value.celebWeeklyTopGainHoldings
          : celebWeeklyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
    ));
  }

  @override
  $CelebrityProfileCopyWith<$Res> get celebrityProfile {
    return $CelebrityProfileCopyWith<$Res>(_value.celebrityProfile, (value) {
      return _then(_value.copyWith(celebrityProfile: value));
    });
  }
}

/// @nodoc
abstract class _$$_CelebrityChallengeResultCopyWith<$Res>
    implements $CelebrityChallengeResultCopyWith<$Res> {
  factory _$$_CelebrityChallengeResultCopyWith(
          _$_CelebrityChallengeResult value,
          $Res Function(_$_CelebrityChallengeResult) then) =
      __$$_CelebrityChallengeResultCopyWithImpl<$Res>;
  @override
  $Res call(
      {CelebrityProfile celebrityProfile,
      @JsonKey(defaultValue: 0)
          double userDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          double userWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          double celebDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          double celebWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> userDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> userWeeklyTopGainHoldings,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> celebDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          List<TopGainHoldingItem> celebWeeklyTopGainHoldings});

  @override
  $CelebrityProfileCopyWith<$Res> get celebrityProfile;
}

/// @nodoc
class __$$_CelebrityChallengeResultCopyWithImpl<$Res>
    extends _$CelebrityChallengeResultCopyWithImpl<$Res>
    implements _$$_CelebrityChallengeResultCopyWith<$Res> {
  __$$_CelebrityChallengeResultCopyWithImpl(_$_CelebrityChallengeResult _value,
      $Res Function(_$_CelebrityChallengeResult) _then)
      : super(_value, (v) => _then(v as _$_CelebrityChallengeResult));

  @override
  _$_CelebrityChallengeResult get _value =>
      super._value as _$_CelebrityChallengeResult;

  @override
  $Res call({
    Object? celebrityProfile = freezed,
    Object? userDailyPortfolioGainPercentage = freezed,
    Object? userWeeklyPortfolioGainPercentage = freezed,
    Object? celebDailyPortfolioGainPercentage = freezed,
    Object? celebWeeklyPortfolioGainPercentage = freezed,
    Object? userDailyTopGainHoldings = freezed,
    Object? userWeeklyTopGainHoldings = freezed,
    Object? celebDailyTopGainHoldings = freezed,
    Object? celebWeeklyTopGainHoldings = freezed,
  }) {
    return _then(_$_CelebrityChallengeResult(
      celebrityProfile: celebrityProfile == freezed
          ? _value.celebrityProfile
          : celebrityProfile // ignore: cast_nullable_to_non_nullable
              as CelebrityProfile,
      userDailyPortfolioGainPercentage: userDailyPortfolioGainPercentage ==
              freezed
          ? _value.userDailyPortfolioGainPercentage
          : userDailyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      userWeeklyPortfolioGainPercentage: userWeeklyPortfolioGainPercentage ==
              freezed
          ? _value.userWeeklyPortfolioGainPercentage
          : userWeeklyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      celebDailyPortfolioGainPercentage: celebDailyPortfolioGainPercentage ==
              freezed
          ? _value.celebDailyPortfolioGainPercentage
          : celebDailyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      celebWeeklyPortfolioGainPercentage: celebWeeklyPortfolioGainPercentage ==
              freezed
          ? _value.celebWeeklyPortfolioGainPercentage
          : celebWeeklyPortfolioGainPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      userDailyTopGainHoldings: userDailyTopGainHoldings == freezed
          ? _value._userDailyTopGainHoldings
          : userDailyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
      userWeeklyTopGainHoldings: userWeeklyTopGainHoldings == freezed
          ? _value._userWeeklyTopGainHoldings
          : userWeeklyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
      celebDailyTopGainHoldings: celebDailyTopGainHoldings == freezed
          ? _value._celebDailyTopGainHoldings
          : celebDailyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
      celebWeeklyTopGainHoldings: celebWeeklyTopGainHoldings == freezed
          ? _value._celebWeeklyTopGainHoldings
          : celebWeeklyTopGainHoldings // ignore: cast_nullable_to_non_nullable
              as List<TopGainHoldingItem>,
    ));
  }
}

/// @nodoc

@JsonSerializable(fieldRename: FieldRename.none)
class _$_CelebrityChallengeResult implements _CelebrityChallengeResult {
  _$_CelebrityChallengeResult(
      {required this.celebrityProfile,
      @JsonKey(defaultValue: 0)
          required this.userDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          required this.userWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          required this.celebDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          required this.celebWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> userDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> userWeeklyTopGainHoldings,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> celebDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> celebWeeklyTopGainHoldings})
      : _userDailyTopGainHoldings = userDailyTopGainHoldings,
        _userWeeklyTopGainHoldings = userWeeklyTopGainHoldings,
        _celebDailyTopGainHoldings = celebDailyTopGainHoldings,
        _celebWeeklyTopGainHoldings = celebWeeklyTopGainHoldings;

  factory _$_CelebrityChallengeResult.fromJson(Map<String, dynamic> json) =>
      _$$_CelebrityChallengeResultFromJson(json);

  @override
  final CelebrityProfile celebrityProfile;
  @override
  @JsonKey(defaultValue: 0)
  final double userDailyPortfolioGainPercentage;
  @override
  @JsonKey(defaultValue: 0)
  final double userWeeklyPortfolioGainPercentage;
  @override
  @JsonKey(defaultValue: 0)
  final double celebDailyPortfolioGainPercentage;
  @override
  @JsonKey(defaultValue: 0)
  final double celebWeeklyPortfolioGainPercentage;
  final List<TopGainHoldingItem> _userDailyTopGainHoldings;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get userDailyTopGainHoldings {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_userDailyTopGainHoldings);
  }

  final List<TopGainHoldingItem> _userWeeklyTopGainHoldings;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get userWeeklyTopGainHoldings {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_userWeeklyTopGainHoldings);
  }

  final List<TopGainHoldingItem> _celebDailyTopGainHoldings;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get celebDailyTopGainHoldings {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_celebDailyTopGainHoldings);
  }

  final List<TopGainHoldingItem> _celebWeeklyTopGainHoldings;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get celebWeeklyTopGainHoldings {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_celebWeeklyTopGainHoldings);
  }

  @override
  String toString() {
    return 'CelebrityChallengeResult(celebrityProfile: $celebrityProfile, userDailyPortfolioGainPercentage: $userDailyPortfolioGainPercentage, userWeeklyPortfolioGainPercentage: $userWeeklyPortfolioGainPercentage, celebDailyPortfolioGainPercentage: $celebDailyPortfolioGainPercentage, celebWeeklyPortfolioGainPercentage: $celebWeeklyPortfolioGainPercentage, userDailyTopGainHoldings: $userDailyTopGainHoldings, userWeeklyTopGainHoldings: $userWeeklyTopGainHoldings, celebDailyTopGainHoldings: $celebDailyTopGainHoldings, celebWeeklyTopGainHoldings: $celebWeeklyTopGainHoldings)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CelebrityChallengeResult &&
            const DeepCollectionEquality()
                .equals(other.celebrityProfile, celebrityProfile) &&
            const DeepCollectionEquality().equals(
                other.userDailyPortfolioGainPercentage,
                userDailyPortfolioGainPercentage) &&
            const DeepCollectionEquality().equals(
                other.userWeeklyPortfolioGainPercentage,
                userWeeklyPortfolioGainPercentage) &&
            const DeepCollectionEquality().equals(
                other.celebDailyPortfolioGainPercentage,
                celebDailyPortfolioGainPercentage) &&
            const DeepCollectionEquality().equals(
                other.celebWeeklyPortfolioGainPercentage,
                celebWeeklyPortfolioGainPercentage) &&
            const DeepCollectionEquality().equals(
                other._userDailyTopGainHoldings, _userDailyTopGainHoldings) &&
            const DeepCollectionEquality().equals(
                other._userWeeklyTopGainHoldings, _userWeeklyTopGainHoldings) &&
            const DeepCollectionEquality().equals(
                other._celebDailyTopGainHoldings, _celebDailyTopGainHoldings) &&
            const DeepCollectionEquality().equals(
                other._celebWeeklyTopGainHoldings,
                _celebWeeklyTopGainHoldings));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(celebrityProfile),
      const DeepCollectionEquality().hash(userDailyPortfolioGainPercentage),
      const DeepCollectionEquality().hash(userWeeklyPortfolioGainPercentage),
      const DeepCollectionEquality().hash(celebDailyPortfolioGainPercentage),
      const DeepCollectionEquality().hash(celebWeeklyPortfolioGainPercentage),
      const DeepCollectionEquality().hash(_userDailyTopGainHoldings),
      const DeepCollectionEquality().hash(_userWeeklyTopGainHoldings),
      const DeepCollectionEquality().hash(_celebDailyTopGainHoldings),
      const DeepCollectionEquality().hash(_celebWeeklyTopGainHoldings));

  @JsonKey(ignore: true)
  @override
  _$$_CelebrityChallengeResultCopyWith<_$_CelebrityChallengeResult>
      get copyWith => __$$_CelebrityChallengeResultCopyWithImpl<
          _$_CelebrityChallengeResult>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CelebrityChallengeResultToJson(this);
  }
}

abstract class _CelebrityChallengeResult implements CelebrityChallengeResult {
  factory _CelebrityChallengeResult(
      {required final CelebrityProfile celebrityProfile,
      @JsonKey(defaultValue: 0)
          required final double userDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          required final double userWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          required final double celebDailyPortfolioGainPercentage,
      @JsonKey(defaultValue: 0)
          required final double celebWeeklyPortfolioGainPercentage,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> userDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> userWeeklyTopGainHoldings,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem> celebDailyTopGainHoldings,
      @JsonKey(defaultValue: [])
          required final List<TopGainHoldingItem>
              celebWeeklyTopGainHoldings}) = _$_CelebrityChallengeResult;

  factory _CelebrityChallengeResult.fromJson(Map<String, dynamic> json) =
      _$_CelebrityChallengeResult.fromJson;

  @override
  CelebrityProfile get celebrityProfile => throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: 0)
  double get userDailyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: 0)
  double get userWeeklyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: 0)
  double get celebDailyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: 0)
  double get celebWeeklyPortfolioGainPercentage =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get userDailyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get userWeeklyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get celebDailyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(defaultValue: [])
  List<TopGainHoldingItem> get celebWeeklyTopGainHoldings =>
      throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_CelebrityChallengeResultCopyWith<_$_CelebrityChallengeResult>
      get copyWith => throw _privateConstructorUsedError;
}

CelebrityProfile _$CelebrityProfileFromJson(Map<String, dynamic> json) {
  return _CelebrityProfile.fromJson(json);
}

/// @nodoc
mixin _$CelebrityProfile {
  String get displayName => throw _privateConstructorUsedError;
  String get username => throw _privateConstructorUsedError;
  String? get dpThumbnail => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CelebrityProfileCopyWith<CelebrityProfile> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CelebrityProfileCopyWith<$Res> {
  factory $CelebrityProfileCopyWith(
          CelebrityProfile value, $Res Function(CelebrityProfile) then) =
      _$CelebrityProfileCopyWithImpl<$Res>;
  $Res call({String displayName, String username, String? dpThumbnail});
}

/// @nodoc
class _$CelebrityProfileCopyWithImpl<$Res>
    implements $CelebrityProfileCopyWith<$Res> {
  _$CelebrityProfileCopyWithImpl(this._value, this._then);

  final CelebrityProfile _value;
  // ignore: unused_field
  final $Res Function(CelebrityProfile) _then;

  @override
  $Res call({
    Object? displayName = freezed,
    Object? username = freezed,
    Object? dpThumbnail = freezed,
  }) {
    return _then(_value.copyWith(
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      username: username == freezed
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String,
      dpThumbnail: dpThumbnail == freezed
          ? _value.dpThumbnail
          : dpThumbnail // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
abstract class _$$_CelebrityProfileCopyWith<$Res>
    implements $CelebrityProfileCopyWith<$Res> {
  factory _$$_CelebrityProfileCopyWith(
          _$_CelebrityProfile value, $Res Function(_$_CelebrityProfile) then) =
      __$$_CelebrityProfileCopyWithImpl<$Res>;
  @override
  $Res call({String displayName, String username, String? dpThumbnail});
}

/// @nodoc
class __$$_CelebrityProfileCopyWithImpl<$Res>
    extends _$CelebrityProfileCopyWithImpl<$Res>
    implements _$$_CelebrityProfileCopyWith<$Res> {
  __$$_CelebrityProfileCopyWithImpl(
      _$_CelebrityProfile _value, $Res Function(_$_CelebrityProfile) _then)
      : super(_value, (v) => _then(v as _$_CelebrityProfile));

  @override
  _$_CelebrityProfile get _value => super._value as _$_CelebrityProfile;

  @override
  $Res call({
    Object? displayName = freezed,
    Object? username = freezed,
    Object? dpThumbnail = freezed,
  }) {
    return _then(_$_CelebrityProfile(
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      username: username == freezed
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String,
      dpThumbnail: dpThumbnail == freezed
          ? _value.dpThumbnail
          : dpThumbnail // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(fieldRename: FieldRename.none)
class _$_CelebrityProfile implements _CelebrityProfile {
  _$_CelebrityProfile(
      {required this.displayName, required this.username, this.dpThumbnail});

  factory _$_CelebrityProfile.fromJson(Map<String, dynamic> json) =>
      _$$_CelebrityProfileFromJson(json);

  @override
  final String displayName;
  @override
  final String username;
  @override
  final String? dpThumbnail;

  @override
  String toString() {
    return 'CelebrityProfile(displayName: $displayName, username: $username, dpThumbnail: $dpThumbnail)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CelebrityProfile &&
            const DeepCollectionEquality()
                .equals(other.displayName, displayName) &&
            const DeepCollectionEquality().equals(other.username, username) &&
            const DeepCollectionEquality()
                .equals(other.dpThumbnail, dpThumbnail));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(displayName),
      const DeepCollectionEquality().hash(username),
      const DeepCollectionEquality().hash(dpThumbnail));

  @JsonKey(ignore: true)
  @override
  _$$_CelebrityProfileCopyWith<_$_CelebrityProfile> get copyWith =>
      __$$_CelebrityProfileCopyWithImpl<_$_CelebrityProfile>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CelebrityProfileToJson(this);
  }
}

abstract class _CelebrityProfile implements CelebrityProfile {
  factory _CelebrityProfile(
      {required final String displayName,
      required final String username,
      final String? dpThumbnail}) = _$_CelebrityProfile;

  factory _CelebrityProfile.fromJson(Map<String, dynamic> json) =
      _$_CelebrityProfile.fromJson;

  @override
  String get displayName => throw _privateConstructorUsedError;
  @override
  String get username => throw _privateConstructorUsedError;
  @override
  String? get dpThumbnail => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_CelebrityProfileCopyWith<_$_CelebrityProfile> get copyWith =>
      throw _privateConstructorUsedError;
}

TopGainHoldingItem _$TopGainHoldingItemFromJson(Map<String, dynamic> json) {
  return _TopGainHoldingItem.fromJson(json);
}

/// @nodoc
mixin _$TopGainHoldingItem {
  @JsonKey(name: 'company_id')
  int get companyId => throw _privateConstructorUsedError;
  String get displayName => throw _privateConstructorUsedError;
  String? get logoUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TopGainHoldingItemCopyWith<TopGainHoldingItem> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TopGainHoldingItemCopyWith<$Res> {
  factory $TopGainHoldingItemCopyWith(
          TopGainHoldingItem value, $Res Function(TopGainHoldingItem) then) =
      _$TopGainHoldingItemCopyWithImpl<$Res>;
  $Res call(
      {@JsonKey(name: 'company_id') int companyId,
      String displayName,
      String? logoUrl});
}

/// @nodoc
class _$TopGainHoldingItemCopyWithImpl<$Res>
    implements $TopGainHoldingItemCopyWith<$Res> {
  _$TopGainHoldingItemCopyWithImpl(this._value, this._then);

  final TopGainHoldingItem _value;
  // ignore: unused_field
  final $Res Function(TopGainHoldingItem) _then;

  @override
  $Res call({
    Object? companyId = freezed,
    Object? displayName = freezed,
    Object? logoUrl = freezed,
  }) {
    return _then(_value.copyWith(
      companyId: companyId == freezed
          ? _value.companyId
          : companyId // ignore: cast_nullable_to_non_nullable
              as int,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      logoUrl: logoUrl == freezed
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
abstract class _$$_TopGainHoldingItemCopyWith<$Res>
    implements $TopGainHoldingItemCopyWith<$Res> {
  factory _$$_TopGainHoldingItemCopyWith(_$_TopGainHoldingItem value,
          $Res Function(_$_TopGainHoldingItem) then) =
      __$$_TopGainHoldingItemCopyWithImpl<$Res>;
  @override
  $Res call(
      {@JsonKey(name: 'company_id') int companyId,
      String displayName,
      String? logoUrl});
}

/// @nodoc
class __$$_TopGainHoldingItemCopyWithImpl<$Res>
    extends _$TopGainHoldingItemCopyWithImpl<$Res>
    implements _$$_TopGainHoldingItemCopyWith<$Res> {
  __$$_TopGainHoldingItemCopyWithImpl(
      _$_TopGainHoldingItem _value, $Res Function(_$_TopGainHoldingItem) _then)
      : super(_value, (v) => _then(v as _$_TopGainHoldingItem));

  @override
  _$_TopGainHoldingItem get _value => super._value as _$_TopGainHoldingItem;

  @override
  $Res call({
    Object? companyId = freezed,
    Object? displayName = freezed,
    Object? logoUrl = freezed,
  }) {
    return _then(_$_TopGainHoldingItem(
      companyId: companyId == freezed
          ? _value.companyId
          : companyId // ignore: cast_nullable_to_non_nullable
              as int,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      logoUrl: logoUrl == freezed
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(fieldRename: FieldRename.none)
class _$_TopGainHoldingItem implements _TopGainHoldingItem {
  _$_TopGainHoldingItem(
      {@JsonKey(name: 'company_id') required this.companyId,
      required this.displayName,
      this.logoUrl});

  factory _$_TopGainHoldingItem.fromJson(Map<String, dynamic> json) =>
      _$$_TopGainHoldingItemFromJson(json);

  @override
  @JsonKey(name: 'company_id')
  final int companyId;
  @override
  final String displayName;
  @override
  final String? logoUrl;

  @override
  String toString() {
    return 'TopGainHoldingItem(companyId: $companyId, displayName: $displayName, logoUrl: $logoUrl)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_TopGainHoldingItem &&
            const DeepCollectionEquality().equals(other.companyId, companyId) &&
            const DeepCollectionEquality()
                .equals(other.displayName, displayName) &&
            const DeepCollectionEquality().equals(other.logoUrl, logoUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(companyId),
      const DeepCollectionEquality().hash(displayName),
      const DeepCollectionEquality().hash(logoUrl));

  @JsonKey(ignore: true)
  @override
  _$$_TopGainHoldingItemCopyWith<_$_TopGainHoldingItem> get copyWith =>
      __$$_TopGainHoldingItemCopyWithImpl<_$_TopGainHoldingItem>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_TopGainHoldingItemToJson(this);
  }
}

abstract class _TopGainHoldingItem implements TopGainHoldingItem {
  factory _TopGainHoldingItem(
      {@JsonKey(name: 'company_id') required final int companyId,
      required final String displayName,
      final String? logoUrl}) = _$_TopGainHoldingItem;

  factory _TopGainHoldingItem.fromJson(Map<String, dynamic> json) =
      _$_TopGainHoldingItem.fromJson;

  @override
  @JsonKey(name: 'company_id')
  int get companyId => throw _privateConstructorUsedError;
  @override
  String get displayName => throw _privateConstructorUsedError;
  @override
  String? get logoUrl => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_TopGainHoldingItemCopyWith<_$_TopGainHoldingItem> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:freezed_annotation/freezed_annotation.dart';

part 'holdings_comparision_model.freezed.dart';
part 'holdings_comparision_model.g.dart';

@freezed
class HoldingsComparisionModel with _$HoldingsComparisionModel {
  factory HoldingsComparisionModel({
    String? name,
    required int userId,
    required String username,
    required String displayName,
    String? displayPic,
    required double percentageMatch,
    required List<CommonCompanyModel> commonCompanies,
  }) = _HoldingsComparisionModel;

  factory HoldingsComparisionModel.fromJson(Map<String, dynamic> json) => _$HoldingsComparisionModelFromJson(json);
}

@freezed
class CommonCompanyModel with _$CommonCompanyModel {
  factory CommonCompanyModel({
    required String name,
    String? icon,
    required int instrumentId,
  }) = _CommonCompanyModel;

  factory CommonCompanyModel.fromJson(Map<String, dynamic> json) => _$CommonCompanyModelFromJson(json);
}

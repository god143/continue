// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'celebrity_challenge_result.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CelebrityChallengeResult _$$_CelebrityChallengeResultFromJson(
        Map<String, dynamic> json) =>
    _$_CelebrityChallengeResult(
      celebrityProfile: CelebrityProfile.fromJson(
          json['celebrityProfile'] as Map<String, dynamic>),
      userDailyPortfolioGainPercentage:
          (json['userDailyPortfolioGainPercentage'] as num?)?.toDouble() ?? 0,
      userWeeklyPortfolioGainPercentage:
          (json['userWeeklyPortfolioGainPercentage'] as num?)?.toDouble() ?? 0,
      celebDailyPortfolioGainPercentage:
          (json['celebDailyPortfolioGainPercentage'] as num?)?.toDouble() ?? 0,
      celebWeeklyPortfolioGainPercentage:
          (json['celebWeeklyPortfolioGainPercentage'] as num?)?.toDouble() ?? 0,
      userDailyTopGainHoldings: (json['userDailyTopGainHoldings']
                  as List<dynamic>?)
              ?.map(
                  (e) => TopGainHoldingItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      userWeeklyTopGainHoldings: (json['userWeeklyTopGainHoldings']
                  as List<dynamic>?)
              ?.map(
                  (e) => TopGainHoldingItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      celebDailyTopGainHoldings: (json['celebDailyTopGainHoldings']
                  as List<dynamic>?)
              ?.map(
                  (e) => TopGainHoldingItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      celebWeeklyTopGainHoldings: (json['celebWeeklyTopGainHoldings']
                  as List<dynamic>?)
              ?.map(
                  (e) => TopGainHoldingItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );

Map<String, dynamic> _$$_CelebrityChallengeResultToJson(
        _$_CelebrityChallengeResult instance) =>
    <String, dynamic>{
      'celebrityProfile': instance.celebrityProfile,
      'userDailyPortfolioGainPercentage':
          instance.userDailyPortfolioGainPercentage,
      'userWeeklyPortfolioGainPercentage':
          instance.userWeeklyPortfolioGainPercentage,
      'celebDailyPortfolioGainPercentage':
          instance.celebDailyPortfolioGainPercentage,
      'celebWeeklyPortfolioGainPercentage':
          instance.celebWeeklyPortfolioGainPercentage,
      'userDailyTopGainHoldings': instance.userDailyTopGainHoldings,
      'userWeeklyTopGainHoldings': instance.userWeeklyTopGainHoldings,
      'celebDailyTopGainHoldings': instance.celebDailyTopGainHoldings,
      'celebWeeklyTopGainHoldings': instance.celebWeeklyTopGainHoldings,
    };

_$_CelebrityProfile _$$_CelebrityProfileFromJson(Map<String, dynamic> json) =>
    _$_CelebrityProfile(
      displayName: json['displayName'] as String,
      username: json['username'] as String,
      dpThumbnail: json['dpThumbnail'] as String?,
    );

Map<String, dynamic> _$$_CelebrityProfileToJson(_$_CelebrityProfile instance) =>
    <String, dynamic>{
      'displayName': instance.displayName,
      'username': instance.username,
      'dpThumbnail': instance.dpThumbnail,
    };

_$_TopGainHoldingItem _$$_TopGainHoldingItemFromJson(
        Map<String, dynamic> json) =>
    _$_TopGainHoldingItem(
      companyId: json['company_id'] as int,
      displayName: json['displayName'] as String,
      logoUrl: json['logoUrl'] as String?,
    );

Map<String, dynamic> _$$_TopGainHoldingItemToJson(
        _$_TopGainHoldingItem instance) =>
    <String, dynamic>{
      'company_id': instance.companyId,
      'displayName': instance.displayName,
      'logoUrl': instance.logoUrl,
    };

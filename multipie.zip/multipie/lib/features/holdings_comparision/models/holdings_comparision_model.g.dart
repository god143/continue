// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'holdings_comparision_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_HoldingsComparisionModel _$$_HoldingsComparisionModelFromJson(
        Map<String, dynamic> json) =>
    _$_HoldingsComparisionModel(
      name: json['name'] as String?,
      userId: json['user_id'] as int,
      username: json['username'] as String,
      displayName: json['display_name'] as String,
      displayPic: json['display_pic'] as String?,
      percentageMatch: (json['percentage_match'] as num).toDouble(),
      commonCompanies: (json['common_companies'] as List<dynamic>)
          .map((e) => CommonCompanyModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_HoldingsComparisionModelToJson(
        _$_HoldingsComparisionModel instance) =>
    <String, dynamic>{
      'name': instance.name,
      'user_id': instance.userId,
      'username': instance.username,
      'display_name': instance.displayName,
      'display_pic': instance.displayPic,
      'percentage_match': instance.percentageMatch,
      'common_companies': instance.commonCompanies,
    };

_$_CommonCompanyModel _$$_CommonCompanyModelFromJson(
        Map<String, dynamic> json) =>
    _$_CommonCompanyModel(
      name: json['name'] as String,
      icon: json['icon'] as String?,
      instrumentId: json['instrument_id'] as int,
    );

Map<String, dynamic> _$$_CommonCompanyModelToJson(
        _$_CommonCompanyModel instance) =>
    <String, dynamic>{
      'name': instance.name,
      'icon': instance.icon,
      'instrument_id': instance.instrumentId,
    };

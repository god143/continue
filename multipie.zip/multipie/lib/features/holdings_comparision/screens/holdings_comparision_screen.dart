import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/mp_avatar.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/features/holdings_comparision/cubit/holdings_comparision_cubit.dart';
import 'package:multipie/features/holdings_comparision/models/holdings_comparision_model.dart';
import 'package:multipie/features/holdings_comparision/screens/celebrity_challenge_screen.dart';
import 'package:multipie/locator.dart';
import 'package:provider/provider.dart';

class HoldingsComparisionScreen extends StatelessWidget {
  const HoldingsComparisionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Provider(
      create: (_) => HoldingsComparisionCubit(
        holdingsRepository: locator(),
      ),
      child: Scaffold(
        appBar: MultipieAppBar(
          title: 'You v/s Superstar Portfolios',
        ),
        body: _Body(),
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HoldingsComparisionCubit, HoldingsComparisionState>(
      builder: (context, state) {
        if (state.isLoading) {
          return Center(
            child: MPLoadingIndicator(),
          );
        } else if (state.holdings.isEmpty) {
          return Center(
            child: Text(
              'No data available',
              style: mpHeadLine6(context: context),
            ),
          );
        } else {
          return _SuperstarsList(data: state.holdings);
        }
      },
    );
  }
}

class _SuperstarsList extends StatelessWidget {
  const _SuperstarsList({
    Key? key,
    required this.data,
  }) : super(key: key);

  final List<HoldingsComparisionModel> data;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (context, index) {
        final model = data[index];
        return _ListItem(
          key: Key(model.username),
          model: model,
        );
      },
      itemCount: data.length,
    );
  }
}

class _ListItem extends StatefulWidget {
  const _ListItem({
    Key? key,
    required this.model,
  }) : super(key: key);

  final HoldingsComparisionModel model;

  @override
  State<_ListItem> createState() => __ListItemState();
}

class __ListItemState extends State<_ListItem> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final hasCommonCompanies = widget.model.commonCompanies.isNotEmpty;
    return Container(
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        color: context.appTheme.cardBackgroundColor,
        border: Border.all(
          color: context.appTheme.borderColor,
          width: 0.5,
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: AnimatedSize(
        curve: Curves.easeInOut,
        duration: Duration(milliseconds: 250),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: [
                  MPAvatar(
                    size: 44,
                    imageUrl: '${Constants.BASE_URL}${widget.model.displayPic}',
                    placeholderText: widget.model.displayName.characters.firstOrNull ?? '?',
                    isCircular: true,
                  ),
                  Expanded(
                    flex: 3,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            widget.model.displayName,
                            style: mpHeadLine5(
                              context: context,
                              textColor: context.appTheme.primaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                          ),
                          SizedBox(height: 2),
                          Text(
                            '@${widget.model.username}',
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.secondaryTextColor,
                            ),
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: context.appTheme.primaryColor,
                            ),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  backgroundColor: context.appTheme.transparentColor,
                                  value: widget.model.percentageMatch / 100,
                                  color: context.appTheme.progressBarColor,
                                  minHeight: 20,
                                ),
                              ),
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8, top: 2),
                                    child: Center(
                                      child: Text(
                                        '${widget.model.percentageMatch.formatAsString()}%',
                                        style: mpHeadLine6(
                                          context: context,
                                          textColor: context.appTheme.primaryColor,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 8),
                        InkWell(
                          onTap: () {
                            CleverTapPlugin.recordEvent('Challenge a superstar', {});
                            Navigator.of(context).push(
                              MaterialPageRoute<CelebrityChallengeScreen>(
                                builder: (_) {
                                  return CelebrityChallengeScreen(
                                    celebrityUserId: widget.model.userId.toString(),
                                  );
                                },
                              ),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: context.appTheme.primaryColor,
                              ),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Challenge',
                                textAlign: TextAlign.center,
                                style: mpHeadLine6(
                                  context: context,
                                  textColor: context.appTheme.primaryColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: hasCommonCompanies
                  ? () => setState(
                        () {
                          _isExpanded = !_isExpanded;
                        },
                      )
                  : null,
              child: Container(
                decoration: BoxDecoration(
                  color: context.appTheme.expandableTileHeaderColor,
                  borderRadius: !_isExpanded
                      ? BorderRadius.only(
                          bottomLeft: Radius.circular(6),
                          bottomRight: Radius.circular(6),
                        )
                      : null,
                ),
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        hasCommonCompanies ? 'View common stocks' : 'No common Stocks',
                        style: mpHeadLine5(context: context),
                      ),
                    ),
                    SizedBox(width: 8),
                    if (hasCommonCompanies)
                      Icon(
                        _isExpanded ? Icons.keyboard_arrow_up_outlined : Icons.keyboard_arrow_down_outlined,
                        color: context.appTheme.primaryTextColor,
                      ),
                  ],
                ),
              ),
            ),
            if (_isExpanded)
              Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 4,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: widget.model.commonCompanies
                      .map(
                        (c) => Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Text(
                            c.name,
                            style: mpHeadLine6(context: context),
                            maxLines: 1,
                          ),
                        ),
                      )
                      .toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

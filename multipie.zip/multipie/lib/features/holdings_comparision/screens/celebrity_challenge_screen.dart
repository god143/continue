import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/core/widgets/mp_avatar.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/features/for_you/presentation/widgets/toggle_duration_button.dart';
import 'package:multipie/features/holdings_comparision/cubit/celebrity_challenge/celebrity_challenge_cubit.dart';
import 'package:multipie/features/holdings_comparision/models/celebrity_challenge_result.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/bloc.dart';
import 'package:multipie/locator.dart';
import 'package:multipie/screens/company_screen/company_info_mobile_portrait.dart';
import 'package:provider/provider.dart';

class CelebrityChallengeScreen extends StatelessWidget {
  const CelebrityChallengeScreen({
    Key? key,
    required this.celebrityUserId,
  }) : super(key: key);

  final String celebrityUserId;

  @override
  Widget build(BuildContext context) {
    return Provider<CelebrityChallengeCubit>(
      create: (_) => CelebrityChallengeCubit(
        celebrityUserId: celebrityUserId,
        repository: locator(),
      ),
      child: BlocBuilder<CelebrityChallengeCubit, CelebrityChallengeState>(
        builder: (context, state) {
          return Scaffold(
            appBar: MultipieAppBar(
              title: [
                'Challenge',
                state.challengeResult?.celebrityProfile.displayName,
              ].where((element) => element != null).join(' '),
            ),
            body: _Body(),
          );
        },
      ),
    );
  }
}

enum _TabType {
  yourTopGainers,
  celebrityTopGainers,
}

const _tabNames = {
  _TabType.yourTopGainers: 'Your top gainers',
  _TabType.celebrityTopGainers: "Celebrity's top gainers",
};
const _tabs = [
  _TabType.yourTopGainers,
  _TabType.celebrityTopGainers,
];

class _Body extends StatefulWidget {
  const _Body({Key? key}) : super(key: key);

  @override
  State<_Body> createState() => _BodyState();
}

class _BodyState extends State<_Body> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(length: _tabs.length, vsync: this);
    context.read<CelebrityChallengeCubit>().fetchResult();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CelebrityChallengeCubit, CelebrityChallengeState>(
      builder: (context, state) {
        final user = context.read<UserProfileBloc>().currentUser!;
        final cubit = context.read<CelebrityChallengeCubit>();
        if (state.isLoading) {
          return Center(
            child: MPLoadingIndicator(),
          );
        } else if (state.challengeResult == null) {
          return Center(
            child: Text(
              'No data available!',
              style: mpHeadLine5(context: context),
            ),
          );
        } else {
          return NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              final challengeResult = state.challengeResult!;
              final celebrityProfile = challengeResult.celebrityProfile;
              bool isUserWon;
              if (state.selectedPeriod == '1d') {
                isUserWon = challengeResult.userDailyPortfolioGainPercentage >=
                    challengeResult.celebDailyPortfolioGainPercentage;
              } else {
                isUserWon = challengeResult.userWeeklyPortfolioGainPercentage >=
                    challengeResult.celebWeeklyPortfolioGainPercentage;
              }

              return [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: _UserTile(
                                displayName: user.displayname,
                                userName: user.username,
                                dpUrl: user.dpThumbnail,
                                changeInPercentages: state.selectedPeriod == '1d'
                                    ? challengeResult.userDailyPortfolioGainPercentage
                                    : challengeResult.userWeeklyPortfolioGainPercentage,
                              ),
                            ),
                            SizedBox(width: 20),
                            Column(
                              children: [
                                Text(
                                  'V/S',
                                  style: mpHeadLine4(context: context),
                                ),
                                SizedBox(height: 4),
                                ToggleDurationButton(
                                  value: state.selectedPeriod == '1d' ? 'for 1 day' : 'for 1 week',
                                  onPressed: () => cubit.togglePeriod(),
                                ),
                              ],
                            ),
                            SizedBox(width: 20),
                            Flexible(
                              child: _UserTile(
                                displayName: celebrityProfile.displayName,
                                userName: celebrityProfile.username,
                                dpUrl: (celebrityProfile.dpThumbnail == null || celebrityProfile.dpThumbnail!.isEmpty)
                                    ? ''
                                    : '${Constants.BASE_URL}${celebrityProfile.dpThumbnail}',
                                changeInPercentages: state.selectedPeriod == '1d'
                                    ? challengeResult.celebDailyPortfolioGainPercentage
                                    : challengeResult.celebWeeklyPortfolioGainPercentage,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20),
                        Center(
                          child: Text(
                            isUserWon ? 'You Won!' : 'You Lost!',
                            style: mpHeadLine2(context: context),
                          ),
                        ),
                        SizedBox(height: 8),
                        Center(
                          child: Text(
                            isUserWon
                                ? 'You have beaten ${celebrityProfile.displayName} - share it with your friends'
                                : 'Better luck next time. Afterall its very difficult to beat superstars',
                            style: mpHeadLine6(context: context),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SliverAppBar(
                  leading: SizedBox(),
                  leadingWidth: 0,
                  elevation: 0,
                  title: _TabBar(tabController: _tabController),
                  pinned: true,
                ),
              ];
            },
            body: TabBarView(
              controller: _tabController,
              children: [
                _HoldingsList(items: cubit.userHoldings),
                _HoldingsList(items: cubit.celebHoldings),
              ],
            ),
          );
        }
      },
    );
  }
}

class _UserTile extends StatelessWidget {
  const _UserTile({
    Key? key,
    required this.displayName,
    required this.userName,
    required this.dpUrl,
    required this.changeInPercentages,
  }) : super(key: key);

  final String displayName;
  final String userName;
  final String? dpUrl;
  final double changeInPercentages;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        MPAvatar(
          size: 64,
          imageUrl: dpUrl ?? '',
          placeholderText: displayName.characters.firstOrNull ?? '-',
          isCircular: true,
        ),
        SizedBox(height: 4),
        Text(
          displayName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: mpHeadLine4(
            context: context,
            fontWeight: FontWeight.w500,
            textColor: context.appTheme.activeIndicationColor,
          ),
        ),
        SizedBox(height: 2),
        Text(
          '@$userName',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: mpHeadLine6(
            context: context,
          ),
        ),
        SizedBox(height: 6),
        Text(
          '(${percentageConverter(changeInPercentages.toString())})',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: mpHeadLine6(
            context: context,
            textColor:
                changeInPercentages >= 0 ? context.appTheme.positiveGainColor : context.appTheme.negativeGainColor,
          ),
        )
      ],
    );
  }
}

class _TabBar extends StatefulWidget {
  const _TabBar({
    Key? key,
    required this.tabController,
  }) : super(key: key);

  final TabController tabController;

  @override
  State<_TabBar> createState() => _TabBarState();
}

class _TabBarState extends State<_TabBar> {
  late Key _tabBarKey;

  @override
  void initState() {
    _tabBarKey = Key('${widget.tabController.index}');
    widget.tabController.addListener(_onTabScrolled);
    super.initState();
  }

  void _onTabScrolled() {
    if (widget.tabController.indexIsChanging) {
      return;
    }
    setState(() {
      _tabBarKey = Key('${widget.tabController.index}');
    });
  }

  @override
  Widget build(BuildContext context) {
    return TabBar(
      key: _tabBarKey,
      controller: widget.tabController,
      indicatorWeight: 4,
      indicatorColor: context.appTheme.activeIndicationColor,
      tabs: _tabs
          .mapIndexed(
            (index, tabType) => _TabBarItem(
              title: _tabNames[tabType] ?? '?',
              isActive: index == widget.tabController.index,
            ),
          )
          .toList(),
    );
  }

  @override
  void dispose() {
    widget.tabController.removeListener(_onTabScrolled);
    super.dispose();
  }
}

class _TabBarItem extends StatelessWidget {
  const _TabBarItem({
    Key? key,
    required this.title,
    required this.isActive,
  }) : super(key: key);

  final String title;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    return Tab(
      child: Container(
        alignment: Alignment.center,
        child: Text(
          title,
          style: mpHeadLine5(
            context: context,
            textColor: isActive ? context.appTheme.primaryColor : context.appTheme.secondaryTextColor,
          ),
        ),
      ),
    );
  }
}

class _HoldingsList extends StatelessWidget {
  const _HoldingsList({
    Key? key,
    required this.items,
  }) : super(key: key);

  final List<TopGainHoldingItem> items;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemBuilder: (context, index) {
        final item = items[index];
        return ListTile(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => CompanyInfoMobilePortrait(
                  companyId: item.companyId.toString(),
                  companyName: item.displayName,
                ),
              ),
            );
          },
          leading: MPAvatar(
            size: 44,
            imageUrl: item.logoUrl == null || item.logoUrl!.isEmpty ? '' : '${Constants.BASE_URL}${item.logoUrl!}',
            placeholderText: item.displayName.characters.firstOrNull ?? '-',
            isCircular: true,
          ),
          title: Text(
            item.displayName,
            style: mpHeadLine5(context: context),
          ),
        );
      },
      separatorBuilder: (context, index) => Container(
        height: 0.5,
        margin: EdgeInsets.symmetric(vertical: 4),
        color: context.appTheme.borderColor.withOpacity(0.5),
      ),
      itemCount: items.length,
    );
  }
}

import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/custom_icon.dart';
import 'package:multipie/features/chat/presentation/cubit/chat_rooms/chat_rooms_cubit.dart';
import 'package:multipie/features/chat/presentation/screens/chat_rooms_screen.dart';
import 'package:multipie/features/chat/presentation/widgets/unread_messages_badge.dart';
import 'package:multipie/features/explore/presentation/screens/explore_search_active.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_explore_tab_view.dart';
import 'package:multipie/features/navigation_drawer/component/navigation_drawer_component.dart';
import 'package:multipie/features/reward/presentation/screens/reward_webview.dart';
import 'package:multipie/services/navigation_service.dart';

import 'explore_search_result.dart';

late GlobalKey<ExploreTabViewState> discoverPageKey;

class ExploreInitialScreen extends StatefulWidget {
  @override
  State<ExploreInitialScreen> createState() => _ExploreInitialScreenState();
}

class _ExploreInitialScreenState extends State<ExploreInitialScreen> {
  @override
  void initState() {
    discoverPageKey = GlobalKey<ExploreTabViewState>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: NavigationDrawerComponent(),
        titleSpacing: 0,
        elevation: 0,
        title: GestureDetector(
          onTap: () {
            Navigate.push(context, ExploreSearchActive());
          },
          child: Container(
            height: 40,
            margin: EdgeInsets.only(left: 12, right: 16),
            padding: EdgeInsets.only(left: 16),
            decoration: BoxDecoration(
                color: context.appTheme.searchBackground, borderRadius: BorderRadius.all(Radius.circular(10))),
            child: TextField(
              maxLines: 1,
              enabled: false,
              style: mpHeadLine4(
                context: context,
                textColor: context.appTheme.primaryTextColor,
              ),
              decoration: new InputDecoration(
                border: InputBorder.none,
                hintText: "Search",
                hintStyle: mpHeadLine4(
                  context: context,
                  textColor: context.appTheme.secondaryTextColor,
                ),
              ),
            ),
          ),
        ),
        actions: [
          InkWell(
            onTap: () {
              CleverTapPlugin.recordEvent('Reward', {'source': 'Discover'});
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => RewardWebView(),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.all(10),
              child: CustomIcon(
                CustomIcons.ic_reward,
                width: 24,
                height: 24,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute<ChatRoomsScreen>(
                  builder: (context) => ChatRoomsScreen(),
                ),
              );
              CleverTapPlugin.recordEvent('Chat Initiated', {'source': 'Discover'});
            },
            child: Stack(
              children: [
                Container(
                  margin: EdgeInsets.all(10),
                  child: CustomIcon(
                    CustomIcons.messages,
                    width: 24,
                    height: 24,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                BlocBuilder<ChatRoomsCubit, ChatRoomsState>(
                  builder: (context, state) {
                    final unreadCount = context.read<ChatRoomsCubit>().state.unreadMessagesCount;
                    final String unreadCountText;
                    if (unreadCount >= 100) {
                      unreadCountText = '99+';
                    } else if (unreadCount > 0) {
                      unreadCountText = '${unreadCount}';
                    } else {
                      unreadCountText = '';
                    }
                    if (unreadCountText.isNotEmpty) {
                      return Positioned(
                        top: 8,
                        right: 6,
                        child: UnreadMessagesBadge(unreadMessages: unreadCountText),
                      );
                    } else {
                      return SizedBox();
                    }
                  },
                ),
              ],
            ),
          )
        ],
      ),
      body: ExploreTabView(
        key: discoverPageKey,
        searchPhrase: '',
        showTags: true,
        onTagSelect: (value) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => ExploreSearchResult(
                        searchQuery: value,
                      )));
        },
      ),
    );
  }
}

import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/mp_loading_indicator.dart';
import 'package:multipie/features/explore/presentation/cubit/mf_list_cubit.dart';
import 'package:multipie/features/explore/presentation/screens/mf_filters_screen.dart';
import 'package:multipie/features/explore/presentation/screens/mf_list_by_type_screen.dart';
import 'package:multipie/features/for_you/presentation/widgets/toggle_duration_button.dart';
import 'package:multipie/locator.dart';

class MFListScreen extends StatelessWidget {
  const MFListScreen({
    Key? key,
    required this.title,
    this.searchText = '',
  }) : super(key: key);

  final String title;
  final String searchText;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => MfListCubit(
        mfListRepository: locator(),
        mfFilterRespository: locator(),
        preferences: locator(),
      ),
      child: Scaffold(
        appBar: MultipieAppBar(title: title),
        body: _Body(),
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MfListCubit, MfListState>(
      builder: (context, state) {
        if (state.isLoadingFunds && state.funds.isEmpty) {
          return Center(
            child: MPLoadingIndicator(),
          );
        } else if (!state.isLoadingFunds && state.funds.isEmpty) {
          return _EmptyScreen();
        } else {
          return _FundsList();
        }
      },
    );
  }
}

class _FundsList extends StatefulWidget {
  const _FundsList({
    Key? key,
  }) : super(key: key);

  @override
  State<_FundsList> createState() => _FundsListState();
}

class _FundsListState extends State<_FundsList> {
  late ScrollController _scrollController;

  @override
  void initState() {
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
    super.initState();
  }

  void _onScroll() {
    if (_scrollController.offset >= _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      context.read<MfListCubit>().loadMoreFunds();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MfListCubit, MfListState>(
      builder: (context, state) {
        final cubit = context.read<MfListCubit>();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  MaterialButton(
                    height: 30,
                    minWidth: 100,
                    onPressed: () {
                      CleverTapPlugin.recordEvent('Sort/Filter Mutual Fund', {});
                      Scaffold.of(context).showBottomSheet<void>(
                        (BuildContext context) {
                          return MFFiltersScreen(cubit: cubit);
                        },
                      );
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Sort/Filter',
                          style: TextStyle(
                            color: context.appTheme.primaryColor,
                            fontFamily: 'Roboto',
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Image.asset(
                          'assets/images/sort_filter.png',
                          color: context.appTheme.primaryColor,
                        ),
                        state.appliedChildFilters.isNotEmpty
                            ? Padding(
                                padding: EdgeInsets.only(left: 10),
                                child: Container(
                                  alignment: Alignment.center,
                                  height: 20,
                                  width: 40,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: context.appTheme.blueShadeColor.withOpacity(0.2),
                                  ),
                                  child: Text(
                                    state.appliedChildFilters.length.toString(),
                                    style: mpHeadLine6(
                                      context: context,
                                      textColor: context.appTheme.blueShadeColor,
                                    ),
                                  ),
                                ),
                              )
                            : Container()
                      ],
                    ),
                  ),
                  ToggleDurationButton(
                    value: cubit.selectedReturnDurationPeriod,
                    onPressed: cubit.toggleReturnDuration,
                  ),
                ],
              ),
            ),
            Expanded(
              child: RefreshIndicator(
                color: context.appTheme.activeIndicationColor,
                onRefresh: () => cubit.refresh(),
                child: ListView.builder(
                  controller: _scrollController,
                  itemBuilder: (context, index) {
                    final fund = state.funds[index];
                    return MFItem(
                      fund,
                      returnIndex: cubit.indexOfSelectedReturnDurationPeriod,
                    );
                  },
                  itemCount: state.funds.length,
                ),
              ),
            ),
            if (state.isLoadingFunds)
              SizedBox(
                height: 100,
                child: Center(
                  child: MPLoadingIndicator(),
                ),
              ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    super.dispose();
  }
}

class _EmptyScreen extends StatelessWidget {
  const _EmptyScreen({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<MfListCubit>();
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "Data is not available!",
            style: mpHeadLine6(context: context),
          ),
          if (cubit.state.appliedChildFilters.isNotEmpty) ...[
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                context.read<MfListCubit>().clearFilters();
              },
              child: Text(
                'Clear Filter',
                style: mpHeadLine6(context: context, textColor: context.appTheme.activeIndicationColor),
              ),
              style: ElevatedButton.styleFrom(primary: context.appTheme.primaryColor),
            )
          ]
        ],
      ),
    );
  }
}

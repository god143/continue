import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/models/mp_option_model.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/presentation/cubit/mf_list_cubit.dart';

class MFFiltersScreen extends StatefulWidget {
  const MFFiltersScreen({
    Key? key,
    required this.cubit,
  }) : super(key: key);

  final MfListCubit cubit;

  @override
  State<MFFiltersScreen> createState() => _MFFiltersScreenState();
}

class _MFFiltersScreenState extends State<MFFiltersScreen> {
  String? _selectedParentCategory;
  List<String> _selectedChildCategories = [];
  late String _selectedSortByDuration;
  int _currentParentFilterIndex = 0;

  static const _kDebt = 'Debt';
  static const _kEquity = 'Equity';
  static const _kGold = 'Gold';
  static const _kSortBy = 'sort_by';

  List<MPOptionModel> get parentCategoryFilters => [
        MPOptionModel(displayName: _kDebt, value: _kDebt),
        MPOptionModel(displayName: _kEquity, value: _kEquity),
        MPOptionModel(displayName: _kGold, value: _kGold),
        MPOptionModel(
          displayName: 'Sort By (${widget.cubit.getFormattedDurationForDurationValue(_selectedSortByDuration)})',
          value: _kSortBy,
        ),
      ];

  String get _currentParentFilterType => parentCategoryFilters[_currentParentFilterIndex].value;

  List<MPOptionModel> get childCategoryFilters {
    final filters = widget.cubit.state.filters;
    switch (_currentParentFilterType) {
      case _kDebt:
        return (filters?.debt ?? []).map((e) => MPOptionModel(displayName: e, value: e)).toList();
      case _kEquity:
        return (filters?.equity ?? []).map((e) => MPOptionModel(displayName: e, value: e)).toList();
      case _kGold:
        return (filters?.gold ?? []).map((e) => MPOptionModel(displayName: e, value: e)).toList();
      case _kSortBy:
        return widget.cubit.durations
            .map(
              (e) => MPOptionModel(
                displayName: widget.cubit.getFormattedDurationForDurationValue(e),
                value: e,
              ),
            )
            .toList();
      default:
        return [];
    }
  }

  @override
  void initState() {
    final currentState = widget.cubit.state;
    _selectedParentCategory = currentState.appliedParentFilter;
    _selectedChildCategories = currentState.appliedChildFilters;
    _selectedSortByDuration = currentState.sortBy;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: widget.cubit,
      child: BlocBuilder<MfListCubit, MfListState>(
        builder: (context, state) {
          return Container(
            height: MediaQuery.of(context).size.height - (Scaffold.of(context).appBarMaxHeight ?? 0.0),
            color: context.appTheme.cardBackgroundColor,
            child: Center(
              child: Column(
                children: <Widget>[
                  Container(
                    height: 40,
                    color: context.appTheme.primaryColor.withOpacity(0.5),
                    child: Row(
                      children: [
                        Expanded(
                          child: MaterialButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Row(
                              children: <Widget>[
                                Icon(
                                  Icons.close,
                                  color: context.appTheme.primaryColor,
                                  size: 18,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Filter',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: context.appTheme.primaryColor,
                                    fontFamily: 'Roboto',
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        MaterialButton(
                          height: 30,
                          minWidth: 100,
                          onPressed: () {
                            widget.cubit.clearFilters();
                            Navigator.pop(context);
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              Text(
                                "CLEAR ALL",
                                style: mpHeadLine5(
                                  context: context,
                                  textColor: context.appTheme.cardBackgroundColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                      child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: ListView.builder(
                          itemCount: parentCategoryFilters.length,
                          itemBuilder: (context, index) {
                            final parentFilter = parentCategoryFilters[index];
                            final isApplied =
                                parentFilter.value == _selectedParentCategory || parentFilter.value == 'sort_by';
                            return InkWell(
                              onTap: () {
                                setState(
                                  () {
                                    _currentParentFilterIndex = index;
                                  },
                                );
                              },
                              child: Container(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.all(10),
                                height: 56,
                                color: _currentParentFilterIndex == index
                                    ? context.appTheme.primaryColor.withOpacity(0.3)
                                    : context.appTheme.cardBackgroundColor,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Text(
                                    parentFilter.displayName,
                                    textAlign: TextAlign.left,
                                    style: mpHeadLine5(
                                      context: context,
                                      textColor: isApplied
                                          ? context.appTheme.primaryColor
                                          : context.appTheme.secondaryTextColor,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      VerticalDivider(
                        width: 1,
                        color: context.appTheme.borderColor,
                      ),
                      Expanded(
                        flex: 3,
                        child: ListView.builder(
                          itemCount: childCategoryFilters.length,
                          itemBuilder: (BuildContext context, index) {
                            final filter = childCategoryFilters[index];
                            final isSelected = _currentParentFilterType == _kSortBy
                                ? _selectedSortByDuration == filter.value
                                : _currentParentFilterType == _selectedParentCategory
                                    ? _selectedChildCategories.contains(filter.value)
                                    : false;

                            return InkWell(
                              onTap: () {
                                setState(
                                  () {
                                    if (_currentParentFilterType == _kSortBy) {
                                      _selectedSortByDuration = filter.value;
                                      return;
                                    }

                                    if (_selectedParentCategory != _currentParentFilterType) {
                                      _selectedChildCategories = [];
                                    }
                                    if (_selectedChildCategories.contains(filter.value)) {
                                      _selectedChildCategories.remove(filter.value);
                                    } else {
                                      _selectedChildCategories.add(filter.value);
                                    }
                                    _selectedParentCategory =
                                        _selectedChildCategories.isNotEmpty ? _currentParentFilterType : null;
                                  },
                                );
                              },
                              child: Container(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.all(10),
                                height: 50,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Row(
                                    children: [
                                      filter.displayName.contains('Year')
                                          ? Container()
                                          : Icon(
                                              Icons.check,
                                              color: isSelected
                                                  ? context.appTheme.primaryColor
                                                  : context.appTheme.secondaryTextColor,
                                              size: isSelected ? 20 : 18,
                                            ),
                                      Padding(
                                        padding: EdgeInsets.only(left: 20),
                                        child: Text(
                                          filter.displayName,
                                          textAlign: TextAlign.left,
                                          style: mpHeadLine5(
                                            context: context,
                                            textColor: isSelected
                                                ? context.appTheme.primaryColor
                                                : context.appTheme.secondaryTextColor,
                                            fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      )
                    ],
                  )),
                  Divider(
                    height: 1,
                    color: context.appTheme.borderColor,
                  ),
                  Container(
                    height: 100,
                    padding: EdgeInsets.all(15),
                    alignment: Alignment.topRight,
                    child: MaterialButton(
                      child: Text(
                        'Apply',
                        style: TextStyle(color: context.appTheme.cardBackgroundColor),
                      ),
                      color: context.appTheme.primaryColor,
                      onPressed: () {
                        widget.cubit.onFiltersApplied(
                          parentCategory: _selectedParentCategory,
                          childCategories: _selectedChildCategories,
                          sortDuration: _selectedSortByDuration,
                        );
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

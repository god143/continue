import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/explore/presentation/widgets/mutual_fund_screen.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_list_by_type.dart';

List<String> mfDuration = ['1 Year', '3 Year', '5 Year'];

List listMF = [];

class MFItem extends StatelessWidget {
  final MFListByType mfListItem;
  final int returnIndex;

  const MFItem(this.mfListItem, {required this.returnIndex}) : super();

  String durationReturn() {
    switch (returnIndex) {
      case 0:
        return twoDigitRoundOffConverterPercentage(mfListItem.mfReturnMetaInfo.mutualFundsReturnFor1Year);
      case 1:
        return twoDigitRoundOffConverterPercentage(mfListItem.mfReturnMetaInfo.mutualFundsReturnFor3Year);
      case 2:
        return twoDigitRoundOffConverterPercentage(mfListItem.mfReturnMetaInfo.mutualFundsReturnFor5Year);
      default:
        return twoDigitRoundOffConverterPercentage(mfListItem.mfReturnMetaInfo.mutualFundsReturnFor3Year);
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => MutualFundScreen(
                    mutualFundId: mfListItem.id,
                    mutualFundName: mfListItem.name,
                  )),
        );
      },
      child: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: context.appTheme.borderColor,
              width: 0.2,
            ),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            mfListItem.iconUrl == null || mfListItem.iconUrl.isEmpty
                ? Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: context.appTheme.blueShadeColor.withOpacity(0.3),
                    ),
                    child: Center(
                      child: Text(
                        mfListItem.name != null ? mfListItem.name[0] : "",
                        style: TextStyle(
                          fontSize: 25,
                          color: context.appTheme.primaryColor,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  )
                : CachedNetworkImage(
                    height: 60,
                    width: 60,
                    imageUrl: Constants.API_MF_IMAGE_URL + mfListItem.iconUrl,
                  ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      mfListItem.name,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: context.appTheme.primaryTextColor,
                        fontFamily: 'Roboto',
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      mfListItem.cap,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: context.appTheme.primaryTextColor,
                        fontFamily: 'Roboto',
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.0),
              child: Text(
                durationReturn(),
                style: mpHeadLine6(
                  context: context,
                  textColor: context.appTheme.primaryTextColor,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

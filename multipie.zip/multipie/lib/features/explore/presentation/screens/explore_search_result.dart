import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/presentation/screens/explore_search_active.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_explore_tab_view.dart';
import 'package:multipie/services/navigation_service.dart';

class ExploreSearchResult extends StatelessWidget {
  final String searchQuery;

  ExploreSearchResult({this.searchQuery = ''});

  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    searchController.text = searchQuery;
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      width: 40,
                      child: Icon(
                        Icons.arrow_back_ios_outlined,
                        size: 28,
                        color: context.appTheme.secondaryTextColor,
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigate.pushReplacement(context, ExploreSearchActive());
                      },
                      child: Container(
                        height: 40,
                        margin: EdgeInsets.only(left: 12),
                        padding: EdgeInsets.only(left: 16),
                        decoration: BoxDecoration(
                            color: context.appTheme.searchBackground,
                            borderRadius: BorderRadius.all(Radius.circular(10))),
                        child: TextField(
                          controller: searchController,
                          maxLines: 1,
                          enabled: false,
                          style: TextStyle(
                            color: context.appTheme.primaryTextColor,
                            fontWeight: FontWeight.w400,
                          ),
                          decoration: new InputDecoration(
                            border: InputBorder.none,
                            hintText: "Search",
                            labelStyle: TextStyle(
                              color: context.appTheme.secondaryTextColor,
                              fontWeight: FontWeight.bold,
                              fontSize: sSize(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Expanded(
                child: ExploreTabView(
              key: Key(searchQuery),
              searchPhrase: searchQuery,
              showTags: false,
              initialTabIndex: 1,
              onTagSelect: (value) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ExploreSearchActive(searchPhrase: value),
                  ),
                );
              },
            )),
          ],
        ),
      ),
    );
  }
}

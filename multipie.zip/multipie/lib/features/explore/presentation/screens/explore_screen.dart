import 'package:flutter/cupertino.dart';
import 'package:multipie/core/responsive/builders/orientation_layout.dart';
import 'package:multipie/core/responsive/builders/screen_type_layout.dart';

import 'explore_initial_screen.dart';

class ExploreScreen extends StatelessWidget {
  final int initTabIndex;

  const ExploreScreen({required this.initTabIndex}) : super();

  @override
  Widget build(BuildContext context) {
    return ScreenTypeLayout(
      // mobile UI
      mobile: OrientationLayout(
        // when device orientation is portrait
        portrait: ExploreInitialScreen(),
      ),
    );
  }
}

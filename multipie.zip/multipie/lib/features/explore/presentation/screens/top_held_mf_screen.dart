import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/presentation/widgets/mutual_fund_screen.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';

class TopHeldMutualFundsScreen extends StatefulWidget {
  final List<TopHeldMutualFund> listData;

  const TopHeldMutualFundsScreen({
    Key? key,
    required this.listData,
  }) : super(key: key);

  @override
  _TopHeldMutualFundsScreenState createState() => _TopHeldMutualFundsScreenState();
}

class _TopHeldMutualFundsScreenState extends State<TopHeldMutualFundsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MultipieAppBar(
        title: 'Top held mutual funds on Multipie',
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: TopHeldStockList(widget.listData),
      ),
    );
  }
}

class TopHeldStockList extends StatelessWidget {
  final List<TopHeldMutualFund> listData;

  TopHeldStockList([
    this.listData = const [],
  ]);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: listData.length,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: TopHeldStockItem(data: listData[index]),
        );
      },
    );
  }
}

class TopHeldStockItem extends StatefulWidget {
  final TopHeldMutualFund data;

  TopHeldStockItem({
    required this.data,
  });

  @override
  _TopHeldStockItemState createState() => _TopHeldStockItemState();
}

class _TopHeldStockItemState extends State<TopHeldStockItem> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.appTheme.cardBackgroundColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: context.appTheme.borderColor,
          width: 0.2,
        ),
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => MutualFundScreen(
                  mutualFundId: widget.data.id,
                  mutualFundName: widget.data.name,
                )),
          );
        },
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(
                vertical: 8,
                horizontal: 16,
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    widget.data.iconUrl == null || widget.data.iconUrl.isEmpty
                        ? Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: context.appTheme.blueShadeColor.withOpacity(0.3),
                      ),
                      child: Center(
                        child: Text(
                          widget.data.name != null ? widget.data.name[0] : "",
                          style: TextStyle(
                            fontSize: 25,
                            color: context.appTheme.primaryColor,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                    )
                        : CachedNetworkImage(
                      height: 60,
                      width: 60,
                      imageUrl: Constants.API_MF_IMAGE_URL + widget.data.iconUrl,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.data.name,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: context.appTheme.primaryTextColor,
                                fontFamily: 'Roboto',
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
            ),
            Container(
              decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withAlpha(30),
                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10), bottomRight: Radius.circular(10))),
              padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
              width: double.infinity,
              child: Text(
                widget.data.investorsCount + ' investors on Multipie',
                style: mpHeadLine6(
                  context: context,
                  textColor: context.appTheme.primaryTextColor,
                ),
              ),
            ),
          ],
        ),
      )
    );
  }
}

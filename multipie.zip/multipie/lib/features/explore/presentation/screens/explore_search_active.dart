import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/presentation/bloc/search/bloc.dart';
import 'package:multipie/features/explore/presentation/screens/explore_search_result.dart';
import 'package:multipie/features/explore/presentation/widgets/search_history.dart';
import 'package:multipie/features/watchlist/presentation/blocs/get_watchlist/bloc.dart' as watchlist_bloc;
import 'package:multipie/features/watchlist/presentation/blocs/watchlist_mf/bloc.dart' as watchlist_mf;
import 'package:multipie/features/watchlist/presentation/blocs/watchlist_stocks/bloc.dart' as watchlist_stock;

import '../../../../debouncer.dart';

class ExploreSearchActive extends StatefulWidget {
  final String searchPhrase;

  const ExploreSearchActive({this.searchPhrase = ""}) : super();

  @override
  _ExploreSearchActiveState createState() => _ExploreSearchActiveState();
}

class _ExploreSearchActiveState extends State<ExploreSearchActive> {
  TextEditingController searchController = TextEditingController();
  bool searchSuggestionVisible = true;
  late FocusNode focusNode;
  String prevText = '';

  late SearchResult searchResult;

  late Debouncer debouncer;
  late watchlist_stock.WatchlistStocksBloc watchlistStocksBloc;
  late watchlist_mf.WatchlistMfBloc watchlistMFBloc;

  @override
  initState() {
    super.initState();
    focusNode = FocusNode();
    BlocProvider.of<SearchResultsBloc>(context).add(GetListSearchResults(widget.searchPhrase));
    searchController.text = widget.searchPhrase;

    debouncer = Debouncer(milliseconds: 800);
    searchController.addListener(_listener);
    focusNode.requestFocus();

    watchlistStocksBloc = context.read<watchlist_stock.WatchlistStocksBloc>();
    watchlistMFBloc = context.read<watchlist_mf.WatchlistMfBloc>();
  }

  _listener() {
    if (prevText != searchController.text) {
      prevText = searchController.text;
      searchSuggestionVisible = searchController.text.length == 0;
      if (!searchSuggestionVisible) {
        debouncer.run(() {
          BlocProvider.of<SearchResultsBloc>(context).add(GetListSearchResults(searchController.text.toString()));
        });
      } else {
        // searchResult = null;
        debouncer.run(() {
          BlocProvider.of<SearchResultsBloc>(context).add(GetListSearchResults(''));
        });
      }
      //setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(context);
                    },
                    child: Container(
                      width: 40,
                      child: Icon(
                        Icons.arrow_back_ios_outlined,
                        size: 28,
                        color: context.appTheme.secondaryTextColor,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 40,
                      margin: EdgeInsets.only(left: 12),
                      padding: EdgeInsets.only(left: 16),
                      decoration: BoxDecoration(
                          color: context.appTheme.searchBackground,
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: TextField(
                        maxLines: 1,
                        autofocus: true,
                        focusNode: focusNode,
                        controller: searchController,
                        onSubmitted: (value) {
                          if (searchController.text.isNotEmpty)
                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => ExploreSearchResult(
                                          searchQuery: searchController.text,
                                        )));
                          // Navigator.pop(context, searchController.text);
                        },
                        style: mpHeadLine4(
                          context: context,
                          textColor: context.appTheme.primaryTextColor,
                        ),
                        decoration: new InputDecoration(
                          border: InputBorder.none,
                          hintText: "Search",
                          hintStyle: mpHeadLine4(
                            context: context,
                            textColor: context.appTheme.secondaryTextColor,
                          ),
                          suffixIcon: IconButton(
                            onPressed: searchController.clear,
                            icon: Icon(Icons.clear, color: context.appTheme.secondaryTextColor),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Divider(height: 1),
            Expanded(
              child: BlocBuilder<SearchResultsBloc, SearchResultsState>(
                builder: (context, state) {
                  if (state is Loaded) {
                    BlocProvider.of<watchlist_bloc.GetWatchlistBloc>(context)
                        .add(watchlist_bloc.FetchWatchlistDataEvent());
                    searchResult = state.searchResult;
                    return SearchHistory(
                      searchResult,
                      showSnackBar: (value) {
                        Scaffold.of(context).showSnackBar(SnackBar(
                            content: Text(
                          value,
                          style: mpHeadLine6(
                            context: context,
                            textColor: context.appTheme.lightTextColor,
                          ),
                        )));
                      },
                    );
                  } else if (state is Loading) {
                    return Center(child: CircularProgressIndicator());
                  } else if (state is Error) {
                    return Center(
                        child: Text(
                      state.message,
                      style: mpHeadLine6(context: context),
                    ));
                  } else {
                    return Container();
                  }
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    focusNode.dispose();
    searchController.dispose();
    watchlistStocksBloc.add(watchlist_stock.FetchWatchlistStocksEvent());
    watchlistMFBloc.add(watchlist_mf.FetchWatchlistMutualFundsEvent());
    super.dispose();
  }
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'mf_list_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$MfListState {
  bool get isLoadingFunds => throw _privateConstructorUsedError;
  List<MFListByType> get funds => throw _privateConstructorUsedError;
  String? get appliedParentFilter => throw _privateConstructorUsedError;
  List<String> get appliedChildFilters => throw _privateConstructorUsedError;
  String get returnDuration => throw _privateConstructorUsedError;
  String get sortBy => throw _privateConstructorUsedError;
  bool get isLoadingFilters => throw _privateConstructorUsedError;
  MFFilter? get filters => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MfListStateCopyWith<MfListState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MfListStateCopyWith<$Res> {
  factory $MfListStateCopyWith(
          MfListState value, $Res Function(MfListState) then) =
      _$MfListStateCopyWithImpl<$Res>;
  $Res call(
      {bool isLoadingFunds,
      List<MFListByType> funds,
      String? appliedParentFilter,
      List<String> appliedChildFilters,
      String returnDuration,
      String sortBy,
      bool isLoadingFilters,
      MFFilter? filters});
}

/// @nodoc
class _$MfListStateCopyWithImpl<$Res> implements $MfListStateCopyWith<$Res> {
  _$MfListStateCopyWithImpl(this._value, this._then);

  final MfListState _value;
  // ignore: unused_field
  final $Res Function(MfListState) _then;

  @override
  $Res call({
    Object? isLoadingFunds = freezed,
    Object? funds = freezed,
    Object? appliedParentFilter = freezed,
    Object? appliedChildFilters = freezed,
    Object? returnDuration = freezed,
    Object? sortBy = freezed,
    Object? isLoadingFilters = freezed,
    Object? filters = freezed,
  }) {
    return _then(_value.copyWith(
      isLoadingFunds: isLoadingFunds == freezed
          ? _value.isLoadingFunds
          : isLoadingFunds // ignore: cast_nullable_to_non_nullable
              as bool,
      funds: funds == freezed
          ? _value.funds
          : funds // ignore: cast_nullable_to_non_nullable
              as List<MFListByType>,
      appliedParentFilter: appliedParentFilter == freezed
          ? _value.appliedParentFilter
          : appliedParentFilter // ignore: cast_nullable_to_non_nullable
              as String?,
      appliedChildFilters: appliedChildFilters == freezed
          ? _value.appliedChildFilters
          : appliedChildFilters // ignore: cast_nullable_to_non_nullable
              as List<String>,
      returnDuration: returnDuration == freezed
          ? _value.returnDuration
          : returnDuration // ignore: cast_nullable_to_non_nullable
              as String,
      sortBy: sortBy == freezed
          ? _value.sortBy
          : sortBy // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingFilters: isLoadingFilters == freezed
          ? _value.isLoadingFilters
          : isLoadingFilters // ignore: cast_nullable_to_non_nullable
              as bool,
      filters: filters == freezed
          ? _value.filters
          : filters // ignore: cast_nullable_to_non_nullable
              as MFFilter?,
    ));
  }
}

/// @nodoc
abstract class _$$_MfListStateCopyWith<$Res>
    implements $MfListStateCopyWith<$Res> {
  factory _$$_MfListStateCopyWith(
          _$_MfListState value, $Res Function(_$_MfListState) then) =
      __$$_MfListStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {bool isLoadingFunds,
      List<MFListByType> funds,
      String? appliedParentFilter,
      List<String> appliedChildFilters,
      String returnDuration,
      String sortBy,
      bool isLoadingFilters,
      MFFilter? filters});
}

/// @nodoc
class __$$_MfListStateCopyWithImpl<$Res> extends _$MfListStateCopyWithImpl<$Res>
    implements _$$_MfListStateCopyWith<$Res> {
  __$$_MfListStateCopyWithImpl(
      _$_MfListState _value, $Res Function(_$_MfListState) _then)
      : super(_value, (v) => _then(v as _$_MfListState));

  @override
  _$_MfListState get _value => super._value as _$_MfListState;

  @override
  $Res call({
    Object? isLoadingFunds = freezed,
    Object? funds = freezed,
    Object? appliedParentFilter = freezed,
    Object? appliedChildFilters = freezed,
    Object? returnDuration = freezed,
    Object? sortBy = freezed,
    Object? isLoadingFilters = freezed,
    Object? filters = freezed,
  }) {
    return _then(_$_MfListState(
      isLoadingFunds: isLoadingFunds == freezed
          ? _value.isLoadingFunds
          : isLoadingFunds // ignore: cast_nullable_to_non_nullable
              as bool,
      funds: funds == freezed
          ? _value._funds
          : funds // ignore: cast_nullable_to_non_nullable
              as List<MFListByType>,
      appliedParentFilter: appliedParentFilter == freezed
          ? _value.appliedParentFilter
          : appliedParentFilter // ignore: cast_nullable_to_non_nullable
              as String?,
      appliedChildFilters: appliedChildFilters == freezed
          ? _value._appliedChildFilters
          : appliedChildFilters // ignore: cast_nullable_to_non_nullable
              as List<String>,
      returnDuration: returnDuration == freezed
          ? _value.returnDuration
          : returnDuration // ignore: cast_nullable_to_non_nullable
              as String,
      sortBy: sortBy == freezed
          ? _value.sortBy
          : sortBy // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingFilters: isLoadingFilters == freezed
          ? _value.isLoadingFilters
          : isLoadingFilters // ignore: cast_nullable_to_non_nullable
              as bool,
      filters: filters == freezed
          ? _value.filters
          : filters // ignore: cast_nullable_to_non_nullable
              as MFFilter?,
    ));
  }
}

/// @nodoc

class _$_MfListState implements _MfListState {
  _$_MfListState(
      {this.isLoadingFunds = false,
      final List<MFListByType> funds = const [],
      this.appliedParentFilter,
      final List<String> appliedChildFilters = const [],
      this.returnDuration = '3y',
      this.sortBy = '3y',
      this.isLoadingFilters = false,
      this.filters})
      : _funds = funds,
        _appliedChildFilters = appliedChildFilters;

  @override
  @JsonKey()
  final bool isLoadingFunds;
  final List<MFListByType> _funds;
  @override
  @JsonKey()
  List<MFListByType> get funds {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_funds);
  }

  @override
  final String? appliedParentFilter;
  final List<String> _appliedChildFilters;
  @override
  @JsonKey()
  List<String> get appliedChildFilters {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_appliedChildFilters);
  }

  @override
  @JsonKey()
  final String returnDuration;
  @override
  @JsonKey()
  final String sortBy;
  @override
  @JsonKey()
  final bool isLoadingFilters;
  @override
  final MFFilter? filters;

  @override
  String toString() {
    return 'MfListState(isLoadingFunds: $isLoadingFunds, funds: $funds, appliedParentFilter: $appliedParentFilter, appliedChildFilters: $appliedChildFilters, returnDuration: $returnDuration, sortBy: $sortBy, isLoadingFilters: $isLoadingFilters, filters: $filters)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MfListState &&
            const DeepCollectionEquality()
                .equals(other.isLoadingFunds, isLoadingFunds) &&
            const DeepCollectionEquality().equals(other._funds, _funds) &&
            const DeepCollectionEquality()
                .equals(other.appliedParentFilter, appliedParentFilter) &&
            const DeepCollectionEquality()
                .equals(other._appliedChildFilters, _appliedChildFilters) &&
            const DeepCollectionEquality()
                .equals(other.returnDuration, returnDuration) &&
            const DeepCollectionEquality().equals(other.sortBy, sortBy) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingFilters, isLoadingFilters) &&
            const DeepCollectionEquality().equals(other.filters, filters));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(isLoadingFunds),
      const DeepCollectionEquality().hash(_funds),
      const DeepCollectionEquality().hash(appliedParentFilter),
      const DeepCollectionEquality().hash(_appliedChildFilters),
      const DeepCollectionEquality().hash(returnDuration),
      const DeepCollectionEquality().hash(sortBy),
      const DeepCollectionEquality().hash(isLoadingFilters),
      const DeepCollectionEquality().hash(filters));

  @JsonKey(ignore: true)
  @override
  _$$_MfListStateCopyWith<_$_MfListState> get copyWith =>
      __$$_MfListStateCopyWithImpl<_$_MfListState>(this, _$identity);
}

abstract class _MfListState implements MfListState {
  factory _MfListState(
      {final bool isLoadingFunds,
      final List<MFListByType> funds,
      final String? appliedParentFilter,
      final List<String> appliedChildFilters,
      final String returnDuration,
      final String sortBy,
      final bool isLoadingFilters,
      final MFFilter? filters}) = _$_MfListState;

  @override
  bool get isLoadingFunds => throw _privateConstructorUsedError;
  @override
  List<MFListByType> get funds => throw _privateConstructorUsedError;
  @override
  String? get appliedParentFilter => throw _privateConstructorUsedError;
  @override
  List<String> get appliedChildFilters => throw _privateConstructorUsedError;
  @override
  String get returnDuration => throw _privateConstructorUsedError;
  @override
  String get sortBy => throw _privateConstructorUsedError;
  @override
  bool get isLoadingFilters => throw _privateConstructorUsedError;
  @override
  MFFilter? get filters => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_MfListStateCopyWith<_$_MfListState> get copyWith =>
      throw _privateConstructorUsedError;
}

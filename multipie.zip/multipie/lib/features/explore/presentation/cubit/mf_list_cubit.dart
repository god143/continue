import 'package:bloc/bloc.dart';
import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/features/market/domain/entities/mf_filter/mf_filter.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mf_list_by_type.dart';
import 'package:multipie/features/market/domain/repositories/mf_filter_repository.dart';
import 'package:multipie/features/market/domain/repositories/mf_list_by_type_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

part 'mf_list_cubit.freezed.dart';
part 'mf_list_state.dart';

class MfListCubit extends Cubit<MfListState> {
  MfListCubit({
    required this.mfListRepository,
    required this.mfFilterRespository,
    required this.preferences,
  }) : super(MfListState()) {
    _init();
  }

  final MFListByTypeRepository mfListRepository;
  final MFFilterRespository mfFilterRespository;
  final SharedPreferences preferences;

  int _page = 1;
  final int _pageSize = 20;
  bool get _hasMoreData => state.funds.length < (_page + 1) * _pageSize;
  final durations = ['1y', '3y', '5y'];

  String get selectedReturnDurationPeriod => getFormattedDurationForDurationValue(state.returnDuration);

  String getFormattedDurationForDurationValue(String value) {
    switch (value) {
      case '1y':
        return '1 Year';
      case '3y':
        return '3 Year';
      case '5y':
        return '5 Year';
      default:
        return value;
    }
  }

  int get indexOfSelectedReturnDurationPeriod => durations.indexOf(state.returnDuration).clamp(0, durations.length - 1);

  Future<void> _init() async {
    String? parentCategory;
    List<String>? childCategories;
    try {
      parentCategory = await preferences.getString(Constants.MF_FILTER_PARENT);
      final childCategoriesString = await preferences.getString(Constants.MF_FILTER_CHILDREN_LIST);
      if (childCategoriesString != null) {
        childCategories = Uri.decodeFull(childCategoriesString).split(',');
      }
    } catch (ex) {
      print(ex);
    }

    emit(
      state.copyWith(
        appliedParentFilter: parentCategory,
        appliedChildFilters: childCategories ?? [],
      ),
    );

    refresh();
  }

  Future<void> refresh() async {
    _page = 1;
    await _fetchFunds();
    if (state.filters == null) {
      await _fetchFilters();
    }
  }

  Future<void> loadMoreFunds() async {
    if (state.isLoadingFunds || !_hasMoreData) {
      return;
    }
    await _fetchFunds();
  }

  Future<void> _fetchFunds() async {
    final filterParams = {
      if (state.appliedParentFilter != null && state.appliedChildFilters.isNotEmpty)
        'assets': state.appliedParentFilter!,
      if (state.appliedChildFilters.isNotEmpty) 'fund_category': Uri.encodeFull(state.appliedChildFilters.join(',')),
      'sort_by': state.sortBy,
    }.entries.map((entry) => '${entry.key}=${entry.value}').join('&');
    emit(state.copyWith(isLoadingFunds: true));
    final result = await mfListRepository.getMFListByType(
      null,
      true,
      filterParams,
      _pageSize,
      _page,
    );
    final isInitialPage = _page == 1;
    final fetchedFunds = result.fold(
      (_) => <MFListByType>[],
      (funds) {
        _page += 1;
        return funds;
      },
    );
    emit(
      state.copyWith(
        isLoadingFunds: false,
        funds: [
          if (!isInitialPage) ...state.funds,
          ...fetchedFunds,
        ],
      ),
    );
  }

  Future<void> _fetchFilters() async {
    emit(state.copyWith(isLoadingFilters: true));
    final result = await mfFilterRespository.getMFFilterList();
    final filters = result.fold((failure) => null, (d) => d);
    emit(
      state.copyWith(
        isLoadingFilters: false,
        filters: filters ?? state.filters,
      ),
    );
  }

  void toggleReturnDuration() {
    final index = durations.indexWhere((e) => state.returnDuration == e);
    final nextDurationIndex = (index + 1) % durations.length;
    final nextDuration = durations[nextDurationIndex];
    emit(state.copyWith(returnDuration: nextDuration));
  }

  Future<void> clearFilters() async {
    emit(
      state.copyWith(
        appliedParentFilter: null,
        appliedChildFilters: [],
        sortBy: '3y',
        returnDuration: '3y',
      ),
    );

    await preferences.remove(Constants.MF_FILTER_PARENT);
    await preferences.remove(Constants.MF_FILTER_CHILDREN_LIST);

    await refresh();
  }

  Future<void> onFiltersApplied({
    required String? parentCategory,
    required List<String> childCategories,
    required String sortDuration,
  }) async {
    CleverTapPlugin.recordEvent(
      'Sort/Filter Mutual Fund Applied',
      {
        'Asset-Class': parentCategory,
        'Categories': childCategories.join(','),
      },
    );
    if (childCategories.isEmpty) {
      emit(
        state.copyWith(
          appliedParentFilter: null,
          appliedChildFilters: [],
          sortBy: sortDuration,
          returnDuration: sortDuration,
        ),
      );
      await preferences.remove(Constants.MF_FILTER_PARENT);
      await preferences.remove(Constants.MF_FILTER_CHILDREN_LIST);
    } else {
      emit(
        state.copyWith(
          appliedParentFilter: parentCategory,
          appliedChildFilters: childCategories,
          sortBy: sortDuration,
          returnDuration: sortDuration,
        ),
      );
      await preferences.setString(Constants.MF_FILTER_PARENT, parentCategory ?? 'unknown');
      final encodedChildren = Uri.encodeFull(childCategories.join(','));
      await preferences.setString(Constants.MF_FILTER_CHILDREN_LIST, encodedChildren);
    }
    await refresh();
  }
}

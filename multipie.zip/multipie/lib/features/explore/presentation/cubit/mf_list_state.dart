part of 'mf_list_cubit.dart';

@freezed
class MfListState with _$MfListState {
  factory MfListState({
    @Default(false) bool isLoadingFunds,
    @Default([]) List<MFListByType> funds,
    String? appliedParentFilter,
    @Default([]) List<String> appliedChildFilters,
    @Default('3y') String returnDuration,
    @Default('3y') String sortBy,
    @Default(false) bool isLoadingFilters,
    MFFilter? filters,
  }) = _MfListState;
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

import 'package:multipie/features/explore/domain/entities/hash_tag.dart';

@immutable
abstract class HashTagState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends HashTagState {}

class Loading extends HashTagState {}

class Loaded extends HashTagState {
  final List<HashTag> hashTagList;
  Loaded({required this.hashTagList});

  @override
  List<Object> get props => [hashTagList];
}

class Error extends HashTagState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/features/explore/domain/usecases/get_hash_tag_result.dart';
import 'package:multipie/features/explore/presentation/bloc/hashtag/bloc.dart';

class HashTagBloc extends Bloc<HashTagEvent, HashTagState> {
  final GetHashTagResult getHashTagResult;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  HashTagState get initialState => Empty();

  HashTagBloc({required GetHashTagResult getHashTagResult})
      : assert(getHashTagResult != null),
        getHashTagResult = getHashTagResult,
        super(Empty());

  @override
  Stream<HashTagState> mapEventToState(
    HashTagEvent event,
  ) async* {
    if (event is GetHashTagList) {
      yield Loading();
      final failureOrBalanceSheetList =
          await getHashTagResult(Params(searchPhrase: event.searchPhrase));
      yield* _eitherLoadedOrErrorState(failureOrBalanceSheetList);
    }
  }

  Stream<HashTagState> _eitherLoadedOrErrorState(
    Either<Failure, List<HashTag>> failureOrHashTagsResults,
  ) async* {
    yield failureOrHashTagsResults.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (hashTags) => Loaded(hashTagList: hashTags),
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class HashTagEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetHashTagList extends HashTagEvent {
  final String searchPhrase;

  GetHashTagList(this.searchPhrase);

  @override
  List<Object> get props => [searchPhrase];
}

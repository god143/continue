import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class CompanySearchEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListCompanySearchResults extends CompanySearchEvent {
  final String searchPhrase;

  GetListCompanySearchResults(this.searchPhrase);

  @override
  List<Object> get props => [searchPhrase];
}

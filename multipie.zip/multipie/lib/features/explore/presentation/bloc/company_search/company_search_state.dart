import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

@immutable
abstract class CompanySearchState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends CompanySearchState {}

class Loading extends CompanySearchState {}

class Loaded extends CompanySearchState {
  final List<Company> searchResultList;
  Loaded({required this.searchResultList});

  @override
  List<Object> get props => [searchResultList];
}

class Error extends CompanySearchState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

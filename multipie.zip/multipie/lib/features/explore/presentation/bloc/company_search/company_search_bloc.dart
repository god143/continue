import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/explore/domain/usecases/get_company_search_result.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

import 'bloc.dart';

class CompanySearchBloc extends Bloc<CompanySearchEvent, CompanySearchState> {
  final GetCompanySearchResult getCompanySearchResult;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  CompanySearchState get initialState => Empty();

  CompanySearchBloc({required GetCompanySearchResult getCompanySearchResult})
      : assert(getCompanySearchResult != null),
        getCompanySearchResult = getCompanySearchResult,
        super(Empty());

  @override
  Stream<CompanySearchState> mapEventToState(
    CompanySearchEvent event,
  ) async* {
    if (event is GetListCompanySearchResults) {
      yield Loading();
      final failureOrCompanySearchList = await getCompanySearchResult(
          ParamsCompany(searchCompanyPhrase: event.searchPhrase));
      yield* _eitherLoadedOrErrorState(failureOrCompanySearchList);
    }
  }

  Stream<CompanySearchState> _eitherLoadedOrErrorState(
    Either<Failure, List<Company>> failureOrQuarterlyResults,
  ) async* {
    yield failureOrQuarterlyResults.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        List<Company> temp = data;
        //Todo

        return Loaded(searchResultList: temp);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

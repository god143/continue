import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class SearchResultsEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListSearchResults extends SearchResultsEvent {
  final String searchPhrase;

  GetListSearchResults(this.searchPhrase);

  @override
  List<Object> get props => [searchPhrase];
}

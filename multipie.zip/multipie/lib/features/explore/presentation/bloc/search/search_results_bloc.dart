import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/domain/usecases/get_explore_result.dart';

import 'bloc.dart';

//fixme remove at release build time if not used. Not used as of now
class SearchResultsBloc extends Bloc<SearchResultsEvent, SearchResultsState> {
  final GetExploreResult getSearchResults;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  SearchResultsState get initialState => Empty();

  SearchResultsBloc({required GetExploreResult getSearchResults})
      : assert(getSearchResults != null),
        getSearchResults = getSearchResults,
        super(Empty());

  @override
  Stream<SearchResultsState> mapEventToState(
    SearchResultsEvent event,
  ) async* {
    if (event is GetListSearchResults) {
      if (event.searchPhrase.isEmpty) {
        yield Loading();
      }
      final failureOrBalanceSheetList =
          await getSearchResults(Params(searchPhrase: event.searchPhrase));
      yield* _eitherLoadedOrErrorState(failureOrBalanceSheetList);
    }
  }

  Stream<SearchResultsState> _eitherLoadedOrErrorState(
    Either<Failure, SearchResult> failureOrQuarterlyResults,
  ) async* {
    yield failureOrQuarterlyResults.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (data) {
        /* List<CommonSearch> temp = [];
        //adding filtered people to common list
        if (data.people.length > 0) {
          temp.add(CommonSearch(id: "0", name: "PEOPLE", isTitle: true));
        }
        (data.people).forEach((element) {
          temp.add(CommonSearch(id: element.id, name: element.name));
        });
        //adding filtered Companies to common list
        if (data.companies.length > 0) {
          temp.add(CommonSearch(id: "0", name: "COMPANIES", isTitle: true));
        }
        (data.companies).forEach((element) {
          temp.add(CommonSearch(id: element.id, name: element.name));
        });
        //adding filtered mutual funds to common list
        if (data.mutualFunds.length> 0) {
          temp.add(CommonSearch(id: "0", name: "MUTUAL FUNDS", isTitle: true));
        }
        (data.mutualFunds).forEach((element) {
          temp.add(CommonSearch(id: element.id, name: element.name));
        });
*/
        return Loaded(searchResult: data);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

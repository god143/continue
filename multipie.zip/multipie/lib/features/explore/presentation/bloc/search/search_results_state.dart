import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';

@immutable
abstract class SearchResultsState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends SearchResultsState {}

class Loading extends SearchResultsState {}

class Loaded extends SearchResultsState {
  final SearchResult searchResult;
  Loaded({required this.searchResult});

  @override
  List<Object> get props => [searchResult];
}

class Error extends SearchResultsState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

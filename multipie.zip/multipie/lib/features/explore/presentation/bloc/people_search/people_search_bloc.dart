import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/explore/domain/usecases/get_people_result.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

import 'bloc.dart';

class PeopleSearchBloc extends Bloc<PeopleSearchEvent, PeopleSearchState> {
  final GetPeopleSearchResult getPeopleSearchResult;
  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  PeopleSearchState get initialState => EmptyPeople();

  PeopleSearchBloc({required GetPeopleSearchResult getPeopleSearchResult})
      : assert(getPeopleSearchResult != null),
        getPeopleSearchResult = getPeopleSearchResult,
        super(EmptyPeople());

  @override
  Stream<PeopleSearchState> mapEventToState(
    PeopleSearchEvent event,
  ) async* {
    if (event is GetPeopleSearchResults) {
      if (event.page == 1) yield LoadingPeople();
      final failureOrPeopleSearchList = await getPeopleSearchResult(
          ParamsPeople(
              searchPeoplePhrase: event.searchPhrase,
              pageSize: event.pageSize,
              page: event.page));
      yield* _eitherLoadedOrErrorState(failureOrPeopleSearchList);
    }
  }

  Stream<PeopleSearchState> _eitherLoadedOrErrorState(
    Either<Failure, List<User>> failureOrPeopleResults,
  ) async* {
    yield failureOrPeopleResults.fold(
      (failure) => ErrorPeople(message: _mapFailureToMessage(failure)),
      (people) => LoadedPeople(searchUserResultList: people),
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

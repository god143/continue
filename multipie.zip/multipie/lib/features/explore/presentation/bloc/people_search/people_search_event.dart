import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class PeopleSearchEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetPeopleSearchResults extends PeopleSearchEvent {
  final String searchPhrase;
  final int pageSize;
  final int page;

  GetPeopleSearchResults(this.searchPhrase, {this.pageSize = 20, this.page = 1});

  @override
  List<Object> get props => [searchPhrase, pageSize, page];
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

@immutable
abstract class PeopleSearchState extends Equatable {
  @override
  List<Object> get props => [];
}

class EmptyPeople extends PeopleSearchState {}

class LoadingPeople extends PeopleSearchState {}

class LoadedPeople extends PeopleSearchState {
  final List<User> searchUserResultList;

  LoadedPeople({required this.searchUserResultList});

  @override
  List<Object> get props => [searchUserResultList];
}

class ErrorPeople extends PeopleSearchState {
  final String message;

  ErrorPeople({required this.message});

  @override
  List<Object> get props => [message];
}

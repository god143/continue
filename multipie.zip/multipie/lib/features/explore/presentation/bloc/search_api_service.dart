import 'package:dio/dio.dart';
import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/server_info.dart';
import 'package:multipie/features/explore/data/models/hash_tag_model.dart';
import 'package:multipie/features/explore/data/models/search_result_model.dart';
import 'package:multipie/features/explore/domain/entities/common_search_entity.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/features/market/data/models/company/company_model.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

class APIService {
  static Future getSuggestions(String query) async {
    try {
      var response = await Dio()
          .get(ServerInfo.baseUrl + "/search" + "?search_phrase=$query");
      try {
        print("Normal >> " + response.data.toString());
        Map<String, dynamic> json = Japx.decode(response.data);
        print("Updated with Japx >> " + json.toString());
        final searchModel = SearchResultModel.fromJson(json['data']);
        List<CommonSearch> temp = [];
        //adding filtered people to common list
        if (searchModel.people.length > 0) {
          temp.add(CommonSearch(
              id: "0", name: "PEOPLE", isTitle: true, type: "people"));
        }
        (searchModel.people).forEach((element) {
          temp.add(CommonSearch(
              id: element.id, name: element.displayname, type: "people"));
        });
        //adding filtered Companies to common list
        if (searchModel.companies.length > 0) {
          temp.add(CommonSearch(
              id: "0", name: "COMPANIES", isTitle: true, type: "company"));
        }
        (searchModel.companies).forEach((element) {
          temp.add(CommonSearch(
              id: element.id, name: element.displayName!, type: "company"));
        });
        //adding filtered mutual funds to common list
        if (searchModel.mutualFunds.length > 0) {
          temp.add(CommonSearch(
              id: "0",
              name: "MUTUAL FUNDS",
              isTitle: true,
              type: "mutual_fund"));
        }
        (searchModel.mutualFunds).forEach((element) {
          temp.add(CommonSearch(
              id: element.id, name: element.name, type: "mutual_fund"));
        });
        return temp;
      } catch (e) {
        throw ServerException('Failed to get posts from data');
      }
    } catch (e) {
      throw Exception('Failed to load post');
    }
  }

  static Future<List<Company>> getCompanySuggestions(String query) async {
    try {
      print(ServerInfo.baseUrl +
          "/companies" +
          "?search_phrase=$query" +
          '&page_size=5');

      var response = await Dio().get(ServerInfo.baseUrl +
          "/companies" +
          "?search_phrase=$query" +
          '&page_size=5');
      Map<String, dynamic> json = Japx.decode(response.data);
      Iterable data = json['data'];
      return data.map((post) => CompanyModel.fromJson(post)).toList();
    } catch (e) {
      throw Exception('Failed to load post');
    }
  }

  static Future<List<HashTag>> getHashTagSuggestions(String query) async {
    try {
      var response = await Dio()
          .get(ServerInfo.baseUrl + "/hashtags" + "?search_phrase=$query");
      Map<String, dynamic> json = Japx.decode(response.data);
      Iterable data = json['data'];
      return data.map((post) => HashTagModel.fromJson(post)).toList();
    } catch (e) {
      throw Exception('Failed to load post');
    }
  }
}

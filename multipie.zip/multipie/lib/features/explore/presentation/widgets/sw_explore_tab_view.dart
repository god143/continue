import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/theme/cubit/app_theme_cubit.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/presentation/widgets/search_posts.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_mutual_fund_to_explore.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_people_explore.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_stocks_to_explore.dart';
import 'package:multipie/features/for_you/presentation/screens/for_you_screen.dart';
import 'package:multipie/features/post/presentation/bloc/trending_posts/bloc.dart';
import 'package:multipie/locator.dart';

class ExploreTabView extends StatefulWidget {
  final String searchPhrase;
  final OnTagSelect onTagSelect;
  final bool showTags;
  final int? initialTabIndex;

  const ExploreTabView({
    required Key key,
    required this.searchPhrase,
    required this.onTagSelect,
    required this.showTags,
    this.initialTabIndex,
  }) : super(key: key);

  @override
  ExploreTabViewState createState() => ExploreTabViewState();
}

typedef OnTagSelect = void Function(String searchPhrase);

class ExploreTabViewState extends State<ExploreTabView> with TickerProviderStateMixin {
  TabController? searchTabController;

  final List<String> tabsTitle = ['For You', 'Posts', 'People', 'Stocks', 'Mutual Funds'];

  @override
  void initState() {
    super.initState();
    searchTabController = new TabController(length: 5, vsync: this);
    searchTabController!.index = widget.initialTabIndex ?? 0;
    CleverTapPlugin.recordEvent('For you', {});
    searchTabController!.addListener(() {
      CleverTapPlugin.recordEvent('Explore ${tabsTitle[searchTabController!.index]}', {});

      setState(() {
        // widget.onTabSelection(tabController.index);
      });
    });

    final window = WidgetsBinding.instance.window;
    window.onPlatformBrightnessChanged = () {
      if (!mounted) {
        return;
      }
      final cubit = context.read<AppThemeCubit>();
      if (cubit.state.themeMode == ThemeMode.system) {
        // Force build to adopt the new theme based style
        setState(() {});
      }
    };
  }

  @override
  void dispose() {
    super.dispose();
    searchTabController!.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        TabBar(
          controller: searchTabController,
          indicatorWeight: 4,
          indicatorColor: context.appTheme.activeIndicationColor,
          isScrollable: true,
          onTap: (value) {
            CleverTapPlugin.recordEvent('Explore ${tabsTitle[value]}', {});
          },
          tabs: <Widget>[
            buildTab(0, tabsTitle[0]),
            buildTab(1, tabsTitle[1]),
            buildTab(2, tabsTitle[2]),
            buildTab(3, tabsTitle[3]),
            buildTab(4, tabsTitle[4], isMF: true),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: searchTabController,
            children: <Widget>[
              ForYouScreen(),
              BlocProvider(
                create: (_) => locator<TrendingPostBloc>(),
                child: SearchPosts(
                  searchPhrase: widget.searchPhrase,
                  showTags: widget.showTags,
                ),
              ),
              PeopleExplore(searchPhrase: widget.searchPhrase),
              StocksToExplore(searchPhrase: widget.searchPhrase),
              MutualFundToExplore(searchPhrase: widget.searchPhrase),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildTab(int pos, String title, {bool isMF = false}) {
    return Tab(
      child: Container(
        width: isMF ? sWidth(86) : sWidth(57),
        alignment: Alignment.center,
        child: Text(
          title,
          style: mpHeadLine5(
            context: context,
            textColor:
                pos == searchTabController!.index ? context.appTheme.primaryColor : context.appTheme.secondaryTextColor,
          ),
        ),
      ),
    );
  }

  void selectTab(int tabIndex) {
    searchTabController?.animateTo(tabIndex);
  }
}

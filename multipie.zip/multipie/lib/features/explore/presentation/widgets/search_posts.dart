import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/features/explore/presentation/bloc/hashtag/bloc.dart' as hash_tag_bloc;
import 'package:multipie/features/post/domain/entities/post.dart';
import 'package:multipie/features/post/presentation/bloc/trending_posts/bloc.dart';
import 'package:multipie/features/post/presentation/widgets/new_post/new_post_container.dart';

class SearchPosts extends StatefulWidget {
  final String searchPhrase;
  final bool showTags;

  SearchPosts({
    required this.searchPhrase,
    required this.showTags,
  });

  @override
  _SearchPostsState createState() => _SearchPostsState();
}

class _SearchPostsState extends State<SearchPosts> {
  HashTag? _selectedTag;

  @override
  void initState() {
    super.initState();
    context.read<TrendingPostBloc>().add(GetTrendingPostList(1, widget.searchPhrase));
    if (widget.showTags) {
      context.read<hash_tag_bloc.HashTagBloc>().add(hash_tag_bloc.GetHashTagList(''));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Empty Placeholder to avoid issue mentioned here:
          // https://github.com/flutter/flutter/issues/55170
          SliverToBoxAdapter(),
          if (widget.showTags) ...[
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 12,
                ),
                child: Text(
                  'Trending tags on Multipie',
                  style: mpHeadLine4(
                    context: context,
                    fontWeight: FontWeight.w500,
                    textColor: context.appTheme.activeIndicationColor,
                  ),
                ),
              ),
            ),
            BlocConsumer<hash_tag_bloc.HashTagBloc, hash_tag_bloc.HashTagState>(
              listener: (context, state) {
                if (state is hash_tag_bloc.Error) {
                  print(state.message);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        state.message,
                        style: mpHeadLine6(
                          context: context,
                          textColor: context.appTheme.lightTextColor,
                        ),
                      ),
                    ),
                  );
                }
              },
              builder: (context, state) {
                if (state is hash_tag_bloc.Loaded && state.hashTagList.isNotEmpty) {
                  return SliverToBoxAdapter(
                    child: _TagsWidget(
                      tags: state.hashTagList.take(20).toList(growable: false),
                      selectedTag: _selectedTag,
                      onTagSelected: (tag) {
                        setState(() => _selectedTag = tag);
                        final String phrase;
                        if (_selectedTag != null) {
                          phrase = _selectedTag!.title.replaceFirst('#', '');
                        } else {
                          phrase = widget.searchPhrase;
                        }
                        context.read<TrendingPostBloc>().add(GetTrendingPostList(1, phrase));
                      },
                    ),
                  );
                } else {
                  return SliverToBoxAdapter();
                }
              },
            ),
          ],
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                'Trending on Multipie',
                style: mpHeadLine4(
                  context: context,
                  fontWeight: FontWeight.w500,
                  textColor: context.appTheme.activeIndicationColor,
                ),
              ),
            ),
          ),
          BlocConsumer<TrendingPostBloc, TrendingPostState>(
            listener: (context, state) {
              if (state is Error) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      state.message,
                      style: mpHeadLine6(
                        context: context,
                        textColor: context.appTheme.lightTextColor,
                      ),
                    ),
                  ),
                );
              }
            },
            builder: (context, state) {
              if (state is Loading) {
                return SliverFillRemaining(
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                );
              } else if (state is Loaded && state.postList.isNotEmpty) {
                return SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final post = state.postList[index];
                      return NewPostContainer(
                        post: post,
                        feedListPostUpdate: (Post poppedPost) {
                          setState(() {
                            if (poppedPost.isDeleted) {
                              state.postList[index].isDeleted = true;
                            }
                            state.postList[index].isBookmarked = poppedPost.isBookmarked;
                          });
                        },
                        onUserBlocked: (userId) =>
                            BlocProvider.of<TrendingPostBloc>(context).add(GetTrendingPostList(1, widget.searchPhrase)),
                      );
                    },
                    childCount: state.postList.length,
                  ),
                );
              } else {
                return SliverFillRemaining(
                  child: SizedBox(
                    height: 100,
                    child: Center(
                      child: Text(
                        'No Results Found',
                        style: mpHeadLine5(context: context),
                      ),
                    ),
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class _TagsWidget extends StatelessWidget {
  const _TagsWidget({
    Key? key,
    required this.tags,
    required this.selectedTag,
    required this.onTagSelected,
  }) : super(key: key);

  final List<HashTag> tags;
  final HashTag? selectedTag;
  final ValueChanged<HashTag?> onTagSelected;

  final itemsInEachRow = 20;
  final rowHeight = 56.0;
  final tagsListPadding = 24.0;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: rowHeight + tagsListPadding,
      child: ListView(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          SizedBox(width: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: <Widget>[
                  for (final tag in tags)
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 4,
                        vertical: 4,
                      ),
                      child: _TagItem(
                        item: tag,
                        isSelected: selectedTag == tag,
                        onTagSelected: onTagSelected,
                      ),
                    )
                ],
              ),
            ],
          ),
          SizedBox(width: 20),
        ],
      ),
    );
  }
}

class _TagItem extends StatelessWidget {
  const _TagItem({
    Key? key,
    required this.item,
    required this.isSelected,
    required this.onTagSelected,
  }) : super(key: key);

  final HashTag item;
  final bool isSelected;
  final ValueChanged<HashTag?> onTagSelected;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Material(
        color: context.appTheme.cardBackgroundColor,
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          onTap: () => onTagSelected(isSelected ? null : item),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isSelected ? context.appTheme.activeIndicationColor : context.appTheme.borderColor,
                width: 0.5,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '#${item.title}',
                    style: mpHeadLine5(
                      context: context,
                      fontWeight: FontWeight.bold,
                      textColor:
                          isSelected ? context.appTheme.activeIndicationColor : context.appTheme.primaryTextColor,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '${item.postCount ?? '0'} Posts',
                    style: mpHeadLine7(
                      context: context,
                      textColor:
                          isSelected ? context.appTheme.activeIndicationColor : context.appTheme.primaryTextColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

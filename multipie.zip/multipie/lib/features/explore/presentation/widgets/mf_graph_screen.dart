import 'dart:convert';

import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/explore/presentation/widgets/dash_line_with_cut_widget.dart';
import 'package:multipie/features/explore/presentation/widgets/mf_options_sheet.dart';
import 'package:multipie/features/mf_timeperiod/presentation/bloc/bloc.dart';
import 'package:multipie/features/mf_timeperiod/presentation/widgets/mf_line_chart.dart';
import 'package:multipie/features/post/data/models/post_widget_sub_models/mf_graph_model.dart';
import 'package:multipie/features/post/domain/entities/post_widget.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/create_post.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/custom_bottom_sheet.dart';

class MFGraphScreen extends StatefulWidget {
  final String mutualFundId;

  MFGraphScreen({required this.mutualFundId});

  @override
  _MFGraphScreenState createState() => _MFGraphScreenState();
}

class _MFGraphScreenState extends State<MFGraphScreen> {
  bool showBenchmarkLine = true;
  String dateText = 'At Inception';
  String dateValue = '1900-01-01';
  String mSIPText = 'Monthly SIP';
  bool mSIPValue = true;

  @override
  void initState() {
    BlocProvider.of<MFTimeBloc>(context)
        .add(GetMFTime(widget.mutualFundId, dateValue, mSIPValue));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MFTimeBloc, MFTimeState>(builder: (context, state) {
      if (state is Loading) {
        return Container(
          height: sHeight(280),
          child: Center(
            child: CircularProgressIndicator(),
          ),
        );
      } else if (state is Loaded) {
        return Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '₹1000 invested as',
                  textAlign: TextAlign.center,
                  style: mpHeadLine6(
                    context: context,
                    textColor: context.appTheme.secondaryTextColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                // Investment Type Selector
                GestureDetector(
                  onTap: () {
                    CleverTapPlugin.recordEvent('MF Calculator', {
                      'Source': 'Invested As',
                    });
                    showCustomBottomSheet(
                        context: context,
                        child: MFOptionSheetWidget(
                          onTap: onTap,
                          onTimePeriodCallBak: (String dText, String dValue) {
                            //setState(() {
                            dateText = dText;
                            dateValue = dValue;
                            //});
                          },
                          onMonthlySIPCallBack: (String val, bool isSIP) {
                            //setState(() {
                            mSIPText = val;
                            mSIPValue = isSIP;
                            //});
                          },
                        ),
                        padding: EdgeInsets.all(0));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: context.appTheme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                    child: Text(
                      mSIPText,
                      textAlign: TextAlign.center,
                      style: mpHeadLine6(
                        context: context,
                        textColor: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ),

                // Investment Duration Selector
                GestureDetector(
                  onTap: () {
                    CleverTapPlugin.recordEvent('MF Calculator', {
                      'Source': 'Time Period',
                    });
                    showCustomBottomSheet(
                        context: context,
                        child: MFOptionSheetWidget(
                          onTap: onTap,
                          onTimePeriodCallBak: (String dText, String dValue) {
                            //setState(() {
                            dateText = dText;
                            dateValue = dValue;
                            //});
                          },
                          onMonthlySIPCallBack: (String val, bool isSIP) {
                            //setState(() {
                            mSIPText = val;
                            mSIPValue = isSIP;
                            //});
                          },
                        ),
                        padding: EdgeInsets.all(0));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: context.appTheme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                    child: Text(
                      '$dateText',
                      textAlign: TextAlign.center,
                      style: mpHeadLine6(
                        context: context,
                        textColor: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(right: 8.0),
                  child: Text(
                    'ago',
                    textAlign: TextAlign.center,
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.secondaryTextColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 15, bottom: 5),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          //IRR
                          Padding(
                            padding: EdgeInsets.only(right: 8.0),
                            child: Text(
                              '${twoDigitRoundOffConverter(state.mfTimeSeriesModel.fundReturns!.xirr.toString())}%',
                              style: mpHeadLine4(
                                context: context,
                                fontWeight: FontWeight.w500,
                                textColor: double.parse(state
                                            .mfTimeSeriesModel.fundReturns!.xirr
                                            .toString()) >
                                        0
                                    ? context.appTheme.positiveGainColor
                                    : context.appTheme.negativeGainColor,
                              ),
                            ),
                          ),
                          Text(
                            'IRR',
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.secondaryTextColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 5, bottom: 15),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(right: 8.0),
                            child: Text(
                              '${currencyFormatter(state.mfTimeSeriesModel.fundReturns!.percentageProfitLoss.toString(), 2)}%',
                              style: mpHeadLine5(
                                context: context,
                                fontWeight: FontWeight.w500,
                                textColor: double.parse(state.mfTimeSeriesModel
                                            .fundReturns!.percentageProfitLoss
                                            .toString()) >
                                        0
                                    ? context.appTheme.positiveGainColor
                                    : context.appTheme.negativeGainColor,
                              ),
                            ),
                          ),
                          Text(
                            'Absolute Return',
                            style: mpHeadLine6(
                              context: context,
                              textColor: context.appTheme.secondaryTextColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                state.mfTimeSeriesModel.benchmarkData!.states!.isNotEmpty
                    ? Row(
                        children: [
                          Center(
                            child: Switch(
                              value: showBenchmarkLine,
                              onChanged: (value) {
                                setState(
                                  () {
                                    showBenchmarkLine = value;
                                  },
                                );
                              },
                              activeColor: context.appTheme.blueShadeColor,
                            ),
                          ),
                          Text(
                            'Benchmark',
                            style: mpHeadLine6(
                              context: context,
                              textColor: showBenchmarkLine
                                  ? context.appTheme.blueShadeColor
                                  : context.appTheme.secondaryTextColor,
                            ),
                          ),
                        ],
                      )
                    : Container(),
              ],
            ),
            Container(
              height: sHeight(220),
              child: Padding(
                padding: EdgeInsets.only(left: 15),
                child: MFLineChart(
                  fundReturnsData: state.mfTimeSeriesModel.fundReturns!.states!,
                  benchmarkData: state.mfTimeSeriesModel.benchmarkData!.states!,
                  showBenchmarkLine: showBenchmarkLine,
                ),
              ),
            ),
            DashWithCut(
              onShareTap: () {
                var mfGraphModel = MFGraphModel.fromJson(
                    json.decode(Constants.mfGraphWidgetString));

                final Map<String, dynamic> data = new Map<String, dynamic>();
                data['initial_investment_date'] = dateValue;
                data['initial_investment_year'] = dateText;
                data['initial_investment_type'] = mSIPValue;
                data['to_date'] = mfGraphModel.toDate;
                data['mutual_fund_ext_id'] = mfGraphModel.mutualFundExtId;
                Constants.mfGraphWidgetString = json.encode(data);

                mfGraphModel = MFGraphModel.fromJson(
                    json.decode(Constants.mfGraphWidgetString));
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CreatePost(
                        postWidget: PostWidget(
                            type: 'MFValueTrendWidget',
                            mfGraphModel: mfGraphModel),
                      ),
                    ));
              },
            ),
          ],
        );
      } else if (state is Error) {
        return Container();
      } else {
        return Container();
      }
    });
  }

  onTap() {
    BlocProvider.of<MFTimeBloc>(context)
        .add(GetMFTime(widget.mutualFundId, dateValue, mSIPValue));
  }
}

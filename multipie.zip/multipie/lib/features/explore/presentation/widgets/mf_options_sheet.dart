import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class MFOptionSheetWidget extends StatefulWidget {
  final Function onTap;
  final Function(String text, bool isSIP) onMonthlySIPCallBack;
  final Function(String text, String value) onTimePeriodCallBak;

  const MFOptionSheetWidget({
    required this.onMonthlySIPCallBack,
    required this.onTimePeriodCallBak,
    required this.onTap,
  }) : super();

  @override
  _MFOptionSheetWidgetState createState() => _MFOptionSheetWidgetState();
}

enum InvestmentType { sip, lumpsum }

enum TimePeriodCharacter {
  atInception,
  fiveYears,
  threeYears,
  oneYear,
  sixMonths,
  threeMonths,
}

InvestmentType investmentType = InvestmentType.sip;
TimePeriodCharacter timePeriodCharacter = TimePeriodCharacter.atInception;
var date = new DateTime.now();
var newDate = new DateTime(date.year - 1, date.month, date.day);
String dateSlug =
    "${newDate.year.toString()}-${newDate.month.toString().padLeft(2, '0')}-${newDate.day.toString().padLeft(2, '0')}";
bool isSIP = false;

class _MFOptionSheetWidgetState extends State<MFOptionSheetWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      IntrinsicHeight(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 16.0),
                      child: Text(
                        'INVESTED AS',
                        textAlign: TextAlign.center,
                        style: mpHeadLine6(
                          context: context,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    RadioListTile(
                      value: InvestmentType.sip,
                      groupValue: investmentType,
                      dense: true,
                      onChanged: (InvestmentType? value) {
                        setState(() {
                          investmentType = value!;
                          widget.onMonthlySIPCallBack('Monthly SIP', true);
                          isSIP = true;
                        });
                      },
                      title: Text(
                        "Monthly SIP",
                        style: mpHeadLine6(context: context),
                      ),
                    ),
                    RadioListTile(
                      value: InvestmentType.lumpsum,
                      groupValue: investmentType,
                      dense: true,
                      onChanged: (InvestmentType? value) {
                        setState(() {
                          investmentType = value!;
                          widget.onMonthlySIPCallBack('Lumpsum', false);
                          isSIP = false;
                        });
                      },
                      title: Text(
                        "Lumpsum",
                        style: mpHeadLine6(context: context),
                      ),
                    ),
                  ],
                ),
              ),
              VerticalDivider(
                color: context.appTheme.borderColor,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0),
                          child: Text(
                            'TIME PERIOD',
                            textAlign: TextAlign.center,
                            style: mpHeadLine6(
                              context: context,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    RadioListTile(
                      value: TimePeriodCharacter.atInception,
                      groupValue: timePeriodCharacter,
                      dense: true,
                      onChanged: (TimePeriodCharacter? value) {
                        setState(() {
                          timePeriodCharacter = value!;
                          widget.onTimePeriodCallBak("At Inception", '1900-01-01');
                        });
                      },
                      title: Text(
                        "At Inception",
                        style: mpHeadLine6(context: context),
                      ),
                    ),
                    RadioListTile(
                      value: TimePeriodCharacter.fiveYears,
                      groupValue: timePeriodCharacter,
                      dense: true,
                      onChanged: (TimePeriodCharacter? value) {
                        setState(() {
                          newDate = new DateTime(date.year - 5, date.month, date.day);
                          dateSlug =
                              "${newDate.year.toString()}-${newDate.month.toString().padLeft(2, '0')}-${newDate.day.toString().padLeft(2, '0')}";
                          timePeriodCharacter = value!;
                          widget.onTimePeriodCallBak('5 Years', dateSlug);
                        });
                      },
                      title: Text(
                        "5 Years",
                        style: mpHeadLine6(context: context),
                      ),
                    ),
                    RadioListTile(
                      value: TimePeriodCharacter.threeYears,
                      groupValue: timePeriodCharacter,
                      dense: true,
                      onChanged: (TimePeriodCharacter? value) {
                        setState(() {
                          newDate = new DateTime(date.year - 3, date.month, date.day);
                          dateSlug =
                              "${newDate.year.toString()}-${newDate.month.toString().padLeft(2, '0')}-${newDate.day.toString().padLeft(2, '0')}";
                          timePeriodCharacter = value!;
                          widget.onTimePeriodCallBak("3 Years", dateSlug);
                        });
                      },
                      title: Text(
                        "3 Years",
                        style: mpHeadLine6(context: context),
                      ),
                    ),
                    RadioListTile(
                      value: TimePeriodCharacter.oneYear,
                      groupValue: timePeriodCharacter,
                      dense: true,
                      onChanged: (TimePeriodCharacter? value) {
                        setState(() {
                          newDate = new DateTime(date.year - 1, date.month, date.day);
                          dateSlug =
                              "${newDate.year.toString()}-${newDate.month.toString().padLeft(2, '0')}-${newDate.day.toString().padLeft(2, '0')}";
                          timePeriodCharacter = value!;
                          widget.onTimePeriodCallBak("1 Year", dateSlug);
                        });
                      },
                      title: Text(
                        "1 Year",
                        style: mpHeadLine6(context: context),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0, bottom: 16),
            child: FlatButton(
              textColor: context.appTheme.primaryBackgroundColor,
              color: Theme.of(context).primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              onPressed: () async {
                widget.onTap();
                CleverTapPlugin.recordEvent('MF Calculator', {
                  'Invested As': investmentType.name,
                  'Time Period': timePeriodCharacter.name,
                });
                print("$timePeriodCharacter $investmentType");
                // BlocProvider.of<MFTimeBloc>(context)
                //     .add(GetMFTime(dateSlug, isSIP));

                Navigator.pop(context);
              },
              child: Text(
                'Apply',
                style: mpHeadLine6(
                  context: context,
                  textColor: context.appTheme.cardBackgroundColor,
                ),
              ),
            ),
          ),
        ],
      )
    ]);
  }
}

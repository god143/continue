import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';

class Peer extends StatelessWidget {
  final String fundName;
  final String percentage;
  final bool isBold;

  const Peer({
    required this.fundName,
    required this.isBold,
    required this.percentage,
  }) : super();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            '$fundName',
            textAlign: TextAlign.start,
            style: isBold
                ? mpHeadLine6(
                    context: context,
                    fontWeight: FontWeight.w600,
                  )
                : mpHeadLine6(context: context),
          ),
        ),
        Container(
          constraints: BoxConstraints(minWidth: 50),
          child: Text(
            '$percentage',
            textAlign: TextAlign.end,

            style: isBold
                ? mpHeadLine6(
                    context: context,
                    fontWeight: FontWeight.w600,
                  )
                : mpHeadLine6(context: context),
            // style: TextStyle(
            //     color: context.appTheme.secondaryTextColor,
            //     fontWeight: isBold ? FontWeight.w600 : FontWeight.w400,
            //     fontSize: 12),
          ),
        ),
      ],
    );
  }
}

import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/core/widgets/custom_icon.dart';
import 'package:multipie/core/widgets/list_item_divider.dart';
import 'package:multipie/features/for_you/presentation/cubit/for_you_cubit.dart';
import 'package:multipie/features/for_you/presentation/widgets/toggle_duration_button.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/presentation/bloc/company/company_list/bloc.dart';
import 'package:multipie/features/market/presentation/screens/top_held_stocks/top_held_stocks_screen.dart';
import 'package:multipie/features/market_indexes/domain/entities/market_index.dart';
import 'package:multipie/features/market_indexes/presentation/bloc/bloc.dart' as market;
import 'package:multipie/features/market_indexes/presentation/screens/market_index_screen.dart';
import 'package:multipie/features/watchlist/presentation/blocs/add_remove_watchlist/bloc.dart' as add_remove_watchlist;
import 'package:multipie/locator.dart';
import 'package:multipie/screens/company_screen/company_info_screen.dart';
import 'package:multipie/services/navigation_service.dart';

class StocksToExplore extends StatelessWidget {
  final List<Company>? companies;
  final String searchPhrase;

  StocksToExplore({this.companies, this.searchPhrase = ''});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) {
          // ==> LOAD TOP MOVER STOCKS
          final forYouCubit = context.read<ForYouCubit>();
          if (forYouCubit.state.topMoverStocks.isEmpty) {
            forYouCubit.getTopMoverStocks();
          }
          // <==

          return CompanyBloc(companyList: locator(), topHeldStockList: locator());
        },
        child: _StocksToExplore(companies: companies, searchPhrase: searchPhrase));
  }
}

class _StocksToExplore extends StatefulWidget {
  final List<Company>? companies;
  final String searchPhrase;

  _StocksToExplore({this.companies, this.searchPhrase = ''});

  @override
  _StocksToExploreState createState() => _StocksToExploreState();
}

class _StocksToExploreState extends State<_StocksToExplore> {
  String prevText = '';

  ScrollController _scrollController = ScrollController();
  int page = 1;

  List<Company> listData = [];
  List<Company> listTopHeldData = [];
  int stPageSize = 20;
  bool stHasMoreData = true;
  int topStockCounts = 50;

  @override
  void initState() {
    super.initState();

    listData.clear();
    listTopHeldData.clear();

    BlocProvider.of<CompanyBloc>(context).add(GetListCompanySuggestions(widget.searchPhrase, stPageSize, page));
    BlocProvider.of<CompanyBloc>(context).add(GetListTopHeldStocks('top_held', topStockCounts));
    BlocProvider.of<market.MarketIndexBloc>(context).add(market.GetListMarket());

    _scrollController.addListener(() {
      if (_scrollController.position.maxScrollExtent == _scrollController.position.pixels && stHasMoreData) {
        if (listData.length >= stPageSize) page = ((listData.length / stPageSize) + 1).toInt();
        BlocProvider.of<CompanyBloc>(context).add(GetListCompanySuggestions(widget.searchPhrase, stPageSize, page));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 24.0, right: 24, top: 16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Top held stocks on Multipie",
                      style: mpHeadLine5(
                        context: context,
                        textColor: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    //View All
                    GestureDetector(
                      onTap: () {
                        CleverTapPlugin.recordEvent('Top Stocks See More Clicked', {
                          'source': 'Explore Text',
                        });
                        Navigate.push(context, TopHeldStockScreen(listData: listTopHeldData));
                      },
                      child: Text(
                        'View All',
                        style: mpHeadLine6(
                          context: context,
                          textColor: context.appTheme.secondaryColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),

                //Top Held Stocks List
                InkWell(
                    onTap: () {
                      CleverTapPlugin.recordEvent('Top Stocks See More Clicked', {
                        'source': 'Explore Card',
                      });
                      Navigate.push(context, TopHeldStockScreen(listData: listTopHeldData));
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        vertical: 12,
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          color: context.appTheme.cardBackgroundColor,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: context.appTheme.borderColor,
                            width: 0.5,
                          ),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: TopHeldStocks(
                                listTopHeldData,
                              ),
                            ),
                            Expanded(
                              child: Image.asset(
                                'assets/images/top_held_icon.png',
                                fit: BoxFit.cover,
                                //height: 105,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )),
              ],
            ),
          ),
          //todo :: Verify from what API will we show BSE/NSE Data
          BlocConsumer<market.MarketIndexBloc, market.MarketIndexState>(
            listener: (context, state) {
              if (state is market.Error) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      state.message,
                      style: mpHeadLine6(
                        context: context,
                        textColor: context.appTheme.lightTextColor,
                      ),
                    ),
                  ),
                );
              }
            },
            builder: (context, state) {
              return state is market.Loading
                  ? Center(child: CircularProgressIndicator())
                  : state is market.Loaded
                      ? state.markets.length > 0
                          ? Padding(
                              padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                              child: Column(
                                children: [
                                  Row(
                                    children: buildMarketIndicesWidgets(state.markets.take(2)),
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      CleverTapPlugin.recordEvent('More Indices Explore Stocks', {});
                                      showModalBottomSheet(
                                        backgroundColor: context.appTheme.cardBackgroundColor,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.vertical(top: Radius.circular(15.0)),
                                        ),
                                        context: context,
                                        builder: (context) {
                                          return DraggableScrollableSheet(
                                            initialChildSize: 0.95,
                                            maxChildSize: 0.95,
                                            builder: (context, controller) {
                                              return AllMarketIndicesList(
                                                markets: state.markets,
                                                controller: controller,
                                              );
                                            },
                                            expand: false,
                                          );
                                        },
                                        isScrollControlled: true,
                                      );
                                    },
                                    child: Align(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(0, 8, 8, 0),
                                          child: Wrap(
                                            crossAxisAlignment: WrapCrossAlignment.center,
                                            children: [
                                              Text(
                                                'More Indices',
                                                style: mpHeadLine6(
                                                  context: context,
                                                  textColor: context.appTheme.secondaryColor,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                              Icon(Icons.chevron_right_rounded,
                                                  size: 20, color: context.appTheme.secondaryColor)
                                            ],
                                          ),
                                        ),
                                        alignment: Alignment.centerRight),
                                  ),
                                ],
                              ),
                            )
                          : Container()
                      : Container();
            },
          ),
          BlocBuilder<ForYouCubit, ForYouState>(
            builder: (context, _) {
              return _TopMoverStocksList();
            },
          ),
          //todo :: we will need separate list for trending stocks based on your portfolio
          Padding(
            padding: const EdgeInsets.only(left: 24.0, right: 24, top: 0, bottom: 16),
            child: Text(
              widget.searchPhrase.length > 0 ? "Search Results" : "Trending stocks on Multipie",
              style: mpHeadLine5(
                context: context,
                textColor: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 16),
            child: StocksFromSuggestions(listData, stPageSize, stHasMoreData),
          ),
          SizedBox(height: 70)
        ],
      ),
    );
  }
}

class StockItem extends StatefulWidget {
  final String price;
  final Company data;
  final bool isFromSearch;
  final String stockWatchlistId;
  final Function? showSnackBar;

  StockItem({
    this.price = "100",
    required this.data,
    this.isFromSearch = false,
    this.stockWatchlistId = "undefined",
    this.showSnackBar,
  });

  @override
  _StockItemState createState() => _StockItemState();
}

class _StockItemState extends State<StockItem> {
  late add_remove_watchlist.AddRemoveWatchlistBloc addRemoveWatchlistBloc;

  @override
  void initState() {
    addRemoveWatchlistBloc = BlocProvider.of<add_remove_watchlist.AddRemoveWatchlistBloc>(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () {
            Navigate.push(context, CompanyInfoScreen(companyId: widget.data.id, companyName: widget.data.displayName!));
          },
          child: Padding(
            padding: EdgeInsets.symmetric(
              vertical: 8,
              horizontal: !widget.isFromSearch ? 16 : 0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(),
                  child: widget.data.iconUrl.isEmpty
                      ? Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: context.appTheme.blueShadeColor.withOpacity(0.3),
                          ),
                          child: Center(
                            child: Text(
                              widget.data.name.isNotEmpty ? widget.data.name[0] : widget.data.displayName![0],
                              style: TextStyle(
                                fontSize: 20,
                                color: context.appTheme.primaryColor,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        )
                      : CachedNetworkImage(imageUrl: widget.data.iconUrl),
                ),
                SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (widget.data.nseTicker != null)
                              Text(
                                widget.data.nseTicker ?? '',
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                style: mpHeadLine7(
                                  context: context,
                                  textColor: context.appTheme.secondaryTextColor,
                                ),
                              ),
                            if (widget.data.nseTicker != null)
                              SizedBox(
                                height: 2,
                              ),
                            Text(
                              widget.data.displayName ?? "",
                              textAlign: TextAlign.start,
                              overflow: TextOverflow.ellipsis,
                              style: mpHeadLine6(
                                context: context,
                                textColor: context.appTheme.primaryTextColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!widget.isFromSearch)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              widget.data.lastTradedPrice == 0.0 ? '-' : '₹${widget.data.lastTradedPrice}',
                              textAlign: TextAlign.center,
                              style: mpHeadLine6(
                                context: context,
                                textColor: context.appTheme.primaryTextColor,
                              ),
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            Text(
                              '${widget.data.change > 0 ? '+' : ''}'
                              '${widget.data.change == 0.0 ? '-' : widget.data.change}'
                              ' (${widget.data.percentChange == 0.0 ? '-' : widget.data.percentChange}%)',
                              textAlign: TextAlign.center,
                              style: mpHeadLine6(
                                context: context,
                                textColor: widget.data.change > 0
                                    ? context.appTheme.positiveGainColor
                                    : widget.data.change < 0
                                        ? context.appTheme.negativeGainColor
                                        : context.appTheme.primaryTextColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      if (widget.isFromSearch)
                        InkWell(
                          onTap: () {
                            if (!widget.data.addedToWatchlist) {
                              addRemoveWatchlistBloc.add(
                                add_remove_watchlist.AddWatchlistEvent(
                                    widget.stockWatchlistId, widget.data.id, "stock"),
                              );
                              if (widget.showSnackBar != null) widget.showSnackBar!("Added to watchlist");
                            } else {
                              addRemoveWatchlistBloc.add(
                                add_remove_watchlist.RemoveWatchlistEvent(
                                    widget.stockWatchlistId, widget.data.id, "stock"),
                              );
                              if (widget.showSnackBar != null) widget.showSnackBar!("Removed from watchlist");
                            }

                            setState(
                              () {
                                widget.data.addedToWatchlist = !widget.data.addedToWatchlist;
                              },
                            );

                            final eventData = {
                              'Type': 'Stock',
                              'Name': widget.data.displayName,
                              'Watch': widget.data.addedToWatchlist,
                            };
                            CleverTapPlugin.recordEvent('Watched Investments', eventData);
                          },
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            margin: EdgeInsets.all(5),
                            child: Icon(
                              widget.data.addedToWatchlist ? Icons.bookmark : Icons.bookmark_border,
                              color: Theme.of(context).primaryColor,
                              size: 20,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class TopHeldStockItem extends StatefulWidget {
  final Company data;

  TopHeldStockItem({required this.data, Key? key}) : super(key: key);

  @override
  _TopHeldStockItemState createState() => _TopHeldStockItemState();
}

class _TopHeldStockItemState extends State<TopHeldStockItem> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: 8,
        horizontal: 0,
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 25,
                  height: 25,
                  decoration: BoxDecoration(),
                  child: widget.data.iconUrl.isEmpty
                      ? Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: context.appTheme.blueShadeColor.withOpacity(0.3),
                          ),
                          child: Center(
                            child: Text(
                              widget.data.name.isNotEmpty ? widget.data.name[0] : widget.data.displayName![0],
                              style: TextStyle(
                                fontSize: 12,
                                color: context.appTheme.primaryColor,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        )
                      : CachedNetworkImage(imageUrl: widget.data.iconUrl),
                ),
                SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: Text(
                    widget.data.displayName ?? "",
                    textAlign: TextAlign.start,
                    overflow: TextOverflow.ellipsis,
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.primaryTextColor,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class IndicesItem extends StatelessWidget {
  final MarketIndex marketIndex;

  IndicesItem({
    required this.marketIndex,
  });

  @override
  Widget build(BuildContext context) {
    final name = marketIndex.displayName;
    final price = currencyFormat(double.parse(marketIndex.value).toInt().toString());
    final percentChange = twoDigitRoundOffConverter(marketIndex.percentageChange);
    final change = double.parse(twoDigitRoundOffConverter(marketIndex.absoluteChange));
    int status = change > 0
        ? 1
        : change == 0
            ? 0
            : -1;
    return InkWell(
      onTap: () => Navigate.push(
        context,
        MarketIndexScreen(
          id: marketIndex.id,
          marketIndex: marketIndex,
        ),
      ),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: context.appTheme.cardBackgroundColor,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: context.appTheme.borderColor,
            width: 0.5,
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    name.toUpperCase(),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: mpHeadLine6(
                      context: context,
                      textColor: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  margin: EdgeInsets.only(left: 4),
                  decoration: BoxDecoration(
                    color: colorFromStatus(status, context),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${status == 1 ? '+' : status == -1 ? '-' : ''}${change.toInt()}',
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.lightTextColor,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                Text(
                  '$price',
                  // '₹$price',
                  style: mpHeadLine5(
                    context: context,
                    textColor: context.appTheme.primaryTextColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Spacer(),
                Transform.rotate(
                  angle: status == 0 || status == 1 ? 0 : 180 * pi / 180,
                  child: CustomIcon(
                    CustomIcons.ic_arrow_up,
                    height: 12,
                    width: 12,
                    color: colorFromStatus(status, context),
                  ),
                ),
                SizedBox(width: 8),
                Text(
                  '$percentChange%',
                  style: mpHeadLine6(
                    context: context,
                    textColor: colorFromStatus(status, context),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Color colorFromStatus(int status, BuildContext context) {
    return status == 0
        ? context.appTheme.secondaryTextColor
        : status == 1
            ? context.appTheme.positiveGainColor
            : context.appTheme.negativeGainColor;
  }
}

class StocksFromSuggestions extends StatelessWidget {
  final List<Company> listData;
  final int stPageSize;
  bool stHasMoreData;

  StocksFromSuggestions([
    this.listData = const [],
    this.stPageSize = 20,
    this.stHasMoreData = true,
  ]);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CompanyBloc, CompanyState>(builder: (context, state) {
      if (state is Loading) {
        return Center(
          child: CircularProgressIndicator(),
        );
      }

      if (state is Loaded) {
        if (state.companies.length < stPageSize) {
          stHasMoreData = false;
        } else {
          stHasMoreData = true;
        }
      }

      if (listData.length > 0) {
        return ListView.separated(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: listData.length + 1,
          separatorBuilder: (context, index) {
            if (index == listData.length) {
              if (stHasMoreData == false) return Container();
              return SizedBox();
            }
            return Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
              ),
              child: MPListItemDivider(thickness: 0.2),
            );
          },
          itemBuilder: (context, index) {
            if (index == listData.length) {
              if (stHasMoreData == false) return Container();
              return Container(
                height: 60,
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              );
            }
            return StockItem(data: listData[index]);
          },
        );
      } else {
        return Center(
          child: Text(
            'No Results Found.',
            style: mpHeadLine5(context: context),
          ),
        );
      }
    }, listener: (context, state) {
      if (state is Loaded) {
        listData.addAll(state.companies);
      }
    });
  }
}

class TopHeldStocks extends StatelessWidget {
  final List<Company> listTopHeldData;

  TopHeldStocks([
    this.listTopHeldData = const [],
  ]);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CompanyBloc, CompanyState>(
      listener: (context, state) {
        if (state is LoadedTopHeldStocks) listTopHeldData.addAll(state.topHeldStocks);

        if (state is Error) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
              state.message,
              style: mpHeadLine6(
                context: context,
                textColor: context.appTheme.lightTextColor,
              ),
            ),
          ));
        }
      },
      builder: (context, state) {
        if (listTopHeldData.length > 0) {
          return ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: 3,
            itemBuilder: (context, index) {
              return TopHeldStockItem(data: listTopHeldData[index]);
            },
          );
        } else if (state is Error) {
          return Center(
            child: Text('No data found!'),
          );
        } else {
          return Center(child: CircularProgressIndicator());
        }
      },
    );
  }
}

class _TopMoverStocksList extends StatelessWidget {
  const _TopMoverStocksList({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ForYouCubit>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Top Mover Stocks',
                    style: mpHeadLine5(
                      context: context,
                      textColor: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ToggleDurationButton(
                  value: cubit.state.topMoverStocksPeriod,
                  onPressed: () => cubit.toggleTopMoverStocksDuration(),
                ),
                // TopMoverStocksFilter(),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 16),
            child: Column(
              children: cubit.state.topMoverStocks.map(
                (stock) {
                  return Column(
                    children: [
                      StockItem(
                        data: stock,
                        isFromSearch: false,
                      ),
                      SizedBox(height: 2),
                      Container(
                        height: 0.5,
                        color: context.appTheme.borderColor,
                      ),
                    ],
                  );
                },
              ).toList(growable: false),
            ),
          ),
        ],
      ),
    );
  }
}

List<Widget> buildMarketIndicesWidgets(Iterable<MarketIndex> indicesList) {
  List<Widget> tempList = [];
  indicesList.toList().asMap().forEach((index, MarketIndex element) {
    tempList.add(Expanded(
      child: Padding(
        padding: EdgeInsets.only(right: index == 0 ? 16 : 0),
        child: IndicesItem(marketIndex: element),
      ),
    ));
  });
  return tempList;
}

class AllMarketIndicesList extends StatelessWidget {
  const AllMarketIndicesList({
    Key? key,
    required this.markets,
    required this.controller,
  }) : super(key: key);

  final List<MarketIndex> markets;
  final ScrollController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 70,
          height: 5,
          margin: EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: context.appTheme.borderColor.withAlpha(80),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 15),
          child: Text(
            'Market Indices',
            style: mpHeadLine5(
              context: context,
              textColor: Theme.of(context).primaryColor,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            separatorBuilder: (context, index) {
              return SizedBox(height: 10);
            },
            //gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            controller: controller,
            itemCount: markets.length,
            itemBuilder: (context, index) => IndicesItem(marketIndex: markets[index]),
          ),
        ),
      ],
    );
  }
}

import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/core/utils/share_util.dart';
import 'package:multipie/core/widgets/custom_icon.dart';
import 'package:multipie/core/widgets/mp_tab_bar.dart';
import 'package:multipie/features/explore/presentation/widgets/fund_manager_section_screen.dart';
import 'package:multipie/features/explore/presentation/widgets/mf_options_sheet.dart';
import 'package:multipie/features/explore/presentation/widgets/peer_screen.dart';
import 'package:multipie/features/explore/presentation/widgets/sector_holding.dart';
import 'package:multipie/features/market/presentation/widgets/mutual_funds/mf_investors_section.dart';
import 'package:multipie/features/mf_timeperiod/presentation/screens/see_multipie_view.dart';
import 'package:multipie/features/mutual_fund/presentation/bloc/bloc.dart';
import 'package:multipie/features/mutual_fund/presentation/cubit/mutual_fund_conversations_cubit.dart';
import 'package:multipie/features/mutual_fund/presentation/widgets/mutual_fund_conversations_widget.dart';
import 'package:multipie/features/post/data/models/post_widget_sub_models/mf_performance.dart';
import 'package:multipie/features/post/domain/entities/post_widget.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/create_post.dart';
import 'package:multipie/features/watchlist/presentation/blocs/add_remove_watchlist/bloc.dart' as add_remove_watchlist;
import 'package:multipie/features/watchlist/presentation/blocs/get_watchlist/bloc.dart' as watchlist_bloc;
import 'package:multipie/features/watchlist/presentation/blocs/watchlist_mf/bloc.dart' as watchlist_mf;
import 'package:multipie/locator.dart';
import 'package:provider/provider.dart';

import 'all_mf_holdings_screen.dart';
import 'dash_line_with_cut_widget.dart';
import 'lumb_sum.dart';
import 'mf_graph_screen.dart';
import 'performance_section_screen.dart';
import 'showing_border_widget.dart';

enum _TabType {
  conversations,
  performance,
  peerComparision,
  holding,
  fundManager,
}

const _tabNames = {
  _TabType.conversations: 'Conversations',
  _TabType.performance: 'Performance',
  _TabType.peerComparision: 'Peer Comparison',
  _TabType.holding: 'Holdings',
  _TabType.fundManager: 'Fund Manager',
};

const _tabs = [
  _TabType.conversations,
  _TabType.performance,
  _TabType.peerComparision,
  _TabType.holding,
  _TabType.fundManager,
];

class MutualFundScreen extends StatefulWidget {
  final String mutualFundName;
  final String mutualFundId;

  const MutualFundScreen({required this.mutualFundName, required this.mutualFundId}) : super();

  @override
  _MutualFundScreenState createState() => _MutualFundScreenState();
}

class _MutualFundScreenState extends State<MutualFundScreen> with TickerProviderStateMixin {
  late TabController _tabController;

  List<String> years = ['1', '3', '5'];
  int i = 0;
  TabController? holdingsSubTabsController;

  add_remove_watchlist.AddRemoveWatchlistBloc? addRemoveWatchlistBloc;
  late watchlist_bloc.GetWatchlistBloc getWatchlistBloc;
  bool bookmarkAdded = false;
  String watchlistId = "undefined";
  bool prevBookmark = false;
  watchlist_mf.WatchlistMfBloc? watchlistMfBloc;

  @override
  void initState() {
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController.addListener(_onTabScrolled);

    holdingsSubTabsController = new TabController(length: 2, vsync: this);
    holdingsSubTabsController!.index = 0;
    BlocProvider.of<MutualFundBloc>(context).add(GetMutualFundOne(widget.mutualFundId));
    investmentType = InvestmentType.sip;
    timePeriodCharacter = TimePeriodCharacter.atInception;

    addRemoveWatchlistBloc = BlocProvider.of<add_remove_watchlist.AddRemoveWatchlistBloc>(context);
    getWatchlistBloc = BlocProvider.of<watchlist_bloc.GetWatchlistBloc>(context);
    getWatchlistBloc.add(watchlist_bloc.FetchWatchlistDataEvent());
    super.initState();
  }

  void _onTabScrolled() {
    if (!_tabController.indexIsChanging) {
      final selectedTab = _tabs[_tabController.index];
      switch (selectedTab) {
        case _TabType.conversations:
          CleverTapPlugin.recordEvent('Conversations On The Mutual Fund', _defaultAnalyticsEventData);
          break;
        case _TabType.performance:
          CleverTapPlugin.recordEvent('Performance', _defaultAnalyticsEventData);
          break;
        case _TabType.peerComparision:
          CleverTapPlugin.recordEvent('Peer Comparison', _defaultAnalyticsEventData);
          break;
        case _TabType.holding:
          CleverTapPlugin.recordEvent('Holdings', _defaultAnalyticsEventData);
          break;
        case _TabType.fundManager:
          CleverTapPlugin.recordEvent('Fund Manager', _defaultAnalyticsEventData);
          break;
      }
    }
  }

  @override
  void didChangeDependencies() {
    watchlistMfBloc = BlocProvider.of<watchlist_mf.WatchlistMfBloc>(context);
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    if (prevBookmark != bookmarkAdded) {
      watchlistMfBloc!.add(watchlist_mf.FetchWatchlistMutualFundsEvent());
      getWatchlistBloc.add(watchlist_bloc.FetchWatchlistDataEvent());
    }

    _tabController.removeListener(_onTabScrolled);
    _tabController.dispose();

    super.dispose();
  }

  Map<String, dynamic> get _defaultAnalyticsEventData => {
        'Type': 'Mutual Fund',
        'Name': widget.mutualFundName,
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: MultipieAppBar(
          title: '${widget.mutualFundName}',
          actions: [
            Center(
              child: InkWell(
                onTap: () {
                  if (!bookmarkAdded)
                    addRemoveWatchlistBloc!
                        .add(add_remove_watchlist.AddWatchlistEvent(watchlistId, widget.mutualFundId, "mutual_fund"));
                  else
                    addRemoveWatchlistBloc!.add(
                        add_remove_watchlist.RemoveWatchlistEvent(watchlistId, widget.mutualFundId, "mutual_fund"));

                  setState(() {
                    bookmarkAdded = !bookmarkAdded;
                  });
                  final eventData = {
                    ..._defaultAnalyticsEventData,
                    'Watch': bookmarkAdded,
                  };
                  CleverTapPlugin.recordEvent('Watched Investments', eventData);
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    color: Theme.of(context).primaryColor.withOpacity(0.15),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      child: Row(
                        children: [
                          Icon(bookmarkAdded ? Icons.bookmark : Icons.bookmark_border),
                          SizedBox(width: 4),
                          Text(
                            bookmarkAdded ? 'WATCHED' : 'WATCH',
                            style: Theme.of(context).textTheme.button?.copyWith(
                                  color: Theme.of(context).primaryColor,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            InkWell(
              onTap: () {
                shareMutualFundDashboard(
                  mutualFundId: widget.mutualFundId,
                  mutualFundName: widget.mutualFundName,
                );
              },
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0, right: 15.0),
                child: CustomIcon(
                  CustomIcons.share2,
                  color: context.appTheme.primaryColor,
                  height: 18,
                  width: 18,
                ),
              ),
            ),
          ],
        ),
        body: Stack(
          children: [
            BlocBuilder<MutualFundBloc, MutualFundState>(
              builder: (context, state) {
                if (state is Loading) {
                  return Center(child: CircularProgressIndicator());
                } else if (state is Loaded) {
                  CleverTapPlugin.recordEvent('Viewed Investments', _defaultAnalyticsEventData);
                  return NestedScrollView(
                    headerSliverBuilder: (context, innerBoxIsScrolled) {
                      return [
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 15),
                            child: Column(
                              children: [
                                MFInvestorsSection(mfId: widget.mutualFundId),
                                Padding(
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      //Mutual Fund Logo
                                      SizedBox(
                                        width: 35,
                                        height: 35,
                                        child: state.mutualFundModelOne.companyUrl == null
                                            ? Container(
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: context.appTheme.blueShadeColor.withOpacity(0.3),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    state.mutualFundModelOne.displayName![0],
                                                    style: TextStyle(
                                                        fontSize: 20,
                                                        color: Theme.of(context).primaryColor,
                                                        fontWeight: FontWeight.w400),
                                                  ),
                                                ),
                                              )
                                            : CachedNetworkImage(
                                                imageUrl: "https://assets.multipie.co" +
                                                    state.mutualFundModelOne.companyUrl!),
                                      ),

                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            //Mutual Fund Name
                                            Container(
                                              child: Padding(
                                                padding: const EdgeInsets.only(top: 5.0, right: 25),
                                                child: Text(
                                                  '${state.mutualFundModelOne.displayName}',
                                                  style: mpHeadLine4(
                                                    context: context,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: 15),
                                            Row(
                                              children: [
                                                ShowingBorderWidget(
                                                  text: '${state.mutualFundModelOne.risk}',
                                                ),
                                                SizedBox(width: 8),
                                                ShowingBorderWidget(
                                                  text: '${state.mutualFundModelOne.categoryLevel1}',
                                                ),
                                                SizedBox(width: 8),
                                                ShowingBorderWidget(
                                                  text: '${state.mutualFundModelOne.fundCategory}',
                                                )
                                              ],
                                            ),
                                            SizedBox(height: 15),

                                            // See Multipie View
                                            GestureDetector(
                                              onTap: () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => SeeMultipieView(),
                                                  ),
                                                );
                                              },
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    child: Container(
                                                      height: 12,
                                                      width: 12,
                                                      child: SvgPicture.asset('assets/icons/star_mutual.svg'),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.only(
                                                      right: 5.0,
                                                      left: 5,
                                                    ),
                                                    child: Text(
                                                      'See Multipie view',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(
                                                        color: context.appTheme.secondaryTextColor,
                                                        fontSize: sSp(12.0),
                                                        decoration: TextDecoration.underline,
                                                      ),
                                                    ),
                                                  ),
                                                  Center(
                                                    child: SvgPicture.asset(
                                                      'assets/icons/forward_mutual.svg',
                                                      alignment: Alignment.center,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),

                                MFGraphScreen(
                                  mutualFundId: widget.mutualFundId,
                                ),

                                Container(
                                  height: 200,
                                  child: MutualFundLumpSumScreen(
                                    state.mutualFundModelOne.expenseRatio == null
                                        ? '0.0'
                                        : state.mutualFundModelOne.expenseRatio!,
                                    currencyFormatMFCR(state.mutualFundModelOne.fundSize == null
                                        ? '0.0'
                                        : state.mutualFundModelOne.fundSize!),
                                    currencyFormatMF(state.mutualFundModelOne.minLumpsum == null
                                        ? '0.0'
                                        : state.mutualFundModelOne.minLumpsum!),
                                    currencyFormatMF(state.mutualFundModelOne.minSip == null
                                        ? '0.0'
                                        : state.mutualFundModelOne.minSip!),
                                  ),
                                ),
                                // Divider(thickness: 1),
                                DashWithCut(
                                  onShareTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => CreatePost(
                                            postWidget: PostWidget(
                                                type: 'MFValueInfoWidget',
                                                expenseRatio: state.mutualFundModelOne.expenseRatio.toString(),
                                                fundSize: state.mutualFundModelOne.fundSize.toString(),
                                                minLumpSum: state.mutualFundModelOne.minLumpsum.toString(),
                                                minSip: state.mutualFundModelOne.minSip.toString()),
                                          ),
                                        ));
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                        SliverAppBar(
                          leading: SizedBox(),
                          leadingWidth: 0,
                          elevation: 0,
                          title: MPTabBar(
                            tabController: _tabController,
                            tabsCount: _tabs.length,
                            getTabTitle: (index) => _tabNames[_tabs[index]] ?? '?',
                            isTabScrollable: true,
                          ),
                          pinned: true,
                        ),
                      ];
                    },
                    body: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 15),
                      child: TabBarView(
                        controller: _tabController,
                        children: [
                          // Conversations
                          Provider(
                            create: (context) => MutualFundConversationsCubit(
                              id: widget.mutualFundId,
                              repository: locator(),
                            )..refresh(),
                            child: MutualFundConversationsWidget(),
                          ),

                          // Performance
                          buildPerformanceSection(context,
                              oneYear: state.mutualFundModelOne.mutualFundsReturnFor1Year == null
                                  ? '0.0'
                                  : state.mutualFundModelOne.mutualFundsReturnFor1Year!,
                              fiveYear: state.mutualFundModelOne.mutualFundsReturnFor5Year == null
                                  ? '0.0'
                                  : state.mutualFundModelOne.mutualFundsReturnFor5Year!,
                              threeYear: state.mutualFundModelOne.mutualFundsReturnFor3Year == null
                                  ? '0.0'
                                  : state.mutualFundModelOne.mutualFundsReturnFor3Year!,
                              sinceInception: state.mutualFundModelOne.mutualFundsReturnSinceInception == null
                                  ? '0.0'
                                  : state.mutualFundModelOne.mutualFundsReturnSinceInception!),

                          // Peer Comparison
                          SingleChildScrollView(
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Fund Name',
                                        textAlign: TextAlign.start,
                                        style: mpHeadLine6(
                                          context: context,
                                          textColor: Theme.of(context).primaryColor,
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          setState(() {
                                            if (i == 2) {
                                              i = 0;
                                            } else {
                                              i++;
                                            }
                                          });
                                        },
                                        child: Container(
                                          height: 20,
                                          padding: EdgeInsets.symmetric(horizontal: 10),
                                          decoration: BoxDecoration(
                                            color: context.appTheme.blueShadeColor.withOpacity(0.15),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Row(
                                            children: [
                                              Text(
                                                '${years[i]} Year',
                                                style: TextStyle(
                                                  color: context.appTheme.blueShadeColor,
                                                  fontFamily: 'Roboto',
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                              SizedBox(width: 4),
                                              Image.asset(
                                                'assets/images/exchange.png',
                                                color: context.appTheme.blueShadeColor,
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 8),
                                    child: Peer(
                                        isBold: true,
                                        fundName: '${state.mutualFundModelOne.displayName}',
                                        percentage: i == 0
                                            ? '${percentageConverter(state.mutualFundModelOne.mutualFundsReturnFor1Year == null ? '0.0' : state.mutualFundModelOne.mutualFundsReturnFor1Year!)}'
                                            : i == 1
                                                ? '${percentageConverter(state.mutualFundModelOne.mutualFundsReturnFor3Year == null ? '0.0' : state.mutualFundModelOne.mutualFundsReturnFor3Year!)}'
                                                : '${percentageConverter(state.mutualFundModelOne.mutualFundsReturnFor5Year == null ? '0.0' : state.mutualFundModelOne.mutualFundsReturnFor5Year!)}')),
                                ListView.builder(
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemCount: state.mutualFundModelOne.peerReturns.length,
                                    itemBuilder: (context, index) {
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 8),
                                        child: Peer(
                                            isBold: false,
                                            fundName: state.mutualFundModelOne.peerReturns[index].displayName,
                                            percentage: i == 0
                                                ? state.mutualFundModelOne.peerReturns[index].returns
                                                    .mutualFundsReturnFor1Year
                                                : i == 1
                                                    ? state.mutualFundModelOne.peerReturns[index].returns
                                                        .mutualFundsReturnFor3Year
                                                    : state.mutualFundModelOne.peerReturns[index].returns
                                                        .mutualFundsReturnFor5Year),
                                      );
                                    }),
                                DashWithCut(
                                  onShareTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => CreatePost(
                                            postWidget: PostWidget(
                                                type: 'MFPeerComparisonWidget', mfDetail: state.mutualFundModelOne),
                                          ),
                                        ));
                                  },
                                )
                              ],
                            ),
                          ),

                          // Holding
                          SingleChildScrollView(
                            child: Column(
                              children: [
                                TabBar(
                                  controller: holdingsSubTabsController,
                                  indicatorSize: TabBarIndicatorSize.tab,
                                  labelStyle: mpHeadLine5(context: context),
                                  unselectedLabelColor: context.appTheme.borderColor,
                                  indicatorColor: context.appTheme.blueShadeColor,
                                  indicatorWeight: 3.0,
                                  labelColor: context.appTheme.blueShadeColor,
                                  indicatorPadding: const EdgeInsets.fromLTRB(8, 5, 8, 5),
                                  isScrollable: false,
                                  tabs: <Widget>[
                                    buildTab(0, "Holdings"),
                                    buildTab(1,
                                        state.mutualFundModelOne.categoryLevel1 == 'Debt' ? 'Ratings' : "Sector Wise"),
                                  ],
                                ),
                                SizedBox(
                                  height: 210.0,
                                  child: TabBarView(
                                    controller: holdingsSubTabsController,
                                    children: [
                                      state.mutualFundModelOne.instrumentHoldings.length != 0
                                          ? Column(
                                              children: [
                                                ListView.builder(
                                                    shrinkWrap: true,
                                                    physics: NeverScrollableScrollPhysics(),
                                                    itemCount: 5,
                                                    itemBuilder: (context, index) {
                                                      return Holding(
                                                        isViewAll: false,
                                                        holdingName: state
                                                            .mutualFundModelOne
                                                            .instrumentHoldings[
                                                                state.mutualFundModelOne.instrumentHoldings.length -
                                                                    1 -
                                                                    index]
                                                            .name
                                                            .toString(),
                                                        percentage: state
                                                                .mutualFundModelOne
                                                                .instrumentHoldings[
                                                                    state.mutualFundModelOne.instrumentHoldings.length -
                                                                        1 -
                                                                        index]
                                                                .weight
                                                                .toString() +
                                                            '%',
                                                      );
                                                    }),
                                                InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (context) => MFHoldingScreen(
                                                          companyName: '${state.mutualFundModelOne.displayName}',
                                                          instrumentHoldingList:
                                                              state.mutualFundModelOne.instrumentHoldings,
                                                          instrumentSectorsList:
                                                              state.mutualFundModelOne.instrumentSectors,
                                                          instrumentRatingsList:
                                                              state.mutualFundModelOne.instrumentRatings,
                                                          isDebt: state.mutualFundModelOne.categoryLevel1 == 'Debt',
                                                          showIndex: 0,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                  child: Center(
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(10.0),
                                                      child: Text(
                                                        'View All',
                                                        style: TextStyle(
                                                          fontSize: 16,
                                                          color: context.appTheme.blueShadeColor,
                                                          fontWeight: FontWeight.w700,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            )
                                          : Container(
                                              child: Center(
                                                  child: Text(
                                                "No Data Available...",
                                                style: mpHeadLine5(
                                                  context: context,
                                                  textColor: context.appTheme.primaryColor,
                                                ),
                                              )),
                                            ),
                                      state.mutualFundModelOne.instrumentSectors.length != 0 ||
                                              state.mutualFundModelOne.instrumentRatings.length != 0
                                          ? Column(
                                              children: [
                                                ListView.builder(
                                                    shrinkWrap: true,
                                                    physics: NeverScrollableScrollPhysics(),
                                                    itemCount: 5,
                                                    itemBuilder: (context, index) {
                                                      return Holding(
                                                        isViewAll: false,
                                                        holdingName: state.mutualFundModelOne.categoryLevel1 == 'Debt'
                                                            ? state.mutualFundModelOne.instrumentRatings[index].label
                                                                .toString()
                                                            : state.mutualFundModelOne.instrumentSectors[index].label
                                                                .toString(),
                                                        percentage: currencyFormatter(
                                                                state.mutualFundModelOne.categoryLevel1 == 'Debt'
                                                                    ? state.mutualFundModelOne.instrumentRatings[index]
                                                                        .weight
                                                                        .toString()
                                                                    : state.mutualFundModelOne.instrumentSectors[index]
                                                                        .weight
                                                                        .toString(),
                                                                2) +
                                                            '%',
                                                      );
                                                    }),
                                                InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) => MFHoldingScreen(
                                                            companyName: '${state.mutualFundModelOne.displayName}',
                                                            instrumentHoldingList:
                                                                state.mutualFundModelOne.instrumentHoldings,
                                                            instrumentSectorsList:
                                                                state.mutualFundModelOne.instrumentSectors,
                                                            instrumentRatingsList:
                                                                state.mutualFundModelOne.instrumentRatings,
                                                            isDebt: state.mutualFundModelOne.categoryLevel1 == 'Debt',
                                                            showIndex: 1,
                                                          ),
                                                        ));
                                                  },
                                                  child: Center(
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(10.0),
                                                      child: Text(
                                                        'View All',
                                                        style: TextStyle(
                                                          fontSize: 16,
                                                          color: context.appTheme.blueShadeColor,
                                                          fontWeight: FontWeight.w700,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            )
                                          : Container(
                                              child: Center(
                                                  child: Text(
                                                "No Data Available...",
                                                style: mpHeadLine5(
                                                  context: context,
                                                  textColor: context.appTheme.primaryColor,
                                                ),
                                              )),
                                            ),
                                    ],
                                  ),
                                ),
                                DashWithCut(
                                  onShareTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => CreatePost(
                                          postWidget:
                                              PostWidget(type: 'MFHoldingsWidget', mfDetail: state.mutualFundModelOne),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),

                          // Fund Manager
                          SingleChildScrollView(
                            child: Column(
                              children: [
                                state.mutualFundModelOne.fundManagers.isEmpty
                                    ? Padding(
                                        padding: const EdgeInsets.all(20.0),
                                        child: Center(
                                            child: Text(
                                          "No Data Available...",
                                          style: mpHeadLine5(
                                            context: context,
                                            textColor: context.appTheme.primaryColor,
                                          ),
                                        )),
                                      )
                                    : ListView.builder(
                                        shrinkWrap: true,
                                        physics: NeverScrollableScrollPhysics(),
                                        itemCount: state.mutualFundModelOne.fundManagers.length > 5
                                            ? 5
                                            : state.mutualFundModelOne.fundManagers.length,
                                        itemBuilder: (context, index) {
                                          return Padding(
                                            padding: const EdgeInsets.symmetric(vertical: 8),
                                            child: FoundManagerSection(
                                              fundManager: state.mutualFundModelOne.fundManagers[index],
                                            ),
                                          );
                                        },
                                      ),
                                // DashWithCut(),
                              ],
                            ),
                          ),

                          // ! Similar Funds  Please don't delete this
                          //  Similar Funds
                          /*  CustomExpansionTile(
                      tilePadding: EdgeInsets.only(left: 16, right: 16),
                      title: Text(
                        "Similar Funds",
                        style: TextStyle(
                          color: isSimilerFundManagerExpanded
                              ? context.appTheme.lightBlueColor
                              : context.appTheme.primaryColor,
                          fontFamily: 'Roboto',
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(
                        isSimilerFundManagerExpanded
                            ? Icons.remove
                            : Icons.add_rounded,
                        color: isSimilerFundManagerExpanded
                            ? old.context.appTheme.lightBlueColor
                            : old.context.appTheme.primaryColor,
                        size: 20,
                      ),
                      onExpansionChanged: (bool expanding) => setState(
                          () => this.isSimilerFundManagerExpanded = expanding),
                      children: [
                        SimilarFundSection(),
                        DashWithCut(),
                      ],
                    ),
                  */
                        ],
                      ),
                    ),
                  );
                } else if (state is Error) {
                  return Container();
                } else {
                  return Container();
                }
              },
            ),
            BlocConsumer<watchlist_bloc.GetWatchlistBloc, watchlist_bloc.GetWatchlistState>(builder: (context, state) {
              return Container();
            }, listener: (context, state) {
              if (state is watchlist_bloc.Loaded) {
                for (int i = 0; i < state.list.length; i++) {
                  if (state.list[i].instrument_type == "mutual_fund") {
                    watchlistId = state.list[i].id.toString();
                    setState(() {
                      bookmarkAdded =
                          state.list[i].instrument_ids.where((x) => x != null).contains(int.parse(widget.mutualFundId));
                      prevBookmark = bookmarkAdded;
                    });
                  }
                }
              }
            })
          ],
        ));
  }

  Widget buildPerformanceSection(BuildContext context,
      {required String oneYear, required String threeYear, required String fiveYear, required String sinceInception}) {
    List<String> returns = ['', 'Annualized Returns', 'Benchmark Returns', 'Rank Within Category'];
    List<String> oneYearList = ['1Y', '${percentageConverter(oneYear)}', '-', '-'];
    List<String> thereYearList = ['3Y', '${percentageConverter(threeYear)}', '-', '-'];
    List<String> fiveYearList = ['5Y', '${percentageConverter(fiveYear)}', '-', '-'];
    List<String> allYearList = ['ALL', '${percentageConverter(sinceInception)}', '-', '-'];
    return SingleChildScrollView(
      child: Column(
        children: [
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: returns.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: MFPerformanceItem(
                  wantToCentralAlig: index == 0 ? true : false,
                  annualizedReturns: returns[index],
                  oneYear: oneYearList[index],
                  threeY: thereYearList[index],
                  fiveY: fiveYearList[index],
                  allY: allYearList[index],
                ),
              );
            },
          ),
          DashWithCut(
            onShareTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CreatePost(
                          postWidget: PostWidget(
                              type: 'MFPerformanceWidget',
                              mfPerformance: MFPerformance.fromJson(json.decode(Constants.mfPerformanceWidgetString))
                              // mfPerformance:
                              ))));
            },
          )
        ],
      ),
    );
  }

  Widget buildTab(int pos, String title) {
    return Tab(
      text: title,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/explore/presentation/widgets/sector_holding.dart';
import 'package:multipie/features/mutual_fund/data/model/mutual_fund_model.dart';

class MFHoldingScreen extends StatefulWidget {
  final List<InstrumentHoldings> instrumentHoldingList;
  final List<InstrumentSectors> instrumentSectorsList;
  final List<InstrumentRatings> instrumentRatingsList;
  final String companyName;
  final bool isDebt;
  final int showIndex;

  const MFHoldingScreen({
    required this.instrumentHoldingList,
    required this.instrumentSectorsList,
    required this.instrumentRatingsList,
    required this.companyName,
    this.isDebt = false,
    this.showIndex = 0,
  }) : super();

  @override
  _MFHoldingScreenState createState() => _MFHoldingScreenState();
}

late TabController _tabController;

class _MFHoldingScreenState extends State<MFHoldingScreen> with SingleTickerProviderStateMixin {
  @override
  void initState() {
    _tabController = new TabController(
      length: 2,
      vsync: this,
    );
    _tabController.index = widget.showIndex;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 1,
        titleSpacing: 0,
        leading: InkWell(
          child: Padding(
            padding: const EdgeInsets.all(17.5),
            child: SvgPicture.asset(
              'assets/icons/Arrow-Previous.svg',
              color: context.appTheme.primaryColor,
              height: 20,
              width: 20,
            ),
          ),
          onTap: () => Navigator.pop(context),
        ),
        title: Text(
          "${widget.companyName}",
          style: mpHeadLine4(
            context: context,
            fontWeight: FontWeight.w500,
            textColor: context.appTheme.primaryColor,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorSize: TabBarIndicatorSize.tab,
          labelStyle: mpHeadLine5(context: context),
          unselectedLabelColor: context.appTheme.borderColor,
          indicatorColor: context.appTheme.blueShadeColor,
          indicatorWeight: 3.0,
          labelColor: context.appTheme.blueShadeColor,
          indicatorPadding: const EdgeInsets.fromLTRB(8, 5, 8, 5),
          isScrollable: false,
          tabs: <Widget>[
            buildTab(0, "Holdings"),
            buildTab(1, widget.isDebt ? 'Ratings' : "Sector Wise"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          ListView.builder(
              shrinkWrap: true,
              physics: ScrollPhysics(),
              itemCount: widget.instrumentHoldingList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Holding(
                    isViewAll: false,
                    holdingName:
                        widget.instrumentHoldingList[widget.instrumentHoldingList.length - 1 - index].name.toString(),
                    percentage: widget.instrumentHoldingList[widget.instrumentHoldingList.length - 1 - index].weight
                            .toString() +
                        '%',
                  ),
                );
              }),
          ListView.builder(
              shrinkWrap: true,
              physics: ScrollPhysics(),
              itemCount: widget.isDebt ? widget.instrumentRatingsList.length : widget.instrumentSectorsList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Holding(
                    isViewAll: false,
                    holdingName: widget.isDebt
                        ? widget.instrumentRatingsList[index].label.toString()
                        : widget.instrumentSectorsList[index].label.toString(),
                    percentage: currencyFormatter(
                            widget.isDebt
                                ? widget.instrumentRatingsList[index].weight.toString()
                                : widget.instrumentSectorsList[index].weight.toString(),
                            2) +
                        '%',
                  ),
                );
              }),
        ],
      ),
    );
  }

  Widget buildTab(int pos, String title) {
    return Tab(
      text: title,
    );
  }
}

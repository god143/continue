import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class FoundManagerSection extends StatefulWidget {
  final String fundManager;
  const FoundManagerSection({required this.fundManager}) : super();

  @override
  _FoundManagerSectionState createState() => _FoundManagerSectionState();
}

class _FoundManagerSectionState extends State<FoundManagerSection> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: context.appTheme.blueShadeColor.withOpacity(0.3),
            ),
            child: Center(
              child: Text(
                "${widget.fundManager[0]}",
                style: TextStyle(fontSize: 20, color: context.appTheme.primaryColor, fontWeight: FontWeight.w400),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 15),
            child: Text(
              "${widget.fundManager}",
              textAlign: TextAlign.start,
              overflow: TextOverflow.ellipsis,
              style: mpHeadLine5(
                context: context,
                textColor: context.appTheme.primaryColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

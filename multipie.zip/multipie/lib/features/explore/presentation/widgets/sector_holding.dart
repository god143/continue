import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';

class Holding extends StatelessWidget {
  final String holdingName;
  final String percentage;
  final bool isViewAll;
  late Function onPressed;

  Holding({
    required this.holdingName,
    required this.isViewAll,
    required this.percentage,
  }) : super();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              '$holdingName',
              textAlign: TextAlign.start,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: mpHeadLine6(context: context),
            ),
          ),
          Container(
            constraints: BoxConstraints(minWidth: 50),
            child: Text(
              '$percentage',
              textAlign: TextAlign.end,
              style: mpHeadLine6(
                context: context,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

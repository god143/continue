import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

class PerformanceSectionStatic extends StatelessWidget {
  const PerformanceSectionStatic() : super();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(
            flex: 5,
            child: Text(
              "",
              textAlign: TextAlign.center,
              style: TextStyle(color: context.appTheme.secondaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
            ),
          ),
          Expanded(
              flex: 2,
              child: Text(
                '1Y',
                textAlign: TextAlign.center,
                style: TextStyle(color: context.appTheme.secondaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
              )),
          Expanded(
            flex: 2,
            child: Text(
              '3Y',
              textAlign: TextAlign.center,
              style: TextStyle(color: context.appTheme.secondaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '5Y',
              textAlign: TextAlign.center,
              style: TextStyle(color: context.appTheme.secondaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'ALL',
              textAlign: TextAlign.center,
              style: TextStyle(color: context.appTheme.secondaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

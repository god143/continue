import 'package:flutter/material.dart';
import 'package:multipie/core/theme/app_theme.dart';
import 'package:multipie/core/utils/extensions.dart';

class MutualFundLumpSumScreen extends StatelessWidget {
  final String expenseRatio;
  final String fundSize;
  final String minLumpsum;
  final String minSip;
  MutualFundLumpSumScreen(this.expenseRatio, this.fundSize, this.minLumpsum, this.minSip);

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      childAspectRatio: 2,
      crossAxisCount: 2,
      physics: NeverScrollableScrollPhysics(),
      padding: EdgeInsets.all(0),
      children: [
        infoContainer(
          "Expense Ratio",
          expenseRatio + "%",
          context,
        ),
        infoContainer(
          "Fund Size ",
          fundSize,
          context,
        ),
        infoContainer(
          "Minimum Lumpsum",
          minLumpsum,
          context,
        ),
        infoContainer(
          "Minimum SIP",
          minSip,
          context,
        ),
      ],
    );
  }

  Widget infoContainer(title, value, BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Text(
          value,
          style: TextStyle(
            color: context.appTheme.primaryTextColor,
            fontFamily: 'Roboto',
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 5),
        Text(
          title,
          maxLines: 2,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: context.appTheme.secondaryTextColor,
            fontFamily: 'Roboto',
            fontSize: 12,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

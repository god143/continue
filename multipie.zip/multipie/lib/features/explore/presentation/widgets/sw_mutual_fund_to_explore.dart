import 'package:cached_network_image/cached_network_image.dart';
import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/presentation/screens/mf_list_by_type_screen.dart';
import 'package:multipie/features/explore/presentation/screens/mf_list_screen.dart';
import 'package:multipie/features/explore/presentation/screens/top_held_mf_screen.dart';
import 'package:multipie/features/explore/presentation/widgets/mutual_fund_screen.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mp_mf_collection.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/top_mutual_fund.dart';
import 'package:multipie/features/market/presentation/bloc/mutual_fund/mf_list_by_type/bloc.dart' as mf;
import 'package:multipie/features/market/presentation/bloc/mutual_fund/mf_top_held/mf_top_held_bloc.dart';
import 'package:multipie/features/market/presentation/bloc/mutual_fund/mf_top_held/mf_top_held_event.dart';
import 'package:multipie/features/market/presentation/bloc/mutual_fund/mf_top_held/mf_top_held_state.dart';
import 'package:multipie/features/market/presentation/bloc/mutual_fund/mp_mf_collection/bloc.dart';
import 'package:multipie/features/watchlist/presentation/blocs/add_remove_watchlist/bloc.dart' as add_remove_watchlist;
import 'package:multipie/locator.dart';

class MutualFundToExplore extends StatelessWidget {
  final List<MPMutualFundCollection>? mpMutualFundCollection;
  final String searchPhrase;

  MutualFundToExplore({this.mpMutualFundCollection, this.searchPhrase = ''});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) => mf.MFListByTypeBloc(getMFListByType: locator()),
        child: _MutualFundToExplore(mpMutualFundCollection: mpMutualFundCollection, searchPhrase: searchPhrase));
  }
}

class _MutualFundToExplore extends StatefulWidget {
  final List<MPMutualFundCollection>? mpMutualFundCollection;
  final String searchPhrase;

  _MutualFundToExplore({this.mpMutualFundCollection, this.searchPhrase = ''});

  @override
  _MutualFundToExploreState createState() => _MutualFundToExploreState();
}

class _MutualFundToExploreState extends State<_MutualFundToExplore> {
  List<String> duration = ["1 Month", "1 Year", "3 Years", "5 Years", "All"];
  int selection = 0;
  String prevText = '';
  int tapIndex = 1;
  List<TopHeldMutualFund> listTopHeldData = [];
  int topMFCounts = 50;

  List<String> seasonalFundsTitle = [
    "NFO Live",
    "Invite & Earn",
    "Smart Save",
  ];
  List<String> seasonalFundsSubTitle = [
    "Invest in New Fund\nOfferings",
    "₹100 per invite",
    "Save 3-4% more than\nbank account",
  ];

  @override
  void initState() {
    listTopHeldData.clear();

    BlocProvider.of<MPMFCollectionBloc>(context).add(GetMPMFCollectionResults(''));

    BlocProvider.of<mf.MFListByTypeBloc>(context).add(
        mf.GetMFListByTypeResults('', true, pageSize: 10, page: 1, strFilter: 'search_phrase=${widget.searchPhrase}'));

    BlocProvider.of<MFTopHeldBloc>(context).add(GetListTopHeldMutualFunds('top_held', topMFCounts));

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 24.0, right: 24, top: 16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Top held mutual funds on Multipie",
                            style: mpHeadLine5(
                              context: context,
                              textColor: Theme.of(context).primaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          //View All
                          GestureDetector(
                            onTap: () {
                              CleverTapPlugin.recordEvent('Top Mutual Funds See More Clicked', {
                                'source': 'Explore Text',
                              });
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TopHeldMutualFundsScreen(
                                    listData: listTopHeldData,
                                  ),
                                ),
                              );
                            },
                            child: Text(
                              'View All',
                              style: mpHeadLine6(
                                context: context,
                                textColor: context.appTheme.secondaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),

                      //Top Held Stocks List
                      InkWell(
                          onTap: () {
                            CleverTapPlugin.recordEvent('Top Mutual Funds See More Clicked', {
                              'source': 'Explore Card',
                            });
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TopHeldMutualFundsScreen(
                                  listData: listTopHeldData,
                                ),
                              ),
                            );
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                              vertical: 12,
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                color: context.appTheme.cardBackgroundColor,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: context.appTheme.borderColor,
                                  width: 0.5,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: TopHeldMutualFunds(
                                      listTopHeldData,
                                    ),
                                  ),
                                  Expanded(
                                    child: Image.asset(
                                      'assets/images/top_held_icon.png',
                                      fit: BoxFit.cover,
                                      //height: 105,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )),
                    ],
                  ),
                ),

                //Year Toggle
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Container(
                      width: 100,
                      child: FlatButton(
                        height: 25,
                        minWidth: 75,
                        onPressed: () {
                          setState(() {
                            tapIndex++;
                            tapIndex = tapIndex % 3;
                          });
                        },
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        color: context.appTheme.blueShadeColor.withOpacity(0.2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: <Widget>[
                            Text(
                              mfDuration[tapIndex].toString(),
                              style: mpHeadLine6(
                                context: context,
                                textColor: context.appTheme.blueShadeColor,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Image.asset(
                              'assets/images/exchange.png',
                              color: context.appTheme.blueShadeColor,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                //List of Mutual Fund
                BlocBuilder<mf.MFListByTypeBloc, mf.MFListByTypeState>(
                  builder: (context, state) {
                    if (state is mf.Loading) {
                      return Container(
                        height: 60,
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }
                    if (state is mf.Loaded) {
                      if (state.mfListByTypeList.length > 0) {
                        return ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: state.mfListByTypeList.length,
                          itemBuilder: (BuildContext context, index) {
                            return MFItem(
                              state.mfListByTypeList[index],
                              returnIndex: tapIndex,
                            );
                          },
                        );
                      }
                    }
                    return Container(
                      child: Center(
                        child: Text(
                          "Data is not available!",
                          style: mpHeadLine6(context: context),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        // All mutual funds Button
        Padding(
          padding: const EdgeInsets.all(15),
          child: GestureDetector(
            onTap: () {
              CleverTapPlugin.recordEvent('Explore All Mutual Funds', {});
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MFListScreen(
                    title: "All Mutual Funds",
                    searchText: widget.searchPhrase,
                  ),
                ),
              );
            },
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                color: context.appTheme.primaryColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  "All Mutual Funds",
                  style: TextStyle(
                    color: context.appTheme.cardBackgroundColor,
                    fontFamily: 'Roboto',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ),
        Visibility(
            visible: widget.searchPhrase.length == 0,
            child: SizedBox(height: 60 + MediaQuery.of(context).padding.bottom)),
      ],
    );
  }
}

class MutualFundsItem extends StatefulWidget {
  final MutualFund data;
  final bool isFromSearch;
  final String mfWatchlistId;
  final Function showSnackbar;

  MutualFundsItem(this.data, {this.isFromSearch = false, this.mfWatchlistId = "undefined", required this.showSnackbar});

  @override
  _MutualFundsItemState createState() => _MutualFundsItemState();
}

class _MutualFundsItemState extends State<MutualFundsItem> {
  late add_remove_watchlist.AddRemoveWatchlistBloc addRemoveWatchlistBloc;

  @override
  void initState() {
    addRemoveWatchlistBloc = BlocProvider.of<add_remove_watchlist.AddRemoveWatchlistBloc>(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.only(top: 8),
          child: InkWell(
            onTap: () async {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => MutualFundScreen(
                          mutualFundId: widget.data.id,
                          mutualFundName: widget.data.name,
                        )),
              );
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(),
                  child: widget.data.iconUrl.isEmpty
                      ? Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: context.appTheme.blueShadeColor.withOpacity(0.3),
                          ),
                          child: Center(
                            child: Text(
                              widget.data.name[0],
                              style: TextStyle(
                                  fontSize: 20, color: context.appTheme.primaryColor, fontWeight: FontWeight.w400),
                            ),
                          ),
                        )
                      : CachedNetworkImage(imageUrl: Constants.API_MF_IMAGE_URL + widget.data.iconUrl),
                ),
                SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: Text(
                    widget.data.name,
                    textAlign: TextAlign.start,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: mpHeadLine5(context: context),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                if (widget.isFromSearch)
                  InkWell(
                    onTap: () {
                      if (!widget.data.addedToWatchlist) {
                        addRemoveWatchlistBloc.add(add_remove_watchlist.AddWatchlistEvent(
                            widget.mfWatchlistId, widget.data.id, "mutual_fund"));
                        widget.showSnackbar("Added to watchlist");
                      } else {
                        addRemoveWatchlistBloc.add(add_remove_watchlist.RemoveWatchlistEvent(
                            widget.mfWatchlistId, widget.data.id, "mutual_fund"));
                        widget.showSnackbar("Removed from watchlist");
                      }

                      setState(() {
                        widget.data.addedToWatchlist = !widget.data.addedToWatchlist;
                      });
                      final eventData = {
                        'Type': 'Mutual Fund',
                        'Name': widget.data.name,
                        'Watch': widget.data.addedToWatchlist,
                      };
                      CleverTapPlugin.recordEvent('Watched Investments', eventData);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      margin: EdgeInsets.all(5),
                      child: Icon(
                        widget.data.addedToWatchlist ? Icons.bookmark : Icons.bookmark_border,
                        color: Theme.of(context).primaryColor,
                        size: 20,
                      ),
                    ),
                  )
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Divider(),
        )
      ],
    );
  }
}

class TopHeldMutualFundsItem extends StatefulWidget {
  final TopHeldMutualFund data;

  const TopHeldMutualFundsItem({required this.data, Key? key}) : super(key: key);

  @override
  _TopHeldMutualFundsItemState createState() => _TopHeldMutualFundsItemState();
}

class _TopHeldMutualFundsItemState extends State<TopHeldMutualFundsItem> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: 8,
        horizontal: 0,
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 25,
                  height: 25,
                  decoration: BoxDecoration(),
                  child: widget.data.iconUrl.isEmpty
                      ? Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: context.appTheme.blueShadeColor.withOpacity(0.3),
                          ),
                          child: Center(
                            child: Text(
                              widget.data.name.isNotEmpty ? widget.data.name[0] : widget.data.name[0],
                              style: TextStyle(
                                fontSize: 12,
                                color: context.appTheme.primaryColor,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        )
                      : CachedNetworkImage(imageUrl: Constants.API_MF_IMAGE_URL + widget.data.iconUrl),
                ),
                SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: Text(
                    widget.data.name,
                    textAlign: TextAlign.start,
                    overflow: TextOverflow.ellipsis,
                    style: mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.primaryTextColor,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class TopHeldMutualFunds extends StatelessWidget {
  List<TopHeldMutualFund> listTopHeldData;

  TopHeldMutualFunds([
    this.listTopHeldData = const [],
  ]);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<MFTopHeldBloc, MFTopHeldState>(
      listener: (context, state) {
        if (state is LoadedTopHeldMutualFunds) listTopHeldData.addAll(state.topHeldMutualFunds);
      },
      builder: (context, state) {
        if (state is LoadingTopHeld) {
          return Container(
            height: 60,
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (state is LoadedTopHeldMutualFunds) {
          if (state.topHeldMutualFunds.length > 0) {
            return ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: 3,
              itemBuilder: (context, index) {
                return TopHeldMutualFundsItem(data: listTopHeldData[index]);
              },
            );
          }
        }
        return Container(
          child: Center(
            child: Text(
              "Data is not available!",
              style: mpHeadLine6(context: context),
            ),
          ),
        );
      },
    );
  }
}

/// Don't delete the codes below
/// Handpicked by Multipie Header
// Text(
//   'Handpicked by Multipie',
//   style: TextStyle(
//     color: context.appTheme.primaryColor,
//     fontFamily: 'Roboto',
//     fontSize: 16,
//     fontWeight: FontWeight.w500,
//   ),
// ),
//
// // Equity, Debt, Gold, International Funds, Dynamic Asset Allocation, Others Button
// BlocBuilder<MPMFCollectionBloc, MPMFCollectionState>(
//   builder: (context, state) {
//     if (state is Loading) {
//       return Center(child: CircularProgressIndicator());
//     } else if (state is Loaded) {
//       print('loaded');
//       return state.mpMFCollectionList.length > 0
//           ? Padding(
//         padding: const EdgeInsets.only(top: 15),
//         child: Container(
//           height: 200,
//           child: GridView.builder(
//             physics: NeverScrollableScrollPhysics(),
//             gridDelegate:
//             SliverGridDelegateWithMaxCrossAxisExtent(
//               maxCrossAxisExtent: 150,
//               childAspectRatio: 1.3,
//               crossAxisSpacing: 10,
//               mainAxisSpacing: 20,
//             ),
//             itemCount: state.mpMFCollectionList.length,
//             itemBuilder: (BuildContext context, index) {
//               return GestureDetector(
//                 onTap: () {
//                   Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                           builder: (_) => MFListByTypeScreen(
//                             id: state
//                                 .mpMFCollectionList[index]
//                                 .id,
//                             title: state
//                                 .mpMFCollectionList[index]
//                                 .title,
//                           )));
//                 },
//                 child: Container(
//                   alignment: Alignment.center,
//                   child: Column(
//                     mainAxisAlignment:
//                     MainAxisAlignment.center,
//                     children: [
//                       CachedNetworkImage(
//                         height: 50,
//                         width: 50,
//                         imageUrl: NetworkService.baseHost +
//                             state.mpMFCollectionList[index]
//                                 .iconUrl,
//                       ),
//                       Expanded(child: Text(
//                         state.mpMFCollectionList[index].title,
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                           color:
//                           context.appTheme.primaryTextColor,
//                           fontFamily: 'Roboto',
//                           fontSize: 14,
//                           fontWeight: FontWeight.w400,
//                         ),
//                       ),)
//                     ],
//                   ),
//                   padding: EdgeInsets.only(bottom: 5),
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(12),
//                     border: Border.all(
//                       color: context.appTheme.borderColor,
//                       width: 0.4,
//                     ),
//                   ),
//                 ),
//               );
//             },
//           ),
//         ),
//       )
//           : Center(
//         child: Text(
//           'No Results Found.',
//           style: mpHeadLine5(),
//         ),
//       );
//     } else if (state is Error) {
//       return Container();
//     } else {
//       return Container();
//     }
//   },
// ),

//List of Mutual Fund

/// Seasonal Funds Header
// Padding(
//   padding: const EdgeInsets.symmetric(vertical: 10),
//   child: Text(
//     'Seasonal Funds',
//     style: TextStyle(
//       color: context.appTheme.primaryColor,
//       fontFamily: 'Roboto',
//       fontSize: 16,
//       fontWeight: FontWeight.w500,
//     ),
//   ),
// ),

// NFO Live, Invite & Earn, Smart Save Button
// Padding(
//   padding: const EdgeInsets.only(bottom: 15),
//   child: Container(
//     height: 90,
//     child: GridView.builder(
//         physics: NeverScrollableScrollPhysics(),
//         gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
//           maxCrossAxisExtent: 150,
//           childAspectRatio: 1.5,
//           crossAxisSpacing: 10,
//           mainAxisSpacing: 20,
//         ),
//         itemCount: seasonalFundsTitle.length,
//         itemBuilder: (BuildContext context, index) {
//           return GestureDetector(
//             onTap: () {
//               // Navigator.push(
//               //   context,
//               //   PageRouteBuilder(
//               //     opaque: false,
//               //     pageBuilder:
//               //         (context, animation, secondaryAnimation) =>
//               //             NewRedirectedPage(
//               //       title: seasonalFundsTitle[index],
//               //     ),
//               //     transitionsBuilder: (
//               //       context,
//               //       animation,
//               //       secondaryAnimation,
//               //       child,
//               //     ) {
//               //       return SlideTransition(
//               //         position: animation.drive(
//               //           Tween(
//               //                   begin: Offset(1.0, 0.0),
//               //                   end: Offset.zero)
//               //               .chain(
//               //             CurveTween(curve: Curves.ease),
//               //           ),
//               //         ),
//               //         child: child,
//               //       );
//               //     },
//               //   ),
//               // );
//             },
//             child: Container(
//               padding: EdgeInsets.only(top: 8, left: 6),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     seasonalFundsTitle[index],
//                     textAlign: TextAlign.left,
//                     style: TextStyle(
//                       color: context.appTheme.primaryColor,
//                       fontFamily: 'Roboto',
//                       fontSize: 15,
//                       fontWeight: FontWeight.w500,
//                     ),
//                   ),
//                   SizedBox(height: 5),
//                   Text(
//                     seasonalFundsSubTitle[index],
//                     textAlign: TextAlign.left,
//                     style: TextStyle(
//                       color: context.appTheme.secondaryTextColor,
//                       fontFamily: 'Roboto',
//                       fontSize: 12,
//                       fontWeight: FontWeight.w400,
//                     ),
//                   ),
//                 ],
//               ),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(10),
//                 border: Border.all(
//                   color: context.appTheme.borderColor,
//                   width: 0.4,
//                 ),
//               ),
//             ),
//           );
//         }),
//   ),
// ),

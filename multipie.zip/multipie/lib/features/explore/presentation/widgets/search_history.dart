import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_mutual_fund_to_explore.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_people_explore.dart';
import 'package:multipie/features/explore/presentation/widgets/sw_stocks_to_explore.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/features/watchlist/presentation/blocs/get_watchlist/bloc.dart' as watchlist_bloc;

class SearchHistory extends StatelessWidget {
  final SearchResult searchResult;
  final Function showSnackBar;

  SearchHistory(this.searchResult, {required this.showSnackBar});

  @override
  Widget build(BuildContext context) {
    return SearchResultData(searchResult, showSnackBar: showSnackBar);
  }
}

class SearchResultData extends StatefulWidget {
  final SearchResult searchResult;
  final Function showSnackBar;

  SearchResultData(this.searchResult, {required this.showSnackBar});

  @override
  _SearchResultDataState createState() => _SearchResultDataState();
}

class _SearchResultDataState extends State<SearchResultData> with SingleTickerProviderStateMixin {
  String watchlistIdStocks = "undefined";
  String watchlistIdMF = "undefined";

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = new TabController(vsync: this, length: 3);
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<watchlist_bloc.GetWatchlistBloc, watchlist_bloc.GetWatchlistState>(builder: (context, state) {
      if (state is watchlist_bloc.Loading)
        return Center(child: CircularProgressIndicator());
      else if (state is watchlist_bloc.Loaded) {
        return Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 40,
              child: TabBar(
                controller: _tabController,
                indicator: UnderlineTabIndicator(
                  borderSide: BorderSide(
                    width: 3.5,
                    color: context.appTheme.activeIndicationColor,
                  ),
                  insets: EdgeInsets.symmetric(horizontal: 16.0),
                ),
                labelColor: context.appTheme.primaryColor,
                unselectedLabelColor: context.appTheme.secondaryTextColor,
                labelStyle: mpHeadLine6(context: context),
                tabs: [
                  Tab(text: 'Stocks'),
                  Tab(text: 'Mutual Funds'),
                  Tab(text: 'People'),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(controller: _tabController, children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
                  child: SingleChildScrollView(child: loadStocksData(widget.searchResult.companies)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
                  child: SingleChildScrollView(child: loadMFData(widget.searchResult.mutualFunds)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
                  child: SingleChildScrollView(child: loadUserData(widget.searchResult.people)),
                ),
              ]),
            )
          ],
        );
      } else
        return Container();
    }, listener: (context, state) {
      if (state is watchlist_bloc.Loaded) {
        for (int i = 0; i < state.list.length; i++) {
          if (state.list[i].instrument_type == "stock") {
            watchlistIdStocks = state.list[i].id.toString();
            widget.searchResult.companies.forEach((element) {
              if (element != null)
                element.addedToWatchlist = state.list[i].instrument_ids.contains(int.parse(element.id));
            });
          }
          if (state.list[i].instrument_type == "mutual_fund") {
            watchlistIdMF = state.list[i].id.toString();
            widget.searchResult.mutualFunds.forEach((element) {
              if (element != null)
                element.addedToWatchlist = state.list[i].instrument_ids.contains(int.parse(element.id));
            });
          }
        }
      }
    });
  }

  Column loadUserData(List<User> people) {
    List<Widget> widgetData = [];
    people.forEach((element) {
      widgetData.add(PeopleDataItem(data: element));
    });
    return Column(
      children: [
        if (people.length == 0) _noDataFoundView(),
        ...widgetData,
      ],
    );
  }

  Column loadMFData(List<MutualFund> data) {
    List<Widget> widgetData = [];
    data.forEach((element) {
      widgetData.add(
        MutualFundsItem(
          element,
          isFromSearch: true,
          mfWatchlistId: watchlistIdMF,
          showSnackbar: widget.showSnackBar,
        ),
      );
    });
    return Column(
      children: [
        if (data.length == 0) _noDataFoundView(),
        ...widgetData,
      ],
    );
  }

  Column loadStocksData(List<Company> companies) {
    List<Widget> widgetData = [];
    companies.forEach((element) {
      widgetData.add(
        StockItem(
          data: element,
          isFromSearch: true,
          stockWatchlistId: watchlistIdStocks,
          showSnackBar: widget.showSnackBar,
        ),
      );
    });
    return Column(
      children: [
        if (companies.length == 0) _noDataFoundView(),
        ...widgetData,
      ],
    );
  }

  _noDataFoundView() {
    return SizedBox(
      height: 200,
      child: Center(
        child: Text(
          'No results found',
          style: mpHeadLine5(
            context: context,
            textColor: context.appTheme.secondaryTextColor,
          ),
        ),
      ),
    );
  }
}

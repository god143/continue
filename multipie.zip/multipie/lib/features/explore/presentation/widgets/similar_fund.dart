import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper.dart';
import 'package:multipie/core/utils/extensions.dart';

class SimilarFundSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    List<String> companyName = [
      'ICICI Prudential Technology Direct Plan Growth',
      'Axis Bluechip Fund Direct Plan Growth',
      'Tata Motors',
      'HDFC Bank',
    ];

    List<String> equityName = [
      'Equity',
      'Large Cap',
      'Mid Cap',
      'Small Cap',
    ];
    List<String> percentage = [
      '12.36%',
      '21.00%',
      '54%',
      '0.00%',
    ];
    List<String> companyLogo = [
      'assets/logos/Tata Motors.png',
      'assets/logos/HDFC Top 100.png',
      'assets/logos/Tata Motors.png',
      'assets/logos/HDFC Top 100.png',
    ];

    return Container(
      height: 125,
      padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: ListView.separated(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: 4,
              separatorBuilder: (BuildContext context, int index) {
                return SizedBox(width: 15);
              },
              itemBuilder: (context, index) => Container(
                padding: EdgeInsets.all(10),
                width: 300,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: context.appTheme.kSecondaryBackGroundColor),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Image.asset(companyLogo[index]),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                companyName[index],
                                style: TextStyle(
                                  color: context.appTheme.primaryTextColor,
                                  fontFamily: 'Roboto',
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 5.0),
                                child: Text(
                                  equityName[index],
                                  style: TextStyle(
                                    color: context.appTheme.scorpionGray,
                                    fontFamily: 'Roboto',
                                    fontSize: 10,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.person_rounded,
                                    size: 12,
                                    color: context.appTheme.scorpionGray,
                                  ),
                                  SizedBox(width: 1),
                                  Text(
                                    '529 people are talking about this',
                                    style: TextStyle(
                                      color: context.appTheme.scorpionGray,
                                      fontFamily: 'Roboto',
                                      fontSize: 10,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        //Graph
                        // Expanded(child: Center(child: SmallLineChart())),
                        //Price and % growth section
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              percentage[index],
                              style: TextStyle(
                                color: context.appTheme.primaryColor,
                                fontFamily: 'Roboto',
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4.0),
                              child: Text(
                                '3Y',
                                style: TextStyle(
                                  color: context.appTheme.scorpionGray,
                                  fontFamily: 'Roboto',
                                  fontSize: 10,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                            Text(
                              'Annualized',
                              style: TextStyle(
                                color: context.appTheme.scorpionGray,
                                fontFamily: 'Roboto',
                                fontSize: 10,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

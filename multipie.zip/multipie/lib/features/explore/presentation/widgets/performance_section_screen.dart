import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';

class MFPerformanceItem extends StatelessWidget {
  final bool wantToCentralAlig;
  final String annualizedReturns;
  final String oneYear;

  final String threeY;

  final String fiveY;
  final String allY;

  const MFPerformanceItem({
    required this.wantToCentralAlig,
    required this.annualizedReturns,
    required this.oneYear,
    required this.threeY,
    required this.fiveY,
    required this.allY,
  }) : super();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Expanded(
          flex: 5,
          child: Text(
            "$annualizedReturns",
            textAlign: wantToCentralAlig ? TextAlign.center : TextAlign.start,
            style: mpHeadLine6(
              context: context,
              textColor: context.appTheme.secondaryTextColor,
            ),
          ),
        ),
        Expanded(
            flex: 2,
            child: Text(
              '$oneYear',
              textAlign: TextAlign.center,
              style: wantToCentralAlig
                  ? mpHeadLine6(
                      context: context,
                      textColor: context.appTheme.secondaryTextColor,
                    )
                  : mpHeadLine6(context: context),
            )),
        Expanded(
          flex: 2,
          child: Text(
            '$threeY',
            textAlign: TextAlign.center,
            style: wantToCentralAlig
                ? mpHeadLine6(
                    context: context,
                    textColor: context.appTheme.secondaryTextColor,
                  )
                : mpHeadLine6(context: context),
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            '$fiveY',
            textAlign: TextAlign.center,
            style: wantToCentralAlig
                ? mpHeadLine6(
                    context: context,
                    textColor: context.appTheme.secondaryTextColor,
                  )
                : mpHeadLine6(context: context),
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            '$allY',
            textAlign: TextAlign.center,
            style: wantToCentralAlig
                ? mpHeadLine6(
                    context: context,
                    textColor: context.appTheme.secondaryTextColor,
                  )
                : mpHeadLine6(context: context),
          ),
        ),
      ],
    );
  }
}

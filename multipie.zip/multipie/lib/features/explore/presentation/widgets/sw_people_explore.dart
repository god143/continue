import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/explore/presentation/bloc/people_search/bloc.dart';
import 'package:multipie/features/post/presentation/screens/create_post_screen/widgets/custom_bottom_sheet.dart';
import 'package:multipie/features/profile/presentation/bloc/follow_unfollow/bloc.dart' as followBloc;
import 'package:multipie/features/profile/presentation/bloc/profile_screen/bloc.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/new_profile_screen.dart';
import 'package:multipie/features/profile/presentation/widgets/follow_unfollow_widget.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/locator.dart';

String clickedId = "";

class PeopleExplore extends StatelessWidget {
  final List<User>? people;
  final String searchPhrase;

  PeopleExplore({this.people, this.searchPhrase = ''});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) => PeopleSearchBloc(getPeopleSearchResult: locator()),
        child: _PeopleExplore(people: people, searchPhrase: searchPhrase));
  }
}

class _PeopleExplore extends StatefulWidget {
  final List<User>? people;
  final String searchPhrase;

  _PeopleExplore({this.people, this.searchPhrase = ''});

  @override
  _PeopleExploreState createState() => _PeopleExploreState();
}

class _PeopleExploreState extends State<_PeopleExplore> {
  String prevText = '';
  bool inProgress = false;

  ScrollController _scrollController = ScrollController();
  int pageSize = 20;
  int page = 1;
  var hasMoreData = true;
  List peopleListData = [];

  @override
  void initState() {
    super.initState();

    //empty list
    peopleListData.clear();

    BlocProvider.of<PeopleSearchBloc>(context)
        .add(GetPeopleSearchResults(widget.searchPhrase, pageSize: pageSize, page: page));

    _scrollController.addListener(() {
      if (_scrollController.position.maxScrollExtent == _scrollController.position.pixels && hasMoreData) {
        if (peopleListData.length >= pageSize) {
          page = ((peopleListData.length / pageSize) + 1).toInt();
          BlocProvider.of<PeopleSearchBloc>(context)
              .add(GetPeopleSearchResults(widget.searchPhrase, pageSize: pageSize, page: page));
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              left: 16.0,
              right: 16,
              top: 8,
              bottom: 16,
            ),
            child: Text(
              widget.searchPhrase.length > 0 ? "Search Results" : "Trending people on Multipie",
              style: mpHeadLine5(
                context: context,
                textColor: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          BlocConsumer<PeopleSearchBloc, PeopleSearchState>(builder: (context, state) {
            if (state is LoadingPeople) {
              return Center(child: CircularProgressIndicator());
            }

            if (state is LoadedPeople) {
              if (state.searchUserResultList.length < pageSize) {
                hasMoreData = false;
              } else {
                hasMoreData = true;
              }
            }

            if (peopleListData.length > 0) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: peopleListData.length + 1,
                  itemBuilder: (context, index) {
                    if (index == peopleListData.length) {
                      if (hasMoreData == false) return Container();

                      return Container(
                        height: 60,
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    return PeopleDataItem(data: peopleListData[index]);
                  },
                ),
              );
            } else {
              return Center(
                child: Text(
                  'No Results Found.',
                  style: mpHeadLine5(context: context),
                ),
              );
            }
          }, listener: (context, state) {
            if (state is LoadedPeople) {
              peopleListData.addAll(state.searchUserResultList);
            }
          }),
          // BlocBuilder<PeopleSearchBloc, PeopleSearchState>(
          //   builder: (context, state) {
          //
          //   },
          // ),
          SizedBox(height: 70)
        ],
      ),
    );
  }
}

class PeopleDataItem extends StatefulWidget {
  final User data;
  final bool doNotShowFollow;
  bool showRemove;

  PeopleDataItem({required this.data, this.doNotShowFollow = false, this.showRemove = false});

  @override
  _PeopleDataItemState createState() => _PeopleDataItemState();
}

class _PeopleDataItemState extends State<PeopleDataItem> {
  late FollowEvent followEvent;

  @override
  void initState() {
    super.initState();

    followEvent = widget.data.isFollowed
        ? FollowEvent.followed
        : widget.data.isRequested
            ? FollowEvent.pending
            : FollowEvent.none;
  }

  @override
  Widget build(BuildContext context) {
    User? currentUser = BlocProvider.of<UserProfileBloc>(context).currentUser;
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NewProfileScreen(
              userId: widget.data.id,
            ),
          ),
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 0, right: 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 55,
                  height: 55,
                  child: ProfilePictureHolder(
                    profileMode: widget.data.profile?.marketView ?? '',
                    imageUrl: widget.data.dpThumbnail,
                    holderLetter: widget.data.displayname.isEmpty ? '' : widget.data.displayname[0],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Padding(
                              padding: EdgeInsets.only(left: 16.0, right: 16, top: 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          widget.data.displayname,
                                          textAlign: TextAlign.start,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 2,
                                          style: mpHeadLine5(
                                            context: context,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 8,
                                      ),
                                      //todo :: need bit for verified account
                                      /*    if (data.profile.isPrivate)
                                              CustomIcon(
                                                CustomIcons.ic_verified,
                                                height: 24,
                                                width: 24,
                                              )*/
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        child: Text(
                                          "${widget.data.username}",
                                          textAlign: TextAlign.start,
                                          overflow: TextOverflow.ellipsis,
                                          style: mpHeadLine5(
                                            context: context,
                                            textColor: context.appTheme.secondaryTextColor,
                                          ),
                                        ),
                                      ),
                                      if (widget.showRemove) ...[
                                        SizedBox(width: 5),
                                        Text(
                                          '•',
                                          style: mpHeadLine6(context: context),
                                        ),
                                        SizedBox(width: 5),
                                        GestureDetector(
                                          onTap: () {
                                            showCustomBottomSheet(child: removeFollowerPopupWidget(), context: context);
                                          },
                                          child: Text(
                                            "Remove",
                                            style: mpHeadLine6(
                                              context: context,
                                              textColor: context.appTheme.negativeGainColor,
                                            ),
                                          ),
                                        )
                                      ]
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Visibility(
                            visible: !widget.doNotShowFollow ||
                                (widget.doNotShowFollow && widget.data.id != currentUser!.id),
                            child: FollowUnFollowButton(
                              data: widget.data,
                              width: 95,
                              fontSize: 'mp5',
                              radius: 10,
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 16.0, top: 5),
                        child: Text(
                          (widget.data.profile?.bio ?? '').isEmpty ? ' - ' : widget.data.profile!.bio,
                          textAlign: TextAlign.start,
                          style: mpHeadLine6(context: context),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider()
        ],
      ),
    );
  }

  removeFollowerPopupWidget() {
    return Column(children: [
      Text(
        'Remove Follower?',
        style: mpHeadLine6(
          context: context,
          fontWeight: FontWeight.w500,
        ),
      ),
      SizedBox(height: 10),
      Text(
        'Multipie won\'t tell ${widget.data.username} they were removed from your follower',
        style: mpHeadLine6(
          context: context,
          textColor: context.appTheme.secondaryTextColor,
        ),
        textAlign: TextAlign.center,
      ),
      SizedBox(height: 5),
      Divider(thickness: 1),
      SizedBox(height: 5),
      GestureDetector(
        onTap: () {
          setState(() {
            widget.showRemove = false;
          });
          BlocProvider.of<followBloc.FollowUnFollowBloc>(context).add(followBloc.RemoveFollower(widget.data.id));

          //to update follower counter
          BlocProvider.of<UserProfileBloc>(context).currentUser?.profile?.followersCount =
              (BlocProvider.of<UserProfileBloc>(context).currentUser?.profile?.followersCount ?? 0) - 1;
          Navigator.pop(context);
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Text(
            'Remove',
            style: mpHeadLine5(
              context: context,
              textColor: context.appTheme.negativeGainColor,
            ),
          ),
        ),
      )
    ]);
  }
}

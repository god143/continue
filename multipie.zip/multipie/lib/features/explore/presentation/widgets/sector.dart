import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

class Sector extends StatelessWidget {
  final String sectorName;
  final String percentage;

  const Sector({
    required this.sectorName,
    required this.percentage,
  }) : super();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '$sectorName',
            textAlign: TextAlign.start,
            style: TextStyle(color: context.appTheme.primaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
          ),
          Text(
            '$percentage',
            textAlign: TextAlign.end,
            style: TextStyle(color: context.appTheme.secondaryTextColor, fontWeight: FontWeight.w400, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';

class ShowingBorderWidget extends StatelessWidget {
  final String text;
  const ShowingBorderWidget({
    Key? key,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: context.appTheme.borderColor, width: 0.5),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 8.0),
          child: Text(
            "$text",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: context.appTheme.borderColor,
              fontFamily: 'Roboto',
              fontSize: 14,
              letterSpacing: -0.33,
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/explore/data/models/hash_tag_model.dart';
import 'package:multipie/features/explore/data/models/search_result_model.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/services/network_service.dart';

abstract class ExploreSearchRemoteDataSource {
  Future<SearchResult> getSearchResults(String searchPhrase);

  Future<List<HashTag>> getHashTags(String searchPhrase);
}

class ExploreRemoteDataSourceImpl implements ExploreSearchRemoteDataSource {
  final NetworkService networkService;

  ExploreRemoteDataSourceImpl({required this.networkService});

  @override
  Future<SearchResultModel> getSearchResults(String searchPhrase) =>
      getSearchListFromService('/search', searchPhrase);

  Future<SearchResultModel> getSearchListFromService(
      String url, String searchPhrase) async {
    String urlToSubmit = '';
    // Added recent path for for empty search phrase for recent search
    if (searchPhrase.isEmpty) {
      urlToSubmit = url + "/recent";
    } else {
      urlToSubmit = url + "?search_phrase=$searchPhrase";
    }

    final jsonApi = await networkService.getRequest(urlToSubmit);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      // Iterable data = json['data']['mutual_funds'];
      return SearchResultModel.fromJson(json['data']);
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }

  @override
  Future<List<HashTagModel>> getHashTags(String searchPhrase) =>
      getHashTagListFromService('/tags', searchPhrase);

  Future<List<HashTagModel>> getHashTagListFromService(
      String url, String searchPhrase) async {
    String urlToSubmit = url + "?search_phrase=$searchPhrase";
    final jsonApi = await networkService.getRequest(urlToSubmit);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      return json['people']
          .map<HashTagModel>((post) => HashTagModel.fromJson(post))
          .toList();
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }
}

import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/explore/data/models/hash_tag_model.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/services/network_service.dart';

abstract class HashTagRemoteDataSource {
  Future<List<HashTag>> getHashTags(String searchPhrase);
}

class HashTagRemoteDataSourceImpl implements HashTagRemoteDataSource {
  final NetworkService networkService;

  HashTagRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<HashTagModel>> getHashTags(String searchPhrase) =>
      getHashTagSearchResults(searchPhrase);

  Future<List<HashTagModel>> getHashTagSearchResults(
      String searchPhrase) async {
    String urlToSubmit = "/hashtags?search_phrase=$searchPhrase";
    final jsonApi = await networkService.getRequest(urlToSubmit);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((hashTag) => HashTagModel.fromJson(hashTag)).toList();
    } catch (e) {
      throw ServerException('Failed to get hash tags for serach query');
    }
  }
}

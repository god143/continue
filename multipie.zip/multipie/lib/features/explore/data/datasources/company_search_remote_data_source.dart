import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/explore/data/models/comany_search_result_model.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/services/network_service.dart';

abstract class CompanySearchRemoteDataSource {
  Future<List<Company>> getCompanySearchResults(String searchPhrase);
}

class CompanySearchRemoteDataSourceImpl
    implements CompanySearchRemoteDataSource {
  final NetworkService networkService;

  CompanySearchRemoteDataSourceImpl({required this.networkService});
  @override
  Future<List<Company>> getCompanySearchResults(String searchPhrase) async =>
      getSearchListFromService('/companies', searchPhrase);

  Future<List<CompanySearchResultModel>> getSearchListFromService(
      String url, String searchPhrase) async {
    String urlToSubmit = url + "?search_phrase=$searchPhrase";
    final jsonApi = await networkService.getRequest(urlToSubmit);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data
          .map((post) => CompanySearchResultModel.fromJson(post))
          .toList();
      // return CompanySearchResultModel.fromJson(json['data']);
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }
}

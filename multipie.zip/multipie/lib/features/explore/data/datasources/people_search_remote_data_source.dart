import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/services/network_service.dart';

abstract class PeopleSearchRemoteDataSource {
  Future<List<User>> getPeopleSearchResults(
      String searchPhrase, int pageSize, int page);
}

class PeopleSearchRemoteDataSourceImpl implements PeopleSearchRemoteDataSource {
  final NetworkService networkService;

  PeopleSearchRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<User>> getPeopleSearchResults(
      String searchPhrase, int pageSize, int page) async {
    String path = searchPhrase.length > 0
        ? "/people?search_phrase=$searchPhrase"
        : "/multicelebs?page_size=$pageSize&page=$page";
    return getPeopleSearchListFromService(path, searchPhrase);
  }

  Future<List<UserModel>> getPeopleSearchListFromService(
      String url, String searchPhrase) async {
    final jsonApi = await networkService.getRequest(url);
    try {
      // Map<String, dynamic> json = Japx.decode(jsonApi);
      Map<String, dynamic> json =
          Japx.decode(jsonApi, includeList: "user_profile.user");
      Iterable data = json['data'];
      return data.map((post) => UserModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }
}

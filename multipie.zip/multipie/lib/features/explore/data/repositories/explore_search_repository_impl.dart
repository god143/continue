import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/explore/data/datasources/explore_result_remote_datasource.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/features/explore/domain/repositories/explore_result_repository.dart';

class ExploreSearchRepositoryImpl implements ExploreResultRepository {
  final NetworkInfo networkInfo;
  final ExploreSearchRemoteDataSource remoteDataSource;

  ExploreSearchRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, SearchResult>> getSearchResultList(String searchPhrase) async {
    return await _getSearchListFromServer(searchPhrase);
  }

  Future<Either<Failure, SearchResult>> _getSearchListFromServer(String searchPhrase) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getSearchResults(searchPhrase);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<HashTag>>> getHashTagList(String searchPhrase) async {
    // TODO: implement getHashTagList
    return await _getHashTagListFromServer(searchPhrase);
  }

  Future<Either<Failure, List<HashTag>>> _getHashTagListFromServer(String searchPhrase) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getHashTags(searchPhrase);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

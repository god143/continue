import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/explore/data/datasources/company_search_remote_data_source.dart';
import 'package:multipie/features/explore/domain/repositories/company_name_repository.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

class CompanySearchRepositoryImpl implements CompanySearchRepository {
  final NetworkInfo networkInfo;
  final CompanySearchRemoteDataSource companySearchRemoteDataSource;

  CompanySearchRepositoryImpl({required this.networkInfo, required this.companySearchRemoteDataSource});

  @override
  Future<Either<Failure, List<Company>>> getCompanySearchtList(String searchPhrase) async {
    return await _getCompanySearchListFromServer(searchPhrase);
  }

  Future<Either<Failure, List<Company>>> _getCompanySearchListFromServer(String searchPhrase) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await companySearchRemoteDataSource.getCompanySearchResults(searchPhrase);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

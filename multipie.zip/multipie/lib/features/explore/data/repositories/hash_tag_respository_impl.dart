import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/explore/data/datasources/hash_tag_remote_datasource.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/features/explore/domain/repositories/hash_tag_repository.dart';

class HashTagRepositoryImpl implements HashTagRespository {
  final NetworkInfo networkInfo;
  final HashTagRemoteDataSource hashTagRemoteDataSource;

  HashTagRepositoryImpl({required this.networkInfo, required this.hashTagRemoteDataSource});

  @override
  Future<Either<Failure, List<HashTag>>> getHashTagList(String searchPhrase) async {
    return await _getSearchListFromServer(searchPhrase);
  }

  Future<Either<Failure, List<HashTag>>> _getSearchListFromServer(String searchPhrase) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await hashTagRemoteDataSource.getHashTags(searchPhrase);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

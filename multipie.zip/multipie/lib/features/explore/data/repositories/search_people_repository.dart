import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/explore/data/datasources/people_search_remote_data_source.dart';
import 'package:multipie/features/explore/domain/repositories/pepple_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class PeopleSearchRepositoryImpl implements PeopleSearchRepository {
  final NetworkInfo networkInfo;
  final PeopleSearchRemoteDataSource peopleSearchRemoteDataSource;

  PeopleSearchRepositoryImpl({required this.networkInfo, required this.peopleSearchRemoteDataSource});

  @override
  Future<Either<Failure, List<User>>> getPeopleSearchtList(String searchPhrase, int pageSize, int page) async {
    return await _getPeopleSearchListFromServer(searchPhrase, pageSize, page);
  }

  Future<Either<Failure, List<User>>> _getPeopleSearchListFromServer(
      String searchPhrase, int pageSize, int page) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await peopleSearchRemoteDataSource.getPeopleSearchResults(searchPhrase, pageSize, page);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

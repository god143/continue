import 'package:multipie/features/market/domain/entities/company/company.dart';

class CompanySearchResultModel extends Company {
  CompanySearchResultModel({
    required name,
    required id,
    required displayName,
    required iconUrl,
  }) : super(name: name, id: id, displayName: displayName, iconUrl: iconUrl);

  factory CompanySearchResultModel.fromJson(Map<String, dynamic> json) {
    return CompanySearchResultModel(
      name: nullReview(json['name']),
      displayName: nullReview(json['display_name']),
      iconUrl: nullReview(json['icon_url']),
      id: nullReview(json['id']),
    );
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

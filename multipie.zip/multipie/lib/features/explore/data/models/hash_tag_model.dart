import 'package:multipie/features/explore/domain/entities/hash_tag.dart';

class HashTagModel extends HashTag {
  HashTagModel({
    required title,
    required id,
    required postCount,
  }) : super(title: title, id: id, postCount: postCount);

  factory HashTagModel.fromJson(Map<String, dynamic> json) {
    return HashTagModel(
      id: nullReview(json['id']),
      title: nullReview(json['title']),
      postCount: nullReview(json['count_in_post']),
    );
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'count_in_post': postCount,
    };
  }
}

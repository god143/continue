import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class PeopleSearchResultModel extends User {
  PeopleSearchResultModel({
    required id,
    required type,
    required email,
    required mobile,
    required displayname,
    required username,
    required dpUrl,
    coverUrl,
    isFollowed,
    marketView,
    canAccept,
    isRequested,
    knownFollowers,
    profile,
    chosenUsername,
    remainingInvites,
    followsYou,
  }) : super(
          id: id,
          type: type,
          email: '',
          mobile: '',
          displayname: displayname,
          username: username,
          dpUrl: dpUrl,
          coverUrl: nullReview(coverUrl),
          isFollowed: isFollowed,
          marketView: marketView,
          canAccept: canAccept,
          isRequested: isRequested,
          knownFollowers: knownFollowers,
          profile: profile,
          chosenUsername: chosenUsername,
          remainingInvites: remainingInvites,
          followsYou: followsYou,
        );

  factory PeopleSearchResultModel.fromJson(Map<String, dynamic> json) {
    return PeopleSearchResultModel(
      id: nullReview(json['id']),
      displayname: nullReview(json['display_name']),
      email: nullReview(json['email']),
      type: nullReview(json['type']),
      mobile: nullReview(json['mobile']),
      username: nullReview(json['username']),
      dpUrl: nullReview(json['dp_url']),
    );
  }
}

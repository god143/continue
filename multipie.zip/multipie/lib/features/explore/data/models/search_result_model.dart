import 'package:multipie/core/utils/number_formatter.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/market/data/models/company/company_model.dart';
import 'package:multipie/features/market/data/models/mutual_fund/mutual_fund_model.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

class SearchResultModel extends SearchResult {
  SearchResultModel({
    required companiesCount,
    required peopleCount,
    required mutualFundsCount,
    required mutualFunds,
    required people,
    required companies,
  }) : super(
          companiesCount: companiesCount,
          peopleCount: peopleCount,
          mutualFundsCount: mutualFundsCount,
          mutualFunds: mutualFunds,
          people: people,
          companies: companies,
        );

  factory SearchResultModel.fromJson(Map<String, dynamic> json) {
    return SearchResultModel(
      companiesCount: nullReview(json['companies_count']),
      peopleCount: nullReview(json['people_count']),
      mutualFundsCount: nullReview(json['mutual_funds_count']),
      mutualFunds: json['mutual_funds'].map<MutualFundModel>((post) => MutualFundModel.fromJson(post)).toList(),
      people: json['people'].where((e) => e != null).map<UserModel>((post) => UserModel.fromJson(post)).toList(),
      companies: json['companies'].map<CompanyModel>((post) => CompanyModel.fromJson(post)).toList(),
    );
  }
}

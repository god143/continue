import 'package:equatable/equatable.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';
import 'package:multipie/features/market/domain/entities/mutual_fund/mutual_fund.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class SearchResult extends Equatable {
  final String companiesCount;
  final String peopleCount;
  final String mutualFundsCount;
  final List<MutualFund> mutualFunds;
  final List<User> people;
  final List<Company> companies;

  SearchResult({
    required this.companiesCount,
    required this.peopleCount,
    required this.mutualFundsCount,
    required this.mutualFunds,
    required this.people,
    required this.companies,
  });

  @override
  List<Object> get props => [
        companiesCount,
        peopleCount,
        mutualFundsCount,
        mutualFunds,
        people,
        companies
      ];
}

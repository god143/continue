import 'package:equatable/equatable.dart';

class CommonSearch extends Equatable {
  final String name;
  final String id;
  final String type;
  final bool isTitle;

  CommonSearch({
    required this.id,
    required this.name,
    required this.type,
    this.isTitle = false,
  });

  @override
  List<Object> get props => [id, name, type, isTitle];
}

import 'package:equatable/equatable.dart';

class HashTag extends Equatable {
  final String title;
  final String id;
  final String? postCount;

  HashTag({required this.id, required this.title,  this.postCount='0'});

  @override
  List<Object> get props => [id, title, postCount??'0'];
}

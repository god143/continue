import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';

abstract class ExploreResultRepository {
  Future<Either<Failure, SearchResult>> getSearchResultList(
      String searchPhrase);

   Future<Either<Failure, List<HashTag>>> getHashTagList(
      String searchPhrase);
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

abstract class PeopleSearchRepository {
  Future<Either<Failure, List<User>>> getPeopleSearchtList(
      String searchCompanyPhrase, int pageSize, int page);
}

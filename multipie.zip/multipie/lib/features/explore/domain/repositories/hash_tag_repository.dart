import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';

abstract class HashTagRespository {
  Future<Either<Failure, List<HashTag>>> getHashTagList(String searchPhrase);
}

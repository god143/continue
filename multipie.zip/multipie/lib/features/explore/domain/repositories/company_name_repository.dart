import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

abstract class CompanySearchRepository {
  Future<Either<Failure, List<Company>>> getCompanySearchtList(
      String searchCompanyPhrase);
}

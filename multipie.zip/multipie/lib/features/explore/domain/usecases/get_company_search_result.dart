import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/explore/domain/repositories/company_name_repository.dart';
import 'package:multipie/features/market/domain/entities/company/company.dart';

class GetCompanySearchResult implements UseCase<List<Company>, ParamsCompany> {
  final CompanySearchRepository companySearchRepository;

  GetCompanySearchResult(this.companySearchRepository);

  @override
  Future<Either<Failure, List<Company>>> call(ParamsCompany params) async {
    return await companySearchRepository
        .getCompanySearchtList(params.searchCompanyPhrase);
  }
}

class ParamsCompany extends Equatable {
  final String searchCompanyPhrase;

  ParamsCompany({required this.searchCompanyPhrase});

  @override
  List<Object> get props => [searchCompanyPhrase];
}

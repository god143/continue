import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/explore/domain/repositories/pepple_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class GetPeopleSearchResult implements UseCase<List<User>, ParamsPeople> {
  final PeopleSearchRepository peopleSearchRepository;

  GetPeopleSearchResult(this.peopleSearchRepository);

  @override
  Future<Either<Failure, List<User>>> call(ParamsPeople params) async {
    return await peopleSearchRepository.getPeopleSearchtList(
        params.searchPeoplePhrase, params.pageSize, params.page);
  }
}

class ParamsPeople extends Equatable {
  final String searchPeoplePhrase;
  final int pageSize;
  final int page;

  ParamsPeople(
      {required this.searchPeoplePhrase,
      required this.pageSize,
      required this.page});

  @override
  List<Object> get props => [searchPeoplePhrase, pageSize, page];
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/explore/domain/entities/explore_search_result.dart';
import 'package:multipie/features/explore/domain/repositories/explore_result_repository.dart';

class GetExploreResult implements UseCase<SearchResult, Params> {
  final ExploreResultRepository repository;

  GetExploreResult(this.repository);

  @override
  Future<Either<Failure, SearchResult>> call(Params params) async {
    return await repository.getSearchResultList(params.searchPhrase);
  }
}

class Params extends Equatable {
  final String searchPhrase;

  Params({required this.searchPhrase});

  @override
  List<Object> get props => [searchPhrase];
}

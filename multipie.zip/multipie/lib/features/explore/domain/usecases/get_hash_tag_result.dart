import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/explore/domain/entities/hash_tag.dart';
import 'package:multipie/features/explore/domain/repositories/hash_tag_repository.dart';

class GetHashTagResult implements UseCase<List<HashTag>, Params> {
  final HashTagRespository hashTagRepository;

  GetHashTagResult(this.hashTagRepository);

  @override
  Future<Either<Failure, List<HashTag>>> call(Params params) async {
    return await hashTagRepository.getHashTagList(params.searchPhrase);
  }
}

class Params extends Equatable {
  final String searchPhrase;

  Params({required this.searchPhrase});

  @override
  List<Object> get props => [searchPhrase];
}

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/find_friends/data/repositories/contacts_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class GetContactsSuggestionsUsecase extends UseCase<List<User>, Params> {
  final ContactsRepository repository;

  GetContactsSuggestionsUsecase(this.repository);

  @override
  Future<Either<Failure, List<User>>> call(Params params) {
    return repository.getContactsSuggestions(params.page, params.size);
  }
}

class Params extends Equatable {
  final int page;
  final int size;

  Params({required this.page, required this.size});

  @override
  List<Object> get props => [page, size];
}

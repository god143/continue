import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/find_friends/data/repositories/contacts_repository.dart';
import 'package:multipie/features/user/domain/entities/user.dart';

class GetFriendsUsecase extends UseCase<List<User>, GetFriendsUsecaseParams> {
  final ContactsRepository repository;

  GetFriendsUsecase(this.repository);

  @override
  Future<Either<Failure, List<User>>> call(GetFriendsUsecaseParams params) {
    return repository.getFriends(
      searchPhrase: params.searchPhrase,
      page: params.page,
      size: params.size,
    );
  }
}

class GetFriendsUsecaseParams extends Equatable {
  final String searchPhrase;
  final int page;
  final int size;

  GetFriendsUsecaseParams({
    required this.searchPhrase,
    required this.page,
    required this.size,
  });

  @override
  List<Object> get props => [searchPhrase, page, size];
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'find_friends_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$FindFriendsState {
  List<User> get suggestions => throw _privateConstructorUsedError;
  bool get isLoadingSuggestions => throw _privateConstructorUsedError;
  bool get hasUploadedContacts => throw _privateConstructorUsedError;
  bool get isUploadingContacts => throw _privateConstructorUsedError;
  bool get isRequestingFollowAll => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $FindFriendsStateCopyWith<FindFriendsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FindFriendsStateCopyWith<$Res> {
  factory $FindFriendsStateCopyWith(
          FindFriendsState value, $Res Function(FindFriendsState) then) =
      _$FindFriendsStateCopyWithImpl<$Res>;
  $Res call(
      {List<User> suggestions,
      bool isLoadingSuggestions,
      bool hasUploadedContacts,
      bool isUploadingContacts,
      bool isRequestingFollowAll});
}

/// @nodoc
class _$FindFriendsStateCopyWithImpl<$Res>
    implements $FindFriendsStateCopyWith<$Res> {
  _$FindFriendsStateCopyWithImpl(this._value, this._then);

  final FindFriendsState _value;
  // ignore: unused_field
  final $Res Function(FindFriendsState) _then;

  @override
  $Res call({
    Object? suggestions = freezed,
    Object? isLoadingSuggestions = freezed,
    Object? hasUploadedContacts = freezed,
    Object? isUploadingContacts = freezed,
    Object? isRequestingFollowAll = freezed,
  }) {
    return _then(_value.copyWith(
      suggestions: suggestions == freezed
          ? _value.suggestions
          : suggestions // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isLoadingSuggestions: isLoadingSuggestions == freezed
          ? _value.isLoadingSuggestions
          : isLoadingSuggestions // ignore: cast_nullable_to_non_nullable
              as bool,
      hasUploadedContacts: hasUploadedContacts == freezed
          ? _value.hasUploadedContacts
          : hasUploadedContacts // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadingContacts: isUploadingContacts == freezed
          ? _value.isUploadingContacts
          : isUploadingContacts // ignore: cast_nullable_to_non_nullable
              as bool,
      isRequestingFollowAll: isRequestingFollowAll == freezed
          ? _value.isRequestingFollowAll
          : isRequestingFollowAll // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
abstract class _$$_FindFriendsStateCopyWith<$Res>
    implements $FindFriendsStateCopyWith<$Res> {
  factory _$$_FindFriendsStateCopyWith(
          _$_FindFriendsState value, $Res Function(_$_FindFriendsState) then) =
      __$$_FindFriendsStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {List<User> suggestions,
      bool isLoadingSuggestions,
      bool hasUploadedContacts,
      bool isUploadingContacts,
      bool isRequestingFollowAll});
}

/// @nodoc
class __$$_FindFriendsStateCopyWithImpl<$Res>
    extends _$FindFriendsStateCopyWithImpl<$Res>
    implements _$$_FindFriendsStateCopyWith<$Res> {
  __$$_FindFriendsStateCopyWithImpl(
      _$_FindFriendsState _value, $Res Function(_$_FindFriendsState) _then)
      : super(_value, (v) => _then(v as _$_FindFriendsState));

  @override
  _$_FindFriendsState get _value => super._value as _$_FindFriendsState;

  @override
  $Res call({
    Object? suggestions = freezed,
    Object? isLoadingSuggestions = freezed,
    Object? hasUploadedContacts = freezed,
    Object? isUploadingContacts = freezed,
    Object? isRequestingFollowAll = freezed,
  }) {
    return _then(_$_FindFriendsState(
      suggestions: suggestions == freezed
          ? _value._suggestions
          : suggestions // ignore: cast_nullable_to_non_nullable
              as List<User>,
      isLoadingSuggestions: isLoadingSuggestions == freezed
          ? _value.isLoadingSuggestions
          : isLoadingSuggestions // ignore: cast_nullable_to_non_nullable
              as bool,
      hasUploadedContacts: hasUploadedContacts == freezed
          ? _value.hasUploadedContacts
          : hasUploadedContacts // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadingContacts: isUploadingContacts == freezed
          ? _value.isUploadingContacts
          : isUploadingContacts // ignore: cast_nullable_to_non_nullable
              as bool,
      isRequestingFollowAll: isRequestingFollowAll == freezed
          ? _value.isRequestingFollowAll
          : isRequestingFollowAll // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$_FindFriendsState implements _FindFriendsState {
  _$_FindFriendsState(
      {final List<User> suggestions = const [],
      this.isLoadingSuggestions = false,
      this.hasUploadedContacts = false,
      this.isUploadingContacts = false,
      this.isRequestingFollowAll = false})
      : _suggestions = suggestions;

  final List<User> _suggestions;
  @override
  @JsonKey()
  List<User> get suggestions {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_suggestions);
  }

  @override
  @JsonKey()
  final bool isLoadingSuggestions;
  @override
  @JsonKey()
  final bool hasUploadedContacts;
  @override
  @JsonKey()
  final bool isUploadingContacts;
  @override
  @JsonKey()
  final bool isRequestingFollowAll;

  @override
  String toString() {
    return 'FindFriendsState(suggestions: $suggestions, isLoadingSuggestions: $isLoadingSuggestions, hasUploadedContacts: $hasUploadedContacts, isUploadingContacts: $isUploadingContacts, isRequestingFollowAll: $isRequestingFollowAll)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_FindFriendsState &&
            const DeepCollectionEquality()
                .equals(other._suggestions, _suggestions) &&
            const DeepCollectionEquality()
                .equals(other.isLoadingSuggestions, isLoadingSuggestions) &&
            const DeepCollectionEquality()
                .equals(other.hasUploadedContacts, hasUploadedContacts) &&
            const DeepCollectionEquality()
                .equals(other.isUploadingContacts, isUploadingContacts) &&
            const DeepCollectionEquality()
                .equals(other.isRequestingFollowAll, isRequestingFollowAll));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_suggestions),
      const DeepCollectionEquality().hash(isLoadingSuggestions),
      const DeepCollectionEquality().hash(hasUploadedContacts),
      const DeepCollectionEquality().hash(isUploadingContacts),
      const DeepCollectionEquality().hash(isRequestingFollowAll));

  @JsonKey(ignore: true)
  @override
  _$$_FindFriendsStateCopyWith<_$_FindFriendsState> get copyWith =>
      __$$_FindFriendsStateCopyWithImpl<_$_FindFriendsState>(this, _$identity);
}

abstract class _FindFriendsState implements FindFriendsState {
  factory _FindFriendsState(
      {final List<User> suggestions,
      final bool isLoadingSuggestions,
      final bool hasUploadedContacts,
      final bool isUploadingContacts,
      final bool isRequestingFollowAll}) = _$_FindFriendsState;

  @override
  List<User> get suggestions => throw _privateConstructorUsedError;
  @override
  bool get isLoadingSuggestions => throw _privateConstructorUsedError;
  @override
  bool get hasUploadedContacts => throw _privateConstructorUsedError;
  @override
  bool get isUploadingContacts => throw _privateConstructorUsedError;
  @override
  bool get isRequestingFollowAll => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_FindFriendsStateCopyWith<_$_FindFriendsState> get copyWith =>
      throw _privateConstructorUsedError;
}

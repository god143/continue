part of 'find_friends_cubit.dart';

@freezed
class FindFriendsState with _$FindFriendsState {
  factory FindFriendsState({
    @Default([]) List<User> suggestions,
    @Default(false) bool isLoadingSuggestions,
    @Default(false) bool hasUploadedContacts,
    @Default(false) bool isUploadingContacts,
    @Default(false) bool isRequestingFollowAll,
  }) = _FindFriendsState;
}

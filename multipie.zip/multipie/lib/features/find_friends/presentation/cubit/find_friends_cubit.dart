import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/contacts_upload/contacts_upload_manager.dart';
import 'package:multipie/features/find_friends/domain/usecases/get_contacts_suggestions_usecase.dart';
import 'package:multipie/features/profile/domain/usecases/get_people_to_follow.dart'
    show FollowPeopleListUseCase, FollowParams;
import 'package:multipie/features/user/domain/entities/user.dart';

part 'find_friends_cubit.freezed.dart';
part 'find_friends_state.dart';

class FindFriendsCubit extends Cubit<FindFriendsState> {
  FindFriendsCubit({
    required this.loggedInUserId,
    required this.getContactsSuggestionsUsecase,
    required this.followPeopleListUseCase,
    required this.contactsUploadManager,
  }) : super(FindFriendsState());

  final GetContactsSuggestionsUsecase getContactsSuggestionsUsecase;
  final FollowPeopleListUseCase followPeopleListUseCase;
  final ContactsUploadManager contactsUploadManager;

  ValueChanged<String>? onGetSuggestionsError;
  ValueChanged<String>? onContactsUploadError;
  ValueChanged<String>? onFollowAllError;
  VoidCallback? onFollowAllSuccess;

  static const _initialPage = 1;
  static const SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const CACHE_FAILURE_MESSAGE = 'Cache Failure';
  int _page = _initialPage;
  final _pageSize = 20;

  final String loggedInUserId;

  Future<void> getInitialSuggestions() async {
    if (state.isLoadingSuggestions) {
      return;
    }
    _page = _initialPage;
    await _getSuggestions();
  }

  Future<void> getMoreSuggestions() async {
    if (state.isLoadingSuggestions || !state.hasUploadedContacts) {
      return;
    }
    _page += 1;
    await _getSuggestions();
  }

  Future<void> _getSuggestions() async {
    emit(state.copyWith(isLoadingSuggestions: true));
    final page = _page;
    final result = await getContactsSuggestionsUsecase.call(
      Params(page: page, size: _pageSize),
    );
    emit(state.copyWith(isLoadingSuggestions: false));
    result.fold(
      (failure) => onGetSuggestionsError?.call(_mapFailureToMessage(failure)),
      (users) => emit(
        state.copyWith(
          suggestions: page == _initialPage ? users : [...state.suggestions, ...users],
        ),
      ),
    );
  }

  Future<void> followAll() async {
    emit(state.copyWith(isRequestingFollowAll: true));
    final result = await followPeopleListUseCase.call(
      FollowParams(
        list: state.suggestions.map((e) => e.id).toList(growable: false),
        userId: loggedInUserId,
      ),
    );
    result.fold(
      (failure) => onFollowAllError?.call(_mapFailureToMessage(failure)),
      (success) => onFollowAllSuccess?.call(),
    );
    emit(state.copyWith(isRequestingFollowAll: false));
  }

  Future<void> uploadContacts() async {
    emit(state.copyWith(isUploadingContacts: true));
    try {
      await contactsUploadManager.syncContacts(
        onFirstConcurrentBatchUploaded: () => getInitialSuggestions(),
        onCompletion: () {
          emit(
            state.copyWith(
              hasUploadedContacts: true,
              isUploadingContacts: false,
            ),
          );
          getInitialSuggestions();
        },
      );
    } catch (err) {
      onContactsUploadError?.call('Could not upload contact(s)!');
      emit(
        state.copyWith(
          hasUploadedContacts: false,
          isUploadingContacts: false,
        ),
      );
    }
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

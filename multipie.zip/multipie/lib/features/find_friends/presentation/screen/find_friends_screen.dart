import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:multipie/core/responsive/utils/my_button.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/contacts_upload/contacts_upload_manager.dart';
import 'package:multipie/features/find_friends/domain/usecases/get_contacts_suggestions_usecase.dart';
import 'package:multipie/features/find_friends/presentation/cubit/find_friends_cubit.dart';
import 'package:multipie/features/profile/domain/usecases/get_people_to_follow.dart';
import 'package:multipie/features/profile/presentation/bloc/profile_screen/profile_screen_bloc.dart';
import 'package:multipie/features/profile/presentation/screens/people_to_follow_screen.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/new_profile_screen.dart';
import 'package:multipie/features/profile/presentation/widgets/follow_unfollow_widget.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/locator.dart';
import 'package:permission_handler/permission_handler.dart';

class FindFriendsScreen extends StatelessWidget {
  const FindFriendsScreen({
    Key? key,
    this.imageFile,
    required this.isFromHome,
  }) : super(key: key);

  final File? imageFile;
  final bool isFromHome;

  @override
  Widget build(BuildContext context) {
    return BlocProvider<FindFriendsCubit>(
      create: (_) => FindFriendsCubit(
        loggedInUserId: context.read<UserProfileBloc>().currentUser!.id,
        getContactsSuggestionsUsecase: locator<GetContactsSuggestionsUsecase>(),
        followPeopleListUseCase: locator<FollowPeopleListUseCase>(),
        contactsUploadManager: locator<ContactsUploadManager>(),
      )..getInitialSuggestions(),
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: context.appTheme.transparentColor,
          automaticallyImplyLeading: false,
          elevation: 0,
          titleSpacing: 0,
          leading: InkWell(
            child: Padding(
              padding: const EdgeInsets.all(17.5),
              child: SvgPicture.asset(
                'assets/icons/Arrow-Previous.svg',
                color: context.appTheme.primaryColor,
                height: 20,
                width: 20,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: _FindFriendsBody(
          imageFile: imageFile,
          isFromHome: isFromHome,
        ),
      ),
    );
  }
}

class _FindFriendsBody extends StatefulWidget {
  const _FindFriendsBody({
    Key? key,
    required this.imageFile,
    required this.isFromHome,
  }) : super(key: key);

  final File? imageFile;
  final bool isFromHome;

  @override
  State<_FindFriendsBody> createState() => _FindFriendsBodyState();
}

class _FindFriendsBodyState extends State<_FindFriendsBody> {
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();

    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);

    WidgetsBinding.instance.addPostFrameCallback(
      (_) {
        final cubit = context.read<FindFriendsCubit>();
        cubit.onContactsUploadError = _showSanckbar;
        cubit.onGetSuggestionsError = _showSanckbar;
        cubit.onFollowAllError = _showSanckbar;
        cubit.onFollowAllSuccess = () {
          if (mounted) {
            _navigateNext(context);
          }
        };
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: BlocConsumer<FindFriendsCubit, FindFriendsState>(
              listener: (_, __) {},
              builder: (context, state) {
                final isFollowAllDisabled = state.isRequestingFollowAll || state.suggestions.isEmpty;
                return CustomScrollView(
                  slivers: [
                    // Heading
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.only(
                          top: 10,
                          bottom: 20,
                        ),
                        child: Text(
                          'It\'s always better when you\nhave your friends around',
                          textAlign: TextAlign.center,
                          style: mpHeadLine2(context: context),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 12, bottom: 20),
                        child: Row(
                          children: [
                            TextButton(
                              onPressed:
                                  isFollowAllDisabled ? null : () => context.read<FindFriendsCubit>().followAll(),
                              child: Text(
                                'Follow All',
                                style: mpHeadLine4(
                                  context: context,
                                  textColor: isFollowAllDisabled
                                      ? context.appTheme.primaryColor.withOpacity(0.5)
                                      : context.appTheme.primaryColor,
                                ),
                              ),
                            ),
                            SizedBox(width: 20),
                            if (state.isRequestingFollowAll)
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    context.appTheme.primaryColor,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                    // Suggestions List
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) => _SuggestedUserTile(user: state.suggestions[index]),
                        childCount: state.suggestions.length,
                      ),
                    ),
                    // Show Empty State
                    if (!state.isUploadingContacts && !state.isLoadingSuggestions && state.suggestions.isEmpty)
                      SliverToBoxAdapter(
                        child: Center(
                          child: Padding(
                            padding: EdgeInsets.only(
                              top: 20 + (state.suggestions.isEmpty ? 50 : 0),
                              bottom: 20,
                            ),
                            child: Text(
                              'No Results Found.',
                              style: mpHeadLine4(context: context),
                            ),
                          ),
                        ),
                      ),
                    // Show Loading Indicator
                    if (state.isLoadingSuggestions)
                      SliverToBoxAdapter(
                        child: Center(
                          child: Padding(
                            padding: EdgeInsets.only(
                              top: 20 + (state.suggestions.isEmpty ? 50 : 0),
                              bottom: 20,
                            ),
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(context.appTheme.primaryColor),
                            ),
                          ),
                        ),
                      ),
                  ],
                );
              }),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: const _FindFriendsButton(),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.only(
              bottom: 24.0,
              left: 50,
              right: 50,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (widget.isFromHome)
                  SizedBox()
                else
                MaterialButton(
                  padding: EdgeInsets.all(0.0),
                  minWidth: sWidth(115.0),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PeopleToFollowScreen(imageFile: widget.imageFile),
                      ),
                    );
                  },
                  child: Text(
                    'MAYBE LATER',
                    style: mpHeadLine5(
                      context: context,
                      fontWeight: FontWeight.w600,
                      textColor: Theme.of(context).primaryColor,
                    ),
                  ),
                ),
                MultipieButton(
                  text: widget.isFromHome ? "DONE" : "NEXT",
                  elevation: 2,
                  color: Theme.of(context).primaryColor,
                  textColor: context.appTheme.cardBackgroundColor,
                  onPressed: () {
                    _navigateNext(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _navigateNext(BuildContext context) {
    if (widget.isFromHome) {
      Navigator.of(context).pop();
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PeopleToFollowScreen(imageFile: widget.imageFile),
        ),
      );
    }
  }

  void _onScroll() {
    if (_scrollController.position.extentAfter < 200) {
      context.read<FindFriendsCubit>().getMoreSuggestions();
    }
  }

  void _showSanckbar(String message) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: mpHeadLine6(
            context: context,
            textColor: context.appTheme.lightTextColor,
          ),
        ),
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }
}

class _SuggestedUserTile extends StatelessWidget {
  const _SuggestedUserTile({
    Key? key,
    required this.user,
  }) : super(key: key);

  final User user;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NewProfileScreen(
              userId: user.id,
            ),
          ),
        );
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 24),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 65,
                    height: 65,
                    margin: EdgeInsets.only(right: 16),
                    child: ProfilePictureHolder(
                      profileMode: user.marketView,
                      imageUrl: user.dpThumbnail,
                      textStyle: mpHeadLine2(
                        context: context,
                        textColor: context.appTheme.secondaryTextColor,
                      ),
                      holderLetter: user.displayname.isEmpty ? '' : user.displayname[0],
                    ),
                  ),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                user.displayname,
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                style: mpHeadLine5(
                                  context: context,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                "@${user.username}",
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                style: mpHeadLine5(
                                  context: context,
                                  textColor: context.appTheme.secondaryTextColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28,
                          child: FollowUnFollowButton(
                            data: user,
                            width: 110,
                            fontSize: 'mp4',
                            radius: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Divider(
            color: context.appTheme.secondaryTextColor,
          )
        ],
      ),
    );
  }
}

class _FindFriendsButton extends StatelessWidget {
  const _FindFriendsButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<FindFriendsCubit, FindFriendsState>(
      builder: (context, state) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 50),
          height: 70,
          child: MaterialButton(
            color: context.appTheme.tertiaryBackgroundColor,
            padding: EdgeInsets.symmetric(horizontal: 5),
            height: sWidth(30.0),
            minWidth: double.infinity,
            elevation: 0,
            hoverElevation: 0,
            focusElevation: 0,
            highlightElevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(sWidth(10.0)),
            ),
            disabledColor: context.appTheme.tertiaryBackgroundColor.withOpacity(0.5),
            onPressed: state.isUploadingContacts
                ? null
                : () async {
                    final PermissionStatus permissionStatus = await _getPermission();

                    if (permissionStatus == PermissionStatus.granted) {
                      context.read<FindFriendsCubit>().uploadContacts();
                    } else {
                      //If permissions is denied show standard cupertino alert dialog
                      if (!Platform.isIOS) {
                        return showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            backgroundColor: context.appTheme.cardBackgroundColor,
                            title: Text(
                              'Permission error',
                              style: mpHeadLine5(context: context),
                            ),
                            content: Text(
                              'Please enable contact access '
                              'permission in settings.',
                              style: mpHeadLine6(context: context),
                            ),
                            actions: <Widget>[
                              TextButton(
                                child: Text(
                                  'Not now',
                                  style: mpHeadLine6(context: context),
                                ),
                                onPressed: () => Navigator.of(context).pop(),
                              ),
                              TextButton(
                                child: Text(
                                  'Settings',
                                  style: mpHeadLine6(context: context),
                                ),
                                onPressed: () => openAppSettings(),
                              ),
                            ],
                          ),
                        );
                      }

                      return showDialog(
                          context: context,
                          builder: (BuildContext context) => CupertinoAlertDialog(
                                title: Text(
                                  'Permission error',
                                  style: mpHeadLine5(context: context),
                                ),
                                content: Text(
                                  'Please enable contact access '
                                  'permission in settings.',
                                  style: mpHeadLine6(context: context),
                                ),
                                actions: <Widget>[
                                  CupertinoDialogAction(
                                    child: Text(
                                      'Not now',
                                      style: mpHeadLine6(context: context),
                                    ),
                                    onPressed: () => Navigator.of(context).pop(),
                                  ),
                                  CupertinoDialogAction(
                                    child: Text(
                                      'Settings',
                                      style: mpHeadLine6(context: context),
                                    ),
                                    onPressed: () => openAppSettings(),
                                  )
                                ],
                              ));
                    }
                  },
            child: Column(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'FIND MORE FRIENDS',
                          style: mpHeadLine4(
                            context: context,
                            textColor: context.appTheme.primaryButtonTextColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          state.hasUploadedContacts ? 'Refresh your contacts' : 'Connect your contact book',
                          style: mpHeadLine5(
                            context: context,
                            fontWeight: FontWeight.w400,
                            textColor: context.appTheme.primaryButtonTextColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (state.isUploadingContacts)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: LinearProgressIndicator(
                      backgroundColor: context.appTheme.transparentColor,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        context.appTheme.activeIndicationColor,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
      listener: (context, state) {},
    );
  }

  //Check contacts permission
  Future<PermissionStatus> _getPermission() async {
    final PermissionStatus permission = await Permission.contacts.status;

    if (permission != PermissionStatus.granted &&
        (permission == PermissionStatus.permanentlyDenied || permission == PermissionStatus.denied)) {
      final Map<Permission, PermissionStatus> permissionStatus = await [Permission.contacts].request();
      return permissionStatus[Permission.contacts] ?? PermissionStatus.limited;
    } else {
      return permission;
    }
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/find_friends/data/datasources/contacts_remote_datasource.dart';
import 'package:multipie/features/user/data/models/user_model.dart';

class ContactsRepository {
  final NetworkInfo networkInfo;
  final ContactsRemoteDataSource remoteDataSource;

  ContactsRepository({
    required this.networkInfo,
    required this.remoteDataSource,
  });

  Future<Either<Failure, List<UserModel>>> getContactsSuggestions(int page, int size) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getContactsSuggestions(page, size);
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, List<UserModel>>> getFriends({
    required String searchPhrase,
    required int page,
    required int size,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.getFriends(
          searchPhrase: searchPhrase,
          page: page,
          size: size,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

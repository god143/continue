import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/user/data/models/user_model.dart';
import 'package:multipie/services/network_service.dart';

class ContactsRemoteDataSource {
  final NetworkService networkService;

  const ContactsRemoteDataSource({
    required this.networkService,
  });

  Future<List<UserModel>> getContactsSuggestions(int page, int size) async {
    final jsonApi = await networkService.getRequest("/contacts/suggestions/?page_size=$size&page=$page");
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((e) => UserModel.fromJson(e)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }

  Future<List<UserModel>> getFriends({
    required String searchPhrase,
    required int page,
    required int size,
  }) async {
    final jsonApi = await networkService.getRequest("/friends?search_phrase=$searchPhrase&page_size=$size&page=$page");
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((e) => UserModel.fromJson(e)).toList();
    } catch (e) {
      throw ServerException('Failed to get data');
    }
  }
}

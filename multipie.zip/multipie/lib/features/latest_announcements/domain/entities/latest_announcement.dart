import 'package:equatable/equatable.dart';

class LatestAnnouncement extends Equatable {
  final String id;
  final String title;
  final String content;

  LatestAnnouncement({
    required this.id,
    required this.title,
    required this.content,
  });

  @override
  List<Object> get props => [
        id,
        title,
        content,
      ];
}

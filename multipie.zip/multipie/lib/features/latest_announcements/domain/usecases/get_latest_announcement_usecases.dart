import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/latest_announcements/domain/entities/latest_announcement.dart';
import 'package:multipie/features/latest_announcements/domain/repositories/latest_announcement_repository.dart';

class GetLatestAnnouncementUseCase implements UseCase<LatestAnnouncement, NoParams> {
  final LatestAnnouncementRepository latestAnnouncementRespository;

  GetLatestAnnouncementUseCase(this.latestAnnouncementRespository);
  @override
  Future<Either<Failure, LatestAnnouncement>> call(NoParams params) async {
    return await latestAnnouncementRespository.getLatestAnnouncement();
  }
}

class ReadAnnouncementUseCase implements UseCase<MessageResponseModel, Params> {
  final LatestAnnouncementRepository repository;

  ReadAnnouncementUseCase(this.repository);

  @override
  Future<Either<Failure, MessageResponseModel>> call(Params params) async {
    return await repository.readAnnouncement(
      params.id,
    );
  }
}

class Params extends Equatable {
  final String id;

  Params({required this.id});

  @override
  List<Object> get props => [id];
}

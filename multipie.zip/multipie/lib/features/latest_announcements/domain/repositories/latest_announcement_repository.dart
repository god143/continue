import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/latest_announcements/domain/entities/latest_announcement.dart';
import 'package:dartz/dartz.dart';

abstract class LatestAnnouncementRepository {
  Future<Either<Failure, LatestAnnouncement>> getLatestAnnouncement();
  Future<Either<Failure, MessageResponseModel>> readAnnouncement(
    String id,
  );
}

import 'package:multipie/features/latest_announcements/domain/entities/latest_announcement.dart';

class LatestAnnouncementModel extends LatestAnnouncement {
  LatestAnnouncementModel({
    required id,
    required title,
    required content,
  }) : super(
          id: id,
          title: title,
          content: content,
        );

  factory LatestAnnouncementModel.fromJson(Map<String, dynamic> json) {
    return LatestAnnouncementModel(
      id: nullReview(json['id']),
      title: nullReview(json['title']),
      content: nullReview(json['content']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "";
    }
    return obj.toString();
  }
}

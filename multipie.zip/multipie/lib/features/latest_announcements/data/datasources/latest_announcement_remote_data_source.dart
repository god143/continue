import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/latest_announcements/data/models/latest_announcement_model.dart';
import 'package:multipie/services/network_service.dart';
import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';

abstract class LatestAnnouncementRemoteDataSource {
  Future<LatestAnnouncementModel> getLatestAnnouncment();
  Future<MessageResponseModel> readAnnouncement(
    String id,
  );
}

class LatestAnnouncementRemoteDataSourceImpl implements LatestAnnouncementRemoteDataSource {
  final NetworkService networkService;

  LatestAnnouncementRemoteDataSourceImpl({required this.networkService});

  @override
  Future<LatestAnnouncementModel> getLatestAnnouncment() => getLatestAnnouncmentFromService('/announcements/latest');

  Future<LatestAnnouncementModel> getLatestAnnouncmentFromService(
    String url,
  ) async {
    final jsonApi = await networkService.getRequest(url);
    try {
      Map<String, dynamic> jsonData = Japx.decode(jsonApi);
      return LatestAnnouncementModel.fromJson(jsonData['data']);
    } catch (e) {
      print(e.toString());
      throw ServerException('Failed to get posts from data');
    }
  }

  @override
  Future<MessageResponseModel> readAnnouncement(String id) async {
    var jsonApi = await networkService.postRequest(
      '/announcements/$id/read',
    );
    try {
      return MessageResponseModel.fromJson(jsonApi);
    } catch (e) {
      print(e.toString());
      throw ServerException(e.toString());
    }
  }
}

import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/latest_announcements/data/datasources/latest_announcement_remote_data_source.dart';
import 'package:multipie/features/latest_announcements/domain/entities/latest_announcement.dart';
import 'package:multipie/features/latest_announcements/domain/repositories/latest_announcement_repository.dart';

class LatestAnnouncementRepositoryImpl implements LatestAnnouncementRepository {
  final NetworkInfo networkInfo;
  final LatestAnnouncementRemoteDataSource remoteDataSource;

  LatestAnnouncementRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, LatestAnnouncement>> getLatestAnnouncement() async {
    return await _getLatestAnnouncmentFromServer();
  }

  Future<Either<Failure, LatestAnnouncement>> _getLatestAnnouncmentFromServer() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCS = await remoteDataSource.getLatestAnnouncment();
        return Right(remoteCS);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  Future<Either<Failure, MessageResponseModel>> readAnnouncement(String id) async {
    if (await networkInfo.isConnected) {
      try {
        final remotePL = await remoteDataSource.readAnnouncement(id);
        return Right(remotePL);
      } on UnauthorisedException catch (e) {
        return Left(AuthFailure(e.message));
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

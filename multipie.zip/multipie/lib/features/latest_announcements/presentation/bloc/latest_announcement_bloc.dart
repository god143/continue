import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/latest_announcements/domain/entities/latest_announcement.dart';
import 'package:multipie/features/latest_announcements/domain/usecases/get_latest_announcement_usecases.dart';
import 'package:multipie/features/latest_announcements/presentation/bloc/bloc.dart';

class LatestAnnouncementBloc extends Bloc<LatestAnnouncementEvent, LatestAnnouncementState> {
  final GetLatestAnnouncementUseCase getLatestAnnouncementUseCase;
  final ReadAnnouncementUseCase postReadAnnouncementUseCase;

  static const String SERVER_FAILURE_MESSAGE = 'SERVER Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  static const String INVALID_INPUT_FAILURE_MESSAGE = 'Invalid Input - The number must be a positive integer or zero.';

  @override
  LatestAnnouncementState get initialState => Empty();

  LatestAnnouncementBloc({
    required GetLatestAnnouncementUseCase getLatestAnnouncementUseCase,
    required ReadAnnouncementUseCase postReadAnnouncementUseCase,
  })  : getLatestAnnouncementUseCase = getLatestAnnouncementUseCase,
        postReadAnnouncementUseCase = postReadAnnouncementUseCase,
        super(Empty());

  @override
  Stream<LatestAnnouncementState> mapEventToState(
    LatestAnnouncementEvent event,
  ) async* {
    if (event is GetLatestAnnouncement) {
      yield Loading();
      final failureOrLatestAnnouncement = await getLatestAnnouncementUseCase(NoParams());
      yield* _eitherLoadedOrErrorState(failureOrLatestAnnouncement);
    }

    if (event is PostReadAnnouncement) {
      yield Loading();
      final failureOrReadAnnouncement = await postReadAnnouncementUseCase(Params(id: event.readId));
      yield* _eitherLoadedOrReadErrorState(failureOrReadAnnouncement);
    }

    if (event is HideAnnoucmentEvent) {
      yield HidePopup();
    }
  }

  Stream<LatestAnnouncementState> _eitherLoadedOrErrorState(
    Either<Failure, LatestAnnouncement> failureOrLatestAnnouncement,
  ) async* {
    yield failureOrLatestAnnouncement.fold(
      (failure) => Error(message: _mapFailureToMessage(failure)),
      (latestAnnouncement) => Loaded(announcement: latestAnnouncement),
    );
  }

  Stream<LatestAnnouncementState> _eitherLoadedOrReadErrorState(
    Either<Failure, MessageResponseModel> failureOrMessage,
  ) async* {
    yield failureOrMessage.fold(
      (failure) {
        return Error(message: _mapFailureToMessage(failure));
      },
      (data) {
        return ReadAnnouncement(success: data.message);
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class LatestAnnouncementEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetLatestAnnouncement extends LatestAnnouncementEvent {}

class PostReadAnnouncement extends LatestAnnouncementEvent {
  final String readId;

  PostReadAnnouncement(this.readId);

  @override
  List<Object> get props => [readId];
}

class HideAnnoucmentEvent extends LatestAnnouncementEvent {}

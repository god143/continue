import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/latest_announcements/domain/entities/latest_announcement.dart';

@immutable
abstract class LatestAnnouncementState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends LatestAnnouncementState {}

class Loading extends LatestAnnouncementState {}

class HidePopup extends LatestAnnouncementState {}

class Loaded extends LatestAnnouncementState {
  final LatestAnnouncement announcement;
  Loaded({required this.announcement});

  @override
  List<Object> get props => [announcement];
}

class ReadAnnouncement extends LatestAnnouncementState {
  final String success;

  ReadAnnouncement({required this.success});
}

class Error extends LatestAnnouncementState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

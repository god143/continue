import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/list_portfolio/data/models/brokers_model.dart';
import 'package:multipie/features/list_portfolio/data/models/gateway_config.dart';
import 'package:multipie/features/list_portfolio/data/models/sc_transaction.dart';
import 'package:multipie/services/network_service.dart';

abstract class BrokersRemoteDataSource {
  Future<List<BrokersModel>> getBrokersList();

  Future<MessageResponseModel> refreshPortfolio(String provider);

  Future<GatewayConfig> getGatewayConfig();

  Future<SCTransaction> importSCGatewayHoldings({
    required String broker,
    required String authToken,
  });

  Future<bool> saveSCTransaction({
    required Map<String, dynamic> data,
  });

  Future<bool> fetchPortfolio({required String broker});
}

class BrokersRemoteDataSourceImpl implements BrokersRemoteDataSource {
  final NetworkService networkService;

  BrokersRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<BrokersModel>> getBrokersList() => getBrokersListFromService('/brokers');

  Future<List<BrokersModel>> getBrokersListFromService(String url) async {
    final jsonApi = await networkService.getRequest(url);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => BrokersModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }

  @override
  Future<MessageResponseModel> refreshPortfolio(String provider) => _refreshPortfolio('/portfolios/$provider/fetch');

  Future<MessageResponseModel> _refreshPortfolio(String url) async {
    final jsonApi = await networkService.getRequest(url);

    try {
      //Map<String, dynamic> json = Japx.decode(jsonApi);
      return MessageResponseModel.fromJson(jsonApi);
    } catch (e) {
      throw ServerException('Something went wrong');
    }
  }

  @override
  Future<GatewayConfig> getGatewayConfig() async {
    final jsonApi = await networkService.getRequest('/connected_accounts/guest_gateway_initiation');
    try {
      return GatewayConfig.fromJson(jsonApi);
    } catch (e) {
      throw ServerException('Something went wrong');
    }
  }

  @override
  Future<SCTransaction> importSCGatewayHoldings({
    required String broker,
    required String authToken,
  }) async {
    final jsonApi = await networkService.getRequest(
      '/connected_accounts/sc_gateway_holdings_import?token=$authToken&broker=$broker',
    );
    try {
      return SCTransaction.fromJson(jsonApi);
    } catch (e) {
      throw ServerException('Something went wrong');
    }
  }

  @override
  Future<bool> saveSCTransaction({
    required Map<String, dynamic> data,
  }) async {
    await networkService.postRequest(
      '/connected_accounts/save_smallcase_auth_id',
      isUrlEncoded: true,
      body: data,
    );
    try {
      return true;
    } catch (e) {
      throw ServerException('Something went wrong');
    }
  }

  @override
  Future<bool> fetchPortfolio({
    required String broker,
  }) async {
    await networkService.getRequest('/portfolios/$broker/fetch');
    try {
      return true;
    } catch (e) {
      throw ServerException('Something went wrong');
    }
  }
}

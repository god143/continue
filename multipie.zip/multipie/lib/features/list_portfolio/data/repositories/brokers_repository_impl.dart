import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/list_portfolio/data/datasources/brokers_remote_data_source.dart';
import 'package:multipie/features/list_portfolio/data/models/gateway_config.dart';
import 'package:multipie/features/list_portfolio/data/models/sc_transaction.dart';
import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class BrokersRepositoryImpl implements BrokersRepository {
  final NetworkInfo networkInfo;
  final BrokersRemoteDataSource remoteDataSource;

  BrokersRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, List<Brokers>>> getBrokersList() async {
    return await _getBrokersListFromServer();
  }

  Future<Either<Failure, List<Brokers>>> _getBrokersListFromServer() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getBrokersList();
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, MessageResponseModel>> fetchAfterRefresh(String provider) async {
    return await _fetchAfterRefresh(provider);
  }

  Future<Either<Failure, MessageResponseModel>> _fetchAfterRefresh(String provider) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.refreshPortfolio(provider);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, GatewayConfig>> getGatewayConfig() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getGatewayConfig();
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, SCTransaction>> importSCGatewayHoldings({
    required String broker,
    required String authToken,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.importSCGatewayHoldings(
          broker: broker,
          authToken: authToken,
        );
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, bool>> saveSCTransaction({
    required Map<String, dynamic> data,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.saveSCTransaction(data: data);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, bool>> fetchPortfolio({required String broker}) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.fetchPortfolio(broker: broker);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

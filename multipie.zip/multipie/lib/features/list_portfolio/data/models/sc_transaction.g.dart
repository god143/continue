// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sc_transaction.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SCTransaction _$SCTransactionFromJson(Map<String, dynamic> json) =>
    SCTransaction(
      success: json['success'] as bool,
      data: SCTransactionData.fromJson(json['data'] as Map<String, dynamic>),
      brokers:
          (json['brokers'] as List<dynamic>).map((e) => e as String).toList(),
    );

Map<String, dynamic> _$SCTransactionToJson(SCTransaction instance) =>
    <String, dynamic>{
      'success': instance.success,
      'data': instance.data,
      'brokers': instance.brokers,
    };

SCTransactionData _$SCTransactionDataFromJson(Map<String, dynamic> json) =>
    SCTransactionData(
      transactionId: json['transactionId'] as String,
    );

Map<String, dynamic> _$SCTransactionDataToJson(SCTransactionData instance) =>
    <String, dynamic>{
      'transactionId': instance.transactionId,
    };

import 'package:json_annotation/json_annotation.dart';

part 'sc_transaction.g.dart';

@JsonSerializable(fieldRename: FieldRename.none)
class SCTransaction {
  const SCTransaction({
    required this.success,
    required this.data,
    required this.brokers,
  });

  final bool success;
  final SCTransactionData data;
  final List<String> brokers;

  factory SCTransaction.fromJson(Map<String, dynamic> json) => _$SCTransactionFromJson(json);
}

@JsonSerializable(fieldRename: FieldRename.none)
class SCTransactionData {
  const SCTransactionData({
    required this.transactionId,
  });

  final String transactionId;

  factory SCTransactionData.fromJson(Map<String, dynamic> json) => _$SCTransactionDataFromJson(json);
}

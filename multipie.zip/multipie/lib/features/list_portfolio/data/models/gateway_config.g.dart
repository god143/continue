// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gateway_config.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GatewayConfig _$GatewayConfigFromJson(Map<String, dynamic> json) =>
    GatewayConfig(
      gateway: json['gateway'] as String,
      smallcaseAuthToken: json['smallcaseAuthToken'] as String,
      config: json['config'] == null
          ? null
          : ConfigData.fromJson(json['config'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GatewayConfigToJson(GatewayConfig instance) =>
    <String, dynamic>{
      'gateway': instance.gateway,
      'smallcaseAuthToken': instance.smallcaseAuthToken,
      'config': instance.config,
    };

ConfigData _$ConfigDataFromJson(Map<String, dynamic> json) => ConfigData(
      amo: json['amo'] as bool? ?? false,
    );

Map<String, dynamic> _$ConfigDataToJson(ConfigData instance) =>
    <String, dynamic>{
      'amo': instance.amo,
    };

import 'package:json_annotation/json_annotation.dart';

part 'gateway_config.g.dart';

@JsonSerializable(fieldRename: FieldRename.none)
class GatewayConfig {
  const GatewayConfig({
    required this.gateway,
    required this.smallcaseAuthToken,
    this.config,
  });

  final String gateway;
  final String smallcaseAuthToken;
  final ConfigData? config;

  factory GatewayConfig.fromJson(Map<String, dynamic> json) => _$GatewayConfigFromJson(json);

  Map<String, dynamic> toJson() => _$GatewayConfigToJson(this);
}

@JsonSerializable(fieldRename: FieldRename.none)
class ConfigData {
  const ConfigData({
    required this.amo,
  });

  @JsonKey(defaultValue: false)
  final bool amo;

  factory ConfigData.fromJson(Map<String, dynamic> json) => _$ConfigDataFromJson(json);

  Map<String, dynamic> toJson() => _$ConfigDataToJson(this);
}

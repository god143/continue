import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';

class BrokersModel extends Brokers {
  BrokersModel(
      {required identifier,
      required displayName,
      required websiteLink,
      required authUrl,
      required logoPath,
      required callBackUrl,
      required metaInfo})
      : super(
          identifier: identifier,
          displayName: displayName,
          websiteLink: websiteLink,
          authUrl: authUrl,
          logoPath: logoPath,
          callBackUrl: callBackUrl,
          metaInfo: metaInfo,
        );

  factory BrokersModel.fromJson(Map<String, dynamic> json) {
    return BrokersModel(
      identifier: nullReview(json['identifier']),
      displayName: nullReview(json['display_name']),
      websiteLink: nullReview(json['website_link']),
      authUrl: nullReview(json['auth_url']),
      logoPath: nullReview(json['logo_path']),
      callBackUrl: nullReview(json['callback_url']),
      metaInfo: json['meta_info'] != null
          ? MetaInfo.fromJson(json['meta_info'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'identifier': identifier,
      'display_name': displayName,
      'website_link': websiteLink,
      'auth_url': authUrl,
      'logo_path': logoPath,
      'callback_url': callBackUrl
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "0";
    }
    return obj.toString();
  }
}

import 'dart:async';

import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';

class BrokerWebView extends StatefulWidget {
  final String displayName;
  final String authUrl;
  final String callBackUrl;
  final Function successFailureCallbackFunction;
  final String token;
  final String identifier;

  const BrokerWebView(
    this.displayName,
    this.authUrl,
    this.callBackUrl, {
    required this.successFailureCallbackFunction,
    required this.token,
    required this.identifier,
  });

  @override
  _BrokerWebViewState createState() => _BrokerWebViewState();
}

class _BrokerWebViewState extends State<BrokerWebView> {
  final flutterWebviewPlugin = new FlutterWebviewPlugin();

  late StreamSubscription<String> _onUrlChanged;

  @override
  void initState() {
    super.initState();

    flutterWebviewPlugin.close();

    // Add a listener to on url changed
    _onUrlChanged =
        flutterWebviewPlugin.onUrlChanged.listen((String url) async {
      if (mounted) {
        if (url.startsWith(widget.callBackUrl)) {
          if (url.contains("success=false")) {
            _successOrFailureMessage('Broker not connected.', false);
          } else if (url.contains("success=true")) {
            final eventData = {
              'Broker Name': widget.displayName,
            };
            CleverTapPlugin.recordEvent('Broker Connection Successful', eventData);
            _successOrFailureMessage(
                'Broker connected successfully. We are processing your statement, come again after few minutes to see your account connected.',
                true);
          } else {
            _successOrFailureMessage(
                'Something went wrong! Please try again.', false);
          }

          flutterWebviewPlugin.close();
        }
      }
    });
  }

  //Failure or Success Popup
  _successOrFailureMessage(String strMessage, bool isSuccessful) {
    widget.successFailureCallbackFunction(strMessage, isSuccessful);
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _onUrlChanged.cancel();
    flutterWebviewPlugin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String _url = '${Constants.AUTH_SERVER_URL}/auth_redirection/${widget.identifier}'; //
    return WebviewScaffold(
      clearCache: true,
      clearCookies: true,
      appCacheEnabled: false,
      appBar: MultipieAppBar(
        title: "Connect - ${widget.displayName}",
      ),
      url: _url,
      headers: {
        'Authorization': 'Bearer ${widget.token}',
      },
    );
  }
}

import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';

@immutable
abstract class BrokersState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends BrokersState {}

class Loading extends BrokersState {}

class FetchCompletedState extends BrokersState {}

class Loaded extends BrokersState {
  final List<Brokers> brokers;
  Loaded({required this.brokers});

  @override
  List<Object> get props => [brokers];
}

class Error extends BrokersState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

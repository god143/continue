import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';
import 'package:multipie/features/list_portfolio/domain/usecases/fetch_portfolio_usecase.dart';
import 'package:multipie/features/list_portfolio/domain/usecases/get_brokers_usecases.dart';
import 'package:multipie/features/list_portfolio/domain/usecases/get_gateway_config_usecase.dart';
import 'package:multipie/features/list_portfolio/domain/usecases/import_sc_gateway_holdings_usecase.dart';
import 'package:multipie/features/list_portfolio/domain/usecases/refresh_portfolio_usecase.dart';
import 'package:multipie/features/list_portfolio/domain/usecases/save_sc_transaction_usecase.dart';
import 'package:multipie/features/list_portfolio/presentation/bloc/bloc.dart';

class BrokersBloc extends Bloc<BrokersEvent, BrokersState> {
  final GetBrokersUseCase getBrokersUseCase;
  final RefreshPortfolioUseCase fetchRefreshBrokerUseCase;
  final GetGatewayConfigUsecase getGatewayConfigUsecase;
  final ImportSCGatewayHoldingsUsecase importSCGatewayHoldingsUsecase;
  final SaveSCTransactionUsecase saveSCTransactionUsecase;
  final FetchPortfolioUsecase fetchPortfolioUsecase;
  static const String SERVER_FAILURE_MESSAGE = 'SERVER Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';
  static const String INVALID_INPUT_FAILURE_MESSAGE = 'Invalid Input - The number must be a positive integer or zero.';

  @override
  BrokersState get initialState => Empty();

  BrokersBloc({
    required GetBrokersUseCase getBrokersUseCase,
    required RefreshPortfolioUseCase fetchRefreshBrokerUseCase,
    required this.getGatewayConfigUsecase,
    required this.importSCGatewayHoldingsUsecase,
    required this.saveSCTransactionUsecase,
    required this.fetchPortfolioUsecase,
  })  : assert(getBrokersUseCase != null),
        getBrokersUseCase = getBrokersUseCase,
        fetchRefreshBrokerUseCase = fetchRefreshBrokerUseCase,
        super(Empty());

  @override
  Stream<BrokersState> mapEventToState(
    BrokersEvent event,
  ) async* {
    if (event is GetListBrokers) {
      yield Loading();
      final failureOrBrokersList = await getBrokersUseCase(NoParams());
      yield* _eitherLoadedOrErrorState(failureOrBrokersList);
    } else if (event is FetchRefreshBrokerEvent) {
      await fetchRefreshBrokerUseCase(FetchParams(provider: event.provider));
      // yield Loading();
      final failureOrBrokersMessage = await fetchRefreshBrokerUseCase(FetchParams(provider: event.provider));
      if (failureOrBrokersMessage.isLeft()) {
        yield Error(message: 'Something went wrong. Please try later!');
      }
    }
  }

  Stream<BrokersState> _eitherLoadedOrErrorState(
    Either<Failure, List<Brokers>> failureOrBrokersList,
  ) async* {
    yield failureOrBrokersList.fold(
      (failure) => Error(message: mapFailureToMessage(failure)),
      (brokers) => Loaded(brokers: brokers),
    );
  }

  String mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

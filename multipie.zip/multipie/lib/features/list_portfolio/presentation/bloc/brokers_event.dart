import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class BrokersEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListBrokers extends BrokersEvent {}

class FetchRefreshBrokerEvent extends BrokersEvent {
  final String provider;

  FetchRefreshBrokerEvent(this.provider);

  @override
  List<Object> get props => [provider];
}

import 'package:equatable/equatable.dart';

class Brokers extends Equatable {
  final String identifier;
  final String displayName;
  final String websiteLink;
  final String authUrl;
  final String logoPath;
  final String callBackUrl;
  final MetaInfo? metaInfo;

  Brokers({
    required this.identifier,
    required this.displayName,
    required this.websiteLink,
    required this.authUrl,
    required this.logoPath,
    required this.callBackUrl,
    this.metaInfo,
  });

  @override
  List<Object> get props => [
        identifier,
        displayName,
        websiteLink,
        authUrl,
        logoPath,
        callBackUrl,
        metaInfo!,
      ];
}

class MetaInfo {
  bool offline = false;
  bool scGateway = false;

  MetaInfo({
    required this.offline,
    required this.scGateway,
  });

  MetaInfo.fromJson(Map<String, dynamic> json) {
    offline = json['offline'] ?? false;
    scGateway = json['sc_gateway'] ?? false;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['offline'] = this.offline;
    data['sc_gateway'] = this.scGateway;
    return data;
  }
}

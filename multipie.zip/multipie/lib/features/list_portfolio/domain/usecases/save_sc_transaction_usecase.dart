import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class SaveSCTransactionUsecase implements UseCase<bool, SaveSCTransactionParams> {
  final BrokersRepository brokersRespository;

  SaveSCTransactionUsecase(this.brokersRespository);

  @override
  Future<Either<Failure, bool>> call(SaveSCTransactionParams params) =>
      brokersRespository.saveSCTransaction(data: params.data);
}

class SaveSCTransactionParams {
  final Map<String, dynamic> data;

  SaveSCTransactionParams({
    required this.data,
  });
}

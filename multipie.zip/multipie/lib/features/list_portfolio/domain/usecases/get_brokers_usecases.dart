import 'package:multipie/core/utils/failures.dart';
import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class GetBrokersUseCase implements UseCase<List<Brokers>, NoParams> {
  final BrokersRepository brokersRespository;

  GetBrokersUseCase(this.brokersRespository);
  @override
  Future<Either<Failure, List<Brokers>>> call(NoParams params) async {
    return await brokersRespository.getBrokersList();
  }
}

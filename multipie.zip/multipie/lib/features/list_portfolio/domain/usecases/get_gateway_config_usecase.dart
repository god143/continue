import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/list_portfolio/data/models/gateway_config.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class GetGatewayConfigUsecase implements UseCase<GatewayConfig, NoParams> {
  final BrokersRepository brokersRespository;

  GetGatewayConfigUsecase(this.brokersRespository);

  @override
  Future<Either<Failure, GatewayConfig>> call(NoParams params) => brokersRespository.getGatewayConfig();
}

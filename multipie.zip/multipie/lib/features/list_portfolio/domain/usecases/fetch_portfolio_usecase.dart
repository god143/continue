import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class FetchPortfolioUsecase implements UseCase<bool, FetchPortfolioParams> {
  final BrokersRepository brokersRespository;

  FetchPortfolioUsecase(this.brokersRespository);

  @override
  Future<Either<Failure, bool>> call(FetchPortfolioParams params) =>
      brokersRespository.fetchPortfolio(broker: params.broker);
}

class FetchPortfolioParams {
  final String broker;

  FetchPortfolioParams({required this.broker});
}

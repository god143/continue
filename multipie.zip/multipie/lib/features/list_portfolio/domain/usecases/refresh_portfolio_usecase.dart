import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class RefreshPortfolioUseCase implements UseCase<Message, FetchParams> {
  final BrokersRepository repository;

  RefreshPortfolioUseCase(this.repository);

  @override
  Future<Either<Failure, Message>> call(FetchParams params) async {
    return await repository.fetchAfterRefresh(params.provider);
  }
}

class FetchParams extends Equatable {
  final String provider;

  FetchParams({required this.provider});

  @override
  List<Object> get props => [provider];
}

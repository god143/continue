import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/list_portfolio/data/models/sc_transaction.dart';
import 'package:multipie/features/list_portfolio/domain/repositories/brokers_repository.dart';

class ImportSCGatewayHoldingsUsecase implements UseCase<SCTransaction, ImportSCGatewayHoldingsParams> {
  final BrokersRepository brokersRespository;

  ImportSCGatewayHoldingsUsecase(this.brokersRespository);

  @override
  Future<Either<Failure, SCTransaction>> call(ImportSCGatewayHoldingsParams params) =>
      brokersRespository.importSCGatewayHoldings(
        authToken: params.authToken,
        broker: params.broker,
      );
}

class ImportSCGatewayHoldingsParams {
  final String broker;
  final String authToken;

  ImportSCGatewayHoldingsParams({
    required this.broker,
    required this.authToken,
  });
}

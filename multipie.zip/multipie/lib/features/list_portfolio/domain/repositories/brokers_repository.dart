import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/list_portfolio/data/models/gateway_config.dart';
import 'package:multipie/features/list_portfolio/data/models/sc_transaction.dart';
import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';

abstract class BrokersRepository {
  Future<Either<Failure, List<Brokers>>> getBrokersList();
  Future<Either<Failure, Message>> fetchAfterRefresh(String provider);
  Future<Either<Failure, GatewayConfig>> getGatewayConfig();
  Future<Either<Failure, SCTransaction>> importSCGatewayHoldings({
    required String broker,
    required String authToken,
  });
  Future<Either<Failure, bool>> saveSCTransaction({
    required Map<String, dynamic> data,
  });
  Future<Either<Failure, bool>> fetchPortfolio({required String broker});
}

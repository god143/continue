import 'package:dartz/dartz.dart';
import 'package:multipie/core/response_model.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/connected_accounts/data/datasources/connected_accounts_remote_data_source.dart';
import 'package:multipie/features/connected_accounts/domain/entities/connected_accounts.dart';
import 'package:multipie/features/connected_accounts/domain/repositories/connected_accounts_repository.dart';

class ConnectedAccountsRepositoryImpl implements ConnectedAccountsRespository {
  final NetworkInfo networkInfo;
  final ConnectedAccountsRemoteDataSource remoteDataSource;

  ConnectedAccountsRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, List<ConnectedAccounts>>> getConnectedAccountsList() async {
    return await _getConnectedAccountsListFromServer();
  }
 @override
  Future<Either<Failure, ConnectedAccounts>> connectAccount(String uidOnBroker) async {
    return await _connectAccount(uidOnBroker);
  }
 @override
  Future<Either<Failure, ResponseModel>> initiateCasConnect(String uidOnBroker) async {
    return await _initiateCasConnect(uidOnBroker);
  }
 @override
  Future<Either<Failure, Message>> confirmCasConnect(String otp) async {
    return await _confirmCasConnect(otp);
  }

  Future<Either<Failure, List<ConnectedAccounts>>> _getConnectedAccountsListFromServer() async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getConnectedAccountsList();
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
 Future<Either<Failure,ConnectedAccounts>> _connectAccount(String uidOnBroker) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.connectAccount(uidOnBroker);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
 Future<Either<Failure,ResponseModel>> _initiateCasConnect(String uidOnBroker) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.initiateCasConnect(uidOnBroker);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

 Future<Either<Failure,Message>> _confirmCasConnect(String otp) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.confirmCasConnect(otp);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

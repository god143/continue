import 'package:japx/japx.dart';
import 'package:multipie/core/response_model.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/authentication/data/models/auth/message_response_model.dart';
import 'package:multipie/features/connected_accounts/data/models/connected_accounts_model.dart';
import 'package:multipie/services/network_service.dart';

abstract class ConnectedAccountsRemoteDataSource {
  Future<List<ConnectedAccountsModel>> getConnectedAccountsList();

  Future<ConnectedAccountsModel> connectAccount(String uidOnBroker);

  Future<ResponseModel> initiateCasConnect(String uidOnBroker);
  Future<MessageResponseModel> confirmCasConnect(String otp);
}

class ConnectedAccountsRemoteDataSourceImpl
    implements ConnectedAccountsRemoteDataSource {
  final NetworkService networkService;

  ConnectedAccountsRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<ConnectedAccountsModel>> getConnectedAccountsList() =>
      getConnectedAccountsListFromService('/connected_accounts');

  Future<List<ConnectedAccountsModel>> getConnectedAccountsListFromService(
      String url) async {
    final jsonApi = await networkService.getRequest(url);

    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((post) => ConnectedAccountsModel.fromJson(post)).toList();
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }

  @override
  Future<ConnectedAccountsModel> connectAccount(String uidOnBroker) {
    final params = {"uid_on_broker": uidOnBroker, "broker_identifier": "cams"};
    return _connectAccount('/connected_accounts', params);
  }

  Future<ConnectedAccountsModel> _connectAccount(
      String url, Map<String, dynamic> params) async {
    final jsonApi = await networkService.postRequest(url, body: params);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      return ConnectedAccountsModel.fromJson(json['data']);
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }

  @override
  Future<ResponseModel> initiateCasConnect(String uidOnBroker) {
    final params = {"cas_email": uidOnBroker};
    return _initiateCasConnect(
        '/connected_accounts/initiate_cas_connect', params);
  }

  Future<ResponseModel> _initiateCasConnect(
      String url, Map<String, dynamic> params) async {
    final jsonApi =
        await networkService.postRequest2(url, body: params, encodeJson: false);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi.data);
      return jsonApi;
    } catch (e) {
      return ResponseModel(
          statusCode: jsonApi.statusCode, message: 'error', data: {});
    }
  }

  @override
  Future<MessageResponseModel> confirmCasConnect(String otp) {
    final params = {"otp": otp};
    return _confirmCasConnect(
        '/connected_accounts/confirm_cas_account', params);
  }

  Future<MessageResponseModel> _confirmCasConnect(
      String url, Map<String, dynamic> params) async {
    final jsonApi = await networkService.postRequest(url, body: params);
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      return MessageResponseModel.fromJson(json);
    } catch (e) {
      throw ServerException('Failed to get posts from data');
    }
  }
}

import 'package:multipie/features/connected_accounts/domain/entities/connected_accounts.dart';
import 'package:multipie/features/list_portfolio/data/models/brokers_model.dart';

class ConnectedAccountsModel extends ConnectedAccounts {
  ConnectedAccountsModel(
      {required id,
      required currentRefreshStatus,
      required lastRefreshTime,
      required uidOnBroker,
      required accountIdentifier,
      required canDisconnect,
      broker})
      : super(
            id: id,
            currentRefreshStatus: currentRefreshStatus,
            lastRefreshTime: lastRefreshTime,
            uidOnBroker: uidOnBroker,
            accountIdentifier: accountIdentifier,
            canDisconnect: canDisconnect,
            broker: broker);

  factory ConnectedAccountsModel.fromJson(Map<String, dynamic> json) {
    print("JSON : $json");
    return ConnectedAccountsModel(
        id: nullReview(json['id']),
        currentRefreshStatus: nullReview(json['current_refresh_status']),
        lastRefreshTime: nullReview(json['last_refresh_time']),
        uidOnBroker: nullReview(json['uid_on_broker']),
        accountIdentifier: nullReview(json['account_identifier']),
        canDisconnect: json['can_disconnect'] ?? false,
        broker: json['broker'] == null
            ? null
            : BrokersModel.fromJson(json['broker']));
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'current_refresh_status': currentRefreshStatus,
      'last_refresh_time': lastRefreshTime,
      'uid_on_broker': uidOnBroker,
      'account_identifier': accountIdentifier,
      'broker': broker
    };
  }

  static String nullReview(Object? obj) {
    if (obj == null || obj.toString() == "null") {
      return "0";
    }
    return obj.toString();
  }
}

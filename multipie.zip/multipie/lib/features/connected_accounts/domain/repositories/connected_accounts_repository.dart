import 'package:dartz/dartz.dart';
import 'package:multipie/core/response_model.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/connected_accounts/domain/entities/connected_accounts.dart';

abstract class ConnectedAccountsRespository {
  Future<Either<Failure, List<ConnectedAccounts>>> getConnectedAccountsList();
  Future<Either<Failure, ConnectedAccounts>> connectAccount(String uidOnBroker);
  Future<Either<Failure, ResponseModel>> initiateCasConnect(String uidOnBroker);
  Future<Either<Failure, Message>> confirmCasConnect(String otp);
}

import 'package:equatable/equatable.dart';
import 'package:multipie/features/list_portfolio/domain/entities/brokers.dart';

class ConnectedAccounts extends Equatable {
  final String id;
  final String currentRefreshStatus;
  final String lastRefreshTime;
  final String uidOnBroker;
  final String accountIdentifier;
  final Brokers? broker;
  final bool canDisconnect;

  ConnectedAccounts({
    required this.id,
    required this.currentRefreshStatus,
    required this.lastRefreshTime,
    required this.uidOnBroker,
    required this.accountIdentifier,
    required this.broker,
    required this.canDisconnect,
  });

  @override
  List<Object?> get props => [
        id,
        currentRefreshStatus,
        lastRefreshTime,
        uidOnBroker,
        accountIdentifier,
        broker,
        canDisconnect
      ];
}

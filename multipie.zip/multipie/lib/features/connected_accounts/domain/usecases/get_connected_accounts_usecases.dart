import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:multipie/core/response_model.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/authentication/domain/entities/message_entity.dart';
import 'package:multipie/features/connected_accounts/domain/entities/connected_accounts.dart';
import 'package:multipie/features/connected_accounts/domain/repositories/connected_accounts_repository.dart';

class GetConnectedAccountsUseCase
    implements UseCase<List<ConnectedAccounts>, NoParams> {
  final ConnectedAccountsRespository connectedAccountsRespository;

  GetConnectedAccountsUseCase(this.connectedAccountsRespository);

  @override
  Future<Either<Failure, List<ConnectedAccounts>>> call(NoParams params) async {
    return await connectedAccountsRespository.getConnectedAccountsList();
  }
}

class ConnectAccountUseCase
    implements UseCase<ConnectedAccounts, ConnectedAccountParams> {
  final ConnectedAccountsRespository connectedAccountsRespository;

  ConnectAccountUseCase(this.connectedAccountsRespository);

  @override
  Future<Either<Failure, ConnectedAccounts>> call(
      ConnectedAccountParams params) async {
    return await connectedAccountsRespository
        .connectAccount(params.uidOnBroker);
  }
}

class InitiateCasConnectUseCase
    implements UseCase<ResponseModel, ConnectedAccountParams> {
  final ConnectedAccountsRespository connectedAccountsRespository;

  InitiateCasConnectUseCase(this.connectedAccountsRespository);

  @override
  Future<Either<Failure, ResponseModel>> call(
      ConnectedAccountParams params) async {
    return await connectedAccountsRespository
        .initiateCasConnect(params.uidOnBroker);
  }
}

class ConfirmCasAccountUseCase
    implements UseCase<Message, ConfirmAccountParams> {
  final ConnectedAccountsRespository connectedAccountsRespository;

  ConfirmCasAccountUseCase(this.connectedAccountsRespository);

  @override
  Future<Either<Failure, Message>> call(ConfirmAccountParams params) async {
    return await connectedAccountsRespository.confirmCasConnect(params.otp);
  }
}

class ConnectedAccountParams extends Equatable {
  final String uidOnBroker;

  ConnectedAccountParams({
    required this.uidOnBroker,
  });

  @override
  List<Object> get props => [
        uidOnBroker,
      ];
}

class ConfirmAccountParams extends Equatable {
  final String otp;

  ConfirmAccountParams({
    required this.otp,
  });

  @override
  List<Object> get props => [
        otp,
      ];
}

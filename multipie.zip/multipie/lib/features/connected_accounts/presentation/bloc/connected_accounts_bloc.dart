import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/usecase.dart';
import 'package:multipie/features/connected_accounts/domain/entities/connected_accounts.dart';
import 'package:multipie/features/connected_accounts/domain/usecases/get_connected_accounts_usecases.dart';
import 'package:multipie/features/connected_accounts/presentation/bloc/bloc.dart';
import 'package:multipie/features/my_holding/domain/usecases/portfolio_table_usecases.dart';
import 'package:multipie/features/portfolio/domain/entities/latest_statement.dart';

class ConnectedAccountsBloc extends Bloc<ConnectedAccountsEvent, ConnectedAccountsState> {
  final GetConnectedAccountsUseCase getConnectedAccountsUseCase;
  final GetLatestStatementUseCase fetchLatestStatementUseCase;
  LatestStatement? latestStatement;
  List<ConnectedAccounts> connectedAccounts = [];

  @override
  ConnectedAccountsState get initialState => Empty();

  ConnectedAccountsBloc({required this.getConnectedAccountsUseCase, required this.fetchLatestStatementUseCase})
      : super(Empty());

  @override
  Stream<ConnectedAccountsState> mapEventToState(
    ConnectedAccountsEvent event,
  ) async* {
    if (event is GetListConnectedAccounts) {
      yield Loading();
      final failureOrConnectedAccountsList = await getConnectedAccountsUseCase(NoParams());
      if (failureOrConnectedAccountsList.isRight()) {
        connectedAccounts = failureOrConnectedAccountsList.getOrElse(() => <ConnectedAccounts>[]);
        bool isCAMSConnected = connectedAccounts.indexWhere((element) => element.accountIdentifier == 'cams') > -1;
        if (isCAMSConnected) {
          final failureOrStatement = await fetchLatestStatementUseCase(NoParams());
          if (failureOrStatement.isRight()) {
            latestStatement = failureOrStatement.getOrElse(() {
              return null;
            });
          }
        }
        yield Loaded(connectedAccounts: connectedAccounts);
      } else {
        yield Error(message: "Something went wrong! Please try later");
      }
    }
  }
}

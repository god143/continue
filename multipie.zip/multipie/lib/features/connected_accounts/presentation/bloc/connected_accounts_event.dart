import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class ConnectedAccountsEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetListConnectedAccounts extends ConnectedAccountsEvent {}

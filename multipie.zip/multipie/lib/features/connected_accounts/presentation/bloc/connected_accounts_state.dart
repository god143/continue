import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/connected_accounts/domain/entities/connected_accounts.dart';

@immutable
abstract class ConnectedAccountsState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends ConnectedAccountsState {}

class Loading extends ConnectedAccountsState {}

// class NoMForBrokerAdded extends ConnectedAccountsState {}

class Loaded extends ConnectedAccountsState {
  final List<ConnectedAccounts> connectedAccounts;
  Loaded({required this.connectedAccounts});

  @override
  List<Object> get props => [connectedAccounts];
}

class Error extends ConnectedAccountsState {
  final String message;

  Error({required this.message});

  @override
  List<Object> get props => [message];
}

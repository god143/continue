// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'uploaded_file_info.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UploadedFileInfo _$$_UploadedFileInfoFromJson(Map<String, dynamic> json) =>
    _$_UploadedFileInfo(
      recordId: json['record_id'] as int,
      filePath: json['file_path'] as String,
      fileType: json['file_type'] as String,
    );

Map<String, dynamic> _$$_UploadedFileInfoToJson(_$_UploadedFileInfo instance) =>
    <String, dynamic>{
      'record_id': instance.recordId,
      'file_path': instance.filePath,
      'file_type': instance.fileType,
    };

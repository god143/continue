// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'uploaded_file_info.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

UploadedFileInfo _$UploadedFileInfoFromJson(Map<String, dynamic> json) {
  return _UploadedFileInfo.fromJson(json);
}

/// @nodoc
mixin _$UploadedFileInfo {
  int get recordId => throw _privateConstructorUsedError;
  String get filePath => throw _privateConstructorUsedError;
  String get fileType => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UploadedFileInfoCopyWith<UploadedFileInfo> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UploadedFileInfoCopyWith<$Res> {
  factory $UploadedFileInfoCopyWith(
          UploadedFileInfo value, $Res Function(UploadedFileInfo) then) =
      _$UploadedFileInfoCopyWithImpl<$Res>;
  $Res call({int recordId, String filePath, String fileType});
}

/// @nodoc
class _$UploadedFileInfoCopyWithImpl<$Res>
    implements $UploadedFileInfoCopyWith<$Res> {
  _$UploadedFileInfoCopyWithImpl(this._value, this._then);

  final UploadedFileInfo _value;
  // ignore: unused_field
  final $Res Function(UploadedFileInfo) _then;

  @override
  $Res call({
    Object? recordId = freezed,
    Object? filePath = freezed,
    Object? fileType = freezed,
  }) {
    return _then(_value.copyWith(
      recordId: recordId == freezed
          ? _value.recordId
          : recordId // ignore: cast_nullable_to_non_nullable
              as int,
      filePath: filePath == freezed
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      fileType: fileType == freezed
          ? _value.fileType
          : fileType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_UploadedFileInfoCopyWith<$Res>
    implements $UploadedFileInfoCopyWith<$Res> {
  factory _$$_UploadedFileInfoCopyWith(
          _$_UploadedFileInfo value, $Res Function(_$_UploadedFileInfo) then) =
      __$$_UploadedFileInfoCopyWithImpl<$Res>;
  @override
  $Res call({int recordId, String filePath, String fileType});
}

/// @nodoc
class __$$_UploadedFileInfoCopyWithImpl<$Res>
    extends _$UploadedFileInfoCopyWithImpl<$Res>
    implements _$$_UploadedFileInfoCopyWith<$Res> {
  __$$_UploadedFileInfoCopyWithImpl(
      _$_UploadedFileInfo _value, $Res Function(_$_UploadedFileInfo) _then)
      : super(_value, (v) => _then(v as _$_UploadedFileInfo));

  @override
  _$_UploadedFileInfo get _value => super._value as _$_UploadedFileInfo;

  @override
  $Res call({
    Object? recordId = freezed,
    Object? filePath = freezed,
    Object? fileType = freezed,
  }) {
    return _then(_$_UploadedFileInfo(
      recordId: recordId == freezed
          ? _value.recordId
          : recordId // ignore: cast_nullable_to_non_nullable
              as int,
      filePath: filePath == freezed
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      fileType: fileType == freezed
          ? _value.fileType
          : fileType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$_UploadedFileInfo implements _UploadedFileInfo {
  _$_UploadedFileInfo(
      {required this.recordId, required this.filePath, required this.fileType});

  factory _$_UploadedFileInfo.fromJson(Map<String, dynamic> json) =>
      _$$_UploadedFileInfoFromJson(json);

  @override
  final int recordId;
  @override
  final String filePath;
  @override
  final String fileType;

  @override
  String toString() {
    return 'UploadedFileInfo(recordId: $recordId, filePath: $filePath, fileType: $fileType)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_UploadedFileInfo &&
            const DeepCollectionEquality().equals(other.recordId, recordId) &&
            const DeepCollectionEquality().equals(other.filePath, filePath) &&
            const DeepCollectionEquality().equals(other.fileType, fileType));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(recordId),
      const DeepCollectionEquality().hash(filePath),
      const DeepCollectionEquality().hash(fileType));

  @JsonKey(ignore: true)
  @override
  _$$_UploadedFileInfoCopyWith<_$_UploadedFileInfo> get copyWith =>
      __$$_UploadedFileInfoCopyWithImpl<_$_UploadedFileInfo>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_UploadedFileInfoToJson(this);
  }
}

abstract class _UploadedFileInfo implements UploadedFileInfo {
  factory _UploadedFileInfo(
      {required final int recordId,
      required final String filePath,
      required final String fileType}) = _$_UploadedFileInfo;

  factory _UploadedFileInfo.fromJson(Map<String, dynamic> json) =
      _$_UploadedFileInfo.fromJson;

  @override
  int get recordId => throw _privateConstructorUsedError;
  @override
  String get filePath => throw _privateConstructorUsedError;
  @override
  String get fileType => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_UploadedFileInfoCopyWith<_$_UploadedFileInfo> get copyWith =>
      throw _privateConstructorUsedError;
}

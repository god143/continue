import 'package:freezed_annotation/freezed_annotation.dart';

part 'uploaded_file_info.freezed.dart';
part 'uploaded_file_info.g.dart';

@freezed
class UploadedFileInfo with _$UploadedFileInfo {
  @JsonSerializable(explicitToJson: true)
  factory UploadedFileInfo({
    required int recordId,
    required String filePath,
    required String fileType,
  }) = _UploadedFileInfo;

  factory UploadedFileInfo.fromJson(Map<String, dynamic> json) => _$UploadedFileInfoFromJson(json);
}

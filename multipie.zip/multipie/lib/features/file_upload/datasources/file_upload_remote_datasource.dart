import 'dart:io';

import 'package:dio/dio.dart';
import 'package:japx/japx.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/file_upload/models/uploaded_file_info.dart';
import 'package:multipie/services/network_service.dart';

class FileUploadRemoteDataSource {
  final NetworkService networkService;

  const FileUploadRemoteDataSource({
    required this.networkService,
  });

  Future<UploadedFileInfo> uploadFile({
    required String attachableType,
    required String attachableId,
    required File file,
  }) async {
    final jsonApi = await networkService.postMultipartFormRequest(
      '/file_uploads',
      fields: {
        'attachable_type': attachableType,
        'attachable_id': attachableId,
        'file': MultipartFile.fromFileSync(file.path),
      },
    );
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      final data = json['data'] as Map;
      return UploadedFileInfo.fromJson(Map<String, dynamic>.from(data));
    } catch (e) {
      throw ServerException('Failed to upload file!');
    }
  }
}

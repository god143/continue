import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/file_upload/datasources/file_upload_remote_datasource.dart';
import 'package:multipie/features/file_upload/models/uploaded_file_info.dart';

class FileUploadRepository {
  final NetworkInfo networkInfo;
  final FileUploadRemoteDataSource remoteDataSource;

  const FileUploadRepository({
    required this.networkInfo,
    required this.remoteDataSource,
  });

  Future<Either<Failure, UploadedFileInfo>> uploadFile({
    required String attachableType,
    required String attachableId,
    required File file,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final response = await remoteDataSource.uploadFile(
          attachableType: attachableType,
          attachableId: attachableId,
          file: file,
        );
        return Right(response);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      } on DioError catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

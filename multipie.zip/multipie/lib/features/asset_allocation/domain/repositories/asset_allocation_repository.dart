import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/asset_allocation/data/models/held_instument.dart';

abstract class AssetAllocationRepository {
  Future<Either<Failure, List<HeldInstrument>>> getTopEquityMFHoldingList(String userId);
  Future<Either<Failure, List<HeldInstrument>>> getTopDirectEquityHoldingList(String userId);
  Future<Either<Failure, List<HeldInstrument>>> getDebtMFHoldingList(String userId);
  Future<Either<Failure, List<HeldInstrument>>> getBondHoldingList(String userId);
}

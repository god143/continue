import 'package:japx/japx.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/features/asset_allocation/data/models/held_instument.dart';
import 'package:multipie/services/network_service.dart';

abstract class AssetHoldingRemoteDataSource {
  Future<List<HeldInstrument>> getTopEquityMFHoldingList(String userId);

  Future<List<HeldInstrument>> getTopDirectEquityHoldingList(String userId);

  Future<List<HeldInstrument>> getTopDebtMFHoldingList(String userId);

  Future<List<HeldInstrument>> getTopBondHoldingList(String userId);
}

class AssetHoldingRemoteDataSourceImpl implements AssetHoldingRemoteDataSource {
  final NetworkService networkService;

  AssetHoldingRemoteDataSourceImpl({required this.networkService});

  @override
  Future<List<HeldInstrument>> getTopEquityMFHoldingList(String userId) async {
    String urlToSubmit = "${Constants.BASE_URL}/api/v2/top_equity_mf_holdings?user_id=$userId";
    final jsonApi = await networkService.getRequest(
      urlToSubmit,
      isFullURL: true,
    );
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((asset) => HeldInstrument.fromJson(asset)).toList();
    } catch (e) {
      throw ServerException('Failed to get equity mf for data');
    }
  }

  @override
  Future<List<HeldInstrument>> getTopDirectEquityHoldingList(String userId) async {
    String urlToSubmit = "${Constants.BASE_URL}/api/v2/top_direct_equity_holdings?user_id=$userId";
    final jsonApi = await networkService.getRequest(
      urlToSubmit,
      isFullURL: true,
    );
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((asset) => HeldInstrument.fromJson(asset)).toList();
    } catch (e) {
      throw ServerException('Failed to top direct list for');
    }
  }

  @override
  Future<List<HeldInstrument>> getTopDebtMFHoldingList(String userId) async {
    String urlToSubmit = "${Constants.BASE_URL}/api/v2/top_debt_mf_holdings?user_id=$userId";
    final jsonApi = await networkService.getRequest(
      urlToSubmit,
      isFullURL: true,
    );
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((asset) => HeldInstrument.fromJson(asset)).toList();
    } catch (e) {
      throw ServerException('Failed to top direct list for');
    }
  }

  @override
  Future<List<HeldInstrument>> getTopBondHoldingList(String userId) async {
    String urlToSubmit = "${Constants.BASE_URL}/api/v2/top_bond_holdings?user_id=$userId";
    final jsonApi = await networkService.getRequest(
      urlToSubmit,
      isFullURL: true,
    );
    try {
      Map<String, dynamic> json = Japx.decode(jsonApi);
      Iterable data = json['data'];
      return data.map((asset) => HeldInstrument.fromJson(asset)).toList();
    } catch (e) {
      throw ServerException('Failed to top direct list for');
    }
  }
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'held_instument.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

HeldInstrument _$HeldInstrumentFromJson(Map<String, dynamic> json) {
  return _HeldInstrument.fromJson(json);
}

/// @nodoc
mixin _$HeldInstrument {
  int get id => throw _privateConstructorUsedError;
  String get displayName => throw _privateConstructorUsedError;
  String get identifier => throw _privateConstructorUsedError;
  String get extId => throw _privateConstructorUsedError;
  InstrumentType get type => throw _privateConstructorUsedError;
  int get ownerId => throw _privateConstructorUsedError;
  String? get logoUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HeldInstrumentCopyWith<HeldInstrument> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HeldInstrumentCopyWith<$Res> {
  factory $HeldInstrumentCopyWith(
          HeldInstrument value, $Res Function(HeldInstrument) then) =
      _$HeldInstrumentCopyWithImpl<$Res>;
  $Res call(
      {int id,
      String displayName,
      String identifier,
      String extId,
      InstrumentType type,
      int ownerId,
      String? logoUrl});
}

/// @nodoc
class _$HeldInstrumentCopyWithImpl<$Res>
    implements $HeldInstrumentCopyWith<$Res> {
  _$HeldInstrumentCopyWithImpl(this._value, this._then);

  final HeldInstrument _value;
  // ignore: unused_field
  final $Res Function(HeldInstrument) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? displayName = freezed,
    Object? identifier = freezed,
    Object? extId = freezed,
    Object? type = freezed,
    Object? ownerId = freezed,
    Object? logoUrl = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      identifier: identifier == freezed
          ? _value.identifier
          : identifier // ignore: cast_nullable_to_non_nullable
              as String,
      extId: extId == freezed
          ? _value.extId
          : extId // ignore: cast_nullable_to_non_nullable
              as String,
      type: type == freezed
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as InstrumentType,
      ownerId: ownerId == freezed
          ? _value.ownerId
          : ownerId // ignore: cast_nullable_to_non_nullable
              as int,
      logoUrl: logoUrl == freezed
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
abstract class _$$_HeldInstrumentCopyWith<$Res>
    implements $HeldInstrumentCopyWith<$Res> {
  factory _$$_HeldInstrumentCopyWith(
          _$_HeldInstrument value, $Res Function(_$_HeldInstrument) then) =
      __$$_HeldInstrumentCopyWithImpl<$Res>;
  @override
  $Res call(
      {int id,
      String displayName,
      String identifier,
      String extId,
      InstrumentType type,
      int ownerId,
      String? logoUrl});
}

/// @nodoc
class __$$_HeldInstrumentCopyWithImpl<$Res>
    extends _$HeldInstrumentCopyWithImpl<$Res>
    implements _$$_HeldInstrumentCopyWith<$Res> {
  __$$_HeldInstrumentCopyWithImpl(
      _$_HeldInstrument _value, $Res Function(_$_HeldInstrument) _then)
      : super(_value, (v) => _then(v as _$_HeldInstrument));

  @override
  _$_HeldInstrument get _value => super._value as _$_HeldInstrument;

  @override
  $Res call({
    Object? id = freezed,
    Object? displayName = freezed,
    Object? identifier = freezed,
    Object? extId = freezed,
    Object? type = freezed,
    Object? ownerId = freezed,
    Object? logoUrl = freezed,
  }) {
    return _then(_$_HeldInstrument(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      displayName: displayName == freezed
          ? _value.displayName
          : displayName // ignore: cast_nullable_to_non_nullable
              as String,
      identifier: identifier == freezed
          ? _value.identifier
          : identifier // ignore: cast_nullable_to_non_nullable
              as String,
      extId: extId == freezed
          ? _value.extId
          : extId // ignore: cast_nullable_to_non_nullable
              as String,
      type: type == freezed
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as InstrumentType,
      ownerId: ownerId == freezed
          ? _value.ownerId
          : ownerId // ignore: cast_nullable_to_non_nullable
              as int,
      logoUrl: logoUrl == freezed
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_HeldInstrument implements _HeldInstrument {
  _$_HeldInstrument(
      {required this.id,
      required this.displayName,
      required this.identifier,
      required this.extId,
      required this.type,
      required this.ownerId,
      this.logoUrl});

  factory _$_HeldInstrument.fromJson(Map<String, dynamic> json) =>
      _$$_HeldInstrumentFromJson(json);

  @override
  final int id;
  @override
  final String displayName;
  @override
  final String identifier;
  @override
  final String extId;
  @override
  final InstrumentType type;
  @override
  final int ownerId;
  @override
  final String? logoUrl;

  @override
  String toString() {
    return 'HeldInstrument(id: $id, displayName: $displayName, identifier: $identifier, extId: $extId, type: $type, ownerId: $ownerId, logoUrl: $logoUrl)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HeldInstrument &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality()
                .equals(other.displayName, displayName) &&
            const DeepCollectionEquality()
                .equals(other.identifier, identifier) &&
            const DeepCollectionEquality().equals(other.extId, extId) &&
            const DeepCollectionEquality().equals(other.type, type) &&
            const DeepCollectionEquality().equals(other.ownerId, ownerId) &&
            const DeepCollectionEquality().equals(other.logoUrl, logoUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(displayName),
      const DeepCollectionEquality().hash(identifier),
      const DeepCollectionEquality().hash(extId),
      const DeepCollectionEquality().hash(type),
      const DeepCollectionEquality().hash(ownerId),
      const DeepCollectionEquality().hash(logoUrl));

  @JsonKey(ignore: true)
  @override
  _$$_HeldInstrumentCopyWith<_$_HeldInstrument> get copyWith =>
      __$$_HeldInstrumentCopyWithImpl<_$_HeldInstrument>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_HeldInstrumentToJson(this);
  }
}

abstract class _HeldInstrument implements HeldInstrument {
  factory _HeldInstrument(
      {required final int id,
      required final String displayName,
      required final String identifier,
      required final String extId,
      required final InstrumentType type,
      required final int ownerId,
      final String? logoUrl}) = _$_HeldInstrument;

  factory _HeldInstrument.fromJson(Map<String, dynamic> json) =
      _$_HeldInstrument.fromJson;

  @override
  int get id => throw _privateConstructorUsedError;
  @override
  String get displayName => throw _privateConstructorUsedError;
  @override
  String get identifier => throw _privateConstructorUsedError;
  @override
  String get extId => throw _privateConstructorUsedError;
  @override
  InstrumentType get type => throw _privateConstructorUsedError;
  @override
  int get ownerId => throw _privateConstructorUsedError;
  @override
  String? get logoUrl => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_HeldInstrumentCopyWith<_$_HeldInstrument> get copyWith =>
      throw _privateConstructorUsedError;
}

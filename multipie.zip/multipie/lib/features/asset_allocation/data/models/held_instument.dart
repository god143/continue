import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';

part 'held_instument.freezed.dart';
part 'held_instument.g.dart';

@freezed
class HeldInstrument with _$HeldInstrument {
  factory HeldInstrument({
    required int id,
    required String displayName,
    required String identifier,
    required String extId,
    required InstrumentType type,
    required int ownerId,
    String? logoUrl,
  }) = _HeldInstrument;

  factory HeldInstrument.fromJson(Map<String, dynamic> json) => _$HeldInstrumentFromJson(json);
}

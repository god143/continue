// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'held_instument.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_HeldInstrument _$$_HeldInstrumentFromJson(Map<String, dynamic> json) =>
    _$_HeldInstrument(
      id: json['id'] as int,
      displayName: json['display_name'] as String,
      identifier: json['identifier'] as String,
      extId: json['ext_id'] as String,
      type: $enumDecode(_$InstrumentTypeEnumMap, json['type']),
      ownerId: json['owner_id'] as int,
      logoUrl: json['logo_url'] as String?,
    );

Map<String, dynamic> _$$_HeldInstrumentToJson(_$_HeldInstrument instance) =>
    <String, dynamic>{
      'id': instance.id,
      'display_name': instance.displayName,
      'identifier': instance.identifier,
      'ext_id': instance.extId,
      'type': _$InstrumentTypeEnumMap[instance.type],
      'owner_id': instance.ownerId,
      'logo_url': instance.logoUrl,
    };

const _$InstrumentTypeEnumMap = {
  InstrumentType.marketIndex: 'MarketIndex',
  InstrumentType.fund: 'Fund',
  InstrumentType.stock: 'Stock',
};

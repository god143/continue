import 'package:flutter/material.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/profile/domain/entities/profile_holding.dart';

List<Color> getAssetIndicatorColor(String label, List<ProfileHoldingGroup> groupList, BuildContext context) {
  List<Color> data = [];
  for (int index = 0; index < groupList.length; index++) {
    if (label == "Equity") {
      if (groupList[index].label == "Equity MFs") {
        data.add(context.appTheme.equityMFChartColor);
      } else if (groupList[index].label == "Large Cap") {
        data.add(context.appTheme.largeCapEquityChartColor);
      } else {
        data.add(context.appTheme.midAndSmallCapEquityChartColor);
      }
    } else if (label == "Gold") {
      if (groupList[index].label == "SGB" || groupList[index].label == "Gold") {
        data.add(context.appTheme.sgbChartColor);
      } else {
        data.add(context.appTheme.goldMFAndETFChartColor);
      }
    } else if (label == "Debt") {
      if (groupList[index].label == "Debt MF") {
        data.add(context.appTheme.debtMFChartColor);
      } else {
        data.add(context.appTheme.otherBondsChartColor);
      }
    } else if (label == "Asset Allocations") {
      if (groupList[index].label == "Equity") {
        data.add(context.appTheme.equityChartColor);
      } else if (groupList[index].label == "Gold") {
        data.add(context.appTheme.goldChartColor);
      } else {
        data.add(context.appTheme.debtChartColor);
      }
    } else {
      data.add(Theme.of(context).primaryColor);
    }
  }
  return data;
}

List<String> getGroupData(List<ProfileHoldingGroup> groupList) {
  List<String> strData = [];
  groupList.forEach((element) {
    strData.add(element.label);
  });
  return strData;
}

List<double> getAssetPercentage(List<ProfileHoldingGroup> groupList) {
  List<double> data = [];
  groupList.forEach((element) {
    data.add(double.parse(num.parse(element.weight).toStringAsFixed(1)));
  });
  return data;
}

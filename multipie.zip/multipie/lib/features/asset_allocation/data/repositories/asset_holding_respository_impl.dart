import 'package:dartz/dartz.dart';
import 'package:multipie/core/utils/exceptions.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/core/utils/network_info.dart';
import 'package:multipie/features/asset_allocation/data/datasource/asset_holding_remote_datasource.dart';
import 'package:multipie/features/asset_allocation/data/models/held_instument.dart';
import 'package:multipie/features/asset_allocation/domain/repositories/asset_allocation_repository.dart';

class AssetHoldingRepositoryImpl implements AssetAllocationRepository {
  final NetworkInfo networkInfo;
  final AssetHoldingRemoteDataSource remoteDataSource;

  AssetHoldingRepositoryImpl({required this.networkInfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, List<HeldInstrument>>> getTopEquityMFHoldingList(String userId) async {
    return await getListFromServer(userId);
  }

  Future<Either<Failure, List<HeldInstrument>>> getListFromServer(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTopEquityMFHoldingList(userId);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<HeldInstrument>>> getTopDirectEquityHoldingList(String userId) async {
    return await getDirectEquityListFromServer(userId);
  }

  Future<Either<Failure, List<HeldInstrument>>> getDirectEquityListFromServer(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTopDirectEquityHoldingList(userId);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<HeldInstrument>>> getDebtMFHoldingList(String userId) async {
    return await getDebtMFListFromServer(userId);
  }

  Future<Either<Failure, List<HeldInstrument>>> getDebtMFListFromServer(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTopDebtMFHoldingList(userId);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }

  @override
  Future<Either<Failure, List<HeldInstrument>>> getBondHoldingList(String userId) async {
    return await getBondListFromServer(userId);
  }

  Future<Either<Failure, List<HeldInstrument>>> getBondListFromServer(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final remoteCL = await remoteDataSource.getTopBondHoldingList(userId);
        return Right(remoteCL);
      } on ServerException catch (e) {
        return Left(ServerFailure(e.message));
      }
    } else {
      return Left(InternetFailure());
    }
  }
}

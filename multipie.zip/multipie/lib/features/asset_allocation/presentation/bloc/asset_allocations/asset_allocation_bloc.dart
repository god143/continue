import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multipie/core/utils/failures.dart';
import 'package:multipie/features/asset_allocation/data/models/held_instument.dart';
import 'package:multipie/features/asset_allocation/domain/repositories/asset_allocation_repository.dart';

import 'bloc.dart';

class AssetAllocationBloc extends Bloc<AssetAllocationEvent, AssetAllocationState> {
  final AssetAllocationRepository assetAllocationRepository;

  static const String SERVER_FAILURE_MESSAGE = 'Server Failure';
  static const String CACHE_FAILURE_MESSAGE = 'Cache Failure';

  AssetAllocationState get initialState => Empty();

  AssetAllocationBloc({
    required this.assetAllocationRepository,
  }) : super(Empty());

  @override
  Stream<AssetAllocationState> mapEventToState(
    AssetAllocationEvent event,
  ) async* {
    yield LoadingHoldings();
    if (event is GetTopEquityMFList) {
      final failureOrPostList = await assetAllocationRepository.getTopEquityMFHoldingList(event.userId);
      yield* _eitherLoadedOrErrorState(failureOrPostList, event);
    }
    if (event is GetTopDirectEquityList) {
      final failureOrPostList = await assetAllocationRepository.getTopDirectEquityHoldingList(event.userId);
      yield* _eitherLoadedOrErrorState(failureOrPostList, event);
    }
    if (event is GetDebtMFHoldingList) {
      final failureOrPostList = await assetAllocationRepository.getDebtMFHoldingList(event.userId);
      yield* _eitherLoadedOrErrorState(failureOrPostList, event);
    }
    if (event is GetTopBondHoldingList) {
      final failureOrPostList = await assetAllocationRepository.getBondHoldingList(event.userId);
      yield* _eitherLoadedOrErrorState(failureOrPostList, event);
    }
  }

  Stream<AssetAllocationState> _eitherLoadedOrErrorState(
      Either<Failure, List<HeldInstrument>> failureOrPostResults, event) async* {
    yield failureOrPostResults.fold(
      (failure) {
        if (event is GetTopEquityMFList) {
          return ErrorLoadingMFHoldings(message: _mapFailureToPosts(failure));
        }
        if (event is GetTopDirectEquityList) {
          return ErrorLoadingDirectHoldings(message: _mapFailureToPosts(failure));
        }
        if (event is GetDebtMFHoldingList) {
          return ErrorLoadingDebtMF(message: _mapFailureToPosts(failure));
        } else {
          return ErrorLoadingBondHoldings(message: _mapFailureToPosts(failure));
        }
      },
      (data) {
        if (event is GetTopEquityMFList) {
          return EquityMFLoaded(listData: data);
        }
        if (event is GetTopDirectEquityList) {
          return DirectEquityLoaded(listData: data);
        }
        if (event is GetDebtMFHoldingList) {
          return DebtMFLoaded(listData: data);
        }
        if (event is GetTopBondHoldingList) {
          return BondLoaded(listData: data);
        } else
          return Empty();
      },
    );
  }

  String _mapFailureToPosts(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case CacheFailure:
        return CACHE_FAILURE_MESSAGE;
      default:
        return 'Unexpected error';
    }
  }
}

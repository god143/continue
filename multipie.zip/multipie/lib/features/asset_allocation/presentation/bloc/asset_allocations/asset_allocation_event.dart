import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class AssetAllocationEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetTopEquityMFList extends AssetAllocationEvent {
  final String userId;

  GetTopEquityMFList(this.userId);

  @override
  List<Object> get props => [userId];
}

class GetTopDirectEquityList extends AssetAllocationEvent {
  final String userId;

  GetTopDirectEquityList(this.userId);

  @override
  List<Object> get props => [userId];
}

class GetDebtMFHoldingList extends AssetAllocationEvent {
  final String userId;

  GetDebtMFHoldingList(this.userId);

  @override
  List<Object> get props => [userId];
}

class GetTopBondHoldingList extends AssetAllocationEvent {
  final String userId;

  GetTopBondHoldingList(this.userId);

  @override
  List<Object> get props => [userId];
}

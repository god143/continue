import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:multipie/features/asset_allocation/data/models/held_instument.dart';

@immutable
abstract class AssetAllocationState extends Equatable {
  @override
  List<Object> get props => [];
}

class Empty extends AssetAllocationState {}

class LoadingHoldings extends AssetAllocationState {}

class EquityMFLoaded extends AssetAllocationState {
  final List<HeldInstrument> listData;

  EquityMFLoaded({required this.listData});

  @override
  List<Object> get props => [listData];
}

class DirectEquityLoaded extends AssetAllocationState {
  final List<HeldInstrument> listData;

  DirectEquityLoaded({required this.listData});

  @override
  List<Object> get props => [listData];
}

class DebtMFLoaded extends AssetAllocationState {
  final List<HeldInstrument> listData;

  DebtMFLoaded({required this.listData});

  @override
  List<Object> get props => [listData];
}

class BondLoaded extends AssetAllocationState {
  final List<HeldInstrument> listData;

  BondLoaded({required this.listData});

  @override
  List<Object> get props => [listData];
}

class ErrorLoadingMFHoldings extends AssetAllocationState {
  final String message;

  ErrorLoadingMFHoldings({required this.message});

  @override
  List<Object> get props => [message];
}

class ErrorLoadingBondHoldings extends AssetAllocationState {
  final String message;

  ErrorLoadingBondHoldings({required this.message});

  @override
  List<Object> get props => [message];
}

class ErrorLoadingDirectHoldings extends AssetAllocationState {
  final String message;

  ErrorLoadingDirectHoldings({required this.message});

  @override
  List<Object> get props => [message];
}

class ErrorLoadingDebtMF extends AssetAllocationState {
  final String message;

  ErrorLoadingDebtMF({required this.message});

  @override
  List<Object> get props => [message];
}

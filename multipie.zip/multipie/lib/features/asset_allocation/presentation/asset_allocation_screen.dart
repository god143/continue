import 'package:cached_network_image/cached_network_image.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:multipie/constants.dart';
import 'package:multipie/core/multipie_widgets/multipie_appbar.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/profile_picture_holder.dart';
import 'package:multipie/features/asset_allocation/data/asset_allocation_data.dart';
import 'package:multipie/features/asset_allocation/data/models/held_instument.dart';
import 'package:multipie/features/asset_allocation/presentation/bloc/asset_allocations/bloc.dart';
import 'package:multipie/features/asset_allocation/presentation/widgets/asset_allocation_screen_donut.dart';
import 'package:multipie/features/explore/presentation/widgets/mutual_fund_screen.dart';
import 'package:multipie/features/instruments/data/models/instrument/instrument.dart';
import 'package:multipie/features/profile/domain/entities/profile_holding.dart';
import 'package:multipie/features/profile/presentation/screens/user_profile_screen/pinch_to_zoom.dart';
import 'package:multipie/features/user/domain/entities/user.dart';
import 'package:multipie/screens/company_screen/company_info_mobile_portrait.dart';
import 'package:multipie/services/navigation_service.dart';

class AssetAllocationScreen extends StatefulWidget {
  final int navigateTo;
  final List<ProfileHolding> profileHoldingList;
  final User user;

  const AssetAllocationScreen({
    Key? key,
    required this.navigateTo,
    required this.user,
    required this.profileHoldingList,
  }) : super(key: key);

  @override
  _AssetAllocationScreenState createState() => _AssetAllocationScreenState();
}

class _AssetAllocationScreenState extends State<AssetAllocationScreen> with TickerProviderStateMixin {
  late User currentUser;
  int touchedIndex = 0;
  late PageController controller;
  List<ProfileHolding> holdingList = [];
  List<HeldInstrument> equityMFList = [];
  List<HeldInstrument> directEquityList = [];
  List<HeldInstrument> debtMFHoldings = [];
  List<HeldInstrument> bondList = [];
  ValueNotifier<Key> _expanded = ValueNotifier(UniqueKey());
  late TabController equityTabController;
  late TabController debtTabController;

  @override
  void initState() {
    super.initState();
    currentUser = widget.user;
    controller = PageController(initialPage: widget.navigateTo);

    BlocProvider.of<AssetAllocationBloc>(context).add(GetTopDirectEquityList(currentUser.id));

    BlocProvider.of<AssetAllocationBloc>(context).add(GetTopEquityMFList(currentUser.id));

    BlocProvider.of<AssetAllocationBloc>(context).add(GetDebtMFHoldingList(currentUser.id));

    BlocProvider.of<AssetAllocationBloc>(context).add(GetTopBondHoldingList(currentUser.id));

    if (widget.profileHoldingList != null && widget.profileHoldingList.length > 0) {
      holdingList.addAll(widget.profileHoldingList);
    }
    equityTabController = TabController(length: 2, vsync: this)
      ..addListener(() {
        setState(() {});
      });
    debtTabController = TabController(length: 2, vsync: this)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  void dispose() {
    equityTabController.dispose();
    debtTabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MultipieAppBar(
        title: 'Asset Allocation',
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Container(
                          height: 60,
                          width: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: context.appTheme.cardBackgroundColor,
                          ),
                          child: GestureDetector(
                            onTap: () {
                              Navigate.push(
                                  context,
                                  PinchToZoomScreen(
                                    userName: currentUser.displayname,
                                    gifUrl: currentUser.dpUrl,
                                  ));
                            },
                            child: ProfilePictureHolder(
                              profileMode: currentUser.marketView,
                              imageUrl: currentUser.dpThumbnail,
                              holderLetter: currentUser.displayname == null || currentUser.displayname == ''
                                  ? ''
                                  : currentUser.displayname[0],
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(width: 10),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          currentUser.displayname,
                          style: TextStyle(
                            color: context.appTheme.primaryTextColor,
                            fontSize: 15,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          '@' + currentUser.username,
                          style: TextStyle(
                            color: context.appTheme.secondaryTextColor,
                            fontSize: 15,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: BlocConsumer<AssetAllocationBloc, AssetAllocationState>(
              listener: (context, state) {
                if (state is ErrorLoadingDirectHoldings) {
                  print(state.message);
                  Scaffold.of(context).showSnackBar(SnackBar(
                    content: Text(
                      state.message,
                      style: mpHeadLine6(
                        context: context,
                        textColor: context.appTheme.lightTextColor,
                      ),
                    ),
                  ));
                }
                if (state is ErrorLoadingMFHoldings) {
                  print(state.message);
                  Scaffold.of(context).showSnackBar(SnackBar(
                    content: Text(
                      state.message,
                      style: mpHeadLine6(
                        context: context,
                        textColor: context.appTheme.lightTextColor,
                      ),
                    ),
                  ));
                }
                if (state is DirectEquityLoaded) {
                  setState(() {
                    directEquityList.addAll(state.listData);
                  });
                }
                if (state is EquityMFLoaded) {
                  setState(() {
                    equityMFList.addAll(state.listData);
                  });
                }
                if (state is DebtMFLoaded) {
                  setState(() {
                    debtMFHoldings.addAll(state.listData);
                  });
                }
                if (state is BondLoaded) {
                  setState(() {
                    bondList.addAll(state.listData);
                  });
                }
              },
              builder: (context, state) {
                return PageView(
                  controller: controller,
                  physics: NeverScrollableScrollPhysics(),
                  children: [
                    //Equity Holdings
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        children: [
                          //Pie Chart
                          Stack(
                            children: [
                              AssetAllocationScreenDonut(
                                expandedItem: _expanded,
                                holdingData: holdingList[0],
                                selectedPieIndex: (selectedIndex) {
                                  if (selectedIndex == 0 || selectedIndex == 1) {
                                    _expanded.value = Key('equityStocks');
                                    equityTabController.animateTo(0);
                                  } else if (selectedIndex == 2) {
                                    _expanded.value = Key('equityMF');
                                    equityTabController.animateTo(1);
                                  }
                                },
                              ),
                              centerLabel(context, holdingList[0].label),
                              nextArrow(context),
                            ],
                          ),
                          //Pie Chart Section Indicator
                          legendIndicators(holdingList[0]),
                          //Direct Equity Holdings & Equity MF Holdings
                          Expanded(
                            flex: 7,
                            child: !(directEquityList.length > 0 ||
                                    equityMFList.length > 0 ||
                                    bondList.length > 0 ||
                                    debtMFHoldings.length > 0)
                                ? Center(
                                    child: CircularProgressIndicator(),
                                  )
                                : (holdingList[0].label.toLowerCase() == "equity")
                                    ? Column(
                                        children: [
                                          TabBar(
                                            unselectedLabelColor: context.appTheme.secondaryTextColor,
                                            labelColor: context.appTheme.blueShadeColor,
                                            tabs: [
                                              //if (directEquityList.length > 0)
                                              Tab(
                                                child: Text(
                                                  'Top Stocks',
                                                  style: mpHeadLine5(
                                                    context: context,
                                                    textColor: context.appTheme.secondaryTextColor,
                                                  ),
                                                ),
                                              ),
                                              //if (equityMFList.length > 0)
                                              Tab(
                                                child: Text(
                                                  'Top Mutual Funds',
                                                  style: mpHeadLine5(
                                                    context: context,
                                                    textColor: context.appTheme.secondaryTextColor,
                                                  ),
                                                ),
                                              ),
                                            ],
                                            controller: equityTabController,
                                            indicatorWeight: 3,
                                            onTap: (value) {
                                              setState(() {
                                                equityTabController.index = value;
                                                equityTabController.index == 0
                                                    ? _expanded.value = Key('equityStocks')
                                                    : _expanded.value = Key('equityMF');
                                              });
                                            },
                                            indicatorSize: TabBarIndicatorSize.tab,
                                            indicatorColor: context.appTheme.blueShadeColor,
                                          ),
                                          Expanded(
                                            child: TabBarView(
                                              children: [
                                                TopHoldingList(listData: directEquityList, key: Key('equityStocks')),
                                                TopHoldingList(listData: equityMFList, key: Key('equityMF')),
                                              ],
                                              controller: equityTabController,
                                            ),
                                          )
                                        ],
                                      )
                                    : Column(
                                        children: [
                                          TabBar(
                                            unselectedLabelColor: context.appTheme.secondaryTextColor,
                                            labelColor: context.appTheme.blueShadeColor,
                                            tabs: [
                                              //if (directEquityList.length > 0)
                                              Tab(
                                                child: Text(
                                                  'Top Debt MF Holdings',
                                                  style: mpHeadLine5(
                                                    context: context,
                                                    textColor: context.appTheme.secondaryTextColor,
                                                  ),
                                                ),
                                              ),
                                              //if (equityMFList.length > 0)
                                              Tab(
                                                child: Text(
                                                  'Top Bonds',
                                                  style: mpHeadLine5(
                                                    context: context,
                                                    textColor: context.appTheme.secondaryTextColor,
                                                  ),
                                                ),
                                              ),
                                            ],
                                            controller: debtTabController,
                                            indicatorWeight: 3,
                                            onTap: (value) {
                                              setState(() {
                                                debtTabController.index = value;
                                                debtTabController.index == 0
                                                    ? _expanded.value = Key('debtMF')
                                                    : _expanded.value = Key('debtBonds');
                                              });
                                            },
                                            indicatorSize: TabBarIndicatorSize.tab,
                                            indicatorColor: context.appTheme.blueShadeColor,
                                          ),
                                          Expanded(
                                            child: TabBarView(
                                              children: [
                                                TopHoldingList(listData: debtMFHoldings, key: Key('debtMF')),
                                                TopHoldingList(listData: bondList, key: Key('debtBonds')),
                                              ],
                                              controller: debtTabController,
                                            ),
                                          )
                                        ],
                                      ),
                          ),
                        ],
                      ),
                    ),

                    //Debt Holdings
                    if (holdingList.length > 1)
                      Container(
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            //Pie Chart
                            Stack(
                              children: [
                                AssetAllocationScreenDonut(
                                  expandedItem: _expanded,
                                  holdingData: holdingList[1],
                                  selectedPieIndex: (selectedIndex) {},
                                ),
                                centerLabel(context, holdingList[1].label),
                                previousArrow(context),
                              ],
                            ),
                            //Pie Chart Section Indicator
                            legendIndicators(holdingList[1]),
                            //Debt MF Holdings & Bonds
                            Expanded(
                              flex: 7,
                              child: (holdingList[1].label.toLowerCase() == "debt")
                                  ? Column(
                                      children: [
                                        TabBar(
                                          unselectedLabelColor: context.appTheme.secondaryTextColor,
                                          labelColor: context.appTheme.blueShadeColor,
                                          tabs: [
                                            //if (directEquityList.length > 0)
                                            Tab(
                                              child: Text(
                                                'Top Debt MF Holdings',
                                                style: mpHeadLine5(
                                                  context: context,
                                                  textColor: context.appTheme.secondaryTextColor,
                                                ),
                                              ),
                                            ),
                                            //if (equityMFList.length > 0)
                                            Tab(
                                              child: Text(
                                                'Top Bonds',
                                                style: mpHeadLine5(
                                                  context: context,
                                                  textColor: context.appTheme.secondaryTextColor,
                                                ),
                                              ),
                                            ),
                                          ],
                                          controller: debtTabController,
                                          indicatorWeight: 3,
                                          onTap: (value) {
                                            setState(() {
                                              debtTabController.index = value;
                                              debtTabController.index == 0
                                                  ? _expanded.value = Key('debtMF')
                                                  : _expanded.value = Key('debtBonds');
                                            });
                                          },
                                          indicatorSize: TabBarIndicatorSize.tab,
                                          indicatorColor: context.appTheme.blueShadeColor,
                                        ),
                                        Expanded(
                                          child: TabBarView(
                                            children: [
                                              TopHoldingList(listData: debtMFHoldings, key: Key('debtMF')),
                                              TopHoldingList(listData: bondList, key: Key('debtBonds')),
                                            ],
                                            controller: debtTabController,
                                          ),
                                        )
                                      ],
                                    )
                                  : Column(
                                      children: [
                                        TabBar(
                                          unselectedLabelColor: context.appTheme.secondaryTextColor,
                                          labelColor: context.appTheme.blueShadeColor,
                                          tabs: [
                                            //if (directEquityList.length > 0)
                                            Tab(
                                              child: Text(
                                                'Top Stocks',
                                                style: mpHeadLine5(
                                                  context: context,
                                                  textColor: context.appTheme.secondaryTextColor,
                                                ),
                                              ),
                                            ),
                                            //if (equityMFList.length > 0)
                                            Tab(
                                              child: Text(
                                                'Top Mutual Funds',
                                                style: mpHeadLine5(
                                                  context: context,
                                                  textColor: context.appTheme.secondaryTextColor,
                                                ),
                                              ),
                                            ),
                                          ],
                                          controller: equityTabController,
                                          indicatorWeight: 3,
                                          onTap: (value) {
                                            setState(() {
                                              equityTabController.index = value;
                                              equityTabController.index == 0
                                                  ? _expanded.value = Key('equityStocks')
                                                  : _expanded.value = Key('equityMF');
                                            });
                                          },
                                          indicatorSize: TabBarIndicatorSize.tab,
                                          indicatorColor: context.appTheme.blueShadeColor,
                                        ),
                                        Expanded(
                                          child: TabBarView(
                                            children: [
                                              TopHoldingList(listData: directEquityList, key: Key('equityStocks')),
                                              TopHoldingList(listData: equityMFList, key: Key('equityMF')),
                                            ],
                                            controller: equityTabController,
                                          ),
                                        )
                                      ],
                                    ),
                            ),
                          ],
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  SizedBox previousArrow(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 200,
      child: Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.only(left: 10),
          child: InkWell(
            child: CircleAvatar(
              backgroundColor: context.appTheme.primaryBackgroundColor,
              radius: 18,
              child: SvgPicture.asset(
                'assets/icons/Arrow-Previous.svg',
                color: context.appTheme.primaryColor,
                height: 20,
                width: 20,
              ),
            ),
            onTap: () {
              print('previous');
              controller.animateToPage(
                0,
                duration: Duration(milliseconds: 300),
                curve: Curves.easeInOut,
              );
            },
          ),
        ),
      ),
    );
  }

  Expanded legendIndicators(ProfileHolding holdingData) {
    return Expanded(
      flex: 1,
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: holdingData.groupList.length,
        separatorBuilder: (BuildContext context, int index) {
          return SizedBox(width: 18);
        },
        itemBuilder: (BuildContext context, int index) => Row(
          children: [
            Container(
              height: 12,
              width: 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: getAssetIndicatorColor(holdingData.label, holdingData.groupList, context)[index],
              ),
            ),
            SizedBox(
              width: 6,
            ),
            Text(
              holdingData.groupList[index].label,
              style: mpHeadLine5(
                context: context,
                textColor: context.appTheme.secondaryTextColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Visibility nextArrow(BuildContext context) {
    return Visibility(
      visible: holdingList.length > 1,
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: 200,
        child: Align(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.only(right: 10),
            child: InkWell(
              child: CircleAvatar(
                backgroundColor: context.appTheme.primaryBackgroundColor,
                radius: 18,
                child: SvgPicture.asset(
                  'assets/icons/Arrow_Next.svg',
                  color: context.appTheme.primaryColor,
                  height: 20,
                  width: 20,
                ),
              ),
              onTap: () {
                controller.animateToPage(
                  1,
                  duration: Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  SizedBox centerLabel(BuildContext context, String label) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 200,
      child: Center(
          child: Text(
        label.toUpperCase(),
        style: mpHeadLine5(
          context: context,
          textColor: Theme.of(context).primaryColor,
          fontWeight: FontWeight.bold,
        ),
      )),
    );
  }
}

class TopHoldingList extends StatelessWidget {
  final List<HeldInstrument> listData;

  const TopHoldingList({required Key key, required this.listData}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return listData.length > 0
        ? ListView.separated(
            physics: AlwaysScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: listData.length,
            separatorBuilder: (BuildContext context, int index) {
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Divider(
                  thickness: 1,
                  height: 2,
                ),
              );
            },
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return listData[index].type == InstrumentType.stock
                            ? CompanyInfoMobilePortrait(
                                companyId: listData[index].ownerId.toString(),
                                companyName: listData[index].displayName,
                              )
                            : MutualFundScreen(
                                mutualFundId: listData[index].ownerId.toString(),
                                mutualFundName: listData[index].displayName,
                              );
                      },
                    ),
                  );
                },
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 16.0),
                      child: CachedNetworkImage(
                        imageUrl: '${Constants.API_MF_IMAGE_URL}${listData[index].logoUrl}',
                        width: 30,
                        height: 30,
                        errorWidget: (context, url, error) {
                          return Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: context.appTheme.borderColor,
                              shape: BoxShape.circle,
                            ),
                            child: Text(
                              listData[index].displayName.characters.firstOrNull ?? '-',
                              style: mpHeadLine4(
                                context: context,
                                textColor: Theme.of(context).primaryColor,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Text(
                          listData[index].displayName,
                          style: mpHeadLine6(
                            context: context,
                            textColor: context.appTheme.primaryTextColor,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          )
        : Container(
            child: Center(
              child: Text(
                key == Key('equityStocks')
                    ? 'No Stocks'
                    : (key == Key('equityMF') || key == Key('debtMF'))
                        ? 'No Mutual Funds'
                        : 'No Bonds',
                style: mpHeadLine6(context: context),
              ),
            ),
          );
  }
}

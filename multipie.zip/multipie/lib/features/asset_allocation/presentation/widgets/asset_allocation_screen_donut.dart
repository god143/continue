import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/features/asset_allocation/data/asset_allocation_data.dart';
import 'package:multipie/features/profile/domain/entities/profile_holding.dart';

class AssetAllocationScreenDonut extends StatefulWidget {
  final ProfileHolding holdingData;
  final ValueNotifier<Key> expandedItem;
  final Function(int) selectedPieIndex;

  const AssetAllocationScreenDonut({
    required this.holdingData,
    required this.expandedItem,
    required this.selectedPieIndex,
  }) : super();

  @override
  _AssetAllocationScreenDonutState createState() => _AssetAllocationScreenDonutState();
}

class _AssetAllocationScreenDonutState extends State<AssetAllocationScreenDonut> {
  int touchedIndex = 0;

  @override
  void initState() {
    super.initState();
    widget.expandedItem.addListener(listener);
  }

  void listener() {
    if (widget.expandedItem.value == Key('equityStocks') || widget.expandedItem.value == Key('debtMF')) {
      touchedIndex = 0;
    } else {
      touchedIndex = 2;
    }
    //setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: MediaQuery.of(context).size.width / 200,
      child: PieChart(
        PieChartData(
          startDegreeOffset: -90,
          pieTouchData: PieTouchData(
            touchCallback: (touchInput, pieTouchResponse) {
              setState(
                () {
                  if (touchInput is FlPanStartEvent || touchInput is FlLongPressStart) {
                    touchedIndex = pieTouchResponse!.touchedSection!.touchedSectionIndex;
                  } else {
                    touchedIndex = touchedIndex;
                  }
                  widget.selectedPieIndex(touchedIndex);
                  print("Touched Index $touchedIndex");
                },
              );
            },
          ),
          borderData: FlBorderData(
            show: false,
          ),
          sectionsSpace: 2,
          centerSpaceRadius: 40,
          sections: [
            if (getGroupData(widget.holdingData.groupList).length > 0)
              PieChartSectionData(
                color: getAssetIndicatorColor(
                  widget.holdingData.label,
                  widget.holdingData.groupList[0].label == 'Equity MFs'
                      ? widget.holdingData.groupList.reversed.toList()
                      : widget.holdingData.groupList,
                  context,
                )[0],
                value: getAssetPercentage(
                  widget.holdingData.groupList[0].label == 'Equity MFs'
                      ? widget.holdingData.groupList.reversed.toList()
                      : widget.holdingData.groupList,
                )[0],
                radius: touchedIndex == 0 || touchedIndex == 1 ? 55.0 : 40.0,
                showTitle: true,
                title:
                    '${getAssetPercentage(widget.holdingData.groupList[0].label == 'Equity MFs' ? widget.holdingData.groupList.reversed.toList() : widget.holdingData.groupList)[0].toString()}%',
                titleStyle: mpHeadLine6(
                  context: context,
                  fontWeight: FontWeight.w600,
                  textColor: context.appTheme.chartLabelTextColor,
                ),
              ),
            if (getGroupData(widget.holdingData.groupList).length > 1)
              PieChartSectionData(
                color: getAssetIndicatorColor(
                  widget.holdingData.label,
                  widget.holdingData.groupList[0].label == 'Equity MFs'
                      ? widget.holdingData.groupList.reversed.toList()
                      : widget.holdingData.groupList,
                  context,
                )[1],
                value: getAssetPercentage(
                  widget.holdingData.groupList[0].label == 'Equity MFs'
                      ? widget.holdingData.groupList.reversed.toList()
                      : widget.holdingData.groupList,
                )[1],
                radius: touchedIndex == 0 || touchedIndex == 1 ? 55.0 : 40.0,
                showTitle: true,
                title:
                    '${getAssetPercentage(widget.holdingData.groupList[0].label == 'Equity MFs' ? widget.holdingData.groupList.reversed.toList() : widget.holdingData.groupList)[1].toString()}%',
                titleStyle: mpHeadLine6(
                  context: context,
                  fontWeight: FontWeight.w600,
                  textColor: context.appTheme.chartLabelTextColor,
                ),
              ),
            if (getGroupData(widget.holdingData.groupList).length > 2)
              PieChartSectionData(
                color: getAssetIndicatorColor(
                  widget.holdingData.label,
                  widget.holdingData.groupList[0].label == 'Equity MFs'
                      ? widget.holdingData.groupList.reversed.toList()
                      : widget.holdingData.groupList,
                  context,
                )[2],
                value: getAssetPercentage(
                  widget.holdingData.groupList[0].label == 'Equity MFs'
                      ? widget.holdingData.groupList.reversed.toList()
                      : widget.holdingData.groupList,
                )[2],
                radius: touchedIndex == 2 ? 55.0 : 40.0,
                showTitle: true,
                title:
                    '${getAssetPercentage(widget.holdingData.groupList[0].label == 'Equity MFs' ? widget.holdingData.groupList.reversed.toList() : widget.holdingData.groupList)[2].toString()}%',
                titleStyle: mpHeadLine6(
                  context: context,
                  fontWeight: FontWeight.w600,
                  textColor: context.appTheme.chartLabelTextColor,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

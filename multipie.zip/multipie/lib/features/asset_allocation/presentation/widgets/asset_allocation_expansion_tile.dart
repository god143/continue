import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:multipie/core/ui_helper_new.dart';
import 'package:multipie/core/utils/extensions.dart';
import 'package:multipie/core/widgets/list_item_divider.dart';

const Duration _kExpand = Duration(milliseconds: 200);

class AssetAllocationExpansionTile extends StatefulWidget {
  final Widget title;
  final List listData;
  final Color backgroundColor;
  final ValueNotifier<Key?> expandedItem;
  final bool initiallyExpanded;

  const AssetAllocationExpansionTile({
    Key? key,
    required this.title,
    required this.listData,
    required this.backgroundColor,
    required this.expandedItem,
    this.initiallyExpanded = false,
  })  : assert(initiallyExpanded != null),
        super(key: key);

  @override
  _AssetAllocationExpansionTileState createState() => _AssetAllocationExpansionTileState();
}

class _AssetAllocationExpansionTileState extends State<AssetAllocationExpansionTile>
    with SingleTickerProviderStateMixin {
  static final Animatable<double> _easeOutTween = CurveTween(curve: Curves.easeOut);
  static final Animatable<double> _easeInTween = CurveTween(curve: Curves.easeIn);

  final ColorTween _borderColorTween = ColorTween();
  final ColorTween _headerColorTween = ColorTween();
  final ColorTween _iconColorTween = ColorTween();
  final ColorTween _backgroundColorTween = ColorTween();

  late AnimationController _controller;
  late Animation<double> _heightFactor;
  late Animation<Color?> _borderColor;
  late Animation<Color?> _headerColor;
  late Animation<Color?> _iconColor;
  late Animation<Color?> _backgroundColor;

  bool _isExpanded = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: _kExpand, vsync: this);
    _heightFactor = _controller.drive(_easeInTween);
    _borderColor = _controller.drive(_borderColorTween.chain(_easeOutTween));
    _headerColor = _controller.drive(_headerColorTween.chain(_easeInTween));
    _iconColor = _controller.drive(_iconColorTween.chain(_easeInTween));
    _backgroundColor = _controller.drive(_backgroundColorTween.chain(_easeOutTween));

    _isExpanded = widget.initiallyExpanded;
    if (_isExpanded) _controller.value = 1.0;

    widget.expandedItem.addListener(listener);
  }

  void listener() {
    _changeState(widget.expandedItem.value == widget.key);
  }

  @override
  void dispose() {
    _controller.dispose();
    widget.expandedItem.removeListener(listener);
    super.dispose();
  }

  void _changeState(bool isExpanded) {
    setState(() {
      _isExpanded = isExpanded;
      if (_isExpanded) {
        _controller.forward();
      } else {
        _controller.reverse().then<void>((void value) {
          if (!mounted) return;
        });
      }
      PageStorage.of(context)?.writeState(context, _isExpanded);
    });
  }

  void _handleTap() {
    if (!_isExpanded) {
      _changeState(!_isExpanded);
      widget.expandedItem.value = _isExpanded ? widget.key : null;
    }
  }

  Widget _buildChildren(BuildContext context, Widget? child) {
    final Color borderSideColor = _borderColor.value ?? context.appTheme.transparentColor;

    return Container(
      decoration: BoxDecoration(
        color: _backgroundColor.value ?? context.appTheme.transparentColor,
        border: Border(
          top: BorderSide(color: borderSideColor),
          bottom: BorderSide(color: borderSideColor),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          ListTileTheme.merge(
            iconColor: _iconColor.value,
            textColor: _headerColor.value,
            child: ListTile(
              onTap: _handleTap,
              title: widget.title,
            ),
          ),
          ClipRect(
            child: Align(
              heightFactor: _heightFactor.value,
              child: child,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void didChangeDependencies() {
    final ThemeData theme = Theme.of(context);
    _borderColorTween..end = theme.dividerColor;
    _headerColorTween
      ..begin = theme.textTheme.subtitle1?.color
      ..end = theme.accentColor;
    _iconColorTween
      ..begin = theme.unselectedWidgetColor
      ..end = theme.accentColor;
    _backgroundColorTween..end = widget.backgroundColor;
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    final bool closed = !_isExpanded && _controller.isDismissed;
    return AnimatedBuilder(
      animation: _controller.view,
      builder: _buildChildren,
      child: closed
          ? null
          : widget.listData.length > 0
              ? ListView.separated(
                  physics: NeverScrollableScrollPhysics(),
                  /*widget.listData.length <= 5
                      ? NeverScrollableScrollPhysics()
                      : NeverScrollableScrollPhysics(),*/
                  shrinkWrap: true,
                  itemCount: widget.listData.length > 10 ? 10 : widget.listData.length,
                  separatorBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: MPListItemDivider(),
                    );
                  },
                  itemBuilder: (context, index) {
                    String imgURL;
                    if (widget.key == Key('1')) {
                      imgURL =
                          'https://assets.multipie.co/images/stock_icons/${widget.listData[index].instrumentISINCode}.png';
                    } else {
                      imgURL =
                          'https://assets.multipie.co/images/amc_icons/${widget.listData[index].serviceProviderBOSCode}.png';
                    }
                    return Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0),
                          child: CachedNetworkImage(
                            imageUrl: imgURL,
                            width: 30,
                            height: 30,
                            errorWidget: (context, url, error) {
                              return Container(
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: context.appTheme.borderColor,
                                  shape: BoxShape.circle,
                                ),
                                child: Text(
                                  widget.listData[index].instrumentName[0],
                                  style: mpHeadLine4(
                                    context: context,
                                    textColor: Theme.of(context).primaryColor,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                            child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(
                            widget.listData[index].instrumentName,
                            style: mpHeadLine6(context: context),
                          ),
                        )),
                      ],
                    );
                  },
                )
              : Container(),
    );
  }
}

#import "AppDelegate.h"
#import "GeneratedPluginRegistrant.h"
//#import "CleverTap.h"
//#import "CleverTapPlugin.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
//      [CleverTap autoIntegrate]; // integrate CleverTap SDK using the autoIntegrate option
//[[CleverTapPlugin sharedInstance] applicationDidLaunchWithOptions:launchOptions];
  [GeneratedPluginRegistrant registerWithRegistry:self];
  if (@available(iOS 10.0, *)) {
  [UNUserNotificationCenter currentNotificationCenter].delegate = (id<UNUserNotificationCenterDelegate>) self;
}
  // Override point for customization after application launch.
  return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

@end

package com.vartul.multipie;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

<script lang="ts">
	import { getContext } from 'svelte';
	import { toast } from 'svelte-sonner';

	import { mobile, showSidebar, user } from '$lib/stores';

	import { slide } from 'svelte/transition';
	import { page } from '$app/stores';

	import { WEBUI_API_BASE_URL } from '$lib/constants';

	import PencilSquare from '../icons/PencilSquare.svelte';
	import Tooltip from '../common/Tooltip.svelte';
	import Sidebar from '../icons/Sidebar.svelte';
	import Hashtag from '../icons/Hashtag.svelte';
	import Lock from '../icons/Lock.svelte';
	import UserAlt from '../icons/UserAlt.svelte';
	import ChannelInfoModal from './ChannelInfoModal.svelte';
	import Users from '../icons/Users.svelte';
	import Pin from '../icons/Pin.svelte';
	import PinnedMessagesModal from './PinnedMessagesModal.svelte';
	import ChannelMenu from './ChannelMenu.svelte';

	const i18n: any = getContext('i18n');

	let showChannelPinnedMessagesModal = false;
	let showChannelInfoModal = false;

	const hasPublicReadGrant = (grants: any) =>
		Array.isArray(grants) &&
		grants.some(
			(grant) =>
				grant?.principal_type === 'user' &&
				grant?.principal_id === '*' &&
				grant?.permission === 'read'
		);

	const isPublicChannel = (channel: any): boolean => {
		if (channel?.type === 'group') {
			if (typeof channel?.is_private === 'boolean') {
				return !channel.is_private;
			}
			return hasPublicReadGrant(channel?.access_grants);
		}
		return hasPublicReadGrant(channel?.access_grants);
	};

	export let channel;
	export let readOnly = false;

	export let onPin = (messageId, pinned) => {};
	export let onUpdate = () => {};
</script>

{#if !readOnly}
	<PinnedMessagesModal bind:show={showChannelPinnedMessagesModal} {channel} {onPin} />
	<ChannelInfoModal bind:show={showChannelInfoModal} {channel} {onUpdate} />
{/if}
<nav class="sticky top-0 z-30 w-full px-3 py-1 -mb-8 flex items-center drag-region flex-col">
	<div
		id="navbar-bg-gradient-to-b"
		class=" bg-linear-to-b via-50% from-white via-white to-transparent dark:from-gray-900 dark:via-gray-900 dark:to-transparent pointer-events-none absolute inset-0 -bottom-7 z-[-1]"
	></div>

	<div class=" flex max-w-full w-full mx-auto pt-0.5 bg-transparent">
		<div class="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center w-full max-w-full">
			{#if $mobile}
				<div
					class="{$showSidebar
						? 'md:hidden'
						: ''} col-start-1 row-start-1 mr-1.5 mt-0.5 self-center flex flex-none items-center text-gray-600 dark:text-gray-400"
				>
					<Tooltip
						content={$showSidebar ? $i18n.t('Close Sidebar') : $i18n.t('Open Sidebar')}
						interactive={true}
					>
						<button
							id="sidebar-toggle-button"
							class=" cursor-pointer flex rounded-lg hover:bg-gray-100 dark:hover:bg-gray-850 transition cursor-"
							aria-label={$showSidebar ? $i18n.t('Close Sidebar') : $i18n.t('Open Sidebar')}
							on:click={() => {
								showSidebar.set(!$showSidebar);
							}}
						>
							<div class=" self-center p-1.5">
								<Sidebar className="size-4" />
							</div>
						</button>
					</Tooltip>
				</div>
			{/if}

			<div
				class="col-start-2 row-start-1 min-w-0 overflow-hidden max-w-full py-0.5 flex items-center
			{$showSidebar ? 'ml-1' : ''}
			"
			>
				{#if channel}
					<div class="flex min-w-0 items-center gap-1.5">
						{#if channel?.type === 'dm'}
							{#if channel?.users}
								{@const channelMembers = channel.users.filter((u) => u.id !== $user?.id)}
								<div class="flex shrink-0 relative">
									{#each channelMembers.slice(0, 2) as u, index}
										<img
											src={`${WEBUI_API_BASE_URL}/users/${u.id}/profile/image`}
											alt={u.name}
											class=" size-5.5 rounded-full object-cover border border-white dark:border-gray-900 {index ===
											1
												? '-ml-2'
												: ''}"
										/>
									{/each}

									{#if channelMembers.length === 1}
										<div class="absolute bottom-0 right-0">
											<span class="relative flex size-2">
												<span
													class="relative inline-flex size-2 rounded-full {channelMembers[0]
														?.is_active
														? 'bg-green-500'
														: 'bg-gray-300 dark:bg-gray-700'} border-[1.5px] border-white dark:border-gray-900"
												></span>
											</span>
										</div>
									{/if}
								</div>
							{:else}
								<Users className="size-4" strokeWidth="1.5" />
							{/if}
						{:else}
							<div class=" size-4 shrink-0 justify-center flex items-center">
								{#if isPublicChannel(channel)}
									<Hashtag className="size-4" strokeWidth="1.5" />
								{:else}
									<Lock className="size-4" strokeWidth="1.5" />
								{/if}
							</div>
						{/if}

						<div
							class=" min-w-0 truncate text-left text-sm font-medium leading-5 text-gray-700 dark:text-gray-300"
						>
							{#if channel?.name}
								{channel.name}
							{:else}
								{channel?.users
									?.filter((u) => u.id !== $user?.id)
									.map((u) => u.name)
									.join(', ')}
							{/if}
						</div>
					</div>
				{/if}
				<slot name="status" />
			</div>

			<div
				class="col-start-3 row-start-1 self-center flex flex-none items-center text-gray-600 dark:text-gray-400 gap-1 shrink-0"
			>
				<slot name="actions">
					{#if channel}
						<Tooltip content={$i18n.t('Pinned Messages')}>
							<button
								class=" flex size-7 items-center justify-center cursor-pointer rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-50/60 dark:hover:bg-gray-800/60 transition-colors"
								aria-label={$i18n.t('Pinned Messages')}
								type="button"
								on:click={() => {
									showChannelPinnedMessagesModal = true;
								}}
							>
								<div class=" flex items-center gap-1 m-auto self-center shrink-0">
									<Pin className=" size-4" strokeWidth="1.5" />
								</div>
							</button>
						</Tooltip>

						{#if channel?.user_count !== undefined}
							<Tooltip content={$i18n.t('Users')}>
								<button
									class=" flex h-7 items-center cursor-pointer shrink-0 px-1.5 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-50/60 dark:hover:bg-gray-800/60 transition-colors"
									type="button"
									on:click={() => {
										showChannelInfoModal = true;
									}}
								>
									<div class=" flex items-center gap-1 m-auto self-center shrink-0">
										<UserAlt className=" size-4" strokeWidth="1.5" />

										<span class="sr-only">{$i18n.t('User Count')}</span>
										<div class="text-xs tabular-nums shrink-0">
											{channel.user_count}
										</div>
									</div>
								</button>
							</Tooltip>
						{/if}
						<ChannelMenu {channel} />
					{/if}
				</slot>
			</div>
			{#if $$slots.subtitle}
				<div class="col-start-2 row-start-2 min-w-0 {$showSidebar ? 'ml-1' : ''}">
					<slot name="subtitle" />
				</div>
			{/if}
		</div>
	</div>
</nav>

<script lang="ts">
	import { resolveLocalizedResource } from '$lib/utils/localizedContent';
	import { toast } from 'svelte-sonner';

	import { config, functions, models, settings, tools, user } from '$lib/stores';
	import { createEventDispatcher, onMount, getContext, tick } from 'svelte';

	import {
		getUserValvesSpecById as getToolUserValvesSpecById,
		getUserValvesById as getToolUserValvesById,
		updateUserValvesById as updateToolUserValvesById,
		getTools
	} from '$lib/apis/tools';
	import {
		getUserValvesSpecById as getFunctionUserValvesSpecById,
		getUserValvesById as getFunctionUserValvesById,
		updateUserValvesById as updateFunctionUserValvesById,
		getFunctions
	} from '$lib/apis/functions';

	import Tooltip from '$lib/components/common/Tooltip.svelte';
	import Spinner from '$lib/components/common/Spinner.svelte';
	import Valves from '$lib/components/common/Valves.svelte';

	const dispatch = createEventDispatcher();

	const i18n = getContext('i18n');

	export let show = false;

	let tab = $config?.features?.enable_tools ? 'tools' : 'functions';
	let selectedId = '';

	let loading = false;

	let valvesSpec = null;
	let valves = {};

	let debounceTimer;

	const debounceSubmitHandler = async () => {
		if (debounceTimer) {
			clearTimeout(debounceTimer);
		}

		// Set a new timer
		debounceTimer = setTimeout(() => {
			submitHandler();
		}, 500); // 0.5 second debounce
	};

	const getUserValves = async () => {
		loading = true;
		if (tab === 'tools') {
			valves = await getToolUserValvesById(localStorage.token, selectedId);
			valvesSpec = await getToolUserValvesSpecById(localStorage.token, selectedId);
		} else if (tab === 'functions') {
			valves = await getFunctionUserValvesById(localStorage.token, selectedId);
			valvesSpec = await getFunctionUserValvesSpecById(localStorage.token, selectedId);
		}

		if (valvesSpec) {
			// Convert array to string
			for (const property in valvesSpec.properties) {
				if (valvesSpec.properties[property]?.type === 'array') {
					if (valvesSpec.properties[property]?.input?.type === 'multiselect') {
						continue;
					}
					if (valves[property] != null) {
						valves[property] = (Array.isArray(valves[property]) ? valves[property] : []).join(',');
					} else {
						valves[property] = null;
					}
				}
			}
		}

		loading = false;
	};

	const submitHandler = async () => {
		if (valvesSpec) {
			// Convert string to array
			for (const property in valvesSpec.properties) {
				if (valvesSpec.properties[property]?.type === 'array') {
					if (typeof valves[property] === 'string') {
						valves[property] = (valves[property] ?? '')
							.split(',')
							.map((v) => v.trim())
							.filter((v) => v.length > 0);
					} else if (valves[property] == null) {
						valves[property] = null;
					}
				}
			}

			if (tab === 'tools') {
				const res = await updateToolUserValvesById(localStorage.token, selectedId, valves).catch(
					(error) => {
						toast.error(`${error}`);
						return null;
					}
				);

				if (res) {
					toast.success($i18n.t('Valves updated'));
					valves = res;
				}
			} else if (tab === 'functions') {
				const res = await updateFunctionUserValvesById(
					localStorage.token,
					selectedId,
					valves
				).catch((error) => {
					toast.error(`${error}`);
					return null;
				});

				if (res) {
					toast.success($i18n.t('Valves updated'));
					valves = res;
				}
			}
		}
	};

	$: if (tab) {
		selectedId = '';
	}

	$: if (selectedId) {
		getUserValves();
	}

	$: if (show) {
		init();
	}

	const init = async () => {
		loading = true;

		if ($functions === null) {
			functions.set(await getFunctions(localStorage.token));
		}
		if ($tools === null) {
			tools.set(await getTools(localStorage.token));
		}

		loading = false;
	};
</script>

{#if show && !loading}
	<form
		class="flex flex-col h-full justify-between space-y-2 text-xs"
		on:submit|preventDefault={() => {
			submitHandler();
			dispatch('save');
		}}
	>
		<div class="flex flex-col">
			<div class="space-y-1">
				<div class="flex gap-2">
					<div class="flex-1">
						<select
							class="w-full rounded-sm py-1 px-1 text-xs bg-transparent outline-hidden"
							bind:value={tab}
							placeholder={$i18n.t('Select')}
						>
							{#if $config?.features?.enable_tools}
								<option value="tools" class="bg-gray-100 dark:bg-gray-800"
									>{$i18n.t('Tools')}</option
								>
							{/if}
							{#if $config?.features?.enable_functions}
								<option value="functions" class="bg-gray-100 dark:bg-gray-800"
									>{$i18n.t('Functions')}</option
								>
							{/if}
						</select>
					</div>

					<div class="flex-1">
						<select
							class="w-full rounded-sm py-1 px-1 text-xs bg-transparent outline-hidden"
							bind:value={selectedId}
							on:change={async () => {
								await tick();
							}}
						>
							{#if tab === 'tools'}
								<option value="" selected disabled class="bg-gray-100 dark:bg-gray-800"
									>{$i18n.t('Select a tool')}</option
								>

								{#each $tools
									.filter((tool) => !tool?.id?.startsWith('server:'))
									.sort((a, b) => (a.name ?? '').localeCompare(b.name ?? '')) as tool, toolIdx}
									<option value={tool.id} class="bg-gray-100 dark:bg-gray-800"
										>{resolveLocalizedResource(tool, $i18n.language)}</option
									>
								{/each}
							{:else if tab === 'functions'}
								<option value="" selected disabled class="bg-gray-100 dark:bg-gray-800"
									>{$i18n.t('Select a function')}</option
								>

								{#each $functions.sort( (a, b) => (a.name ?? '').localeCompare(b.name ?? '') ) as func, funcIdx}
									<option value={func.id} class="bg-gray-100 dark:bg-gray-800"
										>{resolveLocalizedResource(func, $i18n.language)}</option
									>
								{/each}
							{/if}
						</select>
					</div>
				</div>
			</div>

			{#if selectedId}
				<div class="my-1 text-xs">
					{#if !loading}
						<div class="chat-control-valves">
							<Valves
								{valvesSpec}
								meta={(tab === 'tools' ? $tools : $functions)?.find(
									(item) => item.id === selectedId
								)?.meta}
								userValves
								bind:valves
								on:change={() => {
									debounceSubmitHandler();
								}}
							/>
						</div>
					{:else}
						<Spinner className="size-5" />
					{/if}
				</div>
			{/if}
		</div>
	</form>
{:else}
	<Spinner className="size-4" />
{/if}

<style>
	.chat-control-valves :global(input),
	.chat-control-valves :global(select),
	.chat-control-valves :global(textarea) {
		font-size: 0.75rem;
		line-height: 1rem;
	}
</style>

package config

import (
	"bytes"
	"embed"
	"fmt"
	"github.com/spf13/viper"
	"log"
	"multipie_ilearn_go/internal/utils"
	"time"
)

//go:embed credentials/*
var embeddedFiles embed.FS

func getEncryptedCreds(env string) ([]byte, error) {
	fileName := fmt.Sprintf("credentials/%s.yaml.enc", env)
	return embeddedFiles.ReadFile(fileName)
}

var AppConfigs *EnvConfig
var AppSecrets *SecretConfig

// EnvConfig holds data from the .env file
type EnvConfig struct {
	AppEnv          string `mapstructure:"APP_ENV"`
	SecretsFilePath string `mapstructure:"SECRETS_FILE_PATH"`
	KeyName         string `mapstructure:"KEY_NAME"`
	KeyPath         string `mapstructure:"KEY_PATH"`
	Timezone        string `mapstructure:"TIMEZONE"`
}

// SecretConfig holds data from the config/secrets.yaml file
type SecretConfig struct {
	HTTP              HTTPConfig        `mapstructure:"http"`
	Log               LogConfig         `mapstructure:"log"`
	MultipieILearnDb  MySqlConfig       `mapstructure:"mysql_config"`
	SecurityKeys      SecurityKeys      `mapstructure:"security_keys"`
	Redis             RedisConfig       `mapstructure:"redis"`
	Aws               AwsCredentials    `mapstructure:"aws"`
	IlearnOauthClient OauthClient       `mapstructure:"oauth"`
	QueueWorker       QueueWorkerConfig `mapstructure:"queue_worker_config"`
}

type HTTPConfig struct {
	Host               string        `mapstructure:"host"`
	Port               string        `mapstructure:"port"`
	ReadTimeout        time.Duration `mapstructure:"readTimeout"`
	WriteTimeout       time.Duration `mapstructure:"writeTimeout"`
	MaxHeaderMegabytes int           `mapstructure:"maxHeaderBytes"`
}

type LogConfig struct {
	Level    string `mapstructure:"level"`
	Location string `mapstructure:"location"`
}

type MySqlConfig struct {
	Host              string `mapstructure:"host"`
	Port              string `mapstructure:"port"`
	Username          string `mapstructure:"username"`
	Password          string `mapstructure:"password"`
	Database          string `mapstructure:"database"`
	ConnectionTimeout int    `mapstructure:"connection_timeout"`
}

type SecurityKeys struct {
	AesPrivateKey string `mapstructure:"aes_private_key"`
	Key           string `mapstructure:"key"`
	IV            string `mapstructure:"iv"`
}

type RedisConfig struct {
	Host string `mapstructure:"host"`
	Port string `mapstructure:"port"`
}

type AwsCredentials struct {
	AccessKey       string `mapstructure:"access_key"`
	SecretAccessKey string `mapstructure:"secret_key"`
	Region          string `mapstructure:"region"`
}

type OauthClient struct {
	ClientId     string `mapstructure:"client_id"`
	ClientSecret string `mapstructure:"client_secret"`
	Scope        string `mapstructure:"scope"`
	AuthUrl      string `mapstructure:"auth_url"`
}

type QueueWorkerConfig struct {
	StatsQueueWorker int `mapstructure:"stats_queue_worker"`
}

// LoadEnv reads the .env file from the root directory
func LoadEnv() {
	v := viper.New()
	v.SetConfigFile(".env")
	v.AutomaticEnv()

	if err := v.ReadInConfig(); err != nil {
		fmt.Errorf("failed to read .env: %w", err)
	}

	var envCfg EnvConfig
	if err := v.Unmarshal(&envCfg); err != nil {
		fmt.Errorf("failed to unmarshal .env: %w", err)
	}

	AppConfigs = &envCfg

	if AppConfigs.AppEnv == "local" {
		AppConfigs.KeyPath = "encryptionUtil"
	}
}

// LoadSecrets reads the YAML file dynamically using the path provided
func LoadSecrets() {

	v1 := viper.New()

	v1.SetConfigType("yaml")

	encryptedConfig, err := getEncryptedCreds(AppConfigs.AppEnv)
	if err != nil {
		log.Fatalf("Failed to read config with Viper: %v", err)
	}

	data := utils.DecryptSecrets(AppConfigs.KeyPath, AppConfigs.KeyName, encryptedConfig)

	if err := v1.ReadConfig(bytes.NewBuffer([]byte(data))); err != nil {
		log.Printf("failed to read secrets file: %w", err)
	}

	var secrets SecretConfig

	if err := v1.Unmarshal(&secrets); err != nil {
		log.Printf("failed to unmarshal secrets: %w", err)
	}

	AppSecrets = &secrets
}

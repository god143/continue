package security

import (
	"github.com/gin-gonic/gin"
)

// SecurityHeadersMiddleware injects standard security headers into every response
func SecurityHeadersMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 1. Content-Security-Policy (CSP)
		// Restricts where resources (scripts, styles, images) can be loaded from.
		c.Header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'self';")

		// 2. Referrer-Policy
		// Controls how much referrer info is leaked when navigating off-site.
		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")

		// 3. X-XSS-Protection
		// Note: Modern browsers rely on CSP, but "0" explicitly disables unsafe legacy browser filters.
		c.Header("X-XSS-Protection", "0")

		// 4. Strict-Transport-Security (HSTS)
		// Forces the browser to communicate exclusively over HTTPS for the next 1 year (in seconds).
		c.Header("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload")

		// 5. X-Frame-Options
		// Protects against clickjacking by preventing the page from being rendered in an <iframe_>.
		c.Header("X-Frame-Options", "DENY")

		// 6. X-Content-Type-Options
		// Prevents the browser from MIME-sniffing away from the declared Content-Type.
		c.Header("X-Content-Type-Options", "nosniff")

		// Continue processing the request chain
		c.Next()
	}
}

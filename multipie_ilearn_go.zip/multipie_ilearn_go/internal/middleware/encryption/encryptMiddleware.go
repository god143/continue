package encryption

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"fmt"

	"github.com/gin-gonic/gin"
)

type responseWriter struct {
	gin.ResponseWriter
	body *bytes.Buffer
}

func (w *responseWriter) Write(b []byte) (int, error) {
	return w.body.Write(b)
}

func encrypt(data []byte, key, iv []byte) (string, error) {
	// AES-256 requires 32-byte key
	if len(key) != 32 {
		return "", fmt.Errorf("encryption key must be 32 bytes")
	}

	// Your existing GCM specification uses 16-byte IV
	if len(iv) != 16 {
		return "", fmt.Errorf("encryption IV must be 16 bytes")
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	gcm, err := cipher.NewGCMWithNonceSize(block, 16)
	if err != nil {
		return "", err
	}

	// Encrypt
	ciphertext := gcm.Seal(nil, iv, data, nil)

	// Base64 encode
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func DecryptResponse(encrypted string, key, iv []byte) ([]byte, error) {
	// AES-256 = 32-byte key
	if len(key) != 32 {
		return nil, fmt.Errorf("AES-256 key must be 32 bytes")
	}

	// GCM normally uses a 12-byte nonce
	if len(iv) != 16 {
		return nil, fmt.Errorf("GCM nonce/IV must be 16 bytes")
	}

	cipherText, err := base64.StdEncoding.DecodeString(encrypted)
	if err != nil {
		return nil, err
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCMWithNonceSize(block, 16)
	if err != nil {
		return nil, err
	}

	// Encrypt
	plaintext, err := gcm.Open(nil, iv, cipherText, nil)
	if err != nil {
		return nil, fmt.Errorf("decryption failed: %w", nil)
	}

	// Convert to Base64
	return plaintext, nil
}

func EncryptResponse(key, iv []byte) gin.HandlerFunc {
	return func(c *gin.Context) {

		// Capture response
		writer := &responseWriter{
			ResponseWriter: c.Writer,
			body:           bytes.NewBuffer(nil),
		}

		c.Writer = writer

		// Execute actual handler
		c.Next()

		// Get original response
		responseBody := writer.body.Bytes()

		// Nothing to encrypt
		if len(responseBody) == 0 {
			return
		}

		// Encrypt response
		encrypted, err := encrypt(responseBody, key, iv)
		if err != nil {
			c.Writer = writer.ResponseWriter

			c.AbortWithStatusJSON(500, gin.H{
				"error": "failed to encrypt response",
			})
			return
		}

		// Restore original writer
		c.Writer = writer.ResponseWriter

		// Return encrypted response
		c.Header("Content-Type", "application/json")

		c.JSON(writer.Status(), encrypted)
		// c.Data(writer.Status(), "text/plain; charset=utf-8", []byte(encrypted))		// uncomment this for removing double quotes
	}
}

package auth

import (
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"go.uber.org/zap"
)

/*
AuthMiddleware...
 1. Fetch access_token from header
 2. verify access token
 3. Fectch User details from oauth-server i.e. multipie-auth
 4. Set current userId, requestId and role in context
*/
func AuthMiddleware(dbLayer db.DBLayer) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		skipStatusCheck := ctx.FullPath() == "/admin/api/v1/users/status"
		err := authMiddlewareHelper(ctx, dbLayer, skipStatusCheck)
		if err != nil {
			resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
			ctx.JSON(http.StatusUnauthorized, resp)
			ctx.Abort()
			return
		}

		ctx.Next()
	}
}

func authMiddlewareHelper(ctx *gin.Context, dbLayer db.DBLayer, skipStatusCheck bool) error {
	// requestId := ctx.Request.Header.Get("Request-Id")

	authHeader := ctx.GetHeader("Authorization")
	if authHeader == "" {
		logger.Error(ctx, "authorization header missing")
		return fmt.Errorf("authorization header missing")
	}

	parts := strings.SplitN(authHeader, " ", 2)
	if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
		logger.Error(ctx, "invalid auth token")
		return fmt.Errorf("invalid auth token")
	}
	accessToken := strings.TrimSpace(parts[1])
	authToken, err := dbLayer.GetToken(ctx, accessToken)
	if err != nil {
		logger.Error(ctx, "invalid auth token", zap.Error(err))
		return err
	}

	if authToken.RevokedAt != nil {
		logger.Error(ctx, "auth token revoked")
		return fmt.Errorf("auth token revoked")
	}

	if time.Now().After(authToken.ExpiresAt) {
		logger.Error(ctx, "auth token expired")
		return fmt.Errorf("auth token expired")
	}

	user, err := dbLayer.GetUserByUID(ctx, int64(authToken.UserId))
	if err != nil {
		logger.Error(ctx, "user not found", zap.Error(err))
		return err
	}

	status := constants.UserStatusEnumActive

	if user.Status == nil {
		logger.Error(ctx, "status not found")
		return fmt.Errorf("status not found")
	}

	if !skipStatusCheck {
		if *user.Status != status {
			logger.Error(ctx, "user is not active")
			return fmt.Errorf("user is not active")
		}
	}

	requestId := ctx.GetHeader("Request-Id")
	if strings.TrimSpace(requestId) == "" {
		requestId = uuid.NewString()
	}

	ctx.Set("userId", *user.ID)
	ctx.Set("requestId", requestId)
	ctx.Set("role", user.Role)
	ctx.Set("username", user.Username)
	ctx.Next()
	return nil
}

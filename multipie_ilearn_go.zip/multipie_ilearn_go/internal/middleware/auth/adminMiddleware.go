package auth

import (
	"errors"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

/*
Admin middleware fetches user role from DB using uid
*/
func AdminMiddleware() gin.HandlerFunc {

	return func(ctx *gin.Context) {
		if err := adminMiddlewareHelper(ctx); err != nil {
			resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
			ctx.JSON(http.StatusUnauthorized, resp)
			ctx.Abort()
			return
		}
		ctx.Next()
	}
}

/*
adminMiddlewareHelper.....Helper function to check admin access
*/
func adminMiddlewareHelper(ctx *gin.Context) error {
	role, exits := ctx.Get("role")
	if !exits {
		logger.Error(ctx, "unable to retrive role from auth token")
		return errors.New("unable to retrive role from auth token")
	}

	requestedPath := ctx.Request.URL.Path
	if strings.HasPrefix(requestedPath, constants.ADMIN_ROUTE_PREFIX) && role != constants.UserRoleEnumAdmin.String() {
		logger.Error(ctx, "access denied, only admin is user is allowed to access admin route")
		return errors.New("access denied")
	}

	return nil
}

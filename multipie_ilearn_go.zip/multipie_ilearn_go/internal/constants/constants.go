//go:generate go-enum --marshal --flag --sql
package constants

import (
	"os"
	"path/filepath"
)

const (
	ENV_DEV            = "dev"
	ENV_PROD           = "prod"
	ENV_LOCAL          = "local"
	MOBILE_PHONE_REGEX = `^([1-9]{1}\d{0,5} ){0,1}[1-9]\d{4,13}$`
	EMAIL_ID_REGEX     = `/\S+@\S+\.\S+/`
	MAXINVALIDATTEMPTS = 10
	MAXRESENDOTP       = 5

	MULTIPIE_AUTH_URL = "https://test-auth.multipie.co"

	API_ICICI_DIRECT_URL     = "https://api.icicidirect.com"
	EMAIL_OTP_URL            = "http://localhost:8081"
	EMAIL_OTP_URL_BK         = "https://isec-cms.iseccorp.in"
	MULTIPIE_MY_HOLDINGS_URL = "https://ilearn.icicidirect.com/api/v2/my_holdings?instrument_type=stock"
	IDIRECT_NEWS_URL         = "https://www.icicidirect.com/mobileapi/getarticlesbybucketid"
	ILEARN_AUTH_URL          = "https://auth.multipie.co"
	ILEARN_DOMAIN            = "https://api-ilearn.icicidirect.com"
	IDIRECT_NEWS_BUCKET_ID   = "3188"
	IDIRECT_AUTH_TOKEN       = "SUNJQ0lkOmFiYzEyMw=="
	AWS_S3_ASSETS_BUCKET     = "ilearn-app"
	// AWS_S3_ASSETS_BUCKET     = "ilearn-bucket"
	AXIOM_BASE_URL = "http://iaxiommessaging-app.iseccorp.in:8181/publisher/http6listener"
	// AXIOM_BASE_URL = "http://10.221.180.103:8181/publisher/http6listener"
	DCODE  = "ISECRISK"
	SubUID = "ISECRISK"
	Pwd    = "PNdMQb3gYbbuz2wEbbkMPA=="
	// DCODE   = "TestRisk"
	// SubUID  = "TestRisk"
	// Pwd     = "xGcmmbbSt63UarjB6sQ2tQ=="
	From    = "ISECLT"
	IntFlag = "1"
	MsgType = "S"
	OTPFlag = "1"
	CType   = "1"
	LangID  = "en"

	IDIRECT_TOP_PERFORMER_URL         = "https://idirect-aws.iseccorp.in/ILearnAPI/GetEquityFundlisting"
	IDIRECT_TOP_PERFORMER_FILTERS_URL = "https://idirect-aws.iseccorp.in/ILearnAPI/GetTopPerformerListHeading"

	IDIRECT_GET_SCHEME_INFO_URL       = "https://idirect-aws.iseccorp.in/NonLoginAPI/GetSchemeInfo"
	IDIRECT_GET_PERFORMANCE_URL       = "https://idirect-aws.iseccorp.in/NonLoginAPI/GetPeriodReturn"
	IDIRECT_GET_TOP_HOLDINGS_URL      = "https://idirect-aws.iseccorp.in/NonLoginAPI/GetMfTopHolding"
	IDIRECT_GET_SECTOR_ALLOCATION_URL = "https://idirect-aws.iseccorp.in/NonLoginAPI/GetMfSectorAllocationDetail"
	IDIRECT_GET_PEER_COMPARISON_URL   = "https://idirect-aws.iseccorp.in/NonLoginAPI/GetMFPeerComparisionListing"

	IDIRECT_MF_TERM                          = "S"
	IDIRECT_ORGANIZATIONTYPE                 = "CIRSIL"
	IDIRECT_TOKEN_MUTUAL_FUNDS               = "GRFz2IMMYRoScBAcj7Kf0w=="
	IDIRECT_TOKEN_TOP_PERFORMER_MUTUAL_FUNDS = "FwMrL1fAkBxN2synLaQrdHOsRv9UHGZcq/3ripeUImA="

	STATS_QUEUE                    = "stats_queue"
	STATS_GROUP                    = "stats_group"
	STATS_MODEL_COURSE             = "course"
	STATS_MODEL_COURSE_MODULES     = "course_module"
	STATS_MODEL_INFOGRAPHIC        = "infographic"
	STATS_MODEL_RESOURCE           = "resource"
	STATS_MODEL_COMMENT            = "comment"
	MODEL_TYPE_QUIZ                = "quiz"
	MODEL_TYPE_COURSE              = "course"
	MODEL_TYPE_CERTIFICATE         = "certificate"
	CONTENT_TYPE_IMAGE             = "image/png"
	SERVICE_NAME_S3                = "S3"
	SERVICE_NAME_LOCAL             = "LOCAL"
	STATS_MODEL_SECONDARY_RESOURCE = "secondary_resource"
	STATUS_IN_PROGRESS             = "in-progress"
	QUIZ_ATTEMPT_PASS              = "pass"
	QUIZ_ATTEMPT_FAIL              = "fail"
	MODEL_TYPE_VIDEO               = "video"

	STATS_ACTION_LIKE   = "like"
	STATS_ACTION_UNLIKE = "unlike"
	STATS_ACTION_VIEW   = "view"

	ADMIN_ROUTE_PREFIX = "/admin"

	FILE_TYPE_EXTENSION_PDF = "application/pdf"

	FILE_SIZE_LIMIT = 50 * 1024 * 1024

	ErrHUFLoginRequired  = "HUF_LOGIN_REQUIRED"
	ErrMultipleAccounts  = "MULTIPLE_ACCOUNTS_FOUND"
	AUTH_SIGNUP_ENDPOINT = "/api/v2/signup_with_mobile"
	API_KEY              = "6R7M98o02tm9c5p3s3xCp17654#T5_85"
	API_SECRET           = "3Vg1Hzvl4_364087H25R968e4*33mu83"
)

var (
	BaseDir, _                           = os.Getwd()
	SUPER_STAR_CERTIFICATE_TEMPLATE_PATH = filepath.Join(BaseDir, "assets/templates/Certificate_Superstar.jpg")
	STAR_CERTIFICATE_TEMPLATE_PATH       = filepath.Join(BaseDir, "assets/templates/Certificate_Star.jpg")
	COURSE_CERTIFICATE_TEMPLATE_PATH     = filepath.Join(BaseDir, "assets/templates/Certificate_Module.jpg")
	CERTIFICATE_OUTPUT_PATH              = filepath.Join(BaseDir, "output/")
	FONT_PATH                            = filepath.Join(BaseDir, "assets/templates/fonts/Mulish-Black.ttf")
)

// ENUM(video, podcast, article, expert, learn)
type RelatedResourcesTagEnum int64

// ENUM(courses, videos, podcasts, articles, infographics, learn, expert)
type CategoryTypeEnum int64

// ENUM(mobile, idirect)
type Vialogin string

// ENUM(video, article)
type CourseFormatEnum int64

// ENUM(beginner, intermediate, advanced)
type CourseDiffcultyEnum int64

// ENUM(video, article)
type CourseModuleContentTypeEnum int64

// ENUM(chapter, quiz, certificate)
type CourseModuleTypeEnum int64

// ENUM(started, in-progress, completed)
type EnrollmentStatusEnum int64

// ENUM(mcq, boolean, graph, image_based)
type QuestionTypeEnum int64

// ENUM(video, article, podcast)
type ResourceTypeEnum int64

// ENUM(active, inactive, blocked)
type UserStatusEnum int64

// ENUM(admin, user)
type UserRoleEnum int64

// ENUM(beginner, intermediate, advanced)
type QuizDiffcultyEnum int64

// ENUM(pass, fail)
type QuizAttemptsStatusEnum int64

// ENUM(course, course_module, video, podcast, article, infographic)
type BookmarkModelTypeEnum int64

// ENUM(viewed, in-progress, completed)
type ActivityStatusEnum int64

// ENUM(course_module, course, resource)
type ActivityModelTypeEnum int64

// ENUM(resource, infographics, course_module,secondary_resource)
type CommentsModelTypeEnum int64

// ENUM(trending)
type FilterTypeEnum string

// ENUM(expert, learn)
type AuxiliaryType string

// ENUM(primary, expert, learn)
type SubTypeEnum string

// ENUM(primary, expert, learn)
type BookmarkSubTypeEnum int64

// ENUM(primary, expert, learn)
type TagMappingSubTypeEnum string

package awsUtil

import (
	"fmt"
	"sync"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
)

type awsUtils struct {
	awsSession *session.Session
	once       sync.Once
}

func GetAwsUtils(awsAccessKey, awsSecretAccessKey, awsBucketRegion string) (*session.Session, error) {
	utils := &awsUtils{}
	var err error

	utils.once.Do(func() {
		// Ensure the credentials are being passed correctly
		if awsAccessKey == "" || awsSecretAccessKey == "" {
			err = fmt.Errorf("AWS credentials are empty")
			return
		}

		utils.awsSession, err = session.NewSession(&aws.Config{
			Region:      aws.String(awsBucketRegion),
			Credentials: credentials.NewStaticCredentials(awsAccessKey, awsSecretAccessKey, ""),
		})

		// Log the outcome of session creation
		if err != nil {
			fmt.Println("Failed to create AWS session:", err)
		} else {
			fmt.Println("AWS session created successfully for the first time")
		}
	})

	if err != nil {
		// Log the error if session creation failed
		return nil, fmt.Errorf("error creating AWS session: %v", err)
	}
	return utils.awsSession, nil
}

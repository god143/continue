package awsUtil

import (
	"bytes"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net/http"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"golang.org/x/net/http2"
)

func S3Upload(session *session.Session, fileReader io.Reader, filekey, awsBucketName string) (string, error) {
	uploader := s3manager.NewUploader(session)

	output, err := uploader.Upload(
		&s3manager.UploadInput{
			Bucket: aws.String(awsBucketName),
			Body:   fileReader,
			Key:    aws.String(filekey),
			// ContentLength: 	aws.Int64(originalFileSizeInBytes),		//added for content length mismatch
		},
	)

	if err != nil {

		return "", err
	}
	return output.Location, nil
}

func S3Download(sess *session.Session, filekey, awsBucketName string) ([]byte, error) {
	// 1. Force HTTP/2 on the underlying HTTP Client config
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{
			// Optional: Specify TLS 1.2 minimum if required by your security policy
			MinVersion: tls.VersionTLS12,
		},
		DisableCompression: true,
	}

	// Explicitly configure transport for HTTP/2
	if err := http2.ConfigureTransport(tr); err != nil {
		return nil, fmt.Errorf("failed to configure HTTP/2 transport: %w", err)
	}

	httpClient := &http.Client{Transport: tr}

	// 2. Create the S3 client utilizing the HTTP/2 client overrides
	svc := s3.New(sess, aws.NewConfig().WithHTTPClient(httpClient))

	req := &s3.GetObjectInput{
		Bucket: aws.String(awsBucketName),
		Key:    aws.String(filekey),
	}

	// 3. Execute the S3 API Call
	resp, err := svc.GetObject(req)
	if err != nil {
		// 4. Exhaustive AWS SDK error unpacking
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			case s3.ErrCodeNoSuchBucket:
				return nil, fmt.Errorf("bucket %s does not exist: %w", awsBucketName, aerr)
			case s3.ErrCodeNoSuchKey:
				return nil, fmt.Errorf("file key %s not found in bucket: %w", filekey, aerr)
			case "InvalidAccessKeyId", "SignatureDoesNotMatch":
				return nil, fmt.Errorf("AWS credential mismatch or authentication failed: %w", aerr)
			case "AccessDenied":
				return nil, fmt.Errorf("insufficient permissions to access this object: %w", aerr)
			default:
				// Fallback for general AWS errors (throttling, internal server errors, etc.)
				return nil, fmt.Errorf("AWS SDK error [Code: %s]: %s", aerr.Code(), aerr.Message())
			}
		}
		// Non-AWS network/system errors
		return nil, fmt.Errorf("network or connection error talking to S3: %w", err)
	}
	defer resp.Body.Close()

	// Guard against nil pointer safely before reading
	if resp.ContentLength != nil {
		fmt.Println("resp length----->", *resp.ContentLength)
	}

	// 5. Read the body payload with stream error handling
	fileContent, err := io.ReadAll(resp.Body)
	if err != nil {
		// Detect premature stream closures (common in network blips or bad HTTP/2 frames)
		if errors.Is(err, io.ErrUnexpectedEOF) || errors.Is(err, io.EOF) {
			return nil, fmt.Errorf("s3 download stream interrupted unexpectedly: %w", err)
		}
		return nil, fmt.Errorf("unable to read file payload: %w", err)
	}

	// Return the file content as a byte slice
	return fileContent, nil
}

func (a *awsUtils) AwsS3MultipartUpload(session *session.Session, filekey string, filesize int64, fileReader io.Reader, awsBucketName string) (string, error) {
	var (
		filepath        string
		multipartOutput *s3.CreateMultipartUploadOutput
		err             error
	)
	const (
		maxPartSize = int64(1 * 1024 * 1024)
	)

	// conf := config.GetConfig()

	buffer := make([]byte, filesize)
	fileType := http.DetectContentType(buffer)

	s3Client := s3.New(session)

	multipartUploadInput := &s3.CreateMultipartUploadInput{
		Bucket:      aws.String(awsBucketName),
		Key:         aws.String(filekey),
		ContentType: aws.String(fileType),
	}

	if multipartOutput, err = s3Client.CreateMultipartUpload(multipartUploadInput); err != nil {
		return filepath, err
	}

	var curr, partLength int64
	var remaining = filesize
	var completedParts []*s3.CompletedPart
	partNumber := 1

	for curr = 0; remaining != 0; curr += partLength {
		if remaining < maxPartSize {
			partLength = remaining
		} else {
			partLength = maxPartSize
		}
		completedPart, err := multipartUploadPart(s3Client, multipartOutput, buffer[curr:curr+partLength], partNumber)
		if err != nil {
			err := abortMultipartUpload(s3Client, multipartOutput)
			return filepath, err
		}
		remaining -= partLength
		partNumber++
		completedParts = append(completedParts, completedPart)
	}

	completeResponse, err := completeMultipartUpload(s3Client, multipartOutput, completedParts)
	if err != nil {
		return filepath, err
	}

	return *completeResponse.Location, err
}

func multipartUploadPart(s3Client *s3.S3, multipartOutput *s3.CreateMultipartUploadOutput, fileBytes []byte, partNumber int) (*s3.CompletedPart, error) {
	const maxRetries = 3
	tryNum := 1

	partInput := &s3.UploadPartInput{
		Body:          bytes.NewReader(fileBytes),
		Bucket:        multipartOutput.Bucket,
		Key:           multipartOutput.Key,
		PartNumber:    aws.Int64(int64(partNumber)),
		UploadId:      multipartOutput.UploadId,
		ContentLength: aws.Int64(int64(len(fileBytes))),
	}

	for tryNum <= maxRetries {
		uploadResult, err := s3Client.UploadPart(partInput)
		if err != nil {
			if tryNum == maxRetries {
				if aerr, ok := err.(awserr.Error); ok {
					return nil, aerr
				}
				return nil, err
			}
			tryNum++
		} else {
			return &s3.CompletedPart{
				ETag:       uploadResult.ETag,
				PartNumber: aws.Int64(int64(partNumber)),
			}, nil
		}
	}
	return nil, nil
}

func completeMultipartUpload(s3Client *s3.S3, resp *s3.CreateMultipartUploadOutput, completedParts []*s3.CompletedPart) (*s3.CompleteMultipartUploadOutput, error) {
	completeInput := &s3.CompleteMultipartUploadInput{
		Bucket:   resp.Bucket,
		Key:      resp.Key,
		UploadId: resp.UploadId,
		MultipartUpload: &s3.CompletedMultipartUpload{
			Parts: completedParts,
		},
	}
	return s3Client.CompleteMultipartUpload(completeInput)
}

func abortMultipartUpload(s3Client *s3.S3, resp *s3.CreateMultipartUploadOutput) error {
	abortInput := &s3.AbortMultipartUploadInput{
		Bucket:   resp.Bucket,
		Key:      resp.Key,
		UploadId: resp.UploadId,
	}
	_, err := s3Client.AbortMultipartUpload(abortInput)
	return err
}

package utils

import (
	"context"
	"crypto/tls"
	"time"

	"github.com/go-resty/resty/v2"
)

type HttpClient struct {
	client *resty.Client
}

type HttpResponse struct {
	Status     int         `json:"status"`
	Data       interface{} `json:"data,omitempty"`
	Error      string      `json:"error,omitempty"`
	RequestId  string      `json:"request_id,omitempty"`
	StatusText string      `json:"status_text,omitempty"`
}

type ClientConfig struct {
	Timeout       time.Duration
	RetryCount    int
	RetryWaitTime time.Duration
	SkipTls       bool
	BaseUrl       string
}

func NewHttpClient(config ClientConfig) *HttpClient {
	client := resty.New()

	// set default timeout, if not ptovided
	if config.Timeout == 0 {
		config.Timeout = 30 * time.Second
	}

	//configure client
	client.SetTimeout(config.Timeout).
		SetRetryCount(config.RetryCount).
		SetRetryWaitTime(config.RetryWaitTime).
		SetBaseURL(config.BaseUrl)

	//skip tls verfication if required
	if config.SkipTls {
		client.SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true})
	}

	//set default headers
	client.SetHeaders(map[string]string{
		"Content-Type": "application/json",
		"Accept":       "application/json",
	})

	return &HttpClient{
		client: client,
	}
}

// Get makes a get call
func (h *HttpClient) Get(ctx context.Context, url string, queryParams map[string]string) (*HttpResponse, error) {
	response, err := h.client.R().
		SetContext(ctx).
		SetQueryParams(queryParams).
		Get(url)

	if err != nil {
		return nil, err
	}

	return &HttpResponse{
		Status:     response.StatusCode(),
		Data:       response.Body(),
		StatusText: response.Status(),
	}, nil
}

func (h *HttpClient) Post(ctx context.Context, url string, body interface{}) (*HttpResponse, error) {
	response, err := h.client.R().
		SetContext(ctx).
		SetBody(body).
		Post(url)

	if err != nil {
		return nil, err
	}

	return &HttpResponse{
		Status:     response.StatusCode(),
		Data:       response.Body(),
		StatusText: response.Status(),
	}, nil
}

func (h *HttpClient) Put(ctx context.Context, url string, body interface{}) (*HttpResponse, error) {
	response, err := h.client.R().
		SetContext(ctx).
		SetBody(body).
		Put(url)

	if err != nil {
		return nil, err
	}

	return &HttpResponse{
		Status:     response.StatusCode(),
		Data:       response.Body(),
		StatusText: response.Status(),
	}, nil
}

func (h *HttpClient) SetAuthToken(token string) {
	h.client.SetAuthToken(token)
}

func (h *HttpClient) SetHeader(key, value string) {
	h.client.SetHeader(key, value)
}

func (h *HttpClient) SetHeaders(headers map[string]string) {
	h.client.SetHeaders(headers)
}

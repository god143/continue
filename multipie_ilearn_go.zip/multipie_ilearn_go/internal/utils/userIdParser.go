package utils

import (
	"errors"

	"github.com/gin-gonic/gin"
)

func ExtractUserId(ctx *gin.Context) (int64, error) {
	userId, exists := ctx.Get("userId")
	if !exists {
		return 0, errors.New("user not authenticated")
	}
	uid, ok := userId.(int64)
	if !ok {
		return 0, errors.New("invalid userId")
	}

	return uid, nil
}

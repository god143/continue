package utils

import (
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestExtractUsername(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name     string
		setupCtx func(*gin.Context)
		want     string
		wantErr  bool
		errMsg   string
	}{
		{
			name: "Success - Valid String Username",
			setupCtx: func(ctx *gin.Context) {
				ctx.Set("username", "john_doe")
			},
			want:    "john_doe",
			wantErr: false,
		},
		{
			name: "Failure - Username Not Exists",
			setupCtx: func(ctx *gin.Context) {
				// Key not set in context
			},
			want:    "",
			wantErr: true,
			errMsg:  "user not authenticated",
		},
		{
			name: "Failure - Invalid Type (Int instead of String)",
			setupCtx: func(ctx *gin.Context) {
				ctx.Set("username", 12345) // Int stored where String expected
			},
			want:    "",
			wantErr: true,
			errMsg:  "invalid username format",
		},
		{
			name: "Failure - Nil Value",
			setupCtx: func(ctx *gin.Context) {
				ctx.Set("username", nil)
			},
			want:    "",
			wantErr: true,
			errMsg:  "invalid username format",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Arrange
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)
			tt.setupCtx(ctx)

			// Act
			got, err := ExtractUsername(ctx)

			// Assert
			if tt.wantErr {
				assert.Error(t, err)
				assert.Equal(t, tt.errMsg, err.Error())
				assert.Equal(t, "", got)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

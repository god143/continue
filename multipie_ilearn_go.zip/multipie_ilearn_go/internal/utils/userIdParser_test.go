package utils

import (
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestExtractUserId(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name       string
		setupCtx   func(*gin.Context)
		wantUserId int64
		wantErr    bool
		errMsg     string
	}{
		{
			name: "Success - Valid Int64 UserId",
			setupCtx: func(ctx *gin.Context) {
				ctx.Set("userId", int64(12345))
			},
			wantUserId: 12345,
			wantErr:    false,
		},
		{
			name: "Failure - UserId Not Exists",
			setupCtx: func(ctx *gin.Context) {
				// Don't set anything
			},
			wantUserId: 0,
			wantErr:    true,
			errMsg:     "user not authenticated",
		},
		{
			name: "Failure - Invalid Type (String instead of Int64)",
			setupCtx: func(ctx *gin.Context) {
				ctx.Set("userId", "12345") // Setting as string
			},
			wantUserId: 0,
			wantErr:    true,
			errMsg:     "invalid userId",
		},
		{
			name: "Failure - Invalid Type (Int instead of Int64)",
			setupCtx: func(ctx *gin.Context) {
				ctx.Set("userId", 123) // Plain int is different from int64 in Go
			},
			wantUserId: 0,
			wantErr:    true,
			errMsg:     "invalid userId",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create a fresh context for every test case
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)

			// Apply the specific setup for this test case
			tt.setupCtx(ctx)

			// Act
			got, err := ExtractUserId(ctx)

			// Assert
			if tt.wantErr {
				assert.Error(t, err)
				assert.Equal(t, tt.errMsg, err.Error())
				assert.Equal(t, int64(0), got)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.wantUserId, got)
			}
		})
	}
}

package utils

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestPointerConverters(t *testing.T) {
	t.Run("StringToPointer", func(t *testing.T) {
		val := "hello"
		res := StringToPointer(val)
		assert.NotNil(t, res)
		assert.Equal(t, val, *res)
	})

	t.Run("Int64ToPointer", func(t *testing.T) {
		val := int64(100)
		res := Int64ToPointer(val)
		assert.NotNil(t, res)
		assert.Equal(t, val, *res)
	})

	t.Run("IntToPointer", func(t *testing.T) {
		val := 10
		res := IntToPointer(val)
		assert.NotNil(t, res)
		assert.Equal(t, val, *res)
	})

	t.Run("FloatToPointer", func(t *testing.T) {
		val := 99.99
		res := FloatToPointer(val)
		assert.NotNil(t, res)
		assert.Equal(t, val, *res)
	})

	t.Run("BoolToPointer", func(t *testing.T) {
		val := true
		res := BoolToPointer(val)
		assert.NotNil(t, res)
		assert.Equal(t, val, *res)
	})

	t.Run("TimeToPointer", func(t *testing.T) {
		val := time.Now()
		res := TimeToPointer(val)
		assert.NotNil(t, res)
		assert.True(t, val.Equal(*res))
	})

	t.Run("ConvertInt64ToInt", func(t *testing.T) {
		var input int64 = 500
		res := ConvertInt64ToInt(&input)
		assert.NotNil(t, res)
		assert.Equal(t, 500, *res)
	})
}

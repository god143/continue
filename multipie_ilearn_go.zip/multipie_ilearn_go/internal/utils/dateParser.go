package utils

import (
	"fmt"
	"strings"
	"time"
)

var formatMap = map[string]string{
	"dd-mm-yyyy":          "02-01-2006",
	"yyyy/mm/dd":          "2006/01/02",
	"yyyy-mm-dd":          "2006-01-02",
	"mm/dd/yyyy":          "01/02/2006",
	"dd/mm/yyyy":          "02/01/2006",
	"yyyy/mm/dd hh:mm":    "2006/01/02 15:04",
	"yyyy-mm-dd hh:mm":    "2006-01-02 15:04",
	"yyyy-mm-dd hh:mm:ss": "2006-01-02 15:04:05",
}

func FormatDate(dateStr string) (string, error) {
	dateStr = strings.TrimSpace(dateStr)

	if dateStr == "" {
		return "", fmt.Errorf("date cannot be empty")
	}

	layouts := []string{
		"2006-01-02",          // yyyy-mm-dd
		"02-01-2006",          // dd-mm-yyyy
		"01-02-2006",          // mm-dd-yyyy
		"2006/01/02",          // yyyy/mm/dd
		"02/01/2006",          // dd/mm/yyyy
		"01/02/2006",          // mm/dd/yyyy
		"02.01.2006",          // dd.mm.yyyy
		"2006.01.02",          // yyyy.mm.dd
		"02 Jan 2006",         // dd Mon yyyy
		"02 January 2006",     // dd Month yyyy
		"2006-01-02 15:04:05", // yyyy-mm-dd hh:mm:ss
		time.RFC3339,          // ISO timestamp
	}

	for _, layout := range layouts {
		parsedDate, err := time.Parse(layout, dateStr)
		if err == nil {
			return parsedDate.Format("2006-01-02"), nil

		}
	}

	return "", fmt.Errorf("unsupported date format: %q", dateStr)
}

func FormatDateTime(dateTimeStr string) (*time.Time, error) {
	dateTimeStr = strings.TrimSpace(dateTimeStr)

	if dateTimeStr == "" {
		return nil, fmt.Errorf("date-time cannot be empty")
	}

	var layouts []string
	//DD-MM-YYYY or DD/MM/YYYY
	layouts = []string{

		// "01-02-2006 15:04",    // mm-dd-yyyy hh:mm.        --only article , videos
		"2006-01-02 15:04:05", // yyyy-mm-dd hh:mm:ss --  course_url
		"02-01-2006 15:04",    //dd-mm-yyyy hh:mm    -- expert , learn , course_url
	}

	for _, layout := range layouts {

		loc, err := time.LoadLocation("Asia/Kolkata")
		if err != nil {
			return nil, err
		}
		parsedDateTime, err := time.ParseInLocation(layout, dateTimeStr, loc)
		if err == nil {
			fmt.Println("CSV Input:", dateTimeStr)
			fmt.Println("Parsed Date:", parsedDateTime.Format("2006-01-02 15:04:05"))

			return &parsedDateTime, nil
		}
	}

	return nil, fmt.Errorf(
		"unsupported date-time format: %q", dateTimeStr,
	)
}

// FormatTime takes a time.Time variable and a general format string, and returns the formatted time as a string.
func FormatTime(t time.Time, format string) (string, error) {
	goFormat, ok := formatMap[format]
	if !ok {
		return "", fmt.Errorf("invalid format: %s", format)
	}

	return t.Format(goFormat), nil
}

// ParseTime takes a time string and a general format string, and returns the parsed time object or an error if parsing fails.
func ParseTime(timeStr, format string) (time.Time, error) {
	goFormat, ok := formatMap[format]
	if !ok {
		return time.Time{}, fmt.Errorf("invalid format: %s", format)
	}

	parsedTime, err := time.Parse(goFormat, timeStr)
	if err != nil {
		return time.Time{}, fmt.Errorf("error parsing time: %v", err)
	}

	return parsedTime, nil
}

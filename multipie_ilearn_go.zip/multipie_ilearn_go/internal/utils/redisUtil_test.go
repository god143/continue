package utils

// import (
// 	"context"
// 	"testing"

// 	"github.com/alicebob/miniredis/v2"
// 	"github.com/stretchr/testify/assert"
// )

// func TestRedis_WithMiniredis(t *testing.T) {
// 	// Start a real redis server in memory
// 	s := miniredis.RunT(t)
// 	defer s.Close()

// 	ctx := context.Background()
// 	redisObj = nil // Reset global

// 	t.Run("Successful Initialization", func(t *testing.T) {
// 		// Use s.Host() and s.Port() provided by miniredis
// 		client, err := NewRedisConn(ctx, s.Host(), s.Port())
// 		assert.NoError(t, err)
// 		assert.NotNil(t, client)
// 	})

// 	t.Run("Set and Get Value", func(t *testing.T) {
// 		client, _ := NewRedisConn(ctx, s.Host(), s.Port())

// 		err := client.SetValue(ctx, "test-key", "hello", 0, false)
// 		assert.NoError(t, err)

// 		var val string
// 		err = client.GetValue(ctx, "test-key", &val)
// 		assert.NoError(t, err)
// 		assert.Equal(t, "hello", val)
// 	})
// }

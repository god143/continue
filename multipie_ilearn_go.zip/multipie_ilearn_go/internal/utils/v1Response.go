package utils

type Response struct {
	Data     interface{} `json:"data,omitempty"`
	Included interface{} `json:"included,omitempty"`
	Errors   *string     `json:"errors,omitempty"`
}

func NewV1Response(data interface{}, errors *string) *Response {
	return &Response{
		Data:   data,
		Errors: errors,
	}
}

func NewV1ResponseWithIncluded(data interface{}, included interface{}, errors *string) *Response {
	return &Response{
		Data:     data,
		Included: included,
		Errors:   errors,
	}
}

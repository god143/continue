package utils

import "github.com/tidwall/gjson"

type JsonScrapper struct {
	jsonStr    string
	jsonObject gjson.Result
}

func NewJsonScrapper(jsonStr string) JsonScrapper {
	return JsonScrapper{
		jsonStr:    jsonStr,
		jsonObject: gjson.Parse(jsonStr),
	}
}

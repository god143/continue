package utils

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestNewHttpClient(t *testing.T) {
	t.Run("Default Config", func(t *testing.T) {
		config := ClientConfig{BaseUrl: "https://api.test.com"}
		client := NewHttpClient(config)
		assert.NotNil(t, client)
		assert.Equal(t, "https://api.test.com", client.client.BaseURL)
	})

	t.Run("Custom Config with SkipTLS", func(t *testing.T) {
		config := ClientConfig{
			Timeout:    10 * time.Second,
			SkipTls:    true,
			RetryCount: 2,
		}
		client := NewHttpClient(config)
		assert.NotNil(t, client)
	})
}

func TestHttpClient_Methods(t *testing.T) {
	// Setup a mock local server
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Mock logic based on method or path
		switch r.Method {
		case http.MethodGet:
			w.WriteHeader(http.StatusOK)
			w.Write([]byte(`{"message": "get success"}`))
		case http.MethodPost:
			w.WriteHeader(http.StatusCreated)
			w.Write([]byte(`{"message": "post success"}`))
		case http.MethodPut:
			w.WriteHeader(http.StatusOK)
			w.Write([]byte(`{"message": "put success"}`))
		default:
			w.WriteHeader(http.StatusInternalServerError)
		}
	}))
	defer server.Close()

	client := NewHttpClient(ClientConfig{BaseUrl: server.URL})
	ctx := context.Background()

	t.Run("GET Success", func(t *testing.T) {
		resp, err := client.Get(ctx, "/test", map[string]string{"key": "value"})
		assert.NoError(t, err)
		assert.Equal(t, http.StatusOK, resp.Status)
		assert.Contains(t, string(resp.Data.([]byte)), "get success")
	})

	t.Run("POST Success", func(t *testing.T) {
		body := map[string]string{"name": "test"}
		resp, err := client.Post(ctx, "/test", body)
		assert.NoError(t, err)
		assert.Equal(t, http.StatusCreated, resp.Status)
	})

	t.Run("PUT Success", func(t *testing.T) {
		body := map[string]string{"name": "update"}
		resp, err := client.Put(ctx, "/test", body)
		assert.NoError(t, err)
		assert.Equal(t, http.StatusOK, resp.Status)
	})

	t.Run("Network Error Case", func(t *testing.T) {
		// Use an unreachable URL to trigger resty's error return
		badClient := NewHttpClient(ClientConfig{BaseUrl: "http://invalid.local"})
		resp, err := badClient.Get(ctx, "/", nil)
		assert.Error(t, err)
		assert.Nil(t, resp)
	})
}

func TestHttpClient_Setters(t *testing.T) {
	// 1. Setup a local mock server to capture the header
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		// This is where we verify the header actually sent by Resty
		assert.Equal(t, "Bearer secret-token", r.Header.Get("Authorization"))
		assert.Equal(t, "value", r.Header.Get("X-Custom"))
		assert.Equal(t, "val", r.Header.Get("X-Multi"))
	}))
	defer server.Close()

	// 2. Initialize your client
	client := NewHttpClient(ClientConfig{})
	t.Run("Set Auth and Headers", func(t *testing.T) {
		client.SetAuthToken("secret-token")
		client.SetHeader("X-Custom", "value")
		client.SetHeaders(map[string]string{"X-Multi": "val"})

		// 3. Execute a dummy request to the mock server to trigger header generation
		// Resty will now combine the 'Token' field into the 'Authorization' header
		_, err := client.client.R().Get(server.URL)
		assert.NoError(t, err)
	})
}

package utils

import (
	"context"
	"fmt"
	"multipie_ilearn_go/internal/logger"
	"strconv"
	"time"

	rdc "github.com/go-redis/cache/v9"
	rd "github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

type RedisUtilInterface interface {
	Close(ctx context.Context) error
	SetValue(ctx context.Context, key string, value interface{}, timeout time.Duration, writeIfNotExists bool) error
	GetValue(ctx context.Context, key string, value interface{}) error
	GetClient() *rd.Client
}

type redisConn struct {
	Url    string
	Port   int
	Client *rd.Client
	Cache  *rdc.Cache
}

var redisObj *redisConn = nil

func NewRedisConn(ctx context.Context, url string, port string) (RedisUtilInterface, error) {
	if redisObj != nil {
		return redisObj, nil
	}

	redisClient := rd.NewClient(&rd.Options{
		Addr:     fmt.Sprintf("%s:%s", url, port),
		Password: "",
		DB:       0,
	})

	//Check redis connection
	pong, err := redisClient.Ping(ctx).Result()
	if err != nil {
		return nil, err
	}

	logger.Info(ctx, "redis connection successful", zap.String("result", pong))

	redisCache := rdc.New(&rdc.Options{
		Redis: redisClient,
	})
	redisPort, err := strconv.Atoi(port)
	if err != nil {
		logger.Error(ctx, "invalid value for redis port", zap.Error(err))
		return nil, err
	}
	redisObj = &redisConn{
		Url:    url,
		Port:   redisPort,
		Client: redisClient,
		Cache:  redisCache,
	}
	return redisObj, nil
}

func GetRedisConn() *redisConn {
	return redisObj
}

func (r *redisConn) Close(ctx context.Context) error {
	return r.Client.Close()
}

// SetValue... Set value in cache
func (r *redisConn) SetValue(ctx context.Context, key string, value interface{}, timeout time.Duration, writeIfNotExists bool) error {
	cacheItem := &rdc.Item{
		Ctx:   ctx,
		Key:   key,
		Value: value,
		TTL:   timeout,
		SetNX: writeIfNotExists,
	}
	return r.Cache.Set(cacheItem)
}

// GetValue... get value from cache
func (r *redisConn) GetValue(ctx context.Context, key string, value interface{}) error {
	return r.Cache.Get(ctx, key, value)
}

func (r *redisConn) GetClient() *rd.Client {
	return r.Client
}

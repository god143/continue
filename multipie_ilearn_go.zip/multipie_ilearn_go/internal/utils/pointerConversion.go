package utils

import "time"

func StringToPointer(value string) *string {
	return &value
}

func Int64ToPointer(value int64) *int64 {
	return &value
}

func IntToPointer(value int) *int {
	return &value
}
func FloatToPointer(value float64) *float64 {
	return &value
}

func BoolToPointer(value bool) *bool {
	return &value
}

func TimeToPointer(value time.Time) *time.Time {
	return &value
}

func ConvertInt64ToInt(val *int64) *int {
	num := int(*val)
	modelId := num
	return &modelId
}

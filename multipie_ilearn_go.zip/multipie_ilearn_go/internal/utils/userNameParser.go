package utils

import (
	"errors"

	"github.com/gin-gonic/gin"
)

func ExtractUsername(ctx *gin.Context) (string, error) {
	username, exists := ctx.Get("username")
	if !exists {
		return "", errors.New("user not authenticated")
	}

	if uname, ok := username.(string); ok {
		return uname, nil
	}

	return "", errors.New("invalid username format")
}

package utils

import "gorm.io/gorm"

type Pagination struct {
	Page       int         `json:"page"`
	PageSize   int         `json:"page_size"`
	TotalRows  int64       `json:"total_rows"`
	TotalPages int         `json:"total_pages"`
	Data       interface{} `json:"data"`
}

func Paginate(db *gorm.DB, model interface{}, pagination *Pagination, query *gorm.DB) error {
	// Validate and set default values for Page and PageSize
	if pagination.Page <= 0 {
		pagination.Page = 1
	}
	if pagination.PageSize <= 0 {
		pagination.PageSize = 10
	}
	if pagination.PageSize > 20 {
		pagination.PageSize = 20
	}

	var totalRows int64

	// Get total number of records based on query
	query.Model(model).Count(&totalRows)
	pagination.TotalRows = totalRows

	// Calculate total pages
	pagination.TotalPages = int((totalRows + int64(pagination.PageSize) - 1) / int64(pagination.PageSize))

	// Set limit and offset for pagination
	offset := (pagination.Page - 1) * pagination.PageSize
	if offset < 0 {
		offset = 0
	}

	// Fetch data with pagination
	query.Limit(pagination.PageSize).Offset(offset).Find(model)
	pagination.Data = model

	return nil
}

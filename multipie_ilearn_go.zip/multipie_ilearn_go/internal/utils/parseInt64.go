package utils

import (
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

// ParseInt64Param is a helper function to parse URL parameters to int64.
func ParseInt64Param(ctx *gin.Context, paramName string) (int64, error) {
	paramStr := ctx.Param(paramName)
	if paramStr == "" {
		return 0, fmt.Errorf("%s parameter is required", paramName)
	}

	paramInt, err := strconv.ParseInt(paramStr, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("%s parameter is invalid", paramName)
	}

	return paramInt, nil
}

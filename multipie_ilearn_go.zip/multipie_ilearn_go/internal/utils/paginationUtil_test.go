package utils

// import (
// 	"testing"

// 	"github.com/stretchr/testify/assert"
// 	"gorm.io/driver/sqlite"
// 	"gorm.io/gorm"
// )

// // Dummy struct to represent your model for DB operations
// type TestUser struct {
// 	ID   uint `gorm:"primaryKey"`
// 	Name string
// }

// func TestPaginate(t *testing.T) {
// 	// 1. Initialize an in-memory SQLite DB (Satisfies *gorm.DB)
// 	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
// 	if err != nil {
// 		t.Fatalf("failed to connect database: %v", err)
// 	}

// 	// 2. Setup the table for the model
// 	db.AutoMigrate(&TestUser{})

// 	tests := []struct {
// 		name     string
// 		page     int
// 		pageSize int
// 		wantPage int
// 		wantSize int
// 	}{
// 		{
// 			name:     "Handle Zero Values",
// 			page:     0,
// 			pageSize: 0,
// 			wantPage: 1,
// 			wantSize: 10,
// 		},
// 		{
// 			name:     "Cap PageSize at 20",
// 			page:     1,
// 			pageSize: 100, // Should be capped to 20
// 			wantPage: 1,
// 			wantSize: 20,
// 		},
// 		{
// 			name:     "Valid Normal Pagination",
// 			page:     2,
// 			pageSize: 15,
// 			wantPage: 2,
// 			wantSize: 15,
// 		},
// 	}

// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			pagination := &Pagination{
// 				Page:     tt.page,
// 				PageSize: tt.pageSize,
// 			}

// 			var users []TestUser
// 			// We pass 'db' for both arguments because the function expects *gorm.DB
// 			err := Paginate(db, &users, pagination, db)

// 			assert.NoError(t, err)
// 			assert.Equal(t, tt.wantPage, pagination.Page)
// 			assert.Equal(t, tt.wantSize, pagination.PageSize)
// 			assert.NotNil(t, pagination.Data)
// 		})
// 	}
// }

package utils

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestFormatTime(t *testing.T) {
	type args struct {
		t      time.Time
		format string
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "Valid format dd-mm-yyyy",
			args: args{
				t:      time.Date(2022, time.December, 25, 10, 30, 0, 0, time.UTC),
				format: "dd-mm-yyyy",
			},
			want:    "25-12-2022",
			wantErr: false,
		},
		{
			name: "Valid format yyyy/mm/dd",
			args: args{
				t:      time.Date(2022, time.December, 25, 10, 30, 0, 0, time.UTC),
				format: "yyyy/mm/dd",
			},
			want:    "2022/12/25",
			wantErr: false,
		},
		{
			name: "Invalid format",
			args: args{
				t:      time.Date(2022, time.December, 25, 10, 30, 0, 0, time.UTC),
				format: "invalid-format",
			},
			want:    "",
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := FormatTime(tt.args.t, tt.args.format)

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, got, tt.want)
			}

		})
	}
}

func TestParseTime(t *testing.T) {
	type args struct {
		timeStr string
		format  string
	}
	tests := []struct {
		name    string
		args    args
		want    time.Time
		wantErr bool
	}{
		{
			name: "Valid format dd-mm-yyyy",
			args: args{
				timeStr: "25-12-2022",
				format:  "dd-mm-yyyy",
			},
			want:    time.Date(2022, time.December, 25, 0, 0, 0, 0, time.UTC),
			wantErr: false,
		},
		{
			name: "Valid format yyyy/mm/dd",
			args: args{
				timeStr: "2022/12/25",
				format:  "yyyy/mm/dd",
			},
			want:    time.Date(2022, time.December, 25, 0, 0, 0, 0, time.UTC),
			wantErr: false,
		},
		{
			name: "Invalid format",
			args: args{
				timeStr: "2022/25/12",
				format:  "yyyy/mm/dd",
			},
			want:    time.Time{}, // zero value indicating parsing failed
			wantErr: true,
		},
		{
			name: "Invalid format with time",
			args: args{
				timeStr: "2022/25/12 10:12:13",
				format:  "yyyy/mm/dd hh-mm-ss",
			},
			want:    time.Time{}, // zero value indicating parsing failed
			wantErr: true,
		},
		{
			name: "Valid format with time",
			args: args{
				timeStr: "2022-12-25 10:30",
				format:  "yyyy-mm-dd hh:mm",
			},
			want:    time.Date(2022, time.December, 25, 10, 30, 0, 0, time.UTC),
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseTime(tt.args.timeStr, tt.args.format)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, got, tt.want)
			}
		})
	}
}

package utils

import (
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestParseInt64Param(t *testing.T) {
	// Set Gin to Test Mode to avoid noisy logs
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name      string
		paramName string
		paramVal  string
		want      int64
		wantErr   bool
		errMsg    string
	}{
		{
			name:      "Valid Positive Int64",
			paramName: "id",
			paramVal:  "123",
			want:      123,
			wantErr:   false,
		},
		{
			name:      "Valid Negative Int64",
			paramName: "user_id",
			paramVal:  "-456",
			want:      -456,
			wantErr:   false,
		},
		{
			name:      "Missing Parameter",
			paramName: "id",
			paramVal:  "", // Simulate empty string from Gin
			want:      0,
			wantErr:   true,
			errMsg:    "id parameter is required",
		},
		{
			name:      "Invalid Format (String)",
			paramName: "id",
			paramVal:  "abc",
			want:      0,
			wantErr:   true,
			errMsg:    "id parameter is invalid",
		},
		{
			name:      "Invalid Format (Float)",
			paramName: "id",
			paramVal:  "12.34",
			want:      0,
			wantErr:   true,
			errMsg:    "id parameter is invalid",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// 1. Create a dummy Gin context
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)

			// 2. MANUALLY inject the parameter into the context
			ctx.Params = []gin.Param{
				{
					Key:   tt.paramName,
					Value: tt.paramVal,
				},
			}

			// 3. Act
			got, err := ParseInt64Param(ctx, tt.paramName)

			// 4. Assert
			if tt.wantErr {
				assert.Error(t, err)
				assert.Equal(t, tt.errMsg, err.Error())
				assert.Equal(t, int64(0), got)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

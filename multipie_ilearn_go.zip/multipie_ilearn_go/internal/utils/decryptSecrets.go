package utils

import (
	"crypto/aes"
	"crypto/cipher"
	"fmt"
	"log"
	"os"
	"strings"
)

func DecryptFile(keyPath, keyName, credPath, env string) string {
	encFile := fmt.Sprintf("%s/%s.yaml.enc", credPath, env)

	encData, err := os.ReadFile(encFile)
	if err != nil {
		log.Fatalf("failed to read encrypted file: %v", err)
	}

	plaintext := DecryptSecrets(keyPath, keyName, encData)

	return string(plaintext)
}

func DecryptSecrets(keyPath, keyName string, data []byte) string {
	keyFile := fmt.Sprintf("%s/%s.key", keyPath, keyName)

	// fmt.Println("keyFile", keyFile)

	// Read the entire file content into a byte slice
	keyContent, err := os.ReadFile(keyFile)
	if err != nil {
		log.Fatalf("Failed to read the key file: %v", err)
	}

	key := []byte(strings.TrimSpace(string(keyContent)))

	block, err := aes.NewCipher(key)
	if err != nil {
		log.Fatalf("failed to create cipher: %v", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		log.Fatalf("failed to create gcm: %v", err)
	}

	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		log.Fatalf("malformed encrypted file")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]

	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		log.Fatalf("decryption failed: %v", err)
	}

	return string(plaintext)
}

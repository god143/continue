package utils

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewJsonScrapper(t *testing.T) {
	tests := []struct {
		name    string
		jsonStr string
		isValid bool
	}{
		{
			name:    "Valid JSON Object",
			jsonStr: `{"name": "John", "age": 30}`,
			isValid: true,
		},
		{
			name:    "Valid JSON Array",
			jsonStr: `[{"id": 1}, {"id": 2}]`,
			isValid: true,
		},
		{
			name:    "Malformed JSON",
			jsonStr: `{"name": "John", age: 30`, // Missing quotes/braces
			isValid: false,
		},
		{
			name:    "Empty String",
			jsonStr: ``,
			isValid: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			scrapper := NewJsonScrapper(tt.jsonStr)

			// 1. Verify internal string storage
			assert.Equal(t, tt.jsonStr, scrapper.jsonStr)

			// 2. Verify gjson parsed result
			// gjson.Parse always returns a Result, even for invalid JSON (Exists() will be false)
			if tt.isValid {
				assert.True(t, scrapper.jsonObject.Exists(), "JSON should be valid for: %s", tt.name)
			} else {
				// For invalid JSON, gjson usually results in a non-existent or null object
				assert.False(t, scrapper.jsonObject.IsObject() && scrapper.jsonObject.IsArray(), "Should not be valid object/array")
			}
		})
	}
}

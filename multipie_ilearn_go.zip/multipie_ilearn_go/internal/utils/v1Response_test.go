package utils

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewV1Response(t *testing.T) {
	t.Run("Success Response with Data", func(t *testing.T) {
		data := map[string]string{"message": "success"}

		// Act
		resp := NewV1Response(data, nil)

		// Assert
		assert.NotNil(t, resp)
		assert.Equal(t, data, resp.Data)
		assert.Nil(t, resp.Errors)
	})

	t.Run("Error Response with Pointer String", func(t *testing.T) {
		errMessage := "something went wrong"
		// Using the utility we tested earlier to get a pointer
		errPtr := StringToPointer(errMessage)

		// Act
		resp := NewV1Response(nil, errPtr)

		// Assert
		assert.NotNil(t, resp)
		assert.Nil(t, resp.Data)
		assert.NotNil(t, resp.Errors)
		assert.Equal(t, errMessage, *resp.Errors)
	})
}

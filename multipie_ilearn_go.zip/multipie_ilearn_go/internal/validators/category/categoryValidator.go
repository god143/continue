package category

import (
	"fmt"
	"reflect"

	"github.com/go-playground/validator/v10"
)

type categoryValidator struct {
}

type CategoryValidator interface {
	ParentCategory(fl validator.FieldLevel) bool
}

func NewCategoryValidator() CategoryValidator {
	return &categoryValidator{}
}

// Custom validation function to check if Parent is nil, then Icon, Banner, and Description are required
func (c *categoryValidator) ParentCategory(fl validator.FieldLevel) bool {
	// Get the field value for the "Parent" field
	parentField := fl.Parent().FieldByName("Parent")
	if parentField.IsValid() && parentField.Kind() == reflect.Ptr {
		// If parent is nil, we need to validate the fields
		fmt.Println(parentField.IsNil())
		if !parentField.IsNil() {
			fmt.Println("inside parentIsNil IF-caluse", parentField.IsNil())
			// Check if Icon, Banner, and Description are nil
			descriptionField := fl.Parent().FieldByName("Description")
			typeField := fl.Parent().FieldByName("Type")

			if descriptionField.IsNil() { //if parent == nil, then description field is required.
				return false
			}

			if typeField.IsValid() && !typeField.IsNil() { //if parent == nil, then type has to be nil
				return false
			}
		}
	}
	// If Parent is not nil, no need to enforce the validation
	return true
}

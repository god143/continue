package validators

import "multipie_ilearn_go/internal/validators/category"

type validator struct {
	category.CategoryValidator
}

type ValidatorGroup interface {
	category.CategoryValidator
}

func NewValidatorGroup() ValidatorGroup {
	return &validator{
		category.NewCategoryValidator(),
	}
}

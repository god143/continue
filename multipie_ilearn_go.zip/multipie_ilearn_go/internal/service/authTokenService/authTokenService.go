package authTokenService

import (
	"context"
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/db"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"
	"time"

	rdc "github.com/go-redis/cache/v9"
	"github.com/tidwall/gjson"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

type User struct {
	UserId      int64
	Username    string
	Mobile      string
	Email       string
	DisplayName string
	Role        string
}

type OauthClient struct {
	AccessToken  string
	RefreshToken string
	ExpiresAt    int64
	Scope        string
}

type OauthClientRequest struct {
	ClientId     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
	GrantType    string `json:"grant_type"`
	Scope        string `json:"scope"`
}

// TokenCalims represent the calims fetched from server
type TokenCalims struct {
	UserID    int64
	Username  string
	Scope     []string
	ExpiresAt int64
}

// AuthTokenService handles validation using either APIKey or JWT authentication
type AuthTokenService struct {
	clientID     string
	clientSecret string
	authUrl      string
}

// Config Holds the configuration for authentication service
type Config struct {
	ClientId     string
	ClientSecret string
	AuthUrl      string
}

// NewAuthService creates a new authentication service based on provided config
func NewAuthTokenService(config Config) (*AuthTokenService, error) {
	if config.ClientId == "" || config.ClientSecret == "" || config.AuthUrl == "" {
		return nil, errors.New("clientId and cleintSecret cannot be blank")
	}

	return &AuthTokenService{
		clientID:     config.ClientId,
		clientSecret: config.ClientSecret,
		authUrl:      config.AuthUrl,
	}, nil
}
func (a *AuthTokenService) TokenInfo(ctx context.Context, token string) (*TokenCalims, error) {
	var tokenClaims TokenCalims
	authHttpClient := a.setUpAuthHttpClient()
	authHttpClient.SetAuthToken(token)

	resp, err := authHttpClient.Get(ctx, "/oauth/token/info", nil)
	if err != nil {
		return nil, err
	}

	if resp.Status != http.StatusOK {
		return nil, errors.New("unable to get token info from auth server")
	}

	respStr := string(resp.Data.([]byte))
	tokenClaims.UserID = gjson.Get(respStr, "resource_owner_id").Int()
	tokenClaims.Scope = getScopeFromToken(respStr)
	tokenClaims.ExpiresAt = getExpireAtFromToken(respStr)

	return &tokenClaims, nil
}

func (a *AuthTokenService) OauthClient(ctx context.Context) (*OauthClient, error) {
	var client OauthClient
	var request OauthClientRequest

	authHttpClient := a.setUpAuthHttpClient()

	request = OauthClientRequest{
		ClientId:     a.clientID,
		ClientSecret: a.clientSecret,
		Scope:        "multipie_internal",
		GrantType:    "client_credentials",
	}
	resp, err := authHttpClient.Post(ctx, "/oauth/token", request)
	if err != nil {
		return nil, err
	}

	if resp.Status != http.StatusOK {
		return nil, errors.New("unable to get user info from auth server")
	}

	// convert resp into json string
	respStr := string(resp.Data.([]byte))

	client.AccessToken = gjson.Get(respStr, "access_token").String()
	client.RefreshToken = gjson.Get(respStr, "refresh_token").String()
	client.Scope = gjson.Get(respStr, "scope").String()
	client.ExpiresAt = gjson.Get(respStr, "expires_at").Time().Unix()

	return &client, nil

}

// AuthenticateUser check if user is valid or not
func (a *AuthTokenService) AuthenticateUser(ctx context.Context, token string, dbLayer db.DBLayer) (*User, error) {
	//check length
	if !a.validApiToken(token) {
		return nil, errors.New("invalid access token")
	}

	user, err := a.CurrentUser(ctx, token, dbLayer)
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (a *AuthTokenService) validApiToken(token string) bool {
	return len(token) > 32
}

func (a *AuthTokenService) CurrentUser(ctx context.Context, token string, dbLayer db.DBLayer) (*User, error) {
	var value User
	//Find in cache
	redisConn := utils.GetRedisConn()

	key := fmt.Sprintf("ilearn-session-%v", token)
	if err := redisConn.GetValue(ctx, key, &value); err != nil && !errors.Is(err, rdc.ErrCacheMiss) {
		return nil, fmt.Errorf("error fetching user details from redis cache, error: %v", err)
	}

	if value.UserId != 0 {
		return &value, nil
	}

	user, err := a.GetUserInfo(ctx, token)
	if err != nil {
		return nil, fmt.Errorf("error fetching user details from auth server, error: %v", err)
	}

	role, err := a.GetUserRole(ctx, user.UserId, dbLayer)
	if err != nil {
		return nil, fmt.Errorf("error fetching user role details from ilearn server, error: %v", err)
	}
	user.Role = role

	if err := redisConn.SetValue(ctx, key, &user, 15*time.Second, true); err != nil {
		return nil, fmt.Errorf("error in saving user details in redis cache, error: %v", err)
	}

	return user, nil
}

func (a *AuthTokenService) GetUserRole(ctx context.Context, userId int64, dbLayer db.DBLayer) (string, error) {

	user, err := dbLayer.GetUserByUID(ctx, userId)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			logger.Error(ctx, "user not found")
			return "", err
		}
		logger.Error(ctx, "unable to fetch user role from iLearn server:", zap.Error(err))
		return "", err

	}
	return user.Role.String(), nil
}

func (a *AuthTokenService) GetUserInfo(ctx context.Context, token string) (*User, error) {
	var user User
	authHttpClient := a.setUpAuthHttpClient()

	authHttpClient.SetAuthToken(token)
	resp, err := authHttpClient.Get(ctx, "api/v1/current_user", nil)
	if err != nil {
		return nil, err
	}

	if resp.Status != http.StatusOK {
		return nil, errors.New("unable to get user info from auth server")
	}

	// convert resp into json string
	respStr := string(resp.Data.([]byte))

	user.UserId = gjson.Get(respStr, "data.id").Int()
	user.Username = gjson.Get(respStr, "data.attributes.username").String()
	user.DisplayName = gjson.Get(respStr, "data.attributes.displayName").String()
	user.Mobile = gjson.Get(respStr, "data.attributes.mobile").String()
	user.Email = gjson.Get(respStr, "data.attributes.email").String()

	return &user, nil
}

func (a *AuthTokenService) setUpAuthHttpClient() *utils.HttpClient {
	appConfig := config.AppSecrets

	httpClinetConfig := utils.ClientConfig{
		Timeout:       15 * time.Second,
		RetryCount:    3,
		RetryWaitTime: 15 * time.Second,
		SkipTls:       true,
		BaseUrl:       appConfig.IlearnOauthClient.AuthUrl,
	}

	return utils.NewHttpClient(httpClinetConfig)

}

func getScopeFromToken(respStr string) []string {
	var result []string
	tempScope := gjson.Get(respStr, "scope").Array()
	for _, val := range tempScope {
		result = append(result, val.String())
	}

	return result
}

func getExpireAtFromToken(respStr string) int64 {
	expiresIn := gjson.Get(respStr, "expires_in").Int()
	createdAt := gjson.Get(respStr, "created_at").Int()

	return expiresIn + createdAt
}

package queueService

import (
	"context"
	"encoding/json"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	"multipie_ilearn_go/internal/logger"
	"sync"
	"time"

	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

type StatsQueueMessage struct {
	Action    string `json:"action"`     // like / unlike / view
	ModelType string `json:"model_type"` // courseModule, course, infographics, resources
	ModelId   int64  `json:"model_id"`   // respective ID of model
	UserID    int64  `json:"user_id"`    // user performing the action
}

type queueService struct {
	client  *redis.Client
	dbLayer db.DBLayer
}

type QueueService interface {
	PublishMessage(ctx context.Context, streamName string, msg interface{}) error
	StartWorker(ctx context.Context, streamName string, groupName string, wg *sync.WaitGroup)
	CreateConsumerGroup(ctx context.Context, streamName string, groupName string) error
	DeleteConsumerGroup(ctx context.Context, streamName string, groupName string) error
}

func NewQueueService(client *redis.Client, dbLayer db.DBLayer) QueueService {
	return &queueService{
		client:  client,
		dbLayer: dbLayer,
	}
}

func (q *queueService) PublishMessage(ctx context.Context, streamName string, msg interface{}) error {
	data, err := json.Marshal(msg)
	if err != nil {
		logger.Error(ctx, "error encoding message", zap.Error(err), zap.Any("message", msg))
		return fmt.Errorf("error encoding the message, error: %v", err)
	}

	_, err = q.client.XAdd(ctx, &redis.XAddArgs{
		Stream: streamName,
		Values: map[string]interface{}{
			"data": string(data),
		},
	}).Result()

	if err != nil {
		logger.Error(ctx, "error publishing message", zap.Error(err))
		return fmt.Errorf("error in publishing message, error: %v", err)
	}

	logger.Debug(ctx, "message published", zap.String("streamName", streamName), zap.Any("message", msg))
	return nil
}

func (q *queueService) CreateConsumerGroup(ctx context.Context, streamName string, groupName string) error {
	//"$" marks the consumer group to start from the latest message
	if err := q.client.XGroupCreateMkStream(ctx, streamName, groupName, "$").Err(); err != nil {
		if err.Error() != "BUSYGROUP Consumer Group name already exists" {
			logger.Error(ctx, "error creating consumer group", zap.Error(err))
			return err
		}
	} else {
		logger.Info(ctx, "consumer group already exists", zap.String("group_name", groupName))
	}
	return nil
}

func (q *queueService) StartWorker(ctx context.Context, streamName string, groupName string, wg *sync.WaitGroup) {
	defer wg.Done()

	// 1. Automatically create the stream and consumer group if they don't exist
	// "$" means read only new messages; change to "0" if you want to read from the beginning
	err := q.client.XGroupCreateMkStream(ctx, streamName, groupName, "$").Err()
	if err != nil {
		// Ignore the error if the consumer group already exists (BUSYGROUP error string)
		if err.Error() != "BUSYGROUP Consumer Group name already exists" {
			logger.Error(ctx, "failed to initialize consumer group", zap.Error(err))
		}
	}

	// Unique consumer instance name for this specific pod/worker run
	consumerName := fmt.Sprintf("consumer-%s-%v", groupName, time.Now().UnixNano())

	for {
		select {
		case <-ctx.Done():
			logger.Info(ctx, "worker stopping")
			// FIX: Delete only this consumer instance, NOT the entire group!
			if err := q.client.XGroupDelConsumer(ctx, streamName, groupName, consumerName).Err(); err != nil {
				logger.Error(ctx, "error deleting the consumer", zap.Error(err))
			}
			return
		default:
			streams, err := q.client.XReadGroup(ctx, &redis.XReadGroupArgs{
				Group:    groupName,
				Consumer: consumerName,
				Streams:  []string{streamName, ">"},
				Count:    1,               // Number of message to read at once
				Block:    time.Second * 1, // Block for 1 second until a message arrives
			}).Result()

			if err != nil {
				if err != redis.Nil {
					logger.Error(ctx, "error reading from stream", zap.Error(err))
					// FIX: Add a backoff sleep to prevent tight loop log spamming on errors
					time.Sleep(2 * time.Second)
				}
				continue
			}

			for _, stream := range streams {
				for _, message := range stream.Messages {
					if err := q.processMessage(ctx, stream.Stream, message); err != nil {
						logger.Error(ctx, "error processing the message", zap.Error(err))
						continue
					}

					// Acknowledge message only after successful processing
					if err := q.client.XAck(ctx, streamName, groupName, message.ID).Err(); err != nil {
						logger.Error(ctx, "error in acknowledging the msg", zap.Error(err))
					}
				}
			}
		}
	}
}

func (q *queueService) processMessage(ctx context.Context, stream string, message redis.XMessage) error {
	switch stream {
	case constants.STATS_QUEUE:
		return q.processStatsQueueMsg(ctx, message)
	default:
		return nil
	}
}

func (q *queueService) processStatsQueueMsg(ctx context.Context, queueMessage redis.XMessage) error {
	var msg StatsQueueMessage
	if err := json.Unmarshal([]byte(queueMessage.Values["data"].(string)), &msg); err != nil {
		logger.Error(ctx, "failed to unmarshal message", zap.Error(err), zap.String("message", queueMessage.Values["data"].(string)))
		return fmt.Errorf("failed to unmarshal event, error: %v", err)
	}
	return q.updateModelTable(ctx, msg.UserID, msg.ModelId, msg.ModelType, msg.Action)
}

func (q *queueService) updateModelTable(ctx context.Context, userID int64, modelID int64, modelType string, action string) error {
	var err error
	if action == constants.STATS_ACTION_VIEW {
		err = q.updateViewsCount(ctx, modelID, modelType)
	} else {
		err = q.updateLikesTable(ctx, userID, modelID, modelType, action)
	}

	if err != nil {
		logger.Error(ctx, "error updating model table", zap.Int64("model_id", modelID), zap.String("model_type", modelType), zap.String("action", action), zap.Error(err))
		return err
	}

	logger.Debug(ctx, "model table updated", zap.Int64("model_id", modelID), zap.String("model_type", modelType), zap.String("action", action))
	return nil
}

func (q *queueService) updateViewsCount(ctx context.Context, modelID int64, modelType string) error {
	switch modelType {
	case constants.STATS_MODEL_COURSE:
		return q.dbLayer.UpdateViewsCountCourses(ctx, modelID)
	case constants.STATS_MODEL_COURSE_MODULES:
		return q.dbLayer.UpdateViewsCountCourseModule(ctx, modelID)
	case constants.STATS_MODEL_RESOURCE:
		return q.dbLayer.UpdateViewsCountResource(ctx, modelID)
	case constants.STATS_MODEL_INFOGRAPHIC:
		return q.dbLayer.UpdateViewsCountInfographic(ctx, modelID)
	default:
		return fmt.Errorf("unknown model type for view count: %s", modelType)
	}
}

func (q *queueService) updateLikesTable(ctx context.Context, userID int64, modelID int64, modelType string, action string) error {
	liked, err := q.dbLayer.HasUserLiked(ctx, userID, modelID, modelType)
	if err != nil {
		return err
	}

	switch action {
	case constants.STATS_ACTION_LIKE:
		if liked {

			return nil
		}
		err = q.dbLayer.AddLike(ctx, userID, modelID, modelType)
	case constants.STATS_ACTION_UNLIKE:
		if !liked {

			return nil
		}
		err = q.dbLayer.RemoveLike(ctx, userID, modelID, modelType)
	default:
		return fmt.Errorf("invalid action: %s", action)
	}

	if err == nil {
		return q.updateLikesCount(ctx, modelID, modelType, action)
	}

	return err
}

func (q *queueService) updateLikesCount(ctx context.Context, modelID int64, modelType string, action string) error {
	switch modelType {
	case constants.STATS_MODEL_COURSE:
		return q.dbLayer.UpdateLikesCountCourses(ctx, modelID, action)
	case constants.STATS_MODEL_COURSE_MODULES:
		return q.dbLayer.UpdateLikesCountCourseModule(ctx, modelID, action)
	case constants.STATS_MODEL_RESOURCE:
		return q.dbLayer.UpdateLikesCountResource(ctx, modelID, action)
	case constants.STATS_MODEL_INFOGRAPHIC:
		return q.dbLayer.UpdateLikesCountInfographic(ctx, modelID, action)
	default:
		return fmt.Errorf("unknown model type: %s", modelType)
	}
}

func (q *queueService) DeleteConsumerGroup(ctx context.Context, streamName string, groupName string) error {
	cleanupCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second) // Set an appropriate timeout for cleanup
	defer cancel()

	err := q.client.XGroupDestroy(cleanupCtx, streamName, groupName).Err()
	if err != nil {
		logger.Error(ctx, "error deleting consumer group", zap.String("stream", streamName), zap.String("group", groupName), zap.Error(err))
		return fmt.Errorf("failed to delete consumer group, error: %v", err)
	}
	return nil
}

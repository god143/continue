package activestorage

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"multipie_ilearn_go/internal/utils/awsUtil"
	"os"
	"path/filepath"
	"strings"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type activeStorageService struct {
	db db.DBLayer
}

type ActiveStorageService interface {
	UploadFile(ctx context.Context, input ActiveStorageUploadInput) (*string, error)
	DownloadFile(ctx context.Context, input ActiveStorageDownloadInput) ([]byte, string, error)
	UploadFileFromLocal(ctx context.Context, input ActiveStorageLocalUploadInput) (*string, error)
	GetURL(tempUrl string) string
}

type ActiveStorageUploadInput struct {
	FileHeader    *multipart.FileHeader
	ServiceName   string //local or S3
	ModelType     string //Category/Course/Resource
	ModelId       int64  //categoryId/courseId
	ContentType   string
	AttachmentFor string
	IsPrimary     bool
	PublicDir     string
}

type ActiveStorageLocalUploadInput struct {
	FileBytes     []byte
	FileName      string
	ServiceName   string
	ModelType     string
	ModelID       int64
	ContentType   string
	AttachmentFor string
	IsPrimary     bool
}

type ActiveStorageDownloadInput struct {
	Filekey  string
	FileName string
}

func isAllowedMimeType(mimeType string) bool {
	allowedMimeTypes := map[string]bool{
		"image/jpeg":               true,
		"image/png":                true,
		"application/pdf":          true,
		"image/gif":                true,
		"application/zip":          true,
		"image/svg+xml":            true,
		"audio/mpeg":               true,
		"text/html":                true,
		"application/octet-stream": true,
		// Add more types as needed
	}

	_, exists := allowedMimeTypes[mimeType]
	return exists
}

func NewActiveStorageService(db db.DBLayer) ActiveStorageService {
	return &activeStorageService{
		db: db,
	}
}

func (a *activeStorageService) UploadFileFromLocal(ctx context.Context, input ActiveStorageLocalUploadInput) (*string, error) {
	var (
		activeStorageRecord dbModel.ActiveStorage
		fileKey             = genrateKey() // Generate a unique file key
	)

	// Validate serviceName
	if input.ServiceName != constants.SERVICE_NAME_LOCAL && input.ServiceName != constants.SERVICE_NAME_S3 {
		return nil, fmt.Errorf("invalid value for service name")
	}

	// Validate file size
	if int64(len(input.FileBytes)) > constants.FILE_SIZE_LIMIT { // 50MB limit
		return nil, fmt.Errorf("file size exceeds the limit, input file size: %v", len(input.FileBytes))
	}

	// Validate file type
	if !isAllowedMimeType(input.ContentType) {
		return nil, fmt.Errorf("invalid file type, input file type: %v", input.ContentType)
	}

	// Generate file hash
	fileHash, err := generateCheckSum(input.FileBytes)
	if err != nil {
		return nil, err
	}

	// Upload file to S3
	if input.ServiceName == constants.SERVICE_NAME_S3 {
		if err := a.uploadToS3(input.FileBytes, fileKey); err != nil {
			return nil, err
		}
	}

	// Insert record into DB
	// oldRecord, err := a.db.GetActiveStorageRecord(ctx, input.ModelType, int(input.ModelID), input.AttachmentFor, input.IsPrimary)
	// if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
	// 	return nil, err
	// }

	activeStorageRecord = dbModel.ActiveStorage{
		Filekey:       &fileKey,
		Filename:      &input.FileName,
		ContentType:   &input.ContentType,
		ByteSize:      utils.Int64ToPointer(int64(len(input.FileBytes))),
		Checksum:      &fileHash,
		ServiceName:   &input.ServiceName,
		ModelType:     &input.ModelType,
		ModelID:       &input.ModelID,
		AttachmentFor: &input.AttachmentFor,
		IsPrimary:     &input.IsPrimary,
	}

	// Update or insert the record
	// if errors.Is(err, gorm.ErrRecordNotFound) {
	// 	if _, err := a.db.CreateActiveStorageRecord(ctx, activeStorageRecord); err != nil {
	// 		return nil, err
	// 	}
	// } else {
	// 	activeStorageRecord.ID = oldRecord.ID
	// 	if _, err := a.db.UpdateActiveStorageRecord(ctx, activeStorageRecord); err != nil {
	// 		return nil, err
	// 	}
	// }

	if _, err := a.db.CreateActiveStorageRecord(ctx, activeStorageRecord); err != nil {
		return nil, err
	}

	// Return file key (path) in S3
	t := fmt.Sprintf("%v/%v", *activeStorageRecord.Filekey, *activeStorageRecord.Filename)
	return &t, nil
}

func (a *activeStorageService) UploadFile(ctx context.Context, input ActiveStorageUploadInput) (*string, error) {
	var (
		activeStorageRecord dbModel.ActiveStorage
		localFilePath       string //incase of local dir, saving filepath as filename
	)

	//validate serviceName
	if input.ServiceName != "local" && input.ServiceName != "S3" {
		return nil, fmt.Errorf("invalid value for service name")
	}

	//extract and validate file properties
	// validate file size
	if input.FileHeader.Size > constants.FILE_SIZE_LIMIT { //50MB
		return nil, fmt.Errorf("file size exceeds the limit, input file size: %v", input.FileHeader.Size)
	}
	// validate file type
	if !isAllowedMimeType(input.ContentType) {
		return nil, fmt.Errorf("invalid file type, input file type: %v", input.ContentType)
	}

	//read file
	file, err := input.FileHeader.Open()
	if err != nil {
		return nil, fmt.Errorf("error opening the file")
	}

	defer file.Close()

	// Read the file's content
	fileBytes, err := io.ReadAll(file)
	if err != nil {
		return nil, fmt.Errorf("unable to read file, error: %v", err)
	}

	//file-name
	fileName := strings.ReplaceAll(input.FileHeader.Filename, " ", "_")

	//Generate file key
	fileKey := genrateKey()

	//generate hash
	fileHash, err := generateCheckSum(fileBytes)
	if err != nil {
		return nil, err
	}

	if input.ServiceName == "S3" {
		if err := a.uploadToS3(fileBytes, fileKey); err != nil {
			return nil, err
		}
	}

	if input.ServiceName == "local" {
		localFilePath, err = a.uploadToPublicDir(fileBytes, fileName, input.PublicDir)
		if err != nil {
			return nil, err
		}
	}

	var oldRecord dbModel.ActiveStorage
	// To add multiple entries for article images for same resource_id and resource_type.
	if input.ModelType != "resource_image" {
		//make entry into db
		// check if attachment record already existis or not
		oldRecord, err = a.db.GetActiveStorageRecord(ctx, input.ModelType, int(input.ModelId), input.AttachmentFor, input.IsPrimary)
		if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, err
		}
	} else {
		err = gorm.ErrRecordNotFound
	}

	//setup DB Model
	activeStorageRecord = dbModel.ActiveStorage{
		Filekey:       &fileKey,
		Filename:      &fileName,
		ContentType:   &input.ContentType,
		ByteSize:      &input.FileHeader.Size,
		Checksum:      &fileHash,
		ServiceName:   &input.ServiceName,
		ModelType:     &input.ModelType,
		ModelID:       &input.ModelId,
		AttachmentFor: &input.AttachmentFor,
		IsPrimary:     &input.IsPrimary,
	}

	if *activeStorageRecord.ServiceName == "local" {
		activeStorageRecord.Filename = &localFilePath
	}

	if errors.Is(err, gorm.ErrRecordNotFound) {
		if _, err := a.db.CreateActiveStorageRecord(ctx, activeStorageRecord); err != nil {
			return nil, err
		}
	} else {
		activeStorageRecord.ID = oldRecord.ID
		if _, err := a.db.UpdateActiveStorageRecord(ctx, activeStorageRecord); err != nil {
			return nil, err
		}
	}
	t := fmt.Sprintf("%v/%v", *activeStorageRecord.Filekey, *activeStorageRecord.Filename)
	return &t, nil
}

func (a *activeStorageService) DownloadFile(ctx context.Context, input ActiveStorageDownloadInput) ([]byte, string, error) {
	var activeStorageRecord dbModel.ActiveStorage
	var fileContent []byte

	activeStorageRecord, err := a.db.GetActiveStorageRecordByKey(ctx, input.Filekey, input.FileName)
	if err != nil {
		return nil, "", err
	}

	fmt.Println("ServiceName---->", activeStorageRecord.ServiceName)
	// add handling for *activeStorageRecord.ServiceName == "local"

	if *&activeStorageRecord.ServiceName != nil {
		if *activeStorageRecord.ServiceName == "local" {
			fileContent, err = a.downloadFromPublicDir(*activeStorageRecord.Filekey)
			if err != nil {
				return nil, "", err
			}
		} else if *activeStorageRecord.ServiceName == "S3" {
			fileContent, err = a.downloadFromS3(*activeStorageRecord.Filekey)
			if err != nil {
				return nil, "", err
			}
		} else {
			return nil, "", fmt.Errorf("invalid service name, error: %v", *activeStorageRecord.ServiceName)
		}
	} else {
		return nil, "", fmt.Errorf("service name not found, error: %v", *activeStorageRecord.ServiceName)
	}

	//check file hash
	fileHash, err := generateCheckSum(fileContent)
	if err != nil {
		return nil, "", err
	}

	if fileHash != *activeStorageRecord.Checksum {
		return nil, "", fmt.Errorf("file is corrupted")
	}

	return fileContent, *activeStorageRecord.ContentType, nil

}

func (a *activeStorageService) GetURL(tempUrl string) string {
	return fmt.Sprintf("/public/api/v1/active_storage/%v", tempUrl)
}
func (a *activeStorageService) uploadToS3(filebytes []byte, fileKey string) error {
	//upload to s3
	cfg := config.AppSecrets

	awsSession, err := awsUtil.GetAwsUtils(cfg.Aws.AccessKey, cfg.Aws.SecretAccessKey, cfg.Aws.Region)
	if err != nil {
		return fmt.Errorf("unable to login into aws-account, error: %v", err)
	}
	_, err = awsUtil.S3Upload(awsSession, bytes.NewReader(filebytes), fileKey, constants.AWS_S3_ASSETS_BUCKET)
	if err != nil {
		return fmt.Errorf("unable to upload file into S3 bucket, error: %v", err)
	}

	return nil
}

func (a *activeStorageService) downloadFromS3(fileKey string) ([]byte, error) {
	cfg := config.AppSecrets

	awsSession, err := awsUtil.GetAwsUtils(cfg.Aws.AccessKey, cfg.Aws.SecretAccessKey, cfg.Aws.Region)
	if err != nil {
		return nil, fmt.Errorf("unable to login into aws-account, error: %v", err)
	}

	fmt.Println("bucket--->", constants.AWS_S3_ASSETS_BUCKET)

	fileContent, err := awsUtil.S3Download(awsSession, fileKey, constants.AWS_S3_ASSETS_BUCKET)
	if err != nil {
		return nil, fmt.Errorf("unable to download file from S3 bucket, error: %v", err)
	}

	return fileContent, nil
}

func (a *activeStorageService) uploadToPublicDir(filebytes []byte, filename string, publicDir string) (string, error) {

	// Ensure the directory exists
	if err := os.MkdirAll(publicDir, os.ModePerm); err != nil {
		return "", fmt.Errorf("unable to create public directory: %v", err)
	}

	// Create the file path (filename will be unique to avoid overwriting)
	filePath := filepath.Join(publicDir, filename)

	// Write the file bytes to the disk
	err := os.WriteFile(filePath, filebytes, 0644)
	if err != nil {
		return "", fmt.Errorf("unable to save file locally: %v", err)
	}

	return filePath, nil
}

func (a *activeStorageService) downloadFromPublicDir(filename string) ([]byte, error) {

	// Check if the file exists
	if _, err := os.Stat(filename); os.IsNotExist(err) {
		return nil, fmt.Errorf("file does not exist, error: %v", err)
	}

	// Read the file content into a byte slice
	content, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read file: %v", err)
	}

	return content, nil
}

func genrateKey() string {
	return uuid.New().String()
}

func generateCheckSum(fileBytes []byte) (string, error) {
	// Create a new SHA-256 hash
	hash := sha256.New()

	// Write the file content (byte slice) to the hash function
	_, err := hash.Write(fileBytes)
	if err != nil {
		fmt.Println("Error writing to hash:", err)
		return "", err
	}

	// Get the checksum in hexadecimal format
	checksum := hash.Sum(nil)
	return hex.EncodeToString(checksum), nil
}

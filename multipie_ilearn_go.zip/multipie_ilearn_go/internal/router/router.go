package router

import (
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/controller"
	"multipie_ilearn_go/internal/db"

	// "multipie_ilearn_go/internal/middleware/encryption"
	authMiddleware "multipie_ilearn_go/internal/middleware/auth"
	"multipie_ilearn_go/internal/middleware/encryption"
	securityMiddleware "multipie_ilearn_go/internal/middleware/security"

	"github.com/gin-gonic/gin"
)

func Init(controllerLayer controller.ControllerLayer, dbLayer db.DBLayer, cfg *config.SecretConfig) *gin.Engine {
	router := gin.New()
	//
	router.Use(securityMiddleware.SecurityHeadersMiddleware()) // api aslc point for security header
	// router.Use(encryption.EncryptResponse([]byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV)))
	//Recover server in case of panic
	router.Use(gin.Recovery())
	router.Use(gin.Logger())
	gin.EnableJsonDecoderDisallowUnknownFields()

	v1ControllerLayer := controllerLayer.GetV1ControllerLayer()
	adminV1ControllerLayer := controllerLayer.GetAdminControllerLayer().GetV1ControllerLayer()
	publicV1ControllerLayer := controllerLayer.GetPublicControllerLayer().GetV1ControllerLayer()
	publicGroup := router.Group("public")
	{
		v1Group := publicGroup.Group("api/v1")
		{
			activeStorageGroup := v1Group.Group("active_storage")
			{
				activeStorageGroup.GET("/:file_key/:file_name", publicV1ControllerLayer.DownloadFile)
			}
		}
	}
	//V1 router group
	v1Group := router.Group("api/v1")
	v1Group.Use(encryption.EncryptResponse([]byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV)))
	{
		v1Group.GET("/ping", v1ControllerLayer.HealthCheckHandler)
		v1Group.GET("/protected", authMiddleware.AuthMiddleware(dbLayer), v1ControllerLayer.HealthCheckHandler)

		courseGroup := v1Group.Group("/course", authMiddleware.AuthMiddleware(dbLayer))
		{
			// //TODO: CHANGE PARAMETER NAMES
			courseGroup.GET("/courseCategory/module/:category", v1ControllerLayer.GetCourseByCategory)
			courseGroup.GET("/courseCategory/module/content/:course", v1ControllerLayer.GetCourseContentHandler)

			courseGroup.GET("", v1ControllerLayer.GetCourseByCategory)
			courseGroup.GET("/:course_id", v1ControllerLayer.GetCourseDetails)
		}

		notificationGroup := v1Group.Group("/appNotifications")
		{
			notificationGroup.GET("", v1ControllerLayer.GetAllNotifications)
		}
		authGroup := v1Group.Group("/identity")
		{
			authGroup.POST("/icici/callback", v1ControllerLayer.IDirectCallback)
			authGroup.POST("idirect/login", v1ControllerLayer.IDirectLogin)
			authGroup.POST("/login", v1ControllerLayer.Login)
			authGroup.POST("/login/resend_otp", v1ControllerLayer.ResendOtp)
			authGroup.POST("/refresh_token", v1ControllerLayer.RefreshToken)
			authGroup.POST("/logout", v1ControllerLayer.Logout)
			authGroup.POST("/verify", v1ControllerLayer.Verify)
			authGroup.POST("/email/send_otp", authMiddleware.AuthMiddleware(dbLayer), v1ControllerLayer.SendEmailOtp)
			authGroup.POST("/email/verify_otp", authMiddleware.AuthMiddleware(dbLayer), v1ControllerLayer.VerifyEmailOtp)
			authGroup.POST("/email/resend_otp", authMiddleware.AuthMiddleware(dbLayer), v1ControllerLayer.ResendEmailOtp)
		}

		categoryGroup := v1Group.Group("category", authMiddleware.AuthMiddleware(dbLayer))
		{
			categoryGroup.GET("", v1ControllerLayer.GetCategories)
			categoryGroup.GET("/:category_id", v1ControllerLayer.GetCategoryByID)
			categoryGroup.GET("/filters", v1ControllerLayer.GetSubCategoriesByType)
			categoryGroup.GET("/secondary", v1ControllerLayer.GetSecondaryCategories)
		}

		courseModuleGroup := v1Group.Group("course_module", authMiddleware.AuthMiddleware(dbLayer))
		{
			courseModuleGroup.GET("", v1ControllerLayer.GetCourseModulesByCourseID)
			courseModuleGroup.GET("/:module_id", v1ControllerLayer.GetCourseModuleDetails)
		}

		infographicGroup := v1Group.Group("infographic", authMiddleware.AuthMiddleware(dbLayer))
		{
			infographicGroup.GET("", v1ControllerLayer.GetInfographics)
			infographicGroup.GET("/:infographic_id", v1ControllerLayer.GetInfographicByID)
		}
		resourceGroup := v1Group.Group("resource", authMiddleware.AuthMiddleware(dbLayer))
		{
			resourceGroup.GET("/:resource_id", v1ControllerLayer.GetResourceById)
			resourceGroup.GET("", v1ControllerLayer.GetResources)
			resourceGroup.GET("/related/:resource_id/:resource_type", v1ControllerLayer.GetRelatedResources)
		}
		newsGroup := v1Group.Group("news", authMiddleware.AuthMiddleware(dbLayer))
		{
			newsGroup.GET("/forYouStocks", v1ControllerLayer.GetForYouStocks)
			newsGroup.GET("/trending", v1ControllerLayer.GetTrendingNews)
		}
		quizGroup := v1Group.Group("quiz", authMiddleware.AuthMiddleware(dbLayer))
		{
			quizGroup.GET("", v1ControllerLayer.GetIndependentQuiz)
			quizGroup.GET("/:quiz_id", v1ControllerLayer.GetQuizByID)
			quizGroup.GET("/course", v1ControllerLayer.GetCourseQuiz)
			quizGroup.GET("/course/:course_id", v1ControllerLayer.GetQuizByCourseID)
			quizGroup.GET("/checkAnswer/:quiz_id", v1ControllerLayer.GetAnswersByQuizID)
			quizGroup.POST("/complete", v1ControllerLayer.GenerateCertificate)

		}

		quizAttemptGroup := v1Group.Group("quizAttempt", authMiddleware.AuthMiddleware(dbLayer))
		{
			quizAttemptGroup.GET("/:quiz_id", v1ControllerLayer.GetQuizAttempts)
			quizAttemptGroup.GET("/score/:quiz_id", v1ControllerLayer.GetQuizScore)
			quizAttemptGroup.POST("", v1ControllerLayer.CreateQuizAttempt)
			quizAttemptGroup.PUT("", v1ControllerLayer.UpdateQuizAttempt)

		}

		enrollmentGroup := v1Group.Group("enrollments", authMiddleware.AuthMiddleware(dbLayer))
		{
			enrollmentGroup.GET("", v1ControllerLayer.GetEnrollments)
			enrollmentGroup.GET("/:course_id", v1ControllerLayer.GetEnrollmentByCourseID)
			enrollmentGroup.POST("", v1ControllerLayer.CreateEnrollment)
			enrollmentGroup.PUT("", v1ControllerLayer.UpdateEnrollment)

		}
		userActivityGroup := v1Group.Group("user_activity", authMiddleware.AuthMiddleware(dbLayer))
		{
			userActivityGroup.POST("", v1ControllerLayer.CreateActivity)
			userActivityGroup.GET("", v1ControllerLayer.GetActivity)
		}

		statsGroup := v1Group.Group("stats", authMiddleware.AuthMiddleware(dbLayer))
		{
			statsGroup.PUT("", v1ControllerLayer.UpdateStats)
			statsGroup.GET("like_status", v1ControllerLayer.GetLikeStatus)
		}

		commentsGroup := v1Group.Group("comments", authMiddleware.AuthMiddleware(dbLayer))
		{
			commentsGroup.POST("", v1ControllerLayer.CreateComment)
			commentsGroup.GET("", v1ControllerLayer.GetComments)
		}

		glossaryGroup := v1Group.Group("glossary", authMiddleware.AuthMiddleware(dbLayer))
		{
			glossaryGroup.GET("", v1ControllerLayer.GetGlossaries)
			glossaryGroup.GET("/all", v1ControllerLayer.GetGlossariesWithoutPagination)

		}

		tagsGroup := v1Group.Group("tags", authMiddleware.AuthMiddleware(dbLayer))
		{
			tagsGroup.GET("", v1ControllerLayer.GetTag)
		}

		tagMappingGroup := v1Group.Group("tag_mapping", authMiddleware.AuthMiddleware(dbLayer))
		{
			tagMappingGroup.GET("", v1ControllerLayer.GetTagMapping)
			tagMappingGroup.GET("tags", v1ControllerLayer.GetTagsByModel)
		}

		bookmarkGroup := v1Group.Group("bookmark", authMiddleware.AuthMiddleware(dbLayer))
		{
			bookmarkGroup.GET("test", v1ControllerLayer.GetBookmarks)
			bookmarkGroup.GET("", v1ControllerLayer.GetBookmarksWithPagination)
			bookmarkGroup.POST("", v1ControllerLayer.CreateBookmark)
			bookmarkGroup.DELETE("", v1ControllerLayer.DeleteBookmark)
		}

		usersGroup := v1Group.Group("users", authMiddleware.AuthMiddleware(dbLayer))
		{
			usersGroup.GET("", v1ControllerLayer.GetUserByUID)
			usersGroup.PUT("", v1ControllerLayer.UpdateUsers)
		}

		certificateGroup := v1Group.Group("certificates", authMiddleware.AuthMiddleware(dbLayer))
		{
			certificateGroup.GET("", v1ControllerLayer.GetCertificateByModelType)
			certificateGroup.GET("/:model_type/:model_id", v1ControllerLayer.GetCertificateDatabyId)
		}

		progressAchievementGroup := v1Group.Group("progress_achievement", authMiddleware.AuthMiddleware(dbLayer))
		{
			progressAchievementGroup.GET("", v1ControllerLayer.GetInProgressCourses)
		}

		mutualFundsGroup := v1Group.Group("mutual_funds")
		{
			mutualFundsGroup.POST("/top_performer", v1ControllerLayer.GetTopPerformers)
			mutualFundsGroup.POST("/top_performer_filters", v1ControllerLayer.GetTopPerformerListFilters)
			mutualFundsGroup.GET("/mf_details/:schemecode", v1ControllerLayer.GetMFDetails)

		}

	}

	//Admin Group
	adminGroup := router.Group("admin") //TODO: Add admin middleware
	adminGroup.Use(encryption.EncryptResponse([]byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV)))
	{
		v1Group := adminGroup.Group("api/v1")
		{
			categoryGroup := v1Group.Group("category")
			{
				categoryGroup.GET("", adminV1ControllerLayer.GetCategories)
				categoryGroup.GET("/:category_id", adminV1ControllerLayer.GetCategoryByID)
				categoryGroup.POST("", adminV1ControllerLayer.CreateCategory)
				categoryGroup.PUT("", adminV1ControllerLayer.UpdateCategory)
				categoryGroup.DELETE("", adminV1ControllerLayer.DisableCategory)
				categoryGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateCategory)
				categoryGroup.POST("/batchUpdate", adminV1ControllerLayer.BulkUpdateCategory)
				categoryGroup.POST("/assetUpload", adminV1ControllerLayer.AssetUpload)

			}

			courseGroup := v1Group.Group("course")
			{
				courseGroup.GET("", adminV1ControllerLayer.GetCoursesByCategory)
				courseGroup.GET("/:course_id", adminV1ControllerLayer.GetCourseDetails)
				courseGroup.POST("", adminV1ControllerLayer.CreateCourse)
				courseGroup.PUT("", adminV1ControllerLayer.UpdateCourse)
				courseGroup.DELETE("", adminV1ControllerLayer.DisableCourse)
				courseGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateCourse)
				courseGroup.POST("/batchUpdate", adminV1ControllerLayer.BulkUpdateCourses)
				courseGroup.POST("/assetUpload", adminV1ControllerLayer.CourseAssetUpload)
			}

			resourceGroup := v1Group.Group("resource", authMiddleware.AuthMiddleware(dbLayer))
			{
				resourceGroup.GET("/:resource_id", adminV1ControllerLayer.GetResourceById)
				resourceGroup.GET("", adminV1ControllerLayer.GetResourcesByCategoryType)
				resourceGroup.POST("", adminV1ControllerLayer.CreateResource)
				resourceGroup.DELETE("", adminV1ControllerLayer.DisableResource)
				resourceGroup.PUT("", adminV1ControllerLayer.UpdateResource)
				resourceGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateResources)
				resourceGroup.POST("/batchUpdate", adminV1ControllerLayer.BatchUpdateResources)
				resourceGroup.POST("/assetUpload", adminV1ControllerLayer.ResourceAssetUpload)
			}

			courseModuleGroup := v1Group.Group("course_module", authMiddleware.AuthMiddleware(dbLayer))
			{
				courseModuleGroup.GET("", adminV1ControllerLayer.GetCourseModulesByCourseID)
				courseModuleGroup.GET("/:module_id", adminV1ControllerLayer.GetCourseModuleDetails)
				courseModuleGroup.POST("", adminV1ControllerLayer.CreateCourseModule)
				courseModuleGroup.PUT("", adminV1ControllerLayer.UpdateCourseModule)
				courseModuleGroup.DELETE("", adminV1ControllerLayer.DeleteCourseModule)
				courseModuleGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateCourseModule)
				courseModuleGroup.POST("/batchUpdate", adminV1ControllerLayer.BatchUpdateCourseModules)
			}

			infographicGroup := v1Group.Group("infographic", authMiddleware.AuthMiddleware(dbLayer))
			{
				infographicGroup.GET("", adminV1ControllerLayer.GetInfographics)
				infographicGroup.GET("/:infographic_id", adminV1ControllerLayer.GetInfographicByID)
				infographicGroup.POST("", adminV1ControllerLayer.CreateInfographic)
				infographicGroup.PUT("", adminV1ControllerLayer.UpdateInfographic)
				infographicGroup.DELETE("", adminV1ControllerLayer.DisableInfographic)
				infographicGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateInfographics)
				infographicGroup.POST("/batchUpdate", adminV1ControllerLayer.BatchUpdateInfographics)
			}

			infographicImagesGroup := v1Group.Group("infographic_images")
			{
				infographicImagesGroup.POST("", adminV1ControllerLayer.CreateInfographicImage)
				infographicImagesGroup.PUT("", adminV1ControllerLayer.UpdateInfographicImage)
				infographicImagesGroup.DELETE("", adminV1ControllerLayer.DeleteInfographicImage)
			}

			quizGroup := v1Group.Group("quiz")
			{
				quizGroup.GET("", adminV1ControllerLayer.GetIndependentQuiz)
				quizGroup.GET("/:quiz_id", adminV1ControllerLayer.GetQuizByID)
				quizGroup.GET("/course", adminV1ControllerLayer.GetCourseQuiz)
				quizGroup.GET("/course/:course_id", adminV1ControllerLayer.GetQuizByCourseID)
				quizGroup.POST("", adminV1ControllerLayer.CreateQuiz)
				quizGroup.PUT("", adminV1ControllerLayer.UpdateQuiz)
				quizGroup.DELETE("", adminV1ControllerLayer.DisableQuiz)
				quizGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateQuizzes)
				quizGroup.POST("/batchUpdate", adminV1ControllerLayer.BatchUpdateQuizzes)
			}

			quizAttemptGroup := v1Group.Group("quizAttempt")
			{
				quizAttemptGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateQuizAttempts)
			}

			userActivityGroup := v1Group.Group("userActivity")
			{
				userActivityGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateUserActivity)
			}

			questionsGroup := v1Group.Group("questions")
			{
				questionsGroup.GET("", adminV1ControllerLayer.GetQuestionByQuizID)
				questionsGroup.POST("", adminV1ControllerLayer.CreateQuestion)
				questionsGroup.PUT("", adminV1ControllerLayer.UpdateQuestion)
				questionsGroup.DELETE("", adminV1ControllerLayer.DeleteQuestion)
				questionsGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateQuestions)
				questionsGroup.POST("/batchUpdate", adminV1ControllerLayer.BatchUpdateQuestions)
				questionsGroup.POST("/assetUpload", adminV1ControllerLayer.QuestionAssetUploader)
			}

			usersGroup := v1Group.Group("users")
			{
				usersGroup.GET("", adminV1ControllerLayer.GetUsers)
				usersGroup.POST("", adminV1ControllerLayer.CreateUsers)
				usersGroup.PUT("", adminV1ControllerLayer.UpdateUsers)
				usersGroup.PUT("/:user_id/lock_user", adminV1ControllerLayer.LockUser)
				usersGroup.PUT("/:user_id/unlock_user", adminV1ControllerLayer.UnLockUser)
				usersGroup.PUT("/:user_id/make_admin", adminV1ControllerLayer.MakeAdmin)
				usersGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateUser)
				usersGroup.PUT("/status", authMiddleware.AuthMiddleware(dbLayer), adminV1ControllerLayer.UpdateStatus)

			}

			enrollmentGroup := v1Group.Group("enrollment")
			{
				enrollmentGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateEnrollment)
			}

			commentsGroup := v1Group.Group("comments", authMiddleware.AuthMiddleware(dbLayer))
			{
				commentsGroup.GET("", adminV1ControllerLayer.GetComments)
				commentsGroup.PUT("", adminV1ControllerLayer.ModifyComment)
				commentsGroup.POST("", adminV1ControllerLayer.ReplyComment)
				commentsGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateComment)

			}
			bookmarkGroup := v1Group.Group("bookmark", authMiddleware.AuthMiddleware(dbLayer))
			{
				bookmarkGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateBookmark)
			}

			likesGroup := v1Group.Group("like", authMiddleware.AuthMiddleware(dbLayer))
			{
				likesGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateLike)
			}

			activeStorageGroup := v1Group.Group("active_storage", authMiddleware.AuthMiddleware(dbLayer))
			{
				activeStorageGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateActiveStorageRecords)
			}

			glossaryGroup := v1Group.Group("glossary")
			{
				glossaryGroup.GET("", adminV1ControllerLayer.GetGlossaries)
				glossaryGroup.POST("", adminV1ControllerLayer.CreateGlossary)
				glossaryGroup.PUT("", adminV1ControllerLayer.UpdateGlossary)
				glossaryGroup.DELETE("", adminV1ControllerLayer.DeleteGlossary)
				glossaryGroup.POST("/batchCreate", adminV1ControllerLayer.BatchInsertGlossary)
				glossaryGroup.POST("/batchUpdate", adminV1ControllerLayer.BatchUpdateGlossaries)

			}

			tagsGroup := v1Group.Group("tags")
			{
				tagsGroup.POST("", adminV1ControllerLayer.CreateTag)
				tagsGroup.PUT("", adminV1ControllerLayer.UpdateTag)
				tagsGroup.DELETE("", adminV1ControllerLayer.DeleteTag)
				tagsGroup.GET("", adminV1ControllerLayer.GetTag)
				tagsGroup.POST("/batchcreate", adminV1ControllerLayer.BatchCreateTag)
				tagsGroup.POST("/batchupdate", adminV1ControllerLayer.BatchUpdateTag)

			}

			tagMappingGroup := v1Group.Group("tag_mapping")
			{
				tagMappingGroup.POST("", adminV1ControllerLayer.CreateTagMapping)
				tagMappingGroup.PUT("", adminV1ControllerLayer.UpdateTagMapping)
				tagMappingGroup.DELETE("", adminV1ControllerLayer.DeleteTagMapping)
			}

			certificateGroup := v1Group.Group("certificate")
			{
				certificateGroup.POST("", adminV1ControllerLayer.CreateCertificate)
				certificateGroup.POST("/batchCreate", adminV1ControllerLayer.BatchCreateCertificate)

			}

		}
	}

	return router
}

package admin

import (
	v1 "multipie_ilearn_go/internal/controller/admin/v1"
	"multipie_ilearn_go/internal/db"
)

type adminController struct {
	v1 v1.V1ControllerLayer
}

type AdminControllerLayer interface {
	GetV1ControllerLayer() v1.V1ControllerLayer
}

func NewControllerLayer(db db.DBLayer) AdminControllerLayer {
	return &adminController{
		v1.NewV1ControllerLayer(db),
	}
}

func (s *adminController) GetV1ControllerLayer() v1.V1ControllerLayer {
	return s.v1
}

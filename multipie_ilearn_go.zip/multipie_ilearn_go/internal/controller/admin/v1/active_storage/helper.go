package activestorage

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/activeStorage"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (q *activeStorageController) batchCreateActiveStorageHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount      int
		batchNo       int
		activestorage []dbModel.ActiveStorage
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 12 || len(row) > 13 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		activeStorage, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		// quiz.Visible = utils.BoolToPointer(true)

		activestorage = append(activestorage, activeStorage)
		if len(activestorage) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateActiveStorageRecords(ctx, activestorage); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			activestorage = []dbModel.ActiveStorage{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(activestorage) > 0 {
		if err := q.db.BatchCreateActiveStorageRecords(ctx, activestorage); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (c *activeStorageController) extractDataFromFile(row []string) (dbModel.ActiveStorage, error) {
	var (
		activeStorage dbModel.ActiveStorage
	)

	switch {
	case len(row) == 12:
		fileKey := strings.TrimSpace(row[0])
		if len(fileKey) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  filekey, error")
		}
		activeStorage.Filekey = &fileKey

		//validate model type
		filename := strings.TrimSpace(row[1])
		if len(filename) == 0 {
			return activeStorage, fmt.Errorf("value for filename cannot be blank")
		}
		activeStorage.Filename = &filename

		ContentType := strings.TrimSpace(row[2])
		if len(ContentType) == 0 {
			return activeStorage, fmt.Errorf("value for content Type cannot be blank")
		}
		activeStorage.ContentType = &ContentType

		byteSizeStr := strings.TrimSpace(row[3])
		if len(byteSizeStr) != 0 {
			ByteSize, err := strconv.Atoi(byteSizeStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for  byte size, error: %v", err)
			}

			activeStorage.ByteSize = utils.Int64ToPointer(int64(ByteSize))
		}

		metadataStr := strings.TrimSpace(row[4])
		if len(metadataStr) != 0 {
			var metadata dbModel.ActiveStorageMetaData

			err := json.Unmarshal([]byte(metadataStr), &metadata)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid additional data :%v", err)

			}
			activeStorage.Metadata = &metadata
		}

		checksum := strings.TrimSpace(row[5])
		if len(checksum) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  checksum, error")
		}
		activeStorage.Checksum = &checksum

		modelType := strings.TrimSpace(row[6])
		if len(modelType) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  modelType, error")
		}
		activeStorage.ModelType = &modelType

		modelIdStr := strings.TrimSpace(row[7])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}

			activeStorage.ModelID = utils.Int64ToPointer(int64(modelId))
		}

		attachmentFor := strings.TrimSpace(row[8])
		if len(attachmentFor) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  modelType, error")
		}
		activeStorage.AttachmentFor = &attachmentFor

		isPrimaryStr := strings.TrimSpace(row[9])
		if len(isPrimaryStr) == 0 {
			return activeStorage, fmt.Errorf("value for is primary,cannot be blank")
		}
		isprimary, err := strconv.ParseBool(isPrimaryStr)
		if err != nil {
			return activeStorage, fmt.Errorf("invalid value for is primary, error: %v", err)
		}
		activeStorage.IsPrimary = &isprimary

		createdAtStr := strings.TrimSpace(row[10])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			activeStorage.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[11])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			activeStorage.UpdatedAt = &updatedAt
		}

		return activeStorage, nil

	case len(row) == 13:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return activeStorage, fmt.Errorf("failed to convert into integer: %v", err)
		}
		activeStorage.ID = utils.Int64ToPointer(int64(id))

		fileKey := strings.TrimSpace(row[0])
		if len(fileKey) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  filekey, error")
		}
		activeStorage.Filekey = &fileKey

		//validate model type
		filename := strings.TrimSpace(row[1])
		if len(filename) == 0 {
			return activeStorage, fmt.Errorf("value for filename cannot be blank")
		}
		activeStorage.Filename = &filename

		ContentType := strings.TrimSpace(row[2])
		if len(ContentType) == 0 {
			return activeStorage, fmt.Errorf("value for content Type cannot be blank")
		}
		activeStorage.ContentType = &ContentType

		byteSizeStr := strings.TrimSpace(row[3])
		if len(byteSizeStr) != 0 {
			ByteSize, err := strconv.Atoi(byteSizeStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for  byte size, error: %v", err)
			}

			activeStorage.ByteSize = utils.Int64ToPointer(int64(ByteSize))
		}

		metadataStr := strings.TrimSpace(row[4])
		if len(metadataStr) != 0 {
			var metadata dbModel.ActiveStorageMetaData

			err := json.Unmarshal([]byte(metadataStr), &metadata)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid additional data :%v", err)

			}
			activeStorage.Metadata = &metadata
		}

		checksum := strings.TrimSpace(row[5])
		if len(checksum) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  checksum, error")
		}
		activeStorage.Checksum = &checksum

		modelType := strings.TrimSpace(row[6])
		if len(modelType) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  modelType, error")
		}
		activeStorage.ModelType = &modelType

		modelIdStr := strings.TrimSpace(row[7])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}

			activeStorage.ModelID = utils.Int64ToPointer(int64(modelId))
		}

		attachmentFor := strings.TrimSpace(row[8])
		if len(attachmentFor) == 0 {
			return activeStorage, fmt.Errorf("invalid value for  modelType, error")
		}
		activeStorage.AttachmentFor = &attachmentFor

		isPrimaryStr := strings.TrimSpace(row[9])
		if len(isPrimaryStr) == 0 {
			return activeStorage, fmt.Errorf("value for is primary,cannot be blank")
		}
		isprimary, err := strconv.ParseBool(isPrimaryStr)
		if err != nil {
			return activeStorage, fmt.Errorf("invalid value for is primary, error: %v", err)
		}
		activeStorage.IsPrimary = &isprimary

		createdAtStr := strings.TrimSpace(row[10])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			activeStorage.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[11])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return activeStorage, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			activeStorage.UpdatedAt = &updatedAt
		}

		return activeStorage, nil

	default:
		fmt.Printf("invalid number of row")
	}

	return activeStorage, nil

}

package tags

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type tagsController struct {
	db db.DBLayer
}

type TagsControllerGroup interface {
	CreateTag(ctx *gin.Context)
	BatchCreateTag(ctx *gin.Context)
	BatchUpdateTag(ctx *gin.Context)
	UpdateTag(ctx *gin.Context)
	DeleteTag(ctx *gin.Context)
	GetTag(ctx *gin.Context)
}

func NewTagsControllerGroup(db db.DBLayer) TagsControllerGroup {
	return &tagsController{
		db: db,
	}
}

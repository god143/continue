package tags

import (
	dbModel "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// create
func (t *tagsController) CreateTag(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateTagsRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := t.createTagHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("tags created", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *tagsController) UpdateTag(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateTagsRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	err := c.updateTagHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(" Tags updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *tagsController) DeleteTag(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DeleteTagRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	err := c.deleteTagHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(" Tags deleted successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *tagsController) GetTag(ctx *gin.Context) {
	var (
		resp        *utils.Response
		getTagsResp []dbModel.Tags
	)

	getTagsResp, err := c.getTagHelper(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getTagsResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (t *tagsController) BatchCreateTag(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = t.batchCreateTagsHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of tags is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (t *tagsController) BatchUpdateTag(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = t.batchUpdateTagsHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch updation of tags is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

package tags

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"mime/multipart"
	"multipie_ilearn_go/internal/db"
	dbModelTag "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/logger"
	"os"

	// "multipie_ilearn_go/internal/utils"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- USER MOCK METHODS ---
type MockDB struct {
	mock.Mock
	db.DBLayer
}

func TestMain(m *testing.M) {
	// Initialize logger once for the package to prevent nil pointer panics in helper.go
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

func (m *MockDB) GetTag(ctx context.Context) ([]dbModelTag.Tags, error) {
	args := m.Called(ctx)

	// If the first argument is nil, return a nil slice and the error
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}

	return args.Get(0).([]dbModelTag.Tags), args.Error(1)
}

func (m *MockDB) BatchCreateTag(ctx context.Context, tags []dbModelTag.Tags) error {
	args := m.Called(ctx, tags)
	return args.Error(0)
}

func (m *MockDB) CreateTag(ctx context.Context, tag *dbModelTag.Tags) error {
	args := m.Called(ctx, tag)
	return args.Error(0)
}

func (m *MockDB) UpdateTag(ctx context.Context, tag *dbModelTag.Tags) error {
	args := m.Called(ctx, tag)
	return args.Error(0)
}

func (m *MockDB) DeleteTag(ctx context.Context, tag *dbModelTag.Tags) error {
	args := m.Called(ctx, tag)
	return args.Error(0)
}

func (m *MockDB) BatchUpdateTag(ctx context.Context, tags []dbModelTag.Tags) error {
	args := m.Called(ctx, tags)
	return args.Error(0)
}

// func ptrInt64(i int64) *int64    { return &i }
// func ptrString(s string) *string { return &s }

func TestTagController_Extended(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("UpdateTag - Binding Failure", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Missing "id" which is required in UpdateTagsRequest
		c.Request, _ = http.NewRequest("PUT", "/", strings.NewReader(`{"key": "test"}`))

		ctrl.UpdateTag(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("BatchCreate - Logic Coverage", func(t *testing.T) {
		// 1. Initialize Mock properly
		mDB := new(MockDB)

		// 2. Initialize Controller with the Mock
		ctrl := &tagsController{db: mDB}

		csvContent := generateCSV(105, false)

		// Setup expectations
		mDB.On("BatchCreateTag", mock.Anything, mock.Anything).Return(nil).Twice()

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Use the helper to create the request
		req, err := createMultipartRequest("file", "test.csv", csvContent)
		assert.NoError(t, err)
		c.Request = req

		// 3. Call the controller
		ctrl.BatchCreateTag(c)

		assert.Equal(t, http.StatusOK, w.Code)
		mDB.AssertExpectations(t)
	})

}

// createMultipartRequest generates a mock HTTP request containing a CSV file
func createMultipartRequest(fieldName, fileName, content string) (*http.Request, error) {
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)

	// Create the form file part
	part, err := writer.CreateFormFile(fieldName, fileName)
	if err != nil {
		return nil, err
	}

	// Write the CSV content into the part
	_, err = part.Write([]byte(content))
	if err != nil {
		return nil, err
	}

	// Close writer to set the terminating boundary
	err = writer.Close()
	if err != nil {
		return nil, err
	}

	// Create the request with the correct Content-Type header (including boundary)
	req, err := http.NewRequest("POST", "/batch", body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())

	return req, nil
}

// generateCSV is a helper to create strings for testing batch limits (e.g., 100+ rows)
func generateCSV(rows int, includeId bool) string {
	res := "id,key\n"
	if !includeId {
		res = "key\n"
	}
	for i := 1; i <= rows; i++ {
		if includeId {
			res += fmt.Sprintf("%d,Tag%d\n", i, i)
		} else {
			res += fmt.Sprintf("Tag%d\n", i)
		}
	}
	return res
}

func TestTagController_CRUD_Coverage(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("CreateTag - Success", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}

		// Expectation: use mock.Anything for the second argument
		// because the controller creates the pointer internally
		mDB.On("CreateTag", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Must provide a valid JSON that matches CreateTagsRequest
		body := `{"key": "NewTag"}`
		c.Request, _ = http.NewRequest("POST", "/", strings.NewReader(body))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.CreateTag(c)

		assert.Equal(t, http.StatusOK, w.Code)
		mDB.AssertExpectations(t)
	})

	t.Run("DeleteTag - Success", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}
		mDB.On("DeleteTag", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("DELETE", "/", strings.NewReader(`{"id": 123}`))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.DeleteTag(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("BatchUpdate - Success 105 rows", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}

		// Use generateCSV(105, true) to get ID and Key columns
		csvContent := generateCSV(105, true)

		// Setup expectations: .Twice() because 105 rows = 1 batch of 100 + 1 batch of 5
		mDB.On("BatchUpdateTag", mock.Anything, mock.Anything).Return(nil).Twice()

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		req, err := createMultipartRequest("file", "update.csv", csvContent)
		assert.NoError(t, err)
		c.Request = req

		ctrl.BatchUpdateTag(c)

		assert.Equal(t, http.StatusOK, w.Code)
		mDB.AssertExpectations(t)
	})
	t.Run("BatchUpdate - Invalid ID Column", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// "ABC" triggers the strconv.Atoi error branch
		req, _ := createMultipartRequest("file", "test.csv", "id,key\nABC,Tag1")
		c.Request = req

		ctrl.BatchUpdateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchUpdate - Wrong Column Count", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Sending only 1 column when 2 are expected (id, key)
		req, _ := createMultipartRequest("file", "test.csv", "id\n1")
		c.Request = req

		ctrl.BatchUpdateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchCreate - Blank Key Validation", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// " " triggers the "value of key field cannot be blank" error in extractDataFromFile
		req, _ := createMultipartRequest("file", "test.csv", "key\n ")
		c.Request = req

		ctrl.BatchCreateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

}
func TestTagController_Errors(t *testing.T) {
	t.Run("GetTag - DB Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}

		// Explicitly return nil for the slice and a real error
		mDB.On("GetTag", mock.Anything).Return(nil, errors.New("db down"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/tags", nil)

		ctrl.GetTag(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchCreate - FormFile Missing", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// No file attached to request
		c.Request, _ = http.NewRequest("POST", "/", nil)

		ctrl.BatchCreateTag(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
	t.Run("CreateTag - Database Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}
		mDB.On("CreateTag", mock.Anything, mock.Anything).Return(errors.New("db error"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/", strings.NewReader(`{"key": "fail"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.CreateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchUpdate - DB Flush Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}

		// Mock the DB to fail on the first batch attempt
		mDB.On("BatchUpdateTag", mock.Anything, mock.Anything).Return(errors.New("connection lost"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := createMultipartRequest("file", "test.csv", "id,key\n1,Tag")
		c.Request = req

		ctrl.BatchUpdateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("UpdateTag - DB Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}
		mDB.On("UpdateTag", mock.Anything, mock.Anything).Return(errors.New("update failed"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("PUT", "/", strings.NewReader(`{"id": 1, "key": "fail"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.UpdateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("DeleteTag - DB Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}
		mDB.On("DeleteTag", mock.Anything, mock.Anything).Return(errors.New("delete failed"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("DELETE", "/", strings.NewReader(`{"id": 1}`))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.DeleteTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchUpdate - CSV Read Error", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Malformed CSV (unclosed quote) triggers the reader.Read() error branch
		malformedCSV := "id,key\n1,\"unclosed quote"
		req, _ := createMultipartRequest("file", "test.csv", malformedCSV)
		c.Request = req

		ctrl.BatchUpdateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("BatchUpdate - Final Batch DB Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}

		// 5 rows means the loop finishes and hits the "Insert remaining tags" block
		csvContent := generateCSV(5, true)
		mDB.On("BatchUpdateTag", mock.Anything, mock.Anything).Return(errors.New("final batch failed"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := createMultipartRequest("file", "test.csv", csvContent)
		c.Request = req

		ctrl.BatchUpdateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("BatchCreate - CSV Read Error", func(t *testing.T) {
		ctrl := &tagsController{db: new(MockDB)}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Malformed CSV triggers reader.Read() error in batchCreateTagsHelper
		req, _ := createMultipartRequest("file", "test.csv", "key\n\"unclosed")
		c.Request = req
		ctrl.BatchCreateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchCreate - Final Batch DB Failure", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &tagsController{db: mDB}
		// 5 rows triggers the "Insert remaining tags" block at the end of the helper
		mDB.On("BatchCreateTag", mock.Anything, mock.Anything).Return(errors.New("final fail"))
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := createMultipartRequest("file", "test.csv", "key\nTag1\nTag2")
		c.Request = req
		ctrl.BatchCreateTag(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

}

// --- BENCHMARKS ---

func BenchmarkBatchCreateTag_Large(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	// Mock accepts any batch of tags
	mDB.On("BatchCreateTag", mock.Anything, mock.Anything).Return(nil)
	ctrl := &tagsController{db: mDB}

	csvData := generateCSV(200, false)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := createMultipartRequest("file", "bench.csv", csvData)
		c.Request = req
		ctrl.BatchCreateTag(c)
	}
}

func BenchmarkUpdateTag_JSON(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("UpdateTag", mock.Anything, mock.Anything).Return(nil)
	ctrl := &tagsController{db: mDB}

	payload := []byte(`{"id": 1, "key": "UpdatedKey"}`)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(payload))
		ctrl.UpdateTag(c)
	}
}

func BenchmarkBatchUpdateTag_Large(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("BatchUpdateTag", mock.Anything, mock.Anything).Return(nil)
	ctrl := &tagsController{db: mDB}
	csvData := generateCSV(500, true)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := createMultipartRequest("file", "bench.csv", csvData)
		c.Request = req
		ctrl.BatchUpdateTag(c)
	}
}

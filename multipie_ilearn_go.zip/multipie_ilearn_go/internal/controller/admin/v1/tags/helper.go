package tags

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

/*
createTagHelper.....create tags name in database
*/
func (t *tagsController) createTagHelper(ctx context.Context, request CreateTagsRequest) error {

	tag := &dbModel.Tags{
		Key: request.Key,
		ID:  request.ID,
	}

	err := t.db.CreateTag(ctx, tag)
	if err != nil {
		logger.Error(ctx, "unable to create tag entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to create tag entry in database")
	}
	return nil
}

/*
updateTagHelper ....update tag of particular id in database
*/
func (c *tagsController) updateTagHelper(ctx context.Context, request UpdateTagsRequest) error {

	tag := &dbModel.Tags{
		ID:  request.Id,
		Key: request.Key,
	}

	err := c.db.UpdateTag(ctx, tag)
	if err != nil {
		logger.Error(ctx, "unable to update tag entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update tag entry in database")
	}
	return nil
}

/*
deleteTagHelper ....delete tag/key of particular id in database
*/
func (c *tagsController) deleteTagHelper(ctx context.Context, request DeleteTagRequest) error {

	tag := &dbModel.Tags{
		ID: request.Id,
	}

	err := c.db.DeleteTag(ctx, tag)
	if err != nil {
		logger.Error(ctx, "unable to delete tag entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete tag entry in database")
	}
	return nil
}

/*
getTagHelper gives all tags name from tags table
*/
func (c *tagsController) getTagHelper(ctx context.Context) ([]dbModel.Tags, error) {

	tags, err := c.db.GetTag(ctx)
	if err != nil {
		logger.Error(ctx, "unable to fetch tags in database", zap.Error(err), zap.Any("tags not found", tags))
		return nil, errors.New("unable to fetch tags in database")
	}
	return tags, err
}

/*
batchCreateTagsHelper....create tags through csv file in database
*/
func (t *tagsController) batchCreateTagsHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		tags     []dbModel.Tags
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) != 1 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		tag, err := t.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		tags = append(tags, tag)
		if len(tags) == 100 {
			batchNo++ // Increment batch number
			if err := t.db.BatchCreateTag(ctx, tags); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			tags = []dbModel.Tags{} // Reset the list
		}
	}

	// Insert remaining tags if any
	if len(tags) > 0 {
		if err := t.db.BatchCreateTag(ctx, tags); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
		logger.Debug(ctx, fmt.Sprintf("Final batch %d successfully", batchNo))
	}

	return nil
}

/*
extractDataFromFile....extract data field from csv file
*/
func (t *tagsController) extractDataFromFile(row []string) (dbModel.Tags, error) {
	var tag dbModel.Tags

	//validate key
	key := strings.TrimSpace(row[0])
	if len(key) == 0 {
		return tag, fmt.Errorf("value of key field cannot be blank")
	}
	tag.Key = &key

	return tag, nil
}

/*
batchUpdateTagsHelper....update tags of given id through csv file in database
*/
func (t *tagsController) batchUpdateTagsHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		tags     []dbModel.Tags
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) != 2 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		//extract ID
		id, err := strconv.Atoi(strings.TrimSpace(row[0]))
		if err != nil {
			return errors.New("invalid value for id column")
		}

		// Extract data from CSV row
		tag, err := t.extractDataFromFile(row[1:])
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		tag.ID = utils.Int64ToPointer((int64(id)))

		tags = append(tags, tag)
		if len(tags) == 100 {
			batchNo++ // Increment batch number
			if err := t.db.BatchUpdateTag(ctx, tags); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			tags = []dbModel.Tags{} // Reset the list
		}
	}

	// Insert remaining tags if any
	if len(tags) > 0 {
		if err := t.db.BatchUpdateTag(ctx, tags); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
		logger.Debug(ctx, fmt.Sprintf("Final batch %d successfully", batchNo))
	}

	return nil
}

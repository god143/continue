package tags

type TagsResult struct {
	ID  *int64  `json:"id"`
	Key *string `json:"key"`
}

// get list of all tags
type GetTagListResponse struct {
	Key *string `json:"key"`
}

// createTags request
type CreateTagsRequest struct {
	ID  *int64  `json:"id"`
	Key *string `json:"key" binding:"required"`
}

// update request
type UpdateTagsRequest struct {
	Id  *int64  `json:"id" binding:"required"`
	Key *string `json:"key" binding:"required"`
}

// delete request
type DeleteTagRequest struct {
	Id *int64 `json:"id" binding:"required"`
}

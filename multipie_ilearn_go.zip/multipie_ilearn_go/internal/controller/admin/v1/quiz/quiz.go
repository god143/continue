package quiz

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (q *quizController) GetCourseQuiz(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getCourseResp, err := q.getQuizByCourseHelper(ctx, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quizzes for course", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quizzes"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(getCourseResp, nil))
}

func (q *quizController) GetIndependentQuiz(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}
	getIndependentQuiz, err := q.getIndependentQuizHelper(ctx, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch independent quizzes", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch independent quizzes"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(getIndependentQuiz, nil))
}

func (q *quizController) GetQuizByID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuizByIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid quizId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	quizResult, err := q.getQuizByIDHelper(ctx, request, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quiz questions", zap.Int64("quizId", request.ID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quiz by ID"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(quizResult, nil))
}

func (q *quizController) GetQuizByCourseID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuizByCourseIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid courseId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	quizResult, err := q.getQuizByCourseIDHelper(ctx, request, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quizzes for course", zap.Int64("courseId", request.CourseID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quiz by course ID"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(quizResult, nil))
}

func (q *quizController) CreateQuiz(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateQuizRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createQuizResp, err := q.createQuizHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createQuizResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *quizController) UpdateQuiz(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateQuizRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := q.updateQuizHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("quiz updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *quizController) DisableQuiz(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DisableQuizRequest
	)

	if err := ctx.BindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := q.disableQuizHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("quiz disabled successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *quizController) BatchCreateQuizzes(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = q.batchCreateQuizzesHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of quizzes is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *quizController) BatchUpdateQuizzes(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = q.batchUpdateQuizzesHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch updation of quizzes is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

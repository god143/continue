package quiz

import (
	"multipie_ilearn_go/internal/constants"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	dbModelQuiz "multipie_ilearn_go/internal/db/quiz"
)

type GetQuizByIDRequest struct {
	ID int64 `uri:"quiz_id" binding:"required"`
}

type GetQuizByCourseIDRequest struct {
	CourseID int64 `uri:"course_id" binding:"required"`
}

type QuizResult struct {
	QuizWithUserState
	Questions []dbModelQuestions.Question `json:"questions"`
}

type QuizWithUserState struct {
	dbModelQuiz.Quiz
	HasCheckedAnswer bool   `json:"has_checked_answer"`
	HasUserPassed    bool   `json:"has_user_passed"`
	HasAttempted     bool   `json:"has_attempted"`
	AttemptID        *int64 `json:"attempt_id"`
}

type CreateQuizRequest struct {
	Name            *string                      `json:"name" binding:"required"`
	CourseID        *int64                       `json:"course_id"`
	PassPercentage  *int64                       `json:"pass_percentage" binding:"required"`
	NumQuestions    *int64                       `json:"num_questions" binding:"required"`
	CertificateID   *int64                       `json:"certificate_id"`
	Duration        *int64                       `json:"duration" binding:"required"`
	DifficultyLevel *constants.QuizDiffcultyEnum `json:"difficulty_level" binding:"required"`
}

type CreateQuizResponse struct {
	ID int64 `json:"id"`
}
type UpdateQuizRequest struct {
	ID              *int64                       `json:"id" binding:"required"`
	Name            *string                      `json:"name"`
	CourseID        *int64                       `json:"course_id"`
	PassPercentage  *int64                       `json:"pass_percentage"`
	NumQuestions    *int64                       `json:"num_questions"`
	CertificateID   *int64                       `json:"certificate_id"`
	Visible         *bool                        `json:"visible"`
	Duration        *int64                       `json:"duration"`
	DifficultyLevel *constants.QuizDiffcultyEnum `json:"difficulty_level"`
}

type DisableQuizRequest struct {
	ID int64 `json:"quiz_id" binding:"required"`
}

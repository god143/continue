package quiz

import (
	"bytes"
	"context"
	"errors"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	dbModelQuiz "multipie_ilearn_go/internal/db/quiz"
	dbModelQuizAttempt "multipie_ilearn_go/internal/db/quizAttempts"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- MOCKS ---

type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) GetCourseQuiz(ctx context.Context, v *bool) ([]dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, v)
	return args.Get(0).([]dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockDBLayer) GetIndependentQuiz(ctx context.Context, v *bool) ([]dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, v)
	return args.Get(0).([]dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockDBLayer) GetQuizById(ctx context.Context, id int64, v *bool) (dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, id, v)
	return args.Get(0).(dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockDBLayer) GetQuizCourseId(ctx context.Context, id int64, v *bool) (dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, id, v)
	return args.Get(0).(dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockDBLayer) GetQuizAttemptStatus(ctx context.Context, uID, qID int64) (*dbModelQuizAttempt.QuizAttemptStatus, error) {
	args := m.Called(ctx, uID, qID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModelQuizAttempt.QuizAttemptStatus), args.Error(1)
}
func (m *MockDBLayer) GetQuestionsByQuizId(ctx context.Context, id int64, n *int64) ([]dbModelQuestions.Question, error) {
	args := m.Called(ctx, id, n)
	return args.Get(0).([]dbModelQuestions.Question), args.Error(1)
}
func (m *MockDBLayer) CreateQuiz(ctx context.Context, q *dbModelQuiz.Quiz) (*dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, q)
	return args.Get(0).(*dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockDBLayer) UpdateQuiz(ctx context.Context, q *dbModelQuiz.Quiz) (*dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, q)
	return args.Get(0).(*dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockDBLayer) DisableQuiz(ctx context.Context, id int64) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockDBLayer) BatchCreateQuiz(ctx context.Context, q []dbModelQuiz.Quiz) error {
	return m.Called(ctx, q).Error(0)
}
func (m *MockDBLayer) BatchUpdateQuiz(ctx context.Context, q []dbModelQuiz.Quiz) error {
	return m.Called(ctx, q).Error(0)
}

func TestMain(m *testing.M) {
	// Initialize logger once for the package to prevent nil pointer panics in helper.go
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- UNIT TESTS ---

func TestGetQuizByID(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		quizIDParam    string
		setUserID      bool
		mockDBFunc     func(m *MockDBLayer)
		expectedStatus int
	}{
		{
			name:        "Success Path",
			quizIDParam: "10",
			setUserID:   true,
			mockDBFunc: func(m *MockDBLayer) {
				qid := int64(10)
				num := int64(5)
				m.On("GetQuizById", mock.Anything, qid, mock.Anything).Return(dbModelQuiz.Quiz{ID: &qid, NumQuestions: &num}, nil)
				m.On("GetQuizAttemptStatus", mock.Anything, int64(1), qid).Return(&dbModelQuizAttempt.QuizAttemptStatus{HasAttempted: true}, nil)
				m.On("GetQuestionsByQuizId", mock.Anything, qid, &num).Return([]dbModelQuestions.Question{{}}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Invalid ID Format",
			quizIDParam:    "abc",
			setUserID:      true,
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Unauthenticated",
			quizIDParam:    "10",
			setUserID:      false,
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:        "Database Error",
			quizIDParam: "10",
			setUserID:   true,
			mockDBFunc: func(m *MockDBLayer) {
				m.On("GetQuizById", mock.Anything, int64(10), mock.Anything).Return(dbModelQuiz.Quiz{}, errors.New("db crash"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockDB := new(MockDBLayer)
			if tt.mockDBFunc != nil {
				tt.mockDBFunc(mockDB)
			}
			ctrl := NewQuizController(mockDB)

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Params = []gin.Param{{Key: "quiz_id", Value: tt.quizIDParam}}
			if tt.setUserID {
				c.Set("userId", int64(1))
			}

			ctrl.GetQuizByID(c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestBatchCreateQuizzes_Coverage(t *testing.T) {
	mockDB := new(MockDBLayer)
	ctrl := NewQuizController(mockDB)

	t.Run("No File Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/batch", nil)
		ctrl.BatchCreateQuizzes(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Invalid CSV Columns", func(t *testing.T) {
		w := httptest.NewRecorder()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		part.Write([]byte("header\nInvalidRow,OnlyThreeCols"))
		writer.Close()

		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/batch", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.BatchCreateQuizzes(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestExtractDataFromFile_BranchCoverage(t *testing.T) {
	q := &quizController{}

	t.Run("Valid 7 Column Row", func(t *testing.T) {
		row := []string{"Test Quiz", "1", "80", "10", "100", "60", "intermediate"}
		quiz, err := q.extractDataFromFile(row)
		assert.NoError(t, err)
		assert.Equal(t, "Test Quiz", *quiz.Name)
	})

	t.Run("Invalid CourseID Int", func(t *testing.T) {
		row := []string{"Test Quiz", "invalid", "80", "10", "100", "60", "intermediate"}
		_, err := q.extractDataFromFile(row)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "invalid value for course_id")
	})
}
func TestQuizController_AdditionalEndpoints(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("GetCourseQuiz_Success", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)
		qid := int64(5)

		mockDB.On("GetCourseQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz{{ID: &qid}}, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, int64(1), qid).Return(&dbModelQuizAttempt.QuizAttemptStatus{HasAttempted: true}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", int64(1))
		ctrl.GetCourseQuiz(c)

		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("UpdateQuiz_Success", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)

		mockDB.On("UpdateQuiz", mock.Anything, mock.Anything).Return(&dbModelQuiz.Quiz{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		payload := `{"id": 1, "name": "Updated Name"}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(payload))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.UpdateQuiz(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("DisableQuiz_Success", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)
		mockDB.On("DisableQuiz", mock.Anything, int64(1)).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(`{"quiz_id": 1}`))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.DisableQuiz(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestBatchUpdateQuizzes_Coverage(t *testing.T) {
	mockDB := new(MockDBLayer)
	ctrl := NewQuizController(mockDB)

	t.Run("BatchUpdate_Success", func(t *testing.T) {
		w := httptest.NewRecorder()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "update.csv")
		// Header + 11 columns (ID + 7 data cols + 3 extra/padding as per your logic)
		csvContent := "id,name,course,pass,num,cert,dur,diff,ext,ext,ext\n1,Quiz,1,80,10,1,60,beginner,x,x,x"
		part.Write([]byte(csvContent))
		writer.Close()

		mockDB.On("BatchUpdateQuiz", mock.Anything, mock.Anything).Return(nil)

		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/batch-update", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.BatchUpdateQuizzes(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestExtractDataFromFile_8Column_Coverage(t *testing.T) {
	q := &quizController{}

	t.Run("Valid 8 Column Row", func(t *testing.T) {
		row := []string{"101", "Quiz 8", "1", "70", "15", "5", "45", "advanced"}
		quiz, err := q.extractDataFromFile(row)
		assert.NoError(t, err)
		assert.Equal(t, int64(101), *quiz.ID)
		assert.Equal(t, "Quiz 8", *quiz.Name)
	})

	t.Run("8 Column Missing ID", func(t *testing.T) {
		row := []string{"", "Quiz 8", "1", "70", "15", "5", "45", "advanced"}
		_, err := q.extractDataFromFile(row)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "quizId cannot be empty")
	})
}

func TestQuizController_FinalCoveragePush(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("GetIndependentQuiz_Success", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)
		qid := int64(7)
		mockDB.On("GetIndependentQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz{{ID: &qid}}, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, int64(1), qid).Return(&dbModelQuizAttempt.QuizAttemptStatus{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", int64(1))
		ctrl.GetIndependentQuiz(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("GetQuizByCourseID_Success", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)
		qid, cid, num := int64(10), int64(5), int64(5)

		mockDB.On("GetQuizCourseId", mock.Anything, cid, mock.Anything).Return(dbModelQuiz.Quiz{ID: &qid, NumQuestions: &num}, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, int64(1), qid).Return(&dbModelQuizAttempt.QuizAttemptStatus{}, nil)
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qid, &num).Return([]dbModelQuestions.Question{{}}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "course_id", Value: "5"}}
		c.Set("userId", int64(1))
		ctrl.GetQuizByCourseID(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("CreateQuiz_InternalError_Branch", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)
		// Trigger the if err != nil after createQuizHelper
		mockDB.On("CreateQuiz", mock.Anything, mock.Anything).Return((*dbModelQuiz.Quiz)(nil), errors.New("db error"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		payload := `{"name":"Fail","pass_percentage":80,"num_questions":1,"duration":10,"difficulty_level":"beginner"}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(payload))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.CreateQuiz(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	// t.Run("BatchCreate_FullLoop_And_FinalInsert", func(t *testing.T) {
	// 	mockDB := new(MockDBLayer)
	// 	ctrl := NewQuizController(mockDB)

	// 	mockDB.On("BatchCreateQuiz", mock.Anything, mock.Anything).Return(nil)

	// 	w := httptest.NewRecorder()
	// 	body := &bytes.Buffer{}
	// 	writer := multipart.NewWriter(body)
	// 	part, _ := writer.CreateFormFile("file", "test.csv")
	// 	// FIXED: Added exactly 7 columns to match your 'extractDataFromFile' logic
	// 	// Format: name, course_id, pass_percentage, num_questions, certificate_id, duration, difficulty
	// 	part.Write([]byte("header_row_is_skipped\nQuizA,1,80,10,1,60,beginner"))
	// 	writer.Close()

	// 	c, _ := gin.CreateTestContext(w)
	// 	c.Request, _ = http.NewRequest("POST", "/", body)
	// 	c.Request.Header.Set("Content-Type", writer.FormDataContentType())

	// 	ctrl.BatchCreateQuizzes(c)
	// 	assert.Equal(t, http.StatusOK, w.Code)
	// })
	t.Run("CreateQuiz_Success_Full", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		ctrl := NewQuizController(mockDB)
		qid := int64(100)

		mockDB.On("CreateQuiz", mock.Anything, mock.Anything).Return(&dbModelQuiz.Quiz{ID: &qid}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Valid JSON matching CreateQuizRequest binding tags
		payload := `{"name":"New Quiz","pass_percentage":80,"num_questions":10,"duration":30,"difficulty_level":"beginner"}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(payload))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.CreateQuiz(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

}
func TestBatchProcessing_HighCoverage(t *testing.T) {
	mockDB := new(MockDBLayer)
	ctrl := NewQuizController(mockDB)

	t.Run("BatchCreate_101_Rows_Trigger_Batching", func(t *testing.T) {
		w := httptest.NewRecorder()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")

		// Header
		part.Write([]byte("name,course,pass,num,cert,dur,diff\n"))
		// Write 101 rows to trigger the if len(quizzes) == 100 block AND the final residual block
		for i := 0; i < 101; i++ {
			part.Write([]byte("Quiz,1,80,10,1,60,beginner\n"))
		}
		writer.Close()

		// Expect two calls: one for the batch of 100, one for the final 1
		mockDB.On("BatchCreateQuiz", mock.Anything, mock.MatchedBy(func(q []dbModelQuiz.Quiz) bool {
			return len(q) == 100
		})).Return(nil).Once()
		mockDB.On("BatchCreateQuiz", mock.Anything, mock.MatchedBy(func(q []dbModelQuiz.Quiz) bool {
			return len(q) == 1
		})).Return(nil).Once()

		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.BatchCreateQuizzes(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestHelper_ErrorBranches(t *testing.T) {
	// Targeting the missing % in updateQuizHelper and disableQuizHelper
	mockDB := new(MockDBLayer)
	q := &quizController{db: mockDB}

	t.Run("UpdateHelper_Error", func(t *testing.T) {
		mockDB.On("UpdateQuiz", mock.Anything, mock.Anything).Return((*dbModelQuiz.Quiz)(nil), errors.New("fail"))
		err := q.updateQuizHelper(context.Background(), UpdateQuizRequest{ID: utils.Int64ToPointer(1)})
		assert.Error(t, err)
	})

	t.Run("DisableHelper_Error", func(t *testing.T) {
		mockDB.On("DisableQuiz", mock.Anything, int64(1)).Return(errors.New("fail"))
		err := q.disableQuizHelper(context.Background(), DisableQuizRequest{ID: 1})
		assert.Error(t, err)
	})
}

func TestQuizController_CompleteCoverage(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mockDB := new(MockDBLayer)
	ctrl := NewQuizController(mockDB)

	t.Run("GetQuizByCourseID_Success", func(t *testing.T) {
		qid, cid, num := int64(10), int64(5), int64(5)
		mockDB.On("GetQuizCourseId", mock.Anything, cid, mock.Anything).Return(dbModelQuiz.Quiz{ID: &qid, NumQuestions: &num}, nil).Once()
		mockDB.On("GetQuizAttemptStatus", mock.Anything, int64(1), qid).Return(&dbModelQuizAttempt.QuizAttemptStatus{}, nil).Once()
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qid, &num).Return([]dbModelQuestions.Question{{}}, nil).Once()

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "course_id", Value: "5"}}
		c.Set("userId", int64(1))
		ctrl.GetQuizByCourseID(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("BatchCreate_101_Rows_Success", func(t *testing.T) {
		mockDB.On("BatchCreateQuiz", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		part.Write([]byte("name,course,pass,num,cert,dur,diff\n"))
		for i := 0; i < 101; i++ {
			part.Write([]byte("Quiz,1,80,10,1,60,beginner\n"))
		}
		writer.Close()

		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())
		ctrl.BatchCreateQuizzes(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("BatchUpdate_101_Rows_Success", func(t *testing.T) {
		mockDB.On("BatchUpdateQuiz", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		// id + 7 columns + 3 extra = 11 columns
		part.Write([]byte("id,name,course,pass,num,cert,dur,diff,x,x,x\n"))
		for i := 0; i < 101; i++ {
			part.Write([]byte("1,Quiz,1,80,10,1,60,beginner,x,x,x\n"))
		}
		writer.Close()

		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())
		ctrl.BatchUpdateQuizzes(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestHelper_FinalErrorPaths(t *testing.T) {
	mockDB := new(MockDBLayer)
	q := &quizController{db: mockDB}

	t.Run("BatchCreate_DB_Failure", func(t *testing.T) {
		mockDB.On("BatchCreateQuiz", mock.Anything, mock.Anything).Return(errors.New("db fail"))

		// Create a small valid multipart file to avoid nil panic
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		part.Write([]byte("h\nQ,1,80,10,1,60,beginner"))
		writer.Close()

		req, _ := http.NewRequest("POST", "/", body)
		req.Header.Set("Content-Type", writer.FormDataContentType())
		file, _, _ := req.FormFile("file")
		defer file.Close()

		err := q.batchCreateQuizzesHelper(context.Background(), file)
		assert.Error(t, err)
	})
}

func TestQuizController_ChaosSuite(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mockDB := new(MockDBLayer)
	ctrl := NewQuizController(mockDB)
	ctx, _ := gin.CreateTestContext(httptest.NewRecorder())
	ctx.Set("userId", int64(1))

	t.Run("GetCourseQuiz_DB_Failure", func(t *testing.T) {
		mockDB.On("GetCourseQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz(nil), errors.New("fail")).Once()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", int64(1))
		ctrl.GetCourseQuiz(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("GetIndependentQuiz_DB_Failure", func(t *testing.T) {
		mockDB.On("GetIndependentQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz(nil), errors.New("fail")).Once()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", int64(1))
		ctrl.GetIndependentQuiz(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("FetchQuestions_Failure_Branch", func(t *testing.T) {
		// This hits the 40% missing in fetchQuestionsFromDB
		mockDB.On("GetQuestionsByQuizId", mock.Anything, mock.Anything, mock.Anything).Return([]dbModelQuestions.Question(nil), errors.New("fail")).Once()
		q := &quizController{db: mockDB}
		_, err := q.fetchQuestionsFromDB(context.Background(), 1, 5)
		assert.Error(t, err)
	})

	t.Run("UpdateQuiz_Helper_Failure", func(t *testing.T) {
		mockDB.On("UpdateQuiz", mock.Anything, mock.Anything).Return((*dbModelQuiz.Quiz)(nil), errors.New("fail")).Once()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		payload := `{"id":1}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(payload))
		c.Request.Header.Set("Content-Type", "application/json")
		ctrl.UpdateQuiz(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchUpdate_Helper_Failure", func(t *testing.T) {
		// Targets the 47% in BatchUpdateQuizzes controller
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// No file attached triggers the controller's first error branch
		c.Request, _ = http.NewRequest("POST", "/", nil)
		ctrl.BatchUpdateQuizzes(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

func TestBatchHelpers_AdditionalErrorPaths(t *testing.T) {
	mockDB := new(MockDBLayer)
	q := &quizController{db: mockDB}

	t.Run("BatchUpdate_InvalidID_Column", func(t *testing.T) {
		// FIXED: Exactly 11 columns to satisfy both csv.Reader and your logic
		// Format: ID, Name, CourseID, Pass%, NumQ, CertID, Visible, Dur, Diff, Pad, Pad
		csvContent := "id,name,course,pass,num,cert,visible,dur,diff,ext1,ext2\n" +
			"not-an-int,q,1,80,10,1,true,60,beginner,x,x"

		buf := &bytes.Buffer{}
		mw := multipart.NewWriter(buf)
		part, _ := mw.CreateFormFile("file", "test.csv")
		part.Write([]byte(csvContent))
		mw.Close()

		req, _ := http.NewRequest("POST", "/", buf)
		req.Header.Set("Content-Type", mw.FormDataContentType())
		file, _, _ := req.FormFile("file")
		defer file.Close()

		err := q.batchUpdateQuizzesHelper(context.Background(), file)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "invalid value for id column")
	})
}

func TestExtractDataFromFile_ValidationGauntlet(t *testing.T) {
	q := &quizController{}

	tests := []struct {
		name string
		row  []string
	}{
		{"7-Col Blank Name", []string{"", "1", "80", "10", "1", "60", "beginner"}},
		{"7-Col Invalid Pass %", []string{"Quiz", "1", "abc", "10", "1", "60", "beginner"}},
		{"7-Col Invalid NumQ", []string{"Quiz", "1", "80", "abc", "1", "60", "beginner"}},
		{"8-Col Missing ID", []string{"", "Quiz", "1", "80", "10", "1", "60", "beginner"}},
		{"8-Col Invalid ID", []string{"abc", "Quiz", "1", "80", "10", "1", "60", "beginner"}},
		{"Invalid Difficulty", []string{"Quiz", "1", "80", "10", "1", "60", "impossible"}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := q.extractDataFromFile(tt.row)
			assert.Error(t, err)
		})
	}
}

// --- BENCHMARKS ---
func BenchmarkCSVExtraction(b *testing.B) {
	q := &quizController{}
	row := []string{"1", "Bench Quiz", "10", "80", "20", "1", "60", "intermediate"}
	for i := 0; i < b.N; i++ {
		_, _ = q.extractDataFromFile(row)
	}
}
func BenchmarkFullQuizFlow(b *testing.B) {
	mockDB := new(MockDBLayer)
	ctrl := NewQuizController(mockDB)
	qid, num := int64(1), int64(5)
	mockDB.On("GetQuizById", mock.Anything, mock.Anything, mock.Anything).Return(dbModelQuiz.Quiz{ID: &qid, NumQuestions: &num}, nil)
	mockDB.On("GetQuizAttemptStatus", mock.Anything, mock.Anything, mock.Anything).Return(&dbModelQuizAttempt.QuizAttemptStatus{}, nil)
	mockDB.On("GetQuestionsByQuizId", mock.Anything, mock.Anything, mock.Anything).Return([]dbModelQuestions.Question{}, nil)

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Params = []gin.Param{{Key: "quiz_id", Value: "1"}}
	c.Set("userId", int64(1))

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetQuizByID(c)
	}
}

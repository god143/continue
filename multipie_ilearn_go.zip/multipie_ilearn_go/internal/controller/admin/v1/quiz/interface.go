package quiz

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type quizController struct {
	db db.DBLayer
}

type QuizControllerGroup interface {
	GetCourseQuiz(ctx *gin.Context)
	GetIndependentQuiz(ctx *gin.Context)
	GetQuizByID(ctx *gin.Context)
	GetQuizByCourseID(ctx *gin.Context)
	CreateQuiz(ctx *gin.Context)
	UpdateQuiz(ctx *gin.Context)
	DisableQuiz(ctx *gin.Context)
	BatchCreateQuizzes(ctx *gin.Context)
	BatchUpdateQuizzes(ctx *gin.Context)
}

func NewQuizController(db db.DBLayer) QuizControllerGroup {
	return &quizController{
		db: db,
	}
}

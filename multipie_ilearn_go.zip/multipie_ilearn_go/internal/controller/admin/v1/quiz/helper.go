package quiz

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	dbModelQuiz "multipie_ilearn_go/internal/db/quiz"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (q *quizController) getQuizByCourseHelper(ctx context.Context, userID int64) ([]QuizWithUserState, error) {
	quizzes, err := q.db.GetCourseQuiz(ctx, utils.BoolToPointer(true))
	if err != nil {
		return nil, err
	}

	var result []QuizWithUserState
	for _, quiz := range quizzes {
		state := QuizWithUserState{Quiz: quiz}
		status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
		if err == nil && status != nil {
			state.HasUserPassed = status.HasUserPassed
			state.HasCheckedAnswer = status.HasCheckedAnswer
			state.HasAttempted = status.HasAttempted
			state.AttemptID = status.AttemptID
		}
		result = append(result, state)
	}

	return result, nil
}

func (q *quizController) getIndependentQuizHelper(ctx context.Context, userID int64) ([]QuizWithUserState, error) {
	quizzes, err := q.db.GetIndependentQuiz(ctx, utils.BoolToPointer(true))
	if err != nil {
		return nil, err
	}

	var result []QuizWithUserState
	for _, quiz := range quizzes {
		state := QuizWithUserState{Quiz: quiz}
		status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
		if err == nil && status != nil {
			state.HasUserPassed = status.HasUserPassed
			state.HasCheckedAnswer = status.HasCheckedAnswer
			state.HasAttempted = status.HasAttempted
			state.AttemptID = status.AttemptID
		}
		result = append(result, state)
	}

	return result, nil
}

func (q *quizController) getQuizByIDHelper(ctx context.Context, request GetQuizByIDRequest, userID int64) (*QuizResult, error) {

	quiz, err := q.db.GetQuizById(ctx, request.ID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database", zap.Error(err), zap.Int64("ID", request.ID))
		return nil, err
	}

	quizResult := &QuizResult{
		QuizWithUserState: QuizWithUserState{Quiz: quiz},
	}

	status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
	if err == nil && status != nil {
		quizResult.HasUserPassed = status.HasUserPassed
		quizResult.HasCheckedAnswer = status.HasCheckedAnswer
		quizResult.HasAttempted = status.HasAttempted
		quizResult.AttemptID = status.AttemptID
	}

	questions, err := q.fetchQuestionsFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		return nil, err
	}

	quizResult.Questions = questions
	return quizResult, nil
}

func (q *quizController) getQuizByCourseIDHelper(ctx context.Context, request GetQuizByCourseIDRequest, userID int64) (*QuizResult, error) {
	quiz, err := q.db.GetQuizCourseId(ctx, request.CourseID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database by courseID", zap.Error(err), zap.Int64("ID", request.CourseID))
		return nil, err
	}

	quizResult := &QuizResult{
		QuizWithUserState: QuizWithUserState{Quiz: quiz},
	}

	status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
	if err == nil && status != nil {
		quizResult.HasUserPassed = status.HasUserPassed
		quizResult.HasCheckedAnswer = status.HasCheckedAnswer
		quizResult.HasAttempted = status.HasAttempted
		quizResult.AttemptID = status.AttemptID
	}

	questions, err := q.fetchQuestionsFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		return nil, err
	}

	quizResult.Questions = questions
	return quizResult, nil
}

func (q *quizController) createQuizHelper(ctx context.Context, request CreateQuizRequest) (CreateQuizResponse, error) {
	var resp CreateQuizResponse

	quiz := &dbModelQuiz.Quiz{
		Name:            request.Name,
		CourseID:        request.CourseID,
		PassPercentage:  request.PassPercentage,
		NumQuestions:    request.NumQuestions,
		Visible:         utils.BoolToPointer(true), // Default to true
		CertificateID:   request.CertificateID,
		Duration:        request.Duration,
		DifficultyLevel: request.DifficultyLevel,
	}

	quiz, err := q.db.CreateQuiz(ctx, quiz)
	if err != nil {
		logger.Error(ctx, "Unable to create quiz", zap.Error(err))
		return resp, errors.New("unable to create quiz")
	}

	resp = CreateQuizResponse{
		ID: *quiz.ID,
	}

	return resp, nil
}

func (q *quizController) updateQuizHelper(ctx context.Context, request UpdateQuizRequest) error {
	quiz := &dbModelQuiz.Quiz{
		ID:              request.ID,
		Name:            request.Name,
		CourseID:        request.CourseID,
		PassPercentage:  request.PassPercentage,
		NumQuestions:    request.NumQuestions,
		Visible:         request.Visible,
		CertificateID:   request.CertificateID,
		Duration:        request.Duration,
		DifficultyLevel: request.DifficultyLevel,
	}

	_, err := q.db.UpdateQuiz(ctx, quiz)
	if err != nil {
		logger.Error(ctx, "unable to update quiz entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update quiz entry in database")
	}

	return nil
}

func (q *quizController) disableQuizHelper(ctx context.Context, request DisableQuizRequest) error {
	err := q.db.DisableQuiz(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to disable quiz in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to disable quiz entry in database")
	}

	return nil
}

func (q *quizController) batchCreateQuizzesHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		quizzes  []dbModelQuiz.Quiz
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 7 || len(row) > 8 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		quiz, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		quiz.Visible = utils.BoolToPointer(true)

		quizzes = append(quizzes, quiz)
		if len(quizzes) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateQuiz(ctx, quizzes); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			quizzes = []dbModelQuiz.Quiz{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(quizzes) > 0 {
		if err := q.db.BatchCreateQuiz(ctx, quizzes); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (q *quizController) batchUpdateQuizzesHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		quizzes  []dbModelQuiz.Quiz
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) != 11 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		//extract ID
		id, err := strconv.Atoi(strings.TrimSpace(row[0]))
		if err != nil {
			return errors.New("invalid value for id column")
		}

		// Extract data from CSV row
		quiz, err := q.extractDataFromFile(row[1:])
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		quiz.ID = utils.Int64ToPointer(int64(id))

		quizzes = append(quizzes, quiz)
		if len(quizzes) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchUpdateQuiz(ctx, quizzes); err != nil {
				logger.Error(ctx, "batch updation failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch updation failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			quizzes = []dbModelQuiz.Quiz{} // Reset the list
		}
	}

	// update remaining quiz if any
	if len(quizzes) > 0 {
		if err := q.db.BatchUpdateQuiz(ctx, quizzes); err != nil {
			logger.Error(ctx, "batch updation failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch updation failed for final batch")
		}
	}
	return nil
}

func (q *quizController) fetchQuestionsFromDB(ctx context.Context, quizId int64, numOfQuestions int64) ([]dbModelQuestions.Question, error) {
	question, err := q.db.GetQuestionsByQuizId(ctx, quizId, &numOfQuestions)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database", zap.Error(err))
		return nil, err
	}
	return question, nil
}

func (q *quizController) extractDataFromFile(row []string) (dbModelQuiz.Quiz, error) {
	var quiz dbModelQuiz.Quiz
	switch {
	case len(row) == 7:
		//validate name
		name := strings.TrimSpace(row[0])
		if len(name) == 0 {
			return quiz, fmt.Errorf("value of name field cannot be blank")
		}

		quiz.Name = &name

		//validate courseId
		courseIdStr := strings.TrimSpace(row[1])
		if len(courseIdStr) != 0 {
			courseId, err := strconv.Atoi(courseIdStr)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for course_id, error: %v", err)
			}

			quiz.CourseID = utils.Int64ToPointer(int64(courseId))
		} else {
			quiz.CourseID = nil
		}

		//validate pass percentage
		passPercentageStr := strings.TrimSpace(row[2])
		if len(passPercentageStr) == 0 {
			return quiz, fmt.Errorf("value for pass_percentage field cannot be blank")
		}

		passPercentage, err := strconv.Atoi(passPercentageStr)
		if err != nil {
			return quiz, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
		}

		quiz.PassPercentage = utils.Int64ToPointer(int64(passPercentage))

		//validate number of questions
		numQuestionsStr := strings.TrimSpace(row[3])
		if len(numQuestionsStr) == 0 {
			return quiz, fmt.Errorf("value for num_questions field cannot be blank")
		}

		numQuestions, err := strconv.Atoi(numQuestionsStr)
		if err != nil {
			return quiz, fmt.Errorf("invalid value for num_questions, error: %v", err)
		}

		quiz.NumQuestions = utils.Int64ToPointer(int64(numQuestions))

		//validate certificate id
		certificateIdStr := strings.TrimSpace(row[4])
		if len(certificateIdStr) != 0 {
			certificateId, err := strconv.Atoi(certificateIdStr)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for certificate_id, error: %v", err)
			}

			quiz.CertificateID = utils.Int64ToPointer(int64(certificateId))
		}

		//validate duration
		durationStr := strings.TrimSpace(row[5])
		if len(durationStr) != 0 {
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for duration column,error: %v", err)
			}
			quiz.Duration = utils.Int64ToPointer(int64(duration))
		}

		//validate diffculty level
		diffcultyLevel := strings.TrimSpace(row[6])
		if len(diffcultyLevel) != 0 {
			diffcultyLevel, err := validateQuizDiffcultyLevel(diffcultyLevel)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for course diffculty level, error: %v", err)
			}

			quiz.DifficultyLevel = &diffcultyLevel
		}
	case len(row) == 8:
		// quizid
		quizId := strings.TrimSpace(row[0])
		if len(quizId) != 0 {
			id, err := strconv.Atoi(quizId)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for quizId, error: %v", err)
			}
			quiz.ID = utils.Int64ToPointer(int64(id))
		} else {
			return quiz, fmt.Errorf("quizId cannot be empty")
		}

		//validate name
		name := strings.TrimSpace(row[1])
		if len(name) == 0 {
			return quiz, fmt.Errorf("value of name field cannot be blank")
		}

		quiz.Name = &name

		//validate courseId
		courseIdStr := strings.TrimSpace(row[2])
		if len(courseIdStr) != 0 {
			courseId, err := strconv.Atoi(courseIdStr)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for course_id, error: %v", err)
			}

			quiz.CourseID = utils.Int64ToPointer(int64(courseId))
		} else {
			quiz.CourseID = nil
		}

		//validate pass percentage
		passPercentageStr := strings.TrimSpace(row[3])
		if len(passPercentageStr) == 0 {
			return quiz, fmt.Errorf("value for pass_percentage field cannot be blank")
		}

		passPercentage, err := strconv.Atoi(passPercentageStr)
		if err != nil {
			return quiz, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
		}

		quiz.PassPercentage = utils.Int64ToPointer(int64(passPercentage))

		//validate number of questions
		numQuestionsStr := strings.TrimSpace(row[4])
		if len(numQuestionsStr) == 0 {
			return quiz, fmt.Errorf("value for num_questions field cannot be blank")
		}

		numQuestions, err := strconv.Atoi(numQuestionsStr)
		if err != nil {
			return quiz, fmt.Errorf("invalid value for num_questions, error: %v", err)
		}

		quiz.NumQuestions = utils.Int64ToPointer(int64(numQuestions))

		//validate certificate id
		certificateIdStr := strings.TrimSpace(row[5])
		if len(certificateIdStr) != 0 {
			certificateId, err := strconv.Atoi(certificateIdStr)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for certificate_id, error: %v", err)
			}

			quiz.CertificateID = utils.Int64ToPointer(int64(certificateId))
		}

		//validate duration
		durationStr := strings.TrimSpace(row[6])
		if len(durationStr) != 0 {
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for duration column,error: %v", err)
			}
			quiz.Duration = utils.Int64ToPointer(int64(duration))
		}

		//validate diffculty level
		diffcultyLevel := strings.TrimSpace(row[7])
		if len(diffcultyLevel) != 0 {
			diffcultyLevel, err := validateQuizDiffcultyLevel(diffcultyLevel)
			if err != nil {
				return quiz, fmt.Errorf("invalid value for course diffculty level, error: %v", err)
			}

			quiz.DifficultyLevel = &diffcultyLevel
		}
	}

	return quiz, nil

}

func validateQuizDiffcultyLevel(diffcultyLevel string) (constants.QuizDiffcultyEnum, error) {
	return constants.ParseQuizDiffcultyEnum(diffcultyLevel)
}

package questions

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type questionsController struct {
	db db.DBLayer
}

type QuestionsControllerGroup interface {
	GetQuestionByQuizID(ctx *gin.Context)
	CreateQuestion(ctx *gin.Context)
	UpdateQuestion(ctx *gin.Context)
	DeleteQuestion(ctx *gin.Context)
	BatchCreateQuestions(ctx *gin.Context)
	BatchUpdateQuestions(ctx *gin.Context)
	QuestionAssetUploader(ctx *gin.Context)
}

func NewQuestionsController(db db.DBLayer) QuestionsControllerGroup {
	return &questionsController{
		db: db,
	}
}

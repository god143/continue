package questions

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (q *questionsController) GetQuestionByQuizID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuestionByQuizIDRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid quizId value"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	questions, err := q.getQuestionByQuizIDHelper(ctx, request)
	if err != nil {
		logger.Error(ctx, "unable to fetch quizzes for course", zap.Int64("courseId", request.QuizID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quiz by course ID"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(questions, nil))
}

func (q *questionsController) CreateQuestion(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateQuestionRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createQuestionResp, err := q.createQuestionHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createQuestionResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *questionsController) UpdateQuestion(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateQuestionRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := q.updateQuestionHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("question updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *questionsController) DeleteQuestion(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DeleteQuestionRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid question ID format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := q.deleteQuestionHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("question deleted successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *questionsController) BatchCreateQuestions(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	defer file.Close()

	err = q.batchInsertHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch insertion of questions is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *questionsController) BatchUpdateQuestions(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	defer file.Close()

	err = q.batchUpdateHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch update of questions is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *questionsController) QuestionAssetUploader(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request AssetUploadRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err), zap.Any("requestBody", request))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	assetUploadResponse, err := q.questionAssetUploadHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(assetUploadResponse, nil)
	ctx.JSON(http.StatusOK, resp)
}

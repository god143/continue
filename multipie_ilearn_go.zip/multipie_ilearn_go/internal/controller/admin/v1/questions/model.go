package questions

import "mime/multipart"

type CreateQuestionRequest struct {
	QuizID        *int64         `json:"quiz_id" binding:"required"`
	QuestionText  *string        `json:"question_text" binding:"required"`
	QuestionType  *string        `json:"question_type" binding:"required"`
	ImageURL      *string        `json:"image_url,omitempty"`
	Answers       *AnswerRequest `json:"answers" binding:"required"`
	CorrectAnswer *string        `json:"correct_answer" binding:"required"`
}

type AnswerRequest struct {
	Options *[]string `json:"options" binding:"required"`
}

type UpdateQuestionRequest struct {
	ID            *int64         `json:"id" binding:"required"`
	QuizID        *int64         `json:"quiz_id"`
	QuestionText  *string        `json:"question_text"`
	QuestionType  *string        `json:"question_type"`
	ImageURL      *string        `json:"image_url,omitempty"`
	Answers       *AnswerRequest `json:"answers"`
	CorrectAnswer *string        `json:"correct_answer"`
}

type DeleteQuestionRequest struct {
	ID *int64 `json:"question_id" binding:"required"`
}

type CreateQuestionResponse struct {
	ID int64 `json:"id"`
}

type AssetUploadRequest struct {
	QuestionId *int64                `form:"question_id" binding:"required"`
	AssetFile  *multipart.FileHeader `form:"asset_file" binding:"required"` // For the uploaded file
}

type AssetUploadResponse struct {
	Path string `json:"path"`
}

type GetQuestionByQuizIDRequest struct {
	QuizID int64 `form:"quiz_id" binding:"required"`
}

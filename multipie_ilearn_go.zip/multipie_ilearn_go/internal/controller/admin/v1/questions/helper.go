package questions

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/question"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (q *questionsController) getQuestionByQuizIDHelper(ctx context.Context, request GetQuestionByQuizIDRequest) ([]dbModel.Question, error) {
	questions, err := q.db.GetQuestionsByQuizId(ctx, request.QuizID, nil)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database by quizID", zap.Error(err), zap.Int64("ID", request.QuizID))
		return nil, err
	}

	return questions, nil
}
func (q *questionsController) createQuestionHelper(ctx context.Context, request CreateQuestionRequest) (CreateQuestionResponse, error) {
	var (
		resp CreateQuestionResponse
	)

	questionType, err := q.validateQuestionType(request.QuestionType)
	if err != nil {
		logger.Error(ctx, "invalid value for question type", zap.Error(err), zap.Any("input value", request.QuestionType))
		return resp, fmt.Errorf("invalid value for question type, error: %v", err)
	}

	if q.validateOptions(*request.Answers.Options) {
		return resp, fmt.Errorf("at least one answer option must be provided")
	}

	if !q.validateAnswerOptions(*request.Answers.Options, *request.CorrectAnswer) {
		return resp, fmt.Errorf("correctAnswer %s is not in the answers list %v", *request.CorrectAnswer, *request.Answers.Options)
	}

	question := &dbModel.Question{
		QuizID:        request.QuizID,
		QuestionText:  request.QuestionText,
		Type:          &questionType,
		ImageURL:      request.ImageURL,
		Answers:       q.constructAnswers(request.Answers),
		CorrectAnswer: request.CorrectAnswer,
	}

	question, err = q.db.CreateQuestion(ctx, question)
	if err != nil {
		logger.Error(ctx, "unable to create question entry for quiz in database", zap.Error(err), zap.Any("requestBody", request))
		return resp, errors.New("unable to create question entry for quiz in database")
	}

	resp = CreateQuestionResponse{
		ID: *question.ID,
	}
	return resp, nil
}

func (q *questionsController) updateQuestionHelper(ctx context.Context, request UpdateQuestionRequest) error {
	var (
		err error
	)

	question := &dbModel.Question{
		ID:            request.ID,
		QuizID:        request.QuizID,
		QuestionText:  request.QuestionText,
		ImageURL:      request.ImageURL,
		CorrectAnswer: request.CorrectAnswer,
	}

	if request.QuestionType != nil {
		questionType, err := q.validateQuestionType(request.QuestionType)
		if err != nil {
			logger.Error(ctx, "invalid value for question type", zap.Error(err), zap.Any("input value", request.QuestionType))
			return fmt.Errorf("invalid value for course_module type, error: %v", err)
		}

		question.Type = &questionType
	}

	if q.validateOptions(*request.Answers.Options) {
		return fmt.Errorf("at least one answer option must be provided")
	}

	if !q.validateAnswerOptions(*request.Answers.Options, *request.CorrectAnswer) {
		return fmt.Errorf("correctAnswer %s is not in the answers list %v", *request.CorrectAnswer, *request.Answers.Options)
	}

	if request.Answers != nil {
		question.Answers = q.constructAnswers(request.Answers)
	}

	_, err = q.db.UpdateQuestion(ctx, question)
	if err != nil {
		logger.Error(ctx, "unable to update question entry for quiz in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update question entry for quiz in database")
	}

	return nil
}

func (q *questionsController) deleteQuestionHelper(ctx context.Context, request DeleteQuestionRequest) error {
	err := q.db.DeleteQuestion(ctx, *request.ID)
	if err != nil {
		logger.Error(ctx, "unable to delete question from database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete question from database")
	}
	return nil
}

func (q *questionsController) batchInsertHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount  int
		batchNo   int
		questions []dbModel.Question
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}
		if len(row) < 8 || len(row) > 9 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		question, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		questions = append(questions, question)
		if len(questions) == 100 {
			batchNo++ //increment batch
			if err := q.db.BatchCreateQuestions(ctx, questions); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			questions = []dbModel.Question{} //clear categories array
		}

	}

	if len(questions) > 0 {
		batchNo++ //increment batch
		if err := q.db.BatchCreateQuestions(ctx, questions); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}
	return nil
}

func (q *questionsController) batchUpdateHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount  int
		batchNo   int
		questions []dbModel.Question
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}
		if len(row) != 9 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row

		//validate ID column
		questionIdStr := strings.TrimSpace(row[0])
		if len(questionIdStr) == 0 {
			return fmt.Errorf("question_id value is blank, error: %v", err)
		}
		questionId, err := strconv.Atoi(questionIdStr)
		if err != nil {
			return fmt.Errorf("invalid value for module_id column,error: %v", err)
		}

		question, err := q.extractDataFromFile(row[1:])
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		question.ID = utils.Int64ToPointer(int64(questionId))

		questions = append(questions, question)
		if len(questions) == 100 {
			batchNo++ //increment batch
			if err := q.db.BatchUpdateQuestions(ctx, questions); err != nil {
				logger.Error(ctx, "batch update failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch update failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			questions = []dbModel.Question{} //clear categories array
		}

	}

	if len(questions) > 0 {
		batchNo++ //increment batch
		if err := q.db.BatchUpdateQuestions(ctx, questions); err != nil {
			logger.Error(ctx, "final batch updation failed for batch", zap.Error(err))
			return fmt.Errorf("final batch updation failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}
	return nil
}

func (q *questionsController) questionAssetUploadHelper(ctx context.Context, request AssetUploadRequest) (AssetUploadResponse, error) {
	var (
		response AssetUploadResponse
	)

	//intialize active storage service
	activeStorageService := activestorage.NewActiveStorageService(q.db)

	activeStorageInput := activestorage.ActiveStorageUploadInput{
		FileHeader:    request.AssetFile,
		ServiceName:   "S3",
		ModelType:     "question",
		ModelId:       int64(*request.QuestionId),
		ContentType:   request.AssetFile.Header.Get("Content-Type"),
		AttachmentFor: *utils.StringToPointer("banner"),
	}
	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
	if err != nil {
		logger.Error(ctx, "error recived while processing in active storage service", zap.Error(err))
		return response, err
	}

	fileUrl := activeStorageService.GetURL(*tempFileName)

	//update database
	question := dbModel.Question{
		ID:       request.QuestionId,
		ImageURL: &fileUrl,
	}

	if _, err := q.db.UpdateQuestion(ctx, &question); err != nil {
		logger.Error(ctx, "unable to update file path in s3")
		return response, fmt.Errorf("unable to update file path in s3")
	}

	response.Path = fileUrl
	return response, nil
}
func (q *questionsController) validateQuestionType(questionType *string) (constants.QuestionTypeEnum, error) {
	return constants.ParseQuestionTypeEnum(*questionType)
}

func (q *questionsController) constructAnswers(answers *AnswerRequest) *dbModel.Answer {

	return &dbModel.Answer{
		Options: answers.Options,
	}
}

func (q *questionsController) extractDataFromFile(row []string) (dbModel.Question, error) {
	var (
		question dbModel.Question
	)

	switch {
	case len(row) == 8:
		//validate quiz_id
		quizIdStr := strings.TrimSpace(row[0])
		if len(quizIdStr) == 0 {
			return question, fmt.Errorf("quiz_id field is blank")
		}
		quizId, err := strconv.Atoi(quizIdStr)
		if err != nil {
			return question, fmt.Errorf("invalid value for quiz_id, error: %v", err)
		}
		question.QuizID = utils.Int64ToPointer(int64(quizId))

		//validate questionText
		questionText := strings.TrimSpace(row[1])
		if len(questionText) == 0 {
			return question, fmt.Errorf("question_text filed cannot be blank")
		}

		question.QuestionText = &questionText

		//validate type
		questionTypeStr := strings.TrimSpace(row[2])
		questionType, err := q.validateQuestionType(&questionTypeStr)
		if err != nil {
			return question, fmt.Errorf("invalid value for question_type, error: %v", err)
		}
		question.Type = &questionType

		var options []string
		//Extract answers from individual columns (option1, option2, option3, option4)
		//check index 3: Append only if not empty - option1
		if len(row) > 3 {
			if option1 := strings.TrimSpace(row[3]); option1 != "" {
				options = append(options, option1)
			}
		}
		//check index 4: Append only if not empty - option2
		if len(row) > 4 {
			if option2 := strings.TrimSpace(row[4]); option2 != "" {
				options = append(options, option2)
			}
		}
		//check index 5: Append only if not empty - option3
		if len(row) > 5 {
			if option3 := strings.TrimSpace(row[5]); option3 != "" {
				options = append(options, option3)
			}
		}
		//check index 6: Append only if not empty - option4
		if len(row) > 6 {
			if option4 := strings.TrimSpace(row[6]); option4 != "" {
				options = append(options, option4)
			}
		}
		//
		// Validate that we have at least one valid option
		if len(options) == 0 || (options[0] == "" && options[1] == "" && options[2] == "" && options[3] == "") {
			return question, fmt.Errorf("at least one answer option must be provided")
		}

		question.Answers = &dbModel.Answer{
			Options: &options,
		}

		//validate correct answers
		correctAnswer := strings.TrimSpace(row[7])
		if len(correctAnswer) == 0 {
			return question, fmt.Errorf("correct_answer filed cannot be blank")
		}

		if !q.validateAnswerOptions(options, correctAnswer) {
			return question, fmt.Errorf("correctAnswer %s is not in the answers list %v", correctAnswer, options)
		}
		question.CorrectAnswer = &correctAnswer

		//If length of columns is 9
	case len(row) == 9:
		questionIdStr := strings.TrimSpace(row[0])
		if len(questionIdStr) == 0 {
			return question, fmt.Errorf("quiz_id field is blank")
		}
		questionId, err := strconv.Atoi(questionIdStr)
		if err != nil {
			return question, fmt.Errorf("invalid value for quiz_id, error: %v", err)
		}
		question.ID = utils.Int64ToPointer(int64(questionId))

		//validate quiz_id
		quizIdStr := strings.TrimSpace(row[1])
		if len(quizIdStr) == 0 {
			return question, fmt.Errorf("quiz_id field is blank")
		}
		quizId, err := strconv.Atoi(quizIdStr)
		if err != nil {
			return question, fmt.Errorf("invalid value for quiz_id, error: %v", err)
		}
		question.QuizID = utils.Int64ToPointer(int64(quizId))

		//validate questionText
		questionText := strings.TrimSpace(row[2])
		if len(questionText) == 0 {
			return question, fmt.Errorf("question_text filed cannot be blank")
		}

		question.QuestionText = &questionText

		//validate type
		questionTypeStr := strings.TrimSpace(row[3])
		questionType, err := q.validateQuestionType(&questionTypeStr)
		if err != nil {
			return question, fmt.Errorf("invalid value for question_type, error: %v", err)
		}
		question.Type = &questionType

		var options []string
		//Extract answers from individual columns (option1, option2, option3, option4)
		//check index 3: Append only if not empty - option1
		if len(row) > 4 {
			if option1 := strings.TrimSpace(row[4]); option1 != "" {
				options = append(options, option1)
			}
		}
		//check index 5: Append only if not empty - option2
		if len(row) > 5 {
			if option2 := strings.TrimSpace(row[5]); option2 != "" {
				options = append(options, option2)
			}
		}
		//check index 6: Append only if not empty - option3
		if len(row) > 6 {
			if option3 := strings.TrimSpace(row[6]); option3 != "" {
				options = append(options, option3)
			}
		}
		//check index 7: Append only if not empty - option4
		if len(row) > 7 {
			if option4 := strings.TrimSpace(row[7]); option4 != "" {
				options = append(options, option4)
			}
		}

		// Validate that we have at least one valid option
		if len(options) == 0 || (options[0] == "" && options[1] == "" && options[2] == "" && options[3] == "") {
			return question, fmt.Errorf("at least one answer option must be provided")
		}

		question.Answers = &dbModel.Answer{
			Options: &options,
		}

		//validate correct answers
		correctAnswer := strings.TrimSpace(row[8])
		if len(correctAnswer) == 0 {
			return question, fmt.Errorf("correct_answer filed cannot be blank")
		}

		if !q.validateAnswerOptions(options, correctAnswer) {
			return question, fmt.Errorf("correctAnswer %s is not in the answers list %v", correctAnswer, options)
		}
		question.CorrectAnswer = &correctAnswer
	}

	return question, nil
}

func (q *questionsController) validateAnswerOptions(options []string, correctAnswer string) bool {
	for _, item := range options {
		if item == correctAnswer {
			return true
		}
	}

	return false
}

func (q *questionsController) validateOptions(options []string) bool {
	return len(options) == 0
}

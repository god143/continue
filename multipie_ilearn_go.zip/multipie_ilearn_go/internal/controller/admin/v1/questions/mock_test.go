package questions

// import (
// 	"bytes"
// 	"context"
// 	"encoding/csv"
// 	"encoding/json"
// 	"errors"
// 	"mime/multipart"
// 	"net/http"
// 	"net/http/httptest"
// 	"os"
// 	"testing"
// 	"multipie_ilearn_go/internal/db"
// 	dbModel "multipie_ilearn_go/internal/db/question"
// 	"multipie_ilearn_go/internal/logger"
// 	"multipie_ilearn_go/internal/utils"

// 	"github.com/gin-gonic/gin"
// 	"github.com/stretchr/testify/assert"
// 	"github.com/stretchr/testify/mock"
// )
// // --- Mocks ---
// type MockQuestionsDB struct {
// 	mock.Mock
// 	db.DBLayer
// }
// func (m *MockQuestionsDB) CreateQuestion(ctx context.Context, q *dbModel.Question) (*dbModel.Question, error) {
// 	args := m.Called(ctx, q)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.Question), args.Error(1)
// }

// func (m *MockQuestionsDB) GetQuestionsByQuizId(ctx context.Context, id int64, limit *int64) ([]dbModel.Question, error) {
// 	args := m.Called(ctx, id, limit)
// 	return args.Get(0).([]dbModel.Question), args.Error(1)
// }

// func (m *MockQuestionsDB) UpdateQuestion(ctx context.Context, q *dbModel.Question) (*dbModel.Question, error) {
// 	args := m.Called(ctx, q)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.Question), args.Error(1)
// }

// func (m *MockQuestionsDB) DeleteQuestion(ctx context.Context, id int64) error {
// 	return m.Called(ctx, id).Error(0)
// }

// func (m *MockQuestionsDB) BatchCreateQuestions(ctx context.Context, q []dbModel.Question) error {
// 	return m.Called(ctx, q).Error(0)
// }

// func (m *MockQuestionsDB) BatchUpdateQuestions(ctx context.Context, q []dbModel.Question) error {
// 	return m.Called(ctx, q).Error(0)
// }

// func TestMain(m *testing.M) {
// 	// Initialize logger once for the package to prevent nil pointer panics in helper.go
// 	_ = logger.NewLogger("test", "error", "")
// 	gin.SetMode(gin.TestMode)
// 	os.Exit(m.Run())
// }

// func ptrString(s string) *string { return &s }
// func ptrInt64(i int64) *int64    { return &i }

// // --- Helpers ---
// func createMultipartCSV(rows [][]string) (*bytes.Buffer, string) {
// 	body := &bytes.Buffer{}
// 	writer := multipart.NewWriter(body)
// 	part, _ := writer.CreateFormFile("file", "questions.csv")
// 	csvWriter := csv.NewWriter(part)
// 	csvWriter.WriteAll(rows)
// 	csvWriter.Flush()
// 	writer.Close()
// 	return body, writer.FormDataContentType()
// }

// func TestQuestionsController_CRUD(t *testing.T) {
// 	gin.SetMode(gin.TestMode)

// 	t.Run("Create Question - Success MCQs", func(t *testing.T) {
// 		m := new(MockQuestionsDB)
// 		ctrl := NewQuestionsController(m)
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)

// 		input := CreateQuestionRequest{
// 			QuizID:        utils.Int64ToPointer(1),
// 			QuestionText:  utils.StringToPointer("Go is a?"),
// 			QuestionType:  utils.StringToPointer("mcq"),
// 			Answers:       &AnswerRequest{Options: &[]string{"Language", "Tool"}},
// 			CorrectAnswer: utils.StringToPointer("Language"),
// 		}
// 		jsonInput, _ := json.Marshal(input)
// 		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jsonInput))
// 		c.Request.Header.Set("Content-Type", "application/json")

// 		id := int64(1)
// 		m.On("CreateQuestion", mock.Anything, mock.Anything).Return(&dbModel.Question{ID: &id}, nil)

// 		ctrl.CreateQuestion(c)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("Update Question - Correct Answer Validation Fail", func(t *testing.T) {
// 		m := new(MockQuestionsDB)
// 		ctrl := NewQuestionsController(m)
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)

// 		input := UpdateQuestionRequest{
// 			ID:            utils.Int64ToPointer(10),
// 			Answers:       &AnswerRequest{Options: &[]string{"A", "B"}},
// 			CorrectAnswer: utils.StringToPointer("C"), // Not in options
// 		}
// 		jsonInput, _ := json.Marshal(input)
// 		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jsonInput))
// 		c.Request.Header.Set("Content-Type", "application/json")

// 		ctrl.UpdateQuestion(c)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "is not in the answers list")
// 	})
// }

// func TestQuestionsController_BatchOperations(t *testing.T) {
// 	t.Run("Batch Create - Success with 8 Columns", func(t *testing.T) {
// 		m := new(MockQuestionsDB)
// 		ctrl := NewQuestionsController(m)
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)

// 		csvRows := [][]string{
// 			{"quiz_id", "question_text", "question_type", "opt1", "opt2", "opt3", "opt4", "correct_answer"},
// 			{"1", "What is 2+2?", "mcq", "3", "4", "5", "", "4"},
// 		}
// 		body, ct := createMultipartCSV(csvRows)
// 		c.Request, _ = http.NewRequest("POST", "/", body)
// 		c.Request.Header.Set("Content-Type", ct)

// 		m.On("BatchCreateQuestions", mock.Anything, mock.Anything).Return(nil)

// 		ctrl.BatchCreateQuestions(c)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("Batch Update - Fail on Blank ID", func(t *testing.T) {
// 		m := new(MockQuestionsDB)
// 		ctrl := NewQuestionsController(m)
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)

// 		csvRows := [][]string{
// 			{"id", "quiz_id", "text", "type", "o1", "o2", "o3", "o4", "correct"},
// 			{" ", "1", "Quest", "mcq", "A", "B", "", "", "A"}, // Blank ID index 0
// 		}
// 		body, ct := createMultipartCSV(csvRows)
// 		c.Request, _ = http.NewRequest("POST", "/", body)
// 		c.Request.Header.Set("Content-Type", ct)

// 		ctrl.BatchUpdateQuestions(c)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// }
// func TestExtractDataFromFile_DeepCoverage(t *testing.T) {
// 	m := new(MockQuestionsDB)
// 	ctrl := &questionsController{db: m}
// 	t.Run("Extract 9 Column Success Path", func(t *testing.T) {
// 		row := []string{"10", "1", "Question Text", "mcq", "Op1", "Op2", "", "", "Op1"}
// 		res, err := ctrl.extractDataFromFile(row)
// 		assert.NoError(t, err)
// 		assert.Equal(t, int64(10), *res.ID)
// 		assert.Equal(t, 2, len(*res.Answers.Options))
// 	})
// 	t.Run("Extract 8 Column - No Options Error", func(t *testing.T) {
// 		row := []string{"1", "Question", "mcq", "", "", "", "", "Correct"}
// 		_, err := ctrl.extractDataFromFile(row)
// 		assert.Error(t, err)
// 		assert.Contains(t, err.Error(), "at least one answer option must be provided")
// 	})
// }
// func TestAnswer_GormJsonMethods(t *testing.T) {
// 	t.Run("Value and Scan Coverage", func(t *testing.T) {
// 		ans := &dbModel.Answer{Options: &[]string{"O1", "O2"}}

// 		// Test Value()
// 		val, err := ans.Value()
// 		assert.NoError(t, err)
// 		assert.Contains(t, string(val.([]byte)), "O1")

// 		// Test Scan()
// 		newAns := &dbModel.Answer{}
// 		err = newAns.Scan(val)
// 		assert.NoError(t, err)
// 		assert.Equal(t, 2, len(*newAns.Options))
// 	})
// }

// func TestQuestionsController_HighCoverage(t *testing.T) {
// 	gin.SetMode(gin.TestMode)

// 	t.Run("GetQuestionByQuizID_Success", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		m := new(MockQuestionsDB)
// 		ctrl := &questionsController{db: m}
// 		quizIDStr, quizIDInt := "123", int64(123)

// 		ctx.Request = httptest.NewRequest("GET", "/?quiz_id="+quizIDStr, nil)
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: quizIDStr}}

// 		mockResponse := []dbModel.Question{
// 			{ID: ptrInt64(1), QuestionText: ptrString("Test Question")},
// 		}

// 		m.On("GetQuestionsByQuizId", mock.Anything, quizIDInt, mock.Anything).
// 			Return(mockResponse, nil).Once()

// 		ctrl.GetQuestionByQuizID(ctx)

// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("GetQuestionByQuizID_DB_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		m := new(MockQuestionsDB)
// 		ctrl := &questionsController{db: m}
// 		quizIDStr, quizIDInt := "123", int64(123)

// 		ctx.Request = httptest.NewRequest("GET", "/?quiz_id="+quizIDStr, nil)
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: quizIDStr}}

// 		m.On("GetQuestionsByQuizId", mock.Anything, quizIDInt, mock.Anything).
// 			Return([]dbModel.Question{}, errors.New("database error")).Once()

// 		ctrl.GetQuestionByQuizID(ctx)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("QuestionAssetUploader_NoFile_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		m := new(MockQuestionsDB)
// 		ctrl := &questionsController{db: m}

// 		// Create request without the "file" part to trigger error branch in helper
// 		body := &bytes.Buffer{}
// 		writer := multipart.NewWriter(body)
// 		writer.Close()

// 		ctx.Request = httptest.NewRequest("POST", "/upload", body)
// 		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())

// 		ctrl.QuestionAssetUploader(ctx)
// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})

// 	// --- SECTION: BATCH OPERATIONS ---
// 	t.Run("BatchUpdate_Partial_DB_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		m := new(MockQuestionsDB)
// 		ctrl := &questionsController{db: m}

// 		body := &bytes.Buffer{}
// 		writer := multipart.NewWriter(body)
// 		part, _ := writer.CreateFormFile("file", "questions.csv")
// 		part.Write([]byte("id,question_text\n1,Test Question")) // Dummy CSV content
// 		writer.Close()

// 		ctx.Request = httptest.NewRequest("POST", "/", body)
// 		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())

// 		// Mock the helper/DB to return an error to cover the error branch
// 		m.On("BatchUpdateQuestions", mock.Anything, mock.Anything).
// 			Return(errors.New("db error")).Once()

// 		ctrl.BatchUpdateQuestions(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("UpdateQuestion_Validation_Fail", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		m := new(MockQuestionsDB)
// 		ctrl := &questionsController{db: m}
// 		ctx, _ := gin.CreateTestContext(w)

// 		jsonInput := `{"id": "this_should_be_an_int"}`

// 		ctx.Request = httptest.NewRequest("PUT", "/", bytes.NewBufferString(jsonInput))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		ctrl.UpdateQuestion(ctx)

// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})

// }

// func TestBatchOperations_Coverage(t *testing.T) {
// 	t.Run("BatchUpdate_Partial_Failure", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		// Mock payload where one item is valid and one is missing an ID
// 		jsonInput := `[{"id": "1", "text": "Valid"}, {"id": "", "text": "Invalid"}]`
// 		ctx.Request = httptest.NewRequest("POST", "/batch", bytes.NewBufferString(jsonInput))
// 	})
// }

// // ---  Benchmarks ---
// func BenchmarkCreateQuestionHelper(b *testing.B) {
// 	m := new(MockQuestionsDB)
// 	ctrl := &questionsController{db: m}
// 	req := CreateQuestionRequest{
// 		QuizID:        utils.Int64ToPointer(1),
// 		QuestionText:  utils.StringToPointer("Text"),
// 		QuestionType:  utils.StringToPointer("mcq"),
// 		Answers:       &AnswerRequest{Options: &[]string{"A", "B"}},
// 		CorrectAnswer: utils.StringToPointer("A"),
// 	}
// 	id := int64(1)
// 	m.On("CreateQuestion", mock.Anything, mock.Anything).Return(&dbModel.Question{ID: &id}, nil)

// 	b.ResetTimer()
// 	for i := 0; i < b.N; i++ {
// 		_, _ = ctrl.createQuestionHelper(context.Background(), req)
// 	}
// }

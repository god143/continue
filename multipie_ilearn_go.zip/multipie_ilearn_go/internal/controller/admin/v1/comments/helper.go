package comments

import (
	"context"
	"encoding/csv"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/comments"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *commentController) getCommentsHelper(ctx *gin.Context, modelType string, modelID int64) ([]dbModel.CommentWithReplies, error) {

	comments, err := c.db.GetCommentsByModelAndID(ctx, modelType, modelID, nil, nil)
	if err != nil {
		return nil, err
	}

	commentMap := make(map[int64]*dbModel.CommentWithReplies)
	var parentComments []dbModel.CommentWithReplies

	for i := 0; i < len(comments); i++ {
		comment := comments[i]

		commentWithReplies := &dbModel.CommentWithReplies{
			Comment: dbModel.CommentWithUser{
				ID:         comment.ID,
				UserID:     comment.UserID,
				Username:   comment.Username,
				FirstName:  comment.FirstName,
				LastName:   comment.LastName,
				PictureURL: comment.PictureURL,
				Content:    comment.Content,
				ParentID:   comment.ParentID,
				ModelType:  comment.ModelType,
				ModelID:    comment.ModelID,
				Visible:    comment.Visible,
				LikesCount: comment.LikesCount,
				CreatedAt:  comment.CreatedAt,
				UpdatedAt:  comment.UpdatedAt,
			},
			Replies: []dbModel.CommentWithUser{},
		}

		// Check if it's a parent comment or a reply
		if comment.ParentID == nil {
			// It's a parent comment
			parentComments = append(parentComments, *commentWithReplies)
			commentMap[*comment.ID] = &parentComments[len(parentComments)-1]
		} else {
			// It's a reply, find the parent and attach it
			if parent, exists := commentMap[*comment.ParentID]; exists {
				parent.Replies = append(parent.Replies, commentWithReplies.Comment)
			}
		}
	}

	sort.Slice(parentComments, func(i, j int) bool {
		return parentComments[i].Comment.CreatedAt.After(*parentComments[j].Comment.CreatedAt)
	})

	for i := range parentComments {
		sort.Slice(parentComments[i].Replies, func(a, b int) bool {
			return parentComments[i].Replies[a].CreatedAt.After(*parentComments[i].Replies[b].CreatedAt)
		})
	}

	return parentComments, nil
}
func (c *commentController) enableCommentHelper(ctx *gin.Context, commentID int64) error {
	err := c.db.EnableComment(ctx, commentID)
	if err != nil {
		return err
	}
	return nil
}

func (c *commentController) disableCommentHelper(ctx *gin.Context, commentID int64) error {

	err := c.db.DisableComment(ctx, commentID)
	if err != nil {
		return err
	}
	return nil
}

func (c *commentController) replyCommentHelper(ctx *gin.Context, request ReplyCommentRequest, userID int64) (dbModel.Comment, error) {
	var newReply dbModel.Comment

	newReply.UserID = &userID
	newReply.Content = request.Content
	newReply.ParentID = request.ParentID
	newReply.ModelType = request.ModelType
	newReply.ModelID = request.ModelID
	newReply.Visible = utils.BoolToPointer(true)

	createdReply, err := c.db.CreateComment(ctx, &newReply)
	if err != nil {
		return dbModel.Comment{}, err
	}
	return *createdReply, nil
}

func (q *commentController) batchCreateCommentsHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		comments []dbModel.Comment
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 9 || len(row) > 10 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		comment, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		// quiz.Visible = utils.BoolToPointer(true)

		comments = append(comments, comment)
		if len(comments) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateComments(ctx, comments); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			comments = []dbModel.Comment{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(comments) > 0 {
		if err := q.db.BatchCreateComments(ctx, comments); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (c *commentController) extractDataFromFile(row []string) (dbModel.Comment, error) {
	var (
		comment dbModel.Comment
	)

	switch {
	case len(row) == 9:
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			comment.UserID = utils.Int64ToPointer(int64(userId))
		}

		content := strings.TrimSpace(row[1])
		if len(content) != 0 {
			comment.Content = &content
		}

		parentIdStr := strings.TrimSpace(row[2])
		if len(parentIdStr) != 0 {
			parentId, err := strconv.Atoi(parentIdStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for  parentId, error: %v", err)
			}

			comment.ParentID = utils.Int64ToPointer(int64(parentId))
		}
		modelIdStr := strings.TrimSpace(row[3])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}

			comment.ModelID = utils.Int64ToPointer(int64(modelId))
		}

		//validate model type
		modelType := strings.TrimSpace(row[4])
		if len(modelType) != 0 {
			modeltype, err := validateModelType(modelType)
			if err != nil {
				return comment, fmt.Errorf("invalid value for model type, error: %v", err)
			}
			comment.ModelType = &modeltype
		}

		createdAtStr := strings.TrimSpace(row[5])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			comment.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[6])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			comment.UpdatedAt = &updatedAt
		}

		visibleStr := strings.TrimSpace(row[7])
		if len(visibleStr) == 0 {
			return comment, fmt.Errorf("value for visible cannot be blank")
		}
		visible, err := strconv.ParseBool(visibleStr)
		if err != nil {
			return comment, fmt.Errorf("invalid value for visible, error: %v", err)
		}
		comment.Visible = &visible

		likesStr := strings.TrimSpace(row[8])
		if len(likesStr) == 0 {
			return comment, fmt.Errorf("value for like count field cannot be blank")
		}
		likeCount, err := strconv.Atoi(likesStr)
		if err != nil {
			return comment, fmt.Errorf("invalid value like count, error: %v", err)
		}
		comment.LikesCount = utils.Int64ToPointer(int64(likeCount))

		return comment, nil

	case len(row) == 10:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return comment, fmt.Errorf("failed to convert into integer: %v", err)
		}
		comment.ID = utils.Int64ToPointer(int64(id))

		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for  userId, error: %v", err)
			}
			comment.UserID = utils.Int64ToPointer(int64(userId))
		}

		content := strings.TrimSpace(row[2])
		if len(content) != 0 {
			comment.Content = &content
		}

		parentIdStr := strings.TrimSpace(row[3])
		if parentIdStr != "" {
			parentId, err := strconv.ParseInt(parentIdStr, 10, 64)
			if err == nil {
				comment.ParentID = utils.Int64ToPointer(int64(parentId))
			}

			comment.ParentID = utils.Int64ToPointer(int64(parentId))
		}

		modelIdStr := strings.TrimSpace(row[4])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}

			comment.ModelID = utils.Int64ToPointer(int64(modelId))
		}
		//validate model type
		modelType := strings.TrimSpace(row[5])
		if len(modelType) != 0 {
			modeltype, err := validateModelType(modelType)
			if err != nil {
				return comment, fmt.Errorf("invalid value for model type, error: %v", err)
			}
			comment.ModelType = &modeltype
		}

		createdAtStr := strings.TrimSpace(row[6])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			comment.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[7])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return comment, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			comment.UpdatedAt = &updatedAt
		}

		visibleStr := strings.TrimSpace(row[8])
		if len(visibleStr) == 0 {
			return comment, fmt.Errorf("value for visible cannot be blank")
		}
		visible, err := strconv.ParseBool(visibleStr)
		if err != nil {
			return comment, fmt.Errorf("invalid value for visible, error: %v", err)
		}
		comment.Visible = &visible

		likesStr := strings.TrimSpace(row[9])
		if len(likesStr) == 0 {
			return comment, fmt.Errorf("value for like count field cannot be blank")
		}
		likeCount, err := strconv.Atoi(likesStr)
		if err != nil {
			return comment, fmt.Errorf("invalid value like count, error: %v", err)
		}
		comment.LikesCount = utils.Int64ToPointer(int64(likeCount))

		return comment, nil

	default:
		fmt.Printf("invalid number of row")
	}

	return comment, nil

}

func validateModelType(modelType string) (constants.CommentsModelTypeEnum, error) {
	return constants.ParseCommentsModelTypeEnum(modelType)
}

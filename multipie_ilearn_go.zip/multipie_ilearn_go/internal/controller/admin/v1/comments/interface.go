package comments

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type commentController struct {
	db db.DBLayer
}

type CommentControllerGroup interface {
	GetComments(ctx *gin.Context)
	ReplyComment(ctx *gin.Context)
	ModifyComment(ctx *gin.Context)
	BatchCreateComment(ctx *gin.Context)
}

func NewCommentControllerGroup(db db.DBLayer) CommentControllerGroup {
	return &commentController{
		db: db,
	}
}

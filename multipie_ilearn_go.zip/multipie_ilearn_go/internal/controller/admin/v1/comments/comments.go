package comments

import (
	dbModel "multipie_ilearn_go/internal/db/comments"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *commentController) GetComments(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCommentRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid query parameters", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid query parameters"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	comments, err := c.getCommentsHelper(ctx, request.ModelType, request.ModelID)
	if err != nil {
		logger.Error(ctx, "failed to fetch comments", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch comments"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(comments, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *commentController) ReplyComment(ctx *gin.Context) {
	var (
		resp         *utils.Response
		request      ReplyCommentRequest
		createdReply dbModel.Comment
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createdReply, err = c.replyCommentHelper(ctx, request, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create reply: "+err.Error()))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createdReply, nil)
	ctx.JSON(http.StatusCreated, resp)
}

func (c *commentController) ModifyComment(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request ModifyCommentRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid JSON body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid JSON body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	switch request.Action {
	case "enable":
		err := c.enableCommentHelper(ctx, request.CommentID)
		if err != nil {
			logger.Error(ctx, "failed to enable comment", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to enable comment"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

	case "disable":
		err := c.disableCommentHelper(ctx, request.CommentID)
		if err != nil {
			logger.Error(ctx, "failed to disable comment", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to disable comment"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

	default:
		logger.Error(ctx, "invalid action value", zap.String("action", request.Action))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid action value"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(nil, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *commentController) BatchCreateComment(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = q.batchCreateCommentsHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of comments is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

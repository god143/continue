package comments

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/comments"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- MOCK DEFINITION ---
type MockCommentDB struct {
	mock.Mock
	db.DBLayer
}

func TestMain(m *testing.M) {
	// Initialize logger once for the package to prevent nil pointer panics in helper.go
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

func (m *MockCommentDB) CreateComment(ctx context.Context, comment *dbModel.Comment) (*dbModel.Comment, error) {
	args := m.Called(ctx, comment)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Comment), args.Error(1)
}

func (m *MockCommentDB) DisableComment(ctx context.Context, id int64) error {
	return m.Called(ctx, id).Error(0)
}

func (m *MockCommentDB) EnableComment(ctx context.Context, id int64) error {
	return m.Called(ctx, id).Error(0)
}

func (m *MockCommentDB) GetCommentsByModelAndID(ctx context.Context, modelType string, modelID int64, userID *int64, visible *bool) ([]dbModel.CommentWithUser, error) {
	args := m.Called(ctx, modelType, modelID, userID, visible)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.CommentWithUser), args.Error(1)
}

// --- POINTER HELPERS ---
func ptrInt64(i int64) *int64                                                         { return &i }
func ptrString(s string) *string                                                      { return &s }
func ptrModelType(m constants.CommentsModelTypeEnum) *constants.CommentsModelTypeEnum { return &m }

// --- UNIT TESTS ---

func TestReplyComment(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		reqBody        interface{}
		userID         interface{} // Use interface to test invalid types
		setupMock      func(*MockCommentDB)
		expectedStatus int
	}{
		{
			name:   "Success - 201",
			userID: int64(1), // Explicit int64
			reqBody: ReplyCommentRequest{
				Content: ptrString("Hello"), ParentID: ptrInt64(0),
				ModelID: ptrInt64(1), ModelType: ptrModelType(constants.CommentsModelTypeEnumResource),
			},
			setupMock: func(m *MockCommentDB) {
				m.On("CreateComment", mock.Anything, mock.Anything).Return(&dbModel.Comment{ID: ptrInt64(50)}, nil)
			},
			expectedStatus: http.StatusCreated,
		},
		{
			name:           "Failure - 401 Unauthorized (Missing)",
			userID:         nil,
			reqBody:        ReplyCommentRequest{Content: ptrString("Hi")},
			setupMock:      func(m *MockCommentDB) {},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:   "Failure - 400 DB Error",
			userID: int64(1),
			reqBody: ReplyCommentRequest{
				Content: ptrString("Fail"), ParentID: ptrInt64(0),
				ModelID: ptrInt64(1), ModelType: ptrModelType(constants.CommentsModelTypeEnumCourseModule),
			},
			setupMock: func(m *MockCommentDB) {
				m.On("CreateComment", mock.Anything, mock.Anything).Return(nil, errors.New("db error"))
			},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Failure - Invalid Request Body (Missing Content)",
			userID:         int64(1),
			reqBody:        map[string]interface{}{"parent_id": 0}, // Missing "content" required field
			setupMock:      func(m *MockCommentDB) {},
			expectedStatus: http.StatusBadRequest,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockCommentDB)
			ctrl := &commentController{db: mDB}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			if tt.userID != nil {
				c.Set("userId", tt.userID)
			}

			body, _ := json.Marshal(tt.reqBody)
			c.Request, _ = http.NewRequest("POST", "/reply", bytes.NewBuffer(body))
			c.Request.Header.Set("Content-Type", "application/json")

			tt.setupMock(mDB)
			ctrl.ReplyComment(c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestGetComments(t *testing.T) {
	t.Run("Success with Nested Replies", func(t *testing.T) {
		mockDB := new(MockCommentDB)
		controller := NewCommentControllerGroup(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// Setup Query Params
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

		now := time.Now()
		parentID := int64(1)
		childID := int64(2)

		// Mock Data representing a flat list from DB
		mockData := []dbModel.CommentWithUser{
			{ID: &parentID, Content: utils.StringToPointer("Parent"), CreatedAt: &now, ParentID: nil},
			{ID: &childID, Content: utils.StringToPointer("Reply"), CreatedAt: &now, ParentID: &parentID},
		}

		mockDB.On("GetCommentsByModelAndID", mock.Anything, "course", int64(100), mock.Anything, mock.Anything).Return(mockData, nil)

		controller.GetComments(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		// Verify helper logic nested the reply
		var response utils.Response
		json.Unmarshal(w.Body.Bytes(), &response)
		// Logic check: length should be 1 (the parent) because reply is nested inside it
		assert.NotNil(t, response.Data)
	})

	t.Run("DB Error", func(t *testing.T) {
		mockDB := new(MockCommentDB)
		controller := NewCommentControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

		mockDB.On("GetCommentsByModelAndID", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("db error"))

		controller.GetComments(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("Failure - Get - Invalid Query Params", func(t *testing.T) {
		mockDB := new(MockCommentDB)
		controller := NewCommentControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// Missing required model_id to trigger ShouldBindQuery error
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course", nil)

		controller.GetComments(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
	t.Run("Success - Nested Replies Deep Sorting", func(t *testing.T) {
		mockDB := new(MockCommentDB)
		controller := NewCommentControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

		pID := int64(1)
		oldTime := time.Now().Add(-1 * time.Hour)
		newTime := time.Now()
		mType := constants.CommentsModelTypeEnum(2)

		// Test data to trigger all sorting lines:
		// 2 Parents (Old and New) and 2 Replies for one parent (Old and New)
		mockData := []dbModel.CommentWithUser{
			{ID: &pID, CreatedAt: &oldTime, Content: utils.StringToPointer("Old Parent"), ModelType: &mType},
			{ID: utils.Int64ToPointer(2), CreatedAt: &newTime, Content: utils.StringToPointer("New Parent"), ModelType: &mType},
			{ID: utils.Int64ToPointer(3), CreatedAt: &oldTime, ParentID: &pID, Content: utils.StringToPointer("Old Reply"), ModelType: &mType},
			{ID: utils.Int64ToPointer(4), CreatedAt: &newTime, ParentID: &pID, Content: utils.StringToPointer("New Reply"), ModelType: &mType},
		}

		mockDB.On("GetCommentsByModelAndID", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(mockData, nil).Once()

		controller.GetComments(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

}

func TestModifyComment(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		reqBody        ModifyCommentRequest
		setupMock      func(*MockCommentDB)
		expectedStatus int
	}{
		{
			name:    "Success - Enable",
			reqBody: ModifyCommentRequest{Action: "enable", CommentID: 1},
			setupMock: func(m *MockCommentDB) {
				m.On("EnableComment", mock.Anything, int64(1)).Return(nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:    "Success - Disable",
			reqBody: ModifyCommentRequest{Action: "disable", CommentID: 2},
			setupMock: func(m *MockCommentDB) {
				m.On("DisableComment", mock.Anything, int64(2)).Return(nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:    "Failure - DB Error on Enable",
			reqBody: ModifyCommentRequest{Action: "enable", CommentID: 3},
			setupMock: func(m *MockCommentDB) {
				m.On("EnableComment", mock.Anything, int64(3)).Return(errors.New("fail"))
			},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Failure - Invalid Action",
			reqBody:        ModifyCommentRequest{Action: "delete", CommentID: 4}, // validation fails on 'oneof'
			setupMock:      func(m *MockCommentDB) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:    "Disable Failure - DB Error", // Hits disableCommentHelper error branch
			reqBody: ModifyCommentRequest{Action: "disable", CommentID: 500},
			setupMock: func(m *MockCommentDB) {
				m.On("DisableComment", mock.Anything, int64(500)).Return(errors.New("db disconnect"))
			},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Failure - Invalid Action Default Case",              // Hits the "default" switch branch
			reqBody:        ModifyCommentRequest{Action: "delete", CommentID: 1}, // "oneof" validation might catch this, but if it passes to switch:
			setupMock:      func(m *MockCommentDB) {},
			expectedStatus: http.StatusBadRequest,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockCommentDB)
			ctrl := &commentController{db: mDB}

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			body, _ := json.Marshal(tt.reqBody)
			c.Request, _ = http.NewRequest("PATCH", "/modify", bytes.NewBuffer(body))

			tt.setupMock(mDB)
			ctrl.ModifyComment(c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- BENCHMARKS ---

func BenchmarkReplyComment(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockCommentDB)
	mDB.On("CreateComment", mock.Anything, mock.Anything).Return(&dbModel.Comment{}, nil)
	ctrl := &commentController{db: mDB}

	request := ReplyCommentRequest{
		Content:   ptrString("bench"),
		ParentID:  ptrInt64(1),
		ModelID:   ptrInt64(1),
		ModelType: ptrModelType(constants.CommentsModelTypeEnumCourseModule),
	}
	body, _ := json.Marshal(request)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/reply", bytes.NewBuffer(body))
		c.Set("user_id", int64(100))
		ctrl.ReplyComment(c)
	}
}

func BenchmarkGetComments_Optimized(b *testing.B) {
	mockDB := new(MockCommentDB)
	controller := NewCommentControllerGroup(mockDB)

	now := time.Now()
	mType := constants.CommentsModelTypeEnum(2)
	mockData := []dbModel.CommentWithUser{
		{ID: utils.Int64ToPointer(1), Content: utils.StringToPointer("B"), CreatedAt: &now, ModelType: &mType},
	}
	mockDB.On("GetCommentsByModelAndID", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(mockData, nil)

	// Reuse Request and Recorder to minimize overhead
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Set("userId", int64(1))
	req, _ := http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctx.Request = req // Reuse the request
		controller.GetComments(ctx)
	}
}

package enrollment

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type enrollmentController struct {
	db db.DBLayer
}

type EnrollmentControllerGroup interface {
	BatchCreateEnrollment(ctx *gin.Context)
}

func NewEnrollmentController(db db.DBLayer) EnrollmentControllerGroup {
	return &enrollmentController{
		db: db,
	}
}

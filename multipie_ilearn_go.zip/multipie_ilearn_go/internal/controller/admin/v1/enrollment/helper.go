package enrollment

import (
	"context"
	"encoding/csv"
	"fmt"
	"io"
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/enrollment"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (c *enrollmentController) batchCreateEnrollmentHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount    int
		batchNo     int
		enrollments []dbModel.Enrollment
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}

		if len(row) < 6 || len(row) > 7 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		enrollment, err := c.extractDataForCreateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		enrollments = append(enrollments, enrollment)
		if len(enrollments) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchCreateEnrollment(ctx, enrollments); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			enrollments = []dbModel.Enrollment{} //clear courses array
		}

	}

	if len(enrollments) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchCreateEnrollment(ctx, enrollments); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

func (c *enrollmentController) extractDataForCreateFile(row []string) (dbModel.Enrollment, error) {
	var (
		enrollment dbModel.Enrollment
	)

	switch {
	case len(row) == 6:
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			enrollment.UserID = utils.Int64ToPointer(int64(userId))
		}

		courseIdStr := strings.TrimSpace(row[1])
		if len(courseIdStr) != 0 {
			courseId, err := strconv.Atoi(courseIdStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for  courseId, error: %v", err)
			}

			enrollment.CourseID = utils.Int64ToPointer(int64(courseId))
		}

		status := validateEnrollmentStatus(row[2])
		enrollment.Status = &status

		enrollmentDateStr := strings.TrimSpace(row[4])
		if len(enrollmentDateStr) != 0 {
			enrollmentDate, err := time.Parse("2006-01-02 15:04:05", enrollmentDateStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for enrollment date column,error: %v", err)
			}
			enrollment.EnrollmentDate = &enrollmentDate
		}

		createdAtStr := strings.TrimSpace(row[4])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			enrollment.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[5])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			enrollment.UpdatedAt = &updatedAt
		}

		return enrollment, nil

	case len(row) == 7:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return enrollment, fmt.Errorf("failed to convert into integer: %v", err)
		}
		enrollment.ID = utils.Int64ToPointer(int64(id))

		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			enrollment.UserID = utils.Int64ToPointer(int64(userId))
		}

		courseIdStr := strings.TrimSpace(row[2])
		if len(courseIdStr) != 0 {
			courseId, err := strconv.Atoi(courseIdStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for  courseId, error: %v", err)
			}

			enrollment.CourseID = utils.Int64ToPointer(int64(courseId))
		}

		status := validateEnrollmentStatus(row[3])
		enrollment.Status = &status

		enrollmentDateStr := strings.TrimSpace(row[4])
		if len(enrollmentDateStr) != 0 {
			enrollmentDate, err := time.Parse("2006-01-02 15:04:05", enrollmentDateStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for enrollment date column,error: %v", err)
			}
			enrollment.EnrollmentDate = &enrollmentDate
		}

		createdAtStr := strings.TrimSpace(row[5])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			enrollment.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[6])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return enrollment, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			enrollment.UpdatedAt = &updatedAt
		}

	default:
		fmt.Printf("invalid number of row")
	}

	return enrollment, nil

}

func validateEnrollmentStatus(status string) string {
	if status == "started" {
		return "started"
	} else if status == "in-progress" {
		return "in-progress"
	} else if status == "completed" {
		return "completed"
	} else {
		return "started"
	}
}

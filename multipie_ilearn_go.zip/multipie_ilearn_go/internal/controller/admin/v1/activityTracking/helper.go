package activitytracking

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/activityTracking"
	"multipie_ilearn_go/internal/logger"

	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (c *userActivityController) batchCreateUserActivityHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount       int
		batchNo        int
		userActivities []dbModel.UserActivity
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}

		if len(row) < 7 || len(row) > 8 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		userActivity, err := c.extractDataForCreateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		userActivities = append(userActivities, userActivity)
		if len(userActivities) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchCreateUserActivity(ctx, userActivities); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			userActivities = []dbModel.UserActivity{} //clear courses array
		}

	}

	if len(userActivities) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchCreateUserActivity(ctx, userActivities); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

func (c *userActivityController) extractDataForCreateFile(row []string) (dbModel.UserActivity, error) {
	var (
		activityTracking dbModel.UserActivity
	)

	switch {
	case len(row) == 7:
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			activityTracking.UserID = utils.Int64ToPointer(int64(userId))
		}

		activityStatusStr := strings.TrimSpace(row[1])
		if len(activityStatusStr) != 0 {
			activityStatus, err := validateActivityStatus(activityStatusStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for activity status, error: %v", err)
			}
			activityTracking.ActivityStatus = &activityStatus
		}

		additionalDataStr := strings.TrimSpace(row[2])
		if len(additionalDataStr) != 0 {
			var additionalData dbModel.AdditionalData

			err := json.Unmarshal([]byte(additionalDataStr), &additionalData)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid additional data :%v", err)

			}
			activityTracking.AdditionalData = &additionalData
		} else {
			return activityTracking, fmt.Errorf("invalid additional data ")
		}

		resourceIdStr := strings.TrimSpace(row[3])
		if len(resourceIdStr) != 0 {
			resourceId, err := strconv.Atoi(resourceIdStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for  resource Id, error: %v", err)
			}

			activityTracking.ResourceID = utils.Int64ToPointer(int64(resourceId))
		}

		courseModuleIdStr := strings.TrimSpace(row[4])
		if len(courseModuleIdStr) != 0 {
			courseModuleId, err := strconv.Atoi(courseModuleIdStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for  course module Id, error: %v", err)
			}

			activityTracking.CourseModuleID = utils.Int64ToPointer(int64(courseModuleId))
		}

		if activityTracking.CourseModuleID == nil && activityTracking.ResourceID == nil {
			return activityTracking, fmt.Errorf("one of the course model id or resource model id must be enter, error")
		}

		createdAtStr := strings.TrimSpace(row[5])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			activityTracking.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[6])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			activityTracking.UpdatedAt = &updatedAt
		}

		return activityTracking, nil

	case len(row) == 8:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return activityTracking, fmt.Errorf("failed to convert into integer: %v", err)
		}
		activityTracking.ID = utils.Int64ToPointer(int64(id))

		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			activityTracking.UserID = utils.Int64ToPointer(int64(userId))
		}

		activityStatusStr := strings.TrimSpace(row[2])
		if len(activityStatusStr) != 0 {
			activityStatus, err := validateActivityStatus(activityStatusStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for activity status, error: %v", err)
			}
			activityTracking.ActivityStatus = &activityStatus
		}

		additionalDataStr := strings.TrimSpace(row[3])
		if len(additionalDataStr) != 0 {
			var additionalData dbModel.AdditionalData

			err := json.Unmarshal([]byte(additionalDataStr), &additionalData)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid additional data :%v", err)

			}
			activityTracking.AdditionalData = &additionalData
		} else {
			return activityTracking, fmt.Errorf("invalid additional data :%v", err)
		}

		resourceIdStr := strings.TrimSpace(row[4])
		if len(resourceIdStr) != 0 {
			resourceId, err := strconv.Atoi(resourceIdStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for  resource Id, error: %v", err)
			}

			activityTracking.ResourceID = utils.Int64ToPointer(int64(resourceId))
		}

		courseModuleIdStr := strings.TrimSpace(row[5])
		if len(courseModuleIdStr) != 0 {
			courseModuleId, err := strconv.Atoi(courseModuleIdStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for  course module Id, error: %v", err)
			}

			activityTracking.CourseModuleID = utils.Int64ToPointer(int64(courseModuleId))
		}

		if activityTracking.CourseModuleID == nil && activityTracking.ResourceID == nil {
			return activityTracking, fmt.Errorf("one of the course model id or resource model id must be enter, error: %v", err)
		}

		createdAtStr := strings.TrimSpace(row[6])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			activityTracking.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[7])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return activityTracking, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			activityTracking.UpdatedAt = &updatedAt
		}

	default:
		fmt.Printf("invalid number of row")
	}

	return activityTracking, nil

}

func validateActivityStatus(activityStatus string) (constants.ActivityStatusEnum, error) {
	return constants.ParseActivityStatusEnum(activityStatus)
}

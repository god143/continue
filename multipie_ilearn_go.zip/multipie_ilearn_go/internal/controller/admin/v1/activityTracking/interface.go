package activitytracking

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type userActivityController struct {
	db db.DBLayer
}

type UserActivityControllerGroup interface {
	BatchCreateUserActivity(ctx *gin.Context)
}

func NewUserActivityController(db db.DBLayer) UserActivityControllerGroup {
	return &userActivityController{
		db: db,
	}
}

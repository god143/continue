package quizAttempts

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (q *quizAttemptsController) BatchCreateQuizAttempts(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = q.batchCreateQuizAttemptsHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of quiz attempts is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

package quizAttempts

import (
	"context"
	"encoding/csv"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModelQuizAttempts "multipie_ilearn_go/internal/db/quizAttempts"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"time"

	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (q *quizAttemptsController) batchCreateQuizAttemptsHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount     int
		batchNo      int
		quizAttempts []dbModelQuizAttempts.QuizAttempts
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 9 || len(row) > 10 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		quizAttempt, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		quizAttempts = append(quizAttempts, quizAttempt)
		if len(quizAttempts) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateQuizAttempts(ctx, quizAttempts); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			quizAttempts = []dbModelQuizAttempts.QuizAttempts{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(quizAttempts) > 0 {
		if err := q.db.BatchCreateQuizAttempts(ctx, quizAttempts); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (q *quizAttemptsController) extractDataFromFile(row []string) (dbModelQuizAttempts.QuizAttempts, error) {
	var quizAttempt dbModelQuizAttempts.QuizAttempts
	switch {
	case len(row) == 9:
		//validate userId
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			quizAttempt.UserId = utils.Int64ToPointer(int64(userId))
		}

		quizIdStr := strings.TrimSpace(row[1])
		if len(quizIdStr) != 0 {
			quizId, err := strconv.Atoi(quizIdStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for  quizId, error: %v", err)
			}

			quizAttempt.QuizId = utils.Int64ToPointer(int64(quizId))
		}

		//validate courseId
		attemptNumberStr := strings.TrimSpace(row[2])
		if len(attemptNumberStr) != 0 {
			AttemptNumber, err := strconv.Atoi(attemptNumberStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for attempt Number, error: %v", err)
			}

			quizAttempt.AttemptNumber = utils.Int64ToPointer(int64(AttemptNumber))
		}

		//validate pass percentage
		scoreStr := strings.TrimSpace(row[3])
		if len(scoreStr) == 0 {
			return quizAttempt, fmt.Errorf("value for score field cannot be blank")
		}
		score, err := strconv.ParseFloat(scoreStr, 64)
		if err != nil {
			return quizAttempt, fmt.Errorf("invalid value for score, error: %v", err)
		}
		quizAttempt.Score = utils.FloatToPointer(score)

		//validate pass percentage
		lastAttemptAtStr := strings.TrimSpace(row[4])
		if len(lastAttemptAtStr) != 0 {
			lastAttemptAt, err := time.Parse("2006-01-02 15:04:05", lastAttemptAtStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for last attempt at column,error: %v", err)
			}
			quizAttempt.LastAttemptAt = &lastAttemptAt
		}

		//validate pass percentage
		status, err := validateQuizAttemptStatus(row[5])
		if err != nil {
			return quizAttempt, fmt.Errorf("invalid value for status, error: %v", err)
		}
		quizAttempt.Status = &status

		//validate pass percentage
		createdAtStr := strings.TrimSpace(row[6])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			quizAttempt.CreatedAt = &createdAt
		}

		//validate pass percentage
		updatedAtStr := strings.TrimSpace(row[7])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			quizAttempt.UpdatedAt = &updatedAt
		}

		hasCheckedAnswerStr := strings.TrimSpace(row[8])
		if len(hasCheckedAnswerStr) == 0 {
			return quizAttempt, fmt.Errorf("value for haschecked Answer cannot be blank")
		}
		hasCheckedAnswer, err := strconv.ParseBool(hasCheckedAnswerStr)
		if err != nil {
			return quizAttempt, fmt.Errorf("invalid value for haschecked answer, error: %v", err)
		}
		quizAttempt.HasCheckedAnswer = &hasCheckedAnswer

	case len(row) == 10:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return quizAttempt, fmt.Errorf("failed to convert into integer: %v", err)
		}
		quizAttempt.ID = utils.Int64ToPointer(int64(id))

		//validate userId
		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			quizAttempt.UserId = utils.Int64ToPointer(int64(userId))
		}

		quizIdStr := strings.TrimSpace(row[2])
		if len(quizIdStr) != 0 {
			quizId, err := strconv.Atoi(quizIdStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for  quizId, error: %v", err)
			}

			quizAttempt.QuizId = utils.Int64ToPointer(int64(quizId))
		}

		//validate courseId
		attemptNumberStr := strings.TrimSpace(row[3])
		if len(attemptNumberStr) != 0 {
			AttemptNumber, err := strconv.Atoi(attemptNumberStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for attempt Number, error: %v", err)
			}

			quizAttempt.AttemptNumber = utils.Int64ToPointer(int64(AttemptNumber))
		}

		//validate pass percentage
		scoreStr := strings.TrimSpace(row[4])
		if len(scoreStr) == 0 {
			return quizAttempt, fmt.Errorf("value for score field cannot be blank")
		}
		score, err := strconv.ParseFloat(scoreStr, 64)
		if err != nil {
			return quizAttempt, fmt.Errorf("invalid value for score, error: %v", err)
		}
		quizAttempt.Score = utils.FloatToPointer(score)

		//validate pass percentage
		lastAttemptAtStr := strings.TrimSpace(row[5])
		if len(lastAttemptAtStr) != 0 {
			lastAttemptAt, err := time.Parse("2006-01-02 15:04:05", lastAttemptAtStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for last attempt at column,error: %v", err)
			}
			quizAttempt.LastAttemptAt = &lastAttemptAt
		}

		//validate pass percentage
		status, err := validateQuizAttemptStatus(row[6])
		if err != nil {
			return quizAttempt, fmt.Errorf("invalid value for status, error: %v", err)
		}
		quizAttempt.Status = &status

		//validate pass percentage
		createdAtStr := strings.TrimSpace(row[7])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			quizAttempt.CreatedAt = &createdAt
		}

		//validate pass percentage
		updatedAtStr := strings.TrimSpace(row[8])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return quizAttempt, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			quizAttempt.UpdatedAt = &updatedAt
		}

		hasCheckedAnswerStr := strings.TrimSpace(row[9])
		if len(hasCheckedAnswerStr) == 0 {
			return quizAttempt, fmt.Errorf("value for haschecked Answer cannot be blank")
		}
		hasCheckedAnswer, err := strconv.ParseBool(hasCheckedAnswerStr)
		if err != nil {
			return quizAttempt, fmt.Errorf("invalid value for haschecked answer , error: %v", err)
		}
		quizAttempt.HasCheckedAnswer = &hasCheckedAnswer

	default:
		fmt.Printf("invalid number of row")
	}

	return quizAttempt, nil

}

func validateQuizAttemptStatus(status string) (constants.QuizAttemptsStatusEnum, error) {
	return constants.ParseQuizAttemptsStatusEnum(status)
}

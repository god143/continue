package quizAttempts

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type quizAttemptsController struct {
	db db.DBLayer
}

type QuizAttemptsControllerGroup interface {
	BatchCreateQuizAttempts(ctx *gin.Context)
}

func NewQuizController(db db.DBLayer) QuizAttemptsControllerGroup {
	return &quizAttemptsController{
		db: db,
	}
}

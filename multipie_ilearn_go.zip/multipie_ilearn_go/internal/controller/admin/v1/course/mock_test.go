package course

// import (
// 	"bytes"
// 	"context"
// 	"encoding/json"
// 	"errors"
// 	"fmt"
// 	"mime/multipart"
// 	"net/http"
// 	"net/http/httptest"
// 	"os"
// 	"testing"

// 	"multipie_ilearn_go/internal/db"
// 	dbModel "multipie_ilearn_go/internal/db/course"
// 	"multipie_ilearn_go/internal/logger"
// 	"multipie_ilearn_go/internal/utils"

// 	"github.com/gin-gonic/gin"
// 	"github.com/stretchr/testify/assert"
// 	"github.com/stretchr/testify/mock"
// )

// // --- Mock Setup ---
// type MockCourseDB struct {
// 	mock.Mock
// 	db.DBLayer
// }

// func (m *MockCourseDB) GetCourseByID(ctx context.Context, id int64, vis *bool) (dbModel.Course, error) {
// 	args := m.Called(ctx, id, vis)
// 	return args.Get(0).(dbModel.Course), args.Error(1)
// }

// func (m *MockCourseDB) GetCourseByCategory(ctx context.Context, catID int64, vis *bool) ([]dbModel.Course, error) {
// 	args := m.Called(ctx, catID, vis)
// 	return args.Get(0).([]dbModel.Course), args.Error(1)
// }

// func (m *MockCourseDB) CreateCourse(ctx context.Context, c *dbModel.Course) (*dbModel.Course, error) {
// 	args := m.Called(ctx, c)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.Course), args.Error(1)
// }

// func (m *MockCourseDB) BatchCreateCourses(ctx context.Context, courses []dbModel.Course) error {
// 	return m.Called(ctx, courses).Error(0)
// }

// func (m *MockCourseDB) UpdateCourse(ctx context.Context, c *dbModel.Course) (*dbModel.Course, error) {
// 	args := m.Called(ctx, c)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.Course), args.Error(1)
// }
// func (m *MockCourseDB) DisbaleCourse(ctx context.Context, id int64) error {
// 	return m.Called(ctx, id).Error(0)
// }

// func (m *MockCourseDB) BatchUpdateCourses(ctx context.Context, c []dbModel.Course) error {
// 	return m.Called(ctx, c).Error(0)
// }
// func TestMain(m *testing.M) {
// 	// Initialize logger to prevent nil pointer dereference panics
// 	_ = logger.NewLogger("test", "error", "")
// 	gin.SetMode(gin.TestMode)
// 	os.Exit(m.Run())
// }
// func setupTest() (*gin.Engine, *MockCourseDB, CourseControllerGroup) {
// 	gin.SetMode(gin.TestMode)
// 	mockDB := new(MockCourseDB)
// 	ctrl := NewCourseControllerGroup(mockDB)
// 	r := gin.New()
// 	return r, mockDB, ctrl
// }

// // --- Unit Tests ---
// func TestCourseController_GetCourseByCategory(t *testing.T) {
// 	tests := []struct {
// 		name           string
// 		query          string
// 		setupMock      func(*MockCourseDB)
// 		expectedStatus int
// 	}{
// 		{
// 			name:  "Happy Path - Fetch by Category",
// 			query: "?category_id=5",
// 			setupMock: func(m *MockCourseDB) {
// 				m.On("GetCourseByCategory", mock.Anything, int64(5), mock.Anything).
// 					Return([]dbModel.Course{{ID: utils.Int64ToPointer(1)}}, nil)
// 			},
// 			expectedStatus: http.StatusOK,
// 		},
// 		{
// 			name:           "Edge Case - Missing Category ID",
// 			query:          "",
// 			setupMock:      func(m *MockCourseDB) {},
// 			expectedStatus: http.StatusBadRequest,
// 		},
// 		{
// 			name:           "Edge Case - Invalid Category Format",
// 			query:          "?category_id=abc",
// 			setupMock:      func(m *MockCourseDB) {},
// 			expectedStatus: http.StatusBadRequest,
// 		},
// 		{
// 			name:  "Edge Case - Database Failure",
// 			query: "?category_id=5",
// 			setupMock: func(m *MockCourseDB) {
// 				m.On("GetCourseByCategory", mock.Anything, int64(5), mock.Anything).
// 					Return([]dbModel.Course{}, errors.New("db connection lost"))
// 			},
// 			expectedStatus: http.StatusInternalServerError,
// 		},
// 	}
// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			m := new(MockCourseDB)
// 			tt.setupMock(m)
// 			ctrl := NewCourseControllerGroup(m)

// 			w := httptest.NewRecorder()
// 			c, _ := gin.CreateTestContext(w)
// 			req, _ := http.NewRequest("GET", "/courses"+tt.query, nil)
// 			c.Request = req
// 			ctrl.GetCoursesByCategory(c)
// 			assert.Equal(t, tt.expectedStatus, w.Code)
// 		})
// 	}
// }
// func TestCourseController_GetCourseDetails(t *testing.T) {
// 	tests := []struct {
// 		name           string
// 		courseID       string
// 		setupMock      func(*MockCourseDB)
// 		expectedStatus int
// 	}{
// 		{
// 			name:     "Happy Path - Course Details",
// 			courseID: "100",
// 			setupMock: func(m *MockCourseDB) {
// 				m.On("GetCourseByID", mock.Anything, int64(100), mock.Anything).
// 					Return(dbModel.Course{ID: utils.Int64ToPointer(100)}, nil)
// 			},
// 			expectedStatus: http.StatusOK,
// 		},
// 		{
// 			name:           "Edge Case - Invalid ID format",
// 			courseID:       "not-an-int",
// 			setupMock:      func(m *MockCourseDB) {},
// 			expectedStatus: http.StatusBadRequest,
// 		},
// 		{
// 			name:     "Edge Case - Course Not Found",
// 			courseID: "404",
// 			setupMock: func(m *MockCourseDB) {
// 				m.On("GetCourseByID", mock.Anything, int64(404), mock.Anything).
// 					Return(dbModel.Course{}, errors.New("not found"))
// 			},
// 			expectedStatus: http.StatusInternalServerError,
// 		},
// 	}

// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			m := new(MockCourseDB)
// 			tt.setupMock(m)
// 			ctrl := NewCourseControllerGroup(m)

// 			w := httptest.NewRecorder()
// 			c, _ := gin.CreateTestContext(w)
// 			c.Params = gin.Params{{Key: "course_id", Value: tt.courseID}}

// 			ctrl.GetCourseDetails(c)
// 			assert.Equal(t, tt.expectedStatus, w.Code)
// 		})
// 	}
// }
// func TestCreateCourse_AllCases(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/course", ctrl.CreateCourse)

// 	t.Run("Happy Case", func(t *testing.T) {
// 		body := map[string]interface{}{
// 			"fullname": "Go", "shortname": "go", "category_id": 1,
// 			"difficulty_level": "beginner", "summary": "test", "format": "video", // FIXED ENUMS
// 		}
// 		id := int64(1)
// 		mockDB.On("CreateCourse", mock.Anything, mock.Anything).Return(&dbModel.Course{ID: &id}, nil).Once()

// 		jsonVal, _ := json.Marshal(body)
// 		req, _ := http.NewRequest("POST", "/course", bytes.NewBuffer(jsonVal))
// 		req.Header.Set("Content-Type", "application/json")
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)

// 		assert.Equal(t, http.StatusOK, w.Code)
// 		mockDB.AssertExpectations(t)
// 	})

// 	t.Run("Edge: DB Failure", func(t *testing.T) {
// 		body := map[string]interface{}{
// 			"fullname": "Go", "shortname": "go", "category_id": 1,
// 			"difficulty_level": "beginner", "summary": "test", "format": "article",
// 		}
// 		mockDB.On("CreateCourse", mock.Anything, mock.Anything).Return(nil, fmt.Errorf("db fail")).Once()

// 		jsonVal, _ := json.Marshal(body)
// 		req, _ := http.NewRequest("POST", "/course", bytes.NewBuffer(jsonVal))
// 		req.Header.Set("Content-Type", "application/json")
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// }

// func TestBatchCreateCourse_Coverage(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/batch", ctrl.BatchCreateCourse)
// 	t.Run("Edge - Column Mismatch", func(t *testing.T) {
// 		csvContent := "h1,h2\nval1,val2" // Only 2 columns instead of 9
// 		body := &bytes.Buffer{}
// 		writer := multipart.NewWriter(body)
// 		part, _ := writer.CreateFormFile("file", "test.csv")
// 		part.Write([]byte(csvContent))
// 		writer.Close()

// 		req, _ := http.NewRequest("POST", "/batch", body)
// 		req.Header.Set("Content-Type", writer.FormDataContentType())
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "not enough column")
// 		mockDB.AssertExpectations(t)
// 	})
// }
// func TestExtractDataForUpdate_Edges(t *testing.T) {
// 	// This covers the extractDataForUpdateFile specific logic for 90% coverage
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/bulk-update", ctrl.BulkUpdateCourses)

// 	t.Run("Invalid Course ID (Non-Integer)", func(t *testing.T) {
// 		csv := "id,f,s,c,d,sum,st,en,fo,du\nABC,name,short,1,Beginner,sum,,,online,10"
// 		body := &bytes.Buffer{}
// 		writer := multipart.NewWriter(body)
// 		part, _ := writer.CreateFormFile("file", "test.csv")
// 		part.Write([]byte(csv))
// 		writer.Close()

// 		req, _ := http.NewRequest("POST", "/bulk-update", body)
// 		req.Header.Set("Content-Type", writer.FormDataContentType())
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "invalid value for course_id")
// 		mockDB.AssertNotCalled(t, "BatchUpdateCourses", mock.Anything, mock.Anything)

// 	})
// }

// func TestBulkUpdateCourses_Coverage(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/bulk-update", ctrl.BulkUpdateCourses)

// 	t.Run("Happy Path - 10 Columns", func(t *testing.T) {
// 		// Bulk update expects 10 columns: id, f, s, c, d, sum, st, en, fo, du
// 		csvContent := "id,fullname,shortname,category_id,difficulty,summary,start,end,format,duration\n" +
// 			"1,New Name,SN,1,intermediate,New Sum,2023-01-01,2023-12-31,article,20"

// 		mockDB.On("BatchUpdateCourses", mock.Anything, mock.Anything).Return(nil).Once()

// 		body := &bytes.Buffer{}
// 		writer := multipart.NewWriter(body)
// 		part, _ := writer.CreateFormFile("file", "update.csv")
// 		part.Write([]byte(csvContent))
// 		writer.Close()

// 		req, _ := http.NewRequest("POST", "/bulk-update", body)
// 		req.Header.Set("Content-Type", writer.FormDataContentType())
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)

// 		assert.Equal(t, http.StatusOK, w.Code)
// 		assert.Contains(t, w.Body.String(), "batch updation of course is successful")
// 	})
// }

// func TestDisableCourse_AllCases(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/disable", ctrl.DisableCourse)

// 	t.Run("Happy Case", func(t *testing.T) {
// 		mockDB.On("DisbaleCourse", mock.Anything, int64(10)).Return(nil).Once()

// 		body, _ := json.Marshal(map[string]interface{}{"course_id": 10})
// 		req, _ := http.NewRequest("POST", "/disable", bytes.NewBuffer(body))
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})
// }

// func TestExtractData_ValidationEdges(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/batch-create", ctrl.BatchCreateCourse)
// 	r.POST("/bulk-update", ctrl.BulkUpdateCourses)

// 	// We must mock the DB even for failed cases to satisfy expectations if it accidentally passes
// 	mockDB.On("BatchCreateCourses", mock.Anything, mock.Anything).Return(nil).Maybe()
// 	mockDB.On("BatchUpdateCourses", mock.Anything, mock.Anything).Return(nil).Maybe()
// 	t.Run("Update: Invalid Course ID", func(t *testing.T) {
// 		// Bulk Update row[0] is CourseID. Giving: ABC (non-int)
// 		csv := "id,f,s,c,d,sum,st,en,fo,du\n" +
// 			"ABC,Name,S,1,beginner,Sum,,,video,10"
// 		w := executeMultipartRequest(r, "/bulk-update", "file", csv)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "invalid value for course_id column")
// 	})

// 	t.Run("Update: Blank Category ID", func(t *testing.T) {
// 		// Bulk Update row[3] is CategoryID.
// 		csv := "id,f,s,c,d,sum,st,en,fo,du\n" +
// 			"1,Name,S, ,beginner,Sum,,,video,10"
// 		w := executeMultipartRequest(r, "/bulk-update", "file", csv)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "category_id value is blank")
// 	})
// }
// func TestCourseAssetUpload_Coverage(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.POST("/upload", ctrl.CourseAssetUpload)

// 	t.Run("Edge: Invalid Request (Missing File/ID)", func(t *testing.T) {
// 		// Send empty request to trigger ShouldBind error
// 		req, _ := http.NewRequest("POST", "/upload", nil)
// 		w := httptest.NewRecorder()
// 		r.ServeHTTP(w, req)

// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 		assert.Contains(t, w.Body.String(), "invalid request body")
// 		mockDB.AssertNotCalled(t, "AssetUpload", mock.Anything, mock.Anything)

// 	})
// }
// func TestCourseLifecycle_All(t *testing.T) {
// 	r, mockDB, ctrl := setupTest()
// 	r.PUT("/update", ctrl.UpdateCourse)
// 	r.POST("/disable", ctrl.DisableCourse)

// 	t.Run("UpdateCourse: Happy Case", func(t *testing.T) {
// 		id := int64(1)
// 		mockDB.On("UpdateCourse", mock.Anything, mock.Anything).Return(&dbModel.Course{ID: &id}, nil).Once()

// 		body := map[string]interface{}{
// 			"id": 1, "difficulty_level": "intermediate", "format": "article",
// 		}
// 		w := executeJSONRequest(r, "PUT", "/update", body)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 		assert.Contains(t, w.Body.String(), "course updated successfully")
// 	})
// 	t.Run("DisableCourse: Happy Case", func(t *testing.T) {
// 		mockDB.On("DisbaleCourse", mock.Anything, int64(50)).Return(nil).Once()

// 		body := map[string]interface{}{"course_id": 50}
// 		w := executeJSONRequest(r, "POST", "/disable", body)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 		assert.Contains(t, w.Body.String(), "category disabled successfully")
// 	})
// }
// func executeMultipartRequest(r *gin.Engine, path, field, content string) *httptest.ResponseRecorder {
// 	body := &bytes.Buffer{}
// 	writer := multipart.NewWriter(body)
// 	part, _ := writer.CreateFormFile(field, "test.csv")
// 	part.Write([]byte(content))
// 	writer.Close()

// 	req, _ := http.NewRequest("POST", path, body)
// 	req.Header.Set("Content-Type", writer.FormDataContentType())
// 	w := httptest.NewRecorder()
// 	r.ServeHTTP(w, req)
// 	return w
// }
// func executeJSONRequest(r *gin.Engine, method, path string, body interface{}) *httptest.ResponseRecorder {
// 	jsonVal, _ := json.Marshal(body)
// 	req, _ := http.NewRequest(method, path, bytes.NewBuffer(jsonVal))
// 	req.Header.Set("Content-Type", "application/json")
// 	w := httptest.NewRecorder()
// 	r.ServeHTTP(w, req)
// 	return w
// }
// // --- Benchmarks ---
// func BenchmarkGetCourseDetails(b *testing.B) {
// 	m := new(MockCourseDB)
// 	m.On("GetCourseByID", mock.Anything, mock.Anything, mock.Anything).
// 		Return(dbModel.Course{ID: utils.Int64ToPointer(1)}, nil)
// 	ctrl := NewCourseControllerGroup(m)

// 	b.ResetTimer()
// 	for i := 0; i < b.N; i++ {
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)
// 		c.Params = gin.Params{{Key: "course_id", Value: "1"}}
// 		ctrl.GetCourseDetails(c)
// 	}
// }
// func BenchmarkGetCourseByCategory(b *testing.B) {
// 	m := new(MockCourseDB)
// 	m.On("GetCourseByCategory", mock.Anything, mock.Anything, mock.Anything).
// 		Return([]dbModel.Course{{ID: utils.Int64ToPointer(1)}}, nil)
// 	ctrl := NewCourseControllerGroup(m)

// 	b.ResetTimer()
// 	for i := 0; i < b.N; i++ {
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)
// 		req, _ := http.NewRequest("GET", "/?category_id=1", nil)
// 		c.Request = req
// 		ctrl.GetCoursesByCategory(c)
// 	}
// }
// func BenchmarkBatchCreateCourse(b *testing.B) {
// 	gin.SetMode(gin.TestMode)
// 	mockDB := new(MockCourseDB)
// 	mockDB.On("BatchCreateCourses", mock.Anything, mock.Anything).Return(nil)
// 	ctrl := NewCourseControllerGroup(mockDB)

// 	csvContent := "fullname,shortname,category_id,difficulty,summary,start,end,format,duration\n" +
// 		"Bench,B,1,beginner,S,2023-01-01,2023-12-31,video,10"

// 	b.ResetTimer()
// 	for i := 0; i < b.N; i++ {
// 		body := &bytes.Buffer{}
// 		writer := multipart.NewWriter(body)
// 		part, _ := writer.CreateFormFile("file", "test.csv")
// 		part.Write([]byte(csvContent))
// 		writer.Close()

// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)
// 		c.Request, _ = http.NewRequest("POST", "/batch", body)
// 		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

// 		ctrl.BatchCreateCourse(c)
// 	}
// }
// func BenchmarkBulkUpdate(b *testing.B) {
// 	_, mockDB, ctrl := setupTest()
// 	mockDB.On("BatchUpdateCourses", mock.Anything, mock.Anything).Return(nil)

// 	csv := "id,fullname,shortname,category_id,difficulty,summary,start,end,format,duration\n1,N,S,1,beginner,S,,,video,1"

// 	b.ResetTimer()
// 	for i := 0; i < b.N; i++ {
// 		body := &bytes.Buffer{}
// 		w := multipart.NewWriter(body)
// 		p, _ := w.CreateFormFile("file", "b.csv")
// 		p.Write([]byte(csv))
// 		w.Close()

// 		req, _ := http.NewRequest("POST", "/", body)
// 		req.Header.Set("Content-Type", w.FormDataContentType())
// 		c, _ := gin.CreateTestContext(httptest.NewRecorder())
// 		c.Request = req
// 		ctrl.BulkUpdateCourses(c)
// 	}
// }

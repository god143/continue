package course

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *courseController) GetCoursesByCategory(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseByCategoryRequest
	)
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	courseResp, err := c.getCourseByCategoryHelper(ctx, request)
	if err != nil {
		logger.Error(ctx, "unable to fetch course", zap.Int64("category", request.CategoryID), zap.Error(err))
		resp := utils.NewV1Response(nil, utils.StringToPointer("unable to fetch course"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(courseResp, nil))
}

func (c *courseController) GetCourseDetails(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseDetailsRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid courseId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	courseResp, err := c.getCourseDetailsHelper(ctx, request)
	if err != nil {
		logger.Error(ctx, "unable to fetch course", zap.Int64("courseId", request.CourseID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch course"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(courseResp, nil))
}

func (c *courseController) CreateCourse(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateCourseRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createCourseResp, err := c.createCourseHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createCourseResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *courseController) UpdateCourse(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateCourseRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.updateCourseHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("course updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *courseController) DisableCourse(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DisableCourseRequest
	)

	if err := ctx.BindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.disableCourseHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("category disabled successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *courseController) BatchCreateCourse(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchCreateCourseHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of course is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *courseController) BulkUpdateCourses(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchUpdateCoursesHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch updation of course is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *courseController) CourseAssetUpload(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request AssetUploadRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err), zap.Any("requestBody", request))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	assetUploadResponse, err := c.courseAssetUploadHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(assetUploadResponse, nil)
	ctx.JSON(http.StatusOK, resp)
}

package course

import (
	"mime/multipart"
)

type GetCourseByCategoryRequest struct {
	CategoryID int64 `form:"category_id" binding:"required"`
}

type GetCourseDetailsRequest struct {
	CourseID int64 `uri:"course_id" binding:"required"`
}

type CreateCourseRequest struct {
	Fullname        *string `json:"fullname" binding:"required"`
	Shortname       *string `json:"shortname" binding:"required"`
	CategoryID      *int64  `json:"category_id" binding:"required"`
	DifficultyLevel *string `json:"difficulty_level" binding:"required"`
	Summary         *string `json:"summary" binding:"required"`
	StartDate       *string `json:"start_date"`
	EndDate         *string `json:"end_date"`
	Format          *string `json:"format" binding:"required"`
	Duration        *int64  `json:"duration"`
}

type CreateCourseResponse struct {
	ID int64 `json:"id"`
}

type UpdateCourseRequest struct {
	ID              *int64  `json:"id" binding:"required"`
	Fullname        *string `json:"fullname"`
	Shortname       *string `json:"shortname"`
	CategoryID      *int64  `json:"category_id"`
	DifficultyLevel *string `json:"difficulty_level"`
	Summary         *string `json:"summary"`
	StartDate       *string `json:"start_date"`
	EndDate         *string `json:"end_date"`
	Format          *string `json:"format"`
	Duration        *int64  `json:"duration"`
	Banner          *string `json:"banner"`
}

type UpdateCourseResponse struct {
	ID int64 `json:"id"`
}

type DisableCourseRequest struct {
	ID int64 `json:"course_id" binding:"required"`
}

type AssetUploadRequest struct {
	CourseId  *int64                `form:"course_id" binding:"required"`
	AssetFile *multipart.FileHeader `form:"asset_file" binding:"required"` // For the uploaded file
}

type AssetUploadResponse struct {
	Path string `json:"path"`
}

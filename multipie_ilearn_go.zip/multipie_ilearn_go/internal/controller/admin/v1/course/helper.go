package course

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/course"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (c *courseController) getCourseByCategoryHelper(ctx context.Context, request GetCourseByCategoryRequest) ([]dbModel.Course, error) {
	courses, err := c.db.GetCourseByCategory(ctx, request.CategoryID, nil)
	if err != nil {
		logger.Error(ctx, "error in fetching courses from database", zap.Error(err))
		return courses, err
	}

	return courses, nil
}

func (c *courseController) getCourseDetailsHelper(ctx context.Context, request GetCourseDetailsRequest) (dbModel.Course, error) {

	course, err := c.db.GetCourseByID(ctx, request.CourseID, nil)
	if err != nil {
		logger.Error(ctx, "error in course details from database", zap.Int64("courseID", request.CourseID), zap.Error(err))
		return course, err
	}

	return course, nil
}

func (c *courseController) createCourseHelper(ctx context.Context, request CreateCourseRequest) (CreateCourseResponse, error) {
	var (
		resp CreateCourseResponse
	)
	// TODO: Move validation logic into validator pkg
	//Validate diffculty level and format
	diffcultyLevel, err := validateCourseDiffcultyLevel(*request.DifficultyLevel)
	if err != nil {
		logger.Error(ctx, "invalid value for course diffculty level", zap.Error(err), zap.Any("input value", request.DifficultyLevel))
		return resp, fmt.Errorf("invalid value for course diffculty level, error: %v", err)
	}

	//validate format of the course
	courseFormat, err := validateCourseFormat(*request.Format)
	if err != nil {
		logger.Error(ctx, "invalid value for course format", zap.Error(err), zap.Any("input value", request.Format))
		return resp, fmt.Errorf("invalid value for course format, error: %v", err)
	}

	//format start date
	if request.StartDate != nil {
		_, err = parseCourseStartDate(*request.StartDate)
		if err != nil {
			logger.Error(ctx, "invalid value for course start date", zap.Error(err), zap.Any("input value", request.StartDate))
			return resp, fmt.Errorf("invalid value for course format, error: %v", err)
		}
	}

	//format end date
	if request.EndDate != nil {
		_, err = parseCourseStartDate(*request.EndDate)
		if err != nil {
			logger.Error(ctx, "invalid value for course start date", zap.Error(err), zap.Any("input value", request.StartDate))
			return resp, fmt.Errorf("invalid value for course format, error: %v", err)
		}
	}

	course := &dbModel.Course{
		Fullname:        request.Fullname,
		Shortname:       request.Shortname,
		CategoryID:      request.CategoryID,
		DifficultyLevel: &diffcultyLevel,
		Summary:         request.Summary,
		StartDate:       request.StartDate,
		EndDate:         request.EndDate,
		Format:          &courseFormat,
		Duration:        request.Duration,
		Visible:         utils.BoolToPointer(true),
	}

	course, err = c.db.CreateCourse(ctx, course)
	if err != nil {
		logger.Error(ctx, "unable to create course entry in database", zap.Error(err), zap.Any("requestBody", request))
		return resp, errors.New("unable to create course entry in database")
	}

	resp = CreateCourseResponse{
		ID: *course.ID,
	}

	return resp, nil

}

func (c *courseController) updateCourseHelper(ctx context.Context, request UpdateCourseRequest) error {

	course := &dbModel.Course{
		ID:         request.ID,
		Fullname:   request.Fullname,
		Shortname:  request.Shortname,
		CategoryID: request.CategoryID,
		Summary:    request.Summary,
		Duration:   request.Duration,
		Banner:     request.Banner,
	}

	//Validate diffculty level and format
	if request.DifficultyLevel != nil {
		diffcultyLevel, err := validateCourseDiffcultyLevel(*request.DifficultyLevel)
		if err != nil {
			logger.Error(ctx, "invalid value for course diffculty level", zap.Error(err), zap.Any("input value", request.DifficultyLevel))
			return fmt.Errorf("invalid value for course diffculty level, error: %v", err)
		}
		course.DifficultyLevel = &diffcultyLevel
	}

	//validate format of the course
	if request.Format != nil {
		courseFormat, err := validateCourseFormat(*request.Format)
		if err != nil {
			logger.Error(ctx, "invalid value for course format", zap.Error(err), zap.Any("input value", request.Format))
			return fmt.Errorf("invalid value for course format, error: %v", err)
		}
		course.Format = &courseFormat
	}

	//format start date
	if request.StartDate != nil {
		_, err := parseCourseStartDate(*request.StartDate)
		if err != nil {
			logger.Error(ctx, "invalid value for course start date format", zap.Error(err), zap.Any("input value", request.StartDate))
			return fmt.Errorf("invalid value for course start date format, error: %v", err)
		}
		course.StartDate = request.StartDate
	}

	//format end date
	if request.EndDate != nil {
		_, err := parseCourseStartDate(*request.EndDate)
		if err != nil {
			logger.Error(ctx, "invalid value for course end date format", zap.Error(err), zap.Any("input value", request.StartDate))
			return fmt.Errorf("invalid value for course end date format, error: %v", err)
		}
		course.EndDate = request.EndDate
	}

	_, err := c.db.UpdateCourse(ctx, course)
	if err != nil {
		logger.Error(ctx, "unable to update course entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update course entry in database")
	}

	return nil

}

/*
disableCourseHelper... disable(i.e. make visible=false) course in database
*/
func (c *courseController) disableCourseHelper(ctx context.Context, request DisableCourseRequest) error {
	err := c.db.DisbaleCourse(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to disable course in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to disable course entry in database")
	}

	return nil
}

func (c *courseController) batchCreateCourseHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		courses  []dbModel.Course
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}

		if len(row) < 11 || len(row) > 12 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		course, err := c.extractDataForCreateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		courses = append(courses, course)
		if len(courses) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchCreateCourses(ctx, courses); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			courses = []dbModel.Course{} //clear courses array
		}

	}

	if len(courses) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchCreateCourses(ctx, courses); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

func (c *courseController) batchUpdateCoursesHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		courses  []dbModel.Course
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}
		if len(row) != 10 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		course, err := c.extractDataForUpdateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		courses = append(courses, course)
		if len(courses) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchUpdateCourses(ctx, courses); err != nil {
				logger.Error(ctx, "batch updation failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch updation failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			courses = []dbModel.Course{} //clear categories array
		}

	}

	if len(courses) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchUpdateCourses(ctx, courses); err != nil {
			logger.Error(ctx, "final batch updation failed for batch", zap.Error(err))
			return fmt.Errorf("final batch updation failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

// TODO: Reorganize and club the validation for creation and updation flow together and have one single function for all use-cases.
func (c *courseController) extractDataForCreateFile(row []string) (dbModel.Course, error) {
	var (
		course dbModel.Course
	)

	switch {
	case len(row) == 11:
		// Code to handle a row of length 9

		//Validate diffculty level and format
		diffcultyLevel, err := validateCourseDiffcultyLevel(row[3])
		if err != nil {
			return course, fmt.Errorf("invalid value for course diffculty level, error: %v", err)
		}

		course.DifficultyLevel = &diffcultyLevel

		//validate format of the course
		courseFormat, err := validateCourseFormat(row[7])
		if err != nil {
			return course, fmt.Errorf("invalid value for course format, error: %v", err)
		}

		course.Format = &courseFormat

		//format start date
		// var formattedDate string
		if len(row[5]) != 0 {
			formattedStartDate, err := utils.FormatDate(row[5])
			if err != nil {
				return course, fmt.Errorf("invalid value for formatted start date, error: %v", err)
			}
			course.StartDate = &formattedStartDate
			fmt.Printf("Input: %s | Output: %s\n", row[5], formattedStartDate)
		}

		//format end date
		if len(row[6]) != 0 {
			_, err := parseCourseEndDate(row[6])
			if err != nil {
				return course, fmt.Errorf("invalid value for course end date, error: %v", err)
			}
			course.EndDate = &row[6]
		}

		//category_id formating
		categoryIdStr := strings.TrimSpace(row[2])
		if len(categoryIdStr) == 0 {
			return course, fmt.Errorf("category_id value is blank, error: %v", err)
		}
		categoryId, err := strconv.Atoi(categoryIdStr)
		if err != nil {
			return course, fmt.Errorf("invalid value for category_id column,error: %v", err)
		}
		course.CategoryID = utils.Int64ToPointer(int64(categoryId))

		//duration filed extraction
		durationStr := strings.TrimSpace(row[8])
		if len(durationStr) != 0 {
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				return course, fmt.Errorf("invalid value for duration column,error: %v", err)
			}
			course.Duration = utils.Int64ToPointer(int64(duration))
		}

		createdAtStr := strings.TrimSpace(row[9])
		if len(createdAtStr) != 0 {
			formattedCreatedAt, err := utils.FormatDateTime(row[9])
			if err != nil {
				return course, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			course.CreatedAt = formattedCreatedAt
			fmt.Printf("Input: %s | Output: %s\n", row[9], formattedCreatedAt)
		}

		moduleCountStr := strings.TrimSpace(row[10])
		if len(moduleCountStr) != 0 {
			moduleCount, err := strconv.Atoi(moduleCountStr)
			if err != nil {
				return course, fmt.Errorf("failed to convert into int: %v", err)
			}
			course.ModuleCount = utils.Int64ToPointer(int64(moduleCount))
		}

		//check for fullName
		fullName := strings.TrimSpace(row[0])
		if len(fullName) == 0 {
			return course, fmt.Errorf("fullname value is blank, error: %v", err)
		}
		course.Fullname = &fullName

		//check for shortName
		shortName := strings.TrimSpace(row[1])
		if len(shortName) == 0 {
			return course, fmt.Errorf("shortname value is blank, error: %v", err)
		}

		course.Shortname = &shortName

		//check for summary
		summary := strings.TrimSpace(row[4])
		// if len(summary) == 0 {
		// 	return course, fmt.Errorf("summary value is blank, error: %v", err)
		// }
		course.Summary = &summary

		course.Visible = utils.BoolToPointer(true)
		return course, nil

	case len(row) == 12:
		// Code to handle a row of length 10

		courseId, err := strconv.Atoi(row[0])
		if err != nil {
			return course, fmt.Errorf("failed to convert into integer: %v", err)
		}
		course.ID = utils.Int64ToPointer(int64(courseId))

		//Validate diffculty level and format
		diffcultyLevel, err := validateCourseDiffcultyLevel(row[4])
		if err != nil {
			return course, fmt.Errorf("invalid value for course diffculty level, error: %v", err)
		}

		course.DifficultyLevel = &diffcultyLevel

		//validate format of the course
		courseFormat, err := validateCourseFormat(row[8])
		if err != nil {
			return course, fmt.Errorf("invalid value for course format, error: %v", err)
		}

		course.Format = &courseFormat

		//format start date
		// var formattedDate string
		if len(row[6]) != 0 {
			formattedStartDate, err := utils.FormatDate(row[6])
			if err != nil {
				return course, fmt.Errorf("invalid value for formatted start date, error: %v", err)
			}
			course.StartDate = &formattedStartDate
			fmt.Printf("Input: %s | Output: %s\n", row[6], formattedStartDate)
		}

		//format end date
		if len(row[7]) != 0 {
			_, err := parseCourseEndDate(row[7])
			if err != nil {
				return course, fmt.Errorf("invalid value for course end date, error: %v", err)
			}
			course.EndDate = &row[7]
		}

		//category_id formating
		categoryIdStr := strings.TrimSpace(row[3])
		if len(categoryIdStr) == 0 {
			return course, fmt.Errorf("category_id value is blank, error: %v", err)
		}
		categoryId, err := strconv.Atoi(categoryIdStr)
		if err != nil {
			return course, fmt.Errorf("invalid value for category_id column,error: %v", err)
		}
		course.CategoryID = utils.Int64ToPointer(int64(categoryId))

		//duration filed extraction
		durationStr := strings.TrimSpace(row[9])
		if len(durationStr) != 0 {
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				return course, fmt.Errorf("invalid value for duration column,error: %v", err)
			}
			course.Duration = utils.Int64ToPointer(int64(duration))
		}

		createdAtStr := strings.TrimSpace(row[10])
		if len(createdAtStr) != 0 {
			formattedCreatedAt, err := utils.FormatDateTime(row[10])
			if err != nil {
				return course, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			course.CreatedAt = formattedCreatedAt
			fmt.Printf("Input: %s | Output: %s\n", row[10], formattedCreatedAt)
		}

		moduleCountStr := strings.TrimSpace(row[11])
		if len(moduleCountStr) != 0 {
			moduleCount, err := strconv.Atoi(moduleCountStr)
			if err != nil {
				return course, fmt.Errorf("failed to convert into int: %v", err)
			}
			course.ModuleCount = utils.Int64ToPointer(int64(moduleCount))
		}

		//check for fullName
		fullName := strings.TrimSpace(row[1])
		if len(fullName) == 0 {
			return course, fmt.Errorf("fullname value is blank, error: %v", err)
		}
		course.Fullname = &fullName

		//check for shortName
		shortName := strings.TrimSpace(row[2])
		if len(shortName) == 0 {
			return course, fmt.Errorf("shortname value is blank, error: %v", err)
		}

		course.Shortname = &shortName

		//check for summary
		summary := strings.TrimSpace(row[5])
		// if len(summary) == 0 {
		// 	return course, fmt.Errorf("summary value is blank, error: %v", err)
		// }
		course.Summary = &summary

		course.Visible = utils.BoolToPointer(true)
		return course, nil

	default:
		fmt.Printf("invalid number of row")
	}

	return course, nil

}

func (c *courseController) extractDataForUpdateFile(row []string) (dbModel.Course, error) {
	var (
		course dbModel.Course
		err    error
	)

	//category_id formating
	courseIdStr := strings.TrimSpace(row[0])
	if len(courseIdStr) == 0 {
		return course, fmt.Errorf("course_id value is blank, error: %v", err)
	}
	courseId, err := strconv.Atoi(courseIdStr)
	if err != nil {
		return course, fmt.Errorf("invalid value for course_id column,error: %v", err)
	}
	course.ID = utils.Int64ToPointer(int64(courseId))

	//Validate diffculty level and format
	tempDiffcultyLevel := strings.TrimSpace(row[4])
	if len(tempDiffcultyLevel) != 0 {
		diffcultyLevel, err := validateCourseDiffcultyLevel(tempDiffcultyLevel)
		if err != nil {
			return course, fmt.Errorf("invalid value for course diffculty level, error: %v", err)
		}

		course.DifficultyLevel = &diffcultyLevel
	}

	//validate format of the course
	tempCourseFormat := strings.TrimSpace(row[8])
	if len(tempCourseFormat) != 0 {
		courseFormat, err := validateCourseFormat(row[8])
		if err != nil {
			return course, fmt.Errorf("invalid value for course format, error: %v", err)
		}

		course.Format = &courseFormat
	}

	//format start date
	tempStartDate := strings.TrimSpace(row[6])
	if len(tempStartDate) != 0 {
		_, err := parseCourseStartDate(tempStartDate)
		if err != nil {
			return course, fmt.Errorf("invalid value for course start date, error: %v", err)
		}
		course.StartDate = &tempStartDate
	}

	//format end date
	tempEndDate := strings.TrimSpace(row[7])
	if len(tempEndDate) != 0 {
		_, err := parseCourseEndDate(tempEndDate)
		if err != nil {
			return course, fmt.Errorf("invalid value for course end date, error: %v", err)
		}
		course.EndDate = &tempEndDate
	}

	//category_id formating
	tempCategoryIdStr := strings.TrimSpace(row[3])
	if len(tempCategoryIdStr) == 0 {
		return course, fmt.Errorf("category_id value is blank, error: %v", err)
	}
	categoryId, err := strconv.Atoi(tempCategoryIdStr)
	if err != nil {
		return course, fmt.Errorf("invalid value for category_id column,error: %v", err)
	}
	course.CategoryID = utils.Int64ToPointer(int64(categoryId))

	//duration filed extraction
	tempDurationStr := strings.TrimSpace(row[9])
	if len(tempDurationStr) != 0 {
		duration, err := strconv.Atoi(tempDurationStr)
		if err != nil {
			return course, fmt.Errorf("invalid value for duration column,error: %v", err)
		}
		course.Duration = utils.Int64ToPointer(int64(duration))
	}

	//check for fullName
	tempFullName := strings.TrimSpace(row[1])
	if len(tempFullName) != 0 {
		course.Fullname = &tempFullName
	}

	//check for shortName
	tempShortName := strings.TrimSpace(row[2])
	if len(tempShortName) != 0 {
		course.Shortname = &tempShortName
	}

	//check for summary
	tempSummary := strings.TrimSpace(row[5])
	if len(tempSummary) != 0 {
		course.Summary = &tempSummary
	}

	return course, nil

}

/*
courseAssetUploadHelper ...
1. validate request body, i.e. assetFor parameter
2. validate input file
3. upload to s3
4. update database
5. return s3 path in response
*/
func (c *courseController) courseAssetUploadHelper(ctx context.Context, request AssetUploadRequest) (AssetUploadResponse, error) {
	var (
		response AssetUploadResponse
	)

	//intialize active storage service
	activeStorageService := activestorage.NewActiveStorageService(c.db)

	activeStorageInput := activestorage.ActiveStorageUploadInput{
		FileHeader:    request.AssetFile,
		ServiceName:   "S3",
		ModelType:     "course",
		ModelId:       int64(*request.CourseId),
		ContentType:   request.AssetFile.Header.Get("Content-Type"),
		AttachmentFor: *utils.StringToPointer("banner"),
	}
	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
	if err != nil {
		logger.Error(ctx, "error recived while processing in active storage service", zap.Error(err))
		return response, err
	}

	fileUrl := activeStorageService.GetURL(*tempFileName)

	//update database
	course := dbModel.Course{
		ID:     request.CourseId,
		Banner: &fileUrl,
	}

	if _, err := c.db.UpdateCourse(ctx, &course); err != nil {
		logger.Error(ctx, "unable to update file path in s3")
		return response, fmt.Errorf("unable to update file path in s3")
	}

	response.Path = fileUrl
	return response, nil
}

func validateCourseDiffcultyLevel(diffcultyLevel string) (constants.CourseDiffcultyEnum, error) {
	return constants.ParseCourseDiffcultyEnum(diffcultyLevel)
}

func validateCourseFormat(format string) (constants.CourseFormatEnum, error) {
	return constants.ParseCourseFormatEnum(format)
}

func parseCourseStartDate(startDate string) (time.Time, error) {
	return utils.ParseTime(startDate, "yyyy-mm-dd")
}

func parseCourseEndDate(endDate string) (time.Time, error) {
	return utils.ParseTime(endDate, "yyyy-mm-dd")
}

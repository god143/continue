package course

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type courseController struct {
	db db.DBLayer
}

type CourseControllerGroup interface {
	GetCoursesByCategory(ctx *gin.Context)
	GetCourseDetails(ctx *gin.Context)
	CreateCourse(ctx *gin.Context)
	UpdateCourse(ctx *gin.Context)
	DisableCourse(ctx *gin.Context)
	BatchCreateCourse(ctx *gin.Context)
	BulkUpdateCourses(ctx *gin.Context)
	CourseAssetUpload(ctx *gin.Context)
}

func NewCourseControllerGroup(db db.DBLayer) CourseControllerGroup {
	return &courseController{
		db: db,
	}
}

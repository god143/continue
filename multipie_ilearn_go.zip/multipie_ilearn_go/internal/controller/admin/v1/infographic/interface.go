package infographic

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type infographicController struct {
	db db.DBLayer
}

type InfographicControllerGroup interface {
	GetInfographics(ctx *gin.Context)
	GetInfographicByID(ctx *gin.Context)
	CreateInfographic(ctx *gin.Context)
	UpdateInfographic(ctx *gin.Context)
	DisableInfographic(ctx *gin.Context)
	BatchCreateInfographics(ctx *gin.Context)
	BatchUpdateInfographics(ctx *gin.Context)
}

func NewInfographicControllerGroup(db db.DBLayer) InfographicControllerGroup {
	return &infographicController{
		db: db,
	}
}

package infographic

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (i *infographicController) GetInfographics(ctx *gin.Context) {
	var (
		resp               *utils.Response
		request            GetInfographicsRequest
		getInfographisResp []InfographisResult
	)
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}
	getInfographisResp, err = i.getInfographicsHelper(ctx, &request, &uid)
	if err != nil {
		logger.Error(ctx, "unable to fetch infographics", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch infographics"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(getInfographisResp, nil))
}

func (c *infographicController) GetInfographicByID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetInfographicByIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid infographicId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	infographicResp, err := c.getInfographicByIDHelper(ctx, request, &uid)
	if err != nil {
		logger.Error(ctx, "unable to fetch infographic", zap.Int64("infographicId", request.ID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch infographic"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(infographicResp, nil))
}

func (c *infographicController) CreateInfographic(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateInfographicRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createInfographicResp, err := c.createInfographicHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createInfographicResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *infographicController) UpdateInfographic(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateInfographicRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.updateInfographicHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("infographic updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *infographicController) DisableInfographic(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DisableInfographicRequest
	)

	if err := ctx.BindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.disableInfographicHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("infographic disabled successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *infographicController) BatchCreateInfographics(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchCreateInfographicsHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of infographics is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *infographicController) BatchUpdateInfographics(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchUpdateInfographicsHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch updation of infographics is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

package infographic

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModelInfographic "multipie_ilearn_go/internal/db/infographic"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (i *infographicController) getInfographicsHelper(ctx context.Context, request *GetInfographicsRequest, userId *int64) ([]InfographisResult, error) {
	infographics, err := i.fetchInfographics(ctx, request.CategoryID, request.Page, request.PageSize, request.Filter, userId)
	if err != nil {
		return nil, err
	}

	infographicIDs, err := i.prepareInfographicIDs(infographics)
	if err != nil {
		return nil, err
	}

	images, err := i.fetchImagesFromDB(ctx, infographicIDs)
	if err != nil {
		return nil, err
	}

	imagesByInfographicID := mapImagesByInfographicID(images)

	return i.constructInfographicsResult(infographics, imagesByInfographicID), nil
}

func (i *infographicController) fetchInfographics(ctx context.Context, categoryID *int64, page int, pageSize int, filter string, userId *int64) ([]dbModelInfographic.Infographic, error) {
	var filterType constants.FilterTypeEnum
	var err error
	var infographicIds []int
	var infographicTypes []string
	var subtype []string

	if filter != "" {
		filterType, err = constants.ParseFilterTypeEnum(filter)
		if err != nil {
			logger.Error(ctx, "Invalid filter type", zap.String("filter", filter), zap.Error(err))
			return nil, fmt.Errorf("invalid filter type: %w", err)
		}
	} else {
		filterType = constants.FilterTypeEnum("")
	}

	infographics, err := i.db.GetInfographics(ctx, categoryID, utils.BoolToPointer(true), page, pageSize, filterType)
	if err != nil {
		logger.Error(ctx, "error fetching infographics from database", zap.Error(err))
		return nil, err
	}

	for _, infographic := range infographics {
		infographicIds = append(infographicIds, *infographic.ID)
		infographicTypes = append(infographicTypes, "infographic")
	}

	bookmarks, err := i.db.GetBookmarkByCustomParams(ctx, infographicIds, infographicTypes, subtype, *userId)
	if err != nil {
		return nil, err
	}

	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)

		}
	}

	responses := make([]dbModelInfographic.Infographic, 0, len(infographics))

	for _, m := range infographics {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}
		responses = append(responses, dbModelInfographic.Infographic{
			ID:          m.ID,
			Name:        m.Name,
			CategoryID:  m.CategoryID,
			Description: m.Description,
			Likes:       m.Likes,
			Views:       m.Views,
			Visible:     m.Visible,
			UploadTime:  m.UploadTime,
			IsBookmark:  isBookmark,
			BookmarkId:  bookmarkIdPtr,
			CreatedAt:   m.CreatedAt,
			UpdatedAt:   m.UpdatedAt,
		})
	}

	return responses, nil
}

func (i *infographicController) prepareInfographicIDs(infographics []dbModelInfographic.Infographic) ([]int64, error) {
	var infographicIDs []int64
	for _, infographic := range infographics {
		if infographic.ID == nil {
			return nil, fmt.Errorf("infographic ID is nil for an infographic")
		}
		infographicIDs = append(infographicIDs, int64(*infographic.ID))
	}
	return infographicIDs, nil
}

func (i *infographicController) fetchImagesFromDB(ctx context.Context, infographicIDs []int64) ([]dbModelInfographicImages.InfographicImage, error) {
	images, err := i.db.GetInfographicImagesByInfographics(ctx, infographicIDs)
	if err != nil {
		logger.Error(ctx, "error fetching infographic images from database", zap.Error(err))
		return nil, err
	}
	return images, nil
}

func mapImagesByInfographicID(images []dbModelInfographicImages.InfographicImage) map[int][]dbModelInfographicImages.InfographicImage {
	imagesByInfographicID := make(map[int][]dbModelInfographicImages.InfographicImage)
	for _, image := range images {
		imagesByInfographicID[*image.InfographicID] = append(imagesByInfographicID[*image.InfographicID], image)
	}
	return imagesByInfographicID
}

func (i *infographicController) constructInfographicsResult(infographics []dbModelInfographic.Infographic, imagesByInfographicID map[int][]dbModelInfographicImages.InfographicImage) []InfographisResult {
	var infographicsResult []InfographisResult
	for _, infographic := range infographics {
		result := InfographisResult{
			Infographic: infographic,
		}

		// Attach images to the result if they exist
		if images, ok := imagesByInfographicID[*infographic.ID]; ok {
			result.Images = images
		}

		infographicsResult = append(infographicsResult, result)
	}
	return infographicsResult
}

func (i *infographicController) getInfographicByIDHelper(ctx context.Context, request GetInfographicByIDRequest, userId *int64) (*InfographisResult, error) {

	var infographicIds []int
	var infographicTypes []string
	var bookmarkId *int64
	var subtype []string

	infographic, err := i.db.GetInfographicByID(ctx, request.ID, nil)
	if err != nil {
		logger.Error(ctx, "error fetching infographic from database", zap.Error(err), zap.Int64("ID", request.ID))
		return nil, err
	}

	infographicIds = append(infographicIds, *infographic.ID)
	infographicTypes = append(infographicTypes, "infographic")

	bookmark, err := i.db.GetBookmarkByCustomParams(ctx, infographicIds, infographicTypes, subtype, *userId)
	if err != nil {
		return &InfographisResult{}, err
	}
	for _, bm := range bookmark {
		bookmarkId = bm.ID
	}

	isBookmark := len(bookmark) != 0
	infographic.IsBookmark = &isBookmark
	infographic.BookmarkId = bookmarkId

	infographicIDs := []int64{int64(*infographic.ID)}
	//Fetch infographic images using the infographic IDs
	images, err := i.fetchImagesFromDB(ctx, infographicIDs)
	if err != nil {
		return nil, err
	}

	result := &InfographisResult{
		Infographic: infographic,
		Images:      images,
	}
	return result, nil
}

// TODO: Add funtionality to add images to infographic_table alongwith record creation in infographic table
func (i *infographicController) createInfographicHelper(ctx context.Context, request CreateInfographicRequest) (CreateInfographicResponse, error) {
	var resp CreateInfographicResponse

	infographic := &dbModelInfographic.Infographic{
		Name:        request.Name,
		Description: request.Description,
		CategoryID:  request.CategoryID,
		Likes:       utils.IntToPointer(0),     // Default to 0
		Views:       utils.IntToPointer(0),     // Default to 0
		Visible:     utils.BoolToPointer(true), // Default to true
		UploadTime:  utils.TimeToPointer(time.Now()),
	}

	infographic, err := i.db.CreateInfographic(ctx, infographic)
	if err != nil {
		logger.Error(ctx, "Unable to create infographic", zap.Error(err))
		return resp, errors.New("unable to create infographic")
	}

	resp = CreateInfographicResponse{
		ID: *infographic.ID,
	}

	return resp, nil
}

func (i *infographicController) updateInfographicHelper(ctx context.Context, request UpdateInfographicRequest) error {
	infographic := &dbModelInfographic.Infographic{
		ID:          request.ID,
		Name:        request.Name,
		CategoryID:  request.CategoryID,
		Description: request.Description,
		Visible:     request.Visible,
	}

	// Parse and update start and end dates
	if request.UploadTime != nil {
		uploadTime, err := parseUploadTime(*request.UploadTime)
		if err != nil {
			logger.Error(ctx, "invalid uploadTime format", zap.Error(err), zap.Any("input value", request.UploadTime))
			return fmt.Errorf("invalid uploadTime format, error: %v", err)
		}
		infographic.UploadTime = uploadTime
	}

	// Update infographic in the database
	_, err := i.db.UpdateInfographic(ctx, infographic)
	if err != nil {
		logger.Error(ctx, "unable to update infographic entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update infographic entry in database")
	}

	return nil
}

func (i *infographicController) disableInfographicHelper(ctx context.Context, request DisableInfographicRequest) error {
	err := i.db.DisbaleInfographic(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to disable infographic in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to disable infographic entry in database")
	}

	return nil
}

func (i *infographicController) batchCreateInfographicsHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount     int
		batchNo      int
		infographics []dbModelInfographic.Infographic
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 5 || len(row) > 6 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		infographic, err := i.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		infographics = append(infographics, infographic)
		if len(infographics) == 100 {
			batchNo++ // Increment batch number
			if err := i.db.BatchCreateInfographic(ctx, infographics); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			infographics = []dbModelInfographic.Infographic{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(infographics) > 0 {
		if err := i.db.BatchCreateInfographic(ctx, infographics); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (i *infographicController) batchUpdateInfographicsHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount     int
		batchNo      int
		infographics []dbModelInfographic.Infographic
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 5 || len(row) > 6 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		//extract ID
		id, err := strconv.Atoi(strings.TrimSpace(row[0]))
		if err != nil {
			return errors.New("invalid value for id column")
		}

		// Extract data from CSV row
		infographic, err := i.extractDataFromFile(row[1:])
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		infographic.ID = &id

		infographics = append(infographics, infographic)
		if len(infographics) == 100 {
			batchNo++ // Increment batch number
			if err := i.db.BatchUpdateInfographic(ctx, infographics); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			infographics = []dbModelInfographic.Infographic{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(infographics) > 0 {
		if err := i.db.BatchUpdateInfographic(ctx, infographics); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

// Helper function to parse dates
func parseUploadTime(dateStr string) (*time.Time, error) {
	parsedDate, err := utils.ParseTime(dateStr, "yyyy-mm-dd hh:mm:ss")
	fmt.Println(dateStr, parsedDate)
	if err != nil {
		return nil, fmt.Errorf("unable to parse date: %v", err)
	}
	return &parsedDate, nil
}

// Helper function to extract data from CSV
func (i *infographicController) extractDataFromFile(row []string) (dbModelInfographic.Infographic, error) {
	var infographic dbModelInfographic.Infographic
	switch {
	case len(row) == 5:
		//validate name
		name := strings.TrimSpace(row[0])
		if len(name) == 0 {
			return infographic, fmt.Errorf("value of name field cannot be blank")
		}
		infographic.Name = &name
		//validate category_id
		categoryIdStr := strings.TrimSpace(row[1])
		if len(categoryIdStr) == 0 {
			return infographic, fmt.Errorf("value for category_id field cannot be blank")
		}

		categoryId, err := strconv.Atoi(categoryIdStr)
		if err != nil {
			return infographic, fmt.Errorf("invalid value for category_id, error: %v", err)
		}

		infographic.CategoryID = &categoryId

		//description is not required parameter, so validation.
		description := strings.TrimSpace(row[2])
		infographic.Description = &description

		//validate upload time if provided
		uploadTimeStr := strings.TrimSpace(row[3])
		if len(uploadTimeStr) != 0 {
			uploadTime, err := parseUploadTime(uploadTimeStr)
			if err != nil {
				return infographic, fmt.Errorf("invalid uploadTime format, error: %v", err)
			}
			infographic.UploadTime = uploadTime
		} else {
			infographic.UploadTime = utils.TimeToPointer(time.Now())
		}

		visibleStr := strings.TrimSpace(row[4])
		if visibleStr != "" {
			visible := parseBoolOrFalse(visibleStr)
			infographic.Visible = &visible
			fmt.Println("visible value", *infographic.Visible)
		}

	case len(row) == 6:
		idStr := strings.TrimSpace(row[0])
		if len(idStr) == 0 {
			return infographic, fmt.Errorf("value of id field cannot be blank")
		}
		id, err := strconv.Atoi(idStr)
		if err != nil {
			return infographic, fmt.Errorf("failed to convert id into int: %w", err)
		}
		infographic.ID = &id

		//validate name
		name := strings.TrimSpace(row[1])
		if len(name) == 0 {
			return infographic, fmt.Errorf("value of name field cannot be blank")
		}
		infographic.Name = &name
		//validate category_id
		categoryIdStr := strings.TrimSpace(row[2])
		if len(categoryIdStr) == 0 {
			return infographic, fmt.Errorf("value for category_id field cannot be blank")
		}

		categoryId, err := strconv.Atoi(categoryIdStr)
		if err != nil {
			return infographic, fmt.Errorf("invalid value for category_id, error: %v", err)
		}

		infographic.CategoryID = &categoryId

		//description is not required parameter, so validation.
		description := strings.TrimSpace(row[3])
		infographic.Description = &description

		// validate upload time if provided
		uploadTimeStr := strings.TrimSpace(row[4])
		if len(uploadTimeStr) != 0 {
			formattedUploadTime, err := utils.FormatDateTime(row[4])
			if err != nil {
				return infographic, fmt.Errorf("invalid uploadTime format, error: %v", err)
			}
			infographic.UploadTime = formattedUploadTime
			fmt.Printf("Input: %s | Output: %s\n", row[4], formattedUploadTime)
		} else {
			infographic.UploadTime = utils.TimeToPointer(time.Now())
		}

		visibleStr := strings.TrimSpace(row[5])
		fmt.Println("visible string", visibleStr)
		if visibleStr != "" {
			visible := parseBoolOrFalse(visibleStr)
			infographic.Visible = &visible
			fmt.Println("visible value", *infographic.Visible)
		}

	}
	return infographic, nil
}

func parseBoolOrFalse(value string) bool {
	result, err := strconv.ParseBool(value)
	if err != nil {
		return false
	}
	return result
}

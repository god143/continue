package infographic

import (
	"mime/multipart"
	dbModelInfographic "multipie_ilearn_go/internal/db/infographic"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
)

type GetInfographicsRequest struct {
	CategoryID *int64 `form:"category_id"`
	Page       int    `form:"page" binding:"gte=0"`
	PageSize   int    `form:"page_size" binding:"lte=20"`
	Filter     string `json:"filter" form:"filter"`
}

type InfographisResult struct {
	dbModelInfographic.Infographic
	Images []dbModelInfographicImages.InfographicImage `json:"images"`
}

type GetInfographicByIDRequest struct {
	ID int64 `uri:"infographic_id" binding:"required"`
}

type CreateInfographicRequest struct {
	Name        *string `json:"name" binding:"required"`
	Description *string `json:"description"`
	CategoryID  *int    `json:"category_id" binding:"required"`
}

type CreateInfographicResponse struct {
	ID int `json:"id"`
}

type UpdateInfographicRequest struct {
	ID          *int    `json:"id" binding:"required"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
	CategoryID  *int    `json:"category_id"`
	Visible     *bool   `json:"visible"`
	UploadTime  *string `json:"upload_time" binding:"required"`
}

type DisableInfographicRequest struct {
	ID int64 `json:"infographic_id" binding:"required"`
}

type AssetUploadRequest struct {
	InfographicID *int64                `form:"infographic_id" binding:"required"`
	AssetFile     *multipart.FileHeader `form:"asset_file" binding:"required"` // For the uploaded file
}

type AssetUploadResponse struct {
	Path string `json:"path"`
}

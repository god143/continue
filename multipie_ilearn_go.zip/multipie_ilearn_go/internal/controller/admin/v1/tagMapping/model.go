package tagMapping

type CreateTagMappingRequest struct {
	TagID        *int64  `json:"tag_id" binding:"required"`
	ModelId      *int64  `json:"model_id" binding:"required"`
	ModelType    *string `json:"model_type" binding:"required"`
	ModelSubType *string `json:"model_sub_type" binding:"required"`
}

type UpdateTagMappingRequest struct {
	ID        *int64  `json:"id" binding:"required"`
	ModelId   *int64  `json:"model_id" binding:"required"`
	ModelType *string `json:"model_type" binding:"required"`
}

type DeleteTagMappingRequest struct {
	ID *int64 `json:"id" binding:"required"`
}

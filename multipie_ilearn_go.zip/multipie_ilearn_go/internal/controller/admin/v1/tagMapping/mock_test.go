package tagMapping

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/tagMapping"
	"multipie_ilearn_go/internal/logger"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// MockTagMappingRepo mocks the DB interface
type MockTagMappingRepo struct {
	mock.Mock
	db.DBLayer
}

func (m *MockTagMappingRepo) CreateTagMapping(ctx context.Context, tag *dbModel.TagMapping) error {
	args := m.Called(ctx, tag)
	return args.Error(0)
}

func (m *MockTagMappingRepo) UpdateTagMapping(ctx context.Context, tag *dbModel.TagMapping) error {
	args := m.Called(ctx, tag)
	return args.Error(0)
}

func (m *MockTagMappingRepo) DeleteTagMapping(ctx context.Context, tag *dbModel.TagMapping) error {
	args := m.Called(ctx, tag)
	return args.Error(0)
}

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

func TestTagMappingController(t *testing.T) {

	t.Run("NewTagMappingController_Coverage", func(t *testing.T) {
		mockRepo := new(MockTagMappingRepo)
		ctr := NewTagMappingController(mockRepo)
		assert.NotNil(t, ctr)
	})

	t.Run("CreateTagMapping_Success", func(t *testing.T) {
		mockRepo := new(MockTagMappingRepo)
		controller := &tagMappingController{db: mockRepo}

		tagID, modelID, modelType, subType := int64(1), int64(100), "course", "sub"
		reqBody := CreateTagMappingRequest{
			TagID:        &tagID,
			ModelId:      &modelID,
			ModelType:    &modelType,
			ModelSubType: &subType,
		}

		mockRepo.On("CreateTagMapping", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		jsonBytes, _ := json.Marshal(reqBody)
		c.Request, _ = http.NewRequest("POST", "/create", bytes.NewBuffer(jsonBytes))

		controller.CreateTagMapping(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Tag Mapping created succesfuly")
	})

	t.Run("CreateTagMapping_InvalidRequest", func(t *testing.T) {
		controller := &tagMappingController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Missing required fields
		c.Request, _ = http.NewRequest("POST", "/create", bytes.NewBuffer([]byte("{}")))

		controller.CreateTagMapping(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("CreateTagMapping_HelperError", func(t *testing.T) {
		mockRepo := new(MockTagMappingRepo)
		controller := &tagMappingController{db: mockRepo}

		tagID, modelID, modelType, subType := int64(1), int64(100), "course", "sub"
		reqBody := CreateTagMappingRequest{
			TagID: &tagID, ModelId: &modelID, ModelType: &modelType, ModelSubType: &subType,
		}

		mockRepo.On("CreateTagMapping", mock.Anything, mock.Anything).Return(errors.New("db error"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		jsonBytes, _ := json.Marshal(reqBody)
		c.Request, _ = http.NewRequest("POST", "/create", bytes.NewBuffer(jsonBytes))

		controller.CreateTagMapping(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("UpdateTagMapping_Success", func(t *testing.T) {
		mockRepo := new(MockTagMappingRepo)
		controller := &tagMappingController{db: mockRepo}

		id, modelID, modelType := int64(1), int64(200), "module"
		reqBody := UpdateTagMappingRequest{ID: &id, ModelId: &modelID, ModelType: &modelType}

		mockRepo.On("UpdateTagMapping", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		jsonBytes, _ := json.Marshal(reqBody)
		c.Request, _ = http.NewRequest("PUT", "/update", bytes.NewBuffer(jsonBytes))

		controller.UpdateTagMapping(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("UpdateTagMapping_InvalidRequest", func(t *testing.T) {
		controller := &tagMappingController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("PUT", "/update", bytes.NewBuffer([]byte(`{"id": "wrong_type"}`)))

		controller.UpdateTagMapping(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("DeleteTagMapping_Success", func(t *testing.T) {
		mockRepo := new(MockTagMappingRepo)
		controller := &tagMappingController{db: mockRepo}

		id := int64(5)
		reqBody := DeleteTagMappingRequest{ID: &id}

		mockRepo.On("DeleteTagMapping", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		jsonBytes, _ := json.Marshal(reqBody)
		c.Request, _ = http.NewRequest("DELETE", "/delete", bytes.NewBuffer(jsonBytes))

		controller.DeleteTagMapping(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Tag mapping deleted successfully")
	})

	t.Run("DeleteTagMapping_InvalidRequest", func(t *testing.T) {
		controller := &tagMappingController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("DELETE", "/delete", bytes.NewBuffer([]byte("{}")))

		controller.DeleteTagMapping(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("DeleteTagMapping_DBError", func(t *testing.T) {
		mockRepo := new(MockTagMappingRepo)
		controller := &tagMappingController{db: mockRepo}
		id := int64(5)
		reqBody := DeleteTagMappingRequest{ID: &id}

		mockRepo.On("DeleteTagMapping", mock.Anything, mock.Anything).Return(errors.New("db error"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		jsonBytes, _ := json.Marshal(reqBody)
		c.Request, _ = http.NewRequest("DELETE", "/delete", bytes.NewBuffer(jsonBytes))

		controller.DeleteTagMapping(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

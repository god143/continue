package tagMapping

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/tagMapping"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

/*
createTagHelper.....create tag mapping to specific key through tags_id foreign key to tags table
*/
func (t *tagMappingController) createTagMappingHelper(ctx context.Context, request CreateTagMappingRequest) error {

	tagMapping := &dbModel.TagMapping{
		TagID:     request.TagID,
		ModelId:   request.ModelId,
		ModelType: request.ModelType,
	}

	err := t.db.CreateTagMapping(ctx, tagMapping)
	if err != nil {
		logger.Error(ctx, "unable to create tag entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to create tag entry in database")
	}
	return nil
}

/*
updateTagHelper ....update tag mapping of particular id in database
*/
func (c *tagMappingController) updateTagMappingHelper(ctx context.Context, request UpdateTagMappingRequest) error {

	tagMapping := dbModel.TagMapping{
		ID:        request.ID,
		ModelId:   request.ModelId,
		ModelType: request.ModelType,
	}

	err := c.db.UpdateTagMapping(ctx, &tagMapping)
	if err != nil {
		logger.Error(ctx, "unable to update tag entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update tag entry in database")
	}
	return nil
}

/*
deleteTagMappingHelper ....delete  tag mapping of particular id in database
*/
func (c *tagMappingController) deleteTagHelper(ctx context.Context, request DeleteTagMappingRequest) error {

	tagmapping := dbModel.TagMapping{
		ID: request.ID,
	}

	err := c.db.DeleteTagMapping(ctx, &tagmapping)
	if err != nil {
		logger.Error(ctx, "unable to delete tag entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete tag entry in database")
	}
	return nil
}

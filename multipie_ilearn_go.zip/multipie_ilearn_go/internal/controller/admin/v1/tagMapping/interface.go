package tagMapping

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type tagMappingController struct {
	db db.DBLayer
}

type TagMappingControllerGroup interface {
	CreateTagMapping(ctx *gin.Context)
	UpdateTagMapping(ctx *gin.Context)
	DeleteTagMapping(ctx *gin.Context)
}

func NewTagMappingController(db db.DBLayer) TagMappingControllerGroup {
	return &tagMappingController{
		db: db,
	}
}

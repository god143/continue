package v1

import (
	activestorage "multipie_ilearn_go/internal/controller/admin/v1/active_storage"
	activitytracking "multipie_ilearn_go/internal/controller/admin/v1/activityTracking"
	bookmark "multipie_ilearn_go/internal/controller/admin/v1/bookmarks"
	"multipie_ilearn_go/internal/controller/admin/v1/category"
	"multipie_ilearn_go/internal/controller/admin/v1/certificate"
	"multipie_ilearn_go/internal/controller/admin/v1/comments"
	"multipie_ilearn_go/internal/controller/admin/v1/course"
	"multipie_ilearn_go/internal/controller/admin/v1/courseModules"
	"multipie_ilearn_go/internal/controller/admin/v1/enrollment"
	"multipie_ilearn_go/internal/controller/admin/v1/glossary"
	"multipie_ilearn_go/internal/controller/admin/v1/infographic"
	"multipie_ilearn_go/internal/controller/admin/v1/infographicImages"
	"multipie_ilearn_go/internal/controller/admin/v1/likes"
	"multipie_ilearn_go/internal/controller/admin/v1/questions"
	"multipie_ilearn_go/internal/controller/admin/v1/quiz"
	"multipie_ilearn_go/internal/controller/admin/v1/quizAttempts"
	"multipie_ilearn_go/internal/controller/admin/v1/resource"
	"multipie_ilearn_go/internal/controller/admin/v1/tagMapping"
	"multipie_ilearn_go/internal/controller/admin/v1/tags"
	"multipie_ilearn_go/internal/controller/admin/v1/users"

	"multipie_ilearn_go/internal/db"
)

type v1 struct {
	category.CategoryControllerGroup
	course.CourseControllerGroup
	courseModules.CourseModuleControllerGroup
	infographic.InfographicControllerGroup
	infographicImages.InfographicImagesControllerGroup
	resource.ResourceControllerGroup
	quiz.QuizControllerGroup
	questions.QuestionsControllerGroup
	users.UsersControllerGroup
	comments.CommentControllerGroup
	glossary.GlossaryControllerGroup
	tags.TagsControllerGroup
	tagMapping.TagMappingControllerGroup
	certificate.CertificateControllerGroup
	quizAttempts.QuizAttemptsControllerGroup
	enrollment.EnrollmentControllerGroup
	likes.LikesControllerGroup
	bookmark.BookmarkControllerGroup
	activitytracking.UserActivityControllerGroup
	activestorage.ActiveStorageControllerGroup
}

type V1ControllerLayer interface {
	category.CategoryControllerGroup
	course.CourseControllerGroup
	courseModules.CourseModuleControllerGroup
	infographic.InfographicControllerGroup
	infographicImages.InfographicImagesControllerGroup
	resource.ResourceControllerGroup
	quiz.QuizControllerGroup
	questions.QuestionsControllerGroup
	users.UsersControllerGroup
	comments.CommentControllerGroup
	glossary.GlossaryControllerGroup
	tags.TagsControllerGroup
	tagMapping.TagMappingControllerGroup
	certificate.CertificateControllerGroup
	quizAttempts.QuizAttemptsControllerGroup
	enrollment.EnrollmentControllerGroup
	likes.LikesControllerGroup
	bookmark.BookmarkControllerGroup
	activitytracking.UserActivityControllerGroup
	activestorage.ActiveStorageControllerGroup
}

func NewV1ControllerLayer(db db.DBLayer) V1ControllerLayer {
	return &v1{
		category.NewCategoryControllerGroup(db),
		course.NewCourseControllerGroup(db),
		courseModules.NewCourseModuleControllerGroup(db),
		infographic.NewInfographicControllerGroup(db),
		infographicImages.NewInfographicImageController(db),
		resource.NewResourceControllerGroup(db),
		quiz.NewQuizController(db),
		questions.NewQuestionsController(db),
		users.NewUsersControllerGroup(db),
		comments.NewCommentControllerGroup(db),
		glossary.NewGlossaryControllerGroup(db),
		tags.NewTagsControllerGroup(db),
		tagMapping.NewTagMappingController(db),
		certificate.NewCertificateControllerGroup(db),
		quizAttempts.NewQuizController(db),
		enrollment.NewEnrollmentController(db),
		likes.NewLikesControllerGroup(db),
		bookmark.NewBookmarkControllerGroup(db),
		activitytracking.NewUserActivityController(db),
		activestorage.NewActiveStorageControllerGroup(db),
	}
}

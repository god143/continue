package infographicImages

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type infographicImagesController struct {
	db db.DBLayer
}

type InfographicImagesControllerGroup interface {
	CreateInfographicImage(ctx *gin.Context)
	UpdateInfographicImage(ctx *gin.Context)
	DeleteInfographicImage(ctx *gin.Context)
}

func NewInfographicImageController(db db.DBLayer) InfographicImagesControllerGroup {
	return &infographicImagesController{
		db: db,
	}
}

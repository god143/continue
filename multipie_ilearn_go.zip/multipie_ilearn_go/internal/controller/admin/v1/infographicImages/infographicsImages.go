package infographicImages

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (i *infographicImagesController) CreateInfographicImage(ctx *gin.Context) {
	var (
		request              CreateInfographicImageRequest
		resp                 *utils.Response
		createImageResponses []CreateInfographicImageResponse
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	filenameSet := make(map[string]bool)
	for _, file := range request.AssetFile {
		if _, exists := filenameSet[file.Filename]; exists {
			resp = utils.NewV1Response(nil, utils.StringToPointer("duplicate filename are not allowed"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}
		filenameSet[file.Filename] = true
	}
	for _, file := range request.AssetFile {
		createImageResp, err := i.createInfographicImageHelper(ctx, request, file)
		if err != nil {
			logger.Error(ctx, "Error processing file", zap.Error(err))
			createImageResp.Path = "invalid entry"
			ctx.JSON(http.StatusInternalServerError, createImageResp)
			return
		}
		createImageResponses = append(createImageResponses, createImageResp)
	}
	resp = utils.NewV1Response(createImageResponses, nil)

	ctx.JSON(http.StatusOK, resp)
}
func (i *infographicImagesController) UpdateInfographicImage(ctx *gin.Context) {
	var (
		request UpdateInfographicImageRequest
		resp    *utils.Response
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	filenameSet := make(map[string]bool)
	for _, file := range request.AssetFile {
		if _, exists := filenameSet[file.Filename]; exists {
			resp = utils.NewV1Response(nil, utils.StringToPointer("duplicate filename are not allowed"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}
		filenameSet[file.Filename] = true
	}

	for _, file := range request.AssetFile {
		err := i.updateInfographicImageHelper(ctx, request, file)
		if err != nil {
			logger.Error(ctx, "Error processing file", zap.Error(err))
			continue
		}

	}
	resp = utils.NewV1Response("infographic image details updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (i *infographicImagesController) DeleteInfographicImage(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DeleteInfographicImageRequest
	)

	if err := ctx.BindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := i.deleteInfographicImageHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("infographic image deleted successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

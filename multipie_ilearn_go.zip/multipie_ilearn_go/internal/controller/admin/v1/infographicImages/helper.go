package infographicImages

import (
	"context"
	"errors"
	"fmt"
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/infographicImages"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (i *infographicImagesController) createInfographicImageHelper(ctx context.Context, request CreateInfographicImageRequest, file *multipart.FileHeader) (CreateInfographicImageResponse, error) {
	var response CreateInfographicImageResponse

	infographicImage := &dbModel.InfographicImage{
		InfographicID: request.InfographicId,
		ImageOrder:    request.ImageOrder,
	}
	infographicImage, err := i.db.CreateInfographicImage(ctx, infographicImage)
	if err != nil {
		logger.Error(ctx, "unable to create infographic image entry in DB", zap.Error(err))
		return response, fmt.Errorf("unable to create infographic image entry in DB, error: %v", err)
	}
	//intialize active storage service
	activeStorageService := activestorage.NewActiveStorageService(i.db)

	activeStorageInput := activestorage.ActiveStorageUploadInput{
		FileHeader:    file,
		ServiceName:   "S3",
		ModelType:     "infographic_image",
		ModelId:       int64(*infographicImage.ID),
		ContentType:   file.Header.Get("Content-Type"),
		AttachmentFor: *utils.StringToPointer("image"),
	}
	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
	if err != nil {
		logger.Error(ctx, "error recived while processing in active storage service", zap.Error(err))
		return response, err
	}

	fileUrl := activeStorageService.GetURL(*tempFileName)
	infographicImage.ImageURL = &fileUrl

	if _, err := i.db.UpdateInfographicImage(ctx, infographicImage); err != nil {
		logger.Error(ctx, "unable to update infographicImage details")
		return response, err
	}

	response.Path = fileUrl
	return response, nil
}

func (i *infographicImagesController) updateInfographicImageHelper(ctx context.Context, request UpdateInfographicImageRequest, file *multipart.FileHeader) error {
	infographicImage := dbModel.InfographicImage{
		ID:            request.ImageId,
		ImageOrder:    *request.ImageOrder,
		InfographicID: request.InfographicId,
	}

	if request.AssetFile != nil {
		//intialize active storage service
		activeStorageService := activestorage.NewActiveStorageService(i.db)

		activeStorageInput := activestorage.ActiveStorageUploadInput{
			FileHeader:    file,
			ServiceName:   "S3",
			ModelType:     "infographic_image",
			ModelId:       int64(*request.ImageId),
			ContentType:   file.Header.Get("Content-Type"),
			AttachmentFor: *utils.StringToPointer("image"),
		}
		tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
		if err != nil {
			logger.Error(ctx, "error recived while processing in active storage service", zap.Error(err))
			return err
		}

		fileUrl := activeStorageService.GetURL(*tempFileName)
		infographicImage.ImageURL = &fileUrl
	}

	if _, err := i.db.UpdateInfographicImage(ctx, &infographicImage); err != nil {
		logger.Error(ctx, "unable to update infographicImage details")
		return fmt.Errorf("unable to update infographicImage details, error: %v", err)
	}

	return nil
}

func (i *infographicImagesController) deleteInfographicImageHelper(ctx context.Context, request DeleteInfographicImageRequest) error {
	err := i.db.DeleteInfographicImage(ctx, *request.ID)
	if err != nil {
		logger.Error(ctx, "unable to delete infographic_image entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete infographic_image entry in database")
	}

	return nil
}

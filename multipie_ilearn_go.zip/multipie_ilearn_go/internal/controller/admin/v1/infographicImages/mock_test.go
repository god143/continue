package infographicImages

// import (
// 	"bytes"
// 	"context"
// 	"encoding/json"
// 	"io"
// 	"mime/multipart"
// 	"net/http"
// 	"net/http/httptest"
// 	"net/textproto" // Required for custom multipart headers
// 	"os"
// 	"testing"

// 	"multipie_ilearn_go/internal/db"
// 	dbModel "multipie_ilearn_go/internal/db/infographicImages"
// 	"multipie_ilearn_go/internal/logger"

// 	"github.com/gin-gonic/gin"
// 	"github.com/stretchr/testify/assert"
// 	"github.com/stretchr/testify/mock"
// )
// // --- MOCK DEFINITION ---
// type MockInfographicDB struct {
// 	mock.Mock
// 	db.DBLayer
// }

// func TestMain(m *testing.M) {
// 	// Initialize logger once for the package to prevent nil pointer panics in helper.go
// 	_ = logger.NewLogger("test", "error", "")
// 	gin.SetMode(gin.TestMode)
// 	os.Exit(m.Run())
// }
// func (m *MockInfographicDB) CreateInfographicImage(ctx context.Context, img *dbModel.InfographicImage) (*dbModel.InfographicImage, error) {
// 	args := m.Called(ctx, img)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.InfographicImage), args.Error(1)
// }
// func (m *MockInfographicDB) UpdateInfographicImage(ctx context.Context, img *dbModel.InfographicImage) (*dbModel.InfographicImage, error) {
// 	args := m.Called(ctx, img)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.InfographicImage), args.Error(1)
// }
// func (m *MockInfographicDB) DeleteInfographicImage(ctx context.Context, id int64) error {
// 	return m.Called(ctx, id).Error(0)
// }
// // Satisfy ActiveStorage service internal calls
// func (m *MockInfographicDB) CreateAttachment(ctx context.Context, input interface{}) error {
// 	return nil
// }
// func (m *MockInfographicDB) CreateBlob(ctx context.Context, input interface{}) error { return nil }

// // --- HELPERS ---
// func ptrInt(i int) *int       { return &i }
// func ptrInt64(i int64) *int64 { return &i }

// // Fixed Multipart Generator with correct imports and types
// func createMultipartRequest(files []string, params map[string]string) (*bytes.Buffer, string) {
// 	body := &bytes.Buffer{}
// 	writer := multipart.NewWriter(body)
// 	for key, val := range params {
// 		_ = writer.WriteField(key, val)
// 	}
// 	for _, filename := range files {
// 		h := make(textproto.MIMEHeader)
// 		h.Set("Content-Disposition", `form-data; name="asset_file"; filename="`+filename+`"`)
// 		h.Set("Content-Type", "image/png")
// 		part, _ := writer.CreatePart(h)
// 		_, _ = io.Copy(part, bytes.NewReader([]byte("fake-image-data")))
// 	}
// 	_ = writer.Close()
// 	return body, writer.FormDataContentType()
// }
// // --- UNIT TESTS ---
// func TestCreateInfographicImage(t *testing.T) {
// 	gin.SetMode(gin.TestMode)

// 	tests := []struct {
// 		name           string
// 		files          []string // Now correctly using []string
// 		params         map[string]string
// 		setupMock      func(*MockInfographicDB)
// 		expectedStatus int
// 	}{
// 		{
// 			name:           "Failure - Duplicate Filenames",
// 			files:          []string{"1.png", "1.png"},
// 			params:         map[string]string{"infographic_id": "10"},
// 			setupMock:      func(m *MockInfographicDB) {},
// 			expectedStatus: http.StatusBadRequest,
// 		},
// 	}
// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			mDB := new(MockInfographicDB)
// 			ctrl := &infographicImagesController{db: mDB}
// 			w := httptest.NewRecorder()
// 			c, _ := gin.CreateTestContext(w)

// 			body, contentType := createMultipartRequest(tt.files, tt.params)
// 			c.Request, _ = http.NewRequest("POST", "/create", body)
// 			c.Request.Header.Set("Content-Type", contentType)

// 			tt.setupMock(mDB)
// 			ctrl.CreateInfographicImage(c)
// 			assert.Equal(t, tt.expectedStatus, w.Code)
// 		})
// 	}
// }

// func TestDeleteInfographicImage(t *testing.T) {
// 	gin.SetMode(gin.TestMode)
// 	mDB := new(MockInfographicDB)
// 	ctrl := &infographicImagesController{db: mDB}

// 	t.Run("Delete Success", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)
// 		req := DeleteInfographicImageRequest{ID: ptrInt64(100)}
// 		b, _ := json.Marshal(req)
// 		c.Request, _ = http.NewRequest("DELETE", "/", bytes.NewBuffer(b))

// 		mDB.On("DeleteInfographicImage", mock.Anything, int64(100)).Return(nil)
// 		ctrl.DeleteInfographicImage(c)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})
// }

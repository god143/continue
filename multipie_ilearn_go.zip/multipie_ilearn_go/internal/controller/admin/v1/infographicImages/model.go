package infographicImages

import "mime/multipart"

type CreateInfographicImageRequest struct {
	ImageOrder    int                     `form:"image_order"`
	InfographicId *int                    `form:"infographic_id" binding:"required"`
	AssetFile     []*multipart.FileHeader `form:"asset_file" binding:"required"` // For the uploaded file
}

type CreateInfographicImageResponse struct {
	Path string `json:"path"`
}

type UpdateInfographicImageRequest struct {
	ImageId       *int                    `form:"image_id" binding:"required"`
	InfographicId *int                    `form:"infographic_id"`
	ImageOrder    *int                    `form:"image_order"`
	AssetFile     []*multipart.FileHeader `form:"asset_file"` // For the uploaded file
}

type DeleteInfographicImageRequest struct {
	ID *int64 `json:"image_id" binding:"required"`
}

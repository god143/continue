package category

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type categoryController struct {
	db db.DBLayer
}

type CategoryControllerGroup interface {
	GetCategories(ctx *gin.Context)
	GetCategoryByID(ctx *gin.Context)
	CreateCategory(ctx *gin.Context)
	UpdateCategory(ctx *gin.Context)
	DisableCategory(ctx *gin.Context)
	BatchCreateCategory(ctx *gin.Context)
	BulkUpdateCategory(ctx *gin.Context)
	AssetUpload(ctx *gin.Context)
}

func NewCategoryControllerGroup(db db.DBLayer) CategoryControllerGroup {
	return &categoryController{
		db: db,
	}
}

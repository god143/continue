package category

import (
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/category"
	"time"
)

type CategoriesResult struct {
	ID          *int       `json:"id"`
	Name        *string    `json:"name"`
	Icon        *string    `json:"icon"`
	Banner      *string    `json:"banner"`
	Description *string    `json:"description"`
	Visible     *bool      `json:"visible"`
	CreatedAt   *time.Time `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`

	SubCategory []dbModel.Category `json:"subCategory"`
}

type GetCategoryByIDRequest struct {
	ID int `uri:"category_id" binding:"required"`
}

type CreateCategoryRequest struct {
	Name           *string               `json:"name" binding:"required"`
	Icon           *multipart.FileHeader `json:"icon"`
	Banner         *multipart.FileHeader `json:"banner"`
	Description    *string               `json:"description" binding:"required"`
	Parent         *int                  `json:"parent"`
	Type           *string               `json:"type"`
	Category_order *int                  `json:"category_order" binding:"required"`
}

type CreateCategoryResponse struct {
	ID int64 `json:"id"`
}

type UpdateCategoryRequest struct {
	ID             *int    `json:"id" binding:"required"`
	Name           *string `json:"name"`
	Icon           *string `json:"icon"`
	Banner         *string `json:"banner"`
	Description    *string `json:"description"`
	Parent         *int    `json:"parent"`
	Type           *string `json:"type"`
	Category_order *int    `json:"category_order"`
}

type UpdateCategoryResponse struct {
	ID int64 `json:"id"`
}

type DisableCategoryRequest struct {
	ID int `json:"category_id" binding:"required"`
}

type AssetUploadRequest struct {
	CategoryId *int                  `form:"category_id" binding:"required"`
	AssetFor   *string               `form:"asset_for" binding:"required"`
	AssetFile  *multipart.FileHeader `form:"asset_file" binding:"required"` // For the uploaded file
}

type AssetUploadResponse struct {
	Path string `json:"path"`
}

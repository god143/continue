package category

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/category"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (c *categoryController) getCategoriesHelper(ctx context.Context) ([]CategoriesResult, error) {
	var (
		categoriesResult []CategoriesResult
		parentCategories []dbModel.Category
	)

	parentCategories, err := c.db.GetParentCategories(ctx, nil)
	if err != nil {
		logger.Error(ctx, "unable to fetch parent categories from db", zap.Error(err))
		return categoriesResult, errors.New("unable to fetch parent categories from db")
	}

	for _, item := range parentCategories {
		childCategories, err := c.db.GetSubCategoriesByParent(ctx, *item.ID, nil)
		if err != nil {
			logger.Error(ctx, "unable to fetch child categories from db", zap.Error(err), zap.Any("parentId", item.ID))
			return categoriesResult, errors.New("unable to fetch parent categories from db")
		}

		temp := CategoriesResult{
			ID:          item.ID,
			Name:        item.Name,
			Icon:        item.Icon,
			Banner:      item.Banner,
			Description: item.Description,
			Visible:     item.Visible,
			CreatedAt:   item.CreatedAt,
			UpdatedAt:   item.UpdatedAt,
			SubCategory: childCategories,
		}

		categoriesResult = append(categoriesResult, temp)

	}

	return categoriesResult, nil
}

func (c *categoryController) getCategoryByIDHelper(ctx context.Context, request GetCategoryByIDRequest) (CategoriesResult, error) {
	var (
		categoryResult CategoriesResult
	)

	parentCategory, err := c.db.GetCategoryByID(ctx, request.ID, nil)
	if err != nil {
		logger.Error(ctx, "unable to fetch category from db", zap.Error(err))
		return categoryResult, errors.New("unable to fetch category from db")
	}

	childCategories, err := c.db.GetSubCategoriesByParent(ctx, *parentCategory.ID, nil)
	if err != nil {
		logger.Error(ctx, "unable to fetch child categories from db", zap.Error(err), zap.Any("parentId", parentCategory.ID))
		return categoryResult, errors.New("unable to fetch parent categories from db")
	}

	categoryResult = CategoriesResult{
		ID:          parentCategory.ID,
		Name:        parentCategory.Name,
		Icon:        parentCategory.Icon,
		Banner:      parentCategory.Banner,
		Description: parentCategory.Description,
		Visible:     parentCategory.Visible,
		CreatedAt:   parentCategory.CreatedAt,
		UpdatedAt:   parentCategory.UpdatedAt,
		SubCategory: childCategories,
	}

	return categoryResult, nil
}

/*
createCategoryHelper... create category in database
1. Parse type
2. Add entry in database
*/
func (c *categoryController) createCategoryHelper(ctx context.Context, request CreateCategoryRequest) (*dbModel.Category, error) {

	category := &dbModel.Category{
		Name:           request.Name,
		Description:    request.Description,
		Parent:         request.Parent,
		Visible:        utils.BoolToPointer(true),
		Category_order: request.Category_order,
	}

	if request.Type != nil {
		temp, err := constants.ParseCategoryTypeEnum(*request.Type)
		if err != nil {
			logger.Error(ctx, "invalid value for category type", zap.Error(err))
			return nil, errors.New("invalid value for category type")
		}
		category.Type = &temp
	}

	category, err := c.db.CreateCategory(ctx, category)
	if err != nil {
		logger.Error(ctx, "unable to create category entry in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to create category entry in database")
	}

	return category, nil
}

/*
updateCategoryHelper... update category in database
1. Parse type
2. Update entry in database
*/
func (c *categoryController) updateCategoryHelper(ctx context.Context, request UpdateCategoryRequest) error {

	category := dbModel.Category{
		ID:             request.ID,
		Name:           request.Name,
		Description:    request.Description,
		Icon:           request.Icon,
		Banner:         request.Banner,
		Parent:         request.Parent,
		Category_order: request.Category_order,
	}

	if request.Type != nil {
		temp, err := constants.ParseCategoryTypeEnum(*request.Type)
		if err != nil {
			logger.Error(ctx, "invalid value for category type", zap.Error(err))
			return errors.New("invalid value for category type")
		}
		category.Type = &temp
	}

	_, err := c.db.UpdateCategory(ctx, category)
	if err != nil {
		logger.Error(ctx, "unable to update category entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update category entry in database")
	}

	return nil
}

/*
disableCategoryHelper... disable(i.e. make visible=false) category in database
*/
func (c *categoryController) disableCategoryHelper(ctx context.Context, request DisableCategoryRequest) error {

	err := c.db.DisbaleCategory(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to disable category in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to disable category entry in database")
	}

	return nil
}

/*
batchCreateCategoryHelper... read the file and create category in database. Perform batch creation, if any record in batch fails, rollback entire batch
*/
func (c *categoryController) batchCreateCategoryHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount   int
		batchNo    int
		categories []dbModel.Category
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}
		if len(row) < 6 || len(row) > 7 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		category, categoryTypeStr, err := c.extractDataForCreateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		//validate file record
		if err := c.validateFileRecord(category, categoryTypeStr); err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		categories = append(categories, category)
		if len(categories) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchCreateCategories(ctx, categories); err != nil {
				logger.Error(ctx, "batch insertion failed for batch", zap.Error(err))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			categories = []dbModel.Category{} //clear categories array
		}

	}

	if len(categories) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchCreateCategories(ctx, categories); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

/*
batchUpdateCategoryHelper... read the file and update category in database. Perform batch updation, if any record in batch fails, rollback entire batch
*/
func (c *categoryController) batchUpdateCategoryHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount   int
		batchNo    int
		categories []dbModel.Category
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, "unable to read csv record", zap.Error(err))
			return errors.New("unable to read csv record")
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue
		}

		if len(row) != 7 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		category, categoryTypeStr, err := c.extractDataForUpdateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		//validate file record
		if err := c.validateFileRecord(category, categoryTypeStr); err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		categories = append(categories, category)
		if len(categories) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchUpdateCategories(ctx, categories); err != nil {
				logger.Error(ctx, "batch updation failed for batch", zap.Error(err))
				return fmt.Errorf("batch updation failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			categories = []dbModel.Category{} //clear categories array
		}

	}

	if len(categories) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchUpdateCategories(ctx, categories); err != nil {
			logger.Error(ctx, "batch updation failed for batch", zap.Error(err))
			return fmt.Errorf("batch updation failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

// TODO: Below condition for parent check is wrong.
func (c *categoryController) validateFileRecord(category dbModel.Category, categoryType string) error {
	//validate row
	if category.Parent == nil { //its a parent category, then icon, banner and description is required
		if category.Description == nil {
			return errors.New("invalid value for description column, for parent category these are required value")
		}
		if categoryType != "" {
			return errors.New("invalid value for type column, for parent category type should be null")
		}
	}

	return nil
}

func (c *categoryController) extractDataForCreateFile(row []string) (dbModel.Category, string, error) {

	var (
		category        dbModel.Category
		categoryTypeStr string
	)

	switch {
	case len(row) == 6:
		category := dbModel.Category{
			Name:        utils.StringToPointer(strings.TrimSpace(row[0])),
			Description: utils.StringToPointer(strings.TrimSpace(row[1])),
			Icon:        utils.StringToPointer(strings.TrimSpace(row[2])),
			Banner:      utils.StringToPointer(strings.TrimSpace(row[3])),
		}
		parentStr := strings.TrimSpace(row[4])
		if parentStr != "" {
			parent, err := strconv.Atoi(parentStr)
			if err != nil {
				return category, "", fmt.Errorf("invalid value for parent column,error: %v", err)
			}
			category.Parent = &parent
		}

		categoryTypeStr := strings.TrimSpace(row[5])
		if categoryTypeStr != "" {
			temp, err := constants.ParseCategoryTypeEnum(categoryTypeStr)
			if err != nil {
				return category, "", fmt.Errorf("invalid value for type column,error: %v", err)
			}
			category.Type = &temp
		}

		category.Visible = utils.BoolToPointer(true)
		return category, categoryTypeStr, nil

	case len(row) == 7:

		category := dbModel.Category{
			Name:        utils.StringToPointer(strings.TrimSpace(row[1])),
			Description: utils.StringToPointer(strings.TrimSpace(row[2])),
			Icon:        utils.StringToPointer(strings.TrimSpace(row[3])),
			Banner:      utils.StringToPointer(strings.TrimSpace(row[4])),
		}

		categoryId, err := strconv.Atoi(row[0])
		if err != nil {
			return category, " ", fmt.Errorf("failed to convert into integer: %v", err)
		}
		category.ID = utils.IntToPointer(int(categoryId))

		parentStr := strings.TrimSpace(row[5])
		if parentStr != "" {
			parent, err := strconv.Atoi(parentStr)
			if err != nil {
				return category, "", fmt.Errorf("invalid value for parent column,error: %v", err)
			}
			category.Parent = &parent
		}

		categoryTypeStr := strings.TrimSpace(row[6])
		if categoryTypeStr != "" {
			temp, err := constants.ParseCategoryTypeEnum(categoryTypeStr)
			if err != nil {
				return category, "", fmt.Errorf("invalid value for type column,error: %v", err)
			}
			category.Type = &temp
		}

		category.Visible = utils.BoolToPointer(true)
		return category, categoryTypeStr, nil

	default:
		fmt.Printf("invalid length of row")
	}
	return category, categoryTypeStr, nil

}

func (c *categoryController) extractDataForUpdateFile(row []string) (dbModel.Category, string, error) {
	var category dbModel.Category

	id, err := strconv.Atoi(strings.TrimSpace(row[0]))
	if err != nil {
		return category, "", errors.New("invalid value for id column")
	}

	category = dbModel.Category{
		ID:          &id,
		Name:        utils.StringToPointer(strings.TrimSpace(row[1])),
		Description: utils.StringToPointer(strings.TrimSpace(row[2])),
		Icon:        utils.StringToPointer(strings.TrimSpace(row[3])),
		Banner:      utils.StringToPointer(strings.TrimSpace(row[4])),
	}

	parentStr := strings.TrimSpace(row[5])
	if parentStr != "" {
		parent, err := strconv.Atoi(parentStr)
		if err != nil {
			return category, "", fmt.Errorf("invalid value for parent column,error: %v", err)
		}
		category.Parent = &parent
	}

	categoryTypeStr := strings.TrimSpace(row[6])
	if categoryTypeStr != "" {
		temp, err := constants.ParseCategoryTypeEnum(categoryTypeStr)
		if err != nil {
			return category, "", errors.New("invalid value for type column")
		}
		category.Type = &temp
	}

	return category, categoryTypeStr, nil
}

/*
assetUploadHelper ...
1. validate request body, i.e. assetFor parameter
2. validate input file
3. upload to s3
4. update database
5. return s3 path in response
*/
func (c *categoryController) assetUploadHelper(ctx context.Context, request AssetUploadRequest) (AssetUploadResponse, error) {
	var (
		response AssetUploadResponse
	)

	//validate request body
	if *request.AssetFor != "icon" && *request.AssetFor != "banner" {
		logger.Error(ctx, "invalid value for asset_for parameter")
		return response, fmt.Errorf("invalid value for asset_for parameter")
	}

	//intialize active storage service
	activeStorageService := activestorage.NewActiveStorageService(c.db)

	activeStorageInput := activestorage.ActiveStorageUploadInput{
		FileHeader:    request.AssetFile,
		ServiceName:   "S3",
		ModelType:     "category",
		ModelId:       int64(*request.CategoryId),
		ContentType:   request.AssetFile.Header.Get("Content-Type"),
		AttachmentFor: *request.AssetFor,
	}
	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
	if err != nil {
		logger.Error(ctx, "error recived while processing in active storage service", zap.Error(err))
		return response, err
	}

	fileUrl := activeStorageService.GetURL(*tempFileName)

	//update database
	category := dbModel.Category{
		ID: request.CategoryId,
	}
	if *request.AssetFor == "icon" {
		category.Icon = &fileUrl
	} else {
		category.Banner = &fileUrl
	}

	if _, err := c.db.UpdateCategory(ctx, category); err != nil {
		logger.Error(ctx, "unable to update file path in s3")
		return response, fmt.Errorf("unable to update file path in s3")
	}

	response.Path = fileUrl
	return response, nil
}

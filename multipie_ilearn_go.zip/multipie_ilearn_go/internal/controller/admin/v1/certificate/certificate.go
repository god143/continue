package certificate

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *certificateController) CreateCertificate(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateCertificateRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err), zap.Any("requestBody", request))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	certificate, err := c.createCertificateHelper(ctx, uid, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(certificate, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (q *certificateController) BatchCreateCertificate(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = q.batchCreateCertificateHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of certificate is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

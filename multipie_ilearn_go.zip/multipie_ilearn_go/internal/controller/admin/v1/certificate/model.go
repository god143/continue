package certificate

import (
	"mime/multipart"
)

type CreateCertificateRequest struct {
	ModelID   int64                 `form:"model_id" binding:"required"`
	ModelType string                `form:"model_type" binding:"required"`
	AssetFile *multipart.FileHeader `form:"asset_file" binding:"required"` // For the uploaded file
}

type CreateCertificateResponse struct {
	Path string `json:"path"`
}

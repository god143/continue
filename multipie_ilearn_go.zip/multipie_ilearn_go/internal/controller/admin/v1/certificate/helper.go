package certificate

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/certificate"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (c *certificateController) createCertificateHelper(ctx context.Context, userID int64, request CreateCertificateRequest) (CreateCertificateResponse, error) {

	var (
		response CreateCertificateResponse
	)

	//intialize active storage service
	activeStorageService := activestorage.NewActiveStorageService(c.db)

	activeStorageInput := activestorage.ActiveStorageUploadInput{
		FileHeader:    request.AssetFile,
		ServiceName:   "S3",
		ModelType:     request.ModelType,
		ModelId:       int64(request.ModelID),
		ContentType:   request.AssetFile.Header.Get("Content-Type"),
		AttachmentFor: "certificate",
	}

	if request.AssetFile.Header.Get("Content-Type") != constants.FILE_TYPE_EXTENSION_PDF {
		return response, errors.New("invalid file type : only application/pdf is allowed")
	}

	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
	if err != nil {
		logger.Error(ctx, "error received while processing in active storage service", zap.Error(err))
		return response, err
	}

	fileUrl := activeStorageService.GetURL(*tempFileName)

	certificate := dbModel.Certificate{
		UserID:    &userID,
		ModelID:   &request.ModelID,
		ModelType: &request.ModelType,
		URL:       &fileUrl,
	}

	if _, err := c.db.CreateCertificate(ctx, &certificate); err != nil {
		logger.Error(ctx, "Failed to store file URL in the database", zap.Error(err))
		return response, fmt.Errorf("database insert failed: %v", err)
	}

	response.Path = fileUrl
	return response, nil
}

func (q *certificateController) batchCreateCertificateHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount     int
		batchNo      int
		certificates []dbModel.Certificate
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 6 || len(row) > 7 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		certificate, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		// quiz.Visible = utils.BoolToPointer(true)

		certificates = append(certificates, certificate)
		if len(certificates) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateCertificate(ctx, certificates); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			certificates = []dbModel.Certificate{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(certificates) > 0 {
		if err := q.db.BatchCreateCertificate(ctx, certificates); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (c *certificateController) extractDataFromFile(row []string) (dbModel.Certificate, error) {
	var (
		certificate dbModel.Certificate
	)

	switch {
	case len(row) == 6:
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for  userId, error: %v", err)
			}
			certificate.UserID = utils.Int64ToPointer(int64(userId))
		}

		url := strings.TrimSpace(row[1])
		if len(url) != 0 {
			certificate.URL = &url

		} else {
			return certificate, fmt.Errorf("invalid value for url")
		}

		//validate model type
		modelType := strings.TrimSpace(row[2])
		if len(modelType) == 0 {
			return certificate, fmt.Errorf("value for model type cannot be blank")
		}
		certificate.ModelType = &modelType

		modelIdStr := strings.TrimSpace(row[3])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}
			certificate.ModelID = utils.Int64ToPointer(int64(modelId))
		}

		createdAtStr := strings.TrimSpace(row[4])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			certificate.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[5])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			certificate.UpdatedAt = &updatedAt
		}

		return certificate, nil

	case len(row) == 7:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return certificate, fmt.Errorf("failed to convert into integer: %v", err)
		}
		certificate.ID = utils.Int64ToPointer(int64(id))

		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for  userId, error: %v", err)
			}
			certificate.UserID = utils.Int64ToPointer(int64(userId))
		}

		url := strings.TrimSpace(row[2])
		if len(url) != 0 {
			certificate.URL = &url

		} else {
			return certificate, fmt.Errorf("invalid value for url")
		}

		//validate model type
		modelType := strings.TrimSpace(row[3])
		if len(modelType) == 0 {
			return certificate, fmt.Errorf("value for model type cannot be blank")
		}
		certificate.ModelType = &modelType

		modelIdStr := strings.TrimSpace(row[4])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}
			certificate.ModelID = utils.Int64ToPointer(int64(modelId))
		}

		createdAtStr := strings.TrimSpace(row[5])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			certificate.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[6])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return certificate, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			certificate.UpdatedAt = &updatedAt
		}

	default:
		fmt.Printf("invalid number of row")
	}

	return certificate, nil

}

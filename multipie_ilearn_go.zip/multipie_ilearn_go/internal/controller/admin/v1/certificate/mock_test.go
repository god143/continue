package certificate

import (
	"bytes"
	"context"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"net/textproto"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/certificate"
	"multipie_ilearn_go/internal/logger"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) CreateCertificate(ctx context.Context, cert *dbModel.Certificate) (*dbModel.Certificate, error) {
	args := m.Called(ctx, cert)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Certificate), args.Error(1)
}

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}
func TestCertificateController_90PercentPush(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mDB := new(MockDBLayer)
	ctrl := NewCertificateControllerGroup(mDB)

	// 1. Controller: Hits 401 Path (Missing User)
	t.Run("Auth_Missing_User", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// Body is valid, but no userId in context
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "course")
		h, _ := writer.CreateFormFile("asset_file", "t.pdf")
		h.Write([]byte("%PDF"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())
		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	// 2. Controller: Hits 401 Path (Wrong Type) -> 100% ExtractUserId Coverage
	t.Run("Auth_Invalid_User_Type", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", "string-id") // Wrong type triggers error

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "course")
		h, _ := writer.CreateFormFile("asset_file", "t.pdf")
		h.Write([]byte("%PDF"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())
		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	// 3. Helper: Hits Invalid File Type -> Hits Helper Lines 15-43
	// This branch returns BEFORE the S3 panic, making it safe for coverage.
	t.Run("Helper_Invalid_MIME_Type", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(123))

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "course")

		mh := make(textproto.MIMEHeader)
		mh.Set("Content-Disposition", `form-data; name="asset_file"; filename="test.png"`)
		mh.Set("Content-Type", "image/png") // Trigger validation return
		part, _ := writer.CreatePart(mh)
		part.Write([]byte("fake-image"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "only application/pdf is allowed")
	})

	// 4. Controller: Hits 400 Path (Binding Error)
	t.Run("Controller_Binding_Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(123))
		// Empty body with multipart header triggers binding error
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte{}))
		ctx.Request.Header.Set("Content-Type", "multipart/form-data; boundary=xxx")
		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

func TestCertificateController_FullCoverage(t *testing.T) {
	mDB := new(MockDBLayer)
	ctrl := NewCertificateControllerGroup(mDB)

	// 1. Helper: Invalid MIME Type
	// Hits helper.go logic and returns BEFORE the S3 panic.
	t.Run("Helper_Invalid_MIME_Type", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(123))

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "course")

		h := make(textproto.MIMEHeader)
		h.Set("Content-Disposition", `form-data; name="asset_file"; filename="test.png"`)
		h.Set("Content-Type", "image/png")
		part, _ := writer.CreatePart(h)
		part.Write([]byte("fake-data"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "only application/pdf is allowed")
	})

	// 2. Controller: Auth Failure (User missing)
	// We MUST provide a body so ShouldBind succeeds, allowing code to reach ExtractUserId
	t.Run("Auth_Missing_User", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "course")
		part, _ := writer.CreateFormFile("asset_file", "t.pdf")
		part.Write([]byte("%PDF"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())
		// userId is NOT set in context

		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	// 3. Controller: Binding Failure (Nil Request Fix)
	t.Run("Binding_Error_Empty_Body", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// FIX: Set an empty buffer instead of nil to prevent Gin panic
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte{}))
		ctx.Request.Header.Set("Content-Type", "multipart/form-data")

		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
	// 4. Controller: Auth Failure (Wrong Type) -> Hits 100% of ExtractUserId
	t.Run("Auth_Invalid_User_Type", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", "not-an-int64") // Trigger ExtractUserId type error

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "test")
		h, _ := writer.CreateFormFile("asset_file", "t.pdf")
		h.Write([]byte("%PDF"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
		assert.Contains(t, w.Body.String(), "invalid userId")
	})

	// 5. Helper: Content-Type Missing -> Hits error branch in helper.go
	t.Run("Helper_Missing_MIME_Header", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(123))

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("model_id", "10")
		_ = writer.WriteField("model_type", "test")

		// Create part WITHOUT Content-Type header
		h := make(textproto.MIMEHeader)
		h.Set("Content-Disposition", `form-data; name="asset_file"; filename="test.pdf"`)
		// Missing: h.Set("Content-Type", ...)
		part, _ := writer.CreatePart(h)
		part.Write([]byte("%PDF"))
		writer.Close()

		ctx.Request, _ = http.NewRequest("POST", "/", body)
		ctx.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.CreateCertificate(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

}

// --- BENCHMARKS ---

func BenchmarkCreateCertificate_FullOrchestration(b *testing.B) {
	mDB := new(MockDBLayer)
	ctrl := NewCertificateControllerGroup(mDB)

	// Create a request that fails validation to benchmark the logic
	// without triggering the S3 panic.
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	_ = writer.WriteField("model_id", "1")
	_ = writer.WriteField("model_type", "test")
	h, _ := writer.CreateFormFile("asset_file", "invalid.png")
	h.Write([]byte("data"))
	writer.Close()
	payload := body.Bytes()
	ct := writer.FormDataContentType()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", int64(1))
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(payload))
		c.Request.Header.Set("Content-Type", ct)
		ctrl.CreateCertificate(c)
	}
}

// --- Benchmarks ---
func BenchmarkCreateCertificate_Validation_Lifecycle(b *testing.B) {
	mDB := new(MockDBLayer)
	ctrl := NewCertificateControllerGroup(mDB)

	// Use a non-PDF to ensure it hits the helper but returns before S3 panic
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	_ = writer.WriteField("model_id", "1")
	_ = writer.WriteField("model_type", "test")
	h, _ := writer.CreateFormFile("asset_file", "t.png")
	h.Write([]byte("data"))
	writer.Close()
	payload := body.Bytes()
	ct := writer.FormDataContentType()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", int64(1))
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(payload))
		c.Request.Header.Set("Content-Type", ct)
		ctrl.CreateCertificate(c)
	}
}

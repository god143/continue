package certificate

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type certificateController struct {
	db db.DBLayer
}

type CertificateControllerGroup interface {
	CreateCertificate(ctx *gin.Context)
	BatchCreateCertificate(ctx *gin.Context)
}

func NewCertificateControllerGroup(db db.DBLayer) CertificateControllerGroup {
	return &certificateController{
		db: db,
	}
}

package courseModules

import "mime/multipart"

type CreateCourseModuleRequest struct {
	CourseID       *int    `json:"course_id" binding:"required"`
	Type           *string `json:"type" binding:"required"`
	Name           *string `json:"name" binding:"required"`
	Description    *string `json:"description"`
	Duration       *int    `json:"duration"` //required if type = chapter
	ContentType    *string `json:"content_type"`
	PassPercentage *int    `json:"pass_percentage"` //required if type = quiz
	ModuleOrder    *int    `json:"module_order"`
}

type UpdateCourseModuleRequest struct {
	ID             *int    `json:"id" binding:"required"`
	CourseID       *int    `json:"course_id"`
	Type           *string `json:"type"`
	Name           *string `json:"name"`
	Description    *string `json:"description"`
	Duration       *int    `json:"duration"` //required if type = chapter
	ContentType    *string `json:"content_type"`
	PassPercentage *int    `json:"pass_percentage"` //required if type = quiz
	ModuleOrder    *int    `json:"module_order"`
}

type DeleteCourseModuleRequest struct {
	ID *int64 `json:"module_id" binding:"required"`
}

type AssetUploadRequest struct {
	CourseID  *int64                `form:"course_id" binding:"required"`
	AssetFile *multipart.FileHeader `form:"asset_file" binding:"required"`
}

type AssetUploadResponse struct {
	Path string `json:"path"`
}

type GetCourseModulesByCourseIDRequest struct {
	CourseID *int64 `form:"course_id" binding:"required"`
}

type GetCourseModuleDetailsRequest struct {
	ModuleID *int64 `uri:"module_id" binding:"required"`
}

type CreateCourseModuleResponse struct {
	ID int64 `json:"id"`
}

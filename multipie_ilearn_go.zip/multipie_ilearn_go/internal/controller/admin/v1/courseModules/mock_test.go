package courseModules

import (
	"bytes"
	"context"
	"encoding/csv"
	"errors"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModelBookmark "multipie_ilearn_go/internal/db/bookmark"
	dbModel "multipie_ilearn_go/internal/db/courseModules"
	"multipie_ilearn_go/internal/logger"

	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mock DBLayer Implementation ---
type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) GetCourseModulesWithResource(ctx context.Context, courseID int64) ([]dbModel.CourseModuleWithResource, error) {
	args := m.Called(ctx, courseID)
	return args.Get(0).([]dbModel.CourseModuleWithResource), args.Error(1)
}

func (m *MockDBLayer) GetBookmarkByCustomParams(ctx context.Context, ids []int, types []string, sub []string, uid int64) ([]dbModelBookmark.Bookmark, error) {
	args := m.Called(ctx, ids, types, sub, uid)
	return args.Get(0).([]dbModelBookmark.Bookmark), args.Error(1)
}

func (m *MockDBLayer) GetCourseModuleByIDWithResource(ctx context.Context, moduleID int64) (dbModel.CourseModuleWithResource, error) {
	args := m.Called(ctx, moduleID)
	return args.Get(0).(dbModel.CourseModuleWithResource), args.Error(1)
}

// Add other missing interface methods as empty mocks to satisfy DBLayer interface
func (m *MockDBLayer) GetCourseModuleByID(ctx context.Context, id int64) (dbModel.CourseModule, error) {
	return dbModel.CourseModule{}, nil
}

func (m *MockDBLayer) CreateCourseModule(ctx context.Context, module *dbModel.CourseModule) (*dbModel.CourseModule, error) {
	args := m.Called(ctx, module)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.CourseModule), args.Error(1)
}

func (m *MockDBLayer) UpdateCourseModule(ctx context.Context, module *dbModel.CourseModule) (*dbModel.CourseModule, error) {
	args := m.Called(ctx, module)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.CourseModule), args.Error(1)
}

func (m *MockDBLayer) DeleteCourseModule(ctx context.Context, id int64) error {
	return m.Called(ctx, id).Error(0)
}

// func (m *MockDBLayer) GetBookmarkByCustomParams(ctx context.Context, ids []int, types []string, sub []string, uid int64) ([]dbModel.Bookmark, error) {
// 	args := m.Called(ctx, ids, types, sub, uid)
// 	return args.Get(0).([]dbModel.Bookmark), args.Error(1)
// }

func (m *MockDBLayer) BatchCreateCourseModules(ctx context.Context, modules []dbModel.CourseModule) error {
	return m.Called(ctx, modules).Error(0)
}

func (m *MockDBLayer) BatchUpdateCourseModules(ctx context.Context, modules []dbModel.CourseModule) error {
	return m.Called(ctx, modules).Error(0)
}

func TestMain(m *testing.M) {
	// Initialize logger once for the package to prevent nil pointer panics in helper.go
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

func createCSVBody(rows [][]string, fieldName string) (*bytes.Buffer, string) {
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, _ := writer.CreateFormFile(fieldName, "test.csv")
	csvWriter := csv.NewWriter(part)
	csvWriter.WriteAll(rows)
	csvWriter.Flush()
	writer.Close()
	return body, writer.FormDataContentType()
}

// --- Helper for Test Setup ---
func setupTestContext(method, url string) (*gin.Context, *httptest.ResponseRecorder) {
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	req, _ := http.NewRequest(method, url, nil)
	ctx.Request = req
	return ctx, w
}

func TestCourseModuleController_Create(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		inputBody      string
		mockSetup      func(m *MockDBLayer)
		expectedStatus int
	}{
		{
			name:      "Happy Case - Create Chapter",
			inputBody: `{"course_id": 1, "type": "chapter", "name": "Intro", "content_type": "video", "duration": 10}`,
			mockSetup: func(m *MockDBLayer) {
				id := 101
				m.On("CreateCourseModule", mock.Anything, mock.Anything).Return(&dbModel.CourseModule{ID: &id}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Bad Request - Invalid JSON",
			inputBody:      `{"course_id": "invalid"}`,
			mockSetup:      func(m *MockDBLayer) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Validation Fail - Chapter missing Duration",
			inputBody:      `{"course_id": 1, "type": "chapter", "name": "Fail", "content_type": "video", "duration": -1}`,
			mockSetup:      func(m *MockDBLayer) {},
			expectedStatus: http.StatusInternalServerError,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := new(MockDBLayer)
			tt.mockSetup(m)
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(tt.inputBody))
			c.Request.Header.Set("Content-Type", "application/json")

			ctrl := NewCourseModuleControllerGroup(m)
			ctrl.CreateCourseModule(c)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestCourseModuleController_BatchCreate(t *testing.T) {
	t.Run("Success - Verify 100-row Chunking", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Create 101 rows (Header + 101 data rows) to trigger loop batch + final batch
		rows := [][]string{{"course_id", "type", "name", "desc", "dur", "ctype", "pass", "order"}}
		for i := 0; i < 101; i++ {
			rows = append(rows, []string{"1", "chapter", "Lesson", "Desc", "10", "video", "", "1"})
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		m.On("BatchCreateCourseModules", mock.Anything, mock.MatchedBy(func(l []dbModel.CourseModule) bool { return len(l) == 100 })).Return(nil).Once()
		m.On("BatchCreateCourseModules", mock.Anything, mock.MatchedBy(func(l []dbModel.CourseModule) bool { return len(l) == 1 })).Return(nil).Once()

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.BatchCreateCourseModule(c)

		assert.Equal(t, http.StatusOK, w.Code)
		m.AssertExpectations(t)
	})
}

func TestGetCourseModuleByCourseID(t *testing.T) {
	tests := []struct {
		name           string
		url            string
		setupCtx       func(*gin.Context)
		setupMock      func(*MockDBLayer)
		expectedStatus int
	}{
		{
			name: "Happy Path - Get Modules",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(12345)) // Matches ExtractUserId case-sensitivity
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{{
						CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)},
					}}, nil)
				m.On("GetBookmarkByCustomParams", mock.Anything, []int{1}, []string{"course_module"}, mock.Anything, int64(12345)).
					Return([]dbModelBookmark.Bookmark{}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Edge Case - Unauthorized",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				// No userId set
			},
			setupMock:      func(m *MockDBLayer) {},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name: "Edge Case - Invalid CourseID Type",
			url:  "/modules?course_id=abc", // Binding will fail
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock:      func(m *MockDBLayer) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name: "Edge Case - DB Fetch Modules Error",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{}, errors.New("db error"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name: "Edge Case - DB Fetch Bookmarks Error",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{{
						CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)},
					}}, nil)
				m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, int64(123)).
					Return([]dbModelBookmark.Bookmark{}, errors.New("bookmark db error"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name: "Happy Path - Modules with Existing Bookmarks",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{{
						CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)},
					}}, nil)
				// Simulate a found bookmark to cover the "exists" branch in helper
				m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, int64(123)).
					Return([]dbModelBookmark.Bookmark{{
						ID:      utils.Int64ToPointer(99),
						ModelId: utils.Int64ToPointer(1),
					}}, nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := new(MockDBLayer)
			ctrl := NewCourseModuleControllerGroup(m)
			tt.setupMock(m)

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			req, _ := http.NewRequest("GET", tt.url, nil)
			c.Request = req

			tt.setupCtx(c)
			ctrl.GetCourseModulesByCourseID(c)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestCourseModuleController_UpdateAndDelete(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("UpdateCourseModule - Success", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := `{"id": 10, "name": "Updated Name", "type": "quiz", "pass_percentage": 80}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(body))
		c.Request.Header.Set("Content-Type", "application/json")

		m.On("UpdateCourseModule", mock.Anything, mock.Anything).Return(&dbModel.CourseModule{}, nil)

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.UpdateCourseModule(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "updated successfully")
	})

	t.Run("DeleteCourseModule - Success", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := `{"module_id": 50}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(body))
		c.Request.Header.Set("Content-Type", "application/json")

		m.On("DeleteCourseModule", mock.Anything, int64(50)).Return(nil)

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.DeleteCourseModule(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "deleted successfully")
	})
}

func TestCourseModuleController_BatchUpdate(t *testing.T) {
	t.Run("BatchUpdate - 11 Column CSV Success", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Header + 1 Row with 11 columns
		rows := [][]string{
			{"id", "course_id", "type", "name", "desc", "dur", "ctype", "pass", "order", "extra1", "extra2"},
			{"10", "1", "chapter", "Updated", "Desc", "20", "video", "", "2", "x", "y"},
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		// Mock the ID check in helper
		modID := 10
		m.On("GetCourseModuleByIDWithResource", mock.Anything, int64(10)).Return(dbModel.CourseModuleWithResource{
			CourseModule: dbModel.CourseModule{ID: &modID},
		}, nil)
		m.On("BatchUpdateCourseModules", mock.Anything, mock.Anything).Return(nil)

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.BatchUpdateCourseModules(c)

		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestExtractDataFromFile_Variants(t *testing.T) {
	m := new(MockDBLayer)
	ctrl := &courseModuleController{db: m}

	t.Run("Extract 9 Column Row - Success", func(t *testing.T) {
		// Matching your case len(row) == 9
		row := []string{"100", "1", "chapter", "Name", "Desc", "10", "video", "80", "1"}
		res, err := ctrl.extractDataFromFile(row)
		assert.NoError(t, err)
		assert.Equal(t, 100, *res.ID)
	})

	t.Run("Extract Invalid Column Count - Default Case", func(t *testing.T) {
		// Your code returns (courseModule, nil) and prints for default
		row := []string{"1", "2"}
		_, err := ctrl.extractDataFromFile(row)
		assert.NoError(t, err) // Matches your code returning nil error
	})
}

func TestBatchUpdate_ErrorPaths(t *testing.T) {
	t.Run("BatchUpdate - Error Reading CSV", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Provide an empty file to trigger error or EOF coverage
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.BatchUpdateCourseModules(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("BatchUpdate - Blank Module ID in CSV", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		rows := [][]string{
			{"module_id", "course_id", "type", "name", "desc", "dur", "ctype", "pass", "order", "e1", "e2"},
			{" ", "1", "chapter", "N", "D", "1", "v", "1", "1", "x", "y"}, // Blank ID
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.BatchUpdateCourseModules(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestController_InternalDBErrors(t *testing.T) {
	// Hits the 'if err != nil' branches in the controller to push coverage to 90%
	m := new(MockDBLayer)
	ctrl := NewCourseModuleControllerGroup(m)

	t.Run("Update - DB Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body := `{"id": 1}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(body))
		c.Request.Header.Set("Content-Type", "application/json")

		m.On("UpdateCourseModule", mock.Anything, mock.Anything).Return(nil, errors.New("db fail")).Once()
		ctrl.UpdateCourseModule(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("Delete - DB Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body := `{"module_id": 1}`
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBufferString(body))
		c.Request.Header.Set("Content-Type", "application/json")

		m.On("DeleteCourseModule", mock.Anything, mock.Anything).Return(errors.New("db fail")).Once()
		ctrl.DeleteCourseModule(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestBatchUpdate_Detailed(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("Full Batch Update Success - 11 Columns", func(t *testing.T) {
		m := new(MockDBLayer)
		ctrl := NewCourseModuleControllerGroup(m)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// This exactly follows the row[1:] slicing in your helper
		rows := [][]string{
			{"module_id", "course_id", "type", "name", "desc", "dur", "ctype", "pass", "order", "extra", "extra2"},
			{"500", "1", "quiz", "Quiz 1", "Desc", "", "", "85", "1", "", ""},
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/batch-update", body)
		c.Request.Header.Set("Content-Type", ct)

		// Expecting the batch DB call
		m.On("BatchUpdateCourseModules", mock.Anything, mock.MatchedBy(func(mods []dbModel.CourseModule) bool {
			return len(mods) == 1 && *mods[0].ID == 500
		})).Return(nil)

		ctrl.BatchUpdateCourseModules(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("BatchUpdate - Invalid ID Format", func(t *testing.T) {
		m := new(MockDBLayer)
		ctrl := NewCourseModuleControllerGroup(m)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		rows := [][]string{
			{"id", "cid", "type", "name", "desc", "dur", "ctype", "pass", "order", "e1", "e2"},
			{"NOT_AN_INT", "1", "chapter", "N", "D", "1", "v", "", "1", "", ""},
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateCourseModules(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestHelper_ExtractData_Errors(t *testing.T) {
	m := new(MockDBLayer)
	ctrl := &courseModuleController{db: m}

	t.Run("Extract 8 Column - Invalid CourseID", func(t *testing.T) {
		row := []string{"abc", "chapter", "Name", "Desc", "10", "video", "", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "courseId value is blank")
	})

	t.Run("Extract 8 Column - Invalid Duration Int", func(t *testing.T) {
		row := []string{"1", "chapter", "Name", "Desc", "TEN", "video", "", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
	})

	t.Run("Extract 9 Column - Invalid ModuleID Int", func(t *testing.T) {
		row := []string{"abc", "1", "chapter", "N", "D", "1", "v", "", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
	})
}
func TestBatchUpdate_Detailed_Coverage(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("BatchUpdate - 11 Column Success Path", func(t *testing.T) {
		m := new(MockDBLayer)
		ctrl := NewCourseModuleControllerGroup(m)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		rows := [][]string{
			{"module_id", "course_id", "type", "name", "desc", "dur", "ctype", "pass", "order", "e1", "e2"}, // Header
			{"500", "1", "chapter", "Lesson 1", "Desc", "10", "video", "", "1", "x", "y"},                   // Data
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		// Mock the single batch update call
		m.On("BatchUpdateCourseModules", mock.Anything, mock.Anything).Return(nil).Once()

		ctrl.BatchUpdateCourseModules(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("BatchUpdate - Invalid Module ID Format", func(t *testing.T) {
		m := new(MockDBLayer)
		ctrl := NewCourseModuleControllerGroup(m)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		rows := [][]string{
			{"id", "cid", "t", "n", "d", "du", "ct", "p", "o", "x", "y"},
			{"NOT_AN_INT", "1", "chapter", "Name", "Desc", "10", "video", "", "1", "", ""},
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateCourseModules(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "invalid value for module_id")
	})
}

func TestHelper_DeepBranchCoverage(t *testing.T) {
	m := new(MockDBLayer)
	ctrl := &courseModuleController{db: m}

	t.Run("Extract 8 Column - Blank CourseID Error", func(t *testing.T) {
		row := []string{"", "chapter", "Name", "Desc", "10", "video", "", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "courseId value is blank")
	})

	t.Run("Extract 8 Column - Invalid Duration Format", func(t *testing.T) {
		row := []string{"1", "chapter", "Name", "Desc", "invalid_int", "video", "", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
	})

	t.Run("Extract 9 Column - Invalid ModuleID Int", func(t *testing.T) {
		row := []string{"abc", "1", "chapter", "Name", "Desc", "10", "video", "80", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
	})

	t.Run("Extract 9 Column - Blank CourseID Error", func(t *testing.T) {
		row := []string{"100", "", "chapter", "Name", "Desc", "10", "video", "80", "1"}
		_, err := ctrl.extractDataFromFile(row)
		assert.Error(t, err)
	})
}

func TestBatchCreate_ErrorHandling(t *testing.T) {
	t.Run("BatchCreate - Row Length Mismatch", func(t *testing.T) {
		m := new(MockDBLayer)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		rows := [][]string{
			{"h1", "h2"},
			{"too", "few"}, // Should trigger the "not enough column" error
		}
		body, ct := createCSVBody(rows, "file")
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl := NewCourseModuleControllerGroup(m)
		ctrl.BatchCreateCourseModule(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}
func TestValidation_EdgeCases(t *testing.T) {
	m := new(MockDBLayer)
	ctrl := &courseModuleController{db: m}

	t.Run("Validate Pass Percentage - Quiz Missing", func(t *testing.T) {
		err := ctrl.validatePassPercentage(constants.CourseModuleTypeEnumQuiz, nil)
		assert.Error(t, err)
	})

	t.Run("Validate Pass Percentage - Non-Quiz", func(t *testing.T) {
		err := ctrl.validatePassPercentage(constants.CourseModuleTypeEnumChapter, nil)
		assert.NoError(t, err)
	})
}

func TestGetCourseModuleDetails(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		moduleID       string
		userID         int64
		dbModule       dbModel.CourseModuleWithResource
		dbErr          error
		expectedStatus int
	}{
		{
			name:           "Happy Path - Module Details",
			moduleID:       "500",
			userID:         55,
			dbModule:       dbModel.CourseModuleWithResource{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(500)}},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Edge Case - Invalid Module ID Format",
			moduleID:       "abc",
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Edge Case - DB Not Found",
			moduleID:       "999",
			userID:         55,
			dbErr:          errors.New("not found"),
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:           "Edge Case - DB Bookmark Fetch Error",
			moduleID:       "500",
			userID:         55,
			dbModule:       dbModel.CourseModuleWithResource{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(500)}},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:           "Happy Path - Module Is Bookmarked",
			moduleID:       "500",
			userID:         55,
			dbModule:       dbModel.CourseModuleWithResource{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(500)}},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockDB := new(MockDBLayer)
			ctrl := NewCourseModuleControllerGroup(mockDB)
			ctx, w := setupTestContext("GET", "/")

			ctx.Params = gin.Params{{Key: "module_id", Value: tt.moduleID}}
			ctx.Set("userId", tt.userID)

			if tt.moduleID != "abc" {
				mockDB.On("GetCourseModuleByIDWithResource", mock.Anything, mock.Anything).Return(tt.dbModule, tt.dbErr)

				if tt.dbErr == nil {
					if tt.name == "Edge Case - DB Bookmark Fetch Error" {
						mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, tt.userID).
							Return([]dbModelBookmark.Bookmark{}, errors.New("bookmark fail"))
					} else if tt.name == "Happy Path - Module Is Bookmarked" {
						mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, tt.userID).
							Return([]dbModelBookmark.Bookmark{{ID: utils.Int64ToPointer(1)}}, nil)
					} else {
						mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, tt.userID).
							Return([]dbModelBookmark.Bookmark{}, nil)
					}
				}
			}

			ctrl.GetCourseModuleDetails(ctx)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- Benchmarks for Performance Validation ---
func BenchmarkGetCourseModulesByCourseID(b *testing.B) {
	m := new(MockDBLayer)
	ctrl := NewCourseModuleControllerGroup(m)
	m.On("GetCourseModulesWithResource", mock.Anything, mock.Anything).Return([]dbModel.CourseModuleWithResource{{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)}}}, nil)
	m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModelBookmark.Bookmark{}, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/?course_id=10", nil)
		c.Set("userId", int64(123))
		ctrl.GetCourseModulesByCourseID(c)
	}
}

// BenchmarkGetCourseModuleDetails measures performance of the detail endpoint
func BenchmarkGetCourseModuleDetails(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mockDB := new(MockDBLayer)
	ctrl := NewCourseModuleControllerGroup(mockDB)

	mockDB.On("GetCourseModuleByIDWithResource", mock.Anything, mock.Anything).Return(dbModel.CourseModuleWithResource{}, nil)
	mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModelBookmark.Bookmark{}, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = gin.Params{{Key: "module_id", Value: "1"}}
		req, _ := http.NewRequest("GET", "/module/1", nil)
		ctx.Request = req
		ctx.Set("user_id", int64(1))

		ctrl.GetCourseModuleDetails(ctx)
	}
}

func BenchmarkCSVDataExtraction(b *testing.B) {
	m := new(MockDBLayer)
	ctrl := &courseModuleController{db: m}
	// Row matches the 8-column 'Create' case
	row := []string{"1", "chapter", "Benchmark Module", "Description", "30", "video", "", "1"}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = ctrl.extractDataFromFile(row)
	}
}

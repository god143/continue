package courseModules

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// CreateCourseModule creates a new course module
func (c *courseModuleController) CreateCourseModule(ctx *gin.Context) {
	var (
		request CreateCourseModuleRequest
		resp    *utils.Response
	)
	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createCourseResp, err := c.createCourseModuleHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createCourseResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

// UpdateCourseModule updates an existing course module
func (c *courseModuleController) UpdateCourseModule(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateCourseModuleRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.updateCourseModuleHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("course module updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)

}

// DisableCourseModule disables a specific course module
func (c *courseModuleController) DeleteCourseModule(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DeleteCourseModuleRequest
	)

	if err := ctx.BindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.deleteCourseModuleHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("course module deleted successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

// BatchCreateCourseModule creates multiple course modules at once
func (c *courseModuleController) BatchCreateCourseModule(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchCreateCourseModuleHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of course module is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

// BulkUpdateCourseModules updates multiple course modules at once
func (c *courseModuleController) BatchUpdateCourseModules(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchUpdateCourseModulesHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch updation of course module is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

// GetCourseModulesByCourseID retrieves all modules by course ID
func (c *courseModuleController) GetCourseModulesByCourseID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseModulesByCourseIDRequest
	)
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	courseModulesResp, err := c.getCourseModulesByCourseIDHelper(ctx, request, uid)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer("unable to fetch modules by course-id"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(courseModulesResp, nil))
}

// GetCourseModuleDetails retrieves details of a single course module
func (c *courseModuleController) GetCourseModuleDetails(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseModuleDetailsRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid moduleId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}
	moduleResp, err := c.getCourseModuleDetailsHelper(ctx, request, &uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch course_module details"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(moduleResp, nil))
}

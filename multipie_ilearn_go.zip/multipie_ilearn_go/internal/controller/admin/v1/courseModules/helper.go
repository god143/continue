package courseModules

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/courseModules"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (c *courseModuleController) getCourseModulesByCourseIDHelper(ctx context.Context, request GetCourseModulesByCourseIDRequest, userId int64) ([]dbModel.CourseModuleWithResource, error) {
	var courseModuleIds []int
	var courseModuleTypes []string
	var subtype []string
	courseModules, err := c.db.GetCourseModulesWithResource(ctx, *request.CourseID)
	if err != nil {
		logger.Error(ctx, "unable to fetch course modules", zap.Error(err))
		return courseModules, err
	}

	for _, courseModule := range courseModules {
		courseModuleIds = append(courseModuleIds, *courseModule.ID)
		courseModuleTypes = append(courseModuleTypes, "course_module")
	}

	bookmarks, err := c.db.GetBookmarkByCustomParams(ctx, courseModuleIds, courseModuleTypes, subtype, int64(userId))
	if err != nil {
		return nil, err
	}

	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)

		}
	}

	responses := make([]dbModel.CourseModuleWithResource, 0, len(courseModules))

	for _, m := range courseModules {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}
		responses = append(responses, dbModel.CourseModuleWithResource{
			CourseModule:    m.CourseModule,
			ExternalUrl:     m.ExternalUrl,
			ExternalUrlDark: m.ExternalUrlDark,
			IsBookmark:      isBookmark,
			BookmarkId:      bookmarkIdPtr,
		})
	}

	return responses, nil
}

func (c *courseModuleController) getCourseModuleDetailsHelper(ctx context.Context, request GetCourseModuleDetailsRequest, userId *int64) (dbModel.CourseModuleWithResource, error) {

	var courseIds []int
	var courseTypes []string
	var bookmarkId *int64
	var subtype []string

	course, err := c.db.GetCourseModuleByIDWithResource(ctx, *request.ModuleID)
	if err != nil {
		logger.Error(ctx, "unable to fetch course module", zap.Error(err))
		return dbModel.CourseModuleWithResource{}, err
	}

	courseIds = append(courseIds, *course.ID)
	courseTypes = append(courseTypes, "course_module")

	bookmark, err := c.db.GetBookmarkByCustomParams(ctx, courseIds, courseTypes, subtype, *userId)
	if err != nil {
		return dbModel.CourseModuleWithResource{}, err
	}
	for _, bm := range bookmark {
		bookmarkId = bm.ID
	}

	isBookmark := len(bookmark) != 0
	course.IsBookmark = &isBookmark
	course.BookmarkId = bookmarkId

	return course, nil
}

func (c *courseModuleController) createCourseModuleHelper(ctx context.Context, request CreateCourseModuleRequest) (CreateCourseModuleResponse, error) {
	var (
		resp        CreateCourseModuleResponse
		contentType constants.CourseModuleContentTypeEnum
	)

	//validate type parameter
	moduleType, err := c.validateCourseModuleType(request.Type)
	if err != nil {
		logger.Error(ctx, "invalid value for course_module type", zap.Error(err), zap.Any("input value", request.Type))
		return resp, fmt.Errorf("invalid value for course_module type, error: %v", err)
	}

	//validate content type
	if moduleType == constants.CourseModuleTypeEnumChapter {
		if request.ContentType == nil {
			logger.Error(ctx, "for module type chapter, content_type is required field", zap.Error(err), zap.Any("input value", request.ContentType))
			return resp, fmt.Errorf("for module type chapter, content_type is required field, error: %v", err)
		}
		contentType, err = c.validateCourseContentType(request.ContentType)
		if err != nil {
			logger.Error(ctx, "invalid value for course_module content type", zap.Error(err), zap.Any("input value", request.ContentType))
			return resp, fmt.Errorf("invalid value for course_module content type, error: %v", err)
		}
	}

	//validate pass percentage
	err = c.validatePassPercentage(moduleType, request.PassPercentage)
	if err != nil {
		logger.Error(ctx, "invalid value for pass_percentage", zap.Error(err), zap.Any("input value", request.ContentType))
		return resp, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
	}

	//validate duration
	err = c.validateDuration(moduleType, request.Duration)
	if err != nil {
		logger.Error(ctx, "invalid value for duration", zap.Error(err), zap.Any("input value", request.ContentType))
		return resp, fmt.Errorf("invalid value for duration, error: %v", err)
	}

	courseModule := &dbModel.CourseModule{
		CourseID:       request.CourseID,
		Type:           &moduleType,
		Name:           request.Name,
		Description:    request.Description,
		Duration:       request.Duration,
		ContentType:    &contentType,
		PassPercentage: request.PassPercentage,
		ModuleOrder:    request.ModuleOrder,
	}

	courseModule, err = c.db.CreateCourseModule(ctx, courseModule)
	if err != nil {
		logger.Error(ctx, "unable to create module entry for course in database", zap.Error(err), zap.Any("requestBody", request))
		return resp, errors.New("unable to create module entry for course in database")
	}

	resp = CreateCourseModuleResponse{
		ID: int64(*courseModule.ID),
	}

	return resp, nil
}

func (c *courseModuleController) updateCourseModuleHelper(ctx context.Context, request UpdateCourseModuleRequest) error {
	var (
		moduleType constants.CourseModuleTypeEnum
		err        error
	)

	courseModule := &dbModel.CourseModule{
		ID:          request.ID,
		CourseID:    request.CourseID,
		Name:        request.Name,
		Description: request.Description,
		ModuleOrder: request.ModuleOrder,
	}

	//validate type parameter
	if request.Type != nil {
		moduleType, err = c.validateCourseModuleType(request.Type)
		if err != nil {
			logger.Error(ctx, "invalid value for course_module type", zap.Error(err), zap.Any("input value", request.Type))
			return fmt.Errorf("invalid value for course_module type, error: %v", err)
		}
		courseModule.Type = &moduleType
	}

	//validate content type
	if request.ContentType != nil {
		contentType, err := c.validateCourseContentType(request.Type)
		if err != nil {
			logger.Error(ctx, "invalid value for course_module content type", zap.Error(err), zap.Any("input value", request.ContentType))
			return fmt.Errorf("invalid value for course_module content type, error: %v", err)
		}

		courseModule.ContentType = &contentType
	}

	//validate pass percentage
	err = c.validatePassPercentage(moduleType, request.PassPercentage)
	if err != nil {
		logger.Error(ctx, "invalid value for pass_percentage", zap.Error(err), zap.Any("input value", request.ContentType))
		return fmt.Errorf("invalid value for pass_percentage, error: %v", err)
	}
	courseModule.PassPercentage = request.PassPercentage

	//validate duration
	err = c.validateDuration(moduleType, request.PassPercentage)
	if err != nil {
		logger.Error(ctx, "invalid value for pass_percentage", zap.Error(err), zap.Any("input value", request.ContentType))
		return fmt.Errorf("invalid value for pass_percentage, error: %v", err)
	}

	_, err = c.db.UpdateCourseModule(ctx, courseModule)
	if err != nil {
		logger.Error(ctx, "unable to update course_module entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update course_module entry in database")
	}

	return nil
}

func (c *courseModuleController) deleteCourseModuleHelper(ctx context.Context, request DeleteCourseModuleRequest) error {
	err := c.db.DeleteCourseModule(ctx, *request.ID)
	if err != nil {
		logger.Error(ctx, "unable to delete course_module in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete course_module entry in database")
	}

	return nil
}

func (c *courseModuleController) batchCreateCourseModuleHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		modules  []dbModel.CourseModule
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}
		if len(row) < 8 || len(row) > 9 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		courseModule, err := c.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		modules = append(modules, courseModule)
		if len(modules) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchCreateCourseModules(ctx, modules); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			modules = []dbModel.CourseModule{} //clear categories array
		}

	}

	if len(modules) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchCreateCourseModules(ctx, modules); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

func (c *courseModuleController) batchUpdateCourseModulesHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		modules  []dbModel.CourseModule
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}
		if len(row) != 11 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount), zap.Any("number of columns", len(row)))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		courseModule, err := c.extractDataFromFile(row[1:])
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		//validate ID column
		moduleIdStr := strings.TrimSpace(row[0])
		if len(moduleIdStr) == 0 {
			return fmt.Errorf("module_id value is blank, error: %v", err)
		}
		moduleId, err := strconv.Atoi(moduleIdStr)
		if err != nil {
			return fmt.Errorf("invalid value for module_id column,error: %v", err)
		}
		courseModule.ID = utils.IntToPointer(moduleId)

		modules = append(modules, courseModule)
		if len(modules) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchUpdateCourseModules(ctx, modules); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			modules = []dbModel.CourseModule{} //clear categories array
		}

	}

	if len(modules) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchUpdateCourseModules(ctx, modules); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}
func (c *courseModuleController) extractDataFromFile(row []string) (dbModel.CourseModule, error) {
	var (
		courseModule dbModel.CourseModule
		err          error
	)

	switch {
	case len(row) == 8:

		//validate course_id
		courseIdStr := strings.TrimSpace(row[0])
		if len(courseIdStr) == 0 {
			return courseModule, fmt.Errorf("courseId value is blank, error: %v", err)
		}
		courseId, err := strconv.Atoi(courseIdStr)
		if err != nil {
			return courseModule, fmt.Errorf("courseId value is blank, error: %v", err)
		}
		courseModule.CourseID = utils.IntToPointer(courseId)

		//validate module-type
		temp := strings.TrimSpace(row[1])
		moduleType, err := c.validateCourseModuleType(utils.StringToPointer(temp))
		if err != nil {
			return courseModule, fmt.Errorf("invalid value for course_module type, error: %v", err)
		}
		courseModule.Type = &moduleType

		//validate name
		name := strings.TrimSpace(row[2])
		if len(name) == 0 {
			return courseModule, fmt.Errorf("invalid value for course_module name")
		}
		courseModule.Name = &name

		//validate description
		description := strings.TrimSpace(row[3])
		if len(name) == 0 {
			return courseModule, fmt.Errorf("invalid value for course_module description")
		}
		courseModule.Description = &description

		//duration
		durationStr := strings.TrimSpace(row[4])
		if len(durationStr) != 0 {
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for duration, error: %v", err)
			}
			//validate duration
			err = c.validateDuration(moduleType, &duration)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
			}
			courseModule.Duration = utils.IntToPointer(duration)
		}

		//content_type
		temp = strings.TrimSpace(row[5])
		if len(temp) != 0 {
			contentType, err := c.validateCourseContentType(utils.StringToPointer(temp))
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for course_module content_type, error: %v", err)
			}
			courseModule.ContentType = &contentType
		}

		//pass_percentage
		passPercentageStr := strings.TrimSpace(row[6])
		if len(passPercentageStr) != 0 {
			passPercentage, err := strconv.Atoi(passPercentageStr)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
			}
			err = c.validatePassPercentage(moduleType, &passPercentage)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
			}

			courseModule.PassPercentage = utils.IntToPointer(passPercentage)
		}

		//module_order
		moduleOrderStr := strings.TrimSpace(row[7])
		if len(moduleOrderStr) != 0 {
			moduleOrder, err := strconv.Atoi(moduleOrderStr)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for module_order, error: %v", err)
			}
			courseModule.ModuleOrder = utils.IntToPointer(moduleOrder)
		}

		return courseModule, nil

	case len(row) == 9:
		// validate course_module_id
		courseModuleId, err := strconv.Atoi(row[0])
		if err != nil {
			return courseModule, fmt.Errorf("failed to convert into integer: %v", err)
		}
		courseModule.ID = utils.IntToPointer(int(courseModuleId))

		//validate course_id
		courseIdStr := strings.TrimSpace(row[1])
		if len(courseIdStr) == 0 {
			return courseModule, fmt.Errorf("category_id value is blank, error: %v", err)
		}
		coursesId, err := strconv.Atoi(courseIdStr)
		if err != nil {
			return courseModule, fmt.Errorf("category_id value is blank, error: %v", err)
		}
		courseModule.CourseID = utils.IntToPointer(coursesId)

		//validate module-type
		temp := strings.TrimSpace(row[2])
		moduleType, err := c.validateCourseModuleType(utils.StringToPointer(temp))
		if err != nil {
			return courseModule, fmt.Errorf("invalid value for course_module type, error: %v", err)
		}
		courseModule.Type = &moduleType

		//validate name
		name := strings.TrimSpace(row[3])
		if len(name) == 0 {
			return courseModule, fmt.Errorf("invalid value for course_module name")
		}
		courseModule.Name = &name

		//validate description
		description := strings.TrimSpace(row[4])
		if len(name) == 0 {
			return courseModule, fmt.Errorf("invalid value for course_module description")
		}
		courseModule.Description = &description

		//duration
		durationStr := strings.TrimSpace(row[5])
		if len(durationStr) != 0 {
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for duration, error: %v", err)
			}
			//validate duration
			err = c.validateDuration(moduleType, &duration)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
			}
			courseModule.Duration = utils.IntToPointer(duration)
		}

		//content_type
		temp = strings.TrimSpace(row[6])
		if len(temp) != 0 {
			contentType, err := c.validateCourseContentType(utils.StringToPointer(temp))
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for course_module content_type, error: %v", err)
			}
			courseModule.ContentType = &contentType
		}

		//pass_percentage
		passPercentageStr := strings.TrimSpace(row[7])
		if len(passPercentageStr) != 0 {
			passPercentage, err := strconv.Atoi(passPercentageStr)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
			}
			err = c.validatePassPercentage(moduleType, &passPercentage)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for pass_percentage, error: %v", err)
			}

			courseModule.PassPercentage = utils.IntToPointer(passPercentage)
		}

		//module_order
		moduleOrderStr := strings.TrimSpace(row[8])
		if len(moduleOrderStr) != 0 {
			moduleOrder, err := strconv.Atoi(moduleOrderStr)
			if err != nil {
				return courseModule, fmt.Errorf("invalid value for module_order, error: %v", err)
			}
			courseModule.ModuleOrder = utils.IntToPointer(moduleOrder)
		}

		return courseModule, nil

	default:
		fmt.Printf("invalid number of row")
	}
	return courseModule, nil

}

func (c *courseModuleController) validateCourseModuleType(moduleType *string) (constants.CourseModuleTypeEnum, error) {
	return constants.ParseCourseModuleTypeEnum(*moduleType)
}

func (c *courseModuleController) validateCourseContentType(contentType *string) (constants.CourseModuleContentTypeEnum, error) {
	return constants.ParseCourseModuleContentTypeEnum(*contentType)
}

func (c *courseModuleController) validatePassPercentage(moduleType constants.CourseModuleTypeEnum, passPercentage *int) error {
	if moduleType == constants.CourseModuleTypeEnumQuiz {
		if passPercentage == nil || *passPercentage < 0 {
			return fmt.Errorf("pass_percentage is value is required for quizz module and cannot be less than zero")
		}
	}

	return nil
}

func (c *courseModuleController) validateDuration(moduleType constants.CourseModuleTypeEnum, duration *int) error {
	if moduleType == constants.CourseModuleTypeEnumChapter {
		if duration == nil || *duration < 0 {
			return fmt.Errorf("duration is value is required for chapter module and cannot be less than zero")
		}
	}

	return nil
}

package courseModules

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type courseModuleController struct {
	db db.DBLayer
}

type CourseModuleControllerGroup interface {
	// Course Module Methods
	CreateCourseModule(ctx *gin.Context)
	UpdateCourseModule(ctx *gin.Context)
	DeleteCourseModule(ctx *gin.Context)
	BatchCreateCourseModule(ctx *gin.Context)
	BatchUpdateCourseModules(ctx *gin.Context)
	GetCourseModulesByCourseID(ctx *gin.Context)
	GetCourseModuleDetails(ctx *gin.Context)
}

func NewCourseModuleControllerGroup(db db.DBLayer) CourseModuleControllerGroup {
	return &courseModuleController{
		db: db,
	}
}

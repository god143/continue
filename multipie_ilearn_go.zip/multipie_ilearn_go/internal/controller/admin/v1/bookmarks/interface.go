package bookmark

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type bookmarksController struct {
	db db.DBLayer
}

type BookmarkControllerGroup interface {
	BatchCreateBookmark(ctx *gin.Context)
}

func NewBookmarkControllerGroup(db db.DBLayer) BookmarkControllerGroup {
	return &bookmarksController{
		db: db,
	}
}

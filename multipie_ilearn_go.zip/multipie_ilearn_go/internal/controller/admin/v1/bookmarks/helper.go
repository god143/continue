package bookmark

import (
	"context"
	"encoding/csv"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/bookmark"
	"multipie_ilearn_go/internal/logger"

	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (q *bookmarksController) batchCreateBookmarksHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount  int
		batchNo   int
		bookmarks []dbModel.Bookmark
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 5 || len(row) > 6 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		bookmark, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		// quiz.Visible = utils.BoolToPointer(true)

		bookmarks = append(bookmarks, bookmark)
		if len(bookmarks) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateBookmark(ctx, bookmarks); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			bookmarks = []dbModel.Bookmark{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(bookmarks) > 0 {
		if err := q.db.BatchCreateBookmark(ctx, bookmarks); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (c *bookmarksController) extractDataFromFile(row []string) (dbModel.Bookmark, error) {
	var (
		bookmark dbModel.Bookmark
	)

	switch {
	case len(row) == 5:
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for  userId, error: %v", err)
			}
			bookmark.UserId = utils.Int64ToPointer(int64(userId))
		}

		modelIdStr := strings.TrimSpace(row[1])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}
			bookmark.ModelId = utils.Int64ToPointer(int64(modelId))
		}

		//validate model type
		modelType := strings.TrimSpace(row[2])
		if len(modelType) != 0 {
			modeltype, err := validateModelType(modelType)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for model type, error: %v", err)
			}
			bookmark.ModelType = &modeltype
		}
		name := strings.TrimSpace(row[3])
		if len(name) != 0 {
			bookmark.Name = &name

		} else {
			return bookmark, fmt.Errorf("invalid value for name")
		}

		// createdAtStr := strings.TrimSpace(row[4])
		// if len(createdAtStr) != 0 {
		// 	createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
		// 	if err != nil {
		// 		return bookmark, fmt.Errorf("invalid value for createdAt column,error: %v", err)
		// 	}
		// 	bookmark.CreatedAt = &createdAt
		// }

		// updatedAtStr := strings.TrimSpace(row[5])
		// if len(updatedAtStr) != 0 {
		// 	updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
		// 	if err != nil {
		// 		return bookmark, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
		// 	}
		// 	bookmark.UpdatedAt = &updatedAt
		// }

		subType := strings.TrimSpace(row[4])
		if len(subType) != 0 {
			subType, err := validateSubType(subType)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for sub type, error: %v", err)
			}
			bookmark.SubType = &subType
		}

		return bookmark, nil

	case len(row) == 6:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return bookmark, fmt.Errorf("failed to convert into integer: %v", err)
		}
		bookmark.ID = utils.Int64ToPointer(int64(id))

		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for  userId, error: %v", err)
			}
			bookmark.UserId = utils.Int64ToPointer(int64(userId))
		}

		modelIdStr := strings.TrimSpace(row[2])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}
			bookmark.ModelId = utils.Int64ToPointer(int64(modelId))
		}

		//validate model type
		modelType := strings.TrimSpace(row[3])
		if len(modelType) != 0 {
			modeltype, err := validateModelType(modelType)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for model type, error: %v", err)
			}
			bookmark.ModelType = &modeltype
		}

		name := strings.TrimSpace(row[4])
		if len(name) != 0 {
			bookmark.Name = &name

		} else {
			return bookmark, fmt.Errorf("invalid value for name")
		}

		// createdAtStr := strings.TrimSpace(row[5])
		// if len(createdAtStr) != 0 {
		// 	createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
		// 	if err != nil {
		// 		return bookmark, fmt.Errorf("invalid value for createdAt column,error: %v", err)
		// 	}
		// 	bookmark.CreatedAt = &createdAt
		// }

		// updatedAtStr := strings.TrimSpace(row[6])
		// if len(updatedAtStr) != 0 {
		// 	updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
		// 	if err != nil {
		// 		return bookmark, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
		// 	}
		// 	bookmark.UpdatedAt = &updatedAt
		// }

		subType := strings.TrimSpace(row[5])
		if len(subType) != 0 {
			subType, err := validateSubType(subType)
			if err != nil {
				return bookmark, fmt.Errorf("invalid value for sub type, error: %v", err)
			}
			bookmark.SubType = &subType
		}

		return bookmark, nil

	default:
		fmt.Printf("invalid number of row")
	}

	return bookmark, nil

}

func validateModelType(modelType string) (constants.BookmarkModelTypeEnum, error) {
	return constants.ParseBookmarkModelTypeEnum(modelType)
}

func validateSubType(subType string) (constants.BookmarkSubTypeEnum, error) {
	return constants.ParseBookmarkSubTypeEnum(subType)
}

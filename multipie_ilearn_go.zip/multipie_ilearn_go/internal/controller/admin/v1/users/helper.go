package users

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/users"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

/*getUserHelper... get all users from database */
func (c *usersController) getUsersHelper(ctx context.Context, request GetUsersRequest) (*utils.Pagination, error) {

	usersResult, err := c.db.GetUsers(ctx, request.Page, request.PageSize)

	if err != nil {
		logger.Error(ctx, "unable to fetch users from db", zap.Error(err))
		return nil, errors.New("unable to fetch users from db")
	}

	return usersResult, nil
}

/*
createUserHelper... create user in database
*/
func (c *usersController) createUsersHelper(ctx context.Context, request CreateUsersRequest) (*dbModel.Users, error) {

	defaultRole := constants.UserRoleEnumUser
	defaultStatus := constants.UserStatusEnumActive

	users := &dbModel.Users{
		DisplayName:     request.DisplayName,
		Username:        request.Username,
		FirstName:       request.FirstName,
		LastName:        request.LastName,
		Mobile:          request.Mobile,
		Email:           request.Email,
		Role:            &defaultRole,
		Status:          &defaultStatus,
		Uid:             request.Uid,
		ViaLogin:        request.ViaLogin,
		SignInCount:     request.SignInCount,
		IdirectUsername: request.IdirectUsername,
	}

	users, err := c.db.CreateUsers(ctx, users)
	if err != nil {
		logger.Error(ctx, "unable to create users entry in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to create users entry in database")
	}

	updateUserRequest := &dbModel.Users{
		ID:  users.ID,
		Uid: users.ID,
	}

	updatedUsers, err := c.db.UpdateUsers(ctx, *updateUserRequest)
	if err != nil {
		logger.Error(ctx, "unable to update users uid in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to update uid entry in database")
	}

	users.Uid = updatedUsers.Uid

	return users, nil
}

/*
updateUserHelper... update user in database
*/
func (c *usersController) updateUsersHelper(ctx context.Context, request UpdateUsersRequest) error {
	firstName, remainder, _ := strings.Cut(*request.DisplayName, " ")
	request.FirstName = &firstName
	request.LastName = &remainder

	users := dbModel.Users{
		ID:              request.ID,
		DisplayName:     request.DisplayName,
		Username:        request.Username,
		FirstName:       request.FirstName,
		LastName:        request.LastName,
		Mobile:          request.Mobile,
		Email:           request.Email,
		ViaLogin:        request.ViaLogin,
		SignInCount:     request.SignInCount,
		IdirectUsername: request.IdirectUsername,
	}

	_, err := c.db.UpdateUsers(ctx, users)
	if err != nil {
		logger.Error(ctx, "unable to update users entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update users entry in database")
	}

	return nil
}

/*lockUserHelper... lock user in database*/
func (c *usersController) lockUserHelper(ctx context.Context, request LockUserRequest) error {

	err := c.db.LockUser(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to lock user", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to lock user")
	}

	return nil
}

func (c *usersController) unlockUserHelper(ctx context.Context, request LockUserRequest) error {

	err := c.db.UnLockUser(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to lock user", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to lock user")
	}

	return nil
}

func (c *usersController) updateStatusHelper(ctx context.Context, userId int64, status string) error {

	err := c.db.UpdateStatus(ctx, userId, status)
	if err != nil {
		logger.Error(ctx, "unable to update status", zap.Error(err), zap.Any("userId", userId))
		return errors.New("unable to update status")
	}

	return nil
}

/*makeadminHelper... make user admin in database*/
func (c *usersController) makeAdminHelper(ctx context.Context, request MakeAdminRequest) error {

	err := c.db.MakeAdmin(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to make user admin", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to make user admin")
	}

	return nil
}

func (c *usersController) batchCreateUserHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		users    []dbModel.Users
	)
	//read csv
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ //increment rowCount

		if rowCount == 1 {
			continue //skip first row
		}

		if len(row) < 17 || len(row) > 18 {
			logger.Error(ctx, "not enough column in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough column in the row, rowNumber: %v", rowCount)
		}

		//extract data from row
		user, err := c.extractDataForCreateFile(row)
		if err != nil {
			logger.Error(ctx, "error occured", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		users = append(users, user)
		if len(users) == 100 {
			batchNo++ //increment batch
			if err := c.db.BatchCreateUser(ctx, users); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
			users = []dbModel.Users{} //clear courses array
		}

	}

	if len(users) > 0 {
		batchNo++ //increment batch
		if err := c.db.BatchCreateUser(ctx, users); err != nil {
			logger.Error(ctx, "final batch insertion failed for batch", zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, "batch of records successfully processed", zap.Any("batchNo", batchNo))
	}

	return nil
}

func (c *usersController) extractDataForCreateFile(row []string) (dbModel.Users, error) {
	var (
		users dbModel.Users
	)

	switch {
	case len(row) == 17:

		//validate username of the user
		username := strings.TrimSpace(row[0])
		if len(username) == 0 {
			return users, fmt.Errorf("username value is blank, error")
		}
		users.Username = &username

		//validate fisrtname of the user
		firstName := strings.TrimSpace(row[1])
		if len(firstName) == 0 {
			return users, fmt.Errorf("firstName value is blank, error")
		}
		users.FirstName = &firstName

		//validate lastname of the user
		lastName := strings.TrimSpace(row[2])
		users.LastName = &lastName

		//validate mobile of the user
		mobile := strings.TrimSpace(row[3])
		users.Mobile = &mobile

		//validate email of the user
		email := strings.TrimSpace(row[4])
		users.Email = &email

		//validate role of the user
		role, err := validateUserRole(row[5])
		if err != nil {
			return users, fmt.Errorf("invalid value for role, error: %v", err)
		}
		users.Role = &role

		//validate status of the user
		status, err := validateUserStatus(row[6])
		if err != nil {
			return users, fmt.Errorf("invalid value for status, error: %v", err)
		}
		users.Status = &status

		//validate uid of the user
		uidStr := strings.TrimSpace(row[7])
		if len(uidStr) == 0 {
			return users, fmt.Errorf("uid value is blank, error: %v", err)
		}
		uid, err := strconv.Atoi(uidStr)
		if err != nil {
			return users, fmt.Errorf("invalid value for uid column,error: %v", err)
		}
		users.Uid = utils.Int64ToPointer(int64(uid))

		createdAtStr := strings.TrimSpace(row[8])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			users.CreatedAt = &createdAt
		}

		updatedAtStr := strings.TrimSpace(row[9])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			users.UpdatedAt = &updatedAt
		}

		//validate displayname of the user
		displayName := strings.TrimSpace(row[10])
		if len(displayName) == 0 {
			return users, fmt.Errorf("displayname value is blank, error")
		}
		users.DisplayName = &displayName

		firstAccessStr := strings.TrimSpace(row[11])
		if len(firstAccessStr) != 0 {
			firstAccess, err := time.Parse("2006-01-02 15:04:05", firstAccessStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for first access column,error: %v", err)
			}
			users.FirstAccess = &firstAccess
		}

		lastAccessStr := strings.TrimSpace(row[12])
		if len(lastAccessStr) != 0 {
			lastAccess, err := time.Parse("2006-01-02 15:04:05", lastAccessStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for last access column,error: %v", err)
			}
			users.LastAccess = &lastAccess
		}

		viaLogin := strings.TrimSpace(row[13])
		users.ViaLogin = &viaLogin

		//validate sign in count
		signInCountStr := strings.TrimSpace(row[14])
		if len(signInCountStr) != 0 {
			signInCount, err := strconv.Atoi(signInCountStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for signInCount column,error: %v", err)
			}
			users.SignInCount = utils.Int64ToPointer(int64(signInCount))
		} else {
			users.SignInCount = utils.Int64ToPointer(0)
			return users, err
		}

		idirectUsername := strings.TrimSpace(row[15])
		if idirectUsername != "" {
			users.IdirectUsername = &idirectUsername
		} else {
			users.IdirectUsername = nil
		}

		account_source := strings.TrimSpace(row[16])
		users.AccountSource = &account_source

		return users, nil

	case len(row) == 18:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return users, fmt.Errorf("failed to convert into integer: %v", err)
		}
		users.ID = utils.Int64ToPointer(int64(id))

		//validate username of the user
		username := strings.TrimSpace(row[1])
		if len(username) == 0 {
			return users, fmt.Errorf("category_id value is blank, error:")
		}
		users.Username = &username

		//validate fisrtname of the user
		firstName := strings.TrimSpace(row[2])
		if len(firstName) == 0 {
			return users, fmt.Errorf("firstName value is blank, error")
		}
		users.FirstName = &firstName

		//validate fisrtname of the user
		lastName := strings.TrimSpace(row[3])
		users.LastName = &lastName

		//validate lastname of the user
		mobile := strings.TrimSpace(row[4])
		users.Mobile = &mobile

		//validate email of the user
		email := strings.TrimSpace(row[5])
		users.Email = &email

		//validate userRole of the user
		role, err := validateUserRole(row[6])
		if err != nil {
			return users, fmt.Errorf("invalid value for role, error: %v", err)
		}
		users.Role = &role

		//validate userStatus of the user
		status, err := validateUserStatus(row[7])
		if err != nil {
			return users, fmt.Errorf("invalid value for status, error: %v", err)
		}
		users.Status = &status

		//validate uid of the user
		uidStr := strings.TrimSpace(row[8])
		if len(uidStr) == 0 {
			return users, fmt.Errorf("category_id value is blank, error: %v", err)
		}
		uid, err := strconv.Atoi(uidStr)
		if err != nil {
			return users, fmt.Errorf("invalid value for category_id column,error: %v", err)
		}
		users.Uid = utils.Int64ToPointer(int64(uid))

		//validate createdAt of the user
		createdAtStr := strings.TrimSpace(row[9])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			users.CreatedAt = &createdAt
		}

		//validate updatedAt of the user
		updatedAtStr := strings.TrimSpace(row[10])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			users.UpdatedAt = &updatedAt
		}

		//validate displayname of the user
		displayName := strings.TrimSpace(row[11])
		if len(displayName) == 0 {
			return users, fmt.Errorf("displayname value is blank, error")
		}
		users.DisplayName = &displayName

		firstAccessStr := strings.TrimSpace(row[12])
		if len(firstAccessStr) != 0 {
			firstAccess, err := time.Parse("2006-01-02 15:04:05", firstAccessStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for first access column,error: %v", err)
			}
			users.FirstAccess = &firstAccess
		}

		lastAccessStr := strings.TrimSpace(row[13])
		if len(lastAccessStr) != 0 {
			lastAccess, err := time.Parse("2006-01-02 15:04:05", lastAccessStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for last access column,error: %v", err)
			}
			users.LastAccess = &lastAccess
		}

		viaLogin := strings.TrimSpace(row[14])
		users.ViaLogin = &viaLogin

		//validate sign in count
		signInCountStr := strings.TrimSpace(row[15])
		if len(signInCountStr) != 0 {
			signInCount, err := strconv.Atoi(signInCountStr)
			if err != nil {
				return users, fmt.Errorf("invalid value for signInCount column,error: %v", err)
			}
			users.SignInCount = utils.Int64ToPointer(int64(signInCount))
		} else {
			users.SignInCount = utils.Int64ToPointer(0)
			return users, err
		}

		idirectUsername := strings.TrimSpace(row[16])
		if idirectUsername != "" {
			users.IdirectUsername = &idirectUsername
		} else {
			users.IdirectUsername = nil
		}

		account_source := strings.TrimSpace(row[17])
		users.AccountSource = &account_source

		return users, nil

	default:
		fmt.Printf("invalid number of row")
	}

	return users, nil

}

func validateUserRole(role string) (constants.UserRoleEnum, error) {
	return constants.ParseUserRoleEnum(role)
}
func validateUserStatus(role string) (constants.UserStatusEnum, error) {
	return constants.ParseUserStatusEnum(role)
}
func parseUserStartDate(startDate string) (time.Time, error) {
	return utils.ParseTime(startDate, "yyyy-mm-dd")
}

func parseUserEndDate(endDate string) (time.Time, error) {
	return utils.ParseTime(endDate, "yyyy-mm-dd")
}

package users

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *usersController) GetUsers(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetUsersRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getUsersResp, err := c.getUsersHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getUsersResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *usersController) CreateUsers(ctx *gin.Context) {
	var (
		resp     *utils.Response
		request  CreateUsersRequest
		response CreateUsersResponse
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	users, err := c.createUsersHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response = CreateUsersResponse{
		ID: int64(*users.ID),
	}
	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *usersController) UpdateUsers(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateUsersRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.updateUsersHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("User updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *usersController) LockUser(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request LockUserRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.lockUserHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("user locked successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *usersController) UnLockUser(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request LockUserRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.unlockUserHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("user unlocked successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *usersController) UpdateStatus(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateStatusRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err = c.updateStatusHelper(ctx, userID, request.Status.String())
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("status updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)

}

func (c *usersController) MakeAdmin(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request MakeAdminRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := c.makeAdminHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("User made admin successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}
func (c *usersController) BatchCreateUser(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = c.batchCreateUserHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of users is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

package users

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type usersController struct {
	db db.DBLayer
}

type UsersControllerGroup interface {
	GetUsers(ctx *gin.Context)
	CreateUsers(ctx *gin.Context)
	UpdateUsers(ctx *gin.Context)
	LockUser(ctx *gin.Context)
	UnLockUser(ctx *gin.Context)
	MakeAdmin(ctx *gin.Context)
	BatchCreateUser(ctx *gin.Context)
	UpdateStatus(ctx *gin.Context)
}

func NewUsersControllerGroup(db db.DBLayer) UsersControllerGroup {
	return &usersController{
		db: db,
	}
}

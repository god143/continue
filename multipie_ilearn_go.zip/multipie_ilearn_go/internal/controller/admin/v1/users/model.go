package users

import "multipie_ilearn_go/internal/constants"

type GetUsersRequest struct {
	Page     int64 `form:"page" binding:"gte=0"`
	PageSize int64 `form:"pageSize" binding:"lte=20"`
}

type CreateUsersRequest struct {
	DisplayName     *string `json:"display_name" binding:"required"` // DisplayName of the user
	Username        *string `json:"username" binding:"required"`     // UserName of the user
	FirstName       *string `json:"first_name"`                      // First Name user ID
	LastName        *string `json:"last_name"`                       // Last Name of the user
	Mobile          *string `json:"mobile" binding:"required"`       // Mobile no of the user
	Email           *string `json:"email"`                           // Email of the user
	Uid             *int64  `json:"uid"`
	ViaLogin        *string `json:"via_login"`
	SignInCount     *int64  `json:"sign_in_count"`
	IdirectUsername *string `json:"idirect_username"`
}

type CreateUsersResponse struct {
	ID int64 `json:"id"`
}

type UpdateUsersRequest struct {
	ID              *int64  `json:"id" binding:"required"` // Unique ID for the user
	DisplayName     *string `json:"display_name"`          // DisplayName of the user
	Username        *string `json:"username"`              // UserName of the user
	FirstName       *string `json:"first_name"`            // First Name user ID
	LastName        *string `json:"last_name"`             // Last Name of the user
	Mobile          *string `json:"mobile"`                // Mobile no of the user
	Email           *string `json:"email"`                 // Email of the user
	ViaLogin        *string `json:"via_login"`
	SignInCount     *int64  `json:"sign_in_count"`
	IdirectUsername *string `json:"idirect_username"`
}

type UpdateUsersResponse struct {
	ID int64 `json:"id"`
}

type LockUserRequest struct {
	ID int64 `uri:"user_id" binding:"required"`
}

type LockUserResponse struct {
	ID int64 `json:"id"`
}

type MakeAdminRequest struct {
	ID int64 `uri:"user_id" binding:"required"`
}

type MakeAdminResponse struct {
	ID int64 `json:"id"`
}

type UpdateStatusRequest struct {
	Status *constants.UserStatusEnum `json:"status" binding:"required"`
}

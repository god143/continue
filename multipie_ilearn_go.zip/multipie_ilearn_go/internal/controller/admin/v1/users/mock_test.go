package users

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/users"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- ⚙️ SETUP ---

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- 🛠️ MOCK DB LAYER ---

type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetUsers(ctx context.Context, page int64, pageSize int64) (*utils.Pagination, error) {
	args := m.Called(ctx, page, pageSize)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*utils.Pagination), args.Error(1)
}

func (m *MockDB) CreateUsers(ctx context.Context, user *dbModel.Users) (*dbModel.Users, error) {
	args := m.Called(ctx, user)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Users), args.Error(1)
}

func (m *MockDB) UpdateUsers(ctx context.Context, user dbModel.Users) (*dbModel.Users, error) {
	args := m.Called(ctx, user)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Users), args.Error(1)
}

func (m *MockDB) LockUser(ctx context.Context, userID int64) error {
	return m.Called(ctx, userID).Error(0)
}

func (m *MockDB) MakeAdmin(ctx context.Context, userID int64) error {
	return m.Called(ctx, userID).Error(0)
}

// --- 🧪 TEST SUITE: All Branches ---

func TestUsersController_Comprehensive(t *testing.T) {
	tests := []struct {
		name           string
		method         string
		url            string
		body           interface{}
		params         map[string]string
		setupMock      func(*MockDB)
		expectedStatus int
		callMethod     func(*usersController, *gin.Context)
	}{
		// --- GetUsers Branches ---
		{
			name:   "GetUsers - DB Failure",
			method: "GET", url: "/users",
			setupMock: func(m *MockDB) {
				m.On("GetUsers", mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("fail"))
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.GetUsers(c) },
		},
		// --- CreateUsers Branches ---
		{
			name:   "CreateUsers - Binding Error",
			method: "POST", url: "/users",
			body:           "invalid-json",
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusBadRequest,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.CreateUsers(c) },
		},
		{
			name:   "CreateUsers - DB Error",
			method: "POST", url: "/users",
			body:           CreateUsersRequest{DisplayName: utils.StringToPointer("A"), Username: utils.StringToPointer("B"), Mobile: utils.StringToPointer("1")},
			setupMock:      func(m *MockDB) { m.On("CreateUsers", mock.Anything, mock.Anything).Return(nil, errors.New("fail")) },
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.CreateUsers(c) },
		},
		// --- UpdateUsers Branches ---
		{
			name:   "UpdateUsers - Binding Error",
			method: "PUT", url: "/users",
			body:           "invalid-json",
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusBadRequest,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.UpdateUsers(c) },
		},
		{
			name:   "UpdateUsers - DB Error",
			method: "PUT", url: "/users",
			body:           UpdateUsersRequest{ID: utils.Int64ToPointer(1)},
			setupMock:      func(m *MockDB) { m.On("UpdateUsers", mock.Anything, mock.Anything).Return(nil, errors.New("fail")) },
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.UpdateUsers(c) },
		},
		// --- LockUser Branches ---
		{
			name:   "LockUser - Binding Error",
			method: "POST", url: "/users/lock/abc",
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusBadRequest,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.LockUser(c) },
		},
		{
			name:   "LockUser - DB Error",
			method: "POST", url: "/users/lock/1",
			params:         map[string]string{"user_id": "1"},
			setupMock:      func(m *MockDB) { m.On("LockUser", mock.Anything, int64(1)).Return(errors.New("fail")) },
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.LockUser(c) },
		},
		// --- Success Path Cases ---
		{
			name:   "GetUsers - Success",
			method: "GET", url: "/users?page=1&pageSize=10",
			setupMock: func(m *MockDB) {
				m.On("GetUsers", mock.Anything, int64(1), int64(10)).Return(&utils.Pagination{}, nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.GetUsers(c) },
		},
		{
			name:   "CreateUsers - Success",
			method: "POST", url: "/users",
			body: CreateUsersRequest{
				DisplayName: utils.StringToPointer("John"),
				Username:    utils.StringToPointer("jdoe"),
				Mobile:      utils.StringToPointer("123456"),
			},
			setupMock: func(m *MockDB) {
				m.On("CreateUsers", mock.Anything, mock.Anything).
					Return(&dbModel.Users{ID: utils.Int64ToPointer(101)}, nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.CreateUsers(c) },
		},
		{
			name:   "UpdateUsers - Success",
			method: "PUT", url: "/users",
			body: UpdateUsersRequest{ID: utils.Int64ToPointer(1)},
			setupMock: func(m *MockDB) {
				m.On("UpdateUsers", mock.Anything, mock.Anything).Return(&dbModel.Users{}, nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.UpdateUsers(c) },
		},
		{
			name:   "MakeAdmin - Success",
			method: "POST", url: "/users/admin/1",
			params: map[string]string{"user_id": "1"},
			setupMock: func(m *MockDB) {
				m.On("MakeAdmin", mock.Anything, int64(1)).Return(nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.MakeAdmin(c) },
		},
		{
			name:   "LockUser - Success",
			method: "POST", url: "/users/lock/1",
			params: map[string]string{"user_id": "1"},
			setupMock: func(m *MockDB) {
				m.On("LockUser", mock.Anything, int64(1)).Return(nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.LockUser(c) },
		},
		// --- MakeAdmin DB Error ---
		{
			name:   "MakeAdmin - DB Error",
			method: "POST", url: "/users/admin/1",
			params: map[string]string{"user_id": "1"},
			setupMock: func(m *MockDB) {
				m.On("MakeAdmin", mock.Anything, int64(1)).Return(errors.New("fail"))
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *usersController, c *gin.Context) { ctrl.MakeAdmin(c) },
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockDB)
			ctrl := &usersController{db: mDB}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			jsonBytes, _ := json.Marshal(tt.body)
			c.Request, _ = http.NewRequest(tt.method, tt.url, bytes.NewBuffer(jsonBytes))
			c.Request.Header.Set("Content-Type", "application/json")

			if tt.params != nil {
				var params gin.Params
				for k, v := range tt.params {
					params = append(params, gin.Param{Key: k, Value: v})
				}
				c.Params = params
			}

			tt.setupMock(mDB)
			tt.callMethod(ctrl, c)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- 💡 HELPER TESTS: Complete Coverage ---

func TestUsersHelpers_Full(t *testing.T) {
	mDB := new(MockDB)
	ctrl := &usersController{db: mDB}

	t.Run("updateUsersHelper - Error Branch", func(t *testing.T) {
		mDB.On("UpdateUsers", mock.Anything, mock.Anything).Return(nil, errors.New("fail")).Once()
		err := ctrl.updateUsersHelper(context.Background(), UpdateUsersRequest{ID: utils.Int64ToPointer(1)})
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unable to update")
	})

	t.Run("lockUserHelper - Error Branch", func(t *testing.T) {
		mDB.On("LockUser", mock.Anything, int64(1)).Return(errors.New("fail")).Once()
		err := ctrl.lockUserHelper(context.Background(), LockUserRequest{ID: 1})
		assert.Error(t, err)
	})

}

func BenchmarkUsersController_Helpers(b *testing.B) {
	mDB := new(MockDB)
	ctrl := &usersController{db: mDB}
	ctx := context.Background()

	mDB.On("GetUsers", mock.Anything, mock.Anything, mock.Anything).Return(&utils.Pagination{}, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = ctrl.getUsersHelper(ctx, GetUsersRequest{Page: 1, PageSize: 10})
	}
}

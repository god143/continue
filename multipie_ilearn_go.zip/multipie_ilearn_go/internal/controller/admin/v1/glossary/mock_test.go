package glossary

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/glossary"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// ---  SETUP ---

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// ---  MOCK DB LAYER ---

type MockDB struct {
	mock.Mock
	db.DBLayer
}

// mockFile satisfies the multipart.File interface for testing/benchmarking
type mockFile struct {
	*bytes.Reader
}

func (m *mockFile) Close() error { return nil }

func (m *MockDB) GetGlossaries(ctx context.Context, page, pageSize int64, search string) (*utils.Pagination, error) {
	args := m.Called(ctx, page, pageSize, search)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*utils.Pagination), args.Error(1)
}

func (m *MockDB) GetGlossaryByID(ctx context.Context, id int64) (*dbModel.Glossary, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Glossary), args.Error(1)
}

func (m *MockDB) CreateGlossary(ctx context.Context, glos *dbModel.Glossary) (*dbModel.Glossary, error) {
	args := m.Called(ctx, glos)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Glossary), args.Error(1)
}

func (m *MockDB) UpdateGlossary(ctx context.Context, glos dbModel.Glossary) (*dbModel.Glossary, error) {
	args := m.Called(ctx, glos)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Glossary), args.Error(1)
}

func (m *MockDB) DeleteGlossary(ctx context.Context, id int64) error {
	return m.Called(ctx, id).Error(0)
}

func (m *MockDB) BatchInsertGlossary(ctx context.Context, glossaries []dbModel.Glossary) error {
	return m.Called(ctx, glossaries).Error(0)
}

func (m *MockDB) BatchUpdateGlossary(ctx context.Context, glossaries []dbModel.Glossary) error {
	return m.Called(ctx, glossaries).Error(0)
}

// --- TEST SUITE: Controllers & Helpers ---

func TestNewGlossaryController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	mDB := new(MockDB)
	// Ensure the function name matches your code (e.g., NewGlossaryController)
	ctrl := NewGlossaryControllerGroup(mDB)

	assert.NotNil(t, ctrl)

	t.Run("GetGlossaries_Scenarios", func(t *testing.T) {
		// Update the struct definition here
		tests := []struct {
			name     string
			params   map[string]string // Changed from query string
			setup    func(*MockDB)
			expected int
		}{
			{
				name: "Success_Standard",
				params: map[string]string{
					"page":        "1",
					"page_size":   "10",
					"search_text": "Stock",
				},
				setup: func(m *MockDB) {
					m.On("GetGlossaries", mock.Anything, int64(1), int64(10), "Stock").
						Return(&utils.Pagination{Page: 1}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:   "Success_Empty_Results",
				params: map[string]string{"page": "1", "page_size": "10"},
				setup: func(m *MockDB) {
					m.On("GetGlossaries", mock.Anything, int64(1), int64(10), "").
						Return(&utils.Pagination{}, nil) // Let defaults handle it
				},
				expected: http.StatusOK,
			},
			{
				name: "Edge_Invalid_Regex_Search",
				params: map[string]string{
					"search_text": "Stock@#$%^",
				},
				setup:    func(m *MockDB) {},
				expected: http.StatusInternalServerError,
			},
			{
				name: "WorstCase_DB_Failure",
				params: map[string]string{
					"page":      "1",
					"page_size": "10",
				},
				setup: func(m *MockDB) {
					m.On("GetGlossaries", mock.Anything, int64(1), int64(10), "").
						Return(nil, errors.New("db error"))
				},
				expected: http.StatusInternalServerError,
			},
			// Test for Bind Failure (passing non-numeric page)
			{
				name:     "Fail_Invalid_Page_Type",
				params:   map[string]string{"page": "abc"},
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Fail_Invalid_Page_Type",
				params:   map[string]string{"page": "abc"}, // Triggers 400 for int64
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &glossaryController{db: mDB}

				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				// Use url.Values to safely build the query string
				q := url.Values{}
				for k, v := range tt.params {
					q.Add(k, v)
				}

				// Create the request properly to avoid nil pointer panics
				req, _ := http.NewRequest(http.MethodGet, "/?"+q.Encode(), nil)
				c.Request = req

				tt.setup(mDB)
				ctrl.GetGlossaries(c)

				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})
}

func TestGlossaryController_Comprehensive(t *testing.T) {
	tests := []struct {
		name           string
		method         string
		url            string
		body           interface{}
		params         map[string]string
		setupMock      func(*MockDB)
		expectedStatus int
		callMethod     func(*glossaryController, *gin.Context)
	}{
		{
			name:   "GetGlossaries - Regex Validation Fail",
			method: "GET", url: "/glossary?search_text=invalid@chars!",
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.GetGlossaries(c) },
		},
		{
			name:   "GetGlossaryByID - Success",
			method: "GET", url: "/glossary/1",
			params: map[string]string{"id": "1"},
			setupMock: func(m *MockDB) {
				m.On("GetGlossaryByID", mock.Anything, int64(1)).Return(&dbModel.Glossary{}, nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.GetGlossaryByID(c) },
		},
		{
			name:   "UpdateGlossary - Success",
			method: "PUT", url: "/glossary",
			body: UpdateGlossaryRequest{ID: 1, Key: utils.StringToPointer("K"), Value: utils.StringToPointer("V")},
			setupMock: func(m *MockDB) {
				m.On("UpdateGlossary", mock.Anything, mock.Anything).Return(&dbModel.Glossary{}, nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.UpdateGlossary(c) },
		},
		{
			name:   "DeleteGlossary - Success",
			method: "DELETE", url: "/glossary",
			body: DeleteGlossaryRequest{ID: 1},
			setupMock: func(m *MockDB) {
				m.On("DeleteGlossary", mock.Anything, int64(1)).Return(nil)
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.DeleteGlossary(c) },
		},

		{
			name:   "CreateGlossary - Binding Error",
			method: "POST", url: "/glossary",
			body:           "invalid-json", // Triggers ShouldBind error
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusBadRequest,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.CreateGlossary(c) },
		},
		{
			name:   "CreateGlossary - DB Error Branch",
			method: "POST", url: "/glossary",
			body: CreateGlossaryRequest{Key: utils.StringToPointer("K"), Value: utils.StringToPointer("V")},
			setupMock: func(m *MockDB) {
				m.On("CreateGlossary", mock.Anything, mock.Anything).
					Return(nil, errors.New("insertion failed")).Once()
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.CreateGlossary(c) },
		},

		// Add these to cover the 500 error branches in Controllers
		{
			name:   "UpdateGlossary - DB Error Branch",
			method: "PUT", url: "/glossary",
			body: UpdateGlossaryRequest{ID: 1, Key: utils.StringToPointer("K"), Value: utils.StringToPointer("V")},
			setupMock: func(m *MockDB) {
				m.On("UpdateGlossary", mock.Anything, mock.Anything).Return(nil, errors.New("db error")).Once()
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.UpdateGlossary(c) },
		},
		{
			name:   "BatchInsert - DB Error Branch",
			method: "POST", url: "/batch",
			setupMock: func(m *MockDB) {
				m.On("BatchInsertGlossary", mock.Anything, mock.Anything).Return(errors.New("db error")).Once()
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod: func(ctrl *glossaryController, c *gin.Context) {
				body := &bytes.Buffer{}
				mw := multipart.NewWriter(body)
				part, _ := mw.CreateFormFile("file", "test.csv")
				part.Write([]byte("key,value\nk,v"))
				mw.Close()
				c.Request, _ = http.NewRequest("POST", "/", body)
				c.Request.Header.Set("Content-Type", mw.FormDataContentType())
				ctrl.BatchInsertGlossary(c)
			},
		},

		{
			name:   "DeleteGlossary - Success",
			method: "DELETE", url: "/glossary",
			body: DeleteGlossaryRequest{ID: 1},
			setupMock: func(m *MockDB) {
				m.On("DeleteGlossary", mock.Anything, int64(1)).Return(nil).Once()
			},
			expectedStatus: http.StatusOK,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.DeleteGlossary(c) },
		},
		{
			name:   "BatchUpdate - Helper Success",
			method: "POST", url: "/batch-update",
			setupMock: func(m *MockDB) {
				m.On("BatchUpdateGlossary", mock.Anything, mock.Anything).Return(nil).Once()
			},
			expectedStatus: http.StatusOK,
			callMethod: func(ctrl *glossaryController, c *gin.Context) {
				body := &bytes.Buffer{}
				mw := multipart.NewWriter(body)
				part, _ := mw.CreateFormFile("file", "update.csv")
				part.Write([]byte("id,key,value\n10,k,v"))
				mw.Close()

				c.Request, _ = http.NewRequest("POST", "/", body)
				c.Request.Header.Set("Content-Type", mw.FormDataContentType())
				ctrl.BatchUpdateGlossaries(c)
			},
		},

		// --- DB Error Branches (Critical for 90%+) ---
		{
			name:   "GetGlossaryByID - DB Failure",
			method: "GET", url: "/glossary/1",
			params: map[string]string{"id": "1"},
			setupMock: func(m *MockDB) {
				m.On("GetGlossaryByID", mock.Anything, int64(1)).Return(nil, errors.New("fail"))
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.GetGlossaryByID(c) },
		},
		{
			name:   "DeleteGlossary - DB Failure",
			method: "DELETE", url: "/glossary",
			body: DeleteGlossaryRequest{ID: 1},
			setupMock: func(m *MockDB) {
				m.On("DeleteGlossary", mock.Anything, int64(1)).Return(errors.New("fail"))
			},
			expectedStatus: http.StatusInternalServerError,
			callMethod:     func(ctrl *glossaryController, c *gin.Context) { ctrl.DeleteGlossary(c) },
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockDB)
			ctrl := &glossaryController{db: mDB}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			jsonBytes, _ := json.Marshal(tt.body)
			c.Request, _ = http.NewRequest(tt.method, tt.url, bytes.NewBuffer(jsonBytes))
			c.Request.Header.Set("Content-Type", "application/json")

			if tt.params != nil {
				var params gin.Params
				for k, v := range tt.params {
					params = append(params, gin.Param{Key: k, Value: v})
				}
				c.Params = params
			}

			tt.setupMock(mDB)
			tt.callMethod(ctrl, c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- BATCH & FILE TESTS ---

func TestGlossary_BatchOperations(t *testing.T) {
	mDB := new(MockDB)
	ctrl := &glossaryController{db: mDB}

	t.Run("BatchInsert - CSV Success", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Create Mock CSV
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		part.Write([]byte("key,value\nhello,world\nfoo,bar"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/batch", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		mDB.On("BatchInsertGlossary", mock.Anything, mock.Anything).Return(nil).Once()

		ctrl.BatchInsertGlossary(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("getGlossariesHelper - Empty Search Text", func(t *testing.T) {
		mDB.On("GetGlossaries", mock.Anything, int64(0), int64(10), "").
			Return(&utils.Pagination{}, nil).Once()

		_, err := ctrl.getGlossariesHelper(context.Background(), GetGlossariesRequest{PageSize: 10, SearchText: ""})
		assert.NoError(t, err)
	})
	t.Run("batchInsertGlossaryHelper - Full 100 Batch Flush", func(t *testing.T) {
		// 101 records: 1 header + 100 records
		csvContent := "key,value\n"
		for i := 0; i < 100; i++ {
			csvContent += "k,v\n"
		}
		mFile := &mockFile{Reader: bytes.NewReader([]byte(csvContent))}

		// This will trigger the 'if len(glossaries) == 100' block
		mDB.On("BatchInsertGlossary", mock.Anything, mock.MatchedBy(func(cols []dbModel.Glossary) bool {
			return len(cols) == 100
		})).Return(nil).Once()

		err := ctrl.batchInsertGlossaryHelper(context.Background(), mFile)
		assert.NoError(t, err)
	})
	t.Run("batchUpdateGlossariesHelper - Extraction Failure", func(t *testing.T) {
		csvContent := "id,key,value\n1,KeyOnly,\n"
		mFile := &mockFile{Reader: bytes.NewReader([]byte(csvContent))}

		err := ctrl.batchUpdateGlossariesHelper(context.Background(), mFile)
		assert.Error(t, err)
		// Update this line to match the actual returned string format
		assert.Contains(t, err.Error(), "value of value field cannot be blank")
	})
	t.Run("getGlossariesHelper - Successful Regex and Search", func(t *testing.T) {
		mDB.On("GetGlossaries", mock.Anything, int64(1), int64(10), "ValidSearch123").
			Return(&utils.Pagination{}, nil).Once()

		res, err := ctrl.getGlossariesHelper(context.Background(), GetGlossariesRequest{
			Page: 1, PageSize: 10, SearchText: "ValidSearch123",
		})
		assert.NoError(t, err)
		assert.NotNil(t, res)
	})
	t.Run("BatchInsert - 101 Rows Coverage", func(t *testing.T) {
		// 1 header + 101 rows
		var csvContent strings.Builder
		csvContent.WriteString("key,value\n")
		for i := 0; i < 101; i++ {
			csvContent.WriteString(fmt.Sprintf("key%d,val%d\n", i, i))
		}

		mFile := &mockFile{Reader: bytes.NewReader([]byte(csvContent.String()))}

		// Expecting 2 calls: one for the 100-batch, one for the final 1 row
		mDB.On("BatchInsertGlossary", mock.Anything, mock.MatchedBy(func(g []dbModel.Glossary) bool {
			return len(g) == 100
		})).Return(nil).Once()

		mDB.On("BatchInsertGlossary", mock.Anything, mock.MatchedBy(func(g []dbModel.Glossary) bool {
			return len(g) == 1
		})).Return(nil).Once()

		err := ctrl.batchInsertGlossaryHelper(context.Background(), mFile)
		assert.NoError(t, err)
	})

	t.Run("BatchUpdate - Success Full", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "update.csv")
		// ID, Key, Value
		part.Write([]byte("id,key,value\n10,NewKey,NewVal"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		mDB.On("BatchUpdateGlossary", mock.Anything, mock.Anything).Return(nil).Once()

		ctrl.BatchUpdateGlossaries(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("getGlossaryByIDHelper - DB Error", func(t *testing.T) {
		mDB.On("GetGlossaryByID", mock.Anything, int64(404)).Return(nil, errors.New("not found")).Once()
		_, err := ctrl.getGlossaryByIDHelper(context.Background(), GetGlossaryByIDRequest{ID: 404})
		assert.Error(t, err)
		assert.Equal(t, "unable to fetch glossary from db", err.Error())
	})

	t.Run("BatchInsert - CSV Read Error", func(t *testing.T) {
		// Providing a reader that fails mid-way covers the "unable to read csv" line
		mFile := &mockFile{Reader: bytes.NewReader([]byte("key,value\n\"unclosed quote"))}
		err := ctrl.batchInsertGlossaryHelper(context.Background(), mFile)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unable to read csv record")
	})

	t.Run("BatchUpdate - CSV Error (Invalid ID)", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		part.Write([]byte("id,key,value\nnot-an-int,k,v"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/batch-update", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.BatchUpdateGlossaries(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("BatchUpdate - CSV Success", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "test.csv")
		part.Write([]byte("id,key,value\n1,Hello,World"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/batch-update", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		mDB.On("BatchUpdateGlossary", mock.Anything, mock.Anything).Return(nil).Once()

		ctrl.BatchUpdateGlossaries(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("BatchInsert - Trigger 100 Row Batch", func(t *testing.T) {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Generate 101 rows (Header + 101 data rows) to trigger the batch flush
		csvData := "key,value\n"
		for i := 0; i < 101; i++ {
			csvData += "key,value\n"
		}

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		part, _ := writer.CreateFormFile("file", "large.csv")
		part.Write([]byte(csvData))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		// Expecting 2 calls: one for the 100-count batch, one for the final 1-count batch
		mDB.On("BatchInsertGlossary", mock.Anything, mock.Anything).Return(nil).Twice()

		ctrl.BatchInsertGlossary(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("batchUpdate - Final Batch Failure", func(t *testing.T) {
		// Single row to trigger the "Final batch" error path
		content := []byte("id,key,value\n1,k,v")
		mFile := &mockFile{Reader: bytes.NewReader(content)}

		mDB.On("BatchUpdateGlossary", mock.Anything, mock.Anything).
			Return(errors.New("final failure")).Once()

		err := ctrl.batchUpdateGlossariesHelper(context.Background(), mFile)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "batch updation failed for final batch")
	})

	t.Run("updateGlossaryHelper - DB Fail", func(t *testing.T) {
		mDB.On("UpdateGlossary", mock.Anything, mock.Anything).
			Return(nil, errors.New("fail")).Once()

		err := ctrl.updateGlossaryHelper(context.Background(), UpdateGlossaryRequest{ID: 1})
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unable to update glossary")
	})

	t.Run("BatchInsert - DB Error Branch", func(t *testing.T) {
		mDB.On("BatchInsertGlossary", mock.Anything, mock.Anything).Return(errors.New("db fail")).Once()
		content := []byte("key,value\nk1,v1")
		mFile := &mockFile{Reader: bytes.NewReader(content)}

		err := ctrl.batchInsertGlossaryHelper(context.Background(), mFile)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "batch insertion failed")
	})

	t.Run("ExtractData - Blank Value Error", func(t *testing.T) {
		_, err := ctrl.extractDataFromFile([]string{"Key", ""})
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "value field cannot be blank")
	})
	t.Run("BatchInsert - 101 Rows Flush Logic", func(t *testing.T) {
		csvData := "key,value\n"
		for i := 0; i < 101; i++ {
			csvData += "k,v\n"
		}
		mFile := &mockFile{Reader: bytes.NewReader([]byte(csvData))}

		// Expecting 2 calls: one for the 100-batch, one for the remaining 1
		mDB.On("BatchInsertGlossary", mock.Anything, mock.Anything).Return(nil).Twice()

		err := ctrl.batchInsertGlossaryHelper(context.Background(), mFile)
		assert.NoError(t, err)
	})

}

// ---HELPER LOGIC TESTS ---

func TestGlossaryHelpers_EdgeCases(t *testing.T) {
	mDB := new(MockDB)
	ctrl := &glossaryController{db: mDB}

	t.Run("ExtractDataFromFile - Blank Key Error", func(t *testing.T) {
		_, err := ctrl.extractDataFromFile([]string{"", "value"})
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot be blank")
	})

	t.Run("getGlossariesHelper - Regex Success", func(t *testing.T) {
		mDB.On("GetGlossaries", mock.Anything, mock.Anything, mock.Anything, "valid search").
			Return(&utils.Pagination{}, nil).Once()

		_, err := ctrl.getGlossariesHelper(context.Background(), GetGlossariesRequest{SearchText: "valid search"})
		assert.NoError(t, err)
	})
}

// ---BENCHMARK ---

func BenchmarkBatchInsertHelper(b *testing.B) {
	mDB := new(MockDB)
	ctrl := &glossaryController{db: mDB}
	mDB.On("BatchInsertGlossary", mock.Anything, mock.Anything).Return(nil)

	// CSV content with header and one data row
	content := []byte("key,value\nk1,v1")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		// Use the mockFile struct to satisfy the multipart.File interface
		mFile := &mockFile{Reader: bytes.NewReader(content)}
		_ = ctrl.batchInsertGlossaryHelper(context.Background(), mFile)
	}
}

package glossary

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/glossary"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"regexp"
	"strconv"
	"strings"

	"go.uber.org/zap"
)

func (c *glossaryController) getGlossariesHelper(ctx context.Context, request GetGlossariesRequest) (*utils.Pagination, error) {

	searchText := strings.TrimSpace(request.SearchText)
	if len(searchText) != 0 {
		var validSearchText = regexp.MustCompile(`^[a-zA-Z0-9 ]+$`)

		if !validSearchText.MatchString(searchText) {
			logger.Error(ctx, "Invalid search text: contains special characters", zap.String("searchText", request.SearchText))
			return nil, errors.New("invalid search text: contains special characters are not allowed")
		}
	}

	glossaryResult, err := c.db.GetGlossaries(ctx, request.Page, request.PageSize, request.SearchText)

	if err != nil {
		logger.Error(ctx, "unable to fetch glossaries from db", zap.Error(err))
		return nil, errors.New("unable to fetch glossaries from db")
	}

	return glossaryResult, nil
}

func (c *glossaryController) getGlossaryByIDHelper(ctx context.Context, request GetGlossaryByIDRequest) (*dbModel.Glossary, error) {

	glossary, err := c.db.GetGlossaryByID(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to fetch glossary from db", zap.Error(err))
		return nil, errors.New("unable to fetch glossary from db")
	}

	return glossary, nil
}

func (c *glossaryController) createGlossaryHelper(ctx context.Context, request CreateGlossaryRequest) (*dbModel.Glossary, error) {

	Glossary := &dbModel.Glossary{
		Key:   request.Key,
		Value: request.Value,
	}

	_, err := c.db.CreateGlossary(ctx, Glossary)
	if err != nil {
		logger.Error(ctx, "unable to create glossary entry in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to create glossary entry in database")
	}
	return Glossary, nil
}

func (c *glossaryController) updateGlossaryHelper(ctx context.Context, request UpdateGlossaryRequest) error {

	Glossary := dbModel.Glossary{
		ID:    &request.ID,
		Key:   request.Key,
		Value: request.Value,
	}

	_, err := c.db.UpdateGlossary(ctx, Glossary)
	if err != nil {
		logger.Error(ctx, "unable to update glossary entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update glossary entry in database")
	}

	return nil
}

func (c *glossaryController) deleteGlossaryHelper(ctx context.Context, request DeleteGlossaryRequest) error {

	err := c.db.DeleteGlossary(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to delete glossary in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete glossary entry in database")
	}

	return nil
}

func (q *glossaryController) batchInsertGlossaryHelper(ctx context.Context, file multipart.File) error {

	var (
		rowCount   int
		batchNo    int
		glossaries []dbModel.Glossary
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) != 2 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		glossary, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		glossaries = append(glossaries, glossary)
		if len(glossaries) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchInsertGlossary(ctx, glossaries); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			glossaries = []dbModel.Glossary{} // Reset the list
		}
	}

	if len(glossaries) > 0 {
		batchNo++
		if err := q.db.BatchInsertGlossary(ctx, glossaries); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
			return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
		}
		logger.Debug(ctx, fmt.Sprintf("Final batch %d successfully", batchNo))
	}

	return nil
}

func (q *glossaryController) extractDataFromFile(row []string) (dbModel.Glossary, error) {
	var glossary dbModel.Glossary

	//validate key
	key := strings.TrimSpace(row[0])
	if len(key) == 0 {
		return glossary, fmt.Errorf("value of key field cannot be blank")
	}

	glossary.Key = &key

	//validate value
	value := strings.TrimSpace(row[1])
	if len(value) == 0 {
		return glossary, fmt.Errorf("value of value field cannot be blank")
	}

	glossary.Value = &value

	return glossary, nil

}

func (q *glossaryController) batchUpdateGlossariesHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount   int
		batchNo    int
		glossaries []dbModel.Glossary
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) != 3 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		//extract ID
		id, err := strconv.Atoi(strings.TrimSpace(row[0]))
		if err != nil {
			return errors.New("invalid value for id column")
		}

		// Extract data from CSV row
		glossary, err := q.extractDataFromFile(row[1:])
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		glossary.ID = utils.Int64ToPointer(int64(id))

		glossaries = append(glossaries, glossary)
		if len(glossaries) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchUpdateGlossary(ctx, glossaries); err != nil {
				logger.Error(ctx, "batch updation failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch updation failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			glossaries = []dbModel.Glossary{} // Reset the list
		}
	}

	// update remaining glossary if any
	if len(glossaries) > 0 {
		if err := q.db.BatchUpdateGlossary(ctx, glossaries); err != nil {
			logger.Error(ctx, "batch updation failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch updation failed for final batch")
		}
	}
	return nil
}

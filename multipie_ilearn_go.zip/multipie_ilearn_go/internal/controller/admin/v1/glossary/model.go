package glossary

type GetGlossariesRequest struct {
	Page       int64  `form:"page" binding:"gte=0"`
	PageSize   int64  `form:"page_size" binding:"lte=20"`
	SearchText string `form:"search_text" `
}

type GetAllGlossariesRequest struct {
	Page     int64 `form:"page" binding:"gte=0"`
	PageSize int64 `form:"page_size" binding:"lte=20"`
}

type GetGlossaryByIDRequest struct {
	ID int64 `uri:"id" binding:"required" `
}

type CreateGlossaryRequest struct {
	Key   *string `json:"key" binding:"required"`
	Value *string `json:"value" binding:"required"`
}

type CreateGlossaryResponse struct {
	ID int64 `json:"id"`
}

type UpdateGlossaryRequest struct {
	ID    int64   `json:"id" binding:"required" `
	Key   *string `json:"key" binding:"required"`
	Value *string `json:"value" binding:"required"`
}

type DeleteGlossaryRequest struct {
	ID int64 `json:"id" binding:"required"`
}

package likes

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type likesController struct {
	db db.DBLayer
}

type LikesControllerGroup interface {
	BatchCreateLike(ctx *gin.Context)
}

func NewLikesControllerGroup(db db.DBLayer) LikesControllerGroup {
	return &likesController{
		db: db,
	}
}

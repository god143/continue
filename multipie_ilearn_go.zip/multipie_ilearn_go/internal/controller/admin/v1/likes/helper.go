package likes

import (
	"context"
	"encoding/csv"
	"fmt"
	"io"
	"mime/multipart"
	dbModel "multipie_ilearn_go/internal/db/likes"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (q *likesController) batchCreateLikesHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount int
		batchNo  int
		likes    []dbModel.Like
	)

	// Read CSV
	reader := csv.NewReader(file)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}

		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		rowCount++ // Increment row count

		if rowCount == 1 {
			continue // Skip header row
		}
		if len(row) < 5 || len(row) > 6 {
			logger.Error(ctx, "not enough columns in the row", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("not enough columns in the row, rowNum: %v", rowCount)
		}

		// Extract data from CSV row
		like, err := q.extractDataFromFile(row)
		if err != nil {
			logger.Error(ctx, "error occurred while extracting data", zap.Error(err), zap.Any("rowNum", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}
		// quiz.Visible = utils.BoolToPointer(true)

		likes = append(likes, like)
		if len(likes) == 100 {
			batchNo++ // Increment batch number
			if err := q.db.BatchCreateLikes(ctx, likes); err != nil {
				logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo))
				return fmt.Errorf("batch insertion failed for batch, batchNo: %v", batchNo)
			}
			logger.Debug(ctx, fmt.Sprintf("Batch %d successfully inserted", batchNo))
			likes = []dbModel.Like{} // Reset the list
		}
	}

	// Insert remaining infographics if any
	if len(likes) > 0 {
		if err := q.db.BatchCreateLikes(ctx, likes); err != nil {
			logger.Error(ctx, "batch insertion failed", zap.Error(err), zap.Any("batchNo", batchNo+1))
			return fmt.Errorf("batch insertion failed for final batch")
		}
	}

	return nil
}

func (c *likesController) extractDataFromFile(row []string) (dbModel.Like, error) {
	var (
		like dbModel.Like
	)

	switch {
	case len(row) == 5:
		userIdStr := strings.TrimSpace(row[0])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			like.UserID = int64(*utils.IntToPointer(userId))
		}

		modelIdStr := strings.TrimSpace(row[1])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}

			like.ModelID = int64(*utils.IntToPointer(modelId))
		}

		//validate model type
		modelType := strings.TrimSpace(row[2])
		if len(modelType) == 0 {
			return like, fmt.Errorf("value for model type cannot be blank")
		}
		like.ModelType = modelType

		createdAtStr := strings.TrimSpace(row[3])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			like.CreatedAt = createdAt
		}

		updatedAtStr := strings.TrimSpace(row[4])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			like.UpdatedAt = updatedAt
		}

		return like, nil

	case len(row) == 6:

		id, err := strconv.Atoi(row[0])
		if err != nil {
			return like, fmt.Errorf("failed to convert into integer: %v", err)
		}
		like.ID = (int64(id))

		userIdStr := strings.TrimSpace(row[1])
		if len(userIdStr) != 0 {
			userId, err := strconv.Atoi(userIdStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for  userId, error: %v", err)
			}

			like.UserID = int64(*utils.IntToPointer(userId))
		}

		modelIdStr := strings.TrimSpace(row[2])
		if len(modelIdStr) != 0 {
			modelId, err := strconv.Atoi(modelIdStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for  modelId, error: %v", err)
			}

			like.ModelID = int64(*utils.IntToPointer(modelId))
		}

		//validate model type
		modelType := strings.TrimSpace(row[3])
		if len(modelType) == 0 {
			return like, fmt.Errorf("value for modeltype  cannot be blank")
		}
		like.ModelType = modelType

		createdAtStr := strings.TrimSpace(row[4])
		if len(createdAtStr) != 0 {
			createdAt, err := time.Parse("2006-01-02 15:04:05", createdAtStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			like.CreatedAt = createdAt
		}

		updatedAtStr := strings.TrimSpace(row[5])
		if len(updatedAtStr) != 0 {
			updatedAt, err := time.Parse("2006-01-02 15:04:05", updatedAtStr)
			if err != nil {
				return like, fmt.Errorf("invalid value for updatedAt column,error: %v", err)
			}
			like.UpdatedAt = updatedAt
		}

		return like, nil

	default:
		fmt.Printf("invalid number of row")
	}

	return like, nil

}

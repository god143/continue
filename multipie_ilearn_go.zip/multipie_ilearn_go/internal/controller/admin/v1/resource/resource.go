package resource

import (
	dbModel "multipie_ilearn_go/internal/db/resource"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"

	"go.uber.org/zap"
)

func (r *resourceController) GetResourceById(ctx *gin.Context) {
	var (
		resp                *utils.Response
		getResourceByIdResp *dbModel.Resource
		request             GetResourceByIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getResourceByIdResp, err = r.getResourceByIdHelper(ctx, request.ID, utils.BoolToPointer(true), &uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getResourceByIdResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (r *resourceController) GetResourcesByCategoryType(ctx *gin.Context) {
	var (
		resp             *utils.Response
		getResourcesResp []dbModel.GetResourceByCategory
		request          GetResourcesByCategoryTypeRequest
		pagination       utils.Pagination
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "Failed to bind query parameters", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid query parameters"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	pagination.Page = request.Page
	pagination.PageSize = request.PageSize

	getResourcesResp, err = r.getResourcesByCategoryTypeHelper(ctx, request.CategoryID, request.ResourceType, request.SubType, nil, nil, pagination, request.Filter, &uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getResourcesResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (r *resourceController) DisableResource(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DisableResourceRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := r.disableResourceHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("resource disabled successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (r *resourceController) CreateResource(ctx *gin.Context) {
	var (
		resp     *utils.Response
		request  CreateResourceRequest
		response CreateResourceResponse
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	resource, err := r.createResourceHelper(ctx, request)
	if err != nil {

		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response = CreateResourceResponse{
		ID: int64(*resource.ID),
	}
	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (r *resourceController) UpdateResource(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateResourceRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body "))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := r.updateResourceHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("resource updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (r *resourceController) BatchCreateResources(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = r.batchCreateResourceHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch creation of resource is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}


func (r *resourceController) BatchUpdateResources(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		logger.Error(ctx, "failed to get file from request", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to get file from request"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	defer file.Close()

	err = r.batchUpdateResourceHelper(ctx, file)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("batch updation of resource is successful", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *resourceController) ResourceAssetUpload(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request AssetUploadRequest
	)
	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err), zap.Any("requestBody", request))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	assetUploadResponse, err := c.assetUploadHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(assetUploadResponse, nil)
	ctx.JSON(http.StatusOK, resp)
}

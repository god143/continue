package resource

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModelBookmark "multipie_ilearn_go/internal/db/bookmark"
	dbModel "multipie_ilearn_go/internal/db/resource"

	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mocks ---
type MockResourceRepo struct {
	mock.Mock
	db.DBLayer
}

func (m *MockResourceRepo) GetResourceById(ctx context.Context, id int, vis *bool) (*dbModel.Resource, error) {
	args := m.Called(ctx, id, vis)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Resource), args.Error(1)
}

func (m *MockResourceRepo) GetResourcesByCategoryAndType(ctx context.Context, catID int, rt constants.ResourceTypeEnum, st constants.SubTypeEnum, vis, sh *bool, pag utils.Pagination, ft constants.FilterTypeEnum) ([]dbModel.GetResourceByCategory, error) {
	args := m.Called(ctx, catID, rt, st, vis, sh, pag, ft)
	return args.Get(0).([]dbModel.GetResourceByCategory), args.Error(1)
}

func (m *MockResourceRepo) BatchCreateResources(ctx context.Context, res []dbModel.BatchCreateResource) error {
	return m.Called(ctx, res).Error(0)
}

func (m *MockResourceRepo) BatchUpdateResources(ctx context.Context, res []dbModel.Resource) error {
	return m.Called(ctx, res).Error(0)
}

func (m *MockResourceRepo) CreateResource(ctx context.Context, res *dbModel.Resource) (*dbModel.Resource, error) {
	args := m.Called(ctx, res)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Resource), args.Error(1)
}

func (m *MockResourceRepo) UpdateResource(ctx context.Context, res dbModel.Resource) (*dbModel.Resource, error) {
	args := m.Called(ctx, res)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Resource), args.Error(1)
}

func (m *MockResourceRepo) DisableResource(ctx context.Context, id int) error {
	return m.Called(ctx, id).Error(0)
}

func (m *MockResourceRepo) GetBookmarkByCustomParams(ctx context.Context, ids []int, rts []string, sts []string, uid int64) ([]dbModelBookmark.Bookmark, error) {
	args := m.Called(ctx, ids, rts, sts, uid)
	if args.Get(0) == nil {
		return nil, args.Error(1) // This allows returning (nil, error)
	}
	return args.Get(0).([]dbModelBookmark.Bookmark), args.Error(1)
}
func (m *MockResourceRepo) GetParentCaregorybyResourceId(ctx context.Context, id int64) (*[]string, error) {
	args := m.Called(ctx, id)

	// Safety check for nil returns
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*[]string), args.Error(1)
}

// --- Setup ---
func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

func ptrResType(v constants.ResourceTypeEnum) *constants.ResourceTypeEnum { return &v }
func ptrSubType(v constants.SubTypeEnum) *constants.SubTypeEnum           { return &v }

func ptrSliceString(v []string) *[]string { return &v }
func ptr[T any](v T) *T                   { return &v }

func createCSVPart(content string) (*bytes.Buffer, string) {
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, _ := writer.CreateFormFile("file", "test.csv")
	part.Write([]byte(content))
	writer.Close()
	return body, writer.FormDataContentType()
}

// --- Test Cases ---

func TestResourceController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	t.Run("GetResourceById_Tests", func(t *testing.T) {
		tests := []struct {
			name           string
			uriID          string
			userID         interface{}
			setupMock      func(*MockResourceRepo)
			expectedStatus int
		}{
			{
				name:   "Success_Full_Flow",
				uriID:  "10",
				userID: int64(12345),
				setupMock: func(m *MockResourceRepo) {
					id := 10
					res := &dbModel.Resource{
						ID:   &id,
						Type: ptrResType(constants.ResourceTypeEnumVideo),
					}

					m.On("GetResourceById", mock.Anything, 10, mock.Anything).Return(res, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, []int{10}, []string{"video"}, mock.Anything, int64(12345)).Return([]dbModelBookmark.Bookmark{}, nil)

					// Return a pointer to a slice
					mockTags := []string{"stock", "finance"}
					m.On("GetParentCaregorybyResourceId", mock.Anything, int64(10)).
						Return(&mockTags, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:   "WorstCase_GetResourceById_DB_Failure",
				uriID:  "99",
				userID: int64(123),
				setupMock: func(m *MockResourceRepo) {
					m.On("GetResourceById", mock.Anything, 99, mock.Anything).
						Return(nil, errors.New("simulated database connection error"))
					// Do not mock anything else, as the controller should return early
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:   "Edge_DB_Bookmark_Failure",
				uriID:  "30",
				userID: int64(123),
				setupMock: func(m *MockResourceRepo) {
					id := 30
					m.On("GetResourceById", mock.Anything, 30, mock.Anything).
						Return(&dbModel.Resource{ID: &id, Type: ptrResType(constants.ResourceTypeEnumVideo)}, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("bookmark service down"))
					// Do not mock GetTagKeysByModel, as it's called after bookmark logic in the controller
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:           "Edge_Invalid_ID_Format",
				uriID:          "not_number",
				userID:         int64(123),
				setupMock:      func(m *MockResourceRepo) {},
				expectedStatus: http.StatusBadRequest,
			},
			{
				name:           "Edge_Unauthorized_User",
				uriID:          "10",
				userID:         nil, // Missing user_id in context
				setupMock:      func(m *MockResourceRepo) {},
				expectedStatus: http.StatusUnauthorized,
			},

			{
				name:           "Edge_Unauthorized_Wrong_Type",
				uriID:          "10",
				userID:         "string_instead_of_int64",
				setupMock:      func(m *MockResourceRepo) {},
				expectedStatus: http.StatusUnauthorized,
			},
			{
				name:   "Success_With_Empty_Tags",
				uriID:  "40",
				userID: int64(123),
				setupMock: func(m *MockResourceRepo) {
					id := 40
					// 1. Mock Resource Fetch
					m.On("GetResourceById", mock.Anything, 40, mock.Anything).
						Return(&dbModel.Resource{ID: &id, Type: ptrResType(constants.ResourceTypeEnumVideo)}, nil)

					// 2. Mock Bookmark Fetch
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelBookmark.Bookmark{}, nil)

					// 3. FIX: You MUST add this call because line 44 in your controller requires it
					// We return an empty slice to satisfy the "Empty Tags" test name
					emptyTags := []string{}
					m.On("GetParentCaregorybyResourceId", mock.Anything, int64(40)).
						Return(&emptyTags, nil)

					// 4. Existing Mock (If your controller calls this later)
					m.On("GetTagKeysByModel", mock.Anything, int64(40)).
						Return(ptrSliceString([]string{}), nil)
				},
				expectedStatus: http.StatusOK,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {

				mDB := new(MockResourceRepo)
				ctrl := &resourceController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Params = []gin.Param{{Key: "resource_id", Value: tt.uriID}}
				if tt.userID != nil {
					c.Set("userId", tt.userID)
				}

				tt.setupMock(mDB)
				ctrl.GetResourceById(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})

}

func TestAdminResourceController_CreateResource(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		inputBody      interface{}
		setupMock      func(*MockResourceRepo)
		expectedStatus int
	}{
		{
			name: "Success_Create_Video",
			inputBody: CreateResourceRequest{
				Name:    utils.StringToPointer("Test Video"),
				Type:    ptrResType(constants.ResourceTypeEnumVideo),
				SubType: ptrSubType(constants.SubTypeEnumExpert),
				URL:     utils.StringToPointer("http://video.com"),
			},
			setupMock: func(m *MockResourceRepo) {
				id := 100
				m.On("CreateResource", mock.Anything, mock.MatchedBy(func(r *dbModel.Resource) bool {
					return *r.Name == "Test Video"
				})).Return(&dbModel.Resource{ID: &id}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Edge_Missing_SubType_For_Video",
			inputBody: CreateResourceRequest{
				Name: utils.StringToPointer("Fail Video"),
				Type: ptrResType(constants.ResourceTypeEnumVideo),
				// SubType is missing/nil, triggering validation error
			},
			setupMock:      func(m *MockResourceRepo) {},
			expectedStatus: http.StatusBadRequest, // Changed from 500 to 400
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			m := new(MockResourceRepo)
			tc.setupMock(m)
			ctrl := &resourceController{db: m}

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			body, _ := json.Marshal(tc.inputBody)
			c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))
			c.Request.Header.Set("Content-Type", "application/json")

			ctrl.CreateResource(c)
			assert.Equal(t, tc.expectedStatus, w.Code)
		})
	}
}

func TestAdminResourceController_BatchCreateResources(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		csvContent     string
		inputBody      interface{} // For POST/JSON requests
		setupMock      func(*MockResourceRepo)
		expectedStatus int
	}{
		{
			name: "Success_15_Columns",
			csvContent: "Header1,Header2,Header3,Header4,Header5,Header6,Header7,Header8,Header9,Header10,Header11,Header12,Header13,Header14,Header15\n" +
				"url,dark,video,name,desc,1,2,icon,10,true,true,{},content,expert,2023-01-01 10:00:00",
			setupMock: func(m *MockResourceRepo) {
				m.On("BatchCreateResources", mock.Anything, mock.Anything).Return(nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Fail_Invalid_Column_Count",
			csvContent: "Header1,Header2\n" +
				"val1,val2",
			setupMock:      func(m *MockResourceRepo) {},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name: "Fail_Invalid_Date_Format",
			csvContent: "H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,H14,H15\n" +
				"u,d,video,n,desc,1,1,i,0,t,t,{},c,expert,01-01-2023", // Wrong format
			setupMock:      func(m *MockResourceRepo) {},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:      "DisableResource_Success",
			inputBody: DisableResourceRequest{ID: 5},
			setupMock: func(m *MockResourceRepo) {
				m.On("DisableResource", mock.Anything, 5).Return(nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "GetResources_Video_With_SubType_Success",
			// Query params: ?category_id=1&resource_type=video&sub_type=primary&page=1&page_size=10
			setupMock: func(m *MockResourceRepo) {
				m.On("GetResourcesByCategoryAndType", mock.Anything, 1, constants.ResourceTypeEnumVideo, constants.SubTypeEnumPrimary, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
					Return([]dbModel.GetResourceByCategory{{ID: utils.IntToPointer(1)}}, nil)

				m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
					Return([]dbModelBookmark.Bookmark{}, nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			m := new(MockResourceRepo)
			tc.setupMock(m)
			ctrl := &resourceController{db: m}

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			// Create Multipart Form
			body := &bytes.Buffer{}
			writer := multipart.NewWriter(body)
			part, _ := writer.CreateFormFile("file", "test.csv")
			part.Write([]byte(tc.csvContent))
			writer.Close()

			c.Request, _ = http.NewRequest("POST", "/", body)
			c.Request.Header.Set("Content-Type", writer.FormDataContentType())

			ctrl.BatchCreateResources(c)
			assert.Equal(t, tc.expectedStatus, w.Code)
		})
	}
}

func TestAdminResourceController_All(t *testing.T) {
	tests := []struct {
		name           string
		method         string
		endpoint       string // e.g., "create", "disable", "batch-create"
		inputBody      interface{}
		csvContent     string
		setupMock      func(*MockResourceRepo)
		expectedStatus int
	}{
		{
			name:      "DisableResource_DB_Error",
			method:    "POST",
			endpoint:  "disable",
			inputBody: DisableResourceRequest{ID: 5},
			setupMock: func(m *MockResourceRepo) {
				m.On("DisableResource", mock.Anything, 5).Return(errors.New("db error"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:     "BatchUpdate_MetadataFallback_Success",
			method:   "POST",
			endpoint: "batch-update",
			// Ensure exactly 17 columns (16 commas) in both lines
			csvContent: "ID,URL,D,T,ST,N,Des,CID,MID,I,V,S,Vis,Meta,Con,Cr,Up\n" +
				"1,u,d,video,expert,n,d,1,1,i,0,t,t,MetaValue,content,2023-01-01 10:00:00,nil",
			setupMock: func(m *MockResourceRepo) {
				m.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			m := new(MockResourceRepo)
			tc.setupMock(m)
			ctrl := &resourceController{db: m}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			// --- ROUTING LOGIC ---
			if tc.csvContent != "" {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)
				part, _ := writer.CreateFormFile("file", "test.csv")
				part.Write([]byte(tc.csvContent))
				writer.Close()
				c.Request, _ = http.NewRequest("POST", "/", body)
				c.Request.Header.Set("Content-Type", writer.FormDataContentType())

				// CALL CORRECT FUNCTION BASED ON ENDPOINT
				if tc.endpoint == "batch-update" {
					ctrl.BatchUpdateResources(c)
				} else {
					ctrl.BatchCreateResources(c)
				}
			} else {
				body, _ := json.Marshal(tc.inputBody)
				c.Request, _ = http.NewRequest(tc.method, "/", bytes.NewBuffer(body))
				c.Request.Header.Set("Content-Type", "application/json")

				if tc.endpoint == "disable" {
					ctrl.DisableResource(c)
				} else if tc.endpoint == "create" {
					ctrl.CreateResource(c)
				}
			}

			assert.Equal(t, tc.expectedStatus, w.Code)
		})
	}
}

func TestAdminResourceController_SpecificOps(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		endpoint       string // "update", "asset", "disable"
		inputBody      interface{}
		setupMock      func(*MockResourceRepo)
		isMultipart    bool
		expectedStatus int
	}{
		// --- UPDATE RESOURCE ---
		{
			name:     "UpdateResource_Success",
			endpoint: "update",
			inputBody: UpdateResourceRequest{
				ID:   utils.IntToPointer(10),
				Name: utils.StringToPointer("Updated Name"),
				Type: ptrResType(constants.ResourceTypeEnumVideo),
			},
			setupMock: func(m *MockResourceRepo) {
				m.On("UpdateResource", mock.Anything, mock.MatchedBy(func(r dbModel.Resource) bool {
					return *r.ID == 10 && *r.Name == "Updated Name"
				})).Return(&dbModel.Resource{}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:     "UpdateResource_InvalidType_Error",
			endpoint: "update",
			inputBody: map[string]interface{}{
				"id":   10,
				"type": "invalid_enum_string",
			},
			setupMock:      func(m *MockResourceRepo) {},
			expectedStatus: http.StatusBadRequest, // Fixed: 400 because binding fails
		},

		// --- DISABLE RESOURCE ---
		{
			name:      "DisableResource_Success",
			endpoint:  "disable",
			inputBody: DisableResourceRequest{ID: 5},
			setupMock: func(m *MockResourceRepo) {
				m.On("DisableResource", mock.Anything, 5).Return(nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			m := new(MockResourceRepo)
			tc.setupMock(m)
			ctrl := &resourceController{db: m}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			if tc.isMultipart {
				// --- Handle Multipart Form Data ---
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				// Add the dummy file to satisfy 'required' tag
				part, _ := writer.CreateFormFile("file", "test.png")
				part.Write([]byte("fake-image-content"))

				// Add other fields
				fields := tc.inputBody.(map[string]string)
				for k, v := range fields {
					_ = writer.WriteField(k, v)
				}
				writer.Close()

				c.Request, _ = http.NewRequest("POST", "/", body)
				c.Request.Header.Set("Content-Type", writer.FormDataContentType())
			} else {
				// --- Handle JSON ---
				jsonBody, _ := json.Marshal(tc.inputBody)
				c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jsonBody))
				c.Request.Header.Set("Content-Type", "application/json")
			}

			// Execute
			if tc.endpoint == "update" {
				ctrl.UpdateResource(c)
			} else if tc.endpoint == "asset" {
				ctrl.ResourceAssetUpload(c)
			}

			assert.Equal(t, tc.expectedStatus, w.Code)
		})
	}
}

func TestResourceController_(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	t.Run("BatchCreate_Column_Count_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		// Sending only 5 columns instead of 15/16
		csvData := "h1,h2,h3,h4,h5\nd1,d2,d3,d4,d5"

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "incorrect number of columns")
	})
	t.Run("BatchCreate_Column_Mismatch_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		// Providing only 5 columns (logic expects 15 or 16)
		csvData := "h1,h2,h3,h4,h5\nd1,d2,d3,d4,d5"

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "incorrect number of columns")
	})
	t.Run("BatchUpdate_Empty_ID_Logic", func(t *testing.T) {
		ctrl := &resourceController{}
		// Column 0 is just spaces
		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n" +
			" ,url,dark,video,primary,n,d,1,1,i,0,t,t,{},c,c,u"

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "invalid value for ID column")
	})

	t.Run("BatchUpdate_Empty_ID_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		// Row 0 (ID) is empty
		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n" +
			" ,url,dark,video,primary,n,d,1,1,i,0,t,t,{},c,c,u"

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "invalid value for ID column")
	})
	t.Run("GetResources_NonVideo_WithSubType_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Article type with a subtype should fail based on your helper logic
		c.Request, _ = http.NewRequest("GET", "/res?category_id=1&resource_type=article&sub_type=primary", nil)
		c.Set("userId", int64(1))

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("GetResourceById_Unauthorized_User", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "resource_id", Value: "10"}}

		// Explicitly do NOT set "userId" in context

		ctrl.GetResourceById(c)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
		assert.Contains(t, w.Body.String(), "user not authenticated")
	})
	t.Run("GetResourceById_Invalid_ID_Format", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Pass a string instead of an integer for the ID
		c.Params = []gin.Param{{Key: "resource_id", Value: "not_a_number"}}

		ctrl.GetResourceById(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "invalid request body")
	})

	t.Run("BatchCreate_16Columns_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		// Corrected: Using 'primary' as SubType (Column 14)
		csvData := "id,url,dark,type,name,desc,cat,mod,icon,views,short,vis,meta,content,sub,created\n" +
			"101,http://u.com,d,video,name,desc,1,1,i,0,true,true,{},content,primary,2023-01-01 10:00:00"

		mockRepo.On("BatchCreateResources", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, contentType := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", contentType)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "successful")
	})

	t.Run("BatchUpdate_17Columns_MetadataFallback_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		// Corrected: Using 'expert' as SubType (Column 4) and raw text for metadata (Column 13)
		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,MetaValue,content,c,u\n" +
			"1,u,d,video,expert,n,d,1,1,i,0,t,t,MetaValue,c,c,u"

		mockRepo.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, contentType := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", contentType)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "successful")
	})

	t.Run("CreateResource_Validation_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Missing 'sub_type' which is required by CreateResourceRequest struct tags
		req := CreateResourceRequest{URL: utils.StringToPointer("http://test.com")}
		jsonBytes, _ := json.Marshal(req)
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jsonBytes))

		ctrl.CreateResource(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "invalid request body")
	})

	t.Run("GetResourcesByCategory_Success_WithFilter", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		uid := int64(1)

		mockRepo.On("GetResourcesByCategoryAndType", mock.Anything, 1, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModel.GetResourceByCategory{}, nil)
		mockRepo.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, uid).Return([]dbModelBookmark.Bookmark{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/res?category_id=1&resource_type=video&sub_type=primary&filter=trending", nil)
		c.Set("userId", uid)

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("UpdateResource_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		id := 1
		resType, subType := constants.ResourceTypeEnumVideo, constants.SubTypeEnumLearn
		req := UpdateResourceRequest{ID: &id, Type: &resType, SubType: &subType}

		mockRepo.On("UpdateResource", mock.Anything, mock.Anything).Return(&dbModel.Resource{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(req)
		c.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(b))

		ctrl.UpdateResource(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("DisableResource_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		mockRepo.On("DisableResource", mock.Anything, 50).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(DisableResourceRequest{ID: 50})
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(b))

		ctrl.DisableResource(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("BatchCreate_15Columns_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		// Exactly 15 columns
		csvData := "url,dark,type,name,desc,cat,mod,icon,views,short,vis,meta,content,sub,created\n" +
			"http://u.com,d,video,n,d,1,1,i,0,t,t,{},c,primary,2023-01-01 10:00:00"

		mockRepo.On("BatchCreateResources", mock.Anything, mock.Anything).Return(nil)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData) // Use your helper to create multipart
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("AssetUpload_InvalidAssetFor_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("resource_id", "1")
		_ = writer.WriteField("asset_for", "invalid_type")
		part, _ := writer.CreateFormFile("asset_file", "t.png")
		part.Write([]byte("data"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.ResourceAssetUpload(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetResourceById_DB_Error", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		mockRepo.On("GetResourceById", mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("db fail"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "resource_id", Value: "1"}}
		c.Set("userId", int64(1))

		ctrl.GetResourceById(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("CreateResource_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		resType := constants.ResourceTypeEnumVideo
		subType := constants.SubTypeEnumPrimary
		id := 100

		// Happy path request
		req := CreateResourceRequest{
			URL:     utils.StringToPointer("http://test.com"),
			Type:    &resType,
			SubType: &subType,
		}

		mockRepo.On("CreateResource", mock.Anything, mock.Anything).Return(&dbModel.Resource{ID: &id}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(req)
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(b))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.CreateResource(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("BatchUpdate_DB_Error", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n1,u,d,video,expert,n,d,1,1,i,0,t,t,{},c,c,u"

		// Trigger the Error branch inside batchUpdateResourceHelper
		mockRepo.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(errors.New("db batch error"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("AssetUpload_Invalid_AssetFor_Param", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("resource_id", "1")
		_ = writer.WriteField("asset_for", "banner") // Not in [icon, podcast]
		part, _ := writer.CreateFormFile("asset_file", "t.png")
		part.Write([]byte("data"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.ResourceAssetUpload(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "invalid value for asset_for")
	})

	t.Run("DisableResource_DB_Error", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		mockRepo.On("DisableResource", mock.Anything, mock.Anything).Return(errors.New("db error"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(DisableResourceRequest{ID: 5})
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(b))

		ctrl.DisableResource(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("BatchCreate_Invalid_Date_Format", func(t *testing.T) {
		ctrl := &resourceController{}
		// Invalid date "01-01-2023" (Expected "2006-01-02 15:04:05")
		csvData := "url,dark,type,name,desc,cat,mod,icon,views,short,vis,meta,content,sub,created\n" +
			"u,d,video,n,d,1,1,i,0,t,t,{},c,primary,01-01-2023"

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetResources_Video_With_SubType_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		uid := int64(1)

		mockRepo.On("GetResourcesByCategoryAndType", mock.Anything, mock.Anything, constants.ResourceTypeEnumVideo, constants.SubTypeEnumPrimary, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
			Return([]dbModel.GetResourceByCategory{}, nil)
		mockRepo.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, uid).Return([]dbModelBookmark.Bookmark{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Providing both type=video and a valid sub_type
		c.Request, _ = http.NewRequest("GET", "/res?category_id=1&resource_type=video&sub_type=primary", nil)
		c.Set("userId", uid)

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("ResourceAssetUpload_InvalidAssetFor_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		_ = writer.WriteField("resource_id", "1")
		_ = writer.WriteField("asset_for", "invalid_type") // This triggers the early return
		part, _ := writer.CreateFormFile("asset_file", "t.png")
		part.Write([]byte("data"))
		writer.Close()

		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", writer.FormDataContentType())

		ctrl.ResourceAssetUpload(c)
		// Helper returns error for invalid type, controller returns 500
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("UpdateResource_Full_Logic_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		id := 1
		resType := constants.ResourceTypeEnumVideo
		subType := constants.SubTypeEnumExpert

		req := UpdateResourceRequest{
			ID:      &id,
			Type:    &resType,
			SubType: &subType,
		}

		mockRepo.On("UpdateResource", mock.Anything, mock.Anything).Return(&dbModel.Resource{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(req)
		c.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(b))

		ctrl.UpdateResource(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("BatchUpdate_FinalFlush_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		// 1 row of data (less than 100) hits the 'if len(resources) > 0' block
		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n" +
			"1,u,d,video,primary,n,d,1,1,i,0,t,t,{},c,c,u"

		mockRepo.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("CreateResource_Invalid_ResourceType_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		badType := constants.ResourceTypeEnum(999)
		subType := constants.SubTypeEnum("primary")
		req := CreateResourceRequest{Type: &badType, SubType: &subType}

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(req)
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(b))

		ctrl.CreateResource(c)
		// Updated: Expect 400 because Gin binding catches the invalid enum
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("CreateResource_MissingResourceType_Error", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		// Bypass gin required tags by providing other valid fields but keeping Type nil
		subType := constants.SubTypeEnum("primary")
		req := CreateResourceRequest{
			URL:     utils.StringToPointer("http://test.com"),
			SubType: &subType,
			// Type is nil
		}

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(req)
		c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(b))
		c.Request.Header.Set("Content-Type", "application/json")

		ctrl.CreateResource(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "resource type not provided")
	})

	t.Run("GetResources_QueryBinding_Fail", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// passing string to int field
		c.Request, _ = http.NewRequest("GET", "/res?category_id=abc", nil)

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
	t.Run("GetResources_Invalid_ResourceType_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// "invalid_type" will fail ParseResourceTypeEnum
		c.Request, _ = http.NewRequest("GET", "/res?category_id=1&resource_type=invalid_type", nil)
		c.Set("userId", int64(1))

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "invalid resource type")
	})

	t.Run("GetResources_Invalid_Filter_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Valid type, but "bad_filter" fails ParseFilterTypeEnum
		c.Request, _ = http.NewRequest("GET", "/res?category_id=1&resource_type=video&sub_type=primary&filter=bad_filter", nil)
		c.Set("userId", int64(1))

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("BatchCreate_FinalBatch_DB_Error", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		csvData := "url,dark,type,name,desc,cat,mod,icon,views,short,vis,meta,content,sub,created\n" +
			"u,d,video,n,d,1,1,i,0,t,t,{},c,primary,2023-01-01 10:00:00"

		// Simulate error on the final flush
		mockRepo.On("BatchCreateResources", mock.Anything, mock.Anything).Return(errors.New("final flush fail"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("GetResources_QueryBinding_Error", func(t *testing.T) {
		ctrl := &resourceController{}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Send string "abc" for an expected integer category_id
		c.Request, _ = http.NewRequest("GET", "/res?category_id=abc", nil)

		ctrl.GetResourcesByCategoryType(c)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Invalid query parameters")
	})
	t.Run("BatchUpdate_Success_Remainder_Loop", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		// 2 rows of data (fewer than 100) to hit the "if len(resources) > 0" block
		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n" +
			"1,u,d,video,primary,n,d,1,1,i,0,t,t,{},c,c,u\n" +
			"2,u,d,video,primary,n,d,1,1,i,0,t,t,{},c,c,u"

		mockRepo.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("UpdateResource_DB_Error", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		id := 1
		mockRepo.On("UpdateResource", mock.Anything, mock.Anything).Return(nil, errors.New("update failed"))

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(UpdateResourceRequest{ID: &id})
		c.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(b))

		ctrl.UpdateResource(c)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("BatchCreate_Full_100_Batch_Logic", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		// Generate 101 rows (Header + 101 data rows)
		var sb strings.Builder
		sb.WriteString("url,dark,type,name,desc,cat,mod,icon,views,short,vis,meta,content,sub,created\n")
		for i := 0; i < 101; i++ {
			sb.WriteString("u,d,video,n,d,1,1,i,0,t,t,{},c,primary,2023-01-01 10:00:00\n")
		}

		// Expect 2 calls: one for the 100-batch, one for the remainder
		mockRepo.On("BatchCreateResources", mock.Anything, mock.Anything).Return(nil).Times(2)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(sb.String())
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchCreateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("UpdateResource_Controller_Success_Path", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}
		id := 1
		mockRepo.On("UpdateResource", mock.Anything, mock.Anything).Return(&dbModel.Resource{}, nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		b, _ := json.Marshal(UpdateResourceRequest{ID: &id})
		c.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(b))

		ctrl.UpdateResource(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("CreateResource_Invalid_Enum_Branches", func(t *testing.T) {
		//mockRepo := new(MockResourceRepo)
		//ctrl := &resourceController{db: mockRepo}
		t.Run("BatchUpdate_Extraction_Errors", func(t *testing.T) {
			ctrl := &resourceController{}

			// Case: Invalid Resource Type Enum in CSV
			t.Run("Invalid_Type_In_CSV", func(t *testing.T) {
				csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n" +
					"1,u,d,INVALID_TYPE,primary,n,d,1,1,i,0,t,t,{},c,c,u"
				body, ct := createCSVPart(csvData)
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Request, _ = http.NewRequest("POST", "/", body)
				c.Request.Header.Set("Content-Type", ct)
				ctrl.BatchUpdateResources(c)
				assert.Equal(t, http.StatusInternalServerError, w.Code)
			})
		})
		t.Run("AssetUpload_Early_Errors", func(t *testing.T) {
			ctrl := &resourceController{}

			t.Run("Missing_File_Error", func(t *testing.T) {
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				// No file in request
				c.Request, _ = http.NewRequest("POST", "/upload", nil)
				ctrl.ResourceAssetUpload(c)
				assert.Equal(t, http.StatusBadRequest, w.Code)
			})
		})
	})

	t.Run("BatchUpdate_With_Valid_Metadata_Success", func(t *testing.T) {
		mockRepo := new(MockResourceRepo)
		ctrl := &resourceController{db: mockRepo}

		csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n" +
			"1,u,d,video,primary,n,d,1,1,i,0,t,t,{\"key\":\"val\"},c,c,u"

		mockRepo.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(nil)

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		body, ct := createCSVPart(csvData)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", ct)

		ctrl.BatchUpdateResources(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}
func BenchmarkBatchUpdate(b *testing.B) {
	mockRepo := new(MockResourceRepo)
	ctrl := &resourceController{db: mockRepo}
	mockRepo.On("BatchUpdateResources", mock.Anything, mock.Anything).Return(nil)
	csvData := "id,url,dark,type,sub,name,desc,cat,mod,icon,views,short,vis,meta,content,c,u\n1,u,d,video,learn,n,d,1,1,i,0,t,t,{},c,c,u"

	for i := 0; i < b.N; i++ {
		body, contentType := createCSVPart(csvData)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("POST", "/", body)
		c.Request.Header.Set("Content-Type", contentType)
		ctrl.BatchUpdateResources(c)
	}
}

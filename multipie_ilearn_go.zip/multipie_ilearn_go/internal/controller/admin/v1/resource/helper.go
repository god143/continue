package resource

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/resource"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"slices"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"
)

func (r *resourceController) getResourceByIdHelper(ctx context.Context, id int, visible *bool, userId *int64) (*dbModel.Resource, error) {
	var subtype []string
	var resourceIds []int
	var resourceTypes []string
	var bookmarkId *int64

	resourceData, err := r.db.GetResourceById(ctx, id, visible)
	if err != nil {
		logger.Error(ctx, "unable to fetch resource from db", zap.Error(err))
		return nil, errors.New("unable to fetch resource from db")
	}

	resourceIds = append(resourceIds, *resourceData.ID)
	resourceTypes = append(resourceTypes, resourceData.Type.String())

	bookmark, err := r.db.GetBookmarkByCustomParams(ctx, resourceIds, resourceTypes, subtype, *userId)
	if err != nil {
		return nil, err
	}

	for _, bm := range bookmark {
		bookmarkId = bm.ID
	}
	isBookmark := len(bookmark) != 0
	resourceData.IsBookmark = &isBookmark
	resourceData.BookmarkId = bookmarkId

	return resourceData, nil
}

// getResourcesByCategoryTypeHelper retrieves resources by category and type
func (r *resourceController) getResourcesByCategoryTypeHelper(ctx context.Context, categoryID int, resourceTypeStr string, subTypeStr string, visible *bool, isShort *bool, pagination utils.Pagination, filter string, userId *int64) ([]dbModel.GetResourceByCategory, error) {
	var resourceIds []int
	var resourceTypes []string
	var subTypes []string
	var resourceType constants.ResourceTypeEnum
	var subType constants.SubTypeEnum
	var filterType constants.FilterTypeEnum
	var err error

	if subTypeStr != "" && resourceTypeStr == constants.ResourceTypeEnumVideo.String() {
		subType, err = constants.ParseSubTypeEnum(subTypeStr)
		if err != nil {
			logger.Error(ctx, "Invalid sub type", zap.String("sub_type", subTypeStr), zap.Error(err))
			return nil, fmt.Errorf("invalid sub type: %w", err)
		}
	} else if subTypeStr != "" && resourceTypeStr != constants.ResourceTypeEnumVideo.String() {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	} else if subTypeStr == "" && resourceTypeStr == constants.ResourceTypeEnumVideo.String() {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	}

	resourceType, err = constants.ParseResourceTypeEnum(resourceTypeStr)
	if err != nil {
		logger.Error(ctx, "Invalid resource type", zap.String("resource_type", resourceTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid resource type: %w", err)
	}

	if filter != "" {
		filterType, err = constants.ParseFilterTypeEnum(filter)
		if err != nil {
			logger.Error(ctx, "Invalid filter type", zap.String("filter", filter), zap.Error(err))
			return nil, fmt.Errorf("invalid filter type: %w", err)
		}
	} else {
		filterType = constants.FilterTypeEnum("")
	}

	resourceData, err := r.db.GetResourcesByCategoryAndType(ctx, categoryID, resourceType, subType, visible, isShort, pagination, filterType)
	if err != nil {
		logger.Error(ctx, "unable to fetch resources from db", zap.Error(err))
		return nil, fmt.Errorf("unable to fetch resources from db: %w", err)
	}

	for _, resource := range resourceData {
		resourceIds = append(resourceIds, *resource.ID)
		resourceTypes = append(resourceTypes, resource.Type.String())
		subTypes = append(subTypes, resource.SubType.String())
	}

	bookmarks, err := r.db.GetBookmarkByCustomParams(ctx, resourceIds, resourceTypes, subTypes, *userId)
	if err != nil {
		return nil, err
	}

	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)
		}
	}

	responses := make([]dbModel.GetResourceByCategory, 0, len(resourceData))

	for _, m := range resourceData {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}
		responses = append(responses, dbModel.GetResourceByCategory{
			ID:             m.ID,
			URL:            m.URL,
			DarkModeURL:    m.DarkModeURL,
			Type:           m.Type,
			SubType:        m.SubType,
			Name:           m.Name,
			Description:    m.Description,
			CategoryID:     m.CategoryID,
			CourseModuleID: m.CourseModuleID,
			Icon:           m.Icon,
			Views:          m.Views,
			Likes:          m.Likes,
			Visible:        m.Visible,
			IsShort:        m.IsShort,
			Metadata:       m.Metadata,
			Content:        m.Content,
			CreatedAt:      m.CreatedAt,
			UpdatedAt:      m.UpdatedAt,
			IsBookmark:     isBookmark,
			BookmarkId:     bookmarkIdPtr,
		})
	}
	return responses, nil
}

// disableResourceHelper disables a resource by its ID
func (r *resourceController) disableResourceHelper(ctx context.Context, request DisableResourceRequest) error {
	err := r.db.DisableResource(ctx, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to disable category in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to disable category entry in database")
	}
	return nil
}

// createResourceHelper creates a new resource
func (r *resourceController) createResourceHelper(ctx context.Context, request CreateResourceRequest) (*dbModel.Resource, error) {
	resource := &dbModel.Resource{
		URL:            request.URL,
		DarkModeURL:    request.DarkModeURL,
		Type:           request.Type,
		SubType:        request.SubType,
		Name:           request.Name,
		Description:    request.Description,
		CategoryID:     request.CategoryID,
		CourseModuleID: request.CourseModuleID,
		Icon:           request.Icon,
		Views:          request.Views,
		IsShort:        request.IsShort,
		Visible:        utils.BoolToPointer(true),
		Metadata:       request.Metadata,
		Content:        request.Content,
	}
	if request.Type != nil {
		resourceTypeString := request.Type.String()

		resourceType, err := constants.ParseResourceTypeEnum(resourceTypeString)
		if err != nil {
			logger.Error(ctx, "invalid value for resource type", zap.String("type", resourceTypeString), zap.Error(err))
			return nil, errors.New("invalid value for resource type")
		}
		if request.SubType != nil {
			subTypeString := request.SubType.String()
			subType, err := constants.ParseSubTypeEnum(subTypeString)
			if err != nil {
				logger.Error(ctx, "invalid value for sub type", zap.String("type", subTypeString), zap.Error(err))
				return nil, errors.New("invalid value for sub type")
			}
			resource.SubType = &subType

		} else {
			logger.Error(ctx, "sub type not provided")
			return nil, errors.New("sub type not provided")
		}

		resource.Type = &resourceType

	} else {
		logger.Error(ctx, "resource type not provided, using default", zap.Any("request", request))
		return nil, errors.New("resource type not provided")

	}

	if request.CreatedAt != nil {
		resource.CreatedAt = request.CreatedAt
	}

	createdResource, err := r.db.CreateResource(ctx, resource)
	if err != nil {
		logger.Error(ctx, "unable to create resource in database", zap.Error(err), zap.Any("resource", resource))
		return nil, errors.New("unable to create resource in database")
	}

	logger.Info(ctx, "resource created successfully", zap.Any("createdResource", createdResource))
	return createdResource, nil
}

// updateResourceHelper updates an existing resource
func (r *resourceController) updateResourceHelper(ctx context.Context, request UpdateResourceRequest) error {
	resource := dbModel.Resource{
		ID:             request.ID,
		URL:            request.URL,
		DarkModeURL:    request.DarkModeURL,
		Type:           request.Type,
		SubType:        request.SubType,
		Name:           request.Name,
		Description:    request.Description,
		CategoryID:     request.CategoryID,
		CourseModuleID: request.CourseModuleID,
		Icon:           request.Icon,
		Views:          request.Views,
		IsShort:        request.IsShort,
		Visible:        utils.BoolToPointer(true),
		Metadata:       request.Metadata,
		Content:        request.Content,
	}

	if request.Type != nil {
		resourceTypeString := request.Type.String()
		temp, err := constants.ParseResourceTypeEnum(resourceTypeString)
		if err != nil {
			logger.Error(ctx, "invalid value for sub type", zap.Error(err))
			return errors.New("invalid value for sub type")
		}
		resource.Type = &temp
	}

	if request.SubType != nil {
		subTypeString := request.SubType.String()
		temp, err := constants.ParseSubTypeEnum(subTypeString)
		if err != nil {
			logger.Error(ctx, "invalid value for sub type", zap.Error(err))
			return errors.New("invalid value for sub type")
		}
		resource.SubType = &temp
	}

	_, err := r.db.UpdateResource(ctx, resource)
	if err != nil {
		logger.Error(ctx, "unable to update resource entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update resource entry in database")
	}
	return nil
}

func (r *resourceController) batchCreateResourceHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount  int
		batchNo   int
		resources []dbModel.BatchCreateResource
	)

	// Create a CSV reader that handles lazy quotes (useful for CSV fields with quotes)
	reader := csv.NewReader(file)
	reader.LazyQuotes = true

	// Iterate over the rows in the CSV file
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break // End of file, stop reading
		}
		if err != nil {
			// Error reading the row
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}

		// Increment row count
		rowCount++

		// Skip the header row
		if rowCount == 1 {
			logger.Debug(ctx, "Skipping header row")
			continue
		}

		// Check if the number of columns is as expected
		if len(row) < 15 || len(row) > 16 { // columns increacse due to old id and old type column
			logger.Error(ctx, "incorrect number of columns in the row", zap.Int("rowCount", rowCount), zap.Any("rowData", row))
			return fmt.Errorf("incorrect number of columns in the row, rowNumber: %v", rowCount)
		}

		// Extract data for resource creation from the row
		resource, err := r.extractDataForCreateResource(row)
		if err != nil {
			// Error extracting data from row
			logger.Error(ctx, "error extracting data", zap.Error(err), zap.Int("rowCount", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		// Add resource to the batch
		resources = append(resources, resource)

		// If batch size reaches 100, insert it into the database
		if len(resources) == 100 {
			batchNo++
			if err := r.db.BatchCreateResources(ctx, resources); err != nil {
				// Error during batch insert
				logger.Error(ctx, "batch insertion failed", zap.Int("batchNo", batchNo), zap.Error(err))
				return fmt.Errorf("batch insertion failed for batch %d: %v", batchNo, err)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Int("batchNo", batchNo))
			resources = []dbModel.BatchCreateResource{}
		}
	}

	if len(resources) > 0 {
		batchNo++
		if err := r.db.BatchCreateResources(ctx, resources); err != nil {

			logger.Error(ctx, "final batch insertion failed", zap.Int("batchNo", batchNo), zap.Error(err))
			return fmt.Errorf("final batch insertion failed for batch %d: %v", batchNo, err)
		}
		logger.Debug(ctx, "final batch of records successfully processed", zap.Int("batchNo", batchNo))
	}

	return nil
}

func (r *resourceController) extractDataForCreateResource(row []string) (dbModel.BatchCreateResource, error) {
	var metadata map[string]interface{}
	var resource dbModel.BatchCreateResource

	switch {
	case len(row) == 15:
		if len(row) > 11 && strings.TrimSpace(row[11]) != "" {
			if err := json.Unmarshal([]byte(strings.TrimSpace(row[11])), &metadata); err != nil {
				logger.Error(context.Background(), "failed to parse metadata", zap.Error(err), zap.String("metadata", row[11]))
				return dbModel.BatchCreateResource{}, fmt.Errorf("failed to parse metadata: %v", err)
			}
		}

		var resourceType *constants.ResourceTypeEnum
		if len(row) > 2 && strings.TrimSpace(row[2]) != "" {
			parsedType, err := constants.ParseResourceTypeEnum(strings.TrimSpace(row[2]))
			if err != nil {
				logger.Error(context.Background(), "invalid resource type", zap.Error(err), zap.String("resourceType", row[2]))
				return dbModel.BatchCreateResource{}, fmt.Errorf("invalid resource type: %v", err)
			}
			resourceType = &parsedType
		}

		var subType *constants.SubTypeEnum
		if len(row) > 2 && strings.TrimSpace(row[13]) != "" {
			parsedType, err := constants.ParseSubTypeEnum(strings.TrimSpace(row[13]))
			if err != nil {
				logger.Error(context.Background(), "invalid sub type", zap.Error(err), zap.String("subType", row[13]))
				return dbModel.BatchCreateResource{}, fmt.Errorf("invalid sub type: %v", err)
			}
			subType = &parsedType
		}
		var metadataBytes json.RawMessage
		if len(metadata) > 0 {
			var err error
			metadataBytes, err = json.Marshal(metadata)
			if err != nil {
				logger.Error(context.Background(), "failed to marshal metadata", zap.Error(err))
				return dbModel.BatchCreateResource{}, fmt.Errorf("failed to marshal metadata: %v", err)
			}
		}

		var courseModuleID *int
		if strings.TrimSpace(row[6]) != "" {
			parsedID := parseIntOrZero(strings.TrimSpace(row[6]))
			if parsedID > 0 {
				courseModuleID = utils.IntToPointer(parsedID)
			}
		}

		var categoryID *int
		if strings.TrimSpace(row[5]) != "" {
			parsedID := parseIntOrZero(strings.TrimSpace(row[5]))
			if parsedID > 0 {
				categoryID = utils.IntToPointer(parsedID)
			}
		}

		var createdAt *time.Time
		createdAtStr := strings.TrimSpace(row[14])
		if len(createdAtStr) != 0 {
			formattedCreatedAt, err := utils.FormatDateTime(row[14])
			if err != nil {
				return resource, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			createdAt = formattedCreatedAt
			fmt.Printf("Input: %s | Output: %s\n", row[14], createdAt)
		}

		resource = dbModel.BatchCreateResource{
			URL:            utils.StringToPointer(strings.TrimSpace(row[0])),
			DarkModeURL:    utils.StringToPointer(strings.TrimSpace(row[1])),
			Type:           resourceType,
			SubType:        subType,
			Name:           utils.StringToPointer(strings.TrimSpace(row[3])),
			Description:    utils.StringToPointer(strings.TrimSpace(row[4])),
			CategoryID:     categoryID,
			CourseModuleID: courseModuleID,
			Icon:           utils.StringToPointer(strings.TrimSpace(row[7])),
			Views:          utils.IntToPointer(parseIntOrZero(strings.TrimSpace(row[8]))),
			IsShort:        utils.BoolToPointer(parseBoolOrFalse(strings.TrimSpace(row[9]))),
			Visible:        utils.BoolToPointer(parseBoolOrFalse(strings.TrimSpace(row[10]))),
			Metadata:       metadataBytes,
			Content:        utils.StringToPointer(strings.TrimSpace(row[12])),
			CreatedAt:      createdAt,
			UpdatedAt:      nil,
		}
	case len(row) == 16:
		if len(row) > 11 && strings.TrimSpace(row[12]) != "" {
			if err := json.Unmarshal([]byte(strings.TrimSpace(row[12])), &metadata); err != nil {
				logger.Error(context.Background(), "failed to parse metadata", zap.Error(err), zap.String("metadata", row[12]))
				return dbModel.BatchCreateResource{}, fmt.Errorf("failed to parse metadata: %v", err)
			}
		}

		var resourceType *constants.ResourceTypeEnum
		if len(row) > 2 && strings.TrimSpace(row[3]) != "" {
			parsedType, err := constants.ParseResourceTypeEnum(strings.TrimSpace(row[3]))
			if err != nil {
				logger.Error(context.Background(), "invalid resource type", zap.Error(err), zap.String("resourceType", row[3]))
				return dbModel.BatchCreateResource{}, fmt.Errorf("invalid resource type: %v", err)
			}
			resourceType = &parsedType
		}

		var subType *constants.SubTypeEnum
		if len(row) > 2 && strings.TrimSpace(row[14]) != "" {
			parsedType, err := constants.ParseSubTypeEnum(strings.TrimSpace(row[14]))
			if err != nil {
				logger.Error(context.Background(), "invalid sub type", zap.Error(err), zap.String("subType", row[14]))
				return dbModel.BatchCreateResource{}, fmt.Errorf("invalid sub type: %v", err)
			}
			subType = &parsedType
		}
		var metadataBytes json.RawMessage
		if len(metadata) > 0 {
			var err error
			metadataBytes, err = json.Marshal(metadata)
			if err != nil {
				logger.Error(context.Background(), "failed to marshal metadata", zap.Error(err))
				return dbModel.BatchCreateResource{}, fmt.Errorf("failed to marshal metadata: %v", err)
			}
		}

		var courseModuleID *int
		if strings.TrimSpace(row[7]) != "" {
			parsedID := parseIntOrZero(strings.TrimSpace(row[7]))
			if parsedID > 0 {
				courseModuleID = utils.IntToPointer(parsedID)
			}
		}

		var categoryID *int
		if strings.TrimSpace(row[6]) != "" {
			parsedID := parseIntOrZero(strings.TrimSpace(row[6]))
			if parsedID > 0 {
				categoryID = utils.IntToPointer(parsedID)
			}
		}

		resourceId, err := strconv.Atoi(strings.TrimSpace(row[0]))
		if err != nil {
			logger.Error(context.Background(), "failed to convert resourceId into int", zap.Error(err))
			return dbModel.BatchCreateResource{}, fmt.Errorf("failed to convert resourceId into int: %v", err)
		}

		var createdAt *time.Time
		createdAtStr := strings.TrimSpace(row[15])
		if len(createdAtStr) != 0 {
			formattedCreatedAt, err := utils.FormatDateTime(row[15])
			if err != nil {
				return resource, fmt.Errorf("invalid value for createdAt column,error: %v", err)
			}
			createdAt = formattedCreatedAt
		}

		resource = dbModel.BatchCreateResource{
			ID:             &resourceId,
			URL:            utils.StringToPointer(strings.TrimSpace(row[1])),
			DarkModeURL:    utils.StringToPointer(strings.TrimSpace(row[2])),
			Type:           resourceType,
			SubType:        subType,
			Name:           utils.StringToPointer(strings.TrimSpace(row[4])),
			Description:    utils.StringToPointer(strings.TrimSpace(row[5])),
			CategoryID:     categoryID,
			CourseModuleID: courseModuleID,
			Icon:           utils.StringToPointer(strings.TrimSpace(row[8])),
			Views:          utils.IntToPointer(parseIntOrZero(strings.TrimSpace(row[9]))),
			IsShort:        utils.BoolToPointer(parseBoolOrFalse(strings.TrimSpace(row[10]))),
			Visible:        utils.BoolToPointer(parseBoolOrFalse(strings.TrimSpace(row[11]))),
			Metadata:       metadataBytes,
			Content:        utils.StringToPointer(strings.TrimSpace(row[13])),
			CreatedAt:      createdAt,
			UpdatedAt:      nil,
		}
	}

	return resource, nil
}

func (r *resourceController) batchUpdateResourceHelper(ctx context.Context, file multipart.File) error {
	var (
		rowCount  int
		batchNo   int
		resources []dbModel.Resource
	)
	reader := csv.NewReader(file)
	reader.LazyQuotes = true

	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("unable to read csv record at row %d", rowCount), zap.Error(err))
			return fmt.Errorf("unable to read csv record at row %d: %v", rowCount, err)
		}
		rowCount++
		logger.Debug(ctx, "Read row", zap.Int("rowCount", rowCount), zap.Any("rowData", row))

		if rowCount == 1 {
			logger.Debug(ctx, "Skipping header row")
			continue
		}

		if len(row) != 17 {
			logger.Error(ctx, "incorrect number of columns in the row", zap.Int("rowCount", rowCount), zap.Int("columnCount", len(row)), zap.Any("rowData", row))
			return fmt.Errorf("incorrect number of columns in the row, rowNumber: %v", rowCount)
		}
		resource, err := r.extractDataForUpdateFile(row)
		if err != nil {
			logger.Error(ctx, "error extracting data", zap.Error(err), zap.Int("rowCount", rowCount))
			return fmt.Errorf("error: %v, for rowNum: %v", err, rowCount)
		}

		resources = append(resources, resource)

		if len(resources) == 100 {
			batchNo++
			if err := r.db.BatchUpdateResources(ctx, resources); err != nil {
				logger.Error(ctx, "batch update failed", zap.Int("batchNo", batchNo), zap.Error(err))
				return fmt.Errorf("batch update failed for batch %d: %v", batchNo, err)
			}
			logger.Debug(ctx, "batch of records successfully processed", zap.Int("batchNo", batchNo))
			resources = []dbModel.Resource{}
		}
	}

	if len(resources) > 0 {
		batchNo++
		if err := r.db.BatchUpdateResources(ctx, resources); err != nil {
			logger.Error(ctx, "final batch update failed", zap.Int("batchNo", batchNo), zap.Error(err))
			return fmt.Errorf("final batch update failed for batch %d: %v", batchNo, err)
		}
		logger.Debug(ctx, "final batch of records successfully processed", zap.Int("batchNo", batchNo))
	}

	return nil
}

func (r *resourceController) extractDataForUpdateFile(row []string) (dbModel.Resource, error) {
	var resource dbModel.Resource

	idStr := strings.TrimSpace(row[0])
	if idStr == "" {
		return resource, errors.New("invalid value for ID column")
	}
	id, err := strconv.Atoi(idStr)
	if err != nil {
		logger.Error(context.Background(), "invalid value for ID column", zap.String("idStr", idStr), zap.Error(err))
		return resource, fmt.Errorf("invalid value for ID column: %v", err)
	}
	resource.ID = &id

	resource.URL = utils.StringToPointer(strings.TrimSpace(row[1]))
	resource.DarkModeURL = utils.StringToPointer(strings.TrimSpace(row[2]))

	resourceTypeStr := strings.TrimSpace(row[3])
	if resourceTypeStr != "" {
		parsedType, err := constants.ParseResourceTypeEnum(resourceTypeStr)
		if err != nil {
			logger.Error(context.Background(), "invalid value for type column", zap.String("resourceTypeStr", resourceTypeStr), zap.Error(err))
			return resource, fmt.Errorf("invalid value for type column: %v", err)
		}
		resource.Type = &parsedType
	}

	subTypeStr := strings.TrimSpace(row[4])
	if subTypeStr != "" {
		parsedType, err := constants.ParseSubTypeEnum(subTypeStr)
		if err != nil {
			logger.Error(context.Background(), "invalid value for subtype column", zap.String("subTypeStr", subTypeStr), zap.Error(err))
			return resource, fmt.Errorf("invalid value for subtype column: %v", err)
		}
		resource.SubType = &parsedType
	}

	resource.Name = utils.StringToPointer(strings.TrimSpace(row[5]))
	resource.Description = utils.StringToPointer(strings.TrimSpace(row[6]))

	categoryIDStr := strings.TrimSpace(row[7])
	if categoryIDStr != "" {
		categoryID := parseIntOrZero(categoryIDStr)
		resource.CategoryID = utils.IntToPointer(categoryID)
	}

	courseModuleIDStr := strings.TrimSpace(row[8])
	if courseModuleIDStr != "" {
		courseModuleID := parseIntOrZero(courseModuleIDStr)
		resource.CourseModuleID = utils.IntToPointer(courseModuleID)
	}

	resource.Icon = utils.StringToPointer(strings.TrimSpace(row[9]))

	viewsStr := strings.TrimSpace(row[10])
	if viewsStr != "" {
		views := parseIntOrZero(viewsStr)
		resource.Views = utils.IntToPointer(views)
	}

	isShortStr := strings.TrimSpace(row[11])
	if isShortStr != "" {
		resource.IsShort = utils.BoolToPointer(parseBoolOrFalse(isShortStr))
	}

	visibleStr := strings.TrimSpace(row[12])
	if visibleStr != "" {
		resource.Visible = utils.BoolToPointer(parseBoolOrFalse(visibleStr))
	}

	if len(row) > 12 && strings.TrimSpace(row[13]) != "" {
		metadataStr := strings.TrimSpace(row[13])

		var metadata map[string]interface{}
		if err := json.Unmarshal([]byte(metadataStr), &metadata); err != nil {
			logger.Error(context.Background(), "failed to parse metadata", zap.Error(err), zap.String("metadata", metadataStr))

			var fallbackMetadata map[string]interface{}
			if numericValue, err := strconv.ParseFloat(metadataStr, 64); err == nil {
				fallbackMetadata = map[string]interface{}{"value": numericValue}
			} else {
				fallbackMetadata = map[string]interface{}{"value": metadataStr}
			}
			metadataBytes, err := json.Marshal(fallbackMetadata)
			if err != nil {
				return resource, fmt.Errorf("failed to marshal fallback metadata: %v", err)
			}
			resource.Metadata = metadataBytes
		} else {
			resource.Metadata = []byte(metadataStr)
		}
	}
	resource.Content = utils.StringToPointer(strings.TrimSpace(row[14]))

	createdAtStr := strings.TrimSpace(row[15])
	if len(createdAtStr) != 0 {
		formattedCreatedAt, err := utils.FormatDateTime(row[15])
		if err != nil {
			return resource, fmt.Errorf("invalid value for createdAt column,error: %v", err)
		}
		resource.CreatedAt = formattedCreatedAt
	}

	return resource, nil
}

func parseIntOrZero(value string) int {
	result, err := strconv.Atoi(value)
	if err != nil {
		return 0
	}
	return result
}

func parseBoolOrFalse(value string) bool {
	result, err := strconv.ParseBool(value)
	if err != nil {
		return false
	}
	return result
}

// func (e *AuxiliaryVideoCategoryController) assetUploadHelper(ctx context.Context, request AssetUploadRequest) (AssetUploadResponse, error) {
// 	var response AssetUploadResponse

// 	// if request.AssetFor == nil || *request.AssetFor != "icon" {
// 	// 	logger.Error(ctx, "invalid value for asset_for parameter (must be 'icon')")
// 	// 	return response, fmt.Errorf("invalid value for asset_for parameter (must be 'icon')")
// 	// }

// 	// Init active storage
// 	activeStorageService := activestorage.NewActiveStorageService(e.db)
// 	activeStorageInput := activestorage.ActiveStorageUploadInput{
// 		FileHeader:    request.AssetFile,
// 		ServiceName:   "S3",
// 		ModelType:     "resource_image",
// 		ModelId:       int64(*request.ResourceId),
// 		ContentType:   request.AssetFile.Header.Get("Content-Type"),
// 		AttachmentFor: *request.AssetFor,
// 	}

// 	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
// 	if err != nil {
// 		logger.Error(ctx, "error uploading file to S3", zap.Error(err))
// 		return response, err
// 	}

// 	fileUrl := activeStorageService.GetURL(*tempFileName)

// 	// 🔁 Fetch full category from DB
// 	// category, err := e.db.GetAuxiliaryCategoryByID(ctx, *request.ResourceId)
// 	// if err != nil {
// 	// 	logger.Error(ctx, "unable to fetch category from DB", zap.Error(err))
// 	// 	return response, fmt.Errorf("unable to fetch category with ID %d", *request.ResourceId)
// 	// }

// 	// // Update icon
// 	// category.Icon = &fileUrl
// 	// now := time.Now()
// 	// category.UpdatedAt = &now

// 	// // Save
// 	// if _, err := e.db.UpdateAuxiliaryCategory(ctx, category); err != nil {
// 	// 	logger.Error(ctx, "unable to update icon in DB", zap.Error(err))
// 	// 	return response, fmt.Errorf("unable to update icon")
// 	// }

// 	response.Path = fileUrl
// 	return response, nil
// }

func (r *resourceController) assetUploadHelper(ctx context.Context, request AssetUploadRequest) (AssetUploadResponse, error) {
	var response AssetUploadResponse

	assetForArr := []string{"icon", "podcast", "resource_image"}

	if !slices.Contains(assetForArr, *request.AssetFor) {
		logger.Error(ctx, "invalid value for asset_for parameter")
		return response, fmt.Errorf("invalid value for asset_for parameter, only 'icon' is allowed")
	}

	activeStorageService := activestorage.NewActiveStorageService(r.db)
	activeStorageInput := activestorage.ActiveStorageUploadInput{
		FileHeader:    request.AssetFile,
		ServiceName:   "S3",
		ModelType:     "resource",
		ModelId:       int64(*request.ResourceId),
		ContentType:   request.AssetFile.Header.Get("Content-Type"),
		AttachmentFor: *request.AssetFor,
	}

	if *request.AssetFor == "resource_image" {
		activeStorageInput.ModelType = "resource_image"
	}

	tempFileName, err := activeStorageService.UploadFile(ctx, activeStorageInput)
	if err != nil {
		logger.Error(ctx, "error received while processing in active storage service", zap.Error(err))
		return response, err
	}

	fileUrl := activeStorageService.GetURL(*tempFileName)

	resource := dbModel.Resource{
		ID: request.ResourceId,
	}

	forEmbeddedImage := false
	if *request.AssetFor == "podcast" {
		resource.URL = &fileUrl
	} else if *request.AssetFor == "icon" {
		resource.Icon = &fileUrl
	} else if *request.AssetFor == "resource_image" {
		forEmbeddedImage = true
	} else {
		logger.Error(ctx, "invalid value for asset_for parameter")
		return response, fmt.Errorf("invalid value for asset_for parameter")
	}

	fmt.Println("--------->", forEmbeddedImage)

	if !forEmbeddedImage {
		if _, err := r.db.UpdateResource(ctx, resource); err != nil {
			logger.Error(ctx, "unable to update file path in S3 for resource", zap.Error(err))
			return response, fmt.Errorf("unable to update file path in S3 for resource")
		}
	}

	response.Path = fileUrl
	return response, nil
}

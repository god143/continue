package resource

import (
	"encoding/json"
	"mime/multipart"
	"multipie_ilearn_go/internal/constants"
	"time"
)

type ResourceResult struct {
	ID             *int                        `json:"id,omitempty"`
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	CreatedAt      *time.Time                  `json:"created_at"`
	UpdatedAt      *time.Time                  `json:"updated_at"`
}

type GetResourceByIDRequest struct {
	ID int `uri:"resource_id" binding:"required"`
}

type GetResourcesByCategoryTypeRequest struct {
	CategoryID   int    `json:"category_id" binding:"required" form:"category_id"`
	ResourceType string `json:"resource_type" binding:"required" form:"resource_type"`
	SubType      string `json:"sub_type" form:"sub_type"`
	Page         int    `json:"page" form:"page"`
	PageSize     int    `json:"page_size" form:"page_size"`
	Filter       string `json:"filter" form:"filter"`
}

type DisableResourceRequest struct {
	ID int `json:"resource_id" binding:"required"`
}

type CreateResourceRequest struct {
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type" binding:"required"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	Content        *string                     `json:"content,omitempty"`
	CreatedAt      *time.Time                  `json:"created_at"`
}

type UpdateResourceRequest struct {
	ID             *int                        `json:"id"`
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	Content        *string                     `json:"content,omitempty"`
}

type CreateResourceResponse struct {
	ID int64 `json:"id"`
}

type AssetUploadRequest struct {
	ResourceId *int                  `form:"resource_id" binding:"required"`
	AssetFor   *string               `form:"asset_for" binding:"required"`
	AssetFile  *multipart.FileHeader `form:"asset_file" binding:"required"`
}

type AssetUploadResponse struct {
	Path string `json:"path"`
}

type CreateRelatedResourceRequest struct {
	ResourceID        int64 `json:"resource_id" binding:"required"`
	RelatedResourceID int64 `json:"related_resource_id" binding:"required"`
}

type DeleteRelatedResourceRequest struct {
	ResourceID        int64 `json:"resource_id" binding:"required"`
	RelatedResourceID int64 `json:"related_resource_id" binding:"required"`
}

package resource

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type resourceController struct {
	db db.DBLayer
}

type ResourceControllerGroup interface {
	GetResourceById(ctx *gin.Context)
	GetResourcesByCategoryType(ctx *gin.Context)
	DisableResource(ctx *gin.Context)
	CreateResource(ctx *gin.Context)
	UpdateResource(ctx *gin.Context)
	BatchCreateResources(ctx *gin.Context)
	BatchUpdateResources(ctx *gin.Context)
	ResourceAssetUpload(ctx *gin.Context)
}

func NewResourceControllerGroup(db db.DBLayer) ResourceControllerGroup {
	return &resourceController{
		db: db,
	}
}

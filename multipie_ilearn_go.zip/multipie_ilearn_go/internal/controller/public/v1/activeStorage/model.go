package activeStorage

type DownloadFileRequest struct {
	FileKey  string `uri:"file_key" binding:"required"`
	FileName string `uri:"file_name" binding:"required"`
}

package activeStorage

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type activeStorageController struct {
	db db.DBLayer
}

type ActiveStorageControllerGroup interface {
	DownloadFile(gin *gin.Context)
}

func NewActiveStorageControllerGroup(db db.DBLayer) ActiveStorageControllerGroup {
	return &activeStorageController{
		db: db,
	}
}

package activeStorage

import (
	"fmt"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (a *activeStorageController) DownloadFile(ctx *gin.Context) {
	var (
		request DownloadFileRequest
		resp    *utils.Response
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	activeStorageService := activestorage.NewActiveStorageService(a.db)
	input := activestorage.ActiveStorageDownloadInput{
		FileName: request.FileName,
		Filekey:  request.FileKey,
	}

	fileBytes, fileType, err := activeStorageService.DownloadFile(ctx, input)
	if err != nil {
		logger.Error(ctx, "error downloading the file from source", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("error downloading the file from source"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	contentDisposition := "attachment"
	if strings.HasPrefix(fileType, "text/html") {
		contentDisposition = "inline"
	}
	// if fileType == "" {
	// 	fileType = "application/octet-stream"
	// }
	// Set headers for file download
	ctx.Header("X-Accel-Buffering", "no")

	ctx.Header("Content-Length", fmt.Sprintf("%d", len(fileBytes)))
	ctx.Header("Content-Disposition", fmt.Sprintf("%s; filename=\"%s\"", contentDisposition, request.FileName))

	ctx.Data(http.StatusOK, fileType, fileBytes)
}

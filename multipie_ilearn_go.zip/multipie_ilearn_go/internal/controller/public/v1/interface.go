package v1

import (
	"multipie_ilearn_go/internal/controller/public/v1/activeStorage"
	"multipie_ilearn_go/internal/db"
)

type v1 struct {
	activeStorage.ActiveStorageControllerGroup
}

type V1ControllerLayer interface {
	activeStorage.ActiveStorageControllerGroup
}

func NewV1ControllerLayer(db db.DBLayer) V1ControllerLayer {
	return &v1{
		activeStorage.NewActiveStorageControllerGroup(db),
	}
}

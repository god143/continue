package public

import (
	v1 "multipie_ilearn_go/internal/controller/public/v1"
	"multipie_ilearn_go/internal/db"
)

type publicController struct {
	v1 v1.V1ControllerLayer
}

type PublicControllerLayer interface {
	GetV1ControllerLayer() v1.V1ControllerLayer
}

func NewControllerLayer(db db.DBLayer) PublicControllerLayer {
	return &publicController{
		v1.NewV1ControllerLayer(db),
	}
}

func (s *publicController) GetV1ControllerLayer() v1.V1ControllerLayer {
	return s.v1
}

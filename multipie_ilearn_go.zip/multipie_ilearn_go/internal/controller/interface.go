package controller

import (
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/controller/admin"

	"multipie_ilearn_go/internal/controller/public"
	v1 "multipie_ilearn_go/internal/controller/v1"
	"multipie_ilearn_go/internal/db"
)

type controller struct {
	v1     v1.V1ControllerLayer
	admin  admin.AdminControllerLayer
	public public.PublicControllerLayer
}

type ControllerLayer interface {
	GetV1ControllerLayer() v1.V1ControllerLayer
	GetAdminControllerLayer() admin.AdminControllerLayer
	GetPublicControllerLayer() public.PublicControllerLayer
}

func NewControllerLayer(db db.DBLayer, cfg *config.SecretConfig) ControllerLayer {
	return &controller{
		v1.NewV1ControllerLayer(db, cfg),
		admin.NewControllerLayer(db),
		public.NewControllerLayer(db),
	}
}

func (s *controller) GetV1ControllerLayer() v1.V1ControllerLayer {
	return s.v1
}

func (s *controller) GetAdminControllerLayer() admin.AdminControllerLayer {
	return s.admin
}

func (s *controller) GetPublicControllerLayer() public.PublicControllerLayer {
	return s.public
}

package health

import "github.com/gin-gonic/gin"

type health struct{}

type HeathGroup interface {
	HealthCheckHandler(*gin.Context)
	ProctectedRouteHandler(ctx *gin.Context)
}

func NewHealthGroup() HeathGroup {
	return &health{}
}

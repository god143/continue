package health

import (
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

func (h *health) HealthCheckHandler(ctx *gin.Context) {
	resp := utils.NewV1Response("pong", nil)
	ctx.JSON(http.StatusOK, resp)
}

func (h *health) ProctectedRouteHandler(ctx *gin.Context) {
	resp := utils.NewV1Response("i am proctected route", nil)
	ctx.JSON(http.StatusOK, resp)
}

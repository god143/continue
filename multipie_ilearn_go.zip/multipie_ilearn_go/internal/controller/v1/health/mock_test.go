package health

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

// --- Test Setup ---

func TestMain(m *testing.M) {
	gin.SetMode(gin.TestMode)
	m.Run()
}

// --- Unit Tests ---

func TestHealthCheckHandler(t *testing.T) {
	h := NewHealthGroup()

	t.Run("Success - Ping Pong", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		h.HealthCheckHandler(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "pong")
	})
}

func TestProtectedRouteHandler(t *testing.T) {
	h := NewHealthGroup()

	t.Run("Success - Access Protected", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		h.ProctectedRouteHandler(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "i am proctected route")
	})
}

// --- Benchmarks ---

func BenchmarkHealthCheckHandler(b *testing.B) {
	h := NewHealthGroup()
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.HealthCheckHandler(ctx)
		w.Body.Reset() // Prevent memory bloat from "pong" strings
	}
}

func BenchmarkProtectedRouteHandler(b *testing.B) {
	h := NewHealthGroup()
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.ProctectedRouteHandler(ctx)
		w.Body.Reset()
	}
}

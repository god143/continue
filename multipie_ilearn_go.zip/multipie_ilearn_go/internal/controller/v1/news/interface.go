package news

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type newsController struct {
	db db.DBLayer
}

type NewsControllerGroup interface {
	GetForYouStocks(ctx *gin.Context)
	GetTrendingNews(ctx *gin.Context)
}

func NewNewsGroup(db db.DBLayer) NewsControllerGroup {
	return &newsController{
		db: db,
	}
}

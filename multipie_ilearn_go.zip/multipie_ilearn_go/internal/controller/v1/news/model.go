package news

type GetTrendingNewsRequest struct {
	Page     int `json:"page" form:"page"`
	PageSize int `json:"page_size" form:"page_size"`
}

type Response struct {
	Data     []Holding    `json:"data"`
	Included []Instrument `json:"included"`
}

type Holding struct {
	ID            string               `json:"id"`
	Type          string               `json:"type"`
	Attributes    HoldingAttributes    `json:"attributes"`
	Relationships HoldingRelationships `json:"relationships"`
}

type HoldingAttributes struct {
	Quantity     string    `json:"quantity"`
	Cost         float64   `json:"cost"`
	OnDate       string    `json:"on_date"` // Use time.Time if parsing later
	CurrentValue float64   `json:"current_value"`
	DisplayName  string    `json:"display_name"`
	Identifier   string    `json:"identifier"`
	Type         string    `json:"type"`
	Price        float64   `json:"price"`
	GainsData    GainsData `json:"gains_data"`
}

type GainsData struct {
	DailyGains              float64 `json:"daily_gains"`
	DailyGainsPercentage    float64 `json:"daily_gains_percentage"`
	AbsoluteGains           float64 `json:"absolute_gains"`
	AbsoluteGainsPercentage float64 `json:"absolute_gains_percentage"`
}

type HoldingRelationships struct {
	Instrument RelationshipData `json:"instrument"`
}

type Instrument struct {
	ID            string                  `json:"id"`
	Type          string                  `json:"type"`
	Attributes    InstrumentAttributes    `json:"attributes"`
	Relationships InstrumentRelationships `json:"relationships"`
}

type InstrumentAttributes struct {
	Type        string `json:"type"`
	Identifier  string `json:"identifier"`
	ExtID       string `json:"ext_id"`
	ID          int    `json:"id"`
	OwnerID     int    `json:"owner_id"`
	LogoURL     string `json:"logo_url"`
	DisplayName string `json:"display_name"`
}

type InstrumentRelationships struct {
	Category RelationshipData `json:"category"`
	Owner    RelationshipData `json:"owner"`
}

type RelationshipData struct {
	Data struct {
		ID   string `json:"id"`
		Type string `json:"type"`
	} `json:"data"`
}

type RequestPayload struct {
	BucketID string `json:"BucketId"`
	PageNo   string `json:"pageno"`
	PageSize string `json:"pagesize"`
}

type ApiResponse struct {
	Type       interface{} `json:"Type"`
	IsSuccess  bool        `json:"IsSuccess"`
	Data       Data        `json:"Data"`
	Message    interface{} `json:"Message"`
	StatusCode int         `json:"StatusCode"`
}

type Data struct {
	Table  []Article     `json:"Table"`
	Table1 []PageMetrics `json:"Table1"`
	Table2 []ImageData   `json:"Table2"`
}

type Article struct {
	RowNo             float64     `json:"ROWNO"`
	ArticleID         float64     `json:"ARTICLE_ID"`
	Title             string      `json:"TITLE"`
	Link1             string      `json:"LINK1"`
	Exclusive1        interface{} `json:"EXCLUSIVE1"`
	SecName           interface{} `json:"SEC_NAME"`
	TypeTitle         interface{} `json:"TYPE_TITLE"`
	ThemeTitle        interface{} `json:"THEME_TITLE"`
	ThemeSlug         interface{} `json:"THEME_SLUG"`
	ShoulderTitle     interface{} `json:"SHOULDER_TITLE"`
	ShoulderLink      interface{} `json:"SHOULDER_LINK"`
	Highlight         interface{} `json:"HIGHLIGHT"`
	ExternalLink      interface{} `json:"EXTERNAL_LINK"`
	ThumbImage        interface{} `json:"THUMB_IMAGE"`
	ThumbImageCaption interface{} `json:"THUMB_IMAGE_CAPTION"`
	Description       interface{} `json:"DESCRIPTION"`
	IntName           interface{} `json:"INT_NAME"`
	IntDesignation    interface{} `json:"INT_DESIGNATION"`
	IntDepartment     interface{} `json:"INT_DEPARTMENT"`
	IntCompany        interface{} `json:"INT_COMPANY"`
	AuName            string      `json:"AU_NAME"`
	AuCompany         string      `json:"AU_COMPANY"`
	AuDesignation     interface{} `json:"AU_DESIGNATION"`
	SrcName           string      `json:"SRC_NAME"`
	LastModifiedOn    string      `json:"LAST_MODIFIED_ON"`
	PublishedOn       string      `json:"PUBLISHED_ON"`
	LenContent        interface{} `json:"LEN_CONTENT"`
	BlogName          interface{} `json:"BLOG_NAME"`
	Image             interface{} `json:"IMAGE"`
	DisplayTitle      interface{} `json:"DISPLAYTITLE"`
	CreatedOn         string      `json:"CREATED_ON"`
	CoCode            float64     `json:"CO_CODE"`
	LName             string      `json:"LNAME"`
	CoName            string      `json:"CONAME"`
	Change            float64     `json:"CHANGE"`
	ChangePerc        float64     `json:"CHANGE_PERC"`
	Exchange          string      `json:"EXCHANGE"`
	Isin              string      `json:"ISIN"`
	Ltp               float64     `json:"LTP"`
}

type PageMetrics struct {
	PageCount float64 `json:"PAGE_COUNT"`
	RowsCount float64 `json:"ROWS_COUNT"`
}

type ImageData struct {
	ArticleID         float64 `json:"ARTICLE_ID"`
	Predicate         string  `json:"PREDICATE"`
	Object1           string  `json:"OBJECT1"`
	ArticleCompanyCsv string  `json:"ARTICLE_COMPANY_CSV"`
	DbType            string  `json:"DB_TYPE"`
	Rank              float64 `json:"RANK"`
}

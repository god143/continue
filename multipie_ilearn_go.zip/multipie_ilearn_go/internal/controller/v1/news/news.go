package news

import (
	"bytes"
	"encoding/json"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"
	"slices"
	"strconv"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (n *newsController) GetForYouStocks(ctx *gin.Context) {
	var (
		// resp    *utils.Response
		request GetTrendingNewsRequest
	)

	// 1. Execute S2S Call for Holdings
	apiURL := constants.MULTIPIE_MY_HOLDINGS_URL
	bearerToken := ctx.Request.Header.Get("Authorization")

	fmt.Println("--------apiUrl-------> ", apiURL)

	req, err := http.NewRequest("GET", apiURL, nil)
	if err != nil {
		logger.Error(ctx, "failed to create holdings request", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("internal server error")))
		ctx.Abort()
		return
	}

	req.Header.Set("Authorization", "Bearer "+bearerToken)
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	response, err := client.Do(req)
	if err != nil {
		logger.Error(ctx, "holdings S2S call failed", zap.Error(err), zap.String("url", apiURL))
		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer("upstream service unavailable")))
		ctx.Abort()
		return
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		logger.Error(ctx, "holdings API returned non-200", zap.Int("status", response.StatusCode))
		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer("failed to fetch holdings")))
		ctx.Abort()
		return
	}

	var portfolio Response
	if err := json.NewDecoder(response.Body).Decode(&portfolio); err != nil {
		logger.Error(ctx, "failed to decode holdings response", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("data processing error")))
		ctx.Abort()
		return
	}

	// 2. Bind Query Params
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Warn(ctx, "invalid request query parameters", zap.Error(err))
		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer("invalid request parameters")))
		ctx.Abort()
		return
	}

	// 3. Prepare and Execute News S2S Call
	requestBody := RequestPayload{
		BucketID: constants.IDIRECT_NEWS_BUCKET_ID,
		PageNo:   strconv.Itoa(request.Page),
		PageSize: strconv.Itoa(request.PageSize),
	}

	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		logger.Error(ctx, "failed to marshal news request body", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("internal server error")))
		ctx.Abort()
		return
	}

	externalUrl := constants.IDIRECT_NEWS_URL
	req, err = http.NewRequest("POST", externalUrl, bytes.NewBuffer(jsonData))
	if err != nil {
		logger.Error(ctx, "failed to create news request", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("internal server error")))
		ctx.Abort()
		return
	}

	req.Header.Set("Authorization", "SUNJQ0lkOmFiYzEyMw==")
	req.Header.Set("Content-Type", "application/json")

	finalResp, err := client.Do(req)
	if err != nil {
		logger.Error(ctx, "news S2S call failed", zap.Error(err), zap.String("url", externalUrl))
		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer("news service unavailable")))
		ctx.Abort()
		return
	}
	defer finalResp.Body.Close()

	if finalResp.StatusCode != http.StatusOK {
		logger.Error(ctx, "news API returned non-200", zap.Int("status", finalResp.StatusCode))
		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer("failed to fetch news")))
		ctx.Abort()
		return
	}

	var finalResponse ApiResponse
	if err := json.NewDecoder(finalResp.Body).Decode(&finalResponse); err != nil {
		logger.Error(ctx, "failed to decode news response", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("data processing error")))
		ctx.Abort()
		return
	}

	// 4. Filter News based on Holdings
	identifierArr := []string{}
	for i := range portfolio.Data {
		identifierArr = append(identifierArr, portfolio.Data[i].Attributes.Identifier)
	}

	articleArr := []float64{}
	// Filter Table (News)
	for i := len(finalResponse.Data.Table) - 1; i >= 0; i-- {
		val := finalResponse.Data.Table[i]
		if !slices.Contains(identifierArr, val.Isin) {
			finalResponse.Data.Table = slices.Delete(finalResponse.Data.Table, i, i+1)
		} else {
			articleArr = append(articleArr, val.ArticleID)
		}
	}

	// Filter Table2 (Related data)
	for i := len(finalResponse.Data.Table2) - 1; i >= 0; i-- {
		if !slices.Contains(articleArr, finalResponse.Data.Table2[i].ArticleID) {
			finalResponse.Data.Table2 = slices.Delete(finalResponse.Data.Table2, i, i+1)
		}
	}

	logger.Info(ctx, "successfully fetched and filtered trending news",
		zap.Int("holdings_count", len(identifierArr)),
		zap.Int("news_count", len(finalResponse.Data.Table)))

	ctx.JSON(http.StatusOK, utils.NewV1Response(finalResponse, nil))
}

func (n *newsController) GetTrendingNews(ctx *gin.Context) {
	var (
		// resp    *utils.Response
		request GetTrendingNewsRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Warn(ctx, "invalid request query parameters", zap.Error(err))
		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer("invalid request parameters")))
		ctx.Abort()
		return
	}

	// 3. Prepare and Execute News S2S Call
	requestBody := RequestPayload{
		BucketID: constants.IDIRECT_NEWS_BUCKET_ID,
		PageNo:   strconv.Itoa(request.Page),
		PageSize: strconv.Itoa(request.PageSize),
	}

	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		logger.Error(ctx, "failed to marshal news request body", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("internal server error")))
		ctx.Abort()
		return
	}

	externalUrl := constants.IDIRECT_NEWS_URL
	req, err := http.NewRequest("POST", externalUrl, bytes.NewBuffer(jsonData))
	if err != nil {
		logger.Error(ctx, "failed to create news request", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("internal server error")))
		ctx.Abort()
		return
	}

	token := constants.IDIRECT_AUTH_TOKEN
	req.Header.Set("Authorization", token)
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	finalResp, err := client.Do(req)
	if err != nil {
		logger.Error(ctx, "news S2S call failed", zap.Error(err), zap.String("url", externalUrl))
		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer("news service unavailable")))
		ctx.Abort()
		return
	}
	defer finalResp.Body.Close()

	if finalResp.StatusCode != http.StatusOK {
		logger.Error(ctx, "news API returned non-200", zap.Int("status", finalResp.StatusCode))
		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer("failed to fetch news")))
		ctx.Abort()
		return
	}

	var finalResponse ApiResponse
	if err := json.NewDecoder(finalResp.Body).Decode(&finalResponse); err != nil {
		logger.Error(ctx, "failed to decode news response", zap.Error(err))
		ctx.JSON(http.StatusInternalServerError, utils.NewV1Response(nil, utils.StringToPointer("data processing error")))
		ctx.Abort()
		return
	}

	logger.Info(ctx, "successfully fetched trending news")

	ctx.JSON(http.StatusOK, utils.NewV1Response(finalResponse, nil))
}

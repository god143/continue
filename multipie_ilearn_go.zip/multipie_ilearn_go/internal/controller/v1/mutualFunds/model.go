package mutualFunds

// GET TOP PERFORMER LIST FILTERS

type TopPerformerListHeadingAPIResponse struct {
	IsSuccess  bool                     `json:"IsSuccess"`
	Data       []TopPerformerFilterData `json:"Data"`
	Message    string                   `json:"Message"`
	StatusCode int                      `json:"StatusCode"`
}

type TopPerformerFilterData struct {
	FundType        string `json:"FundType"`
	FundDisplayName string `json:"FundDisplayName"`
}

type TopPerformerFilterResponse struct {
	FundType        string   `json:"fundType"`
	FundDisplayName string   `json:"fundDisplayName"`
	Subcategories   []string `json:"subcategories"`
}

// GET TOP PERFORMER LIST ------------------------------------

type TopPerformerRequest struct {
	FundName string `json:"fundname" binding:"required"`
	FundType string `json:"fundtype" binding:"required"`
	Page     string `json:"page" binding:"required"`
	PageSize string `json:"page_size" binding:"required"`
}

type TopPerformerAPIRequest struct {
	FundName         string `json:"fundname"`
	FundType         string `json:"fundtype"`
	MFTerm           string `json:"mfterm"`
	OrganizationType string `json:"organizationtype"`
	PageNumber       string `json:"pagenumber"`
	PageSize         string `json:"pagesize"`
}

type TopPerformerAPIResponse struct {
	IsSuccess  bool             `json:"IsSuccess"`
	Data       TopPerformerData `json:"Data"`
	Message    string           `json:"Message"`
	StatusCode int              `json:"StatusCode"`
}

type TopPerformerData struct {
	Table []TopPerformerDataItem `json:"Table"`
}

type TopPerformerDataItem struct {
	Category    string  `json:"CATEGORY"`
	SubCategory string  `json:"SUB_CATEGORY"`
	SchemeCode  float32 `json:"SCHEMECODE"`
	SchemeName  string  `json:"SCHEME_NAME"`
	OneYear     string  `json:"ONEYEAR"`
	ThreeYear   string  `json:"THREEYEAR"`
	FiveYear    string  `json:"FIVEYEAR"`
}

type TopPerformer struct {
	ID         string                 `json:"id"`
	Attributes TopPerformerAttributes `json:"attributes"`
}

type TopPerformerAttributes struct {
	AMC            TopPerformerAMC      `json:"amc"`
	FundCategory   string               `json:"fund_category"`
	CategoryLevel1 string               `json:"category_level1"`
	MetaInfo       TopPerformerMetaInfo `json:"meta_info"`
}

type TopPerformerAMC struct {
	Name string `json:"name"`
}

type TopPerformerMetaInfo struct {
	Returns TopPerformerReturns `json:"returns"`
}

type TopPerformerReturns struct {
	OneYear   string `json:"mutualFundsReturnFor1Year"`
	ThreeYear string `json:"mutualFundsReturnFor3Year"`
	FiveYear  string `json:"mutualFundsReturnFor5Year"`
}

// GET MF DETAILS -------------------------------

type MFDetailsRequest struct {
	SchemeCode string `uri:"schemecode" binding:"required"`
	PageSize   string `json:"pageSize"`
}

// 1. SCHEME INFO

type SchemeInfoRequest struct {
	SchemeCode string `json:"schemecode" binding:"required"`
}

type SchemeInfoAPIResponse struct {
	IsSuccess  bool           `json:"IsSuccess"`
	Data       SchemeInfoData `json:"Data"`
	Message    string         `json:"Message"`
	StatusCode int            `json:"StatusCode"`
}

type SchemeInfoData struct {
	Table []SchemeInfoDataItem `json:"Table"`
}

type SchemeInfoDataItem struct {
	SchemeCode      float64 `json:"SCHEMECODE"`
	SchemeName      string  `json:"SCHEME_NAME"`
	RiskLevel       string  `json:"RISK_LEVEL"`
	SchemeCategory  string  `json:"SCHEME_CATEGORY"`
	SubCategoryName string  `json:"SUB_CATEGORY_NAME"`
	ExpenseRatio    string  `json:"EXPENSE_RATIO"`
	SchemeAUM       string  `json:"SCHEME_AUM"`
	MinInvt         string  `json:"MININVT"`
	MinInvtSIP      string  `json:"MININVTSIP"`
	FundManager     string  `json:"FUND_MGR"`
}

type SchemeInfo struct {
	SchemeCode      float64 `json:"schemeCode"`
	SchemeName      string  `json:"schemeName"`
	RiskLevel       string  `json:"riskLevel"`
	SchemeCategory  string  `json:"schemeCategory"`
	SubCategoryName string  `json:"subCategoryName"`
	ExpenseRatio    float64 `json:"expenseRatio"`
	SchemeAUM       float64 `json:"schemeAUM"`
	MinInvt         float64 `json:"minInvestment"`
	MinInvtSIP      float64 `json:"minInvestmentSIP"`
	FundManager     string  `json:"fundManager"`
}

// 2. PERIOD RETURNS / PERFORMANCE

type PeriodReturnsRequest struct {
	SchemeCode string `json:"schemeCode"`
}

type PeriodReturnsAPIResponse struct {
	IsSuccess  bool              `json:"IsSuccess"`
	Data       PeriodReturnsData `json:"Data"`
	Message    string            `json:"Message"`
	StatusCode int               `json:"StatusCode"`
}

type PeriodReturnsData struct {
	Table []PeriodReturnsDataItem `json:"Table"`
}

type PeriodReturnsDataItem struct {
	Name      string `json:"NAME"`
	OneYear   string `json:"ONEYEAR"`
	ThreeYear string `json:"THREEYEAR"`
	FiveYear  string `json:"FIVEYEAR"`
}

// 3. PEER COMPARISON

type PeerComparisonRequest struct {
	MFSchemeCode string `json:"mfschemecode"`
	PageSize     string `json:"pagesize"`
}

type PeerComparisonAPIResponse struct {
	IsSuccess  bool               `json:"IsSuccess"`
	Data       PeerComparisonData `json:"Data"`
	Message    string             `json:"Message"`
	StatusCode int                `json:"StatusCode"`
}

type PeerComparisonData struct {
	Table []PeerComparisonDataItem `json:"Table"`
}

type PeerComparisonDataItem struct {
	SchName string   `json:"SCH_NAME"`
	Ret1Y   *float64 `json:"RET_1Y"`
	Ret3Y   *float64 `json:"RET_3Y"`
	Ret5Y   *float64 `json:"RET_5Y"`
}

// 4. SECTOR ALLOCATION
type SectorAllocationRequest struct {
	SchemeCode string `json:"schemeCode"`
}

type SectorAllocationAPIResponse struct {
	IsSuccess  bool                 `json:"IsSuccess"`
	Data       SectorAllocationData `json:"Data"`
	Message    string               `json:"Message"`
	StatusCode int                  `json:"StatusCode"`
}

type SectorAllocationData struct {
	Table []SectorAllocationDataItem `json:"Table"`
}

type SectorAllocationDataItem struct {
	Sector     string `json:"SECTOR"`
	HoldingPer string `json:"HOLDING_PER"`
}

// 5. TOP HOLDINGS
type TopHoldingsRequest struct {
	SchemeCode string `json:"schemecode"`
}

type TopHoldingsAPIResponse struct {
	IsSuccess  bool            `json:"IsSuccess"`
	Data       TopHoldingsData `json:"Data"`
	Message    string          `json:"Message"`
	StatusCode int             `json:"StatusCode"`
}

type TopHoldingsData struct {
	Table []TopHoldingsDataItem `json:"Table"`
}

type TopHoldingsDataItem struct {
	LName      string `json:"LNAME"`
	PortWeight string `json:"PORTWEIGHT"`
}

// FINAL RESPONSE - GET MF DETAILS

type MFDetailsResponse struct {
	Data     []MFDetailsData     `json:"data"`
	Included []MFDetailsIncluded `json:"included"`
}
type MFDetailsData struct {
	ID            string                 `json:"id"`
	Type          string                 `json:"type"`
	Attributes    MFDetailsAttributes    `json:"attributes"`
	Relationships MFDetailsRelationships `json:"relationships"`
}

type MFDetailsRelationships struct {
	FundValueInfo FundValueInfoRelationship `json:"fund_value_info"`
}

type FundValueInfoRelationship struct {
	Data FundValueInfoRelationshipData `json:"data"`
}

type FundValueInfoRelationshipData struct {
	ID   string `json:"id"`
	Type string `json:"type"`
}

type MFDetailsIncluded struct {
	ID         string                 `json:"id"`
	Type       string                 `json:"type"`
	Attributes MFDetailsIncludedAttrs `json:"attributes"`
}

type MFDetailsAttributes struct {
	AMC                MFDetailsAMC        `json:"amc"`
	FundCategory       string              `json:"fund_category"`
	Risk               string              `json:"risk"`
	CategoryLevel1     string              `json:"category_level1"`
	MetaInfo           MFDetailsMetaInfo   `json:"meta_info"`
	PeerReturns        []PeerReturn        `json:"peer_returns"`
	InstrumentHoldings []InstrumentHolding `json:"instrument_holdings"`
	InstrumentSectors  []InstrumentSector  `json:"instrument_sectors"`
	FundManagers       []string            `json:"fund_managers"`
}

type MFDetailsIncludedAttrs struct {
	ExpenseRatio float64 `json:"expense_ratio"`
	FundSize     float64 `json:"fund_size"`
	MinLumpsum   float64 `json:"min_lumpsum"`
	MinSIP       float64 `json:"min_sip"`
}

type MFDetailsAMC struct {
	Name string `json:"name"`
}

type MFDetailsMetaInfo struct {
	Returns MFDetailsReturns `json:"returns"`
}

type MFDetailsReturns struct {
	OneYear   float64 `json:"mutualFundsReturnFor1Year"`
	ThreeYear float64 `json:"mutualFundsReturnFor3Year"`
	FiveYear  float64 `json:"mutualFundsReturnFor5Year"`
}

type PeerReturn struct {
	// ID          string           `json:"id"`
	DisplayName string           `json:"display_name"`
	Returns     MFDetailsReturns `json:"returns"`
}

type InstrumentHolding struct {
	// ID     string  `json:"id"`
	Name   string  `json:"name"`
	Weight float64 `json:"weight"`
}

type InstrumentSector struct {
	Label  string  `json:"label"`
	Weight float64 `json:"weight"`
}

package mutualFunds

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type mutualFunds struct {
	db db.DBLayer
}

type MutualFundsControllerGroup interface {
	GetTopPerformers(*gin.Context)
	GetTopPerformerListFilters(*gin.Context)
	GetMFDetails(*gin.Context)
}

func NewMutualFundsGroup(db db.DBLayer) MutualFundsControllerGroup {
	return &mutualFunds{
		db: db,
	}
}

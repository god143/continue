package mutualFunds

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
)

// GET TOP PERFORMER FILTERS
func (n *mutualFunds) GetTopPerformerListFilters(ctx *gin.Context) {

	token := constants.IDIRECT_TOKEN_TOP_PERFORMER_MUTUAL_FUNDS

	if token == "" {
		ctx.JSON(http.StatusUnauthorized, utils.NewV1Response(nil, utils.StringToPointer("authorization token is required")))
		ctx.Abort()
		return
	}

	result, err := n.GetTopPerformerListFiltersHelper(ctx, token)

	if err != nil {
		logger.Error(ctx, "failed to fetch top performer filters", zap.Error(err))

		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer(err.Error())))
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(result, nil))
}

// GET TOP PERFORMER LIST
func (n *mutualFunds) GetTopPerformers(ctx *gin.Context) {

	var request TopPerformerRequest

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Warn(ctx, "invalid top performer request", zap.Error(err))

		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer("invalid request parameters")))
		ctx.Abort()
		return
	}

	token := constants.IDIRECT_TOKEN_TOP_PERFORMER_MUTUAL_FUNDS

	if token == "" {
		ctx.JSON(http.StatusUnauthorized, utils.NewV1Response(nil, utils.StringToPointer("authorization token is required")))
		ctx.Abort()
		return
	}

	result, err := n.GetTopPerformersHelper(ctx, request, token)

	if err != nil {
		logger.Error(ctx, "failed to fetch top performers", zap.Error(err))

		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer(err.Error())))
		ctx.Abort()
		return
	}

	ctx.JSON(
		http.StatusOK,
		utils.NewV1Response(result, nil),
	)
}

// GET MF DETAILS

func (n *mutualFunds) GetMFDetails(ctx *gin.Context) {

	var request MFDetailsRequest

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Warn(ctx, "invalid MF details request", zap.Error(err))

		if request.PageSize == "" {
			request.PageSize = "10"
		}

		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer("invalid request parameters")))
		ctx.Abort()
		return
	}

	if request.SchemeCode == "" {
		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer("schemecode is required")))
		ctx.Abort()
		return
	}

	token := constants.IDIRECT_TOKEN_MUTUAL_FUNDS

	if token == "" {
		ctx.JSON(http.StatusUnauthorized, utils.NewV1Response(nil, utils.StringToPointer("authorization token is required")))
		ctx.Abort()
		return
	}
	log.Println("Call b4 helper")

	result, included, err := n.GetMFDetailsHelper(ctx, request, token)
	log.Printf("Call af helper %+v : ", result)

	if err != nil {
		logger.Error(ctx, "failed to fetch MF details", zap.Error(err))

		ctx.JSON(http.StatusBadGateway, utils.NewV1Response(nil, utils.StringToPointer(err.Error())))
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1ResponseWithIncluded(result, included, nil))

	log.Println("Function completes for mF")
}

package mutualFunds

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"multipie_ilearn_go/internal/constants"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"

	"multipie_ilearn_go/internal/logger"
)

var iDirectHTTPClient = &http.Client{
	Timeout: 30 * time.Second,
}

func callIDirectAPI(ctx *gin.Context, requestCtx context.Context, url string, token string, requestBody interface{}, responseBody interface{}) error {

	startTime := time.Now()
	var body *bytes.Reader

	if requestBody != nil {

		jsonData, err := json.Marshal(requestBody)
		if err != nil {
			logger.Error(ctx, "failed to marshal upstream request", zap.Error(err))

			return fmt.Errorf("failed to marshal request: %w", err)
		}
		body = bytes.NewReader(jsonData)
	} else {
		body = bytes.NewReader([]byte{})
	}

	req, err := http.NewRequestWithContext(requestCtx, http.MethodPost, url, body)
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Authorization", token)
	req.Header.Set("Content-Type", "application/json")

	response, err := iDirectHTTPClient.Do(req)
	if err != nil {
		if errors.Is(err, context.Canceled) {
			return fmt.Errorf("upstaream API request cancelled")
		}

		if errors.Is(err, context.DeadlineExceeded) {
			return fmt.Errorf("upstream API request timeout")
		}

		return fmt.Errorf("upstream service unavailble:%w", err)
	}

	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {

		body, _ := io.ReadAll(response.Body)

		logger.Error(ctx, "upstream API returned non-200", zap.String("url", url), zap.Int("status", response.StatusCode), zap.String("response", string(body)), zap.Duration("time taken ", time.Since(startTime)))

		return fmt.Errorf(
			"upstream API returned status code %d",
			response.StatusCode,
		)
	}

	if err := json.NewDecoder(response.Body).Decode(responseBody); err != nil {
		return fmt.Errorf("failed to decode upstream response: %w", err)
	}

	return nil
}

// Get Top Performer List Filters ------------------------------------------------------------------------------------------------

// Subcategory mapping for each fund type
var subCategoryMapping = map[string][]string{
	"EQUITY": {
		"All",
		"Multi Cap Fund",
		"Large Cap Fund",
		"Large & Mid Cap Fund",
		"Mid Cap Fund",
		"Small Cap Fund",
		"Dividend Yield Fund",
		"Value Fund",
		"Contra Fund",
		"Focused Fund",
		"Sectoral/ Thematic",
	},

	"HYBRID": {
		"All",
		"Conservative Hybrid Fund",
		"Aggressive Hybrid Fund",
		"Dynamic Asset Allocation or Balance Advantage",
		"Multi Asset Allocation",
		"Arbitrage Fund",
		"Equity Savings",
	},

	"ELSS": {
		"All",
		"ELSS",
	},

	"ETFS": {
		"All",
		"Retirement Fund",
		"Childrens Fund",
	},
}

func (n *mutualFunds) GetTopPerformerListFiltersHelper(ctx *gin.Context, token string) ([]TopPerformerFilterResponse, error) {

	var response TopPerformerListHeadingAPIResponse

	err := callIDirectAPI(ctx, ctx.Request.Context(), constants.IDIRECT_TOP_PERFORMER_FILTERS_URL, token, nil, &response)

	if err != nil {
		return nil, err
	}

	if !response.IsSuccess {
		return nil, fmt.Errorf("top performer filters API failed: %s", response.Message)
	}

	result := make([]TopPerformerFilterResponse, 0, len(response.Data))

	for _, heading := range response.Data {

		fundType := strings.ToUpper(heading.FundType)

		subCategories := subCategoryMapping[fundType]

		result = append(result, TopPerformerFilterResponse{
			FundType:        heading.FundType,
			FundDisplayName: heading.FundDisplayName,
			Subcategories:   subCategories,
		})
	}

	return result, nil
}

// Get Top Performer List ------------------------------------------------------------------------------------------------

func (n *mutualFunds) GetTopPerformersHelper(ctx *gin.Context, request TopPerformerRequest, token string) ([]TopPerformer, error) {

	var response TopPerformerAPIResponse

	upstreamRequest := TopPerformerAPIRequest{
		FundName:         request.FundName,
		FundType:         request.FundType,
		MFTerm:           "L",
		OrganizationType: "crisil",
		PageNumber:       request.Page,
		PageSize:         request.PageSize,
	}

	err := callIDirectAPI(ctx, ctx.Request.Context(), constants.IDIRECT_TOP_PERFORMER_URL, token, upstreamRequest, &response)

	if err != nil {
		return nil, err
	}

	if !response.IsSuccess {
		return nil, fmt.Errorf("top performer API failed: %s", response.Message)
	}

	result := make([]TopPerformer, 0, len(response.Data.Table))

	for _, fund := range response.Data.Table {

		result = append(result, TopPerformer{
			ID: strconv.FormatInt(int64(fund.SchemeCode), 10),

			Attributes: TopPerformerAttributes{
				AMC: TopPerformerAMC{
					Name: fund.SchemeName,
				},

				FundCategory: fund.SubCategory,

				CategoryLevel1: fund.Category,

				MetaInfo: TopPerformerMetaInfo{
					Returns: TopPerformerReturns{
						OneYear:   fund.OneYear,
						ThreeYear: fund.ThreeYear,
						FiveYear:  fund.FiveYear,
					},
				},
			},
		})
	}

	return result, nil
}

// Get MF details  ----------------------------------------------------------------------------------------------------------------

func (n *mutualFunds) GetMFDetailsHelper(ctx *gin.Context, request MFDetailsRequest, token string) (*MFDetailsData, []MFDetailsIncluded, error) {

	startTime := time.Now()

	requestCtx, cancel := context.WithCancel(ctx.Request.Context())
	defer cancel()

	var (
		schemeInfoResponse       SchemeInfoAPIResponse
		periodReturnsResponse    PeriodReturnsAPIResponse
		peerComparisonResponse   PeerComparisonAPIResponse
		sectorAllocationResponse SectorAllocationAPIResponse
		topHoldingsResponse      TopHoldingsAPIResponse
	)
	var wg sync.WaitGroup

	errChan := make(chan error, 5)
	wg.Add(5)

	//1. Scheme Info Request
	schemeInfoRequest := SchemeInfoRequest{
		SchemeCode: request.SchemeCode,
	}

	// 2. Period Returns Request
	periodReturnsRequest := PeriodReturnsRequest{
		SchemeCode: request.SchemeCode,
	}

	// 3. Peer Comparison Request
	peerComparisonRequest := PeerComparisonRequest{
		MFSchemeCode: request.SchemeCode,
		PageSize:     "10",
	}

	// 4. Sector Allocation Request
	sectorAllocationRequest := SectorAllocationRequest{
		SchemeCode: request.SchemeCode,
	}

	// 5. Top Holdings Request
	topHoldingsRequest := TopHoldingsRequest{
		SchemeCode: request.SchemeCode,
	}

	//Concurrent API Calls
	go func() {
		defer wg.Done()
		startTime := time.Now()
		err := n.getIDirectSchemeInfo(ctx, requestCtx, schemeInfoRequest, token, &schemeInfoResponse)

		logger.Info(ctx, "scheme info api takes ", zap.Duration("time to fetch data ", time.Since(startTime)))

		if err != nil {
			logger.Error(ctx, "scheme info api  failed")
			cancel()
			errChan <- fmt.Errorf("scheme info API failed: %w", err)
			return

		}

	}()

	go func() {
		defer wg.Done()
		startTime := time.Now()
		err := n.getIDirectPeriodReturns(ctx, requestCtx, periodReturnsRequest, token, &periodReturnsResponse)

		logger.Info(ctx, "period return/performance API takes ", zap.Duration("time to fetch data ", time.Since(startTime)))

		if err != nil {
			logger.Error(ctx, "period return/performance API  failed")
			cancel()
			errChan <- fmt.Errorf("period return/performance API failed: %w", err)
			return

		}
	}()

	go func() {
		defer wg.Done()
		startTime := time.Now()
		err := n.getIDirectPeerComparison(ctx, requestCtx, peerComparisonRequest, token, &peerComparisonResponse)

		logger.Info(ctx, "peer comparison API takes ", zap.Duration("time to fetch data ", time.Since(startTime)))

		if err != nil {
			logger.Error(ctx, "peer comparison API   failed")
			cancel()
			errChan <- fmt.Errorf("peer comparison API failed: %w", err)
			return

		}

	}()

	go func() {
		defer wg.Done()
		startTime := time.Now()
		err := n.getIDirectSectorAllocation(ctx, requestCtx, sectorAllocationRequest, token, &sectorAllocationResponse)

		logger.Info(ctx, "sector allocation API  takes ", zap.Duration("time to fetch data ", time.Since(startTime)))

		if err != nil {
			logger.Error(ctx, "sector allocation API  failed")
			cancel()
			errChan <- fmt.Errorf("sector allocation API failed: %w", err)
			return
		}

	}()

	go func() {
		defer wg.Done()
		startTime := time.Now()
		err := n.getIDirectTopHoldings(ctx, requestCtx, topHoldingsRequest, token, &topHoldingsResponse)

		logger.Info(ctx, "Top Holdings API takes ", zap.Duration("time to fetch data ", time.Since(startTime)))

		if err != nil {
			logger.Error(ctx, "Top Holdings API failed")
			cancel()
			errChan <- fmt.Errorf("Top Holdings API failed: %w", err)
			return
		}

	}()

	wg.Wait()
	close(errChan)

	logger.Info(ctx, "MF details api takes total ", zap.Duration("time to fetch data ", time.Since(startTime)))

	for err := range errChan {
		if err != nil {
			logger.Error(ctx, "MF details upstream API failed", zap.Error(err))
			return nil, nil, err
		}
	}

	// MAP SCHEME INFO

	if len(schemeInfoResponse.Data.Table) == 0 {
		return nil, nil, fmt.Errorf("scheme information not found")
	}

	scheme := schemeInfoResponse.Data.Table[0]

	schemeCode := scheme.SchemeCode

	// MAP RETURNS
	var returns MFDetailsReturns

	if len(periodReturnsResponse.Data.Table) > 0 {

		item := periodReturnsResponse.Data.Table[0]

		returns = MFDetailsReturns{
			OneYear:   pasrseFloat(item.OneYear),
			ThreeYear: pasrseFloat(item.ThreeYear),
			FiveYear:  pasrseFloat(item.FiveYear),
		}
	}

	// MAP PEER RETURNS

	peerReturns := make([]PeerReturn, 0, len(peerComparisonResponse.Data.Table))

	for _, item := range peerComparisonResponse.Data.Table {

		peerReturns = append(peerReturns, PeerReturn{
			// ID:          strconv.FormatInt(int64(schemeCode), 10),
			DisplayName: item.SchName,
			Returns: MFDetailsReturns{
				OneYear:   getFloatValue(item.Ret1Y),
				ThreeYear: getFloatValue(item.Ret3Y),
				FiveYear:  getFloatValue(item.Ret5Y),
			},
		})
	}

	// MAP INSTRUMENT HOLDINGS

	instrumentHoldings := make(
		[]InstrumentHolding,
		0,
		len(topHoldingsResponse.Data.Table),
	)

	for _, item := range topHoldingsResponse.Data.Table {

		instrumentHoldings = append(
			instrumentHoldings,
			InstrumentHolding{
				// ID:     strconv.FormatInt(int64(schemeCode), 10),
				Name:   item.LName,
				Weight: pasrseFloat(item.PortWeight),
			},
		)
	}

	// MAP INSTRUMENT SECTORS
	instrumentSectors := make(
		[]InstrumentSector,
		0,
		len(sectorAllocationResponse.Data.Table),
	)

	for _, item := range sectorAllocationResponse.Data.Table {

		instrumentSectors = append(
			instrumentSectors,
			InstrumentSector{
				Label:  item.Sector,
				Weight: pasrseFloat(item.HoldingPer),
			},
		)
	}

	fundManagers := make([]string, 0)

	if scheme.FundManager != "" {
		fundManagers = append(
			fundManagers,
			scheme.FundManager,
		)
	}

	// FINAL RESPONSE
	result := &MFDetailsData{

		ID:   strconv.FormatInt(int64(schemeCode), 10),
		Type: "mutual_fund",

		Attributes: MFDetailsAttributes{

			AMC: MFDetailsAMC{
				Name: scheme.SchemeName,
			},

			FundCategory:   scheme.SubCategoryName,
			Risk:           scheme.RiskLevel,
			CategoryLevel1: strings.TrimSpace(scheme.SchemeCategory),

			MetaInfo: MFDetailsMetaInfo{
				Returns: returns,
			},

			PeerReturns:        peerReturns,
			InstrumentHoldings: instrumentHoldings,
			InstrumentSectors:  instrumentSectors,
			FundManagers:       fundManagers,
		},

		Relationships: MFDetailsRelationships{
			FundValueInfo: FundValueInfoRelationship{
				Data: FundValueInfoRelationshipData{
					ID:   strconv.FormatInt(int64(schemeCode), 10),
					Type: "fund_value_info",
				},
			},
		},
	}

	included := []MFDetailsIncluded{
		{

			ID:   strconv.FormatInt(int64(schemeCode), 10),
			Type: "fund_value_info",
			Attributes: MFDetailsIncludedAttrs{
				ExpenseRatio: pasrseFloat(scheme.ExpenseRatio),
				FundSize:     pasrseFloat(scheme.SchemeAUM),
				MinLumpsum:   pasrseFloat(scheme.MinInvt),
				MinSIP:       pasrseFloat(scheme.MinInvtSIP),
			},
		},
	}

	return result, included, nil
}

func pasrseFloat(value string) float64 {
	value = strings.TrimSpace(value)
	if value == "" {
		return 0.00
	}

	result, err := strconv.ParseFloat(value, 64)
	if err != nil {
		return 0.00
	}

	return result
}

func getFloatValue(value *float64) float64 {
	if value == nil {
		return 0.00
	}

	return math.Round(*value*100) / 100
}

// upstream api functions ----------------------------------------------------------------------------------------------------

func (n *mutualFunds) getIDirectSchemeInfo(ctx *gin.Context, requestCtx context.Context, request SchemeInfoRequest, token string, response *SchemeInfoAPIResponse,
) error {
	return callIDirectAPI(ctx, requestCtx, constants.IDIRECT_GET_SCHEME_INFO_URL, token, request, response)
}

func (n *mutualFunds) getIDirectPeriodReturns(ctx *gin.Context, requestCtx context.Context, request PeriodReturnsRequest, token string, response *PeriodReturnsAPIResponse,
) error {
	return callIDirectAPI(ctx, requestCtx, constants.IDIRECT_GET_PERFORMANCE_URL, token, request, response)
}

func (n *mutualFunds) getIDirectPeerComparison(ctx *gin.Context, requestCtx context.Context, request PeerComparisonRequest, token string, response *PeerComparisonAPIResponse,
) error {
	return callIDirectAPI(ctx, requestCtx, constants.IDIRECT_GET_PEER_COMPARISON_URL, token, request, response)
}

func (n *mutualFunds) getIDirectSectorAllocation(ctx *gin.Context, requestCtx context.Context, request SectorAllocationRequest, token string, response *SectorAllocationAPIResponse,
) error {
	return callIDirectAPI(ctx, requestCtx, constants.IDIRECT_GET_SECTOR_ALLOCATION_URL, token, request, response)
}

func (n *mutualFunds) getIDirectTopHoldings(ctx *gin.Context, requestCtx context.Context, request TopHoldingsRequest, token string, response *TopHoldingsAPIResponse,
) error {
	return callIDirectAPI(ctx, requestCtx, constants.IDIRECT_GET_TOP_HOLDINGS_URL, token, request, response)
}

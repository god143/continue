package activitytracker

import (
	"context"
	"errors"
	"strconv"
	"strings"

	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/activityTracking"

	"github.com/gin-gonic/gin"
)

func (u *activityTrackerController) validateAndCreateActivity(ctx context.Context, request CreateActivityRequest, userID int64) (dbModel.UserActivity, error) {
	var modelTypeEnum constants.ActivityModelTypeEnum
	if err := modelTypeEnum.Set(request.ModelType); err != nil || !modelTypeEnum.IsValid() {
		return dbModel.UserActivity{}, errors.New("invalid model type")
	}

	switch modelTypeEnum {
	case constants.ActivityModelTypeEnumCourseModule:
		return u.handleCourseModuleActivity(ctx, request, userID)
	case constants.ActivityModelTypeEnumResource:
		return u.handleResourceActivity(ctx, request, userID)
	default:
		return dbModel.UserActivity{}, errors.New("invalid model type")
	}
}

func (u *activityTrackerController) handleResourceActivity(ctx context.Context, request CreateActivityRequest, userID int64) (dbModel.UserActivity, error) {
	existingActivity, err := u.db.GetActivityByUserIDAndResourceID(ctx, userID, request.ModelID)
	if err != nil && err.Error() != "activity not found" {
		return dbModel.UserActivity{}, errors.New("error checking existing resource activity")
	}

	if existingActivity != nil {
		return u.updateActivityHelper(ctx, *existingActivity, request)
	}

	return u.createActivityHelper(ctx, request, userID)
}

func (u *activityTrackerController) handleCourseModuleActivity(ctx context.Context, request CreateActivityRequest, userID int64) (dbModel.UserActivity, error) {
	existingActivity, err := u.db.GetActivityByUserIDAndCourseModuleID(ctx, userID, request.ModelID)
	if err != nil && err.Error() != "activity not found" {
		return dbModel.UserActivity{}, errors.New("error checking existing module activity")
	}

	if existingActivity != nil {
		return u.updateActivityHelper(ctx, *existingActivity, request)
	}

	return u.createActivityHelper(ctx, request, userID)
}

func (u *activityTrackerController) updateActivityHelper(ctx context.Context, existingActivity dbModel.UserActivity, request CreateActivityRequest) (dbModel.UserActivity, error) {
	if existingActivity.UserID == nil {
		return dbModel.UserActivity{}, errors.New("user ID is missing in existing activity")
	}

	updatedActivity := dbModel.UserActivity{
		ID:             existingActivity.ID,
		ActivityStatus: request.ActivityStatus,
		AdditionalData: request.AdditionalData,
		ResourceID:     existingActivity.ResourceID,
		CourseModuleID: existingActivity.CourseModuleID,
	}

	updatedActivityRecord, err := u.db.UpdateUserActivityRecord(ctx, updatedActivity, *existingActivity.UserID)
	if err != nil {
		return dbModel.UserActivity{}, errors.New("unable to update activity record")
	}

	return *updatedActivityRecord, nil
}

func (u *activityTrackerController) createActivityHelper(ctx context.Context, request CreateActivityRequest, userID int64) (dbModel.UserActivity, error) {
	var modelTypeEnum constants.ActivityModelTypeEnum
	if err := modelTypeEnum.Set(request.ModelType); err != nil || !modelTypeEnum.IsValid() {
		return dbModel.UserActivity{}, errors.New("invalid model type")
	}

	activity := dbModel.UserActivity{
		AdditionalData: request.AdditionalData,
		ActivityStatus: request.ActivityStatus,
		UserID:         &userID,
	}

	switch modelTypeEnum {
	case constants.ActivityModelTypeEnumCourseModule:
		activity.CourseModuleID = &request.ModelID
	case constants.ActivityModelTypeEnumResource:
		activity.ResourceID = &request.ModelID
	default:
		return dbModel.UserActivity{}, errors.New("invalid model type")
	}

	createdActivity, err := u.db.CreateUserActivityRecord(ctx, activity, userID)
	if err != nil {
		return dbModel.UserActivity{}, errors.New("unable to create activity record")
	}

	return *createdActivity, nil
}

func (u *activityTrackerController) validateAndGetActivity(ctx *gin.Context, request GetActivityRequest, userID int64) ([]dbModel.UserActivityResponse, error) {
	var modelTypeEnum constants.ActivityModelTypeEnum
	if err := modelTypeEnum.Set(request.ModelType); err != nil || !modelTypeEnum.IsValid() {
		return nil, errors.New("invalid model type")
	}

	modelIDs := []int64{}
	for _, str := range strings.Split(request.ModelID, ",") {
		modelID, err := strconv.ParseInt(str, 10, 64)
		if err != nil {
			return nil, errors.New("invalid modelID format")
		}
		modelIDs = append(modelIDs, modelID)
	}

	switch modelTypeEnum {
	case constants.ActivityModelTypeEnumCourse:
		return u.getActivityByCourse(ctx, modelIDs, userID)
	case constants.ActivityModelTypeEnumCourseModule:
		return u.getActivityByCourseModules(ctx, modelIDs, userID)
	case constants.ActivityModelTypeEnumResource:
		return u.getActivityByResources(ctx, modelIDs, userID)
	default:
		return nil, errors.New("invalid modelType")
	}
}

func (u *activityTrackerController) getActivityByCourse(ctx context.Context, courseIDs []int64, userID int64) ([]dbModel.UserActivityResponse, error) {
	return u.db.GetActivitiesByUserIDAndCourseIDs(ctx, userID, courseIDs)
}

func (u *activityTrackerController) getActivityByCourseModules(ctx context.Context, courseModuleIDs []int64, userID int64) ([]dbModel.UserActivityResponse, error) {
	return u.db.GetActivitiesByUserIDAndCourseModuleIDs(ctx, userID, courseModuleIDs)
}

func (u *activityTrackerController) getActivityByResources(ctx context.Context, resourceIDs []int64, userID int64) ([]dbModel.UserActivityResponse, error) {
	return u.db.GetActivitiesByUserIDAndResourceIDs(ctx, userID, resourceIDs)
}

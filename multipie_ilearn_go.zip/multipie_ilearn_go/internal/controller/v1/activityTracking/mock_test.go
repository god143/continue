package activitytracker

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/activityTracking"
	dbModelCoursecontent "multipie_ilearn_go/internal/db/courseContent"
	"multipie_ilearn_go/internal/logger"

	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) CreateUserActivityRecord(ctx context.Context, activity dbModel.UserActivity, userID int64) (*dbModel.UserActivity, error) {
	args := m.Called(ctx, activity, userID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.UserActivity), args.Error(1)
}

func (m *MockDBLayer) UpdateUserActivityRecord(ctx context.Context, activity dbModel.UserActivity, userID int64) (*dbModel.UserActivity, error) {
	args := m.Called(ctx, activity, userID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.UserActivity), args.Error(1)
}

func (m *MockDBLayer) GetActivityByUserIDAndResourceID(ctx context.Context, userID, resourceID int64) (*dbModel.UserActivity, error) {
	args := m.Called(ctx, userID, resourceID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.UserActivity), args.Error(1)
}

func (m *MockDBLayer) GetActivityByUserIDAndCourseModuleID(ctx context.Context, userID, moduleID int64) (*dbModel.UserActivity, error) {
	args := m.Called(ctx, userID, moduleID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.UserActivity), args.Error(1)
}

func (m *MockDBLayer) GetActivitiesByUserIDAndCourseIDs(ctx context.Context, userID int64, courseIDs []int64) ([]dbModel.UserActivityResponse, error) {
	args := m.Called(ctx, userID, courseIDs)
	return args.Get(0).([]dbModel.UserActivityResponse), args.Error(1)
}

func (m *MockDBLayer) GetActivitiesByUserIDAndCourseModuleIDs(ctx context.Context, userID int64, moduleIDs []int64) ([]dbModel.UserActivityResponse, error) {
	args := m.Called(ctx, userID, moduleIDs)
	return args.Get(0).([]dbModel.UserActivityResponse), args.Error(1)
}

func (m *MockDBLayer) GetActivitiesByUserIDAndResourceIDs(ctx context.Context, userID int64, resIDs []int64) ([]dbModel.UserActivityResponse, error) {
	args := m.Called(ctx, userID, resIDs)
	return args.Get(0).([]dbModel.UserActivityResponse), args.Error(1)
}

func (m *MockDBLayer) GetCourseContent(ctx context.Context, id int64) ([]dbModelCoursecontent.MdlCourseContent, error) {
	return nil, nil
}

// --- Setup ---
func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- Controller Tests ---
func TestCreateActivity(t *testing.T) {
	t.Run("Success - Create New Resource Activity", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewActivityTrackerControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		req := CreateActivityRequest{
			ModelType: "resource",
			ModelID:   100,
		}
		jb, _ := json.Marshal(req)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
		ctx.Request.Header.Set("Content-Type", "application/json")
		mockDB.On("GetActivityByUserIDAndResourceID", mock.Anything, int64(1), int64(100)).Return(nil, nil)
		mockDB.On("CreateUserActivityRecord", mock.Anything, mock.Anything, int64(1)).Return(&dbModel.UserActivity{ID: utils.Int64ToPointer(55)}, nil)
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Success - Update Existing Module Activity", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewActivityTrackerControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		req := CreateActivityRequest{ModelType: "course_module", ModelID: 200}
		jb, _ := json.Marshal(req)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
		existing := &dbModel.UserActivity{ID: utils.Int64ToPointer(55), UserID: utils.Int64ToPointer(1), CourseModuleID: utils.Int64ToPointer(200)}
		mockDB.On("GetActivityByUserIDAndCourseModuleID", mock.Anything, int64(1), int64(200)).Return(existing, nil)
		mockDB.On("UpdateUserActivityRecord", mock.Anything, mock.Anything, int64(1)).Return(existing, nil)
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - Invalid Model Type", func(t *testing.T) {
		controller := NewActivityTrackerControllerGroup(new(MockDBLayer))
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		req := CreateActivityRequest{ModelType: "invalid_type", ModelID: 100}
		jb, _ := json.Marshal(req)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

func TestGetActivity(t *testing.T) {
	t.Run("Success - Get Multiple Resource IDs", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewActivityTrackerControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=resource&model_id=1,2,3", nil)
		mockDB.On("GetActivitiesByUserIDAndResourceIDs", mock.Anything, int64(1), []int64{1, 2, 3}).Return([]dbModel.UserActivityResponse{{}}, nil)
		controller.GetActivity(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Success - Get Course Activity", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewActivityTrackerControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=500", nil)
		mockDB.On("GetActivitiesByUserIDAndCourseIDs", mock.Anything, int64(1), []int64{500}).Return([]dbModel.UserActivityResponse{}, nil)
		controller.GetActivity(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - Invalid ModelID Format", func(t *testing.T) {
		controller := NewActivityTrackerControllerGroup(new(MockDBLayer))
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=resource&model_id=1,abc,3", nil)
		controller.GetActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}
func TestActivityTrackerExtraCoverage(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewActivityTrackerControllerGroup(mockDB)
	t.Run("Failure - Unauthorized Create", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	t.Run("Failure - Invalid JSON Body", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{"model_id": "should_be_int"}`)))
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Success - Get Course Modules", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course_module&model_id=201,202", nil)
		mockDB.On("GetActivitiesByUserIDAndCourseModuleIDs", mock.Anything, int64(1), []int64{201, 202}).
			Return([]dbModel.UserActivityResponse{{}}, nil).Once()
		controller.GetActivity(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - DB Error on Resource Fetch", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{"model_type":"resource","model_id":1}`)))
		ctx.Request.Header.Set("Content-Type", "application/json")
		mockDB.On("GetActivityByUserIDAndResourceID", mock.Anything, int64(1), int64(1)).
			Return(nil, errors.New("connection refused")).Once()
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Update Activity Record DB Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{"model_type":"resource","model_id":1}`)))
		existing := &dbModel.UserActivity{ID: utils.Int64ToPointer(10), UserID: utils.Int64ToPointer(1)}
		mockDB.On("GetActivityByUserIDAndResourceID", mock.Anything, int64(1), int64(1)).Return(existing, nil).Once()
		mockDB.On("UpdateUserActivityRecord", mock.Anything, mock.Anything, int64(1)).
			Return(nil, errors.New("update failed")).Once()
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

func TestActivityTrackerFinalMile(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewActivityTrackerControllerGroup(mockDB)
	t.Run("Failure - GetActivity Unauthorized", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		controller.GetActivity(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	t.Run("Failure - GetActivity Invalid Query", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_id=100", nil)
		controller.GetActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Create Activity Record DB Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		req := CreateActivityRequest{ModelType: "resource", ModelID: 100}
		jb, _ := json.Marshal(req)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
		ctx.Request.Header.Set("Content-Type", "application/json")
		mockDB.On("GetActivityByUserIDAndResourceID", mock.Anything, int64(1), int64(100)).Return(nil, nil).Once()
		mockDB.On("CreateUserActivityRecord", mock.Anything, mock.Anything, int64(1)).
			Return(nil, errors.New("db error")).Once()
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Update Missing UserID In Existing Record", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{"model_type":"resource","model_id":1}`)))
		existing := &dbModel.UserActivity{ID: utils.Int64ToPointer(10), UserID: nil}
		mockDB.On("GetActivityByUserIDAndResourceID", mock.Anything, int64(1), int64(1)).Return(existing, nil).Once()
		controller.CreateActivity(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

// --- Benchmarks ---
func BenchmarkCreateActivity(b *testing.B) {
	mockDB := new(MockDBLayer)
	controller := NewActivityTrackerControllerGroup(mockDB)
	mockDB.On("GetActivityByUserIDAndResourceID", mock.Anything, mock.Anything, mock.Anything).Return(nil, nil)
	mockDB.On("CreateUserActivityRecord", mock.Anything, mock.Anything, mock.Anything).Return(&dbModel.UserActivity{}, nil)
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Set("userId", int64(1))
	req := CreateActivityRequest{ModelType: "resource", ModelID: 100}
	jb, _ := json.Marshal(req)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
		controller.CreateActivity(ctx)
	}
}

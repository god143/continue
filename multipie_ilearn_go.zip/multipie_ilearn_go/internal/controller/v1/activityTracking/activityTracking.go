package activitytracker

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (u *activityTrackerController) CreateActivity(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request CreateActivityRequest
	)

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createdActivity, err := u.validateAndCreateActivity(ctx, request, uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createdActivity, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (u *activityTrackerController) GetActivity(ctx *gin.Context) {
	var request GetActivityRequest

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		ctx.JSON(http.StatusUnauthorized, utils.NewV1Response(nil, utils.StringToPointer(err.Error())))
		return
	}

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid query parameters", zap.Error(err))
		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer("invalid query parameters")))
		return
	}

	activities, err := u.validateAndGetActivity(ctx, request, uid)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, utils.NewV1Response(nil, utils.StringToPointer(err.Error())))
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(activities, nil))
}

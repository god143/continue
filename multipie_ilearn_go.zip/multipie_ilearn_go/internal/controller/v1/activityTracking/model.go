package activitytracker

import (
	"multipie_ilearn_go/internal/constants"
	activitytracking "multipie_ilearn_go/internal/db/activityTracking"
)

type CreateUserActivityResponse struct {
	ID int64 `json:"id"`
}
type GetActivityByIDRequest struct {
	ID int64 `uri:"id" binding:"required"`
}

type GetActivityRequest struct {
	ModelType string `form:"model_type" binding:"required"`
	ModelID   string `form:"model_id" binding:"required"`
}

type CreateActivityRequest struct {
	ModelType      string                           `json:"model_type" binding:"required"` // "course_module" or "resource"
	ModelID        int64                            `json:"model_id" binding:"required"`
	ActivityStatus *constants.ActivityStatusEnum    `json:"activity_status"`
	AdditionalData *activitytracking.AdditionalData `json:"additional_data"`
}

type UpdateActivityRequest struct {
	ID             *int64                           `json:"id,omitempty"`
	ActivityStatus *constants.ActivityStatusEnum    `json:"activity_status"`
	AdditionalData *activitytracking.AdditionalData `json:"additional_data"`
	ResourceID     *int64                           `json:"resource_id"`
	CourseModuleID *int64                           `json:"course_module_id"`
}

type ActivityResponse struct {
	ID             *int64                           `json:"id"`
	ActivityStatus *constants.ActivityStatusEnum    `json:"activity_status"`
	AdditionalData *activitytracking.AdditionalData `json:"additional_data"`
	ResourceID     *int64                           `json:"resource_id"`
	CourseModuleID *int64                           `json:"course_module_id"`
	CourseID       *int64                           `json:"course_id"`
}

package activitytracker

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type activityTrackerController struct {
	db db.DBLayer
}

type ActivityTrackerControllerGroup interface {
	CreateActivity(ctx *gin.Context)
	GetActivity(ctx *gin.Context)
}

func NewActivityTrackerControllerGroup(db db.DBLayer) ActivityTrackerControllerGroup {
	return &activityTrackerController{
		db: db,
	}
}

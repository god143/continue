package quiz

import (
	"multipie_ilearn_go/internal/constants"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	dbModelQuiz "multipie_ilearn_go/internal/db/quiz"
	"time"
)

type GetQuizByIDRequest struct {
	ID int64 `uri:"quiz_id" binding:"required"`
}

type GetQuizByCourseIDRequest struct {
	CourseID int64 `uri:"course_id" binding:"required"`
}

type QuizResult struct {
	QuizWithUserState
	Questions []dbModelQuestions.Question `json:"questions"`
}
type GenerateCertificateResponse struct {
	CertificatePath string `json:"certificate_path,omitempty"`
}

type CertificateData struct {
	Name       string
	CourseName string
	Date       string
}

type ValidateQuizData struct {
	IsPassed  bool
	ModelType string
	ModelId   int64
}

type QuizWithUserState struct {
	dbModelQuiz.Quiz
	HasCheckedAnswer bool   `json:"has_checked_answer"`
	HasUserPassed    bool   `json:"has_user_passed"`
	HasAttempted     bool   `json:"has_attempted"`
	AttemptID        *int64 `json:"attempt_id"`
}

type Question struct {
	ID            *int64                      `json:"id"`
	QuizID        *int64                      `json:"quiz_id"`
	QuestionText  *string                     `json:"question_text"`
	Type          *constants.QuestionTypeEnum `json:"question_type"`
	ImageURL      *string                     `json:"image_url,omitempty"`
	Answers       *Answer                     `json:"answers" gorm:"type:json"`
	CorrectAnswer *string                     `json:"correct_answer"`
	CreatedAt     *time.Time                  `json:"-"`
	UpdatedAt     *time.Time                  `json:"-"`
}

type Answer struct {
	Options *[]string `json:"options"`
}

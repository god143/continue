package quiz

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type quizController struct {
	db db.DBLayer
}

type QuizControllerGroup interface {
	GetCourseQuiz(ctx *gin.Context)
	GetIndependentQuiz(ctx *gin.Context)
	GetQuizByID(ctx *gin.Context)
	GetQuizByCourseID(ctx *gin.Context)
	GetAnswersByQuizID(ctx *gin.Context)
	GenerateCertificate(ctx *gin.Context)
}

func NewQuizController(db db.DBLayer) QuizControllerGroup {
	return &quizController{
		db: db,
	}
}

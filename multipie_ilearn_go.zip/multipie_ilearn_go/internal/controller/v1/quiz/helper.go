package quiz

import (
	"context"
	"fmt"
	"image"
	"image/png"
	"math"
	"multipie_ilearn_go/internal/constants"
	dbModelCert "multipie_ilearn_go/internal/db/certificate"
	dbModelEnrollment "multipie_ilearn_go/internal/db/enrollment"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	"multipie_ilearn_go/internal/logger"
	activestorage "multipie_ilearn_go/internal/service/activeStorage"
	"multipie_ilearn_go/internal/utils"
	"os"
	"path/filepath"
	"regexp"
	"time"

	"github.com/fogleman/gg"
	"go.uber.org/zap"
)

func (q *quizController) getQuizByCourseHelper(ctx context.Context, userID int64) ([]QuizWithUserState, error) {
	quizzes, err := q.db.GetCourseQuiz(ctx, utils.BoolToPointer(true))
	if err != nil {
		return nil, err
	}

	var result []QuizWithUserState
	for _, quiz := range quizzes {
		state := QuizWithUserState{Quiz: quiz}
		status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
		if err == nil && status != nil {
			state.HasUserPassed = status.HasUserPassed
			state.HasCheckedAnswer = status.HasCheckedAnswer
			state.HasAttempted = status.HasAttempted
			state.AttemptID = status.AttemptID
		}
		result = append(result, state)
	}

	return result, nil
}

func (q *quizController) getIndependentQuizHelper(ctx context.Context, userID int64) ([]QuizWithUserState, error) {
	quizzes, err := q.db.GetIndependentQuiz(ctx, utils.BoolToPointer(true))
	if err != nil {
		return nil, err
	}

	var result []QuizWithUserState
	for _, quiz := range quizzes {
		state := QuizWithUserState{Quiz: quiz}
		status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
		if err == nil && status != nil {
			state.HasUserPassed = status.HasUserPassed
			state.HasCheckedAnswer = status.HasCheckedAnswer
			state.HasAttempted = status.HasAttempted
			state.AttemptID = status.AttemptID
		}
		result = append(result, state)
	}

	return result, nil
}

func (q *quizController) getAnswersByIDHelper(ctx context.Context, request GetQuizByIDRequest, userID int64) ([]dbModelQuestions.QuestionAnswer, error) {
	quiz, err := q.db.GetQuizById(ctx, request.ID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database", zap.Error(err), zap.Int64("ID", request.ID))
		return nil, err
	}

	questions, err := q.fetchQuestionAnswersFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		return nil, err
	}

	return questions, nil
}

func (q *quizController) getQuizByIDHelper(ctx context.Context, request GetQuizByIDRequest, userID int64) (*QuizResult, error) {
	quiz, err := q.db.GetQuizById(ctx, request.ID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database", zap.Error(err), zap.Int64("ID", request.ID))
		return nil, err
	}

	quizResult := &QuizResult{
		QuizWithUserState: QuizWithUserState{Quiz: quiz},
	}

	status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
	if err == nil && status != nil {
		quizResult.HasUserPassed = status.HasUserPassed
		quizResult.HasCheckedAnswer = status.HasCheckedAnswer
		quizResult.HasAttempted = status.HasAttempted
		quizResult.AttemptID = status.AttemptID
	}

	questions, err := q.fetchQuestionsFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		return nil, err
	}

	quizResult.Questions = questions
	return quizResult, nil
}

func (q *quizController) getQuizByCourseIDHelper(ctx context.Context, request GetQuizByCourseIDRequest, userID int64) (*QuizResult, error) {
	quiz, err := q.db.GetQuizCourseId(ctx, request.CourseID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database by courseID", zap.Error(err), zap.Int64("ID", request.CourseID))
		return nil, err
	}

	quizResult := &QuizResult{
		QuizWithUserState: QuizWithUserState{Quiz: quiz},
	}

	status, err := q.db.GetQuizAttemptStatus(ctx, userID, *quiz.ID)
	if err == nil && status != nil {
		quizResult.HasUserPassed = status.HasUserPassed
		quizResult.HasCheckedAnswer = status.HasCheckedAnswer
		quizResult.HasAttempted = status.HasAttempted
		quizResult.AttemptID = status.AttemptID
	}

	questions, err := q.fetchQuestionsFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		return nil, err
	}

	quizResult.Questions = questions
	return quizResult, nil
}

func (q *quizController) fetchQuestionsFromDB(ctx context.Context, quizId int64, numOfQuestions int64) ([]dbModelQuestions.Question, error) {
	question, err := q.db.GetQuestionsByQuizId(ctx, quizId, &numOfQuestions)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database", zap.Error(err))
		return nil, err
	}
	return question, nil
}

func (q *quizController) fetchQuestionAnswersFromDB(ctx context.Context, quizId int64, numOfQuestions int64) ([]dbModelQuestions.QuestionAnswer, error) {
	question, err := q.db.GetQuestionAnswersByQuizId(ctx, quizId, &numOfQuestions)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database", zap.Error(err))
		return nil, err
	}
	return question, nil
}

// 1. Check if the quiz is independent and validate the score
func (q *quizController) validateQuizCompletion(ctx context.Context, quizID int64, score *float64, userId int64) (*ValidateQuizData, error) {
	var modelType string
	var modelID int64
	var isPassed bool

	quizAttempt, err := q.db.GetQuizAttempts(ctx, userId, quizID)
	if err != nil {
		logger.Error(ctx, "Error fetching quiz attempt", zap.Error(err))
		return nil, err
	}

	if quizAttempt.Score == nil {
		logger.Error(ctx, "no quiz attempts")
		return nil, fmt.Errorf("no quiz attempts")
	}

	scoreInt := int64(math.Round(*score))
	attemptScoreInt := int64(math.Round(*quizAttempt.Score))

	if scoreInt != attemptScoreInt {
		logger.Error(ctx, "invalid score", zap.Int64("score", scoreInt), zap.Int64("quizattempt score", attemptScoreInt))
		return nil, err
	}

	quiz, err := q.db.GetQuizById(ctx, quizID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "Error fetching quiz", zap.Error(err))
		return nil, err
	}

	//scoreInt := int64(math.Round(*score))
	if scoreInt < *quiz.PassPercentage {
		return nil, nil
	}

	isIndependent := quiz.CourseID == nil
	isPassed = true

	if isIndependent {
		modelType = constants.MODEL_TYPE_QUIZ
		modelID = *quiz.ID
	} else {
		modelType = constants.MODEL_TYPE_COURSE
		modelID = *quiz.CourseID
	}

	validateQuizData := ValidateQuizData{
		IsPassed:  isPassed,
		ModelType: modelType,
		ModelId:   modelID,
	}

	return &validateQuizData, nil
}

// 2. Check if a certificate already exists
func (q *quizController) checkCertificateExistence(ctx context.Context, userID, modelID int64, modelType string) (*string, error) {
	cert, err := q.db.GetCertificateByModelIDModelType(ctx, utils.Int64ToPointer(modelID), utils.StringToPointer(modelType), userID)
	if err != nil {
		logger.Error(ctx, "Error fetching certificate", zap.Error(err))
		return nil, err
	}

	if cert == nil {
		return nil, fmt.Errorf("certificate url not found")
	}
	return cert.URL, nil
}

// 3. Fetch the course or quiz name
func (q *quizController) getCourseOrQuizName(ctx context.Context, quizID int64, isModelTypeQuiz bool) (string, error) {
	if isModelTypeQuiz {
		quiz, err := q.db.GetQuizById(ctx, quizID, utils.BoolToPointer(true))
		if err != nil {
			return "", err
		}
		return *quiz.Name, nil
	}

	course, err := q.db.GetCourseNameByQuizID(ctx, quizID)
	if err != nil {
		return "", err
	}
	return course, nil
}

// 4. Generate certificate image
func (q *quizController) generateCertificate(data CertificateData, templatePath, outputPath, fontPath string) error {

	outputDir := filepath.Dir(outputPath)
	if err := os.MkdirAll(outputDir, os.ModePerm); err != nil {
		return fmt.Errorf("failed to create output directory: %w", err)
	}

	imgFile, err := os.Open(templatePath)
	if err != nil {
		return fmt.Errorf("failed to open template: %w", err)
	}
	defer imgFile.Close()

	img, _, err := image.Decode(imgFile)
	if err != nil {
		return fmt.Errorf("failed to decode template: %w", err)
	}

	dc := gg.NewContextForImage(img)
	if err := dc.LoadFontFace(fontPath, 24); err != nil {
		return fmt.Errorf("failed to load font: %w", err)
	}

	dc.SetRGB(0.3, 0.3, 0.3)
	dc.DrawStringAnchored(data.Name, float64(dc.Width())/2, float64(dc.Height())*0.470, 0.5, 0.5)

	if err := dc.LoadFontFace(fontPath, 18); err != nil {
		return fmt.Errorf("failed to load font: %w", err)
	}
	dc.DrawStringAnchored(data.CourseName, float64(dc.Width())/2, float64(dc.Height())*0.620, 0.5, 0.5)

	if err := dc.LoadFontFace(fontPath, 15); err != nil {
		return fmt.Errorf("failed to load font: %w", err)
	}
	dc.DrawStringAnchored(data.Date, (float64(dc.Width())/2)*0.60, float64(dc.Height())*0.75, 0.5, 0.5)

	outFile, err := os.Create(outputPath)
	if err != nil {
		return fmt.Errorf("failed to create output file: %w", err)
	}
	defer outFile.Close()

	if err := png.Encode(outFile, dc.Image()); err != nil {
		return fmt.Errorf("failed to encode image: %w", err)
	}

	return nil
}

// 5. Upload certificate to S3 and delete temp file
func (q *quizController) uploadCertificateToS3(ctx context.Context, modelID int64, filePath string) (string, error) {
	activeStorageService := activestorage.NewActiveStorageService(q.db)

	// Read file contents into a byte slice
	fileBytes, err := os.ReadFile(filePath)
	if err != nil {
		logger.Error(ctx, "Error reading certificate file", zap.Error(err))
		return "", err
	}

	// Create an input struct
	uploadInput := activestorage.ActiveStorageLocalUploadInput{
		FileBytes:     fileBytes,
		FileName:      filepath.Base(filePath),
		ServiceName:   constants.SERVICE_NAME_S3,
		ModelType:     constants.MODEL_TYPE_CERTIFICATE,
		ModelID:       modelID,
		ContentType:   constants.CONTENT_TYPE_IMAGE,
		AttachmentFor: "certificate",
		IsPrimary:     false,
	}

	// Upload the file and get the S3 URL
	tempUrl, err := activeStorageService.UploadFileFromLocal(ctx, uploadInput)
	if err != nil {
		//	fmt.Printf("upload failed error: %+v\n", err)
		logger.Error(ctx, "Error uploading certificate to S3", zap.Error(err))
		return "", err
	}
	fileURL := activeStorageService.GetURL(*tempUrl)

	// Remove local file after successful upload
	if err = os.Remove(filePath); err != nil {
		logger.Error(ctx, "Error deleting temp certificate file", zap.Error(err))
	}

	return fileURL, nil
}

// date string
func (q *quizController) handleCertificateGeneration(ctx context.Context, userID, quizID int64, score *float64, date string) (string, error) {
	// Step 1: Validate quiz completion
	validateQuizData, err := q.validateQuizCompletion(ctx, quizID, score, userID)
	if err != nil {
		logger.Error(ctx, "Error validating quiz completion", zap.Error(err))
		return "", err
	}
	if validateQuizData == nil || !validateQuizData.IsPassed {
		return "", fmt.Errorf("quiz not passed, certificate not generated")
	}

	// Step 2: Check if a certificate already exists
	existingCertURL, err := q.checkCertificateExistence(ctx, userID, validateQuizData.ModelId, validateQuizData.ModelType)
	if err != nil {
		logger.Error(ctx, "Error checking existing certificate", zap.Error(err))
		return "", err
	}
	if existingCertURL != nil {
		logger.Info(ctx, "Certificate already exists, returning existing URL", zap.String("url", *existingCertURL))
		return *existingCertURL, nil
	}

	// Step 3: Fetch course or quiz name
	isModelTypeQuiz := validateQuizData.ModelType == constants.MODEL_TYPE_QUIZ
	courseOrQuizName, err := q.getCourseOrQuizName(ctx, quizID, isModelTypeQuiz)
	if err != nil {
		logger.Error(ctx, "Error fetching course/quiz name", zap.Error(err))
		return "", err
	}

	createdAt := time.Now()
	if date != "" {
		d, err := time.Parse("2006-01-02", date)
		if err != nil {
			return "", fmt.Errorf("invalid date format:%w", err)
		}
		createdAt = d
	}

	// Step 4: Insert certificate **only if it doesn’t exist**
	certificate := dbModelCert.Certificate{
		UserID:    &userID,
		ModelID:   &validateQuizData.ModelId,
		ModelType: &validateQuizData.ModelType,
		CreatedAt: &createdAt,
	}

	cert, err := q.db.CreateCertificate(ctx, &certificate)
	if err != nil {
		logger.Error(ctx, "Failed to create initial certificate entry in DB", zap.Error(err))
		return "", err
	}

	quizdetails, err := q.db.GetQuizById(ctx, quizID, utils.BoolToPointer(true))
	if err != nil {
		return "", err
	}

	// Step 5: Generate certificate image
	// SUPER_STAR_CERTIFICATE_TEMPLATE_PATH
	// STAR_CERTIFICATE_TEMPLATE_PATH
	// COURSE_CERTIFICATE_TEMPLATE_PATH
	templatePath := constants.COURSE_CERTIFICATE_TEMPLATE_PATH
	if isModelTypeQuiz {
		if quizdetails.DifficultyLevel == nil {
			logger.Error(ctx, "difficulty level not present")
			return "", fmt.Errorf("difficulty level not present")
		} else if *quizdetails.DifficultyLevel == constants.QuizDiffcultyEnumAdvanced {
			templatePath = constants.SUPER_STAR_CERTIFICATE_TEMPLATE_PATH
		} else {
			templatePath = constants.STAR_CERTIFICATE_TEMPLATE_PATH
		}
	}
	outputFileName := fmt.Sprintf("certificate_%d.jpg", *cert.ID)
	outputPath := filepath.Join(constants.CERTIFICATE_OUTPUT_PATH, outputFileName)

	user, err := q.db.GetUserByUID(ctx, userID)
	if err != nil {
		logger.Error(ctx, "Error fetching user details", zap.Error(err))
		return "", err
	}

	// displayname= firstname + lastname
	var alphaRegex = regexp.MustCompile(`[A-Za-z]`)
	DisplayName := ""

	if user.FirstName != nil {
		if user.LastName != nil && alphaRegex.MatchString(*user.LastName) {
			DisplayName = *user.FirstName + " " + *user.LastName
		} else {
			DisplayName = *user.FirstName + " "
		}
	} else {
		logger.Error(ctx, "firstname value not available", zap.Error(err))
		return "", fmt.Errorf("firstname value not available")
	}

	CertificateDate := time.Now().Format("January 2, 2006") //get date from certificate csv

	if date != "" {
		t, err := time.Parse("2006-01-02", date)
		if err != nil {
			return "", fmt.Errorf("invalid date format:%w", err)
		}
		CertificateDate = t.Format("January 2, 2006")
	}

	certData := CertificateData{
		Name:       DisplayName,
		CourseName: courseOrQuizName,
		Date:       CertificateDate,
	}

	if err := q.generateCertificate(certData, templatePath, outputPath, constants.FONT_PATH); err != nil {
		logger.Error(ctx, "Error generating certificate image", zap.Error(err))
		return "", err
	}

	// Step 6: Upload certificate to S3

	certURL, err := q.uploadCertificateToS3(ctx, validateQuizData.ModelId, outputPath)
	if err != nil {
		logger.Error(ctx, "Error uploading certificate to S3", zap.Error(err))
		return "", err
	}

	// Step 7: Update the certificate record with the S3 URL
	err = q.db.UpdateCertificateURL(ctx, *cert.ID, certURL)
	if err != nil {
		logger.Error(ctx, "Failed to update certificate URL in DB", zap.Error(err))
		return "", err
	}

	// **Step 8: Update Enrollment Status (only if quiz is linked to a course)**
	if !isModelTypeQuiz {
		enrollment := dbModelEnrollment.Enrollment{
			UserID:   &userID,
			CourseID: &validateQuizData.ModelId,
			Status:   utils.StringToPointer("completed"),
		}

		_, err := q.db.UpdateEnrollment(ctx, enrollment)
		if err != nil {
			logger.Error(ctx, "Error updating enrollment status", zap.Error(err))
			return "", err
		}
		logger.Info(ctx, "Enrollment status updated to completed", zap.Int64("user_id", userID), zap.Int64("course_id", validateQuizData.ModelId))
	}

	logger.Info(ctx, "Certificate successfully generated and stored", zap.String("url", certURL))
	return certURL, nil
}

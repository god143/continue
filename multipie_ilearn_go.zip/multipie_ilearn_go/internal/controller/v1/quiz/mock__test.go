package quiz

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	dbModelQuiz "multipie_ilearn_go/internal/db/quiz"
	dbModelQuizAttempts "multipie_ilearn_go/internal/db/quizAttempts"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mock Definition ---

type MockQuizDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockQuizDB) GetCourseQuiz(ctx context.Context, v *bool) ([]dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, v)
	return args.Get(0).([]dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockQuizDB) GetIndependentQuiz(ctx context.Context, v *bool) ([]dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, v)
	return args.Get(0).([]dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockQuizDB) GetQuizById(ctx context.Context, id int64, v *bool) (dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, id, v)
	return args.Get(0).(dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockQuizDB) GetQuizCourseId(ctx context.Context, cid int64, v *bool) (dbModelQuiz.Quiz, error) {
	args := m.Called(ctx, cid, v)
	return args.Get(0).(dbModelQuiz.Quiz), args.Error(1)
}
func (m *MockQuizDB) GetQuizAttemptStatus(ctx context.Context, uID, qID int64) (*dbModelQuizAttempts.QuizAttemptStatus, error) {
	args := m.Called(ctx, uID, qID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModelQuizAttempts.QuizAttemptStatus), args.Error(1)
}
func (m *MockQuizDB) GetQuestionsByQuizId(ctx context.Context, qID int64, l *int64) ([]dbModelQuestions.Question, error) {
	args := m.Called(ctx, qID, l)
	return args.Get(0).([]dbModelQuestions.Question), args.Error(1)
}
func (m *MockQuizDB) GetCourseNameByQuizID(ctx context.Context, quizID int64) (string, error) {
	args := m.Called(ctx, quizID)
	return args.String(0), args.Error(1)
}
func int64Ptr(f int64) *int64 {
	return &f
}

// --- Test Suite ---
func TestQuizController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	// Helper data
	userID := int64(555)
	t.Run("GetCourseQuiz - Success", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		quizzes := []dbModelQuiz.Quiz{{ID: int64Ptr(1)}}
		status := &dbModelQuizAttempts.QuizAttemptStatus{HasAttempted: true, HasUserPassed: true}

		mockDB.On("GetCourseQuiz", mock.Anything, mock.Anything).Return(quizzes, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, int64(555), int64(1)).Return(status, nil)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(555)) // Mocking ExtractUserId

		controller.GetCourseQuiz(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		mockDB.AssertExpectations(t)
	})

	t.Run("GetQuizByID - Happy Path", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		// Fix: Use the helper to assign pointer values to struct fields
		targetQuizID := int64(10)
		mockQuiz := dbModelQuiz.Quiz{
			ID:           &targetQuizID,
			NumQuestions: int64Ptr(2),
		}

		mockQuestions := []dbModelQuestions.Question{
			{ID: int64Ptr(1)}, // No longer untyped int constant
			{ID: int64Ptr(2)},
		}

		// Setup Mock expectations
		mockDB.On("GetQuizById", mock.Anything, targetQuizID, mock.Anything).Return(mockQuiz, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, int64(555), targetQuizID).Return(nil, nil)
		mockDB.On("GetQuestionsByQuizId", mock.Anything, targetQuizID, mock.Anything).Return(mockQuestions, nil)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(555))
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "10"}}

		controller.GetQuizByID(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		mockDB.AssertExpectations(t)
	})

	t.Run("GetQuizByCourseID - Error Not Found", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		mockDB.On("GetQuizCourseId", mock.Anything, int64(101), mock.Anything).Return(dbModelQuiz.Quiz{}, errors.New("quiz not found"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(555))
		ctx.Params = []gin.Param{{Key: "course_id", Value: "101"}}

		controller.GetQuizByCourseID(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("Edge Case - Unauthorized", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// No "userId" set in context

		controller.GetCourseQuiz(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	t.Run("Edge Case - Invalid URI Parameter", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(555))
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "invalid-string"}}

		controller.GetQuizByID(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Database Question Fetch Error", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		quizID := int64(10)
		quiz := dbModelQuiz.Quiz{ID: &quizID, NumQuestions: int64Ptr(5)}

		mockDB.On("GetQuizById", mock.Anything, quizID, mock.Anything).Return(quiz, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, mock.Anything, quizID).Return(nil, nil)
		mockDB.On("GetQuestionsByQuizId", mock.Anything, quizID, mock.Anything).Return([]dbModelQuestions.Question{}, errors.New("db failure"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(555))
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "10"}}

		controller.GetQuizByID(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetIndependentQuiz - Success with Loop Coverage", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		quizzes := []dbModelQuiz.Quiz{{ID: int64Ptr(1)}, {ID: int64Ptr(2)}}
		status := &dbModelQuizAttempts.QuizAttemptStatus{HasAttempted: true}

		mockDB.On("GetIndependentQuiz", mock.Anything, mock.Anything).Return(quizzes, nil)
		// Branch coverage: one quiz has status, one has error/nil
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, int64(1)).Return(status, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, int64(2)).Return(nil, errors.New("not found"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)

		controller.GetIndependentQuiz(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("GetQuizByCourseID - Happy Path", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		qID := int64(10)
		mockQuiz := dbModelQuiz.Quiz{ID: &qID, NumQuestions: int64Ptr(1)}

		mockDB.On("GetQuizCourseId", mock.Anything, int64(101), mock.Anything).Return(mockQuiz, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, qID).Return(nil, nil)
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qID, mock.Anything).Return([]dbModelQuestions.Question{}, nil)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		ctx.Params = []gin.Param{{Key: "course_id", Value: "101"}}

		controller.GetQuizByCourseID(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("GetCourseQuiz - DB Failure", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)
		mockDB.On("GetCourseQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz{}, errors.New("db error"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)

		controller.GetCourseQuiz(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("Helper - GetIndependentQuiz DB Error", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)
		mockDB.On("GetIndependentQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz{}, errors.New("db error"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)

		controller.GetIndependentQuiz(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("GetQuizByID - Quiz Not Found", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)
		mockDB.On("GetQuizById", mock.Anything, int64(99), mock.Anything).Return(dbModelQuiz.Quiz{}, errors.New("not found"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "99"}}

		controller.GetQuizByID(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetCourseQuiz - Success with Mixed Attempt Status", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		// Setup: 2 quizzes to trigger loop twice
		quizzes := []dbModelQuiz.Quiz{
			{ID: int64Ptr(101)},
			{ID: int64Ptr(102)},
		}
		// Quiz 1 has status, Quiz 2 has DB error for status (covers error branch)
		mockDB.On("GetCourseQuiz", mock.Anything, mock.Anything).Return(quizzes, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, int64(101)).
			Return(&dbModelQuizAttempts.QuizAttemptStatus{HasAttempted: true}, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, int64(102)).
			Return(nil, errors.New("not found"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)

		controller.GetCourseQuiz(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("GetQuizByCourseID - Failure Fetching Questions", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		qID := int64(10)
		mockQuiz := dbModelQuiz.Quiz{ID: &qID, NumQuestions: int64Ptr(5)}

		mockDB.On("GetQuizCourseId", mock.Anything, int64(202), mock.Anything).Return(mockQuiz, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, qID).Return(nil, nil)
		// Fail the question fetch specifically
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qID, mock.Anything).
			Return([]dbModelQuestions.Question{}, errors.New("question fetch failed"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		ctx.Params = []gin.Param{{Key: "course_id", Value: "202"}}

		controller.GetQuizByCourseID(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetCourseQuiz - Branching Loop Coverage", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		// Two quizzes: One with status, one where status call fails (covers both loop branches)
		quizzes := []dbModelQuiz.Quiz{{ID: int64Ptr(1)}, {ID: int64Ptr(2)}}
		mockDB.On("GetCourseQuiz", mock.Anything, mock.Anything).Return(quizzes, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, int64(1)).Return(&dbModelQuizAttempts.QuizAttemptStatus{HasAttempted: true}, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, int64(2)).Return(nil, errors.New("db error"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		controller.GetCourseQuiz(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		mockDB.AssertExpectations(t)
	})

	t.Run("GetIndependentQuiz - DB Initial Failure", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)
		mockDB.On("GetIndependentQuiz", mock.Anything, mock.Anything).Return([]dbModelQuiz.Quiz{}, errors.New("fatal db error"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		controller.GetIndependentQuiz(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("GetQuizByID - Question Fetch Failure Path", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		qID := int64(10)
		quiz := dbModelQuiz.Quiz{ID: &qID, NumQuestions: int64Ptr(5)}

		mockDB.On("GetQuizById", mock.Anything, qID, mock.Anything).Return(quiz, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, qID).Return(nil, nil)
		// Specifically fail questions to hit helper.go:128 error branch
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qID, mock.Anything).Return([]dbModelQuestions.Question{}, errors.New("questions missing"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "10"}}

		controller.GetQuizByID(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("GetQuizByCourseID - Happy Path & Mapping", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		qID := int64(20)
		quiz := dbModelQuiz.Quiz{ID: &qID, NumQuestions: int64Ptr(1)}
		questions := []dbModelQuestions.Question{{ID: int64Ptr(1)}}

		mockDB.On("GetQuizCourseId", mock.Anything, int64(202), mock.Anything).Return(quiz, nil)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, qID).Return(&dbModelQuizAttempts.QuizAttemptStatus{AttemptID: int64Ptr(999)}, nil)
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qID, mock.Anything).Return(questions, nil)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		ctx.Params = []gin.Param{{Key: "course_id", Value: "202"}}

		controller.GetQuizByCourseID(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Edge Case - Unauthorized & Invalid Binding", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		// Sub-case 1: Missing UserID (401)
		w1 := httptest.NewRecorder()
		ctx1, _ := gin.CreateTestContext(w1)
		controller.GetQuizByID(ctx1)
		assert.Equal(t, http.StatusUnauthorized, w1.Code)

		// Sub-case 2: Bad Param Type (400)
		w2 := httptest.NewRecorder()
		ctx2, _ := gin.CreateTestContext(w2)
		ctx2.Set("userId", userID)
		ctx2.Params = []gin.Param{{Key: "quiz_id", Value: "string-not-int"}}
		controller.GetQuizByID(ctx2)
		assert.Equal(t, http.StatusBadRequest, w2.Code)
	})
	t.Run("Helper - getCourseOrQuizName Coverage", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		// Case 1: Quiz Found (Mocking GetQuizById which seems to be called on line 187)
		quizID1 := int64(1)
		mockQuiz := dbModelQuiz.Quiz{ID: &quizID1, Name: utils.StringToPointer("Test Quiz")}

		// Expect GetQuizById because the panic showed it's called there
		mockDB.On("GetQuizById", mock.Anything, quizID1, mock.Anything).Return(mockQuiz, nil)

		// If it also calls GetCourseNameByQuizID, keep this:
		mockDB.On("GetCourseNameByQuizID", mock.Anything, quizID1).Return("Go Basics", nil).Maybe()

		name1, err1 := controller.(*quizController).getCourseOrQuizName(context.Background(), quizID1, true)

		// Case 2: Quiz Not Found / DB Error
		quizID2 := int64(2)
		mockDB.On("GetQuizById", mock.Anything, quizID2, mock.Anything).Return(dbModelQuiz.Quiz{}, errors.New("db error"))

		name2, err2 := controller.(*quizController).getCourseOrQuizName(context.Background(), quizID2, true)

		// Assertions
		assert.NoError(t, err1)
		assert.NotEmpty(t, name1)
		assert.Error(t, err2)
		assert.Empty(t, name2)
		mockDB.AssertExpectations(t)
	})

	t.Run("GetQuizByCourseID - Binding & Auth Failures", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		// Case 1: Unauthorized (No userId in context)
		w1 := httptest.NewRecorder()
		ctx1, _ := gin.CreateTestContext(w1)
		controller.GetQuizByCourseID(ctx1)
		assert.Equal(t, http.StatusUnauthorized, w1.Code)

		// Case 2: Invalid URI (Binding Error)
		w2 := httptest.NewRecorder()
		ctx2, _ := gin.CreateTestContext(w2)
		ctx2.Set("userId", int64(555))
		ctx2.Params = []gin.Param{{Key: "course_id", Value: "not-an-int"}}
		controller.GetQuizByCourseID(ctx2)
		assert.Equal(t, http.StatusBadRequest, w2.Code)
	})

	t.Run("GetIndependentQuiz - Unauthorized Branch", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// Missing userId triggers the early return branch
		controller.GetIndependentQuiz(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})
	t.Run("getQuizByIDHelper - 100% Coverage Branch", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)
		qID := int64(77)

		// Mock Quiz Success
		mockDB.On("GetQuizById", mock.Anything, qID, mock.Anything).
			Return(dbModelQuiz.Quiz{ID: &qID, NumQuestions: utils.Int64ToPointer(1)}, nil)

		// BRANCH 1: Mock Attempt Status Failure (Covers the 'if err != nil' implicit skip)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, userID, qID).
			Return(nil, errors.New("status db error"))

		// Mock Question Success
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qID, mock.Anything).
			Return([]dbModelQuestions.Question{}, nil)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", userID)
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "77"}}

		controller.GetQuizByID(ctx)
		assert.Equal(t, http.StatusOK, w.Code) // Should still succeed even if status fails
	})
	t.Run("getCourseOrQuizName - 100% Coverage", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)
		quizID := int64(1)

		// BRANCH 1: Quiz name found, boolean is true
		mockDB.On("GetQuizById", mock.Anything, quizID, mock.Anything).
			Return(dbModelQuiz.Quiz{Name: utils.StringToPointer("Quiz Name")}, nil).Once()
		name, err := controller.(*quizController).getCourseOrQuizName(context.Background(), quizID, true)
		assert.Equal(t, "Quiz Name", name, err)

		// BRANCH 2: Quiz name found, but boolean is false (Triggers the Join Logic)
		mockDB.On("GetQuizById", mock.Anything, quizID, mock.Anything).
			Return(dbModelQuiz.Quiz{Name: utils.StringToPointer("Quiz Name")}, nil).Once()
		mockDB.On("GetCourseNameByQuizID", mock.Anything, quizID).
			Return("Course Full Name", nil).Once()
		name, err = controller.(*quizController).getCourseOrQuizName(context.Background(), quizID, false)
		assert.Equal(t, "Course Full Name", name, err)

		// BRANCH 3: Course Join Fails (NotFound)
		mockDB.On("GetQuizById", mock.Anything, quizID, mock.Anything).
			Return(dbModelQuiz.Quiz{Name: utils.StringToPointer("Quiz Name")}, nil).Once()
		mockDB.On("GetCourseNameByQuizID", mock.Anything, quizID).
			Return("", errors.New("no course found")).Once()
		_, err = controller.(*quizController).getCourseOrQuizName(context.Background(), quizID, false)
		assert.Error(t, err)
	})
	t.Run("getQuizByIDHelper - 100% Branch - Question Failure", func(t *testing.T) {
		mockDB := new(MockQuizDB)
		controller := NewQuizController(mockDB)

		qID := int64(88)
		uID := int64(555)

		// 1. First Call Succeeds
		mockQuiz := dbModelQuiz.Quiz{
			ID:           &qID,
			NumQuestions: utils.Int64ToPointer(5),
		}
		mockDB.On("GetQuizById", mock.Anything, qID, mock.Anything).Return(mockQuiz, nil)

		// 2. Second Call Fails (But your code ignores this error, so we test that branch)
		mockDB.On("GetQuizAttemptStatus", mock.Anything, uID, qID).
			Return(nil, errors.New("attempt status check failed but ignored"))

		// 3. Third Call FAILS (This is the branch that returns nil, err)
		mockDB.On("GetQuestionsByQuizId", mock.Anything, qID, mock.Anything).
			Return([]dbModelQuestions.Question{}, errors.New("fatal question fetch error"))

		// Setup Gin context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", uID)
		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "88"}}

		// Execute
		controller.GetQuizByID(ctx)

		// Assertions
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		mockDB.AssertExpectations(t)
	})

}

// --- Benchmark Logic ---
func BenchmarkQuizHandlers(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mockDB := new(MockQuizDB)
	controller := NewQuizController(mockDB)

	qID := int64(1)
	quiz := dbModelQuiz.Quiz{ID: &qID, NumQuestions: int64Ptr(1)}
	mockDB.On("GetQuizById", mock.Anything, mock.Anything, mock.Anything).Return(quiz, nil)
	mockDB.On("GetQuizAttemptStatus", mock.Anything, mock.Anything, mock.Anything).Return(nil, nil)
	mockDB.On("GetQuestionsByQuizId", mock.Anything, mock.Anything, mock.Anything).Return([]dbModelQuestions.Question{}, nil)

	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Set("userId", int64(555))
	ctx.Params = []gin.Param{{Key: "quiz_id", Value: "1"}}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		controller.GetQuizByID(ctx)
	}
}

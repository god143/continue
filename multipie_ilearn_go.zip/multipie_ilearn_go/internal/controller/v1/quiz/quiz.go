package quiz

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (q *quizController) GetCourseQuiz(ctx *gin.Context) {
	var resp *utils.Response

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getCourseResp, err := q.getQuizByCourseHelper(ctx, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quizzes for course", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quizzes"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(getCourseResp, nil))
}

func (q *quizController) GetIndependentQuiz(ctx *gin.Context) {
	var resp *utils.Response

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getIndependentQuiz, err := q.getIndependentQuizHelper(ctx, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch independent quizzes", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch independent quizzes"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(getIndependentQuiz, nil))
}

func (q *quizController) GetAnswersByQuizID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuizByIDRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid quizId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	AnswerResp, err := q.getAnswersByIDHelper(ctx, request, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quiz questions", zap.Int64("quizId", request.ID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quiz by ID"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(AnswerResp, nil)

	// encryptedResponse, err := utils.EncryptResponse(resp, []byte(config.GetConfig().SecurityKeys.Key), []byte(config.GetConfig().SecurityKeys.IV))
	// if err != nil {
	// 	logger.Error(ctx, "unable to encrypt response", zap.Int64("quizId", request.ID), zap.Error(err))
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer("unable to encrypt response"))
	// 	ctx.JSON(http.StatusInternalServerError, resp)
	// 	ctx.Abort()
	// 	return
	// }

	// a, _ := utils.DecryptResponse(encryptedResponse, []byte(config.GetConfig().SecurityKeys.Key), []byte(config.GetConfig().SecurityKeys.IV))
	// fmt.Println(string(a))

	ctx.JSON(http.StatusOK, resp)
}

func (q *quizController) GetQuizByID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuizByIDRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid quizId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	quizResult, err := q.getQuizByIDHelper(ctx, request, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quiz questions", zap.Int64("quizId", request.ID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quiz by ID"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(quizResult, nil))
}

func (q *quizController) GetQuizByCourseID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuizByCourseIDRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid courseId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	quizResult, err := q.getQuizByCourseIDHelper(ctx, request, userID)
	if err != nil {
		logger.Error(ctx, "unable to fetch quizzes for course", zap.Int64("courseId", request.CourseID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch quiz by course ID"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(quizResult, nil))
}

func (q *quizController) GenerateCertificate(ctx *gin.Context) {
	var (
		request struct {
			UserID int64    `json:"user_id"`
			QuizID int64    `json:"quiz_id" binding:"required"`
			Score  *float64 `json:"score" binding:"required"`
			Date   string   `json:"date"`
		}
		certificatePathResponse GenerateCertificateResponse
		resp                    *utils.Response
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}
	var userID int64
	var err error
	if request.UserID != 0 {
		userID = request.UserID
	} else {
		userID, err = utils.ExtractUserId(ctx)

		if err != nil {
			logger.Error(ctx, "failed to extract user ID", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to extract user ID"))
			ctx.JSON(http.StatusUnauthorized, resp)
			return
		}
	}

	certificatePath, err := q.handleCertificateGeneration(ctx, userID, request.QuizID, request.Score, request.Date)
	if err != nil {
		logger.Error(ctx, "certificate generation failed", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("certificate generation failed"))
		ctx.JSON(http.StatusInternalServerError, resp)
		return
	}

	certificatePathResponse.CertificatePath = certificatePath

	resp = utils.NewV1Response(certificatePathResponse, nil)
	ctx.JSON(http.StatusOK, resp)
}

package resource

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type resourceController struct {
	db db.DBLayer
}

type ResourceControllerGroup interface {
	GetResourceById(ctx *gin.Context)
	GetResources(ctx *gin.Context)
	GetRelatedResources(ctx *gin.Context)
}

func NewResourceControllerGroup(db db.DBLayer) ResourceControllerGroup {
	return &resourceController{
		db: db,
	}
}

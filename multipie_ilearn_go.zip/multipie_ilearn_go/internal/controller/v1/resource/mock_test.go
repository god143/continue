package resource

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModelBookmark "multipie_ilearn_go/internal/db/bookmark"
	dbModel "multipie_ilearn_go/internal/db/resource"

	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- MOCK DB DEFINITION ---
type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetResourceById(ctx context.Context, id int, v *bool) (*dbModel.Resource, error) {
	args := m.Called(ctx, id, v)
	res, _ := args.Get(0).(*dbModel.Resource)
	return res, args.Error(1)
}

func (m *MockDB) GetBookmarkByCustomParams(ctx context.Context, ids []int, types []string, subs []string, uid int64) ([]dbModelBookmark.Bookmark, error) {
	args := m.Called(ctx, ids, types, subs, uid)
	res, _ := args.Get(0).([]dbModelBookmark.Bookmark)
	return res, args.Error(1)
}

func (m *MockDB) GetTagKeysByModel(ctx context.Context, id int64) (*[]string, error) {
	args := m.Called(ctx, id)
	res, _ := args.Get(0).(*[]string)
	return res, args.Error(1)
}

func (m *MockDB) GetResourcesByCategoryAndType(ctx context.Context, cid int, rt constants.ResourceTypeEnum, st constants.SubTypeEnum, v *bool, is *bool, p utils.Pagination, f constants.FilterTypeEnum) ([]dbModel.GetResourceByCategory, error) {
	args := m.Called(ctx, cid, rt, st, v, is, p, f)
	res, _ := args.Get(0).([]dbModel.GetResourceByCategory)
	return res, args.Error(1)
}

func (m *MockDB) GetResourcesByType(ctx context.Context, rt constants.ResourceTypeEnum, st constants.SubTypeEnum, p utils.Pagination, is *bool, f constants.FilterTypeEnum) ([]dbModel.GetResourceByCategory, error) {
	args := m.Called(ctx, rt, st, p, is, f)
	res, _ := args.Get(0).([]dbModel.GetResourceByCategory)
	return res, args.Error(1)
}

func (m *MockDB) GetRelatedResources(ctx context.Context, id int64, rt constants.RelatedResourcesTagEnum, st constants.TagMappingSubTypeEnum, l int64) ([]dbModel.Resource, error) {
	args := m.Called(ctx, id, rt, st, l)
	res, _ := args.Get(0).([]dbModel.Resource)
	return res, args.Error(1)
}

func (m *MockDB) GetParentCaregorybyResourceId(ctx context.Context, id int64) (*[]string, error) {
	args := m.Called(ctx, id)

	// Safety check for nil returns
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*[]string), args.Error(1)
}

func ptrResType(v constants.ResourceTypeEnum) *constants.ResourceTypeEnum { return &v }
func ptrSliceString(v []string) *[]string                                 { return &v }
func ptr[T any](v T) *T                                                   { return &v }

// --- UNIFIED TEST SUITE ---
func TestResourceController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	//1.GetResourceById Tests
	t.Run("GetResourceById_Tests", func(t *testing.T) {
		tests := []struct {
			name           string
			uriID          string
			userID         interface{}
			setupMock      func(*MockDB)
			expectedStatus int
		}{
			{
				name:   "Success_Full_Flow",
				uriID:  "10",
				userID: int64(12345),
				setupMock: func(m *MockDB) {
					id := 10
					res := &dbModel.Resource{
						ID:   &id,
						Type: ptrResType(constants.ResourceTypeEnumVideo),
					}

					m.On("GetResourceById", mock.Anything, 10, mock.Anything).Return(res, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, []int{10}, []string{"video"}, mock.Anything, int64(12345)).Return([]dbModelBookmark.Bookmark{}, nil)

					// Return a pointer to a slice
					mockTags := []string{"stock", "finance"}
					m.On("GetParentCaregorybyResourceId", mock.Anything, int64(10)).
						Return(&mockTags, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:   "WorstCase_GetResourceById_DB_Failure",
				uriID:  "99",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					m.On("GetResourceById", mock.Anything, 99, mock.Anything).
						Return(nil, errors.New("simulated database connection error"))
					// Do not mock anything else, as the controller should return early
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:   "Edge_DB_Bookmark_Failure",
				uriID:  "30",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					id := 30
					m.On("GetResourceById", mock.Anything, 30, mock.Anything).
						Return(&dbModel.Resource{ID: &id, Type: ptrResType(constants.ResourceTypeEnumVideo)}, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("bookmark service down"))
					// Do not mock GetTagKeysByModel, as it's called after bookmark logic in the controller
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:           "Edge_Invalid_ID_Format",
				uriID:          "not_number",
				userID:         int64(123),
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusBadRequest,
			},
			{
				name:           "Edge_Unauthorized_User",
				uriID:          "10",
				userID:         nil, // Missing user_id in context
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusUnauthorized,
			},
			{
				name:   "Edge_DB_Tag_Failure_After_Resource_Found",
				uriID:  "10",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					id := 10
					// 1. Mock Resource Success
					m.On("GetResourceById", mock.Anything, 10, mock.Anything).
						Return(&dbModel.Resource{ID: &id, Type: ptrResType(constants.ResourceTypeEnumVideo)}, nil)

					// 2. Mock Bookmark Success (or mock.Anything)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelBookmark.Bookmark{}, nil)

					// 3. FIX: Add the missing mock for the method that was "unexpected"
					// Return an error here to trigger the InternalServerError you expect
					m.On("GetParentCaregorybyResourceId", mock.Anything, int64(10)).
						Return(nil, errors.New("tag db error"))

				},
				expectedStatus: http.StatusInternalServerError,
			},

			{
				name:           "Edge_Unauthorized_Wrong_Type",
				uriID:          "10",
				userID:         "string_instead_of_int64",
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusUnauthorized,
			},
			{
				name:   "Success_With_Empty_Tags",
				uriID:  "40",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					id := 40
					// 1. Mock Resource Fetch
					m.On("GetResourceById", mock.Anything, 40, mock.Anything).
						Return(&dbModel.Resource{ID: &id, Type: ptrResType(constants.ResourceTypeEnumVideo)}, nil)

					// 2. Mock Bookmark Fetch
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelBookmark.Bookmark{}, nil)

					// 3. FIX: You MUST add this call because line 44 in your controller requires it
					// We return an empty slice to satisfy the "Empty Tags" test name
					emptyTags := []string{}
					m.On("GetParentCaregorybyResourceId", mock.Anything, int64(40)).
						Return(&emptyTags, nil)

					// 4. Existing Mock (If your controller calls this later)
					m.On("GetTagKeysByModel", mock.Anything, int64(40)).
						Return(ptrSliceString([]string{}), nil)
				},
				expectedStatus: http.StatusOK,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {

				mDB := new(MockDB)
				ctrl := &resourceController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Params = []gin.Param{{Key: "resource_id", Value: tt.uriID}}
				if tt.userID != nil {
					c.Set("userId", tt.userID)
				}

				tt.setupMock(mDB)
				ctrl.GetResourceById(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})

	//2. GetResources Tests
	t.Run("GetResources_Coverage_Expansion", func(t *testing.T) {
		tests := []struct {
			name           string
			query          string
			userID         interface{}
			setupMock      func(*MockDB)
			expectedStatus int
		}{
			{
				name:   "Success_By_ResourceType_Only",
				query:  "resource_type=video&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					res := []dbModel.GetResourceByCategory{{
						ID: ptr(1), Type: ptr(constants.ResourceTypeEnumVideo), SubType: ptr(constants.SubTypeEnumPrimary),
					}}
					m.On("GetResourcesByType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(res, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, []int{1}, []string{"video"}, []string{"primary"}, int64(123)).
						Return([]dbModelBookmark.Bookmark{}, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:   "Success_By_CategoryID_Branch", // Covers the 'if request.CategoryID != nil' branch
				query:  "category_id=10&resource_type=video&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					res := []dbModel.GetResourceByCategory{{
						ID: ptr(10), Type: ptr(constants.ResourceTypeEnumVideo), SubType: ptr(constants.SubTypeEnumPrimary),
					}}
					m.On("GetResourcesByCategoryAndType", mock.Anything, 10, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(res, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelBookmark.Bookmark{}, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:   "Success_With_Existing_Bookmarks", // Covers the map/matching logic in helper
				query:  "resource_type=video&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					res := []dbModel.GetResourceByCategory{{
						ID: ptr(1), Type: ptr(constants.ResourceTypeEnumVideo), SubType: ptr(constants.SubTypeEnumPrimary),
					}}
					m.On("GetResourcesByType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(res, nil)
					// Mock a matching bookmark
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelBookmark.Bookmark{{ID: ptr(int64(99)), ModelId: ptr(int64(1))}}, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:           "Edge_Missing_Required_ResourceType", // Covers validation failure path
				query:          "sub_type=primary",
				userID:         int64(123),
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusBadRequest,
			},
			{
				name:   "WorstCase_DB_Fetch_Failure", // Covers internal error handling
				query:  "resource_type=video&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					m.On("GetResourcesByType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("db connection timeout"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:   "WorstCase_Bookmark_Mapping_Failure", // Covers error path after resources found
				query:  "resource_type=video&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					res := []dbModel.GetResourceByCategory{{ID: ptr(1), Type: ptr(constants.ResourceTypeEnumVideo), SubType: ptr(constants.SubTypeEnumPrimary)}}
					m.On("GetResourcesByType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(res, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("redis bookmark cache failure"))
				},
				expectedStatus: http.StatusInternalServerError,
			},

			{
				name:   "Success_With_Trending_Filter",
				query:  "resource_type=video&sub_type=primary&filter=trending",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					res := []dbModel.GetResourceByCategory{{ID: ptr(1), Type: ptr(constants.ResourceTypeEnumVideo), SubType: ptr(constants.SubTypeEnumPrimary)}}
					// Matches the trending filter enum
					m.On("GetResourcesByType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, constants.FilterTypeEnumTrending).
						Return(res, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelBookmark.Bookmark{}, nil)
				},
				expectedStatus: http.StatusOK,
			},

			{
				name:   "Edge_Video_Missing_SubType",
				query:  "resource_type=video", // No sub_type provided
				userID: int64(123),
				setupMock: func(m *MockDB) {
					// No mock setup needed as it fails internal validation
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:   "Edge_Article_With_Forbidden_SubType",
				query:  "resource_type=article&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					// Article + SubType is forbidden in your helper logic
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:           "Edge_CategoryPath_Invalid_Filter",
				query:          "category_id=1&resource_type=video&sub_type=primary&filter=invalid_val",
				userID:         int64(123),
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:           "Edge_GetResources_Unauthorized_Type",
				query:          "resource_type=video&sub_type=primary",
				userID:         "string_id", // Wrong type to trigger ExtractUserId failure
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusUnauthorized,
			},
			{
				name:   "WorstCase_Category_DB_Failure",
				query:  "category_id=1&resource_type=video&sub_type=primary",
				userID: int64(123),
				setupMock: func(m *MockDB) {
					m.On("GetResourcesByCategoryAndType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("category db error"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &resourceController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Request, _ = http.NewRequest("GET", "/?"+tt.query, nil)
				if tt.userID != nil {
					c.Set("userId", tt.userID)
				}
				tt.setupMock(mDB)
				ctrl.GetResources(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})

	t.Run("GetRelatedResources_Coverage_Expansion", func(t *testing.T) {
		tests := []struct {
			name           string
			idParam        string
			typeParam      string
			query          string
			userID         interface{}
			setupMock      func(*MockDB)
			expectedStatus int
		}{
			// 1. Success with Bookmark Mapping (hits the loop logic in helper)
			{
				name:      "Success_With_Bookmark_Mapping",
				idParam:   "50",
				typeParam: "video",
				query:     "limit=5&sub_type=primary",
				userID:    int64(123),
				setupMock: func(m *MockDB) {
					id := 60
					resType := constants.ResourceTypeEnumVideo
					subType := constants.SubTypeEnumPrimary
					mockRes := dbModel.Resource{
						ID: &id, Type: &resType, SubType: &subType,
					}
					// Mock the main resource fetch
					m.On("GetRelatedResources", mock.Anything, int64(50), mock.Anything, mock.Anything, int64(5)).
						Return([]dbModel.Resource{mockRes}, nil)
					// Mock a matching bookmark to cover the 'if exists' branch in mapping
					m.On("GetBookmarkByCustomParams", mock.Anything, []int{60}, []string{"video"}, []string{"primary"}, int64(123)).
						Return([]dbModelBookmark.Bookmark{{ID: ptr(int64(999)), ModelId: ptr(int64(60))}}, nil)
				},
				expectedStatus: http.StatusOK,
			},

			// 2. Edge Case: Invalid Enum for Related SubType (hits constants.ParseTagMappingSubTypeEnum error)
			{
				name:           "Edge_Invalid_SubType_Enum",
				idParam:        "50",
				typeParam:      "video",
				query:          "limit=5&sub_type=invalid_enum_val",
				userID:         int64(123),
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusInternalServerError,
			},

			// 3. Edge Case: Invalid Resource Type for SubType logic
			{
				name:           "Edge_Forbidden_SubType_For_Non_Video",
				idParam:        "50",
				typeParam:      "article",
				query:          "limit=5&sub_type=primary",
				userID:         int64(123),
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusInternalServerError,
			},

			// 4. Worst Case: GetRelatedResources DB failure
			{
				name:      "WorstCase_DB_Fetch_Failure",
				idParam:   "50",
				typeParam: "video",
				query:     "limit=5&sub_type=primary",
				userID:    int64(123),
				setupMock: func(m *MockDB) {
					m.On("GetRelatedResources", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("db query timeout"))
				},
				expectedStatus: http.StatusInternalServerError,
			},

			// 5. Worst Case: Bookmark DB failure after results found
			{
				name:      "WorstCase_Bookmark_Mapping_Error",
				idParam:   "50",
				typeParam: "video",
				query:     "limit=5&sub_type=primary",
				userID:    int64(123),
				setupMock: func(m *MockDB) {
					id := 60
					m.On("GetRelatedResources", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModel.Resource{{ID: &id, Type: ptr(constants.ResourceTypeEnumVideo), SubType: ptr(constants.SubTypeEnumPrimary)}}, nil)
					m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("bookmark service connection refused"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &resourceController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Request, _ = http.NewRequest("GET", "/?"+tt.query, nil)
				c.Params = []gin.Param{
					{Key: "resource_id", Value: tt.idParam},
					{Key: "resource_type", Value: tt.typeParam},
				}
				if tt.userID != nil {
					c.Set("userId", tt.userID)
				}
				tt.setupMock(mDB)
				ctrl.GetRelatedResources(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})

}

// --- PERFORMANCE BENCHMARKS ---
func BenchmarkGetResourceById_Optimized(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	id := 1

	// Setup Mocks once
	mDB.On("GetResourceById", mock.Anything, 1, mock.Anything).Return(&dbModel.Resource{ID: &id, Type: ptrResType(constants.ResourceTypeEnumVideo)}, nil)
	mDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModelBookmark.Bookmark{}, nil)
	mDB.On("GetTagKeysByModel", mock.Anything, mock.Anything).Return(ptrSliceString([]string{"Tag"}), nil)

	ctrl := &resourceController{db: mDB}

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Params = []gin.Param{{Key: "resource_id", Value: "1"}}
	c.Set("userId", int64(123))
	c.Request, _ = http.NewRequest("GET", "/resources/1", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetResourceById(c)
	}
}

func BenchmarkGetRelatedResources_ComplexMapping(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("GetRelatedResources", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModel.Resource{}, nil)
	mDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModelBookmark.Bookmark{}, nil)

	ctrl := &resourceController{db: mDB}

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	req, _ := http.NewRequest("GET", "/?limit=10&sub_type=short", nil)
	c.Request = req
	c.Params = []gin.Param{{Key: "resource_id", Value: "1"}, {Key: "resource_type", Value: "video"}}
	c.Set("userId", int64(123))

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetRelatedResources(c)
	}
}

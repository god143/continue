package resource

import (
	"encoding/json"
	"multipie_ilearn_go/internal/constants"
	"time"
)

type ResourceResult struct {
	ID             *int                        `json:"id,omitempty"`
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	CreatedAt      *time.Time                  `json:"created_at,omitempty"`
	UpdatedAt      *time.Time                  `json:"updated_at,omitempty"`
}

type GetResourceByIDRequest struct {
	ID int `uri:"resource_id" binding:"required"`
}

type GetResourcesByCategoryTypeRequest struct {
	CategoryID   int    `json:"category_id" binding:"required" form:"category_id"`
	ResourceType string `json:"resource_type" binding:"required" form:"resource_type"`
	SubType      string `json:"sub_type" form:"sub_type"`
}

type GetResourceForDashboardRequest struct {
	ContentType string `form:"content_type" binding:"required,oneof=short video article"`
	Page        int64  `form:"page" binding:"gte=0"`
	PageSize    int64  `form:"page_size" binding:"lte=20"`
}

type GetResourcesRequest struct {
	CategoryID   *int   `json:"category_id" form:"category_id"`
	ResourceType string `json:"resource_type" binding:"required" form:"resource_type"`
	SubType      string `json:"sub_type" form:"sub_type"`
	IsShort      bool   `json:"is_short" form:"is_short"`
	Page         int    `json:"page" form:"page"`
	PageSize     int    `json:"page_size" form:"page_size"`
	Filter       string `json:"filter" form:"filter"`
}

type GetRelatedResourcesRequest struct {
	ResourceID   int64  `uri:"resource_id" binding:"required"`
	ResourceType string `uri:"resource_type" binding:"required,oneof=video article podcast learn expert"`
}

type GetRelatedResourcesQueryRequest struct {
	Limit   int64  `form:"limit" binding:"required"`
	SubType string `form:"sub_type"`
}

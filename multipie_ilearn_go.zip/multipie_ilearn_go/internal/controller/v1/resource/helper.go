package resource

import (
	"context"
	"errors"
	"fmt"
	"html"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/resource"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"strings"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (r *resourceController) getResourceByIdHelper(ctx context.Context, id int, visible *bool, userId *int64) (*dbModel.Resource, error) {
	var resourceIds []int
	var resourceTypes []string
	var bookmarkId *int64
	var subtype []string

	resourceData, err := r.db.GetResourceById(ctx, id, visible)
	if err != nil {
		logger.Error(ctx, "unable to fetch resource from db", zap.Error(err))
		return nil, errors.New("unable to fetch resource from db")
	}

	resourceIds = append(resourceIds, *resourceData.ID)
	resourceTypes = append(resourceTypes, resourceData.Type.String())

	bookmark, err := r.db.GetBookmarkByCustomParams(ctx, resourceIds, resourceTypes, subtype, *userId)
	if err != nil {
		return nil, err
	}
	for _, bm := range bookmark {
		bookmarkId = bm.ID
	}
	isBookmark := len(bookmark) != 0
	resourceData.IsBookmark = &isBookmark
	resourceData.BookmarkId = bookmarkId

	content := resourceData.Content

	if resourceData.Type.String() == "article" && content != nil {
		cleanedConetnt := cleanSpecialCharacters(*content)
		content = &cleanedConetnt
	}

	resourceData.Content = content

	return resourceData, nil
}

func (r *resourceController) getResourcesByCategoryTypeHelper(ctx context.Context, categoryID int, resourceTypeStr string, subTypeStr string, visible *bool, isShort *bool, pagination utils.Pagination, filter string, userId *int64) ([]dbModel.GetResourceByCategory, error) {
	var resourceIds []int
	var resourceTypes []string
	var subTypes []string
	var resourceType constants.ResourceTypeEnum
	var subType constants.SubTypeEnum
	var filterType constants.FilterTypeEnum
	var err error

	if subTypeStr != "" && resourceTypeStr == constants.ResourceTypeEnumVideo.String() {
		subType, err = constants.ParseSubTypeEnum(subTypeStr)
		if err != nil {
			logger.Error(ctx, "Invalid sub type", zap.String("sub_type", subTypeStr), zap.Error(err))
			return nil, fmt.Errorf("invalid sub type: %w", err)
		}
	} else if subTypeStr != "" && resourceTypeStr != constants.ResourceTypeEnumVideo.String() {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	} else if subTypeStr == "" && resourceTypeStr == constants.ResourceTypeEnumVideo.String() {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	}

	resourceType, err = constants.ParseResourceTypeEnum(resourceTypeStr)
	if err != nil {
		logger.Error(ctx, "Invalid resource type", zap.String("resource_type", resourceTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid resource type: %w", err)
	}

	if filter != "" {
		filterType, err = constants.ParseFilterTypeEnum(filter)
		if err != nil {
			logger.Error(ctx, "Invalid filter type", zap.String("filter", filter), zap.Error(err))
			return nil, fmt.Errorf("invalid filter type: %w", err)
		}
	} else {
		filterType = constants.FilterTypeEnum("")
	}

	resourceData, err := r.db.GetResourcesByCategoryAndType(ctx, categoryID, resourceType, subType, visible, isShort, pagination, filterType)
	if err != nil {
		logger.Error(ctx, "unable to fetch resources from db", zap.Error(err))
		return nil, fmt.Errorf("unable to fetch resources from db: %w", err)
	}

	for _, resource := range resourceData {
		resourceIds = append(resourceIds, *resource.ID)
		resourceTypes = append(resourceTypes, resource.Type.String())
		subTypes = append(subTypes, resource.SubType.String())
	}

	bookmarks, err := r.db.GetBookmarkByCustomParams(ctx, resourceIds, resourceTypes, subTypes, *userId)
	if err != nil {
		return nil, err
	}

	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)
		}
	}

	responses := make([]dbModel.GetResourceByCategory, 0, len(resourceData))

	for _, m := range resourceData {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}

		content := m.Content

		if m.Type.String() == "article" && content != nil {
			cleanedConetnt := cleanSpecialCharacters(*content)
			content = &cleanedConetnt
		}

		responses = append(responses, dbModel.GetResourceByCategory{
			ID:             m.ID,
			URL:            m.URL,
			DarkModeURL:    m.DarkModeURL,
			Type:           m.Type,
			SubType:        m.SubType,
			Name:           m.Name,
			Description:    m.Description,
			CategoryID:     m.CategoryID,
			CourseModuleID: m.CourseModuleID,
			Icon:           m.Icon,
			Views:          m.Views,
			Likes:          m.Likes,
			Visible:        m.Visible,
			IsShort:        m.IsShort,
			Metadata:       m.Metadata,
			Content:        content,
			CreatedAt:      m.CreatedAt,
			UpdatedAt:      m.UpdatedAt,
			IsBookmark:     isBookmark,
			BookmarkId:     bookmarkIdPtr,
		})
	}
	return responses, nil
}

func (r *resourceController) getResourcesByTypeHelper(ctx *gin.Context, resourceTypeStr string, subTypeStr string, pagination utils.Pagination, isShort *bool, filter string, userId *int64) ([]dbModel.GetResourceByCategory, error) {
	var resourceIds []int
	var resourceTypes []string
	var subTypes []string
	var resources []dbModel.GetResourceByCategory
	var resourceType constants.ResourceTypeEnum
	var subType constants.SubTypeEnum
	var err error

	if subTypeStr != "" && resourceTypeStr == constants.ResourceTypeEnumVideo.String() {
		subType, err = constants.ParseSubTypeEnum(subTypeStr)
		if err != nil {
			logger.Error(ctx, "Invalid sub type", zap.String("sub_type", subTypeStr), zap.Error(err))
			return nil, fmt.Errorf("invalid sub type: %w", err)
		}
	} else if subTypeStr != "" {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	} else if subTypeStr == "" && resourceTypeStr == constants.ResourceTypeEnumVideo.String() {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	}

	resourceType, err = constants.ParseResourceTypeEnum(resourceTypeStr)
	if err != nil {
		logger.Error(ctx, "Invalid resource type", zap.String("resource_type", resourceTypeStr), zap.Error(err))
		return nil, fmt.Errorf("invalid resource type: %w", err)
	}

	var filterType constants.FilterTypeEnum
	if filter != "" {
		filterType, err = constants.ParseFilterTypeEnum(filter)
		if err != nil {
			logger.Error(ctx, "Invalid filter type", zap.String("filter", filter), zap.Error(err))
			return nil, fmt.Errorf("invalid filter type: %w", err)
		}
	} else {
		filterType = constants.FilterTypeEnum("")
	}

	resources, err = r.db.GetResourcesByType(ctx, resourceType, subType, pagination, isShort, filterType)
	if err != nil {
		logger.Error(ctx, "Failed to fetch resources by type", zap.Error(err))
		return nil, err
	}

	for _, resource := range resources {
		resourceIds = append(resourceIds, *resource.ID)
		resourceTypes = append(resourceTypes, resource.Type.String())
		subTypes = append(subTypes, resource.SubType.String())
	}

	bookmarks, err := r.db.GetBookmarkByCustomParams(ctx, resourceIds, resourceTypes, subTypes, *userId)
	if err != nil {
		return nil, err
	}
	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)

		}
	}

	responses := make([]dbModel.GetResourceByCategory, 0, len(resources))

	for _, m := range resources {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}

		content := m.Content

		if m.Type.String() == "article" && content != nil {
			cleanedConetnt := cleanSpecialCharacters(*content)
			content = &cleanedConetnt
		}

		responses = append(responses, dbModel.GetResourceByCategory{
			ID:             m.ID,
			URL:            m.URL,
			DarkModeURL:    m.DarkModeURL,
			Type:           m.Type,
			SubType:        m.SubType,
			Name:           m.Name,
			Description:    m.Description,
			CategoryID:     m.CategoryID,
			CourseModuleID: m.CourseModuleID,
			Icon:           m.Icon,
			Views:          m.Views,
			Likes:          m.Likes,
			Visible:        m.Visible,
			IsShort:        m.IsShort,
			Metadata:       m.Metadata,
			Content:        content,
			CreatedAt:      m.CreatedAt,
			UpdatedAt:      m.UpdatedAt,
			IsBookmark:     isBookmark,
			BookmarkId:     bookmarkIdPtr,
		})
	}

	return responses, nil

}

func (r *resourceController) GetFullRelatedResources(ctx context.Context, resourceID int64, modelType string, subType string, limit int64, userId *int64) ([]dbModel.Resource, error) {
	var resourceType constants.RelatedResourcesTagEnum
	var resourceSubType constants.TagMappingSubTypeEnum
	var relatedResource []dbModel.Resource
	var resourceIds []int
	var resourceTypes []string
	var subTypes []string
	var err error

	if modelType == constants.RelatedResourcesTagEnumVideo.String() && subType != "" {
		resourceSubType, err = constants.ParseTagMappingSubTypeEnum(subType)
		if err != nil {
			logger.Error(ctx, "invalid value for related resource type", zap.Error(err))
			return nil, errors.New("invalid value for related sub type")
		}
	} else if subType != "" {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subType), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	} else if subType == "" && modelType == constants.RelatedResourcesTagEnumVideo.String() {
		logger.Error(ctx, "invalid paramaters to fetch resources", zap.String("sub type", subType), zap.Error(err))
		return nil, fmt.Errorf("invalid paramaters to fetch resources")
	}

	resourceType, err = constants.ParseRelatedResourcesTagEnum(modelType)
	if err != nil {
		logger.Error(ctx, "invalid value for related resource type", zap.Error(err))
		return nil, errors.New("invalid value for related resource type")
	}

	// TODO: ADD RECENCY LOGIC
	relatedResource, err = r.db.GetRelatedResources(ctx, resourceID, resourceType, resourceSubType, limit)
	if err != nil {
		logger.Error(ctx, "Failed to fetch related resources ", zap.Error(err))
		return nil, err
	}
	for _, resource := range relatedResource {
		resourceIds = append(resourceIds, *resource.ID)
		resourceTypes = append(resourceTypes, resource.Type.String())
		subTypes = append(subTypes, resource.SubType.String())
	}

	bookmarks, err := r.db.GetBookmarkByCustomParams(ctx, resourceIds, resourceTypes, subTypes, *userId)
	if err != nil {
		return nil, err
	}

	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)

		}
	}

	responses := make([]dbModel.Resource, 0, len(relatedResource))

	for _, m := range relatedResource {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}

		content := m.Content

		if m.Type.String() == "article" && content != nil {
			cleanedConetnt := cleanSpecialCharacters(*content)
			content = &cleanedConetnt
		}
		responses = append(responses, dbModel.Resource{
			ID:             m.ID,
			URL:            m.URL,
			DarkModeURL:    m.DarkModeURL,
			Type:           m.Type,
			SubType:        m.SubType,
			Name:           m.Name,
			Description:    m.Description,
			CategoryID:     m.CategoryID,
			CourseModuleID: m.CourseModuleID,
			Icon:           m.Icon,
			Views:          m.Views,
			Likes:          m.Likes,
			Visible:        m.Visible,
			IsShort:        m.IsShort,
			Metadata:       m.Metadata,
			Content:        content,
			CreatedAt:      m.CreatedAt,
			UpdatedAt:      m.UpdatedAt,
			IsBookmark:     isBookmark,
			BookmarkId:     bookmarkIdPtr,
		})
	}

	return responses, nil

}

func cleanSpecialCharacters(input string) string {
	// Decode HTML entities such as &nbsp;, &amp;, and &quot;.
	input = html.UnescapeString(input)

	replacements := strings.NewReplacer(
		// Spaces
		"\u00a0", " ",
		"\u2007", " ",
		"\u202f", " ",

		// Currency
		"â‚¹", "₹",
		"‚¹", "₹",
		",¹", "₹",
		"‚₹", "₹",
		",₹", "₹",

		// Bullet points and list symbols
		"â€¢", "•",
		"â—", "●",
		"â—‹", "○",
		"â–ª", "▪",
		"â– ", "■",
		"â–º", "►",
		"â†’", "→",
		"â‡’", "⇒",

		// Dashes and ellipsis
		"â€“", "–",
		"€“", "–",
		"â€”", "—",
		"âˆ’", "−",
		"â€¦", "…",

		// Single quotation marks
		"â€™", "’",
		"â€˜", "‘",

		// Double quotation marks
		"â€œ", "“",
		"â€\x9d", "”",

		// Copyright and related symbols
		"â„¢", "™",
		"Â©", "©",
		"Â®", "®",
		"Â°", "°",
		"Â±", "±",
		"Â", "",

		// Common incorrectly encoded accented characters
		"Ã©", "é",
		"Ã¨", "è",
		"Ã¡", "á",
		"Ã³", "ó",
		"Ã¼", "ü",
		"Ã±", "ñ",
	)

	return replacements.Replace(input)
}

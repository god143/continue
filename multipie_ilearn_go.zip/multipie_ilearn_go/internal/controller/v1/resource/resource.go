package resource

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	dbModel "multipie_ilearn_go/internal/db/resource"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (r *resourceController) GetResourceById(ctx *gin.Context) {
	var (
		resp                *utils.Response
		getResourceByIdResp *dbModel.Resource
		request             GetResourceByIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getResourceByIdResp, err = r.getResourceByIdHelper(ctx, request.ID, utils.BoolToPointer(true), &uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	tags, err := r.db.GetParentCaregorybyResourceId(ctx, int64(request.ID))
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}
	getResourceByIdResp.Tags = tags

	resp = utils.NewV1Response(getResourceByIdResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (r *resourceController) GetResources(ctx *gin.Context) {
	var (
		resp       *utils.Response
		resources  []dbModel.GetResourceByCategory
		request    GetResourcesRequest
		pagination utils.Pagination
		err        error
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "Failed to bind query params", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid query params"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	pagination.Page = request.Page
	pagination.PageSize = request.PageSize

	if request.CategoryID != nil {
		resources, err = r.getResourcesByCategoryTypeHelper(ctx, *request.CategoryID, request.ResourceType, request.SubType, utils.BoolToPointer(true), utils.BoolToPointer(request.IsShort), pagination, request.Filter, &uid)
		if err != nil {
			logger.Error(ctx, "Failed to get resources by category type", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
			ctx.JSON(http.StatusInternalServerError, resp)
			return
		}
	} else {
		resources, err = r.getResourcesByTypeHelper(ctx, request.ResourceType, request.SubType, pagination, utils.BoolToPointer(request.IsShort), request.Filter, &uid)
		if err != nil {
			logger.Error(ctx, "Failed to get resources by type", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
			ctx.JSON(http.StatusInternalServerError, resp)
			return
		}
	}

	resp = utils.NewV1Response(resources, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *resourceController) GetRelatedResources(ctx *gin.Context) {
	var (
		req      GetRelatedResourcesRequest
		queryReq GetRelatedResourcesQueryRequest
		data     []dbModel.Resource
		resp     *utils.Response
	)

	if err := ctx.ShouldBindUri(&req); err != nil {
		logger.Error(ctx, "invalid URI parameter", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid path params"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	if err := ctx.ShouldBindQuery(&queryReq); err != nil {
		logger.Error(ctx, "invalid query parameter", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid limit param"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	data, err = c.GetFullRelatedResources(ctx, req.ResourceID, req.ResourceType, queryReq.SubType, queryReq.Limit, &uid)
	if err != nil {
		logger.Error(ctx, "failed to fetch related resources", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		return
	}

	resp = utils.NewV1Response(data, nil)
	ctx.JSON(http.StatusOK, resp)
}

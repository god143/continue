package mdlcourse

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// GetCourseByCategory... fetch all courses by category
func (c *courseController) GetCourseByCategory(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseByCategoryRequest
	)
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	courseResp, err := c.getCourseByCategoryHelper(ctx, request)
	if err != nil {
		logger.Error(ctx, "unable to fetch course", zap.Int64("category", request.CategoryID), zap.Error(err))
		resp := utils.NewV1Response(nil, utils.StringToPointer("unable to fetch course"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(courseResp, nil))
}

func (c *courseController) GetCourseDetails(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseDetailsRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid courseId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	courseResp, err := c.getCourseDetailsHelper(ctx, request)
	if err != nil {
		logger.Error(ctx, "unable to fetch course", zap.Int64("courseId", request.CourseID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch course"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(courseResp, nil))
}

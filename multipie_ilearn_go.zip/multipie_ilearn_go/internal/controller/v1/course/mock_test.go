package mdlcourse

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/course"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mock Setup ---

type MockCourseDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockCourseDB) GetCourseByID(ctx context.Context, id int64, vis *bool) (dbModel.Course, error) {
	args := m.Called(ctx, id, vis)
	return args.Get(0).(dbModel.Course), args.Error(1)
}

func (m *MockCourseDB) GetCourseByCategory(ctx context.Context, catID int64, vis *bool) ([]dbModel.Course, error) {
	args := m.Called(ctx, catID, vis)
	return args.Get(0).([]dbModel.Course), args.Error(1)
}

func TestMain(m *testing.M) {
	// Initialize logger to prevent nil pointer dereference panics
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- Unit Tests ---

func TestCourseController_GetCourseByCategory(t *testing.T) {
	tests := []struct {
		name           string
		query          string
		setupMock      func(*MockCourseDB)
		expectedStatus int
	}{
		{
			name:  "Happy Path - Fetch by Category",
			query: "?category_id=5",
			setupMock: func(m *MockCourseDB) {
				m.On("GetCourseByCategory", mock.Anything, int64(5), mock.Anything).
					Return([]dbModel.Course{{ID: utils.Int64ToPointer(1)}}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Edge Case - Missing Category ID",
			query:          "",
			setupMock:      func(m *MockCourseDB) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Edge Case - Invalid Category Format",
			query:          "?category_id=abc",
			setupMock:      func(m *MockCourseDB) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:  "Edge Case - Database Failure",
			query: "?category_id=5",
			setupMock: func(m *MockCourseDB) {
				m.On("GetCourseByCategory", mock.Anything, int64(5), mock.Anything).
					Return([]dbModel.Course{}, errors.New("db connection lost"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := new(MockCourseDB)
			tt.setupMock(m)
			ctrl := NewCourseControllerGroup(m)

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			req, _ := http.NewRequest("GET", "/courses"+tt.query, nil)
			c.Request = req

			ctrl.GetCourseByCategory(c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestCourseController_GetCourseDetails(t *testing.T) {
	tests := []struct {
		name           string
		courseID       string
		setupMock      func(*MockCourseDB)
		expectedStatus int
	}{
		{
			name:     "Happy Path - Course Details",
			courseID: "100",
			setupMock: func(m *MockCourseDB) {
				m.On("GetCourseByID", mock.Anything, int64(100), mock.Anything).
					Return(dbModel.Course{ID: utils.Int64ToPointer(100)}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Edge Case - Invalid ID format",
			courseID:       "not-an-int",
			setupMock:      func(m *MockCourseDB) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:     "Edge Case - Course Not Found",
			courseID: "404",
			setupMock: func(m *MockCourseDB) {
				m.On("GetCourseByID", mock.Anything, int64(404), mock.Anything).
					Return(dbModel.Course{}, errors.New("not found"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := new(MockCourseDB)
			tt.setupMock(m)
			ctrl := NewCourseControllerGroup(m)

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Params = gin.Params{{Key: "course_id", Value: tt.courseID}}

			ctrl.GetCourseDetails(c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- Benchmarks ---

func BenchmarkGetCourseDetails(b *testing.B) {
	m := new(MockCourseDB)
	m.On("GetCourseByID", mock.Anything, mock.Anything, mock.Anything).
		Return(dbModel.Course{ID: utils.Int64ToPointer(1)}, nil)
	ctrl := NewCourseControllerGroup(m)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = gin.Params{{Key: "course_id", Value: "1"}}
		ctrl.GetCourseDetails(c)
	}
}

func BenchmarkGetCourseByCategory(b *testing.B) {
	m := new(MockCourseDB)
	m.On("GetCourseByCategory", mock.Anything, mock.Anything, mock.Anything).
		Return([]dbModel.Course{{ID: utils.Int64ToPointer(1)}}, nil)
	ctrl := NewCourseControllerGroup(m)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("GET", "/?category_id=1", nil)
		c.Request = req
		ctrl.GetCourseByCategory(c)
	}
}

package mdlcourse

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type courseController struct {
	db db.DBLayer
}

type CourseControllerGroup interface {
	GetCourseDetails(ctx *gin.Context)
	GetCourseByCategory(ctx *gin.Context)
}

func NewCourseControllerGroup(db db.DBLayer) CourseControllerGroup {
	return &courseController{
		db: db,
	}
}

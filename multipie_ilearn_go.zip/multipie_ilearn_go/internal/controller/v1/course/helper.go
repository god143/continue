package mdlcourse

import (
	"context"
	dbModel "multipie_ilearn_go/internal/db/course"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (c *courseController) getCourseDetailsHelper(ctx context.Context, request GetCourseDetailsRequest) (dbModel.Course, error) {

	course, err := c.db.GetCourseByID(ctx, request.CourseID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error in course details from database", zap.Int64("courseID", request.CourseID), zap.Error(err))
		return course, err
	}

	return course, nil
}

func (c *courseController) getCourseByCategoryHelper(ctx context.Context, request GetCourseByCategoryRequest) ([]dbModel.Course, error) {

	courses, err := c.db.GetCourseByCategory(ctx, request.CategoryID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error in fetching courses from database", zap.Error(err))
		return courses, err
	}

	return courses, nil
}

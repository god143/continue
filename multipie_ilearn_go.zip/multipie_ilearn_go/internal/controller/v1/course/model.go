package mdlcourse

type GetCourseByCategoryRequest struct {
	CategoryID int64 `form:"category_id" binding:"required"`
}

type GetCourseDetailsRequest struct {
	CourseID int64 `uri:"course_id" binding:"required"`
}

package notifications

import (
	dbModel "multipie_ilearn_go/internal/db/notifications"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

func (n *notificationsController) GetAllNotifications(ctx *gin.Context) {
	var (
		resp                *utils.Response
		GetAllNotifications []dbModel.Notifications
	)

	GetAllNotifications, err := n.getAllNotificationsHelper(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(GetAllNotifications, nil)
	ctx.JSON(http.StatusOK, resp)
}

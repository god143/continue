package notifications

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type notificationsController struct {
	db db.DBLayer
}

type NotificationsControllerGroup interface {
	GetAllNotifications(ctx *gin.Context)
}

func NewNotificationsGroup(db db.DBLayer) NotificationsControllerGroup {
	return &notificationsController{
		db: db,
	}
}

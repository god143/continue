package notifications

import (
	"context"
	"fmt"
	dbModel "multipie_ilearn_go/internal/db/notifications"
)

// fetch in-progress courses
func (c *notificationsController) getAllNotificationsHelper(ctx context.Context) ([]dbModel.Notifications, error) {
	res, err := c.db.GetAllNotifications(ctx)
	if err != nil {
		return nil, fmt.Errorf("unable to fetch courses: %w", err)
	}

	return res, nil
}

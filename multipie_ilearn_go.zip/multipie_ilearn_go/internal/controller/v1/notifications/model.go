package notifications

import (
	"multipie_ilearn_go/internal/constants"
)

type GetInProgressCoursesResponse struct {
	ID            *int64                      `json:"course_id"`
	Name          *string                     `json:"course_name"`
	RemainingTime *int64                      `json:"remaining_time"`
	ModuleCount   *int64                      `json:"module_count"`
	Format        *constants.CourseFormatEnum `json:"format"`
	Views         *int64                      `json:"views"`
	Duration      *int64                      `json:"duration"`
	Summary       *string                     `json:"summary"`
	UpdatedTime   *int64                      `json:"updated_time"`
}

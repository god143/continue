package tagMapping

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type tagMappingController struct {
	db db.DBLayer
}

type TagMappingControllerGroup interface {
	GetTagMapping(ctx *gin.Context)
	GetTagsByModel(ctx *gin.Context)
}

func NewTagMappingController(db db.DBLayer) TagMappingControllerGroup {
	return &tagMappingController{
		db: db,
	}
}

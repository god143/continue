package tagMapping

type GetTagMappingRequest struct {
	Key *string `form:"key" binding:"required"`
}

type GetTagMappingResponse struct {
	ModelId   *int64  `json:"model_id"`
	ModelType *string `json:"model_type"`
}
type GetTagsByModelRequest struct {
	ModelID   int64  `form:"model_id" binding:"required"`
	ModelType string `form:"model_type" binding:"required,oneof=video article podcast"`
}

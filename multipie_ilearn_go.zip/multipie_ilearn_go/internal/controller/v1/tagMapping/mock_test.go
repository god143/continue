package tagMapping

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/tagMapping"
	dbTagsModel "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/logger"
)

func TestMain(m *testing.M) {
	// Initialize logger once for the package to prevent nil pointer panics in helper.go
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

func ptrString(s string) *string { return &s }

type MockDB struct {
	mock.Mock
	db.DBLayer // Embeds the full interface to satisfy all 17 folders
}

const VALID_TYPE = "video" // Check your struct! Is it "news", "video", "course"?

// Note: Matches the DB interface GetTagMapping(ctx, *string)
func (m *MockDB) GetTagMapping(ctx context.Context, key *string) ([]dbModel.TagMapping, error) {
	args := m.Called(ctx, key)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.TagMapping), args.Error(1)
}

func (m *MockDB) GetTagsByModel(ctx context.Context, modelID int64, modelType string) ([]dbTagsModel.Tags, error) {
	args := m.Called(ctx, modelID, modelType)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbTagsModel.Tags), args.Error(1)
}

// --- TEST SUITE: GetTagMapping (POST/Body) ---
func TestGetTagMapping(t *testing.T) {
	tests := []struct {
		name           string
		requestBody    interface{}
		setupMock      func(*MockDB)
		expectedStatus int
	}{
		{
			name:        "Happy Path - 200 OK",
			requestBody: GetTagMappingRequest{Key: ptrString("test_key")},
			setupMock: func(m *MockDB) {
				m.On("GetTagMapping", mock.Anything, ptrString("test_key")).
					Return([]dbModel.TagMapping{{ModelId: ptrInt64(101), ModelType: ptrString("typeA")}}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Invalid JSON - 400 Bad Request",
			requestBody:    "invalid-string-not-json",
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:        "Database Failure - 500 Error",
			requestBody: GetTagMappingRequest{Key: ptrString("fail_key")},
			setupMock: func(m *MockDB) {
				m.On("GetTagMapping", mock.Anything, ptrString("fail_key")).
					Return(nil, errors.New("database connection failed"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockDB)
			ctrl := &tagMappingController{db: mDB}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			// Marshal request body
			jsonBytes, _ := json.Marshal(tt.requestBody)
			c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jsonBytes))
			c.Request.Header.Set("Content-Type", "application/json")

			tt.setupMock(mDB)
			ctrl.GetTagMapping(c)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- TEST SUITE: GetTagsByModel (GET/Query) ---
func TestGetTagsByModel(t *testing.T) {
	tests := []struct {
		name           string
		queryString    string
		setupMock      func(*MockDB)
		expectedStatus int
	}{
		{
			name:        "Happy Path - 200 OK",
			queryString: "?model_id=10&model_type=" + VALID_TYPE,
			setupMock: func(m *MockDB) {
				m.On("GetTagsByModel", mock.Anything, int64(10), VALID_TYPE).
					Return([]dbTagsModel.Tags{{ID: ptrInt64(1)}}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:        "Database Error - 500 Internal Error",
			queryString: "?model_id=10&model_type=" + VALID_TYPE,
			setupMock: func(m *MockDB) {
				m.On("GetTagsByModel", mock.Anything, int64(10), VALID_TYPE).
					Return(nil, errors.New("database connection failed"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:           "Invalid Query Params - 400 Bad Request",
			queryString:    "?model_id=not_an_int&model_type=" + VALID_TYPE,
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:        "Edge Case - Empty DB Result",
			queryString: "?model_id=99&model_type=" + VALID_TYPE,
			setupMock: func(m *MockDB) {
				m.On("GetTagsByModel", mock.Anything, int64(99), VALID_TYPE).
					Return([]dbTagsModel.Tags{}, nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockDB)
			ctrl := &tagMappingController{db: mDB}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request, _ = http.NewRequest("GET", "/"+tt.queryString, nil)

			tt.setupMock(mDB)
			ctrl.GetTagsByModel(c)

			assert.Equal(t, tt.expectedStatus, w.Code, "Failed on: "+tt.name)
			mDB.AssertExpectations(t)
		})
	}
}

// --- PERFORMANCE BENCHMARK ---
func BenchmarkGetTagsByModel(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("GetTagsByModel", mock.Anything, mock.Anything, mock.Anything).Return([]dbTagsModel.Tags{}, nil)
	ctrl := &tagMappingController{db: mDB}

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request, _ = http.NewRequest("GET", "/?model_id=1&model_type=test", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetTagsByModel(c)
	}
}

// Existing helper required for *int64 assignments
func ptrInt64(i int64) *int64 { return &i }

package tagMapping

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/tagMapping"
	dbTagsModel "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

func (c *tagMappingController) getTagMappingHelper(ctx context.Context, request GetTagMappingRequest) ([]dbModel.TagMapping, error) {

	tagMapping, err := c.db.GetTagMapping(ctx, request.Key)
	if err != nil {
		logger.Error(ctx, "unable to fetch tag mapping in database", zap.Error(err), zap.Any("tag mapping not found", tagMapping))
		return nil, errors.New("unable to fetch tag mapping in database")
	}
	return tagMapping, err
}

func (c *tagMappingController) getTagsByModelHelper(ctx context.Context, request GetTagsByModelRequest) ([]dbTagsModel.Tags, error) {
	tags, err := c.db.GetTagsByModel(ctx, request.ModelID, request.ModelType)
	if err != nil {
		logger.Error(ctx, "unable to fetch tags", zap.Error(err))
		return nil, errors.New("unable to fetch tags")
	}
	return tags, nil
}

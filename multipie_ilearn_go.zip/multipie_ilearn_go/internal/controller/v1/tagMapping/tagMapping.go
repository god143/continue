package tagMapping

import (
	dbModel "multipie_ilearn_go/internal/db/tagMapping"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *tagMappingController) GetTagMapping(ctx *gin.Context) {
	var (
		resp              *utils.Response
		getTagMappingResp []dbModel.TagMapping
		request           GetTagMappingRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getTagMappingResp, err := c.getTagMappingHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getTagMappingResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *tagMappingController) GetTagsByModel(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetTagsByModelRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request parameters", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request parameters"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	tags, err := c.getTagsByModelHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		return
	}

	resp = utils.NewV1Response(tags, nil)
	ctx.JSON(http.StatusOK, resp)
}

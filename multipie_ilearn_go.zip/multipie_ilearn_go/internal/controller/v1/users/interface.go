package users

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type usersController struct {
	db db.DBLayer
}

type UsersControllerGroup interface {
	GetUserByUID(ctx *gin.Context)
	UpdateUsers(ctx *gin.Context)
}

func NewUsersControllerGroup(db db.DBLayer) UsersControllerGroup {
	return &usersController{
		db: db,
	}
}

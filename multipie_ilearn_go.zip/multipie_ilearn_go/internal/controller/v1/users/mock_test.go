package users

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/users"
	"multipie_ilearn_go/internal/logger"
)

// --- MOCK DB DEFINITION ---
type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetUserByUID(ctx context.Context, uid int64) (*dbModel.Users, error) {
	args := m.Called(ctx, uid)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Users), args.Error(1)
}

// --- HELPERS ---
func ptrString(s string) *string { return &s }
func ptrInt64(i int64) *int64    { return &i }

func TestGetUserByUID(t *testing.T) {
	// Initialize logger to prevent nil pointer in helper
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		contextUserID  interface{} // Value to put in gin context "userId"
		setupMock      func(*MockDB)
		expectedStatus int
	}{
		{
			name:          "Happy Path - 200 OK",
			contextUserID: int64(100),
			setupMock: func(m *MockDB) {
				m.On("GetUserByUID", mock.Anything, int64(100)).
					Return(&dbModel.Users{ID: ptrInt64(1), Username: ptrString("johndoe")}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Unauthorized - Missing UserID in Context",
			contextUserID:  nil, // Simulates no middleware setting the ID
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:           "Invalid UserID Type in Context - 401",
			contextUserID:  "not-an-int64",
			setupMock:      func(m *MockDB) {},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:          "Database Error - 500 Internal Error",
			contextUserID: int64(100),
			setupMock: func(m *MockDB) {
				m.On("GetUserByUID", mock.Anything, int64(100)).
					Return(nil, errors.New("query failed"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Setup
			mDB := new(MockDB)
			ctrl := &usersController{db: mDB}
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			// Mock the context behavior of ExtractUserId
			if tt.contextUserID != nil {
				c.Set("userId", tt.contextUserID)
			}

			// Mock DB expectations
			tt.setupMock(mDB)

			// Execute
			ctrl.GetUserByUID(c)

			// Assert
			assert.Equal(t, tt.expectedStatus, w.Code)
			mDB.AssertExpectations(t)
		})
	}
}

// --- PERFORMANCE BENCHMARK ---
func BenchmarkGetUserByUID(b *testing.B) {
	// 1. Setup - Run outside the loop to exclude from timing
	gin.SetMode(gin.ReleaseMode)
	_ = logger.NewLogger("test", "error", "")

	mDB := new(MockDB)
	ctrl := &usersController{db: mDB}

	// Mock valid response
	mDB.On("GetUserByUID", mock.Anything, int64(100)).
		Return(&dbModel.Users{
			ID:       ptrInt64(1),
			Username: ptrString("benchmark_user"),
		}, nil)

	// Prepare Gin Context with required Auth data
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Set("userId", int64(100))

	// 2. Start the benchmark
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetUserByUID(c)
	}
}

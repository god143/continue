package users

type UpdateUsersRequest struct {
	ID          *int64  `json:"id"`           // Unique ID for the user
	DisplayName *string `json:"display_name"` // DisplayName of the user
	FirstName   *string `json:"first_name"`   // First Name user ID
	LastName    *string `json:"last_name"`    // Last Name of the user
	Email       *string `json:"email"`
}

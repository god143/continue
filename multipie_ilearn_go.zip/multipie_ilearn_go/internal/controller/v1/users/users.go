package users

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *usersController) GetUserByUID(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getUserByUIDResp, err := c.getUserByUIDHelper(ctx, uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getUserByUIDResp, nil)
	// encryptedResponse, err := utils.EncryptResponse(resp, []byte(config.GetConfig().SecurityKeys.Key), []byte(config.GetConfig().SecurityKeys.IV))
	// if err != nil {
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
	// 	ctx.JSON(http.StatusInternalServerError, resp)
	// 	ctx.Abort()
	// 	return
	// }
	ctx.JSON(http.StatusOK, resp)
}

func (c *usersController) UpdateUsers(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateUsersRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	request.ID = &uid

	err = c.updateUsersHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("User updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

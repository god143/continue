package users

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/users"
	"multipie_ilearn_go/internal/logger"
	"strings"

	"go.uber.org/zap"
)

/*getUserByUIDHelper... get user by Uid from database */
func (c *usersController) getUserByUIDHelper(ctx context.Context, uid int64) (*dbModel.Users, error) {

	user, err := c.db.GetUserByUID(ctx, uid)
	if err != nil {
		logger.Error(ctx, "unable to fetch user from db", zap.Error(err))
		return nil, errors.New("unable to fetch user from db")
	}

	return user, nil
}

func (c *usersController) updateUsersHelper(ctx context.Context, request UpdateUsersRequest) error {
	firstName, remainder, _ := strings.Cut(*request.DisplayName, " ")
	request.FirstName = &firstName
	request.LastName = &remainder

	users := dbModel.Users{
		ID:          request.ID,
		DisplayName: request.DisplayName,
		FirstName:   request.FirstName,
		LastName:    request.LastName,
		Email:       request.Email,
	}

	_, err := c.db.UpdateUsers(ctx, users)
	if err != nil {
		logger.Error(ctx, "unable to update users entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update users entry in database")
	}

	return nil
}

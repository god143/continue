package category

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/category"
	"multipie_ilearn_go/internal/logger"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetParentCategories(ctx context.Context, v *bool) ([]dbModel.Category, error) {
	args := m.Called(ctx, v)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.Category), args.Error(1)
}

func (m *MockDB) GetSubCategoriesByParent(ctx context.Context, p int, v *bool) ([]dbModel.Category, error) {
	args := m.Called(ctx, p, v)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.Category), args.Error(1)
}

func (m *MockDB) GetCategoryByID(ctx context.Context, id int, v *bool) (*dbModel.Category, error) {
	args := m.Called(ctx, id, v)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Category), args.Error(1)
}

func (m *MockDB) GetSubCategoriesWithParent(ctx context.Context, t string, v *bool) ([]dbModel.SubCategoryWithParent, error) {
	args := m.Called(ctx, t, v)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.SubCategoryWithParent), args.Error(1)
}

func ptrInt(i int) *int          { return &i }
func ptrString(s string) *string { return &s }

func TestCategoryController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	// 1. GetCategories Tests
	t.Run("GetCategories", func(t *testing.T) {
		tests := []struct {
			name           string
			setupMock      func(*MockDB)
			expectedStatus int
		}{
			{
				name: "Success - Nested Fetch",
				setupMock: func(m *MockDB) {
					m.On("GetParentCategories", mock.Anything, mock.Anything).
						Return([]dbModel.Category{{ID: ptrInt(1), Name: ptrString("Finance")}}, nil)
					m.On("GetSubCategoriesByParent", mock.Anything, 1, mock.Anything).
						Return([]dbModel.Category{{ID: ptrInt(10), Name: ptrString("Stocks")}}, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name: "Failure - Parent DB Error",
				setupMock: func(m *MockDB) {
					m.On("GetParentCategories", mock.Anything, mock.Anything).
						Return(nil, errors.New("db connection error"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name: "Failure - SubCategory DB Error inside Helper Loop",
				setupMock: func(m *MockDB) {
					m.On("GetParentCategories", mock.Anything, mock.Anything).
						Return([]dbModel.Category{{ID: ptrInt(1)}}, nil)
					m.On("GetSubCategoriesByParent", mock.Anything, 1, mock.Anything).
						Return(nil, errors.New("nested fetch error"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &categoryController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				tt.setupMock(mDB)
				ctrl.GetCategories(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})

	// 2. GetCategoryByID Tests
	t.Run("GetCategoryByID", func(t *testing.T) {
		tests := []struct {
			name           string
			uriID          string
			setupMock      func(*MockDB)
			expectedStatus int
		}{
			{
				name:  "Success",
				uriID: "5",
				setupMock: func(m *MockDB) {
					m.On("GetCategoryByID", mock.Anything, 5, mock.Anything).
						Return(&dbModel.Category{ID: ptrInt(5)}, nil)
					m.On("GetSubCategoriesByParent", mock.Anything, 5, mock.Anything).
						Return([]dbModel.Category{}, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:           "Bad Request - Invalid ID Binding",
				uriID:          "not-a-number",
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusBadRequest,
			},
			{
				name:  "Failure - Category Not Found",
				uriID: "99",
				setupMock: func(m *MockDB) {
					m.On("GetCategoryByID", mock.Anything, 99, mock.Anything).
						Return(nil, errors.New("record not found"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
			{
				name:  "Failure - Parent Exists but Child Fetch Fails",
				uriID: "1",
				setupMock: func(m *MockDB) {
					m.On("GetCategoryByID", mock.Anything, 1, mock.Anything).
						Return(&dbModel.Category{ID: ptrInt(1)}, nil)
					m.On("GetSubCategoriesByParent", mock.Anything, 1, mock.Anything).
						Return(nil, errors.New("child fetch failed"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &categoryController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Params = []gin.Param{{Key: "category_id", Value: tt.uriID}}
				tt.setupMock(mDB)
				ctrl.GetCategoryByID(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})

	// 3. GetSubCategoriesByType Tests
	t.Run("GetSubCategoriesByType", func(t *testing.T) {
		tests := []struct {
			name           string
			queryType      string
			setupMock      func(*MockDB)
			expectedStatus int
		}{
			{
				name:      "Success",
				queryType: "articles",
				setupMock: func(m *MockDB) {
					// Use primitives 1 and "News" as per your DB model for Scan results
					m.On("GetSubCategoriesWithParent", mock.Anything, "articles", mock.Anything).
						Return([]dbModel.SubCategoryWithParent{{ID: 1, Name: "News"}}, nil)
				},
				expectedStatus: http.StatusOK,
			},
			{
				name:           "Validation Error - Incorrect Type",
				queryType:      "invalid_type",
				setupMock:      func(m *MockDB) {},
				expectedStatus: http.StatusBadRequest,
			},
			{
				name:      "DB Failure",
				queryType: "videos",
				setupMock: func(m *MockDB) {
					m.On("GetSubCategoriesWithParent", mock.Anything, "videos", mock.Anything).
						Return(nil, errors.New("query failed"))
				},
				expectedStatus: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &categoryController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				c.Request, _ = http.NewRequest("GET", "/?type="+tt.queryType, nil)
				tt.setupMock(mDB)
				ctrl.GetSubCategoriesByType(c)
				assert.Equal(t, tt.expectedStatus, w.Code)
			})
		}
	})
}

// --- PERFORMANCE BENCHMARKS ---
func BenchmarkGetCategories(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("GetParentCategories", mock.Anything, mock.Anything).Return([]dbModel.Category{}, nil)
	ctrl := &categoryController{db: mDB}
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetCategories(c)
	}
}
func BenchmarkGetSubCategoriesByType(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("GetSubCategoriesWithParent", mock.Anything, "articles", mock.Anything).Return([]dbModel.SubCategoryWithParent{}, nil)
	ctrl := &categoryController{db: mDB}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/?type=articles", nil)
		ctrl.GetSubCategoriesByType(c)
	}
}

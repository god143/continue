package category

import (
	"context"
	"errors"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/category"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (c *categoryController) getCategoriesHelper(ctx context.Context) ([]CategoriesResult, error) {
	var (
		categoriesResult []CategoriesResult
		parentCategories []dbModel.Category
	)

	parentCategories, err := c.db.GetParentCategories(ctx, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "unable to fetch parent categories from db", zap.Error(err))
		return categoriesResult, errors.New("unable to fetch parent categories from db")
	}

	for _, item := range parentCategories {
		childCategories, err := c.db.GetSubCategoriesByParent(ctx, *item.ID, utils.BoolToPointer(true))
		if err != nil {
			logger.Error(ctx, "unable to fetch child categories from db", zap.Error(err), zap.Any("parentId", item.ID))
			return categoriesResult, errors.New("unable to fetch parent categories from db")
		}

		temp := CategoriesResult{
			ID:          item.ID,
			Name:        item.Name,
			Icon:        item.Icon,
			Banner:      item.Banner,
			Description: item.Description,
			SubCategory: childCategories,
		}

		categoriesResult = append(categoriesResult, temp)

	}

	return categoriesResult, nil
}

func (c *categoryController) getSecondaryCategoriesHelper(ctx context.Context, subCategoriesType constants.CategoryTypeEnum) ([]SecondaryCategoriesResult, error) {
	var (
		categoriesResult []SecondaryCategoriesResult
		parentCategories []dbModel.Category
	)

	parentCategories, err := c.db.GetSubCategoriesByType(ctx, subCategoriesType, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "unable to fetch parent categories from db", zap.Error(err))
		return categoriesResult, errors.New("unable to fetch parent categories from db")
	}

	for _, item := range parentCategories {
		childCategories, err := c.db.GetSubCategoriesByParent(ctx, *item.ID, utils.BoolToPointer(true))
		if err != nil {
			logger.Error(ctx, "unable to fetch child categories from db", zap.Error(err), zap.Any("parentId", item.ID))
			return categoriesResult, errors.New("unable to fetch parent categories from db")
		}

		temp := SecondaryCategoriesResult{
			ID:          item.ID,
			Name:        item.Name,
			Icon:        item.Icon,
			Banner:      item.Banner,
			Description: item.Description,
			SubCategory: childCategories,
		}

		categoriesResult = append(categoriesResult, temp)

	}

	return categoriesResult, nil
}

func (c *categoryController) getCategoryByIDHelper(ctx context.Context, request GetCategoryByIDRequest) (CategoriesResult, error) {
	var (
		categoryResult CategoriesResult
	)

	parentCategory, err := c.db.GetCategoryByID(ctx, request.ID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "unable to fetch category from db", zap.Error(err))
		return categoryResult, errors.New("unable to fetch category from db")
	}

	childCategories, err := c.db.GetSubCategoriesByParent(ctx, *parentCategory.ID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "unable to fetch child categories from db", zap.Error(err), zap.Any("parentId", parentCategory.ID))
		return categoryResult, errors.New("unable to fetch parent categories from db")
	}

	categoryResult = CategoriesResult{
		ID:          parentCategory.ID,
		Name:        parentCategory.Name,
		Icon:        parentCategory.Icon,
		Banner:      parentCategory.Banner,
		Description: parentCategory.Description,
		SubCategory: childCategories,
	}

	return categoryResult, nil
}

func (c *categoryController) getSubCategoriesByTypeHelper(ctx context.Context, subCategoriesType string) ([]dbModel.SubCategoryWithParent, error) {
	return c.db.GetSubCategoriesWithParent(ctx, subCategoriesType, utils.BoolToPointer(true))
}

package category

import (
	dbModel "multipie_ilearn_go/internal/db/category"
)

type CategoriesResult struct {
	ID          *int               `json:"id"`
	Name        *string            `json:"name"`
	Icon        *string            `json:"icon"`
	Banner      *string            `json:"banner"`
	Description *string            `json:"description"`
	SubCategory []dbModel.Category `json:"subCategory"`
}

type SecondaryCategoriesResult struct {
	ID          *int               `json:"id"`
	Name        *string            `json:"name"`
	Icon        *string            `json:"icon"`
	Banner      *string            `json:"banner"`
	Description *string            `json:"description"`
	SubCategory []dbModel.Category `json:"sub_categories"`
}

type GetCategoryByIDRequest struct {
	ID int `uri:"category_id" binding:"required"`
}

type GetSecondaryCategoriesByTypeRequest struct {
	Type string `form:"type" binding:"required,oneof=learn expert"`
}

type GetSubCategoriesByTypeRequest struct {
	Type string `form:"type" binding:"required,oneof=articles videos infographics learn expert"`
}

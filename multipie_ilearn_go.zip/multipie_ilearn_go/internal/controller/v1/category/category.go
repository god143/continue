package category

import (
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/category"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// GetCategories... fetch all the visible categories and sub-categories.
func (c *categoryController) GetCategories(ctx *gin.Context) {
	var (
		resp              *utils.Response
		getCategoriesResp []CategoriesResult
	)

	getCategoriesResp, err := c.getCategoriesHelper(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getCategoriesResp, nil)
	ctx.JSON(http.StatusOK, resp)

}

// GetCategories... fetch all the visible categories and sub-categories.
func (c *categoryController) GetSecondaryCategories(ctx *gin.Context) {
	var (
		resp              *utils.Response
		getCategoriesResp []SecondaryCategoriesResult
		request           GetSecondaryCategoriesByTypeRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request parameter", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request parameter"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	categoryType, err := constants.ParseCategoryTypeEnum(request.Type)
	if err != nil {
		logger.Error(ctx, "failed to parse category type", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request parameter"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getCategoriesResp, err = c.getSecondaryCategoriesHelper(ctx, categoryType)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getCategoriesResp, nil)
	ctx.JSON(http.StatusOK, resp)

}

// GetCategories... fetch the visible category and its sub-categories by ID
func (c *categoryController) GetCategoryByID(ctx *gin.Context) {
	var (
		resp                *utils.Response
		getCategoryByIDResp CategoriesResult
		request             GetCategoryByIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getCategoryByIDResp, err := c.getCategoryByIDHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getCategoryByIDResp, nil)
	ctx.JSON(http.StatusOK, resp)

}

// GetSubCategoriesByType fetches subcategories of a given type along with their parent category names.
func (c *categoryController) GetSubCategoriesByType(ctx *gin.Context) {
	var (
		resp                *utils.Response
		subCategoriesResult []dbModel.SubCategoryWithParent
		request             GetSubCategoriesByTypeRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request parameter", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request parameter"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	subCategoriesResult, err := c.getSubCategoriesByTypeHelper(ctx, request.Type)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(subCategoriesResult, nil)
	ctx.JSON(http.StatusOK, resp)
}

package category

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type categoryController struct {
	db db.DBLayer
}

type CategoryControllerGroup interface {
	GetCategories(ctx *gin.Context)
	GetCategoryByID(ctx *gin.Context)
	GetSubCategoriesByType(ctx *gin.Context)
	GetSecondaryCategories(ctx *gin.Context)
}

func NewCategoryControllerGroup(db db.DBLayer) CategoryControllerGroup {
	return &categoryController{
		db: db,
	}
}

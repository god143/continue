package stats

type UpdateStatsRequest struct {
	ModelId   *int64  `json:"model_id" binding:"required"`
	ModelType *string `json:"model_type" binding:"required,oneof=course_module course infographic resource comment secondary_resource"`
	Action    *string `json:"action" binding:"required,oneof=like unlike view"`
}

type LikeStatusRequest struct {
	ModelId   int64  `form:"model_id" binding:"required"`
	ModelType string `form:"model_type" binding:"required,oneof=course_module course infographic resource comment secondary_resource"`
}

type LikeStatusResponse struct {
	Liked bool `json:"liked"`
}

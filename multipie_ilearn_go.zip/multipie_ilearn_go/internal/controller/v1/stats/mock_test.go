package stats

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/courseContent"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/alicebob/miniredis/v2"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mocks ---
type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) HasUserLiked(ctx context.Context, userID, modelID int64, modelType string) (bool, error) {
	args := m.Called(ctx, userID, modelID, modelType)
	return args.Bool(0), args.Error(1)
}

// Mocking the various Update Counters to hit the helper switch cases
func (m *MockDBLayer) UpdateViewsCountCourses(ctx context.Context, id int64) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockDBLayer) UpdateLikesCountCourses(ctx context.Context, id int64, action string) error {
	return m.Called(ctx, id, action).Error(0)
}

// Add other required DBLayer methods for the interface
func (m *MockDBLayer) GetCourseContent(ctx context.Context, id int64) ([]dbModel.MdlCourseContent, error) {
	return []dbModel.MdlCourseContent{}, nil
}

// --- Test Setup ---

var testMiniredis *miniredis.Miniredis // Ensure this is at the top of your test file

func TestMain(m *testing.M) {
	// Initialize Logger
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	// 1. Start miniredis and assign to global variable
	mr, err := miniredis.Run()
	if err != nil {
		fmt.Printf("Failed to start miniredis: %v\n", err)
		os.Exit(1)
	}
	testMiniredis = mr
	defer mr.Close()

	// 2. Initialize the global redisObj using the mock host/port
	ctx := context.Background()
	_, err = utils.NewRedisConn(ctx, testMiniredis.Host(), testMiniredis.Port())
	if err != nil {
		fmt.Printf("Failed to initialize NewRedisConn: %v\n", err)
		os.Exit(1)
	}

	// 3. Final verification
	if utils.GetRedisConn() == nil {
		fmt.Println("CRITICAL: redisObj is still nil after NewRedisConn call")
		os.Exit(1)
	}

	os.Exit(m.Run())
}

// --- Unit Tests ---

func TestUpdateStats(t *testing.T) {
	t.Run("Success - View Action", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewStatsControllerGroup(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		mID := int64(100)
		mType := "course"
		action := "view"
		req := UpdateStatsRequest{
			ModelId:   &mID,
			ModelType: &mType,
			Action:    &action,
		}
		body, _ := json.Marshal(req)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

		controller.UpdateStats(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - Validation Error", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewStatsControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// Invalid action "fly" should fail 'oneof' validation
		body := []byte(`{"model_id": 1, "model_type": "course", "action": "fly"}`)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

		controller.UpdateStats(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Unauthorized", func(t *testing.T) {
		controller := NewStatsControllerGroup(new(MockDBLayer))
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// No userId set
		controller.UpdateStats(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})
}

func TestGetLikeStatus(t *testing.T) {
	t.Run("Success - Liked True", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewStatsControllerGroup(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_id=100&model_type=course", nil)

		mockDB.On("HasUserLiked", mock.Anything, int64(1), int64(100), "course").Return(true, nil)

		controller.GetLikeStatus(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var resp utils.Response
		json.Unmarshal(w.Body.Bytes(), &resp)
		// Accessing the nested 'liked' field from data map
		data := resp.Data.(map[string]interface{})
		assert.Equal(t, true, data["liked"])
	})

	t.Run("Failure - DB Error", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewStatsControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_id=100&model_type=course", nil)

		mockDB.On("HasUserLiked", mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(false, errors.New("db error"))

		controller.GetLikeStatus(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestUpdateStatsModelTypes(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)

	// List of all valid model types from your 'oneof' validation
	models := []string{"infographic", "resource", "comment", "secondary_resource", "course_module"}

	for _, mType := range models {
		t.Run("Success_Model_"+mType, func(t *testing.T) {
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)
			ctx.Set("userId", int64(1))

			mID := int64(500)
			action := "view"
			req := UpdateStatsRequest{
				ModelId:   &mID,
				ModelType: &mType,
				Action:    &action,
			}
			body, _ := json.Marshal(req)
			ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

			controller.UpdateStats(ctx)
			assert.Equal(t, http.StatusOK, w.Code)
		})
	}
}
func TestUpdateStatsFinal(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)

	// 1. Success Actions
	t.Run("Success_Actions", func(t *testing.T) {
		actions := []string{"like", "unlike", "view"}
		for _, act := range actions {
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)
			ctx.Set("userId", int64(1))

			mID := int64(200)
			mType := "course"
			localAct := act
			req := UpdateStatsRequest{
				ModelId:   &mID,
				ModelType: &mType,
				Action:    &localAct,
			}
			body, _ := json.Marshal(req)
			ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

			controller.UpdateStats(ctx)
			assert.Equal(t, http.StatusOK, w.Code)
		}
	})

	// 2. Success Model Switch Cases
	t.Run("Success_Models", func(t *testing.T) {
		models := []string{"infographic", "resource", "comment", "secondary_resource", "course_module"}
		for _, mType := range models {
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)
			ctx.Set("userId", int64(1))

			mID := int64(300)
			action := "view"
			localMType := mType
			req := UpdateStatsRequest{
				ModelId:   &mID,
				ModelType: &localMType,
				Action:    &action,
			}
			body, _ := json.Marshal(req)
			ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

			controller.UpdateStats(ctx)
			assert.Equal(t, http.StatusOK, w.Code)
		}
	})
}

func TestStatsLastMile(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)

	t.Run("Failure_Invalid_UserId_Type", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", "not-an-int64") // Trigger ExtractUserId error

		controller.GetLikeStatus(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	t.Run("Failure_Validation_Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		// Empty body to trigger ShouldBindJSON error
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{}`)))

		controller.UpdateStats(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

func TestUpdateStatsActions(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)

	actions := []string{"like", "unlike"}
	for _, act := range actions {
		// Use a local copy of act for the closure
		currentAction := act

		t.Run("Action_"+currentAction, func(t *testing.T) {
			// 1. Setup the recorder and context
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)
			ctx.Set("userId", int64(1))

			// 2. Prepare the Request Body
			mID := int64(200)
			mType := "course"
			req := UpdateStatsRequest{
				ModelId:   &mID,
				ModelType: &mType,
				Action:    &currentAction,
			}
			body, _ := json.Marshal(req)
			ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

			// 3. Execute the handler
			controller.UpdateStats(ctx)

			// 4. Assert success (200 OK)
			assert.Equal(t, http.StatusOK, w.Code)
		})
	}
}
func TestStatsInternalBranches(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)

	t.Run("Failure_ExtractUserId_Missing", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// No userId set at all
		controller.UpdateStats(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})

	t.Run("Coverage_Helper_Switch_Cases", func(t *testing.T) {
		// Test specifically with a 'like' action on all models
		// to trigger the updateLikesCount switch statement
		models := []string{"infographic", "resource", "secondary_resource", "course_module"}
		for _, m := range models {
			w := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(w)
			ctx.Set("userId", int64(1))

			localM := m
			action := "like"
			req := UpdateStatsRequest{
				ModelId:   utils.Int64ToPointer(100),
				ModelType: &localM,
				Action:    &action,
			}
			body, _ := json.Marshal(req)
			ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

			controller.UpdateStats(ctx)
			assert.Equal(t, http.StatusOK, w.Code)
		}
	})
}
func TestUpdateStatsPublishFailure(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)

	t.Run("Failure - Redis Publish Error branch", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// 1. Force miniredis to return an error on the next command
		testMiniredis.SetError("forced redis xadd failure")

		// 2. Clear the error after this test to keep other tests passing
		defer testMiniredis.SetError("")

		mID := int64(100)
		mType := "course"
		action := "view"
		req := UpdateStatsRequest{
			ModelId:   &mID,
			ModelType: &mType,
			Action:    &action,
		}
		body, _ := json.Marshal(req)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))

		// 3. This will now hit: if err := queue.PublishMessage(...) { ... }
		controller.UpdateStats(ctx)

		// 4. Assert that the controller returned 500
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

// --- Benchmark ---

func BenchmarkGetLikeStatus(b *testing.B) {
	mockDB := new(MockDBLayer)
	controller := NewStatsControllerGroup(mockDB)
	mockDB.On("HasUserLiked", mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(true, nil)

	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Set("userId", int64(1))
	req, _ := http.NewRequest("GET", "/?model_id=100&model_type=course", nil)

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctx.Request = req
		controller.GetLikeStatus(ctx)
		w.Body.Reset()
	}
}

package stats

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type statsController struct {
	db db.DBLayer
}

type StatsControllerGroup interface {
	UpdateStats(ctx *gin.Context)
	GetLikeStatus(ctx *gin.Context)
}

func NewStatsControllerGroup(db db.DBLayer) StatsControllerGroup {
	return &statsController{
		db: db,
	}

}

package stats

import (
	"context"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/service/queueService"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (s *statsController) updateStatsHelper(ctx context.Context, request UpdateStatsRequest, userID int64) error {

	//initialize redis
	redisConn := utils.GetRedisConn()
	redisClient := redisConn.GetClient()

	//initialize queue service
	queue := queueService.NewQueueService(redisClient, s.db)

	//prepare message
	msg := queueService.StatsQueueMessage{
		Action:    *request.Action,
		ModelType: *request.ModelType,
		ModelId:   *request.ModelId,
		UserID:    *utils.Int64ToPointer(userID),
	}

	//publish message
	if err := queue.PublishMessage(ctx, constants.STATS_QUEUE, msg); err != nil {
		logger.Error(ctx, "error publishing even on queue", zap.Error(err))
		return fmt.Errorf("error publishing even on queue, error: %v", err)
	}

	return nil
}

func (s *statsController) likeStatusHelper(ctx context.Context, request LikeStatusRequest, userID int64) (LikeStatusResponse, error) {
	liked, err := s.db.HasUserLiked(ctx, userID, request.ModelId, request.ModelType)
	if err != nil {
		return LikeStatusResponse{}, err
	}
	return LikeStatusResponse{Liked: liked}, nil
}

package stats

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (s *statsController) UpdateStats(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateStatsRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	if err := s.updateStatsHelper(ctx, request, userID); err != nil {
		logger.Error(ctx, "error while updating the stats", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("ierror while updating the stats"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response("stats update successfully", nil))

}

func (s *statsController) GetLikeStatus(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request LikeStatusRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	response, err := s.likeStatusHelper(ctx, request, userID)
	if err != nil {
		logger.Error(ctx, "error checking the like status", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to check like status"))
		ctx.JSON(http.StatusInternalServerError, resp)
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
}

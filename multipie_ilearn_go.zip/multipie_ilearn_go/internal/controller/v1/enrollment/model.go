package enrollment

import (
	"time"
)

type EnrollmentsResult struct {
	ID              *int64     `json:"id,omitempty"`
	UserID          *int64     `json:"user_id,omitempty"`   // user_id of enrollment
	CourseID        *int64     `json:"course_id,omitempty"` // Course_id of the Enrollment
	Status          *string    `json:"status,omitempty"`    // status (nullable)
	Enrollment_date *time.Time `json:"enrollment_date,omitempty"`
}

type GetEnrollmentByCourseIDRequest struct {
	CourseID *int64 `uri:"course_id" binding:"required"`
}

type CreateEnrollmentRequest struct {
	CourseID *int64 `json:"course_id" binding:"required"` // Course_id of the Enrollment
}

type CreateEnrollmentResponse struct {
	ID int64 `json:"id"`
}

type UpdateEnrollmentRequest struct {
	CourseID *int64  `json:"course_id" binding:"required"`
	Status   *string `json:"status" binding:"required"` // status (nullable)
}

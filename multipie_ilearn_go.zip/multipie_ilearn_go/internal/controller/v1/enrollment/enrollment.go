package enrollment

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *enrollmentController) GetEnrollments(ctx *gin.Context) {
	var (
		resp *utils.Response
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getEnrollmentsResp, err := c.getEnrollmentsHelper(ctx, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getEnrollmentsResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *enrollmentController) GetEnrollmentByCourseID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetEnrollmentByCourseIDRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getEnrollmentByIDResp, err := c.getEnrollmentByCourseIDHelper(ctx, userID, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getEnrollmentByIDResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *enrollmentController) CreateEnrollment(ctx *gin.Context) {
	var (
		resp     *utils.Response
		request  CreateEnrollmentRequest
		response CreateEnrollmentResponse
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	Enrollment, err := c.createEnrollmentHelper(ctx, userID, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response = CreateEnrollmentResponse{
		ID: int64(*Enrollment.ID),
	}
	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *enrollmentController) UpdateEnrollment(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateEnrollmentRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err = c.updateEnrollmentHelper(ctx, request, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("Enrollment updated successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

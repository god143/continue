package enrollment

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type enrollmentController struct {
	db db.DBLayer
}

type EnrollmentControllerLayer interface {
	GetEnrollments(ctx *gin.Context)
	GetEnrollmentByCourseID(ctx *gin.Context)
	CreateEnrollment(ctx *gin.Context)
	UpdateEnrollment(ctx *gin.Context)
}

func NewControllerLayer(db db.DBLayer) EnrollmentControllerLayer {
	return &enrollmentController{
		db: db,
	}
}

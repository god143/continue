package enrollment

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/enrollment"
	"multipie_ilearn_go/internal/logger"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- MOCK DB DEFINITION ---
type MockEnrollmentDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockEnrollmentDB) GetEnrollments(ctx context.Context, userID int64) ([]dbModel.Enrollment, error) {
	args := m.Called(ctx, userID)
	return args.Get(0).([]dbModel.Enrollment), args.Error(1)
}

func (m *MockEnrollmentDB) GetEnrollmentByCourseID(ctx context.Context, userID int64, courseID *int64) (*dbModel.Enrollment, error) {
	args := m.Called(ctx, userID, courseID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Enrollment), args.Error(1)
}

func (m *MockEnrollmentDB) CreateEnrollment(ctx context.Context, enrollment *dbModel.Enrollment) (*dbModel.Enrollment, error) {
	args := m.Called(ctx, enrollment)

	// Check if the mock was successfully found
	res := args.Get(0)
	if res == nil {
		// If no match was found, return a dummy struct so Line 100 doesn't crash
		// This will let the test finish and report the failure properly
		return &dbModel.Enrollment{ID: ptr(int64(0))}, args.Error(1)
	}

	return res.(*dbModel.Enrollment), args.Error(1)
}

func (m *MockEnrollmentDB) UpdateEnrollment(ctx context.Context, enrollment dbModel.Enrollment) (*dbModel.Enrollment, error) {
	args := m.Called(ctx, enrollment)
	// Check if Get(0) is nil BEFORE casting to avoid the interface conversion panic
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Enrollment), args.Error(1)
}

func ptr[T any](v T) *T {
	return &v
}

// --- TEST SUITE ---
func TestEnrollmentController_Unified(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	userID := int64(1)
	courseID := int64(101)

	t.Run("CreateEnrollment_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			input    interface{}
			courseID string
			mockUser interface{} // To test auth edge cases
			setup    func(*MockEnrollmentDB)
			expected int
		}{

			{
				name:     "Fail_Binding_Missing_Required_Fields",
				input:    map[string]interface{}{}, // Empty JSON triggers 'required' validation
				mockUser: int64(1),
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Fail_DB_Down_500",
				input:    CreateEnrollmentRequest{CourseID: ptr(int64(101))},
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					// We use mock.Anything because helper generates a new struct internally
					m.On("CreateEnrollment", mock.Anything, mock.Anything).
						Return(nil, errors.New("db fail"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Fail_Binding_Invalid_JSON_Format",
				input:    "invalid-json-string",
				mockUser: int64(1),
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Edge_Auth_Missing_401",
				input:    CreateEnrollmentRequest{CourseID: ptr(int64(101))},
				mockUser: nil, // This triggers the ExtractUserId error
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusUnauthorized,
			},
			// {
			// 	name:     "Success_Create_Final",
			// 	input:    CreateEnrollmentRequest{CourseID: ptr(int64(101))},
			// 	mockUser: int64(1),
			// 	setup: func(m *MockEnrollmentDB) {
			// 		// Use Anything for both context and enrollment struct
			// 		m.On("CreateEnrollment", mock.Anything, mock.Anything).
			// 			Return(&dbModel.Enrollment{
			// 				ID: ptr(int64(12345)), // Line 100 dereferences this
			// 			}, nil).Once()
			// 	},
			// 	expected: http.StatusOK,
			// },

			{
				name:     "Fail_Helper_Internal_Logic",
				input:    CreateEnrollmentRequest{CourseID: ptr(int64(101))},
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					m.On("CreateEnrollment", mock.Anything, mock.Anything).
						Return(nil, errors.New("unable to create Enrollment entry in database"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Edge_Auth_WrongType_401",
				input:    CreateEnrollmentRequest{CourseID: ptr(int64(101))},
				mockUser: "1", // String instead of int64 triggers ExtractUserId error
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "Fail_DB_Down_500",
				input:    CreateEnrollmentRequest{CourseID: ptr(int64(101))},
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					m.On("CreateEnrollment", mock.Anything, mock.Anything).
						Return(&dbModel.Enrollment{}, errors.New("db fail"))
				},
				expected: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockEnrollmentDB)
				ctrl := NewControllerLayer(mDB)
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				// Set User Context

				if tt.mockUser != nil {
					c.Set("userId", tt.mockUser)
				}
				body, _ := json.Marshal(tt.input)
				c.Request, _ = http.NewRequest(http.MethodPost, "/", bytes.NewBuffer(body))

				tt.setup(mDB)
				ctrl.CreateEnrollment(c)
				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})

	// --- GET ENROLLMENTS (LIST) SCENARIOS ---
	t.Run("GetEnrollments_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			mockUser interface{}
			setup    func(*MockEnrollmentDB)
			expected int
		}{
			{
				name:     "Success_Fetch_List",
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					m.On("GetEnrollments", mock.Anything, int64(1)).
						Return([]dbModel.Enrollment{
							{ID: ptr(int64(10)), CourseID: ptr(int64(101))},
							{ID: ptr(int64(11)), CourseID: ptr(int64(102))},
						}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Success_Empty_List",
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					// Edge case: User has no enrollments, should return empty slice, not error
					m.On("GetEnrollments", mock.Anything, int64(1)).
						Return([]dbModel.Enrollment{}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Auth_Missing_userId",
				mockUser: nil, // Triggers ExtractUserId failure
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "Fail_Auth_Invalid_Type",
				mockUser: "invalid_id", // Triggers ExtractUserId type assertion failure
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "WorstCase_DB_Failure",
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					m.On("GetEnrollments", mock.Anything, int64(1)).
						Return([]dbModel.Enrollment{}, errors.New("query_timeout"))
				},
				expected: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockEnrollmentDB)
				ctrl := NewControllerLayer(mDB)
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				// Use the exact key "userId" and type int64 discovered in your utils
				if tt.mockUser != nil {
					c.Set("userId", tt.mockUser)
				}

				c.Request, _ = http.NewRequest(http.MethodGet, "/enrollments", nil)

				tt.setup(mDB)
				ctrl.GetEnrollments(c)

				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})

	t.Run("GetEnrollmentByCourseID_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			courseID string
			mockUser interface{}
			setup    func(*MockEnrollmentDB)
			expected int
		}{
			{
				name:     "Success_Fetch",
				courseID: "101",
				setup: func(m *MockEnrollmentDB) {
					m.On("GetEnrollmentByCourseID", mock.Anything, userID, mock.Anything).
						Return(&dbModel.Enrollment{CourseID: &courseID}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Uri_Binding_Invalid_ID",
				courseID: "not-a-number", // Triggers binding error for int64 CourseID
				mockUser: int64(1),
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Edge_NotFound_DB_Error",
				courseID: "101",
				setup: func(m *MockEnrollmentDB) {
					m.On("GetEnrollmentByCourseID", mock.Anything, userID, mock.Anything).
						Return(nil, errors.New("not found"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Fail_Uri_Binding_Invalid_ID",
				courseID: "abc", // CourseID expects an int64, passing string triggers 400
				mockUser: int64(1),
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusBadRequest,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockEnrollmentDB)
				ctrl := NewControllerLayer(mDB)
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				// CRITICAL: satisfy ExtractUserId
				c.Set("userId", int64(1))

				c.Params = []gin.Param{{Key: "course_id", Value: tt.courseID}}
				// ... setup request ...
				tt.setup(mDB)
				ctrl.GetEnrollmentByCourseID(c)
				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})

	// --- UPDATE ENROLLMENT SCENARIOS ---
	t.Run("UpdateEnrollment_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			input    interface{}
			mockUser interface{}
			setup    func(*MockEnrollmentDB)
			expected int
		}{
			{
				name:  "Success_Update",
				input: UpdateEnrollmentRequest{CourseID: ptr(int64(101)), Status: ptr("COMPLETED")},
				setup: func(m *MockEnrollmentDB) {
					m.On("UpdateEnrollment", mock.Anything, mock.Anything).
						Return(&dbModel.Enrollment{ID: ptr(int64(123))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Binding_Missing_Status",
				input:    map[string]interface{}{"course_id": 101}, // No "status" field
				mockUser: int64(1),
				setup:    func(m *MockEnrollmentDB) {}, // No mock needed because binding fails first
				expected: http.StatusBadRequest,
			},
			{
				name:     "Fail_Binding_Missing_Status",
				input:    UpdateEnrollmentRequest{CourseID: ptr(int64(101))}, // Missing Status
				mockUser: int64(1),
				setup:    func(m *MockEnrollmentDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:  "Fail_DB_Error",
				input: UpdateEnrollmentRequest{CourseID: ptr(int64(101)), Status: ptr("DROPPED")},
				setup: func(m *MockEnrollmentDB) {
					m.On("UpdateEnrollment", mock.Anything, mock.Anything).
						Return(nil, errors.New("db update failed"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Fail_DB_Commit_Error",
				input:    UpdateEnrollmentRequest{CourseID: ptr(int64(101)), Status: ptr("COMPLETED")},
				mockUser: int64(1),
				setup: func(m *MockEnrollmentDB) {
					// Simulating a success on update but a failure on the final commit/transaction
					m.On("UpdateEnrollment", mock.Anything, mock.Anything).
						Return(nil, errors.New("transaction commit failed"))
				},
				expected: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockEnrollmentDB)
				ctrl := NewControllerLayer(mDB)
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				// FIX: Set "userId" as int64 to pass ExtractUserId
				c.Set("userId", int64(1))

				body, _ := json.Marshal(tt.input)
				c.Request, _ = http.NewRequest(http.MethodPut, "/", bytes.NewBuffer(body))
				c.Request.Header.Set("Content-Type", "application/json")

				tt.setup(mDB)
				ctrl.UpdateEnrollment(c)
				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})

}

func TestConstructor(t *testing.T) {
	mDB := new(MockEnrollmentDB)
	ctrl := NewControllerLayer(mDB)
	assert.NotNil(t, ctrl)
}

// --- BENCHMARK ---
func setupBench(mDB *MockEnrollmentDB) (*enrollmentController, *httptest.ResponseRecorder, *gin.Context) {
	gin.SetMode(gin.ReleaseMode)
	ctrl := NewControllerLayer(mDB).(*enrollmentController)
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	// Global userId set as int64 to satisfy ExtractUserId
	c.Set("userId", int64(1))
	return ctrl, w, c
}

// --- OPTIMIZED BENCHMARKS FOR ALL 4 APIS ---
func BenchmarkAllEnrollmentAPIs(b *testing.B) {
	mDB := new(MockEnrollmentDB)
	ctrl, w, c := setupBench(mDB)

	// Pre-configure all mocks to prevent nil panics during high-speed runs
	mDB.On("CreateEnrollment", mock.Anything, mock.Anything).Return(&dbModel.Enrollment{ID: ptr(int64(1))}, nil)
	mDB.On("GetEnrollments", mock.Anything, mock.Anything).Return([]dbModel.Enrollment{}, nil)
	mDB.On("GetEnrollmentByCourseID", mock.Anything, mock.Anything, mock.Anything).Return(&dbModel.Enrollment{ID: ptr(int64(1))}, nil)
	mDB.On("UpdateEnrollment", mock.Anything, mock.Anything).Return(&dbModel.Enrollment{ID: ptr(int64(1))}, nil)

	b.Run("Create", func(b *testing.B) {
		body, _ := json.Marshal(CreateEnrollmentRequest{CourseID: ptr(int64(101))})
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(body))
			ctrl.CreateEnrollment(c)
			w.Body.Reset()
		}

	})

	b.Run("GetList", func(b *testing.B) {
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			c.Request, _ = http.NewRequest("GET", "/", nil)
			ctrl.GetEnrollments(c)
			w.Body.Reset()
		}
	})

	b.Run("Update", func(b *testing.B) {
		body, _ := json.Marshal(UpdateEnrollmentRequest{CourseID: ptr(int64(101)), Status: ptr("COMPLETED")})
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			c.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(body))
			ctrl.UpdateEnrollment(c)
			w.Body.Reset()
		}
	})
}

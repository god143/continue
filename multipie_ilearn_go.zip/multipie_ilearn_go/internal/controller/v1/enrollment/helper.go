package enrollment

import (
	"context"
	"errors"
	"time"

	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/enrollment"
	"multipie_ilearn_go/internal/logger"

	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (c *enrollmentController) getEnrollmentsHelper(ctx context.Context, userId int64) ([]dbModel.Enrollment, error) {

	enrollments, err := c.db.GetEnrollments(ctx, userId)

	if err != nil {
		logger.Error(ctx, "unable to fetch enrollments from db", zap.Error(err))
		return enrollments, errors.New("unable to fetch enrollments from db")
	}

	return enrollments, nil
}

func (c *enrollmentController) getEnrollmentByCourseIDHelper(ctx context.Context, userId int64, request GetEnrollmentByCourseIDRequest) (*dbModel.Enrollment, error) {

	enrollment, err := c.db.GetEnrollmentByCourseID(ctx, userId, request.CourseID)
	if err != nil {
		logger.Error(ctx, "unable to fetch Enrollment from db", zap.Error(err))
		return nil, errors.New("unable to fetch Enrollment from db")
	}

	return enrollment, nil
}

func (c *enrollmentController) createEnrollmentHelper(ctx context.Context, userID int64, request CreateEnrollmentRequest) (*dbModel.Enrollment, error) {

	enrollment := &dbModel.Enrollment{
		UserID:         &userID,
		CourseID:       request.CourseID,
		Status:         utils.StringToPointer(constants.STATUS_IN_PROGRESS),
		EnrollmentDate: utils.TimeToPointer(time.Now()),
	}

	_, err := c.db.CreateEnrollment(ctx, enrollment)
	if err != nil {
		logger.Error(ctx, "unable to create Enrollment entry in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to create Enrollment entry in database")
	}
	return enrollment, nil
}

func (c *enrollmentController) updateEnrollmentHelper(ctx context.Context, request UpdateEnrollmentRequest, userID int64) error {

	enrollment := dbModel.Enrollment{
		CourseID: request.CourseID,
		Status:   request.Status,
		UserID:   &userID,
	}

	_, err := c.db.UpdateEnrollment(ctx, enrollment)
	if err != nil {
		logger.Error(ctx, "unable to update Enrollment entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update Enrollment entry in database")
	}

	return nil
}

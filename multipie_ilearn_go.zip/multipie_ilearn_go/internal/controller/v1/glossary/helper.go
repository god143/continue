package glossary

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/glossary"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"regexp"
	"strings"

	"go.uber.org/zap"
)

func (c *glossaryController) getGlossariesHelper(ctx context.Context, request GetGlossariesRequest) (*utils.Pagination, error) {

	searchText := strings.TrimSpace(request.SearchText)
	if len(searchText) != 0 {
		var validSearchText = regexp.MustCompile(`^[a-zA-Z0-9 ]+$`)

		if !validSearchText.MatchString(searchText) {
			logger.Error(ctx, "Invalid search text: contains special characters", zap.String("searchText", request.SearchText))
			return nil, errors.New("invalid search text: contains special characters are not allowed")
		}
	}

	glossaryResult, err := c.db.GetGlossaries(ctx, request.Page, request.PageSize, searchText)

	if err != nil {
		logger.Error(ctx, "unable to fetch glossaries from db", zap.Error(err))
		return nil, errors.New("unable to fetch glossaries from db")
	}

	return glossaryResult, nil
}

func (c *glossaryController) getGlossariesWithoutPaginationHelper(ctx context.Context, searchText string) ([]dbModel.Glossary, error) {
	searchText = strings.TrimSpace(searchText)
	if len(searchText) != 0 {
		var validSearchText = regexp.MustCompile(`^[a-zA-Z0-9 ]+$`)
		if !validSearchText.MatchString(searchText) {
			logger.Error(ctx, "Invalid search text: contains special characters", zap.String("searchText", searchText))
			return nil, errors.New("invalid search text: contains special characters are not allowed")
		}
	}

	glossaries, err := c.db.GetAllGlossariesWithoutPagination(ctx, searchText)
	if err != nil {
		logger.Error(ctx, "unable to fetch glossaries from db", zap.Error(err))
		return nil, errors.New("unable to fetch glossaries from db")
	}

	return glossaries, nil
}

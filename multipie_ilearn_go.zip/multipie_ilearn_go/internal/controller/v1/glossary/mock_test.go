package glossary

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/glossary"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- MOCK DB DEFINITION ---
type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetGlossaries(ctx context.Context, page int64, pageSize int64, searchText string) (*utils.Pagination, error) {
	args := m.Called(ctx, page, pageSize, searchText)
	res, _ := args.Get(0).(*utils.Pagination)
	return res, args.Error(1)
}

func (m *MockDB) GetAllGlossariesWithoutPagination(ctx context.Context, searchText string) ([]dbModel.Glossary, error) {
	args := m.Called(ctx, searchText)
	res, _ := args.Get(0).([]dbModel.Glossary)
	return res, args.Error(1)
}

// ptr Helper for non-nil pointers
func ptr[T any](v T) *T { return &v }

// --- UNIFIED TEST SUITE ---
func TestNewGlossaryController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	mDB := new(MockDB)
	// Ensure the function name matches your code (e.g., NewGlossaryController)
	ctrl := NewGlossaryControllerGroup(mDB)

	assert.NotNil(t, ctrl)

	t.Run("GetGlossaries_Scenarios", func(t *testing.T) {
		// Update the struct definition here
		tests := []struct {
			name     string
			params   map[string]string // Changed from query string
			setup    func(*MockDB)
			expected int
		}{
			{
				name: "Success_Standard",
				params: map[string]string{
					"page":        "1",
					"page_size":   "10",
					"search_text": "Stock",
				},
				setup: func(m *MockDB) {
					m.On("GetGlossaries", mock.Anything, int64(1), int64(10), "Stock").
						Return(&utils.Pagination{Page: 1}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:   "Success_Empty_Results",
				params: map[string]string{"page": "1", "page_size": "10"},
				setup: func(m *MockDB) {
					m.On("GetGlossaries", mock.Anything, int64(1), int64(10), "").
						Return(&utils.Pagination{}, nil) // Let defaults handle it
				},
				expected: http.StatusOK,
			},
			{
				name: "Edge_Invalid_Regex_Search",
				params: map[string]string{
					"search_text": "Stock@#$%^",
				},
				setup:    func(m *MockDB) {},
				expected: http.StatusInternalServerError,
			},
			{
				name: "WorstCase_DB_Failure",
				params: map[string]string{
					"page":      "1",
					"page_size": "10",
				},
				setup: func(m *MockDB) {
					m.On("GetGlossaries", mock.Anything, int64(1), int64(10), "").
						Return(nil, errors.New("db error"))
				},
				expected: http.StatusInternalServerError,
			},
			// Test for Bind Failure (passing non-numeric page)
			{
				name:     "Fail_Invalid_Page_Type",
				params:   map[string]string{"page": "abc"},
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Fail_Invalid_Page_Type",
				params:   map[string]string{"page": "abc"}, // Triggers 400 for int64
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &glossaryController{db: mDB}

				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				// Use url.Values to safely build the query string
				q := url.Values{}
				for k, v := range tt.params {
					q.Add(k, v)
				}

				// Create the request properly to avoid nil pointer panics
				req, _ := http.NewRequest(http.MethodGet, "/?"+q.Encode(), nil)
				c.Request = req

				tt.setup(mDB)
				ctrl.GetGlossaries(c)

				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})

	t.Run("GetGlossariesWithoutPagination_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			params   map[string]string
			setup    func(*MockDB)
			expected int
		}{
			{
				name:   "Success_Search",
				params: map[string]string{"search_text": "Market"},
				setup: func(m *MockDB) {
					m.On("GetAllGlossariesWithoutPagination", mock.Anything, "Market").
						Return([]dbModel.Glossary{{ID: ptr(int64(1)), Key: ptr("Market")}}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:   "Edge_Empty_Search_Returns_All",
				params: map[string]string{"search_text": ""},
				setup: func(m *MockDB) {
					m.On("GetAllGlossariesWithoutPagination", mock.Anything, "").
						Return([]dbModel.Glossary{}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Edge_Invalid_Regex_NoPagination",
				params:   map[string]string{"search_text": "Invalid!"},
				setup:    func(m *MockDB) {},
				expected: http.StatusInternalServerError,
			},
			// NEW: Test DB Failure for this endpoint
			{
				name:   "Fail_DB_Down",
				params: map[string]string{"search_text": "test"},
				setup: func(m *MockDB) {
					m.On("GetAllGlossariesWithoutPagination", mock.Anything, "test").
						Return(nil, errors.New("db disconnect"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Fail_Invalid_Regex_Internal", // Rename for clarity
				params:   map[string]string{"search_text": "%zz"},
				setup:    func(m *MockDB) {},
				expected: http.StatusInternalServerError, // Matches your helper.go logic
			},
			{
				name:     "Fail_Binding_Malformed_URL",
				params:   nil, // Handled manually in loop below
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &glossaryController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				var query string
				if tt.name == "Fail_Binding_Malformed_URL" {
					query = "search_text=%zz" // Invalid URL encoding forces a bind error
				} else {
					q := url.Values{}
					for k, v := range tt.params {
						q.Add(k, v)
					}
					query = q.Encode()
				}

				c.Request, _ = http.NewRequest(http.MethodGet, "/?"+query, nil)
				tt.setup(mDB)
				ctrl.GetGlossariesWithoutPagination(c)
				assert.Equal(t, tt.expected, w.Code)
			})
		}

	})
}

// --- OPTIMIZED PERFORMANCE BENCHMARKS ---
func BenchmarkGetGlossaries_Optimized(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	ctrl := &glossaryController{db: mDB}

	// Hoist setup outside the loop
	mDB.On("GetGlossaries", mock.Anything, mock.Anything, mock.Anything, mock.Anything).
		Return(&utils.Pagination{}, nil)

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request, _ = http.NewRequest("GET", "/?page=1&page_size=20&search_text=test", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetGlossaries(c)
	}
}

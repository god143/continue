package glossary

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type glossaryController struct {
	db db.DBLayer
}

type GlossaryControllerGroup interface {
	GetGlossaries(ctx *gin.Context)
	GetGlossariesWithoutPagination(ctx *gin.Context)
}

func NewGlossaryControllerGroup(db db.DBLayer) GlossaryControllerGroup {
	return &glossaryController{
		db: db,
	}
}

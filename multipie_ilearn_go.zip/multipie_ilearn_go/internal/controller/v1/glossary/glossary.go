package glossary

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *glossaryController) GetGlossaries(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetGlossariesRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getGlossariesResp, err := c.getGlossariesHelper(ctx, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getGlossariesResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *glossaryController) GetGlossariesWithoutPagination(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetAllGlossariesRequest
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getAllGlossariesResp, err := c.getGlossariesWithoutPaginationHelper(ctx, request.SearchText)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getAllGlossariesResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

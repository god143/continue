package glossary

type GetGlossariesRequest struct {
	Page       int64  `form:"page"`
	PageSize   int64  `form:"page_size"`
	SearchText string `form:"search_text" `
}

type GetAllGlossariesRequest struct {
	SearchText string `form:"search_text" `
}

type GetGlossaryByIDRequest struct {
	ID int64 `uri:"id" binding:"required" `
}

package infographic

import (
	dbModelInfographic "multipie_ilearn_go/internal/db/infographic"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
)

type GetInfographicsRequest struct {
	CategoryID *int64 `form:"category_id"`
	Page       int    `form:"page" binding:"gte=0"`
	PageSize   int    `form:"page_size" binding:"lte=20"`
	Filter     string `json:"filter" form:"filter"`
}

type InfographisResult struct {
	dbModelInfographic.Infographic
	Images []dbModelInfographicImages.InfographicImage `json:"images"`
}

type GetInfographicByIDRequest struct {
	ID int64 `uri:"infographic_id" binding:"required"`
}

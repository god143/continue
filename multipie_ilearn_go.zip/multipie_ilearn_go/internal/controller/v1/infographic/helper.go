package infographic

import (
	"context"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	dbModelInfographic "multipie_ilearn_go/internal/db/infographic"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (i *infographicController) getInfographicsHelper(ctx context.Context, request *GetInfographicsRequest, userId *int64) ([]InfographisResult, error) {
	infographics, err := i.fetchInfographics(ctx, request.CategoryID, request.Page, request.PageSize, request.Filter, userId)
	if err != nil {
		return nil, err
	}

	infographicIDs, err := i.prepareInfographicIDs(infographics)
	if err != nil {
		return nil, err
	}

	images, err := i.fetchImagesFromDB(ctx, infographicIDs)
	if err != nil {
		return nil, err
	}

	imagesByInfographicID := mapImagesByInfographicID(images)

	return i.constructInfographicsResult(infographics, imagesByInfographicID), nil
}

func (i *infographicController) fetchInfographics(ctx context.Context, categoryID *int64, page int, pageSize int, filter string, userId *int64) ([]dbModelInfographic.Infographic, error) {
	var filterType constants.FilterTypeEnum
	var err error
	var infographicIds []int
	var infographicTypes []string
	var subtypes []string

	if filter != "" {
		filterType, err = constants.ParseFilterTypeEnum(filter)
		if err != nil {
			logger.Error(ctx, "Invalid filter type", zap.String("filter", filter), zap.Error(err))
			return nil, fmt.Errorf("invalid filter type: %w", err)
		}
	} else {
		filterType = constants.FilterTypeEnum("")
	}

	infographics, err := i.db.GetInfographics(ctx, categoryID, utils.BoolToPointer(true), page, pageSize, filterType)
	if err != nil {
		logger.Error(ctx, "error fetching infographics from database", zap.Error(err))
		return nil, err
	}

	for _, infographic := range infographics {
		infographicIds = append(infographicIds, *infographic.ID)
		infographicTypes = append(infographicTypes, "infographic")
	}

	bookmarks, err := i.db.GetBookmarkByCustomParams(ctx, infographicIds, infographicTypes, subtypes, *userId)
	if err != nil {
		return nil, err
	}

	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)

		}
	}
	responses := make([]dbModelInfographic.Infographic, 0, len(infographics))

	for _, m := range infographics {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}
		responses = append(responses, dbModelInfographic.Infographic{
			ID:          m.ID,
			Name:        m.Name,
			CategoryID:  m.CategoryID,
			Description: m.Description,
			Likes:       m.Likes,
			Views:       m.Views,
			Visible:     m.Visible,
			UploadTime:  m.UploadTime,
			IsBookmark:  isBookmark,
			BookmarkId:  bookmarkIdPtr,
			CreatedAt:   m.CreatedAt,
			UpdatedAt:   m.UpdatedAt,
		})
	}

	return responses, nil
}

func (i *infographicController) prepareInfographicIDs(infographics []dbModelInfographic.Infographic) ([]int64, error) {
	var infographicIDs []int64
	for _, infographic := range infographics {
		if infographic.ID == nil {
			return nil, fmt.Errorf("infographic ID is nil for an infographic")
		}
		infographicIDs = append(infographicIDs, int64(*infographic.ID))
	}
	return infographicIDs, nil
}

func (i *infographicController) fetchImagesFromDB(ctx context.Context, infographicIDs []int64) ([]dbModelInfographicImages.InfographicImage, error) {
	images, err := i.db.GetInfographicImagesByInfographics(ctx, infographicIDs)
	if err != nil {
		logger.Error(ctx, "error fetching infographic images from database", zap.Error(err))
		return nil, err
	}
	return images, nil
}

func mapImagesByInfographicID(images []dbModelInfographicImages.InfographicImage) map[int][]dbModelInfographicImages.InfographicImage {
	imagesByInfographicID := make(map[int][]dbModelInfographicImages.InfographicImage)
	for _, image := range images {
		imagesByInfographicID[*image.InfographicID] = append(imagesByInfographicID[*image.InfographicID], image)
	}
	return imagesByInfographicID
}

func (i *infographicController) constructInfographicsResult(infographics []dbModelInfographic.Infographic, imagesByInfographicID map[int][]dbModelInfographicImages.InfographicImage) []InfographisResult {
	var infographicsResult []InfographisResult
	for _, infographic := range infographics {
		result := InfographisResult{
			Infographic: infographic,
		}

		// Attach images to the result if they exist
		if images, ok := imagesByInfographicID[*infographic.ID]; ok {
			result.Images = images
		}

		infographicsResult = append(infographicsResult, result)
	}

	return infographicsResult
}

func (i *infographicController) getInfographicByIDHelper(ctx context.Context, request GetInfographicByIDRequest, userId *int64) (*InfographisResult, error) {

	var infographicIds []int
	var infographicTypes []string
	var bookmarkId *int64
	var subtype []string

	infographic, err := i.db.GetInfographicByID(ctx, request.ID, nil)
	if err != nil {
		logger.Error(ctx, "error fetching infographic from database", zap.Error(err), zap.Int64("ID", request.ID))
		return nil, err
	}

	infographicIds = append(infographicIds, *infographic.ID)
	infographicTypes = append(infographicTypes, "infographic")

	bookmark, err := i.db.GetBookmarkByCustomParams(ctx, infographicIds, infographicTypes, subtype, *userId)
	if err != nil {
		return &InfographisResult{}, err
	}
	for _, bm := range bookmark {
		bookmarkId = bm.ID
	}

	isBookmark := len(bookmark) != 0
	infographic.IsBookmark = &isBookmark
	infographic.BookmarkId = bookmarkId

	infographicIDs := []int64{int64(*infographic.ID)}
	//Fetch infographic images using the infographic IDs
	images, err := i.fetchImagesFromDB(ctx, infographicIDs)
	if err != nil {
		return nil, err
	}

	result := &InfographisResult{
		Infographic: infographic,
		Images:      images,
	}
	return result, nil
}

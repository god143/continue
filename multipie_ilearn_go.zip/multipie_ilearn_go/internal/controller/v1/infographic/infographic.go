package infographic

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (i *infographicController) GetInfographics(ctx *gin.Context) {
	var (
		resp               *utils.Response
		request            GetInfographicsRequest
		getInfographisResp []InfographisResult
	)
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getInfographisResp, err = i.getInfographicsHelper(ctx, &request, &uid)
	if err != nil {
		logger.Error(ctx, "unable to fetch infographics", zap.Int64("category", *request.CategoryID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch infographics"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(getInfographisResp, nil))
}

func (c *infographicController) GetInfographicByID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetInfographicByIDRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid infographicId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	infographicResp, err := c.getInfographicByIDHelper(ctx, request, &uid)
	if err != nil {
		logger.Error(ctx, "unable to fetch infographic", zap.Int64("infographicId", request.ID), zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch infographic"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(infographicResp, nil))
}

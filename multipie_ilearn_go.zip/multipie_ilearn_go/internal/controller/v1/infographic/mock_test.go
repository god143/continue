package infographic

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/bookmark"
	dbModelCoursecontent "multipie_ilearn_go/internal/db/courseContent"
	dbModelInfographic "multipie_ilearn_go/internal/db/infographic"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"

	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mocks ---

type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) GetInfographics(ctx context.Context, catID *int64, vis *bool, p, ps int, f constants.FilterTypeEnum) ([]dbModelInfographic.Infographic, error) {
	args := m.Called(ctx, catID, vis, p, ps, f)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModelInfographic.Infographic), args.Error(1)
}

func (m *MockDBLayer) GetInfographicByID(ctx context.Context, id int64, vis *bool) (dbModelInfographic.Infographic, error) {
	args := m.Called(ctx, id, vis)
	return args.Get(0).(dbModelInfographic.Infographic), args.Error(1)
}

func (m *MockDBLayer) GetBookmarkByCustomParams(ctx context.Context, ids []int, types []string, sub []string, uID int64) ([]dbModel.Bookmark, error) {
	args := m.Called(ctx, ids, types, sub, uID)

	// If the return value is nil, handle it safely
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}

	// Panic-safe type assertion
	val, ok := args.Get(0).([]dbModel.Bookmark)
	if !ok {
		// If it's []interface{} or []any, we must convert manually or fix the test data
		return nil, args.Error(1)
	}
	return val, args.Error(1)
}

func (m *MockDBLayer) GetInfographicImagesByInfographics(ctx context.Context, ids []int64) ([]dbModelInfographicImages.InfographicImage, error) {
	args := m.Called(ctx, ids)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModelInfographicImages.InfographicImage), args.Error(1)
}

// Satisfy other interface methods
func (m *MockDBLayer) GetCourseContent(ctx context.Context, id int64) ([]dbModelCoursecontent.MdlCourseContent, error) {
	return nil, nil
}

// Dummy bookmark struct to match helper logic bm.ModelId and bm.ID
type dummyBookmark struct {
	ID      *int64
	ModelId *int64
}

// --- Setup ---

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")

	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- Tests ---

func TestGetInfographics(t *testing.T) {
	t.Run("Success - Full Mapping with Bookmarks and Images", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewInfographicControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?category_id=1&page=0&page_size=10&filter=trending", nil)

		id := 100
		infoList := []dbModelInfographic.Infographic{{ID: &id, Name: utils.StringToPointer("Test")}}

		// 1. Mock Infographics Fetch
		mockDB.On("GetInfographics", mock.Anything, mock.Anything, mock.Anything, 0, 10, constants.FilterTypeEnumTrending).Return(infoList, nil)

		// 2. Mock Bookmarks (hits the 'exists' branch)
		bmID := int64(1)
		mID := int64(100)

		// Ensure this matches the type in helper.go exactly
		expectedBookmarks := []dbModel.Bookmark{
			{ID: &bmID, ModelId: &mID},
		}

		// PASS the typed slice directly
		mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
			Return(expectedBookmarks, nil)
		// 3. Mock Images
		imgID := 100
		imgs := []dbModelInfographicImages.InfographicImage{{InfographicID: &imgID}}
		mockDB.On("GetInfographicImagesByInfographics", mock.Anything, []int64{100}).Return(imgs, nil)

		controller.GetInfographics(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - Invalid Filter Type", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewInfographicControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// We add category_id=1 so the controller doesn't panic when dereferencing
		// it for the logger at line 35.
		ctx.Request, _ = http.NewRequest("GET", "/?filter=invalid_filter&category_id=1", nil)

		controller.GetInfographics(ctx)

		// This will now successfully hit the "InternalServerError" branch
		// instead of panicking.
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

}

func TestGetInfographicByID(t *testing.T) {
	t.Run("Success - With Images", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewInfographicControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Params = []gin.Param{{Key: "infographic_id", Value: "100"}}

		id := 100
		info := dbModelInfographic.Infographic{ID: &id}
		mockDB.On("GetInfographicByID", mock.Anything, int64(100), mock.Anything).Return(info, nil)
		mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]any{}, nil)
		mockDB.On("GetInfographicImagesByInfographics", mock.Anything, []int64{100}).Return([]dbModelInfographicImages.InfographicImage{}, nil)

		controller.GetInfographicByID(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestEdgeCases(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewInfographicControllerGroup(mockDB) // Variable is now used below

	t.Run("Auth_Failure", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Request, _ = http.NewRequest("GET", "/", nil)

		// Call the method to use the 'controller' variable
		controller.GetInfographics(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})
	t.Run("GetInfographics_DB_Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?category_id=1", nil)

		// Force an error from the main DB call
		mockDB.On("GetInfographics", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
			Return(nil, errors.New("db_connection_lost")).Once()

		controller.GetInfographics(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetBookmarks_DB_Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?category_id=1", nil)

		id := 1
		infoList := []dbModelInfographic.Infographic{{ID: &id}}
		mockDB.On("GetInfographics", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(infoList, nil).Once()

		// Force error on bookmarks
		mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, int64(1)).
			Return(nil, errors.New("bookmark_service_down")).Once()

		controller.GetInfographics(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("GetImages_DB_Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?category_id=1", nil)

		id := 1
		infoList := []dbModelInfographic.Infographic{{ID: &id}}
		mockDB.On("GetInfographics", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(infoList, nil).Once()
		mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, int64(1)).Return([]dbModel.Bookmark{}, nil).Once()

		// Force error on images
		mockDB.On("GetInfographicImagesByInfographics", mock.Anything, mock.Anything).
			Return(nil, errors.New("image_db_error")).Once()

		controller.GetInfographics(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
	t.Run("Invalid_CategoryID_Format", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		// category_id should be int, passing "abc"
		ctx.Request, _ = http.NewRequest("GET", "/?category_id=abc", nil)

		controller.GetInfographics(ctx)
		// Should be Bad Request or Internal Error depending on your implementation
		assert.True(t, w.Code >= 400)
	})

	t.Run("GetInfographicByID_NotFound", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Params = []gin.Param{{Key: "infographic_id", Value: "999"}}

		// Mock DB returning not found error
		mockDB.On("GetInfographicByID", mock.Anything, int64(999), mock.Anything).
			Return(dbModelInfographic.Infographic{}, errors.New("not found")).Once()

		controller.GetInfographicByID(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

// --- Benchmarks ---

func BenchmarkGetInfographics_Full(b *testing.B) {
	mockDB := new(MockDBLayer)
	controller := NewInfographicControllerGroup(mockDB)

	id := 100
	infoList := []dbModelInfographic.Infographic{{ID: &id}}
	mockDB.On("GetInfographics", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(infoList, nil)
	mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModel.Bookmark{}, nil)
	mockDB.On("GetInfographicImagesByInfographics", mock.Anything, mock.Anything).Return([]dbModelInfographicImages.InfographicImage{}, nil)

	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Set("userId", int64(1))
	req, _ := http.NewRequest("GET", "/?category_id=1&page=0&page_size=10", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctx.Request = req
		controller.GetInfographics(ctx)
		w.Body.Reset() // Critical for benchmark speed
	}
}

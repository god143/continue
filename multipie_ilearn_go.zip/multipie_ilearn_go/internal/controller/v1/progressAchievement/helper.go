package progressAchievement

import (
	"context"
	"fmt"
	dbModel "multipie_ilearn_go/internal/db/progressAchievement"
)

// fetch in-progress courses
func (c *progressAchievementController) getInProgressCoursesHelper(ctx context.Context, userID int64) ([]dbModel.CourseResult, error) {
	courses, err := c.db.ProgressAndAchivement(ctx, userID)
	if err != nil {
		return nil, fmt.Errorf("unable to fetch courses: %w", err)
	}

	return courses, nil
}

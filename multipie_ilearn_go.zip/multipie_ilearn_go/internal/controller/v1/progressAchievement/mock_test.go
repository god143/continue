package progressAchievement

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/progressAchievement"
	"multipie_ilearn_go/internal/logger"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- SETUP ---

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- MOCK DB ---

type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) ProgressAndAchivement(ctx context.Context, userID int64) ([]dbModel.CourseResult, error) {
	args := m.Called(ctx, userID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.CourseResult), args.Error(1)
}

// --- TEST SUITE ---

func TestGetInProgressCourses(t *testing.T) {
	tests := []struct {
		name           string
		setupContext   func(*gin.Context)
		setupMock      func(*MockDB)
		expectedStatus int
	}{
		{
			name: "Happy Path - 200 OK",
			setupContext: func(c *gin.Context) {
				// Exact key "userId" and type int64 required by your utility
				c.Set("userId", int64(10))
			},
			setupMock: func(m *MockDB) {
				m.On("ProgressAndAchivement", mock.Anything, int64(10)).
					Return([]dbModel.CourseResult{{CourseID: 1, CourseName: "Success"}}, nil).Once()
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Database Error - 500 Internal Error",
			setupContext: func(c *gin.Context) {
				c.Set("userId", int64(20))
			},
			setupMock: func(m *MockDB) {
				m.On("ProgressAndAchivement", mock.Anything, int64(20)).
					Return(nil, errors.New("db error")).Once()
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name: "Unauthorized - Missing userId",
			setupContext: func(c *gin.Context) {
				// Setting nothing triggers "user not authenticated"
			},
			setupMock: func(m *MockDB) {
				// No calls expected
			},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name: "Unauthorized - Invalid Type (String instead of int64)",
			setupContext: func(c *gin.Context) {
				// Triggers "invalid userId" branch in ExtractUserId
				c.Set("userId", "10")
			},
			setupMock: func(m *MockDB) {
				// No calls expected
			},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name: "Success Path - Empty Results",
			setupContext: func(c *gin.Context) {
				c.Set("userId", int64(30))
			},
			setupMock: func(m *MockDB) {
				m.On("ProgressAndAchivement", mock.Anything, int64(30)).
					Return([]dbModel.CourseResult{}, nil).Once()
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockDB)
			ctrl := &progressAchievementController{db: mDB}

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request, _ = http.NewRequest("GET", "/", nil)

			tt.setupContext(c)
			tt.setupMock(mDB)

			ctrl.GetInProgressCourses(c)

			assert.Equal(t, tt.expectedStatus, w.Code, "Failed Case: "+tt.name)
			mDB.AssertExpectations(t)
		})
	}
}

// --- DIRECT HELPER TEST (For 90%+ Coverage) ---

func TestGetInProgressCoursesHelper_Logic(t *testing.T) {
	mDB := new(MockDB)
	ctrl := &progressAchievementController{db: mDB}

	t.Run("Helper Success", func(t *testing.T) {
		mDB.On("ProgressAndAchivement", mock.Anything, int64(1)).
			Return([]dbModel.CourseResult{{CourseID: 1}}, nil).Once()

		res, err := ctrl.getInProgressCoursesHelper(context.Background(), 1)
		assert.NoError(t, err)
		assert.Len(t, res, 1)
	})

	t.Run("Helper DB Error Handling", func(t *testing.T) {
		mDB.On("ProgressAndAchivement", mock.Anything, int64(2)).
			Return(nil, errors.New("sql failure")).Once()

		_, err := ctrl.getInProgressCoursesHelper(context.Background(), 2)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unable to fetch courses")
	})
}

// --- BENCHMARK ---

func BenchmarkGetInProgressCourses(b *testing.B) {
	mDB := new(MockDB)
	mDB.On("ProgressAndAchivement", mock.Anything, mock.Anything).Return([]dbModel.CourseResult{}, nil)
	ctrl := &progressAchievementController{db: mDB}
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Set("userId", int64(1))

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetInProgressCourses(c)
	}
}

package progressAchievement

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type progressAchievementController struct {
	db db.DBLayer
}

type ProgressAchievementControllerGroup interface {
	GetInProgressCourses(ctx *gin.Context)
}

func NewProgressAchievementGroup(db db.DBLayer) ProgressAchievementControllerGroup {
	return &progressAchievementController{
		db: db,
	}
}

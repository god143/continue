package progressAchievement

import (
	dbModel "multipie_ilearn_go/internal/db/progressAchievement"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

func (ipc *progressAchievementController) GetInProgressCourses(ctx *gin.Context) {
	var (
		resp                         *utils.Response
		GetInProgressCoursesResponse []dbModel.CourseResult
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}
	GetInProgressCoursesResponse, err = ipc.getInProgressCoursesHelper(ctx, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(GetInProgressCoursesResponse, nil)
	ctx.JSON(http.StatusOK, resp)
}

package courseModules

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModelBookmark "multipie_ilearn_go/internal/db/bookmark"
	dbModel "multipie_ilearn_go/internal/db/courseModules"
	"multipie_ilearn_go/internal/logger"

	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mock DBLayer Implementation ---
type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) GetCourseModulesWithResource(ctx context.Context, courseID int64) ([]dbModel.CourseModuleWithResource, error) {
	args := m.Called(ctx, courseID)
	return args.Get(0).([]dbModel.CourseModuleWithResource), args.Error(1)
}

func (m *MockDBLayer) GetBookmarkByCustomParams(ctx context.Context, ids []int, types []string, sub []string, uid int64) ([]dbModelBookmark.Bookmark, error) {
	args := m.Called(ctx, ids, types, sub, uid)
	return args.Get(0).([]dbModelBookmark.Bookmark), args.Error(1)
}

func (m *MockDBLayer) GetCourseModuleByIDWithResource(ctx context.Context, moduleID int64) (dbModel.CourseModuleWithResource, error) {
	args := m.Called(ctx, moduleID)
	return args.Get(0).(dbModel.CourseModuleWithResource), args.Error(1)
}

// Add other missing interface methods as empty mocks to satisfy DBLayer interface
func (m *MockDBLayer) GetCourseModuleByID(ctx context.Context, id int64) (dbModel.CourseModule, error) {
	return dbModel.CourseModule{}, nil
}

func TestMain(m *testing.M) {
	// Initialize logger once for the package to prevent nil pointer panics in helper.go
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	os.Exit(m.Run())
}

// --- Helper for Test Setup ---
func setupTestContext(method, url string) (*gin.Context, *httptest.ResponseRecorder) {
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	req, _ := http.NewRequest(method, url, nil)
	ctx.Request = req
	return ctx, w
}

func TestGetCourseModuleByCourseID(t *testing.T) {
	tests := []struct {
		name           string
		url            string
		setupCtx       func(*gin.Context)
		setupMock      func(*MockDBLayer)
		expectedStatus int
	}{
		{
			name: "Happy Path - Get Modules",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(12345)) // Matches ExtractUserId case-sensitivity
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{{
						CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)},
					}}, nil)
				m.On("GetBookmarkByCustomParams", mock.Anything, []int{1}, []string{"course_module"}, mock.Anything, int64(12345)).
					Return([]dbModelBookmark.Bookmark{}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Edge Case - Unauthorized",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				// No userId set
			},
			setupMock:      func(m *MockDBLayer) {},
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name: "Edge Case - Invalid CourseID Type",
			url:  "/modules?course_id=abc", // Binding will fail
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock:      func(m *MockDBLayer) {},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name: "Edge Case - DB Fetch Modules Error",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{}, errors.New("db error"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name: "Edge Case - DB Fetch Bookmarks Error",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{{
						CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)},
					}}, nil)
				m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, int64(123)).
					Return([]dbModelBookmark.Bookmark{}, errors.New("bookmark db error"))
			},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name: "Happy Path - Modules with Existing Bookmarks",
			url:  "/modules?course_id=10",
			setupCtx: func(c *gin.Context) {
				c.Set("userId", int64(123))
			},
			setupMock: func(m *MockDBLayer) {
				m.On("GetCourseModulesWithResource", mock.Anything, int64(10)).
					Return([]dbModel.CourseModuleWithResource{{
						CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)},
					}}, nil)
				// Simulate a found bookmark to cover the "exists" branch in helper
				m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, int64(123)).
					Return([]dbModelBookmark.Bookmark{{
						ID:      utils.Int64ToPointer(99),
						ModelId: utils.Int64ToPointer(1),
					}}, nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := new(MockDBLayer)
			ctrl := NewCourseModuleControllerGroup(m)
			tt.setupMock(m)

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			req, _ := http.NewRequest("GET", tt.url, nil)
			c.Request = req

			tt.setupCtx(c)
			ctrl.GetCourseModulesByCourseID(c)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestGetCourseModuleDetails(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		moduleID       string
		userID         int64
		dbModule       dbModel.CourseModuleWithResource
		dbErr          error
		expectedStatus int
	}{
		{
			name:           "Happy Path - Module Details",
			moduleID:       "500",
			userID:         55,
			dbModule:       dbModel.CourseModuleWithResource{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(500)}},
			expectedStatus: http.StatusOK,
		},
		{
			name:           "Edge Case - Invalid Module ID Format",
			moduleID:       "abc",
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Edge Case - DB Not Found",
			moduleID:       "999",
			userID:         55,
			dbErr:          errors.New("not found"),
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:           "Edge Case - DB Bookmark Fetch Error",
			moduleID:       "500",
			userID:         55,
			dbModule:       dbModel.CourseModuleWithResource{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(500)}},
			expectedStatus: http.StatusInternalServerError,
		},
		{
			name:           "Happy Path - Module Is Bookmarked",
			moduleID:       "500",
			userID:         55,
			dbModule:       dbModel.CourseModuleWithResource{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(500)}},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockDB := new(MockDBLayer)
			ctrl := NewCourseModuleControllerGroup(mockDB)
			ctx, w := setupTestContext("GET", "/")

			ctx.Params = gin.Params{{Key: "module_id", Value: tt.moduleID}}
			ctx.Set("userId", tt.userID)

			if tt.moduleID != "abc" {
				mockDB.On("GetCourseModuleByIDWithResource", mock.Anything, mock.Anything).Return(tt.dbModule, tt.dbErr)

				if tt.dbErr == nil {
					if tt.name == "Edge Case - DB Bookmark Fetch Error" {
						mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, tt.userID).
							Return([]dbModelBookmark.Bookmark{}, errors.New("bookmark fail"))
					} else if tt.name == "Happy Path - Module Is Bookmarked" {
						mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, tt.userID).
							Return([]dbModelBookmark.Bookmark{{ID: utils.Int64ToPointer(1)}}, nil)
					} else {
						mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, tt.userID).
							Return([]dbModelBookmark.Bookmark{}, nil)
					}
				}
			}

			ctrl.GetCourseModuleDetails(ctx)
			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- Benchmarks for Performance Validation ---
func BenchmarkGetCourseModulesByCourseID(b *testing.B) {
	m := new(MockDBLayer)
	ctrl := NewCourseModuleControllerGroup(m)
	m.On("GetCourseModulesWithResource", mock.Anything, mock.Anything).Return([]dbModel.CourseModuleWithResource{{CourseModule: dbModel.CourseModule{ID: utils.IntToPointer(1)}}}, nil)
	m.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModelBookmark.Bookmark{}, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/?course_id=10", nil)
		c.Set("userId", int64(123))
		ctrl.GetCourseModulesByCourseID(c)
	}
}

// BenchmarkGetCourseModuleDetails measures performance of the detail endpoint
func BenchmarkGetCourseModuleDetails(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mockDB := new(MockDBLayer)
	ctrl := NewCourseModuleControllerGroup(mockDB)

	mockDB.On("GetCourseModuleByIDWithResource", mock.Anything, mock.Anything).Return(dbModel.CourseModuleWithResource{}, nil)
	mockDB.On("GetBookmarkByCustomParams", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return([]dbModelBookmark.Bookmark{}, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = gin.Params{{Key: "module_id", Value: "1"}}
		req, _ := http.NewRequest("GET", "/module/1", nil)
		ctx.Request = req
		ctx.Set("user_id", int64(1))

		ctrl.GetCourseModuleDetails(ctx)
	}
}

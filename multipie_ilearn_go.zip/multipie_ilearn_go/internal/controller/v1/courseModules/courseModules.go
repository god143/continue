package courseModules

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// GetCourseModulesByCourseID retrieves all modules by course ID
func (c *courseModuleController) GetCourseModulesByCourseID(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseModulesByCourseIDRequest
	)
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	courseModulesResp, err := c.getCourseModulesByCourseIDHelper(ctx, request, uid)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer("unable to fetch modules by course-id"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(courseModulesResp, nil))
}

// GetCourseModuleDetails retrieves details of a single course module
func (c *courseModuleController) GetCourseModuleDetails(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCourseModuleDetailsRequest
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid moduleId format"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp := utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	moduleResp, err := c.getCourseModuleDetailsHelper(ctx, request, &uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unable to fetch course_module details"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(moduleResp, nil))
}

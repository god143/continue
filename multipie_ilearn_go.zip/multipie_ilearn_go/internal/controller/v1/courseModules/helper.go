package courseModules

import (
	"context"
	dbModel "multipie_ilearn_go/internal/db/courseModules"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

func (c *courseModuleController) getCourseModulesByCourseIDHelper(ctx context.Context, request GetCourseModulesByCourseIDRequest, userId int64) ([]dbModel.CourseModuleWithResource, error) {
	var courseModuleIds []int
	var courseModuleTypes []string
	var subtype []string

	courseModules, err := c.db.GetCourseModulesWithResource(ctx, *request.CourseID)
	if err != nil {
		logger.Error(ctx, "unable to fetch course modules", zap.Error(err))
		return courseModules, err
	}

	for _, courseModule := range courseModules {
		courseModuleIds = append(courseModuleIds, *courseModule.ID)
		courseModuleTypes = append(courseModuleTypes, "course_module")
	}

	bookmarks, err := c.db.GetBookmarkByCustomParams(ctx, courseModuleIds, courseModuleTypes, subtype, int64(userId))
	if err != nil {
		return nil, err
	}
	bookmarkSet := make(map[int]int)
	for _, bm := range bookmarks {
		if bm.ModelId != nil {
			bookmarkSet[int(*bm.ModelId)] = int(*bm.ID)

		}
	}
	responses := make([]dbModel.CourseModuleWithResource, 0, len(courseModules))

	for _, m := range courseModules {
		bookmarkID, exists := bookmarkSet[*m.ID]
		var isBookmark *bool
		if exists {
			trueVal := true
			isBookmark = &trueVal
		} else {
			falseVal := false
			isBookmark = &falseVal
		}

		var bookmarkIdPtr *int64
		if exists {
			bid := int64(bookmarkID)
			bookmarkIdPtr = &bid
		}
		responses = append(responses, dbModel.CourseModuleWithResource{
			CourseModule:    m.CourseModule,
			ExternalUrl:     m.ExternalUrl,
			ExternalUrlDark: m.ExternalUrlDark,
			IsBookmark:      isBookmark,
			BookmarkId:      bookmarkIdPtr,
		})
	}

	return responses, nil
}

func (c *courseModuleController) getCourseModuleDetailsHelper(ctx context.Context, request GetCourseModuleDetailsRequest, userId *int64) (dbModel.CourseModuleWithResource, error) {
	var courseIds []int
	var courseTypes []string
	var bookmarkId *int64
	var subtype []string

	course, err := c.db.GetCourseModuleByIDWithResource(ctx, *request.ModuleID)
	if err != nil {
		logger.Error(ctx, "unable to fetch course module", zap.Error(err))
		return dbModel.CourseModuleWithResource{}, err
	}

	courseIds = append(courseIds, *course.ID)
	courseTypes = append(courseTypes, "course_module")

	bookmark, err := c.db.GetBookmarkByCustomParams(ctx, courseIds, courseTypes, subtype, *userId)
	if err != nil {
		return dbModel.CourseModuleWithResource{}, err
	}
	for _, bm := range bookmark {
		bookmarkId = bm.ID
	}

	isBookmark := len(bookmark) != 0
	course.IsBookmark = &isBookmark
	course.BookmarkId = bookmarkId

	return course, nil
}

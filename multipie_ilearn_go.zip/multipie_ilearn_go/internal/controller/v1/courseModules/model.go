package courseModules

type GetCourseModulesByCourseIDRequest struct {
	CourseID *int64 `form:"course_id" binding:"required"`
}

type GetCourseModuleDetailsRequest struct {
	ModuleID *int64 `uri:"module_id" binding:"required"`
}

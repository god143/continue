package courseModules

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type courseModuleController struct {
	db db.DBLayer
}

type CourseModuleControllerGroup interface {
	GetCourseModulesByCourseID(ctx *gin.Context)
	GetCourseModuleDetails(ctx *gin.Context)
}

func NewCourseModuleControllerGroup(db db.DBLayer) CourseModuleControllerGroup {
	return &courseModuleController{
		db: db,
	}
}

package login

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type SignupRequest struct {
	Mobile      string `json:"mobile" binding:"required"`
	DisplayName string `json:"display_name"`
	Channel     string `json:"channel" binding:"required"`
	InviteCode  string `json:"invite_code,omitempty"`
	WAConsent   bool   `json:"wa_consent"`
}

type EmailSendOtp struct {
	Email string `json:"email" binding:"required"`
}

type VerifyEmailOtpRequest struct {
	Email string `json:"email" binding:"required"`
	Otp   string `json:"otp" binding:"required"`
}

type ResendOtp struct {
	Mobile string `json:"mobile" binding:"required"`
}

type ResendEmailOtp struct {
	Email string `json:"email" binding:"required"`
}

type VerifyRequest struct {
	Identifier string `json:"identifier" binding:"required"`
	Mobile     string `json:"mobile" binding:"required"`
	Otp        string `json:"otp" binding:"required"`
}

type RefreshTokenRequest struct {
	RefreshToken string `json:"refresh_token" binding:"required"`
}

type RefreshTokenResponse struct {
	RefreshToken string `json:"refresh_token" binding:"required"`
	Token        string `json:"token"`
	ExpiresAt    string `json:"expires_at"`
}

type SignupResponse struct {
	Message  string `json:"message"`
	Id       int64  `json:"id"`
	Username string `json:"username"`
}

type FinalResponse struct {
	Message    string `json:"message"`
	Identifier string `json:"identifier"`
}

type EmailOtpResponse struct {
	Message string `json:"message"`
}

type ResendOtpResponse struct {
	Message string `json:"message"`
}

type RequestPayload struct {
	ToEmail     string `json:"to_email"`
	Otp         string `json:"otp"`
	DisplayName string `json:"display_name"`
}

type ResponsePayload struct {
	Status    string `json:"status"`
	RequestID string `json:"request_id"`
}
type CreateUsersRequest struct {
	DisplayName     *string                   `json:"display_name" binding:"required"` // DisplayName of the user
	Username        *string                   `json:"username" binding:"required"`     // UserName of the user
	FirstName       *string                   `json:"first_name"`                      // First Name user ID
	LastName        *string                   `json:"last_name"`                       // Last Name of the user
	Mobile          *string                   `json:"mobile" binding:"required"`       // Mobile no of the user
	Email           *string                   `json:"email"`                           // Email of the user
	Status          *constants.UserStatusEnum `json:"status,omitempty"`                // Status of the user
	Uid             *int64                    `json:"uid"`
	FirstAccess     *time.Time                `json:"first_access"`
	ViaLogin        *string                   `json:"via_login"`
	IdirectUsername *string                   `json:"idirect_username"`
	AccountSource   *string                   `json:"account_source"`
}

type UpdateUsersRequest struct {
	ID              *int64  `json:"id" binding:"required"` // Unique ID for the user
	DisplayName     *string `json:"display_name"`          // DisplayName of the user
	Username        *string `json:"username"`              // UserName of the user
	FirstName       *string `json:"first_name"`            // First Name user ID
	LastName        *string `json:"last_name"`             // Last Name of the user
	Mobile          *string `json:"mobile"`                // Mobile no of the user
	Email           *string `json:"email"`                 // Email of the user
	ViaLogin        *string `json:"via_login"`
	SignInCount     *int64  `json:"sign_in_count"`
	IdirectUsername *string `json:"idirect_username"`
}

type VerifyResponse struct {
	ID               string     `json:"id"`
	Type             string     `json:"type"`
	VerifyAttributes Attributes `json:"attributes"`
}

type Attributes struct {
	Token        string `json:"token"`
	RefreshToken string `json:"refresh_token"`
	ExpiresAt    string `json:"expires_at"`
}

type AxiomSMSService struct {
	BaseURL string `json:"base_url"`
	DCode   string `json:"d_code"`
	SubUID  string `json:"sub_uid"`
	Pwd     string `json:"pwd"`
	From    string `json:"from"`
	IntFlag string `json:"int_flag"`
	MsgType string `json:"msg_type"`
	OTPFlag string `json:"otp_flag"`
	CType   string `json:"c_type"`
	LangID  string `json:"lang_id"`
}

type CustomerDetailsRequest struct {
	APISession string `json:"API_Session"`
	AppKey     string `json:"AppKey"`
}

type CustomerDetailsPayload struct {
	AppKey       string `json:"AppKey"`
	TimeStamp    string `json:"time_stamp"`
	JSONPostData string `json:"JSONPostData"`
	Checksum     string `json:"Checksum"`
}

type CustomerDetailsResponse struct {
	Status  int                    `json:"Status"`
	Error   interface{}            `json:"Error"`
	Success CustomerDetailsSuccess `json:"Success"`
}

type CustomerDetailsSuccess struct {
	IDirectUserID   string `json:"idirect_userid"`
	SessionToken    string `json:"session_token"`
	IDirectUserName string `json:"idirect_user_name"`
	MobileNo        string `json:"MobileNo"`
}

type IDirectLoginRequest struct {
	Token string `json:"token" binding:"required"`
}

type IDirectLoginResponse struct {
	ID               string     `json:"id"`
	Type             string     `json:"type"`
	Identifier       string     `json:"identifier"`
	VerifyAttributes Attributes `json:"attributes"`
	DisplayName      string     `json:"display_name"`
}

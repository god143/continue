package login

import (
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/constants"
	dbLogin "multipie_ilearn_go/internal/db/login"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/middleware/encryption"
	"multipie_ilearn_go/internal/utils"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (n *loginController) Verify(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request VerifyRequest
		resp    *utils.Response
	)
	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	decryptedMobile, err := encryption.DecryptResponse(request.Mobile, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Mobile = string(decryptedMobile)

	decryptedOtp, err := encryption.DecryptResponse(request.Otp, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Otp = string(decryptedOtp)

	isMobileValid := n.validMobileHelper(request.Mobile)
	if !isMobileValid {
		logger.Error(ctx, "invalid mobile number")
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid mobile number"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	// generate hashotp to compare
	hashOtp, err := n.hashHelper(request.Otp)
	if err != nil {
		logger.Error(ctx, "failed to hash otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	// remove hardcorded hash and uncomment db condition for expiry
	err = n.VerifyOtpHelper(ctx, request.Mobile, hashOtp)
	if errors.Is(err, ErrMaxOtpAttempts) {
		logger.Error(ctx, "max invalid otp attempt reached")
		resp = utils.NewV1Response(nil, utils.StringToPointer("max invalid otp attempt reached"))
		ctx.JSON(http.StatusTooManyRequests, resp)
		ctx.Abort()
		return
	}

	if err != nil {
		logger.Error(ctx, "Invalid or expired OTP", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid or expired OTP"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	users, err := n.getUserByPhoneNumberHelper(ctx, request.Mobile)
	if err != nil {
		logger.Error(ctx, "failed to fetch user details", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	var userStatus string
	if request.Identifier == "login" && len(users) > 0 {
		userStatus = constants.UserStatusEnumActive.String()
	} else if request.Identifier == "signup" {
		userStatus = constants.UserStatusEnumInactive.String()
	} else {
		logger.Error(ctx, "invalid identifier")
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid identifier"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	switch {
	case len(users) == 1:
		token, err := n.findOrCreateTokenHelper(ctx, int(*users[0].ID))
		if err != nil {
			logger.Error(ctx, "failed to fetch user details", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
			ctx.JSON(http.StatusInternalServerError, resp)
			ctx.Abort()
			return
		}

		err = n.updateUsersHelper(ctx, int(*users[0].ID), userStatus)
		if err != nil {
			logger.Error(ctx, "failed to update user status", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update user status"))
			ctx.JSON(http.StatusInternalServerError, resp)
			ctx.Abort()
			return
		}

		idStr := strconv.Itoa(token.Id)

		attributes := Attributes{
			Token:        token.Token,
			RefreshToken: token.RefreshToken,
			ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
		}

		response := VerifyResponse{
			ID:               idStr,
			Type:             "access_token",
			VerifyAttributes: attributes,
		}

		ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
		return
	case len(users) > 1:
		fmt.Println("----here--->")
		isHuf := n.isHUFAccount(users)
		if isHuf {
			fmt.Println("----huf--->")
			logger.Error(ctx, "HUF account found redirect to idirect login", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("HUF account found redirect to idirect login"))
			ctx.JSON(http.StatusConflict, resp)
			ctx.Abort()
			return
		} else {
			fmt.Println("----non huf--->")
			ilearnLegacy := "ilearn_legacy"
			ilearnNew := "ilearn_new"
			mobile := constants.VialoginMobile
			for _, user := range users {
				if *user.AccountSource == ilearnLegacy && *user.ViaLogin == string(mobile) {
					token, err := n.findOrCreateTokenHelper(ctx, int(*user.ID))
					if err != nil {
						logger.Error(ctx, "failed to fetch user details", zap.Error(err))
						resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
						ctx.JSON(http.StatusInternalServerError, resp)
						ctx.Abort()
						return
					}

					err = n.updateUsersHelper(ctx, int(*user.ID), userStatus)
					if err != nil {
						logger.Error(ctx, "failed to update user status", zap.Error(err))
						resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update user status"))
						ctx.JSON(http.StatusInternalServerError, resp)
						ctx.Abort()
						return
					}

					idStr := strconv.Itoa(token.Id)

					attributes := Attributes{
						Token:        token.Token,
						RefreshToken: token.RefreshToken,
						ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
					}

					response := VerifyResponse{
						ID:               idStr,
						Type:             "access_token",
						VerifyAttributes: attributes,
					}

					ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
					return
				} else if *user.AccountSource == ilearnNew {
					logger.Error(ctx, "invalid data", zap.Error(err))
					resp = utils.NewV1Response(nil, utils.StringToPointer("invalid data"))
					ctx.JSON(http.StatusBadRequest, resp)
					ctx.Abort()
					return
				}
			}
		}
	}

	// if len(users) != 1 {
	// 	logger.Error(ctx, "invalid request", zap.Error(err))
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request"))
	// 	ctx.JSON(http.StatusInternalServerError, resp)
	// 	ctx.Abort()
	// 	return
	// }

	// token, err := n.findOrCreateTokenHelper(ctx, int(*users[0].ID))
	// if err != nil {
	// 	logger.Error(ctx, "failed to fetch user details", zap.Error(err))
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
	// 	ctx.JSON(http.StatusInternalServerError, resp)
	// 	ctx.Abort()
	// 	return
	// }

	// err = n.updateUsersHelper(ctx, int(*users[0].ID), userStatus)
	// if err != nil {
	// 	logger.Error(ctx, "failed to update user status", zap.Error(err))
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update user status"))
	// 	ctx.JSON(http.StatusInternalServerError, resp)
	// 	ctx.Abort()
	// 	return
	// }

	// idStr := strconv.Itoa(token.Id)

	// attributes := Attributes{
	// 	Token:        token.Token,
	// 	RefreshToken: token.RefreshToken,
	// 	ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
	// }

	// response := VerifyResponse{
	// 	ID:               idStr,
	// 	Type:             "access_token",
	// 	VerifyAttributes: attributes,
	// }

	// ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
}

func (n *loginController) VerifyEmailOtp(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request VerifyEmailOtpRequest
		resp    *utils.Response
	)
	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		logger.Error(ctx, "failed to extract user ID", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to extract user ID"))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	decryptedMobile, err := encryption.DecryptResponse(request.Email, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Email = string(decryptedMobile)

	decryptedOtp, err := encryption.DecryptResponse(request.Otp, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Otp = string(decryptedOtp)

	isEmailValid := n.isEmailValid(request.Email)
	if !isEmailValid {
		logger.Error(ctx, "invalid email")
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid email"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	// generate hashotp to compare
	hashOtp, err := n.hashHelper(request.Otp)
	if err != nil {
		logger.Error(ctx, "failed to hash otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	// remove hardcorded hash and uncomment db condition for expiry
	err = n.verifyEmailOTPHelper(ctx, request.Email, hashOtp, userID)
	if errors.Is(err, ErrMaxOtpAttempts) {
		logger.Error(ctx, "max invalid otp attempt reached")
		resp = utils.NewV1Response(nil, utils.StringToPointer("max invalid otp attempt reached"))
		ctx.JSON(http.StatusTooManyRequests, resp)
		ctx.Abort()
		return
	}

	if err != nil {
		logger.Error(ctx, "Invalid or expired OTP", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid or expired OTP"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	req := UpdateUsersRequest{
		ID:    &userID,
		Email: &request.Email,
	}

	err = n.updateEmailHelper(ctx, req)
	if err != nil {
		logger.Error(ctx, "failed to update user status", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update user status"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response := EmailOtpResponse{
		Message: "email verified successfully",
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
}

func (n *loginController) RefreshToken(ctx *gin.Context) {
	cfg := config.AppSecrets
	var (
		request RefreshTokenRequest
		resp    *utils.Response
	)
	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	decryptedRefreshToken, err := encryption.DecryptResponse(request.RefreshToken, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))

	request.RefreshToken = string(decryptedRefreshToken)

	res, err := n.RefreshTokenHelper(ctx, request)
	if err != nil {
		logger.Error(ctx, "refresh token not found", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("refresh token not found"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	tokenResp := RefreshTokenResponse{
		RefreshToken: res.RefreshToken,
		Token:        res.Token,
		ExpiresAt:    res.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(tokenResp, nil))
	return

}

func (n *loginController) Logout(ctx *gin.Context) {
	authHeader := ctx.GetHeader("Authorization")
	if authHeader == "" {
		logger.Error(ctx, "authorization header missing")
		resp := utils.NewV1Response(nil, utils.StringToPointer("authorization header missing"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	parts := strings.SplitN(authHeader, " ", 2)
	if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
		logger.Error(ctx, "invalid authorization header")
		resp := utils.NewV1Response(nil, utils.StringToPointer("invalid authorization header"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err := n.logoutHelper(ctx, parts[1])
	if err != nil {
		logger.Error(ctx, "failed to revoke token", zap.Error(err))
		resp := utils.NewV1Response(nil, utils.StringToPointer("failed to revoke token"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"message": "successfully logout user",
	})
}

func (n *loginController) Login(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request SignupRequest
		resp    *utils.Response
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	decryptedMobile, err := encryption.DecryptResponse(request.Mobile, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	if err != nil {
		fmt.Errorf("failed to fetch keys")
	}
	request.Mobile = string(decryptedMobile)

	isMobileValid := n.validMobileHelper(request.Mobile)
	if !isMobileValid {
		logger.Error(ctx, "invalid mobile number")
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid mobile number"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	users, err := n.getUserByPhoneNumberHelper(ctx, request.Mobile)
	if err != nil {
		logger.Error(ctx, "failed to fetch user details", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	var identifer string
	if len(users) == 0 || (len(users) == 1 && *users[0].Status == constants.UserStatusEnumInactive) {
		identifer = "signup"
	} else {
		identifer = "login"
	}

	switch {
	case len(users) == 0:
		username, err := n.generateUsernameHelper("ilearn", 4)
		if err != nil {
			logger.Error(ctx, "failed to generate username", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to generate username"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		inactiveStatus := constants.UserStatusEnumInactive
		firstAccess := time.Now()
		viaLogin := "mobile"
		accountSource := "ilearn_new"

		createUsersRequest := CreateUsersRequest{
			DisplayName:   &username,
			Username:      &username,
			FirstName:     &username,
			Mobile:        &request.Mobile,
			Status:        &inactiveStatus,
			FirstAccess:   &firstAccess,
			ViaLogin:      &viaLogin,
			AccountSource: &accountSource,
		}

		user, err := n.createUsersHelper(ctx, createUsersRequest)
		if err != nil {
			logger.Error(ctx, "failed to create user", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create user"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}
		otp := n.generateOTPHelper()
		fmt.Println("otp---->", otp)

		hashOtp, err := n.hashHelper(otp)
		if err != nil {
			logger.Error(ctx, "failed to hash otp", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		fmt.Println("hashotp--->", hashOtp)

		otpVerifications := dbLogin.CreateOtpRequest{
			UserId:    int(*user.ID),
			Mobile:    *user.Mobile,
			OtpHash:   string(hashOtp),
			ResendOtp: 0,
			Attempts:  0,
			ExpiresAt: time.Now().Add(10 * time.Minute),
		}

		_, err = n.CreateOrUpdateOtpHelper(ctx, otpVerifications)
		if err != nil {
			logger.Error(ctx, "failed to store otp in db", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		err = n.sendOTPHelper(ctx, request.Mobile, otp)
		if err != nil {
			logger.Error(ctx, "failed to send otp", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to send otp"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		res := FinalResponse{
			Message:    "success",
			Identifier: identifer,
		}
		ctx.JSON(http.StatusOK, utils.NewV1Response(res, nil))
		return
	case len(users) == 1:
		otp := n.generateOTPHelper()
		fmt.Println("otp---->", otp)

		hashOtp, err := n.hashHelper(otp)
		if err != nil {
			logger.Error(ctx, "failed to hash otp", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		fmt.Println("hashotp--->", hashOtp)

		otpVerifications := dbLogin.CreateOtpRequest{
			UserId:    int(*users[0].ID),
			Mobile:    *users[0].Mobile,
			OtpHash:   string(hashOtp),
			ResendOtp: 0,
			ExpiresAt: time.Now().Add(10 * time.Minute),
		}

		_, err = n.CreateOrUpdateOtpHelper(ctx, otpVerifications)
		if err != nil {
			logger.Error(ctx, "failed to store otp in db", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		err = n.sendOTPHelper(ctx, request.Mobile, otp)
		if err != nil {
			logger.Error(ctx, "failed to send otp", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to send otp"))
			ctx.JSON(http.StatusBadRequest, resp)
			ctx.Abort()
			return
		}

		res := FinalResponse{
			Message:    "success",
			Identifier: identifer,
		}
		ctx.JSON(http.StatusOK, utils.NewV1Response(res, nil))
		return
	case len(users) > 1:
		fmt.Println("----here--->")
		isHuf := n.isHUFAccount(users)
		if isHuf {
			fmt.Println("----huf--->")
			logger.Error(ctx, "HUF account found redirect to idirect login", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("HUF account found redirect to idirect login"))
			ctx.JSON(http.StatusConflict, resp)
			ctx.Abort()
			return
		} else {
			fmt.Println("----non huf--->")
			ilearnLegacy := "ilearn_legacy"
			ilearnNew := "ilearn_new"
			mobile := constants.VialoginMobile
			for _, user := range users {
				fmt.Println("account_source--->", *user.AccountSource == ilearnLegacy)
				fmt.Println("--vialogin--->", *user.ViaLogin == string(mobile))

				if *user.AccountSource == ilearnLegacy && *user.ViaLogin == string(mobile) {
					otp := n.generateOTPHelper()
					fmt.Println("otp-non-huf--->", otp)

					hashOtp, err := n.hashHelper(otp)
					if err != nil {
						logger.Error(ctx, "failed to hash otp", zap.Error(err))
						resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
						ctx.JSON(http.StatusBadRequest, resp)
						ctx.Abort()
						return
					}

					fmt.Println("hashotp-nonhuf-->", hashOtp)

					otpVerifications := dbLogin.CreateOtpRequest{
						UserId:    int(*user.ID),
						Mobile:    *user.Mobile,
						OtpHash:   string(hashOtp),
						ResendOtp: 0,
						ExpiresAt: time.Now().Add(10 * time.Minute),
					}

					_, err = n.CreateOrUpdateOtpHelper(ctx, otpVerifications)
					if err != nil {
						logger.Error(ctx, "failed to store otp in db", zap.Error(err))
						resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
						ctx.JSON(http.StatusBadRequest, resp)
						ctx.Abort()
						return
					}

					err = n.sendOTPHelper(ctx, request.Mobile, otp)
					if err != nil {
						logger.Error(ctx, "failed to send otp", zap.Error(err))
						resp = utils.NewV1Response(nil, utils.StringToPointer("failed to send otp"))
						ctx.JSON(http.StatusBadRequest, resp)
						ctx.Abort()
						return
					}

					res := FinalResponse{
						Message:    "success",
						Identifier: identifer,
					}
					ctx.JSON(http.StatusOK, utils.NewV1Response(res, nil))
					return
				} else if *user.AccountSource == ilearnNew {
					logger.Error(ctx, "invalid data", zap.Error(err))
					resp = utils.NewV1Response(nil, utils.StringToPointer("invalid data"))
					ctx.JSON(http.StatusBadRequest, resp)
					ctx.Abort()
					return
				}
			}
		}
	}
}

func (n *loginController) SendEmailOtp(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request EmailSendOtp
		resp    *utils.Response
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		logger.Error(ctx, "failed to extract user ID", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to extract user ID"))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	decryptedMobile, err := encryption.DecryptResponse(request.Email, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	if err != nil {
		fmt.Errorf("failed to fetch keys")
	}
	request.Email = string(decryptedMobile)

	// isMobileValid := n.isEmailValid(request.Email)
	// if !isMobileValid {
	// 	logger.Error(ctx, "invalid email")
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer("invalid email"))
	// 	ctx.JSON(http.StatusBadRequest, resp)
	// 	ctx.Abort()
	// 	return
	// }

	otp := n.generateOTPHelper()
	fmt.Println("otp---->", otp)

	hashOtp, err := n.hashHelper(otp)
	if err != nil {
		logger.Error(ctx, "failed to hash otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	fmt.Println("hashotp--->", hashOtp)

	emailOtpVerifications := dbLogin.CreateEmailOtpRequest{
		UserId:    int(userID),
		Email:     request.Email,
		OtpHash:   string(hashOtp),
		ResendOtp: 0,
		Attempts:  0,
		ExpiresAt: time.Now().Add(10 * time.Minute),
	}

	_, err = n.CreateOrUpdateEmailOtpHelper(ctx, emailOtpVerifications)
	if err != nil {
		logger.Error(ctx, "failed to store otp in db", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	user, err := n.getUserByUIDHelper(ctx, userID)
	if err != nil {
		logger.Error(ctx, "failed to fetch user details", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err = n.sendEmailOTPHelper(ctx, request.Email, otp, *user.DisplayName)
	if err != nil {
		logger.Error(ctx, "failed to send otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to send otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	res := EmailOtpResponse{
		Message: "otp sent successfully",
	}
	ctx.JSON(http.StatusOK, utils.NewV1Response(res, nil))
}

func (n *loginController) IDirectLogin(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request IDirectLoginRequest
		resp    *utils.Response
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	decryptedToken, err := encryption.DecryptResponse(request.Token, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Token = string(decryptedToken)

	customer, err := n.getCustomerDetailsHelper(ctx, request.Token)
	if err != nil {
		logger.Error(ctx, "invalid idirect session", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid idirect session"))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	decryptedMobile, err := n.decryptAES256ECB(customer.Success.MobileNo, constants.API_SECRET)
	if err != nil {
		logger.Error(ctx, "failed to decrypt mobile number", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to decrypt mobile number"))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	decryptedMobile = "91 " + decryptedMobile
	customer.Success.MobileNo = decryptedMobile

	// customer.Success.MobileNo = "91 " + decryptedMobile
	// identifier := "login"
	// var user *users.Users
	// user, err = n.getUserByIDirectUsernameHelper(ctx, customer.Success)
	// if errors.Is(err, gorm.ErrRecordNotFound) {
	// 	identifier = "signup"
	// 	user, err = n.createIdirectUserHelper(ctx, customer.Success)
	// 	if err != nil {
	// 		logger.Error(ctx, "failed to create idirect user", zap.Error(err))
	// 		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create idirect user"))
	// 		ctx.JSON(http.StatusUnauthorized, resp)
	// 		ctx.Abort()
	// 		return
	// 	}
	// }

	// if err != nil {
	// 	logger.Error(ctx, "failed to fetch or create user", zap.Error(err))
	// 	resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch or create user"))
	// 	ctx.JSON(http.StatusUnauthorized, resp)
	// 	ctx.Abort()
	// 	return
	// }

	users, err := n.getUserByPhoneNumberHelper(ctx, decryptedMobile)
	if err != nil {
		logger.Error(ctx, "failed to fetch user details", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	fmt.Println("number of users --->", len(users))

	var identifier string
	if len(users) == 0 {
		identifier = "signup"
	} else {
		identifier = "login"
	}

	switch {
	case len(users) == 0:
		user, err := n.createIdirectUserHelper(ctx, customer.Success)
		if err != nil {
			logger.Error(ctx, "failed to create idirect user", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create idirect user"))
			ctx.JSON(http.StatusUnauthorized, resp)
			ctx.Abort()
			return
		}
		token, err := n.findOrCreateTokenHelper(ctx, int(*user.ID))
		if err != nil {
			logger.Error(ctx, "failed to create token", zap.Error(err))
			resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create token"))
			ctx.JSON(http.StatusInternalServerError, resp)
			ctx.Abort()
			return
		}

		idStr := strconv.Itoa(token.Id)

		attributes := Attributes{
			Token:        token.Token,
			RefreshToken: token.RefreshToken,
			ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
		}

		response := IDirectLoginResponse{
			ID:               idStr,
			Type:             "access_token",
			Identifier:       identifier,
			DisplayName:      customer.Success.IDirectUserName,
			VerifyAttributes: attributes,
		}

		ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
		return
	case len(users) == 1:
		if users[0].IdirectUsername == nil {
			user, err := n.updateIdirectUsernameHelper(ctx, *users[0].ID, strings.ToUpper(customer.Success.IDirectUserID))
			if err != nil {
				logger.Error(ctx, "failed to update idirectusername", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update idirectusername"))
				ctx.JSON(http.StatusBadRequest, resp)
				ctx.Abort()
				return
			}

			err = n.updateUsersHelper(ctx, int(*user.ID), constants.UserStatusEnumActive.String())
			if err != nil {
				logger.Error(ctx, "failed to update status", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update status"))
				ctx.JSON(http.StatusBadRequest, resp)
				ctx.Abort()
				return
			}

			token, err := n.findOrCreateTokenHelper(ctx, int(*user.ID))
			if err != nil {
				logger.Error(ctx, "failed to create token", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create token"))
				ctx.JSON(http.StatusInternalServerError, resp)
				ctx.Abort()
				return
			}

			idStr := strconv.Itoa(token.Id)

			attributes := Attributes{
				Token:        token.Token,
				RefreshToken: token.RefreshToken,
				ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
			}

			response := IDirectLoginResponse{
				ID:               idStr,
				Type:             "access_token",
				Identifier:       identifier,
				DisplayName:      customer.Success.IDirectUserName,
				VerifyAttributes: attributes,
			}
			ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
			return
		} else if strings.ToUpper(*users[0].IdirectUsername) == strings.ToUpper(customer.Success.IDirectUserID) {
			token, err := n.findOrCreateTokenHelper(ctx, int(*users[0].ID))
			if err != nil {
				logger.Error(ctx, "failed to create token", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create token"))
				ctx.JSON(http.StatusInternalServerError, resp)
				ctx.Abort()
				return
			}

			idStr := strconv.Itoa(token.Id)

			attributes := Attributes{
				Token:        token.Token,
				RefreshToken: token.RefreshToken,
				ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
			}

			response := IDirectLoginResponse{
				ID:               idStr,
				Type:             "access_token",
				Identifier:       identifier,
				DisplayName:      customer.Success.IDirectUserName,
				VerifyAttributes: attributes,
			}

			ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
			return
		}
	case len(users) > 1:
		var trackingId int64
		for _, user := range users {
			if user.IdirectUsername == nil {
				trackingId = *user.ID
			} else if strings.ToUpper(*user.IdirectUsername) == strings.ToUpper(customer.Success.IDirectUserID) {
				token, err := n.findOrCreateTokenHelper(ctx, int(*users[0].ID))
				if err != nil {
					logger.Error(ctx, "failed to create token", zap.Error(err))
					resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create token"))
					ctx.JSON(http.StatusInternalServerError, resp)
					ctx.Abort()
					return
				}

				idStr := strconv.Itoa(token.Id)

				attributes := Attributes{
					Token:        token.Token,
					RefreshToken: token.RefreshToken,
					ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
				}

				response := IDirectLoginResponse{
					ID:               idStr,
					Type:             "access_token",
					Identifier:       identifier,
					DisplayName:      customer.Success.IDirectUserName,
					VerifyAttributes: attributes,
				}

				ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
				return
			}
		}
		if trackingId != 0 {
			user, err := n.updateIdirectUsernameHelper(ctx, trackingId, strings.ToUpper(customer.Success.IDirectUserID))
			if err != nil {
				logger.Error(ctx, "failed to update idirectusername", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update idirectusername"))
				ctx.JSON(http.StatusBadRequest, resp)
				ctx.Abort()
				return
			}

			err = n.updateUsersHelper(ctx, int(*user.ID), constants.UserStatusEnumActive.String())
			if err != nil {
				logger.Error(ctx, "failed to update status", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to update status"))
				ctx.JSON(http.StatusBadRequest, resp)
				ctx.Abort()
				return
			}

			token, err := n.findOrCreateTokenHelper(ctx, int(*user.ID))
			if err != nil {
				logger.Error(ctx, "failed to create token", zap.Error(err))
				resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create token"))
				ctx.JSON(http.StatusInternalServerError, resp)
				ctx.Abort()
				return
			}

			idStr := strconv.Itoa(token.Id)

			attributes := Attributes{
				Token:        token.Token,
				RefreshToken: token.RefreshToken,
				ExpiresAt:    token.ExpiresAt.Format("2006-01-02T15:04:05.999Z"),
			}

			response := IDirectLoginResponse{
				ID:               idStr,
				Type:             "access_token",
				Identifier:       identifier,
				DisplayName:      customer.Success.IDirectUserName,
				VerifyAttributes: attributes,
			}
			ctx.JSON(http.StatusOK, utils.NewV1Response(response, nil))
			return
		}
	}
}

func (n *loginController) IDirectCallback(ctx *gin.Context) {
	requestToken := ctx.PostForm("apisession")

	if requestToken == "" {
		ctx.Redirect(
			http.StatusFound,
			constants.ILEARN_DOMAIN+"/login",
		)
		return
	}

	// Redirect to frontend.
	redirectURL := fmt.Sprintf(
		"%s/idirect/callback?token=%s",
		constants.ILEARN_DOMAIN,
		url.QueryEscape(requestToken),
	)

	ctx.Redirect(http.StatusFound, redirectURL)
}

func (n *loginController) ResendOtp(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request ResendOtp
		resp    *utils.Response
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	decryptedMobile, err := encryption.DecryptResponse(request.Mobile, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Mobile = string(decryptedMobile)

	isMobileValid := n.validMobileHelper(request.Mobile)
	if !isMobileValid {
		logger.Error(ctx, "invalid mobile number")
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid mobile number"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	users, err := n.getUserByPhoneNumberHelper(ctx, request.Mobile)
	if err != nil {
		logger.Error(ctx, "failed to fetch user details", zap.Error(err))
		return
	}

	otpVerifications := dbLogin.CreateOtpRequest{
		Mobile: *users[0].Mobile,
	}

	otpDetails, err := n.GetOtpHelper(ctx, otpVerifications)
	if err != nil {
		logger.Error(ctx, "failed to store otp in db", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	if otpDetails.ResendOtp == constants.MAXRESENDOTP {
		logger.Error(ctx, "max resend otp reached")
		resp = utils.NewV1Response(nil, utils.StringToPointer("max resend otp reached"))
		ctx.JSON(http.StatusTooManyRequests, resp)
		ctx.Abort()
		return
	}

	otp := n.generateOTPHelper()
	fmt.Println("otp---->", otp)

	hashOtp, err := n.hashHelper(otp)
	if err != nil {
		logger.Error(ctx, "failed to hash otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	fmt.Println("hashotp--->", hashOtp)

	createOrUpdateOtpRequest := dbLogin.CreateOtpRequest{
		UserId:    int(*users[0].ID),
		Mobile:    *users[0].Mobile,
		OtpHash:   string(hashOtp),
		ResendOtp: otpDetails.ResendOtp + 1,
		ExpiresAt: time.Now().Add(5 * time.Minute),
	}

	_, err = n.CreateOrUpdateOtpHelper(ctx, createOrUpdateOtpRequest)
	if err != nil {
		logger.Error(ctx, "failed to store otp in db", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err = n.sendOTPHelper(ctx, request.Mobile, otp)
	if err != nil {
		logger.Error(ctx, "failed to send otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to send otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	res := ResendOtpResponse{
		Message: "success",
	}
	ctx.JSON(http.StatusOK, utils.NewV1Response(res, nil))
	return
}

func (n *loginController) ResendEmailOtp(ctx *gin.Context) {
	cfg := config.AppSecrets

	var (
		request ResendEmailOtp
		resp    *utils.Response
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		logger.Error(ctx, "failed to extract user ID", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to extract user ID"))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	decryptedMobile, err := encryption.DecryptResponse(request.Email, []byte(cfg.SecurityKeys.Key), []byte(cfg.SecurityKeys.IV))
	request.Email = string(decryptedMobile)

	otpVerifications := dbLogin.CreateEmailOtpRequest{
		Email:  request.Email,
		UserId: int(userID),
	}

	otpDetails, err := n.GetEmailOtpHelper(ctx, otpVerifications)
	if err != nil {
		logger.Error(ctx, "failed to store otp in db", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	if otpDetails.ResendOtp == constants.MAXRESENDOTP {
		logger.Error(ctx, "max resend otp reached")
		resp = utils.NewV1Response(nil, utils.StringToPointer("max resend otp reached"))
		ctx.JSON(http.StatusTooManyRequests, resp)
		ctx.Abort()
		return
	}

	otp := n.generateOTPHelper()
	fmt.Println("otp---->", otp)

	hashOtp, err := n.hashHelper(otp)
	if err != nil {
		logger.Error(ctx, "failed to hash otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to hash otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	fmt.Println("hashotp--->", hashOtp)

	createOrUpdateEmailOtpRequest := dbLogin.CreateEmailOtpRequest{
		UserId:    int(userID),
		Email:     request.Email,
		OtpHash:   string(hashOtp),
		ResendOtp: otpDetails.ResendOtp + 1,
		ExpiresAt: time.Now().Add(5 * time.Minute),
	}

	_, err = n.CreateOrUpdateEmailOtpHelper(ctx, createOrUpdateEmailOtpRequest)
	if err != nil {
		logger.Error(ctx, "failed to store otp in db", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to store otp in db"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	user, err := n.getUserByUIDHelper(ctx, userID)
	if err != nil {
		logger.Error(ctx, "failed to fetch user details", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch user details"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	err = n.sendEmailOTPHelper(ctx, request.Email, otp, *user.DisplayName)
	if err != nil {
		logger.Error(ctx, "failed to send otp", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to send otp"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	res := EmailOtpResponse{
		Message: "success",
	}
	ctx.JSON(http.StatusOK, utils.NewV1Response(res, nil))
	return
}

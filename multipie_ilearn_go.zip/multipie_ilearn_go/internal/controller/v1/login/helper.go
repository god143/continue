package login

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math/big"
	"multipie_ilearn_go/internal/constants"
	dbLogin "multipie_ilearn_go/internal/db/login"
	dbModel "multipie_ilearn_go/internal/db/users"
	"multipie_ilearn_go/internal/logger"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"go.uber.org/zap"
)

var ErrMaxOtpAttempts = errors.New("max invalid otp attempt reached")

func (c *loginController) getUserByPhoneNumberHelper(ctx context.Context, mobile string) ([]dbModel.Users, error) {

	users, err := c.db.GetUsersByMobile(ctx, mobile)
	if err != nil {
		logger.Error(ctx, "unable to fetch user from db", zap.Error(err))
		return nil, errors.New("unable to fetch user from db")
	}

	return users, nil
}

// func (c *loginController) getUserByEmailHelper(ctx context.Context, email string, userId int64) (*dbModel.Users, error) {

// 	users, err := c.db.GetUsersByEmail(ctx, email, userId)
// 	if err != nil {
// 		logger.Error(ctx, "unable to fetch user from db", zap.Error(err))
// 		return nil, errors.New("unable to fetch user from db")
// 	}

// 	return users, nil
// }

func (c *loginController) createUsersHelper(ctx context.Context, request CreateUsersRequest) (*dbModel.Users, error) {

	defaultRole := constants.UserRoleEnumUser
	// defaultStatus := constants.UserStatusEnumActive

	users := &dbModel.Users{
		DisplayName:     request.DisplayName,
		Username:        request.Username,
		FirstName:       request.FirstName,
		LastName:        request.LastName,
		Mobile:          request.Mobile,
		Email:           request.Email,
		Role:            &defaultRole,
		Status:          request.Status,
		FirstAccess:     request.FirstAccess,
		ViaLogin:        request.ViaLogin,
		IdirectUsername: request.IdirectUsername,
		AccountSource:   request.AccountSource,
	}

	users, err := c.db.CreateUsers(ctx, users)
	if err != nil {
		logger.Error(ctx, "unable to create users entry in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to create users entry in database")
	}

	updateUserRequest := &dbModel.Users{
		ID:  users.ID,
		Uid: users.ID,
	}

	updatedUsers, err := c.db.UpdateUsers(ctx, *updateUserRequest)
	if err != nil {
		logger.Error(ctx, "unable to update users uid in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to update uid entry in database")
	}

	users.Uid = updatedUsers.Uid

	return users, nil
}

func (c *loginController) updateUsersHelper(ctx context.Context, userid int, status string) error {
	err := c.db.UpdateStatus(ctx, int64(userid), status)
	if err != nil {
		logger.Error(ctx, "unable to update users uid in database", zap.Error(err))
		return errors.New("unable to update uid entry in database")
	}

	return nil
}

func (c *loginController) updateEmailHelper(ctx context.Context, request UpdateUsersRequest) error {
	users := dbModel.Users{
		ID:    request.ID,
		Email: request.Email,
	}

	_, err := c.db.UpdateUsers(ctx, users)
	if err != nil {
		logger.Error(ctx, "unable to update users entry in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to update users entry in database")
	}

	return nil
}

func (c *loginController) generateOTPHelper() string {
	n, _ := rand.Int(rand.Reader, big.NewInt(1000000))
	return fmt.Sprintf("%06d", n.Int64())
}

func (c *loginController) generateTokenHelper() string {
	n := rand.Text()
	return fmt.Sprintf("%16v", n)
}

func (c *loginController) hashHelper(input string) (string, error) {
	// hash, err := bcrypt.GenerateFromPassword(
	// 	[]byte(input),
	// 	bcrypt.DefaultCost,
	// )

	// if err != nil {
	// 	logger.Error(ctx, "failed to hash the otp", zap.Error(err))
	// 	return "", fmt.Errorf("failed to hash the otp: %w", err)
	// }

	hash := sha256.Sum256([]byte(input))

	return hex.EncodeToString(hash[:]), nil
}

func (c *loginController) logoutHelper(ctx context.Context, token string) error {
	err := c.db.Logout(ctx, token)
	if err != nil {
		logger.Error(ctx, "failed to revoke token helper", zap.Error(err))
		return fmt.Errorf("failed to revoke token helper: %w", err)
	}
	return nil
}

func (c *loginController) GetOtpHelper(ctx context.Context, request dbLogin.CreateOtpRequest) (*dbLogin.Otp, error) {
	result, err := c.db.GetOtp(ctx, request)
	if err != nil {
		logger.Error(ctx, "failed to get otp details", zap.Error(err))
		return nil, fmt.Errorf("failed to get otp details: %w", err)
	}
	return result, nil
}

func (c *loginController) GetEmailOtpHelper(ctx context.Context, request dbLogin.CreateEmailOtpRequest) (*dbLogin.EmailOtp, error) {
	result, err := c.db.GetEmailOtp(ctx, request)
	if err != nil {
		logger.Error(ctx, "failed to get otp details", zap.Error(err))
		return nil, fmt.Errorf("failed to get otp details: %w", err)
	}
	return result, nil
}

func (c *loginController) CreateOrUpdateOtpHelper(ctx context.Context, request dbLogin.CreateOtpRequest) (*dbLogin.Otp, error) {

	createOtp := dbLogin.CreateOtpRequest{
		UserId:    request.UserId,
		Mobile:    request.Mobile,
		OtpHash:   request.OtpHash,
		ResendOtp: request.ResendOtp,
		Attempts:  request.Attempts,
		ExpiresAt: request.ExpiresAt,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	result, err := c.db.CreateOrUpdateOtp(ctx, createOtp)
	if err != nil {
		logger.Error(ctx, "failed to create otp", zap.Error(err))
		return nil, fmt.Errorf("failed to create otp: %w", err)
	}

	return result, nil
}

func (c *loginController) CreateOrUpdateEmailOtpHelper(ctx context.Context, request dbLogin.CreateEmailOtpRequest) (*dbLogin.EmailOtp, error) {

	createEmailOtp := dbLogin.CreateEmailOtpRequest{
		UserId:    request.UserId,
		Email:     request.Email,
		OtpHash:   request.OtpHash,
		ResendOtp: request.ResendOtp,
		Attempts:  request.Attempts,
		ExpiresAt: request.ExpiresAt,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	result, err := c.db.CreateOrUpdateEmailOtp(ctx, createEmailOtp)
	if err != nil {
		logger.Error(ctx, "failed to create otp", zap.Error(err))
		return nil, fmt.Errorf("failed to create otp: %w", err)
	}

	return result, nil
}

func (c *loginController) VerifyOtpHelper(ctx context.Context, mobile string, hashOtp string) error {

	request := dbLogin.CreateOtpRequest{
		Mobile: mobile,
	}
	resp, err := c.db.GetOtp(ctx, request)
	if err != nil {
		logger.Error(ctx, "failed to fetch otp details", zap.Error(err))
		return fmt.Errorf("failed to fetch otp details: %w", err)
	}

	if resp.Attempts == constants.MAXINVALIDATTEMPTS {
		logger.Error(ctx, "max invalid otp attempt reached")
		return ErrMaxOtpAttempts
	}

	_, err = c.db.VerifyOtp(ctx, mobile, hashOtp, resp.Attempts)
	if err != nil {
		logger.Error(ctx, "invalid otp db", zap.Error(err))
		return fmt.Errorf("invalid otp db: %w", err)
	}
	// update invalid otp attempt and restrict after 10th attempt.

	return nil
}

func (c *loginController) verifyEmailOTPHelper(ctx context.Context, email string, hashOtp string, userId int64) error {
	request := dbLogin.CreateEmailOtpRequest{
		Email:  email,
		UserId: int(userId),
	}
	resp, err := c.db.GetEmailOtp(ctx, request)
	if err != nil {
		logger.Error(ctx, "failed to fetch otp details", zap.Error(err))
		return fmt.Errorf("failed to fetch otp details: %w", err)
	}

	if resp.Attempts == constants.MAXINVALIDATTEMPTS {
		logger.Error(ctx, "max invalid otp attempt reached")
		return ErrMaxOtpAttempts
	}

	_, err = c.db.VerifyEmailOtp(ctx, email, hashOtp, resp.Attempts, userId)
	if err != nil {
		logger.Error(ctx, "invalid otp db", zap.Error(err))
		return fmt.Errorf("invalid otp db: %w", err)
	}
	// update invalid otp attempt and restrict after 10th attempt.

	return nil
}

func (c *loginController) sendOTPHelper(ctx context.Context, mobile string, otp string) error {
	msgContent := fmt.Sprintf("Your OTP to login to ICICI Direct iLearn app is %v. It is valid for next 5 mins.", otp)
	msgContent += " Do not share this OTP with anyone for security reasons."

	u, err := url.Parse(constants.AXIOM_BASE_URL)
	if err != nil {
		logger.Error(ctx, "invalid axiom base URL", zap.Error(err))
		return fmt.Errorf("invalid axiom base URL: %w", err)
	}

	q := u.Query()
	q.Set("dcode", constants.DCODE)
	q.Set("subuid", constants.SubUID)
	q.Set("pwd", constants.Pwd)
	q.Set("from", constants.From)
	q.Set("to", mobile)
	q.Set("msgtxt", msgContent)
	q.Set("intflag", constants.IntFlag)
	q.Set("msgtype", constants.MsgType)
	q.Set("otpflag", constants.OTPFlag)
	q.Set("ctype", constants.CType)
	q.Set("langid", constants.LangID)

	u.RawQuery = q.Encode()
	requestURL := u.String()

	log.Printf("[AxiomSmsService] REQUEST URL = %s", requestURL)

	resp, err := http.Get(requestURL)
	if err != nil {
		logger.Error(ctx, "axiom SMS request failed", zap.Error(err), zap.Any("error", err))
		return fmt.Errorf("axiom SMS request failed: %w", err)
	}
	defer resp.Body.Close()

	// Read response body
	body := make([]byte, 0)
	buf := make([]byte, 4096)

	for {
		n, err := resp.Body.Read(buf)
		if n > 0 {
			body = append(body, buf[:n]...)
		}
		if err != nil {
			break
		}
	}

	log.Printf("[AxiomSmsService] status=%d body=%s", resp.StatusCode, string(body))

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf(
			"axiom SMS request returned status %d: %s",
			resp.StatusCode,
			string(body),
		)
	}

	return nil
}

func (c *loginController) getUserByUIDHelper(ctx context.Context, uid int64) (*dbModel.Users, error) {

	user, err := c.db.GetUserByUID(ctx, uid)
	if err != nil {
		logger.Error(ctx, "unable to fetch user from db", zap.Error(err))
		return nil, errors.New("unable to fetch user from db")
	}

	return user, nil
}

func (c *loginController) sendEmailOTPHelper(ctx context.Context, email string, otp string, displayName string) error {

	// 1. Define target URL and payload
	url := fmt.Sprintf("%s/send-otp", constants.EMAIL_OTP_URL)

	payload := RequestPayload{
		ToEmail:     email,
		Otp:         otp,
		DisplayName: displayName,
	}

	// 2. Marshal payload to JSON
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, "Failed to marshal JSON", zap.Error(err))
		return err
	}

	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	req, err := http.NewRequest(
		http.MethodPost,
		url,
		bytes.NewBuffer(jsonData),
	)

	if err != nil {
		logger.Error(ctx, "request failed", zap.Error(err))
		return err
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error(ctx, "Failed to send request", zap.Error(err))
		return err
	}
	defer resp.Body.Close()

	_, err = io.ReadAll(resp.Body)
	if err != nil {
		logger.Error(ctx, "Failed to read request body", zap.Error(err))
		return err
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		logger.Error(ctx, "Failed to read request body", zap.Error(err))
		return err
	}

	return nil
}

func (c *loginController) RefreshTokenHelper(ctx context.Context, request RefreshTokenRequest) (*dbLogin.Token, error) {
	token, err := c.db.GetRefreshToken(ctx, request.RefreshToken)
	if err != nil {
		logger.Error(ctx, "failed to fetch token details", zap.Error(err))
		return nil, fmt.Errorf("failed to fetch token details: %w", err)
	}

	if token.RevokedAt != nil {
		logger.Error(ctx, "token revoked", zap.Error(err))
		return nil, fmt.Errorf("token revoked: %w", err)
	}

	if time.Now().After(token.RefreshExpiresAt) {
		logger.Error(ctx, "refresh token expired")
		return nil, fmt.Errorf("refresh token expired: %w", err)
	}

	user, err := c.db.GetUserByUID(ctx, int64(token.UserId))
	if err != nil {
		logger.Error(ctx, "user not found", zap.Error(err))
		return nil, err
	}

	status := constants.UserStatusEnumActive

	if *user.Status != status {
		logger.Error(ctx, "user is not active")
		return nil, fmt.Errorf("user is not active")
	}

	accessToken := c.generateTokenHelper()

	// generate refresh token
	refreshToken := c.generateTokenHelper()

	updateToken := dbLogin.UpdateTokenRequest{
		UserId:           token.UserId,
		Token:            accessToken,
		RefreshToken:     refreshToken,
		ExpiresAt:        time.Now().Add(24 * time.Hour),
		RefreshExpiresAt: time.Now().Add(720 * time.Hour),
		CreatedAt:        time.Now(),
		UpdatedAt:        time.Now(),
	}

	_, err = c.db.UpdateToken(ctx, updateToken, token.UserId, request.RefreshToken)
	if err != nil {
		logger.Error(ctx, "failed to update token", zap.Error(err))
		return nil, err
	}

	resp := dbLogin.Token{
		RefreshToken:     refreshToken,
		Token:            accessToken,
		RefreshExpiresAt: updateToken.RefreshExpiresAt,
		ExpiresAt:        updateToken.ExpiresAt,
	}

	return &resp, nil
}

func (c *loginController) getCustomerDetailsHelper(ctx context.Context, requestToken string) (*CustomerDetailsResponse, error) {

	timeStamp := time.Now().Format("02-Jan-2006 15:04:05")

	jsonPostData := CustomerDetailsRequest{
		APISession: requestToken,
		AppKey:     constants.API_KEY,
	}

	jsonPostDataBytes, err := json.Marshal(jsonPostData)
	if err != nil {
		logger.Error(ctx, "failed to marshal data", zap.Error(err))
		return nil, err
	}

	jsonPostDataString := string(jsonPostDataBytes)

	checksumInput := timeStamp + jsonPostDataString + constants.API_SECRET

	hash := sha256.Sum256([]byte(checksumInput))

	checksum := hex.EncodeToString(hash[:])

	payload := CustomerDetailsPayload{
		AppKey:       constants.API_KEY,
		TimeStamp:    timeStamp,
		JSONPostData: jsonPostDataString,
		Checksum:     checksum,
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, "failed to marshal payload", zap.Error(err))
		return nil, err
	}

	req, err := http.NewRequest(http.MethodPost, constants.API_ICICI_DIRECT_URL+"/customer/customerdetails/v1", bytes.NewBuffer(payloadBytes))
	if err != nil {
		logger.Error(ctx, "failed customer details request", zap.Error(err))
		return nil, err
	}

	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Error(ctx, "error connecting to ICICI Server", zap.Error(err))
		return nil, errors.New("error connecting to ICICI Server")
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		logger.Error(ctx, "icici customer details returned status", zap.Error(err))
		return nil, fmt.Errorf("icici customer details returned status %d", resp.StatusCode)
	}

	var result CustomerDetailsResponse

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		logger.Error(ctx, "failed to decode customer details response", zap.Error(err))
		return nil, err
	}

	if result.Status != 200 {
		fmt.Println("status--->", result.Status)
		logger.Error(ctx, "ICICI customer details failed", zap.Error(err))
		return nil, errors.New("ICICI customer details failed")
	}

	return &result, nil
}

func (c *loginController) createIdirectUserHelper(ctx context.Context, customer CustomerDetailsSuccess) (*dbModel.Users, error) {
	activeStatus := constants.UserStatusEnumActive
	username, err := c.generateUsernameHelper("ilearn", 4)
	if err != nil {
		logger.Error(ctx, "failed to generate username", zap.Error(err))
		return nil, errors.New("failed to generate username")
	}
	firstName, remainder, _ := strings.Cut(customer.IDirectUserName, " ")

	firstAccess := time.Now()
	// viaLogin := "idirect"
	ilearnNew := "ilearn_new"

	createUsersRequest := CreateUsersRequest{
		DisplayName: &customer.IDirectUserName,
		Username:    &username,
		FirstName:   &firstName,
		LastName:    &remainder,
		Mobile:      &customer.MobileNo,
		Status:      &activeStatus,
		FirstAccess: &firstAccess,
		// ViaLogin:        &viaLogin,
		IdirectUsername: &customer.IDirectUserID,
		AccountSource:   &ilearnNew,
	}

	user, err := c.createUsersHelper(ctx, createUsersRequest)
	if err != nil {
		logger.Error(ctx, "failed to create otp", zap.Error(err))
		return nil, fmt.Errorf("failed to create otp: %w", err)
	}

	return user, nil

}

func (c *loginController) getUserByIDirectUsernameHelper(ctx context.Context, customer CustomerDetailsSuccess) (*dbModel.Users, error) {
	user, err := c.db.GetUserByIDirectUsername(ctx, customer.IDirectUserID)
	if err != nil {
		logger.Error(ctx, "user not found", zap.Error(err))
		return nil, fmt.Errorf("user not found: %w", err)
	}
	return user, nil
}

func (c *loginController) decryptAES256ECB(inputBase64, secretKey string) (string, error) {
	key := []byte(secretKey)

	// AES-256 requires a 32-byte key
	if len(key) != 32 {
		return "", fmt.Errorf(
			"secret key must be exactly 32 bytes, got %d",
			len(key),
		)
	}

	// Base64 decode
	encrypted, err := base64.StdEncoding.DecodeString(inputBase64)
	if err != nil {
		return "", fmt.Errorf("invalid base64 input: %w", err)
	}

	// AES block size is 16 bytes
	if len(encrypted) == 0 || len(encrypted)%aes.BlockSize != 0 {
		return "", errors.New(
			"encrypted data is not a multiple of 16 bytes",
		)
	}

	// AES-256
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", fmt.Errorf("failed to create AES cipher: %w", err)
	}

	// ECB decryption
	decrypted := make([]byte, len(encrypted))

	for i := 0; i < len(encrypted); i += aes.BlockSize {
		block.Decrypt(
			decrypted[i:i+aes.BlockSize],
			encrypted[i:i+aes.BlockSize],
		)
	}

	// Java AES uses PKCS5Padding
	decrypted, err = c.pkcs5Unpad(decrypted)
	if err != nil {
		return "", fmt.Errorf("invalid padding: %w", err)
	}

	return string(decrypted), nil
}

func (c *loginController) pkcs5Unpad(data []byte) ([]byte, error) {
	if len(data) == 0 {
		return nil, errors.New("empty decrypted data")
	}

	padding := int(data[len(data)-1])

	if padding < 1 || padding > aes.BlockSize {
		return nil, errors.New("invalid padding value")
	}

	if padding > len(data) {
		return nil, errors.New("invalid padding length")
	}

	for _, b := range data[len(data)-padding:] {
		if int(b) != padding {
			return nil, errors.New("invalid padding bytes")
		}
	}

	return data[:len(data)-padding], nil
}

func (c *loginController) findOrCreateTokenHelper(ctx context.Context, userid int) (*dbLogin.Token, error) {
	// generate access token
	token := c.generateTokenHelper()

	// generate refresh token
	refreshToken := c.generateTokenHelper()

	formattedExpiresAt :=
		time.Now().Add(24 * time.Hour)
		//Format("2006-01-02T15:04:05.999Z")

	createToken := dbLogin.CreateTokenRequest{
		UserId:           userid,
		Token:            token,
		RefreshToken:     refreshToken,
		ExpiresAt:        formattedExpiresAt,
		RefreshExpiresAt: time.Now().Add(720 * time.Hour),
		CreatedAt:        time.Now(),
		UpdatedAt:        time.Now(),
	}

	result, err := c.db.FindOrCreateToken(ctx, createToken, userid)
	if err != nil {
		logger.Error(ctx, "failed to create otp", zap.Error(err))
		return nil, fmt.Errorf("failed to create otp: %w", err)
	}

	return result, nil
}

func (c *loginController) updateIdirectUsernameHelper(ctx context.Context, userid int64, idirectusername string) (*dbModel.Users, error) {
	user, err := c.db.UpdateIdirectUsernameByMobile(ctx, userid, idirectusername)
	if err != nil {
		logger.Error(ctx, "failed to update idirectusername helper", zap.Error(err))
		return nil, fmt.Errorf("failed to update idirectusername: %w", err)
	}
	return user, nil
}

const charset = "abcdefghijklmnopqrstuvwxyz0123456789"

// GenerateUsername creates a random username with a prefix and specified length
func (c *loginController) generateUsernameHelper(prefix string, length int) (string, error) {
	b := make([]byte, length)
	for i := range b {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(charset))))
		if err != nil {
			return "", err
		}
		b[i] = charset[num.Int64()]
	}
	return prefix + string(b), nil
}

func (c *loginController) validMobileHelper(mobile string) bool {
	re := regexp.MustCompile(`^91\s[6-9]\d{9}$`)
	return re.MatchString(mobile)
}

func (c *loginController) isHUFAccount(users []dbModel.Users) bool {
	count := 0
	for _, user := range users {
		if user.IdirectUsername != nil && strings.TrimSpace(*user.IdirectUsername) != "" {
			count++
		}

		if count >= 2 {
			return true
		}
	}
	return false
}

// isEmailValid checks if the email provided is valid by regex.
func (c *loginController) isEmailValid(e string) bool {
	emailRegex := regexp.MustCompile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")
	return emailRegex.MatchString(e)
}

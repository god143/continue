package login

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type loginController struct {
	db db.DBLayer
}

type LoginControllerGroup interface {
	Login(ctx *gin.Context)
	Verify(ctx *gin.Context)
	ResendOtp(ctx *gin.Context)
	Logout(ctx *gin.Context)
	RefreshToken(ctx *gin.Context)
	IDirectCallback(ctx *gin.Context)
	IDirectLogin(ctx *gin.Context)
	SendEmailOtp(ctx *gin.Context)
	VerifyEmailOtp(ctx *gin.Context)
	ResendEmailOtp(ctx *gin.Context)
}

func NewLoginGroup(db db.DBLayer) LoginControllerGroup {
	return &loginController{
		db: db,
	}
}

package tags

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type tagsController struct {
	db db.DBLayer
}

type TagsControllerGroup interface {
	GetTag(ctx *gin.Context)
}

func NewTagsControllerGroup(db db.DBLayer) TagsControllerGroup {
	return &tagsController{
		db: db,
	}
}

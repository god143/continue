package tags

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/tags"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- POINTER HELPERS (Required to fix compiler errors) ---
func ptrInt64(i int64) *int64    { return &i }
func ptrString(s string) *string { return &s }

// --- MOCK DEFINITION ---
type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetTag(ctx context.Context) ([]dbModel.Tags, error) {
	args := m.Called(ctx)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.Tags), args.Error(1)
}

// --- UNIT TESTS ---
func TestGetTag(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name           string
		setupMock      func(*MockDB)
		expectedStatus int
	}{
		{
			name: "Happy Path - Success 200",
			setupMock: func(m *MockDB) {
				m.On("GetTag", mock.Anything).
					Return([]dbModel.Tags{
						{
							ID:  ptrInt64(1),           // Fixes *int64 error
							Key: ptrString("Trending"), // Fixes *string error
						},
					}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Database Error - Failure 500",
			setupMock: func(m *MockDB) {
				m.On("GetTag", mock.Anything).
					Return(nil, errors.New("unable to fetch tags in database"))
			},
			expectedStatus: http.StatusInternalServerError,
		},

		{
			name: "Edge Case - Empty Database",
			setupMock: func(m *MockDB) {
				// Tests that 200 OK is returned even if no tags exist
				m.On("GetTag", mock.Anything).Return([]dbModel.Tags{}, nil)
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "Edge Case - Nil Result",
			setupMock: func(m *MockDB) {
				// Tests robustness if the DB driver returns a nil slice without an error
				m.On("GetTag", mock.Anything).Return(nil, nil)
			},
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mDB := new(MockDB)
			ctrl := &tagsController{db: mDB}

			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request, _ = http.NewRequest("GET", "/tags", nil)

			tt.setupMock(mDB)
			ctrl.GetTag(c)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// --- BENCHMARK ---
func BenchmarkGetTag(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	mDB.On("GetTag", mock.Anything).Return([]dbModel.Tags{}, nil)
	ctrl := &tagsController{db: mDB}

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request, _ = http.NewRequest("GET", "/tags", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetTag(c)
	}
}

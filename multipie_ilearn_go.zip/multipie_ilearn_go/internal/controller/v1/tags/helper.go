package tags

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

/*
getTagHelper gives all tags name from tags table
*/
func (c *tagsController) getTagHelper(ctx context.Context) ([]dbModel.Tags, error) {

	tags, err := c.db.GetTag(ctx)
	if err != nil {
		logger.Error(ctx, "unable to fetch tags in database", zap.Error(err), zap.Any("tags not found", tags))
		return nil, errors.New("unable to fetch tags in database")
	}
	return tags, err
}

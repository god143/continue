package tags

import (
	"multipie_ilearn_go/internal/logger"
	"os"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestMain(m *testing.M) {
	// Initialize the logger exactly like app.Run does
	// We use "test" environment and "error" level to keep logs clean
	_ = logger.NewLogger("test", "error", "")

	// Set Gin to Test Mode for the whole package
	gin.SetMode(gin.TestMode)

	os.Exit(m.Run())
}

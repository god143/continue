package tags

import (
	dbModel "multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

func (c *tagsController) GetTag(ctx *gin.Context) {
	var (
		resp        *utils.Response
		getTagsResp []dbModel.Tags
	)

	getTagsResp, err := c.getTagHelper(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getTagsResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

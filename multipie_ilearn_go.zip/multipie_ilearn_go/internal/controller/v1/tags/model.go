package tags

type TagsResult struct {
	ID  *int64  `json:"id"`
	Key *string `json:"key"`
}

// get list of all tags
type GetTagListResponse struct {
	Key *string `json:"key"`
}

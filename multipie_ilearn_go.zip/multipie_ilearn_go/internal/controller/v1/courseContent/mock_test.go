package mdlcoursecontent

import (
	"context"
	"errors"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/courseContent"
	"multipie_ilearn_go/internal/logger"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mocks ---
type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDBLayer) GetCourseContent(ctx context.Context, course int64) ([]dbModel.MdlCourseContent, error) {
	args := m.Called(ctx, course)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.MdlCourseContent), args.Error(1)
}
func TestCertificateController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
}

// --- Unit Tests ---

func TestGetCourseContentHandler(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Run("Success - Content Found", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCourseContentControllerGroup(mockDB)

		expectedData := []dbModel.MdlCourseContent{
			{ID: 1, Course: 101, Name: "Intro to Go"},
		}

		mockDB.On("GetCourseContent", mock.Anything, int64(101)).Return(expectedData, nil)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{{Key: "course", Value: "101"}}

		controller.GetCourseContentHandler(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		mockDB.AssertExpectations(t)
	})

	t.Run("Failure - Invalid ID Format", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCourseContentControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{{Key: "course", Value: "abc"}}
		controller.GetCourseContentHandler(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Database Error", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCourseContentControllerGroup(mockDB)

		mockDB.On("GetCourseContent", mock.Anything, int64(101)).Return(nil, errors.New("db error"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{{Key: "course", Value: "101"}}

		controller.GetCourseContentHandler(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

// --- Benchmarks ---

func BenchmarkGetCourseContentHandler(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mockDB := new(MockDBLayer)
	controller := NewCourseContentControllerGroup(mockDB)

	dummyData := []dbModel.MdlCourseContent{{ID: 1, Course: 101, Name: "Benchmark"}}
	mockDB.On("GetCourseContent", mock.Anything, mock.Anything).Return(dummyData, nil)

	// Pre-setup the context to avoid measuring overhead
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Params = []gin.Param{{Key: "course", Value: "101"}}

	b.ResetTimer() // Start measuring here
	for i := 0; i < b.N; i++ {
		controller.GetCourseContentHandler(ctx)
	}
}

package mdlcoursecontent

import (
	"context"
	dbModel "multipie_ilearn_go/internal/db/courseContent"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

func (c *courseContentController) getCourseContentHelper(ctx context.Context, course int64) ([]dbModel.MdlCourseContent, error) {

	contentData, err := c.db.GetCourseContent(ctx, course)
	if err != nil {
		logger.Error(ctx, "Error fetching course content", zap.Error(err), zap.Int64("courseID", course))
		return contentData, err
	}

	return contentData, nil
}

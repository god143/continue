package mdlcoursecontent

type CourseParam struct {
	CourseID int64 `uri:"course" binding:"required"`
}

package mdlcoursecontent

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *courseContentController) GetCourseContentHandler(ctx *gin.Context) {
	var params CourseParam

	if err := ctx.ShouldBindUri(&params); err != nil {
		logger.Error(ctx, "Invalid parameters", zap.Error(err))
		resp := utils.NewV1Response(nil, utils.StringToPointer("Invalid course ID format"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	contentResp, err := c.getCourseContentHelper(ctx, params.CourseID)
	if err != nil {
		logger.Error(ctx, "Unable to fetch course content", zap.Error(err), zap.Int64("courseID", params.CourseID))
		resp := utils.NewV1Response(nil, utils.StringToPointer("Unable to fetch course content"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	ctx.JSON(http.StatusOK, utils.NewV1Response(contentResp, nil))
}

package mdlcoursecontent

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type courseContentController struct {
	db db.DBLayer
}

type CourseContentControllerGroup interface {
	GetCourseContentHandler(ctx *gin.Context)
}

func NewCourseContentControllerGroup(db db.DBLayer) CourseContentControllerGroup {
	return &courseContentController{
		db: db,
	}
}

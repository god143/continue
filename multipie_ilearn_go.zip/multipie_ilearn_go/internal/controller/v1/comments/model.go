package comments

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type CreateCommentRequest struct {
	Content   *string                          `json:"content" binding:"required"`
	ModelType *constants.CommentsModelTypeEnum `json:"model_type" binding:"required"`
	ModelID   *int64                           `json:"model_id" binding:"required"`
}

type GetCommentRequest struct {
	ModelType string `form:"model_type" binding:"required"`
	ModelID   int64  `form:"model_id" binding:"required"`
}

type CommentWithUserAndLikes struct {
	CommentID  *int64                           `json:"comment_id"`
	UserID     *int64                           `json:"user_id"`
	Username   *string                          `json:"username"`
	FirstName  *string                          `json:"first_name"`
	LastName   *string                          `json:"last_name"`
	Content    *string                          `json:"content"`
	ParentID   *int64                           `json:"parent_id"`
	ModelType  *constants.CommentsModelTypeEnum `json:"model_type"`
	ModelID    *int64                           `json:"model_id"`
	Visible    *bool                            `json:"visible"`
	LikesCount *int64                           `json:"likes_count"`
	PictureURL *string                          `json:"picture_url"`
	CreatedAt  *time.Time                       `json:"created_at"`
	UpdatedAt  *time.Time                       `json:"updated_at"`
}

type CommentWithRepliesAndUser struct {
	Comment CommentWithUserAndLikes   `json:"comment"`
	Replies []CommentWithUserAndLikes `json:"replies"`
}

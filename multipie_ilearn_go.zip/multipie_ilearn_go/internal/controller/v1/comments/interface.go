package comments

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type commentController struct {
	db db.DBLayer
}

type CommentControllerGroup interface {
	CreateComment(ctx *gin.Context)
	GetComments(ctx *gin.Context)
}

func NewCommentControllerGroup(db db.DBLayer) CommentControllerGroup {
	return &commentController{
		db: db,
	}
}

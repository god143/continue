package comments

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/comments"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// --- Mocks ---

type MockDBLayer struct {
	mock.Mock
	db.DBLayer
}

// Mocking required DBLayer methods for comments
func (m *MockDBLayer) CreateComment(ctx context.Context, comment *dbModel.Comment) (*dbModel.Comment, error) {
	args := m.Called(ctx, comment)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Comment), args.Error(1)
}

func (m *MockDBLayer) GetCommentsByModelAndID(ctx context.Context, modelType string, modelID int64, userID *int64, visible *bool) ([]dbModel.CommentWithUser, error) {
	args := m.Called(ctx, modelType, modelID, userID, visible)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]dbModel.CommentWithUser), args.Error(1)
}

// --- Test Setup ---

func TestMain(m *testing.M) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)
	// Initialize logger to prevent nil pointer dereference during tests
	// logger.InitLogger() // Uncomment if your logger needs explicit init
	os.Exit(m.Run())
}

// --- Unit Tests ---

func TestCreateComment(t *testing.T) {
	t.Run("Success", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCommentControllerGroup(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Set("userId", int64(1))
		content := "Great course!"

		// Use the generated constant from your package
		// Usually named like: constants.CommentsModelTypeEnumCourseModule
		mType := constants.CommentsModelTypeEnum(2) // 2 corresponds to course_module in your list
		mID := int64(100)

		reqBody := CreateCommentRequest{
			Content:   &content,
			ModelType: &mType,
			ModelID:   &mID,
		}
		jsonBytes, _ := json.Marshal(reqBody)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jsonBytes))
		ctx.Request.Header.Set("Content-Type", "application/json")

		// Mock Expectation
		mockDB.On("CreateComment", mock.Anything, mock.Anything).Return(&dbModel.Comment{ID: utils.Int64ToPointer(1)}, nil)

		controller.CreateComment(ctx)

		assert.Equal(t, http.StatusCreated, w.Code)
	})

	t.Run("Unauthorized", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCommentControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// No userId set in context
		controller.CreateComment(ctx)
		assert.Equal(t, http.StatusUnauthorized, w.Code)
	})
}

func TestGetComments(t *testing.T) {
	t.Run("Success with Nested Replies", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCommentControllerGroup(mockDB)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// Setup Query Params
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

		now := time.Now()
		parentID := int64(1)
		childID := int64(2)

		// Mock Data representing a flat list from DB
		mockData := []dbModel.CommentWithUser{
			{ID: &parentID, Content: utils.StringToPointer("Parent"), CreatedAt: &now, ParentID: nil},
			{ID: &childID, Content: utils.StringToPointer("Reply"), CreatedAt: &now, ParentID: &parentID},
		}

		mockDB.On("GetCommentsByModelAndID", mock.Anything, "course", int64(100), mock.Anything, mock.Anything).Return(mockData, nil)

		controller.GetComments(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		// Verify helper logic nested the reply
		var response utils.Response
		json.Unmarshal(w.Body.Bytes(), &response)
		// Logic check: length should be 1 (the parent) because reply is nested inside it
		assert.NotNil(t, response.Data)
	})

	t.Run("DB Error", func(t *testing.T) {
		mockDB := new(MockDBLayer)
		controller := NewCommentControllerGroup(mockDB)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

		mockDB.On("GetCommentsByModelAndID", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("db error"))

		controller.GetComments(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}
func TestCommentEdgeCases(t *testing.T) {
	mockDB := new(MockDBLayer)
	controller := NewCommentControllerGroup(mockDB)

	t.Run("Failure - Create - Invalid JSON Body", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// Sending malformed JSON to trigger ShouldBindJSON error
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{"content": 123}`)))

		controller.CreateComment(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - Get - Invalid Query Params", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		// Missing required model_id to trigger ShouldBindQuery error
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course", nil)

		controller.GetComments(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Success - Nested Replies Deep Sorting", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))
		ctx.Request, _ = http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

		pID := int64(1)
		oldTime := time.Now().Add(-1 * time.Hour)
		newTime := time.Now()
		mType := constants.CommentsModelTypeEnum(2)

		// Test data to trigger all sorting lines:
		// 2 Parents (Old and New) and 2 Replies for one parent (Old and New)
		mockData := []dbModel.CommentWithUser{
			{ID: &pID, CreatedAt: &oldTime, Content: utils.StringToPointer("Old Parent"), ModelType: &mType},
			{ID: utils.Int64ToPointer(2), CreatedAt: &newTime, Content: utils.StringToPointer("New Parent"), ModelType: &mType},
			{ID: utils.Int64ToPointer(3), CreatedAt: &oldTime, ParentID: &pID, Content: utils.StringToPointer("Old Reply"), ModelType: &mType},
			{ID: utils.Int64ToPointer(4), CreatedAt: &newTime, ParentID: &pID, Content: utils.StringToPointer("New Reply"), ModelType: &mType},
		}

		mockDB.On("GetCommentsByModelAndID", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(mockData, nil).Once()

		controller.GetComments(ctx)
		assert.Equal(t, http.StatusOK, w.Code)

		// This triggers both:
		// 1. sort.Slice(parentComments...)
		// 2. sort.Slice(parentComments[i].Replies...)
	})

	t.Run("Failure - Create Helper DB Error", func(t *testing.T) {
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Set("userId", int64(1))

		mType := constants.CommentsModelTypeEnum(2)
		mID := int64(100)
		reqBody := CreateCommentRequest{
			Content: utils.StringToPointer("Test"), ModelType: &mType, ModelID: &mID,
		}
		jb, _ := json.Marshal(reqBody)
		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))

		mockDB.On("CreateComment", mock.Anything, mock.Anything).Return(nil, errors.New("insert failed")).Once()

		controller.CreateComment(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

// --- Benchmarks ---

func BenchmarkGetComments_Optimized(b *testing.B) {
	mockDB := new(MockDBLayer)
	controller := NewCommentControllerGroup(mockDB)

	now := time.Now()
	mType := constants.CommentsModelTypeEnum(2)
	mockData := []dbModel.CommentWithUser{
		{ID: utils.Int64ToPointer(1), Content: utils.StringToPointer("B"), CreatedAt: &now, ModelType: &mType},
	}
	mockDB.On("GetCommentsByModelAndID", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return(mockData, nil)

	// Reuse Request and Recorder to minimize overhead
	w := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(w)
	ctx.Set("userId", int64(1))
	req, _ := http.NewRequest("GET", "/?model_type=course&model_id=100", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctx.Request = req // Reuse the request
		controller.GetComments(ctx)
	}
}

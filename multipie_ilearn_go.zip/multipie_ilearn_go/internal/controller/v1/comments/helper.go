package comments

import (
	"fmt"
	dbModel "multipie_ilearn_go/internal/db/comments"
	"multipie_ilearn_go/internal/utils"
	"sort"
	"time"

	"github.com/gin-gonic/gin"
)

func (c *commentController) createCommentHelper(ctx *gin.Context, request CreateCommentRequest, userID int64) (dbModel.Comment, error) {
	var newComment dbModel.Comment

	newComment.UserID = &userID
	newComment.Content = request.Content
	newComment.ParentID = nil
	newComment.ModelType = request.ModelType
	newComment.ModelID = request.ModelID
	newComment.Visible = utils.BoolToPointer(true)

	hasCommented, err := c.db.HasCommented(ctx, request.ModelType.String(), *request.ModelID, &userID, newComment.Visible, time.Hour)
	if err != nil {
		return dbModel.Comment{}, err
	}

	if hasCommented {
		return dbModel.Comment{}, fmt.Errorf("limit reached")
	}

	createdComment, err := c.db.CreateComment(ctx, &newComment)
	if err != nil {
		return dbModel.Comment{}, err
	}

	return *createdComment, nil
}

func (c *commentController) getCommentsHelper(ctx *gin.Context, modelType string, modelID int64, userID int64) ([]dbModel.CommentWithReplies, error) {

	comments, err := c.db.GetCommentsByModelAndID(ctx, modelType, modelID, &userID, utils.BoolToPointer(true))
	if err != nil {
		return nil, err
	}

	commentMap := make(map[int64]*dbModel.CommentWithReplies)
	var parentComments []dbModel.CommentWithReplies

	for i := 0; i < len(comments); i++ {
		comment := comments[i]

		commentWithReplies := &dbModel.CommentWithReplies{
			Comment: dbModel.CommentWithUser{
				ID:         comment.ID,
				UserID:     comment.UserID,
				Username:   comment.Username,
				FirstName:  comment.FirstName,
				LastName:   comment.LastName,
				PictureURL: comment.PictureURL,
				Content:    comment.Content,
				ParentID:   comment.ParentID,
				ModelType:  comment.ModelType,
				ModelID:    comment.ModelID,
				Visible:    comment.Visible,
				LikesCount: comment.LikesCount,
				CreatedAt:  comment.CreatedAt,
				UpdatedAt:  comment.UpdatedAt,
			},
			Replies: []dbModel.CommentWithUser{},
		}

		// Check if it's a parent comment or a reply
		if comment.ParentID == nil {
			// It's a parent comment
			parentComments = append(parentComments, *commentWithReplies)
			commentMap[*comment.ID] = &parentComments[len(parentComments)-1]
		} else {
			// It's a reply, find the parent and attach it
			if parent, exists := commentMap[*comment.ParentID]; exists {
				parent.Replies = append(parent.Replies, commentWithReplies.Comment)
			}
		}
	}

	sort.Slice(parentComments, func(i, j int) bool {
		return parentComments[i].Comment.CreatedAt.After(*parentComments[j].Comment.CreatedAt)
	})

	for i := range parentComments {
		sort.Slice(parentComments[i].Replies, func(a, b int) bool {
			return parentComments[i].Replies[a].CreatedAt.After(*parentComments[i].Replies[b].CreatedAt)
		})
	}

	return parentComments, nil
}

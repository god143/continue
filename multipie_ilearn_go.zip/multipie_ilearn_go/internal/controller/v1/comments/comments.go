package comments

import (
	dbModel "multipie_ilearn_go/internal/db/comments"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *commentController) CreateComment(ctx *gin.Context) {
	var (
		resp           *utils.Response
		request        CreateCommentRequest
		createdComment dbModel.Comment
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	createdComment, err = c.createCommentHelper(ctx, request, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to create comment: "+err.Error()))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(createdComment, nil)
	ctx.JSON(http.StatusCreated, resp)
}

func (c *commentController) GetComments(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCommentRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		logger.Error(ctx, "unauthorized", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized: "+err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid query parameters", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid query parameters"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	comments, err := c.getCommentsHelper(ctx, request.ModelType, request.ModelID, userID)
	if err != nil {
		logger.Error(ctx, "failed to fetch comments", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("failed to fetch comments"))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(comments, nil)
	ctx.JSON(http.StatusOK, resp)
}

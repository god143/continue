package quizAttempts

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type quizAttemptsController struct {
	db db.DBLayer
}

type QuizAttemptsControllerLayer interface {
	CreateQuizAttempt(ctx *gin.Context)
	UpdateQuizAttempt(ctx *gin.Context)
	GetQuizScore(ctx *gin.Context)
	GetQuizAttempts(ctx *gin.Context)
}

func NewQuizAttemptsControllerLayer(db db.DBLayer) QuizAttemptsControllerLayer {
	return &quizAttemptsController{
		db: db,
	}
}

package quizAttempts

import (
	"context"
	"errors"
	"time"

	"multipie_ilearn_go/internal/constants"
	dbModelQuestions "multipie_ilearn_go/internal/db/question"
	dbModel "multipie_ilearn_go/internal/db/quizAttempts"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
)

func (c *quizAttemptsController) fetchQuestionsFromDB(ctx context.Context, quizId int64, numOfQuestions int64) ([]dbModelQuestions.Question, error) {
	question, err := c.db.GetQuestionsByQuizId(ctx, quizId, &numOfQuestions)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database", zap.Error(err))
		return nil, err
	}
	return question, nil
}

func (c *quizAttemptsController) createQuizAttemptHelper(ctx context.Context, userID int64, request CreateQuizAttemptRequest) (*dbModel.QuizAttempts, error) {
	// fetch correct answer for list of questions in request.
	quiz, err := c.db.GetQuizById(ctx, *request.QuizID, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database", zap.Error(err), zap.Int64("ID", *request.QuizID))
		return nil, err
	}

	questions, err := c.fetchQuestionsFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database", zap.Error(err), zap.Int64("ID", *request.QuizID))
		return nil, err
	}

	correctAnswerCount := 0

	answerMap := make(map[int64]string)
	for _, question := range request.Questions {
		answerMap[*question.ID] = question.Option
	}

	for _, res := range questions {
		if answerMap[*res.ID] == *res.CorrectAnswer {
			correctAnswerCount++
		}
	}

	now := time.Now()
	hasChecked := false
	attemptNum := int64(1)

	quizAttempt := &dbModel.QuizAttempts{
		UserId:           &userID,
		QuizId:           request.QuizID,
		AttemptNumber:    &attemptNum,
		LastAttemptAt:    &now,
		HasCheckedAnswer: &hasChecked,
	}

	numOfQuestions := quiz.NumQuestions
	calculatedScore := float64(correctAnswerCount) / float64(*numOfQuestions) * 100
	if calculatedScore >= float64(*quiz.PassPercentage) {
		status := constants.QuizAttemptsStatusEnumPass
		quizAttempt.Status = &status
	} else {
		status := constants.QuizAttemptsStatusEnumFail
		quizAttempt.Status = &status
	}

	quizAttempt.Score = &calculatedScore

	createdAttempt, err := c.db.CreateQuizAttempt(ctx, quizAttempt)
	if err != nil {
		logger.Error(ctx, "unable to create quiz attempt", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("quiz attempt creation failed")
	}
	return createdAttempt, nil
}

func (c *quizAttemptsController) updateQuizAttemptHelper(ctx context.Context, userID int64, request UpdateQuizAttemptRequest) (*dbModel.QuizAttempts, error) {
	quiz, err := c.db.GetQuizById(ctx, *request.QuizId, utils.BoolToPointer(true))
	if err != nil {
		logger.Error(ctx, "error fetching quiz from database", zap.Error(err), zap.Int64("ID", *request.QuizId))
		return nil, err
	}

	questions, err := c.fetchQuestionsFromDB(ctx, *quiz.ID, *quiz.NumQuestions)
	if err != nil {
		logger.Error(ctx, "error fetching questions from database", zap.Error(err), zap.Int64("ID", *request.QuizId))
		return nil, err
	}

	correctAnswerCount := 0

	answerMap := make(map[int64]string)
	for _, question := range request.Questions {
		answerMap[*question.ID] = question.Option
	}

	for _, res := range questions {
		if answerMap[*res.ID] == *res.CorrectAnswer {
			correctAnswerCount++
		}
	}

	quizAttempt := dbModel.QuizAttempts{
		ID:               request.ID,
		UserId:           &userID,
		HasCheckedAnswer: request.HasCheckedAnswer,
	}

	numOfQuestions := quiz.NumQuestions
	calculatedScore := float64(correctAnswerCount) / float64(*numOfQuestions) * 100
	if calculatedScore >= float64(*quiz.PassPercentage) {
		status := constants.QuizAttemptsStatusEnumPass
		quizAttempt.Status = &status
	} else {
		status := constants.QuizAttemptsStatusEnumFail
		quizAttempt.Status = &status
	}

	quizAttempt.Score = &calculatedScore

	_, err = c.db.UpdateQuizAttempt(ctx, &quizAttempt)
	if err != nil {
		logger.Error(ctx, "unable to update quiz attempt", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("quiz attempt update failed")
	}

	isSeen := true
	if *request.HasCheckedAnswer == isSeen {
		data, err := c.db.GetQuizAttempts(ctx, userID, *request.QuizId)
		if err != nil {
			logger.Error(ctx, "unable to fetch score from db", zap.Error(err))
			return nil, errors.New("unable to fetch score from db")
		}
		quizAttempt := dbModel.QuizAttempts{
			ID:               request.ID,
			UserId:           &userID,
			HasCheckedAnswer: request.HasCheckedAnswer,
			Score:            data.Score,
			Status:           data.Status,
		}
		return &quizAttempt, nil
	}

	return &quizAttempt, nil
}
func (c *quizAttemptsController) getQuizAttemptsHelper(ctx context.Context, userID int64, request GetQuizAttemptsRequest) (*dbModel.QuizAttempts, error) {
	quizAttempt, err := c.db.GetQuizAttempts(ctx, userID, *request.QuizId)
	if err != nil {
		logger.Error(ctx, "unable to fetch quizAttempt from db", zap.Error(err), zap.Any("quizID", request.QuizId))
		return nil, errors.New("unable to fetch quizAttempt from db")
	}
	return quizAttempt, nil
}

func (c *quizAttemptsController) getQuizScoreHelper(ctx context.Context, userID int64, request GetQuizScoreRequest) (*dbModel.QuizAttempts, error) {
	score, err := c.db.GetQuizScore(ctx, userID, *request.QuizId)
	if err != nil {
		logger.Error(ctx, "unable to fetch score from db", zap.Error(err))
		return score, errors.New("unable to fetch score from db")
	}
	return score, nil
}

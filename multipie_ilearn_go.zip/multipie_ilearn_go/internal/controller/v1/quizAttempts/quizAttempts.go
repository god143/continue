package quizAttempts

import (
	"net/http"

	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// CreateQuizAttempt handles the POST request to create or update a quiz attempt
func (c *quizAttemptsController) CreateQuizAttempt(ctx *gin.Context) {
	var (
		resp     *utils.Response
		request  CreateQuizAttemptRequest
		response CreateQuizAttemptResponse
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}
	quizAttempt, err := c.createQuizAttemptHelper(ctx, userID, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response = CreateQuizAttemptResponse{ID: quizAttempt.ID, Score: quizAttempt.Score, Status: quizAttempt.Status}
	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

// UpdateQuizAttempt handles the PUT request to update quiz attempt status/score
func (c *quizAttemptsController) UpdateQuizAttempt(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request UpdateQuizAttemptRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}
	res, err := c.updateQuizAttemptHelper(ctx, userID, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(res, nil)
	ctx.JSON(http.StatusOK, resp)
}

// GetQuizAttempts returns all attempts for a given quiz and user
func (c *quizAttemptsController) GetQuizAttempts(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetQuizAttemptsRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request uri", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request uri"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	attempt, err := c.getQuizAttemptsHelper(ctx, userID, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response := GetQuizAttemptsResponse{
		QuizID:        attempt.QuizId,
		AttemptNumber: attempt.AttemptNumber,
		Score:         attempt.Score,
		Status:        attempt.Status,
	}

	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

// GetQuizScore returns the most recent quiz score for a given quiz and user
func (c *quizAttemptsController) GetQuizScore(ctx *gin.Context) {
	var (
		resp     *utils.Response
		request  GetQuizScoreRequest
		response GetQuizScoretResponse
	)

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid request uri", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request uri"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		ctx.Abort()
		return
	}

	getQuizScoreResp, err := c.getQuizScoreHelper(ctx, userID, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response = GetQuizScoretResponse{Score: getQuizScoreResp.Score}
	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

package quizAttempts

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type QuizAttemptsResult struct {
	ID            *int64                            `json:"id"`
	UserID        *int64                            `json:"user_id"`
	QuizID        *int64                            `json:"quiz_id"`
	AttemptNumber *int64                            `json:"attempt_number"`
	Score         *float64                          `json:"score"`
	Status        *constants.QuizAttemptsStatusEnum `json:"status"`
	CreatedAt     *time.Time                        `json:"created_at"`
	UpdatedAt     *time.Time                        `json:"updated_at"`
}

type GetQuizScoreRequest struct {
	QuizId *int64 `uri:"quiz_id" binding:"required"`
}

type GetQuizAttemptsRequest struct {
	QuizId *int64 `uri:"quiz_id" binding:"required"`
}

type GetQuizAttemptsResponse struct {
	QuizID        *int64                            `json:"quiz_id"`
	AttemptNumber *int64                            `json:"attempt_number"`
	Score         *float64                          `json:"score"`
	Status        *constants.QuizAttemptsStatusEnum `json:"status"`
}

type GetQuizScoretResponse struct {
	Score *float64 `json:"score"`
}

type CreateQuizAttemptRequest struct {
	QuizID    *int64     `json:"quiz_id" binding:"required"`
	Questions []Question `json:"question" binding:"required"`
}

type CreateQuizAttemptResponse struct {
	ID     *int64                            `json:"quiz_attempt_id"`
	Score  *float64                          `json:"score"`
	Status *constants.QuizAttemptsStatusEnum `json:"status"`
}

type UpdateQuizAttemptRequest struct {
	ID               *int64     `json:"quiz_attempt_id" binding:"required"`
	QuizId           *int64     `json:"quiz_id" binding:"required"`
	HasCheckedAnswer *bool      `json:"has_checked_answer" binding:"required"`
	Questions        []Question `json:"question" binding:"required"`
}

type UpdateQuizAttemptResponse struct {
	UserId        *int64 `json:"user_id"`
	AttemptNumber *int64 `json:"attempt_number"`
}

type Question struct {
	ID        *int64     `json:"id" binding:"required"`
	Option    string     `json:"option" binding:"required"`
	CreatedAt *time.Time `json:"-"`
	UpdatedAt *time.Time `json:"-"`
}

type Answer struct {
	Options *[]string `json:"options"`
}

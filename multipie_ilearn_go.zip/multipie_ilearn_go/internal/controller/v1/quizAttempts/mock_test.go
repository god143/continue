package quizAttempts

// import (
// 	"bytes"
// 	"context"
// 	"encoding/json"
// 	"errors"
// 	"net/http"
// 	"net/http/httptest"
// 	"os"
// 	"testing"

// 	"multipie_ilearn_go/internal/constants"
// 	"multipie_ilearn_go/internal/db"
// 	dbModelCourseContent "multipie_ilearn_go/internal/db/courseContent"
// 	dbModel "multipie_ilearn_go/internal/db/quizAttempts"

// 	"multipie_ilearn_go/internal/logger"
// 	"multipie_ilearn_go/internal/utils"

// 	"github.com/gin-gonic/gin"
// 	"github.com/stretchr/testify/assert"
// 	"github.com/stretchr/testify/mock"
// )

// // --- Mocks ---

// type MockDBLayer struct {
// 	mock.Mock
// 	db.DBLayer
// }

// func (m *MockDBLayer) CreateQuizAttempt(ctx context.Context, qa *dbModel.QuizAttempts) (*dbModel.QuizAttempts, error) {
// 	args := m.Called(ctx, qa)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.QuizAttempts), args.Error(1)
// }

// func (m *MockDBLayer) UpdateQuizAttempt(ctx context.Context, qa *dbModel.QuizAttempts) (*dbModel.QuizAttempts, error) {
// 	args := m.Called(ctx, qa)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.QuizAttempts), args.Error(1)
// }

// func (m *MockDBLayer) GetQuizAttempts(ctx context.Context, uID, qID int64) (*dbModel.QuizAttempts, error) {
// 	args := m.Called(ctx, uID, qID)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.QuizAttempts), args.Error(1)
// }

// func (m *MockDBLayer) GetQuizScore(ctx context.Context, uID, qID int64) (*dbModel.QuizAttempts, error) {
// 	args := m.Called(ctx, uID, qID)
// 	if args.Get(0) == nil {
// 		return nil, args.Error(1)
// 	}
// 	return args.Get(0).(*dbModel.QuizAttempts), args.Error(1)
// }

// // Satisfy global interface requirements
// func (m *MockDBLayer) GetCourseContent(ctx context.Context, id int64) ([]dbModelCourseContent.MdlCourseContent, error) {
// 	return nil, nil
// }

// func float64ToPointer(f float64) *float64 {
// 	return &f
// }

// // --- Test Setup ---
// func TestMain(m *testing.M) {
// 	_ = logger.NewLogger("test", "error", "")
// 	gin.SetMode(gin.TestMode)
// 	os.Exit(m.Run())
// }

// // --- Controller Tests ---
// func TestQuizAttemptsController(t *testing.T) {
// 	mockDB := new(MockDBLayer)
// 	controller := NewQuizAttemptsControllerLayer(mockDB)

// 	t.Run("CreateSuccess", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		status, _ := constants.ParseQuizAttemptsStatusEnum("pass")
// 		req := CreateQuizAttemptRequest{
// 			QuizID: utils.Int64ToPointer(100),
// 			Score:  float64ToPointer(85.5),
// 			Status: &status,
// 		}
// 		jb, _ := json.Marshal(req)
// 		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		mockDB.On("CreateQuizAttempt", mock.Anything, mock.Anything).Return(&dbModel.QuizAttempts{ID: utils.Int64ToPointer(123)}, nil).Once()

// 		controller.CreateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("UpdateSuccess", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		status, _ := constants.ParseQuizAttemptsStatusEnum("fail")
// 		req := UpdateQuizAttemptRequest{
// 			ID:               utils.Int64ToPointer(123),
// 			HasCheckedAnswer: utils.BoolToPointer(true),
// 			Score:            float64ToPointer(85.5),
// 			Status:           &status,
// 		}
// 		jb, _ := json.Marshal(req)
// 		ctx.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(jb))

// 		mockDB.On("UpdateQuizAttempt", mock.Anything, mock.Anything).Return(&dbModel.QuizAttempts{}, nil).Once()

// 		controller.UpdateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("GetAttemptsSuccess", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		mockDB.On("GetQuizAttempts", mock.Anything, int64(1), int64(100)).
// 			Return(&dbModel.QuizAttempts{QuizId: utils.Int64ToPointer(100), AttemptNumber: utils.Int64ToPointer(1)}, nil).Once()

// 		controller.GetQuizAttempts(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("GetScoreSuccess", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		mockDB.On("GetQuizScore", mock.Anything, int64(1), int64(100)).
// 			Return(&dbModel.QuizAttempts{Score: float64ToPointer(95.5)}, nil).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})
// }

// func TestQuizAttemptsEdgeCases(t *testing.T) {
// 	mockDB := new(MockDBLayer)
// 	controller := NewQuizAttemptsControllerLayer(mockDB)

// 	t.Run("AuthFailure", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		// Missing userId
// 		controller.GetQuizAttempts(ctx)
// 		assert.Equal(t, http.StatusUnauthorized, w.Code)
// 	})

// 	t.Run("InvalidUriBinding", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "not-an-int"}}

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})

// 	t.Run("InternalDBError", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		mockDB.On("GetQuizAttempts", mock.Anything, mock.Anything, mock.Anything).
// 			Return(nil, errors.New("query failed")).Once()

// 		controller.GetQuizAttempts(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// }

// func TestQuizAttemptsAdditionalCoverage(t *testing.T) {
// 	mockDB := new(MockDBLayer)
// 	controller := NewQuizAttemptsControllerLayer(mockDB)

// 	t.Run("Create_Binding_Failure", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		// Sending bad JSON (quiz_id should be int, sending string)
// 		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer([]byte(`{"quiz_id": "invalid"}`)))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		controller.CreateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})

// 	t.Run("Update_Binding_Failure", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer([]byte(`{"quiz_attempt_id": "invalid"}`)))

// 		controller.UpdateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})

// 	t.Run("Create_Helper_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		// Valid body but mock a DB failure to hit the helper's error return
// 		status := constants.QuizAttemptsStatusEnum(1)
// 		req := CreateQuizAttemptRequest{QuizID: utils.Int64ToPointer(1), Score: float64ToPointer(50), Status: &status}
// 		jb, _ := json.Marshal(req)
// 		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		mockDB.On("CreateQuizAttempt", mock.Anything, mock.Anything).Return(nil, errors.New("db fail")).Once()

// 		controller.CreateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("Update_Helper_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		status := constants.QuizAttemptsStatusEnum(1)
// 		req := UpdateQuizAttemptRequest{
// 			ID:               utils.Int64ToPointer(1),
// 			Score:            float64ToPointer(50),
// 			HasCheckedAnswer: utils.BoolToPointer(true),
// 			Status:           &status, // Add this to pass binding
// 		}
// 		jb, _ := json.Marshal(req)
// 		ctx.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer(jb))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		mockDB.On("UpdateQuizAttempt", mock.Anything, mock.Anything).Return(nil, errors.New("update fail")).Once()

// 		controller.UpdateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("GetScore_Helper_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		mockDB.On("GetQuizScore", mock.Anything, mock.Anything, mock.Anything).
// 			Return(nil, errors.New("score fail")).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// 	t.Run("GetScore_Empty_Result", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// Simulate DB returning nil result with an error
// 		mockDB.On("GetQuizScore", mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("not found")).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// 	t.Run("Auth_Missing_User_Fixed", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		// Use a GET request so ShouldBind doesn't interfere
// 		ctx.Request, _ = http.NewRequest("GET", "/quiz/100", nil)
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// userId is NOT set in context
// 		controller.GetQuizAttempts(ctx)

// 		assert.Equal(t, http.StatusUnauthorized, w.Code)
// 	})

// 	t.Run("GetAttempts_DB_Failure", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "101"}}

// 		// Trigger InternalServerError branch in GetQuizAttempts
// 		mockDB.On("GetQuizAttempts", mock.Anything, mock.Anything, mock.Anything).
// 			Return(nil, errors.New("db crash")).Once()

// 		controller.GetQuizAttempts(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("GetScore_DB_Failure", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "101"}}

// 		// Trigger InternalServerError branch in GetQuizScore
// 		mockDB.On("GetQuizScore", mock.Anything, mock.Anything, mock.Anything).
// 			Return(nil, errors.New("db timeout")).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// 	t.Run("GetScore_Empty_Object_Success", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// Mock DB returning a pointer to an empty struct (common for GORM Scan/Find)
// 		mockDB.On("GetQuizScore", mock.Anything, int64(1), int64(100)).
// 			Return(&dbModel.QuizAttempts{}, nil).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})
// 	t.Run("GetAttempts_Nil_Fields_Mapping", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// Mock DB returning a struct where all fields are NIL
// 		// This forces the controller to map nil pointers to the response struct
// 		mockDB.On("GetQuizAttempts", mock.Anything, int64(1), int64(100)).
// 			Return(&dbModel.QuizAttempts{}, nil).Once()

// 		controller.GetQuizAttempts(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("Update_Invalid_JSON_Format", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		// Malformed JSON (missing closing brace) to hit ShouldBindJSON error branch fully
// 		ctx.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer([]byte(`{"quiz_attempt_id": 1`)))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		controller.UpdateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})

// 	t.Run("Auth_Invalid_Type_Detailed", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		// Set userId as a boolean to trigger the "invalid userId" conversion error
// 		ctx.Set("userId", true)

// 		// Provide the URI params so ShouldBindUri passes
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}
// 		ctx.Request, _ = http.NewRequest("GET", "/quiz/100", nil)

// 		controller.GetQuizAttempts(ctx)

// 		// Now it should bypass binding and hit the 401 Unauthorized
// 		assert.Equal(t, http.StatusUnauthorized, w.Code)
// 	})
// 	t.Run("GetScore_Helper_Return_Object_With_Error", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// We return a dummy object AND an error to cover 'return score, err' in helper
// 		dummyScore := &dbModel.QuizAttempts{Score: float64ToPointer(10.0)}
// 		mockDB.On("GetQuizScore", mock.Anything, mock.Anything, mock.Anything).
// 			Return(dummyScore, errors.New("score fetch failed")).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("Create_Helper_Internal_Error_Logging", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		status, _ := constants.ParseQuizAttemptsStatusEnum("fail")
// 		req := CreateQuizAttemptRequest{
// 			QuizID: utils.Int64ToPointer(100),
// 			Score:  float64ToPointer(50.0),
// 			Status: &status,
// 		}
// 		jb, _ := json.Marshal(req)
// 		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		// Mocking the specific error branch in createQuizAttemptHelper
// 		mockDB.On("CreateQuizAttempt", mock.Anything, mock.Anything).
// 			Return(nil, errors.New("db insert error")).Once()

// 		controller.CreateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})
// 	t.Run("GetAttempts_Missing_Fields_In_DB_Mapping", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// Mock DB returning an object where all pointers are NIL
// 		// This covers the lines in controller: response := GetQuizAttemptsResponse{...}
// 		// where it accesses attempt.QuizId, attempt.Score etc.
// 		mockDB.On("GetQuizAttempts", mock.Anything, int64(1), int64(100)).
// 			Return(&dbModel.QuizAttempts{
// 				QuizId:        nil,
// 				Score:         nil,
// 				Status:        nil,
// 				AttemptNumber: nil,
// 			}, nil).Once()

// 		controller.GetQuizAttempts(ctx)
// 		assert.Equal(t, http.StatusOK, w.Code)
// 	})

// 	t.Run("Auth_Invalid_Type_Boolean", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		// Set userId as bool to hit the 'invalid userId' branch in ExtractUserId
// 		ctx.Set("userId", true)
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}
// 		ctx.Request, _ = http.NewRequest("GET", "/quiz/100", nil)

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusUnauthorized, w.Code)
// 	})

// 	t.Run("Update_Invalid_Content_Type", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		// Setting a body but WRONG content type (e.g., text/plain)
// 		// This hits the binding error branch in a different way
// 		ctx.Request, _ = http.NewRequest("PUT", "/", bytes.NewBuffer([]byte(`{"quiz_attempt_id": 1}`)))
// 		ctx.Request.Header.Set("Content-Type", "text/plain")

// 		controller.UpdateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 	})
// 	t.Run("GetScore_Helper_Full_Return_Coverage", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))
// 		ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 		// We return a non-nil object AND an error to cover the 'return score, err' line
// 		// where 'score' is actually returned to the controller.
// 		dummy := &dbModel.QuizAttempts{Score: float64ToPointer(0.0)}
// 		mockDB.On("GetQuizScore", mock.Anything, int64(1), int64(100)).
// 			Return(dummy, errors.New("forced coverage error")).Once()

// 		controller.GetQuizScore(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// 	t.Run("Create_Helper_Error_Logging_Full", func(t *testing.T) {
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		ctx.Set("userId", int64(1))

// 		status := constants.QuizAttemptsStatusEnum(1)
// 		req := CreateQuizAttemptRequest{
// 			QuizID: utils.Int64ToPointer(100),
// 			Score:  float64ToPointer(50.0),
// 			Status: &status,
// 		}
// 		jb, _ := json.Marshal(req)
// 		ctx.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(jb))
// 		ctx.Request.Header.Set("Content-Type", "application/json")

// 		// Specifically mock the Create failure to hit the logger.Error in helper.go
// 		mockDB.On("CreateQuizAttempt", mock.Anything, mock.Anything).
// 			Return(nil, errors.New("db write failure")).Once()

// 		controller.CreateQuizAttempt(ctx)
// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 	})

// }

// func TestAuthTypeFailure(t *testing.T) {
// 	controller := NewQuizAttemptsControllerLayer(new(MockDBLayer))
// 	w := httptest.NewRecorder()
// 	ctx, _ := gin.CreateTestContext(w)

// 	// Set userId as a STRING instead of int64
// 	ctx.Set("userId", "1")

// 	controller.GetQuizAttempts(ctx)
// 	assert.Equal(t, http.StatusUnauthorized, w.Code)
// }

// // --- Benchmarks ---

// func BenchmarkGetQuizAttempts_Final(b *testing.B) {
// 	mockDB := new(MockDBLayer)
// 	controller := NewQuizAttemptsControllerLayer(mockDB)

// 	mockData := &dbModel.QuizAttempts{QuizId: utils.Int64ToPointer(100)}
// 	mockDB.On("GetQuizAttempts", mock.Anything, mock.Anything, mock.Anything).Return(mockData, nil)

// 	w := httptest.NewRecorder()
// 	ctx, _ := gin.CreateTestContext(w)
// 	ctx.Set("userId", int64(1))
// 	ctx.Params = []gin.Param{{Key: "quiz_id", Value: "100"}}

// 	b.ResetTimer()
// 	for i := 0; i < b.N; i++ {
// 		// Reuse the request object to avoid allocations
// 		ctx.Request, _ = http.NewRequest("GET", "/", nil)
// 		controller.GetQuizAttempts(ctx)
// 		w.Body.Reset()
// 	}
// }

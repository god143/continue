package bookmark

import (
	"context"
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	dbModel "multipie_ilearn_go/internal/db/bookmark"
	"multipie_ilearn_go/internal/utils"

	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

func (c *bookmarkController) getBookmarksHelper(ctx context.Context, request GetBookmarksRequest, userId int64) (*utils.Pagination, error) {
	response := make([]BookmarkResponse, 0)
	visibility := true
	var modelIds = []*int64{}

	bookmarksResult, err := c.db.GetBookmarks(ctx, request.Page, request.PageSize, userId, request.ModelType, request.SubType)
	if err != nil {
		logger.Error(ctx, "unable to fetch bookmarks from db", zap.Error(err))
		return nil, fmt.Errorf("unable to fetch bookmarks from db: %w", err)
	}

	bookmarks, ok := bookmarksResult.Data.([]dbModel.Bookmark)
	if !ok {
		return nil, fmt.Errorf("data field is not a slice of bookmark")
	}

	for _, bm := range bookmarks {

		modelIds = append(modelIds, bm.ModelId)

	}

	modelType, err := constants.ParseBookmarkModelTypeEnum(request.ModelType)
	if err != nil {
		return nil, err
	}

	switch modelType {
	case constants.BookmarkModelTypeEnumPodcast, constants.BookmarkModelTypeEnumArticle, constants.BookmarkModelTypeEnumVideo:
		resourceMap, err := c.buildResourceBookmarks(ctx, modelIds, request, &visibility)
		if err != nil {
			return nil, err
		}
		for _, bookmarkRes := range bookmarks {
			modelIdValue, ok := resourceMap[*bookmarkRes.ModelId]
			if !ok || modelIdValue == nil {
				continue
			}
			response = append(response, BookmarkResponse{
				ID:             bookmarkRes.ID,
				UserId:         bookmarkRes.UserId,
				ModelId:        bookmarkRes.ModelId,
				ModelType:      bookmarkRes.ModelType,
				SubType:        modelIdValue.SubType,
				Name:           bookmarkRes.Name,
				CategoryID:     modelIdValue.CategoryID,
				CourseModuleID: modelIdValue.CourseModuleID,
				URL:            modelIdValue.URL,
				DarkModeURL:    modelIdValue.DarkModeURL,
				Type:           modelIdValue.Type,
				Description:    modelIdValue.Description,
				Icon:           modelIdValue.Icon,
				Views:          modelIdValue.Views,
				Likes:          modelIdValue.Likes,
				IsShort:        modelIdValue.IsShort,
				Visible:        modelIdValue.Visible,
				CreatedAt:      modelIdValue.CreatedAt,
				Metadata:       modelIdValue.Metadata,
				Duration:       modelIdValue.Duration,
			})
		}
	case constants.BookmarkModelTypeEnumCourseModule:
		courseModuleMap, err := c.buildCourseModuleBookmarks(ctx, modelIds, &visibility)
		if err != nil {
			return nil, err
		}
		for _, bookmarkRes := range bookmarks {
			modelIdValue, ok := courseModuleMap[*bookmarkRes.ModelId]
			if !ok || modelIdValue == nil {
				continue
			}
			response = append(response, BookmarkResponse{
				ID:                      bookmarkRes.ID,
				UserId:                  bookmarkRes.UserId,
				ModelId:                 bookmarkRes.ModelId,
				ModelType:               bookmarkRes.ModelType,
				Name:                    bookmarkRes.Name,
				Duration:                modelIdValue.Duration,
				ModuleOrder:             modelIdValue.ModuleOrder,
				CourseName:              modelIdValue.CourseName,
				CourseModuleDescription: modelIdValue.CourseModuleDescription,
				ParentCategoryName:      modelIdValue.ParentCategoryName,
				CourseId:                modelIdValue.CourseId,
				ContentType:             modelIdValue.ContentType,
				URL:                     modelIdValue.URL,
				DarkModeURL:             modelIdValue.DarkModeURL,
			})
		}
	case constants.BookmarkModelTypeEnumInfographic:
		infographicMap, err := c.buildInfographicBookmarks(ctx, modelIds, visibility)
		if err != nil {
			return nil, err
		}
		for _, bookmarkRes := range bookmarks {
			modelIdValue, ok := infographicMap[*bookmarkRes.ModelId]
			if !ok || modelIdValue == nil {
				continue
			}

			response = append(response, BookmarkResponse{
				ID:          bookmarkRes.ID,
				UserId:      bookmarkRes.UserId,
				ModelId:     bookmarkRes.ModelId,
				ModelType:   bookmarkRes.ModelType,
				Name:        bookmarkRes.Name,
				Likes:       modelIdValue.Likes,
				Description: modelIdValue.Description,
				CategoryID:  modelIdValue.CategoryID,
				Views:       modelIdValue.Views,
				Visible:     modelIdValue.Visible,
				CreatedAt:   modelIdValue.CreatedAt,
				Images:      modelIdValue.Images,
				Duration:    modelIdValue.Duration,
			})
		}
	}
	bookmarksResult.Data = response
	return bookmarksResult, nil
}

func (c *bookmarkController) getBookmarksWithPaginationHelper(ctx context.Context, request GetBookmarksRequest, userId int64) (*utils.Pagination, error) {

	bookmarksResult, err := c.db.GetBookmarksWithPagination(ctx, request.Page, request.PageSize, userId, request.ModelType)

	if err != nil {
		logger.Error(ctx, "unable to fetch bookmarks from db", zap.Error(err))
		return nil, errors.New("unable to fetch bookmarks from db")
	}

	return bookmarksResult, nil
}

func (c *bookmarkController) buildResourceBookmarks(ctx context.Context, modelIds []*int64, request GetBookmarksRequest, visibility *bool) (map[int64]*BuildBookmark, error) {
	primaryResources := make(map[int64]*BuildBookmark)

	models, err := c.db.GetResourceByIds(ctx, modelIds, visibility, request.IsShort)
	if err != nil {
		logger.Error(ctx, "failed to fetch resources", zap.Error(err))
		return nil, err
	}

	for _, model := range models {
		primaryResources[int64(*model.ID)] = &BuildBookmark{
			ModelId:        model.ID,
			CategoryID:     model.CategoryID,
			CourseModuleID: model.CourseModuleID,
			URL:            model.URL,
			DarkModeURL:    model.DarkModeURL,
			Type:           model.Type,
			SubType:        model.SubType,
			Description:    model.Description,
			Icon:           model.Icon,
			Views:          model.Views,
			Likes:          model.Likes,
			IsShort:        model.IsShort,
			Visible:        model.Visible,
			CreatedAt:      model.CreatedAt,
			Metadata:       model.Metadata,
		}
	}

	// if request.ModelType == constants.BookmarkModelTypeEnumVideo.String() {
	// 	secondaryModels, err := c.db.GetSecondaryVideosByIds(ctx, secondaryResourcesModelIds, visibility, request.IsShort)
	// 	if err != nil {
	// 		logger.Error(ctx, "failed to fetch resource", zap.Error(err))
	// 		return nil, err
	// 	}

	// 	for _, secondaryModel := range secondaryModels {
	// 		secondaryResources[*secondaryModel.ID] = &BuildBookmark{
	// 			ModelId:     utils.ConvertInt64ToInt(secondaryModel.ID),
	// 			IsShort:     secondaryModel.IsShort,
	// 			CategoryID:  utils.ConvertInt64ToInt(secondaryModel.CategoryID),
	// 			URL:         secondaryModel.URL,
	// 			DarkModeURL: secondaryModel.DarkModeURL,
	// 			Description: secondaryModel.Description,
	// 			Views:       utils.ConvertInt64ToInt(secondaryModel.Views),
	// 			Likes:       utils.ConvertInt64ToInt(secondaryModel.Likes),
	// 			Visible:     secondaryModel.Visible,
	// 			CreatedAt:   secondaryModel.CreatedAt,
	// 			Metadata:    secondaryModel.Metadata,
	// 		}
	// 	}
	// }

	// Create a new map that combines both primary and secondary resources
	resourceMap := make(map[int64]*BuildBookmark)
	for key, value := range primaryResources {
		resourceMap[key] = value
	}
	// for key, value := range secondaryResources {
	// 	resourceMap[key] = value
	// }

	return resourceMap, nil
}

func (c *bookmarkController) buildCourseModuleBookmarks(ctx context.Context, modelIds []*int64, visibility *bool) (map[int64]*BuildBookmark, error) {
	courseModuleMap := make(map[int64]*BuildBookmark)
	courseModules, err := c.db.GetCourseModuleByIDs(ctx, modelIds, visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch course module", zap.Error(err))
		return nil, err
	}

	for _, courseModule := range courseModules {
		courseModuleMap[int64(*courseModule.CourseModuleId)] = &BuildBookmark{
			ModelId:                 courseModule.CourseModuleId,
			Duration:                courseModule.Duration,
			ModuleOrder:             courseModule.ModuleOrder,
			CourseName:              courseModule.CourseName,
			CourseModuleDescription: courseModule.Description,
			ParentCategoryName:      courseModule.ParentCategoryName,
			CourseId:                courseModule.CourseId,
			ContentType:             courseModule.ContentType,
			URL:                     courseModule.URL,
			DarkModeURL:             courseModule.DarkModeURL,
		}
	}

	return courseModuleMap, nil
}

func (c *bookmarkController) buildInfographicBookmarks(ctx context.Context, modeIDs []*int64, visibility bool) (map[int64]*BuildBookmark, error) {
	infographicMap := make(map[int64]*BuildBookmark)

	// Fetch infographic metadata
	infographics, err := c.db.GetInfographicByIDs(ctx, modeIDs, &visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch infographic", zap.Error(err))
		return nil, err
	}

	// Collect infographic IDs
	var infographicIDs []int64
	for _, infographic := range infographics {
		infographicID := int64(*infographic.ID)

		infographicMap[infographicID] = &BuildBookmark{
			ID:          infographic.ID,
			CategoryID:  infographic.CategoryID,
			Description: infographic.Description,
			Likes:       infographic.Likes,
			Views:       infographic.Views,
			Visible:     infographic.Visible,
			CreatedAt:   infographic.CreatedAt,
		}
		infographicIDs = append(infographicIDs, infographicID)
	}

	// Fetch infographic images
	infographicImagesData, err := c.db.GetInfographicImagesByInfographics(ctx, infographicIDs)
	if err != nil {
		logger.Error(ctx, "failed to fetch infographic images", zap.Error(err))
		return nil, err
	}

	// Group images by InfographicID
	imageMap := make(map[int64][]dbModelInfographicImages.InfographicImage)
	for _, img := range infographicImagesData {
		if img.InfographicID != nil {
			id := int64(*img.InfographicID)
			imageMap[id] = append(imageMap[id], img)
		}
	}

	// Attach []InfographicImage to each BuildBookmark
	for id, response := range infographicMap {
		if imgs, ok := imageMap[id]; ok {
			response.Images = imgs
		}
	}

	return infographicMap, nil
}

/*
createBookmarkHelper... create Bookmark of a particular user in database
*/
func (c *bookmarkController) createBookmarkHelper(ctx context.Context, userID int64, request CreateBookmarkRequest) (*dbModel.Bookmark, error) {

	visibility := true

	if request.ModelType == nil && request.SubType == nil {
		return nil, errors.New("model type and sub type cannot be nil")
	}

	name, err := c.getModelName(ctx, request.ModelType, request.SubType, request.ModelId, &visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch name", zap.Error(err), zap.Any("requestbody", request))
		return nil, err
	}

	bookmark := &dbModel.Bookmark{
		UserId:    &userID,
		ModelId:   request.ModelId,
		ModelType: request.ModelType,
		SubType:   request.SubType,
		Name:      &name,
	}

	bookmark, err = c.db.CreateBookmark(ctx, bookmark)
	if err != nil {
		logger.Error(ctx, "unable to create bookmarks entry in database", zap.Error(err), zap.Any("requestBody", request))
		return nil, errors.New("unable to create bookmarks entry in database")
	}

	return bookmark, nil
}

/*
deleteBookmarkHelper... delete a Bookmark of a particular user if bookmark_id provided and if bookmark_id not provided delete all Bookmarks in database
*/
func (c *bookmarkController) deleteBookmarkHelper(ctx context.Context, userId int64, request DeleteBookmarkRequest) error {

	err := c.db.DeleteBookmark(ctx, userId, request.ID)
	if err != nil {
		logger.Error(ctx, "unable to delete bookmark in database", zap.Error(err), zap.Any("requestBody", request))
		return errors.New("unable to delete bookmark entry in database")
	}

	return nil
}

/*
getModelname gives Model Name which will be used in createBookmarkHelper
*/
func (c *bookmarkController) getModelName(ctx context.Context, model_type *constants.BookmarkModelTypeEnum, sub_type *constants.BookmarkSubTypeEnum, model_id *int64, visibility *bool) (string, error) {

	switch *model_type {
	case constants.BookmarkModelTypeEnumVideo, constants.BookmarkModelTypeEnumPodcast, constants.BookmarkModelTypeEnumArticle:
		return c.getResourceName(ctx, model_id, model_type, sub_type, visibility)

	case constants.BookmarkModelTypeEnumInfographic:
		return c.getInfographicName(ctx, model_id, visibility)

	case constants.BookmarkModelTypeEnumCourse:
		return c.getCourseName(ctx, model_id, visibility)

	case constants.BookmarkModelTypeEnumCourseModule:
		return c.getCourseModuleName(ctx, model_id, visibility)

	// case constants.BookmarkModelTypeEnumExpert, constants.BookmarkModelTypeEnumLearn:
	// 	return c.getAuxililaryName(ctx, model_id, model_type.String(), visibility)

	default:
		return "", errors.New("invalid model type")
	}

}

/*
getResourceName gives Resource Name which will be used in getModelName
*/
func (c *bookmarkController) getResourceName(ctx context.Context, model_id *int64, model_type *constants.BookmarkModelTypeEnum, sub_type *constants.BookmarkSubTypeEnum, visibility *bool) (string, error) {
	var resourceType constants.ResourceTypeEnum
	var subType constants.SubTypeEnum

	resourceType, err := convertBookmarkTypeToResourceType(*model_type)
	if err != nil {
		logger.Error(ctx, "invalid resource type", zap.Error(err))
		return resourceType.String(), errors.New("invalid resource type")
	}

	subType, err = convertBookmarkTypeToSubType(*sub_type)
	if err != nil {
		logger.Error(ctx, "invalid sub type", zap.Error(err))
		return subType.String(), errors.New("invalid sub type")
	}

	resource, err := c.db.GetResourceByIdandType(ctx, int(*model_id), resourceType, subType, visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch resource", zap.Error(err))
		return "", errors.New("failed to fetch resource")
	}
	if resource.Name == nil || *resource.Name == "" {
		return "", errors.New("resource name is empty or nil")
	}
	return *resource.Name, nil
}

/*
getInfographicName gives Infographic Name which will be used in getModelName
*/
func (c *bookmarkController) getInfographicName(ctx context.Context, model_id *int64, visibility *bool) (string, error) {
	infographic, err := c.db.GetInfographicByID(ctx, *model_id, visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch infographic", zap.Error(err))
		return "", errors.New("failed to fetch infographic")
	}
	return *infographic.Name, nil
}

/*
getCourseName gives Course Name which will be used in getModelName
*/
func (c *bookmarkController) getCourseName(ctx context.Context, model_id *int64, visibility *bool) (string, error) {
	course, err := c.db.GetCourseByID(ctx, *model_id, visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch course", zap.Error(err))
		return "", errors.New("failed to fetch course")
	}
	return *course.Fullname, nil
}

/*
getChapterName gives Chapter Name which will be used in getModelName
*/
func (c *bookmarkController) getCourseModuleName(ctx context.Context, model_id *int64, visibility *bool) (string, error) {
	courseModule, err := c.db.GetCourseModuleByID(ctx, *model_id)
	if err != nil {
		logger.Error(ctx, "failed to fetch course module", zap.Error(err))
		return "", errors.New("failed to fetch course module")
	}

	course, err := c.db.GetCourseByID(ctx, int64(*courseModule.CourseID), visibility)
	if err != nil {
		logger.Error(ctx, "failed to fetch course", zap.Error(err))
		return "", errors.New("failed to fetch course")
	}
	return *courseModule.Name + " - " + *course.Fullname, nil
}

// func (c *bookmarkController) getAuxililaryName(ctx context.Context, model_id *int64, model_type string, visibility *bool) (string, error) {
// 	auxilaryVideo, err := c.db.GetVideoByIDAndType(ctx, *model_id, model_type, *visibility)
// 	if err != nil {
// 		logger.Error(ctx, "failed to fetch secondary resource", zap.Error(err))
// 		return "", errors.New("failed to fetch secondary resource")
// 	}
// 	return *auxilaryVideo.Name, nil
// }

func convertBookmarkTypeToResourceType(bookmarkType constants.BookmarkModelTypeEnum) (constants.ResourceTypeEnum, error) {

	switch bookmarkType {
	case constants.BookmarkModelTypeEnumArticle:
		return constants.ResourceTypeEnumArticle, nil
	case constants.BookmarkModelTypeEnumPodcast:
		return constants.ResourceTypeEnumPodcast, nil
	case constants.BookmarkModelTypeEnumVideo:
		return constants.ResourceTypeEnumVideo, nil
	default:
		return 0, errors.New("invalid resource type")
	}
}

func convertBookmarkTypeToSubType(bookmarkType constants.BookmarkSubTypeEnum) (constants.SubTypeEnum, error) {

	switch bookmarkType {
	case constants.BookmarkSubTypeEnum(constants.BookmarkSubTypeEnumExpert):
		return constants.SubTypeEnumExpert, nil
	case constants.BookmarkSubTypeEnum(constants.BookmarkSubTypeEnumLearn):
		return constants.SubTypeEnumLearn, nil
	case constants.BookmarkSubTypeEnum(constants.BookmarkSubTypeEnumPrimary):
		return constants.SubTypeEnumPrimary, nil
	default:
		return "", errors.New("invalid subType")
	}
}

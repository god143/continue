package bookmark

import (
	"encoding/json"
	"multipie_ilearn_go/internal/constants"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
	"time"
)

type GetBookmarksRequest struct {
	Page      int64  `form:"page"`
	PageSize  int64  `form:"page_size"`
	ModelType string `form:"model_type" binding:"required,oneof=course course_module infographic article podcast video chapter"`
	SubType   string `form:"sub_type"`
	IsShort   *bool  `form:"is_short"`
}

type CreateBookmarkRequest struct {
	ModelId   *int64                           `json:"model_id" binding:"required"`   // model id in from different types of contents
	ModelType *constants.BookmarkModelTypeEnum `json:"model_type" binding:"required"` // type of the model
	SubType   *constants.BookmarkSubTypeEnum   `json:"sub_type" binding:"required"`
}

type CreateBookmarkResponse struct {
	ID int64 `json:"id"`
}

type DeleteBookmarkRequest struct {
	ID *int64 `json:"id" binding:"required"`
}

type BookmarkResponse struct {
	ID                      *int64                                      `json:"id"`
	UserId                  *int64                                      `json:"user_id"`
	ModelId                 *int64                                      `json:"model_id"`
	ModelType               *constants.BookmarkModelTypeEnum            `json:"model_type"`
	Name                    *string                                     `json:"name"`
	CategoryID              *int                                        `json:"category_id"`
	CourseModuleID          *int                                        `json:"course_module_id"`
	URL                     *string                                     `json:"url"`
	DarkModeURL             *string                                     `json:"dark_mode_url"`
	Type                    *constants.ResourceTypeEnum                 `json:"type"`
	SubType                 *constants.SubTypeEnum                      `json:"sub_type"`
	Description             *string                                     `json:"description"`
	Icon                    *string                                     `json:"icon"`
	Views                   *int                                        `json:"views"`
	Likes                   *int                                        `json:"likes"`
	IsShort                 *bool                                       `json:"is_short"`
	Visible                 *bool                                       `json:"visible"`
	CreatedAt               *time.Time                                  `json:"created_at"`
	Metadata                json.RawMessage                             `json:"metadata"`
	Duration                *int                                        `json:"duration"`
	Images                  []dbModelInfographicImages.InfographicImage `json:"images"`
	CourseName              *string                                     `json:"course_name"`
	CourseModuleDescription *string                                     `json:"course_module_description"`
	ModuleOrder             *int                                        `json:"module_order"`
	ParentCategoryName      *string                                     `json:"parent_category_name"`
	CourseId                *int                                        `json:"course_id"`
	ContentType             *string                                     `json:"content_type"`
}

type BuildBookmark struct {
	ID                      *int                                        `json:"id"`
	UserId                  *int64                                      `json:"user_id"`
	ModelId                 *int                                        `json:"model_id"`
	ModelType               *constants.BookmarkModelTypeEnum            `json:"model_type"`
	SubType                 *constants.SubTypeEnum                      `json:"sub_type"`
	Name                    *string                                     `json:"name"`
	CategoryID              *int                                        `json:"category_id"`
	CourseModuleID          *int                                        `json:"course_module_id"`
	URL                     *string                                     `json:"url"`
	DarkModeURL             *string                                     `json:"dark_mode_url"`
	Type                    *constants.ResourceTypeEnum                 `json:"type"`
	Description             *string                                     `json:"description"`
	Icon                    *string                                     `json:"icon"`
	Views                   *int                                        `json:"views"`
	Likes                   *int                                        `json:"likes"`
	IsShort                 *bool                                       `json:"is_short"`
	Visible                 *bool                                       `json:"visible"`
	CreatedAt               *time.Time                                  `json:"created_at"`
	Metadata                json.RawMessage                             `json:"metadata"`
	Duration                *int                                        `json:"duration"`
	Images                  []dbModelInfographicImages.InfographicImage `json:"images"`
	CourseName              *string                                     `json:"course_name"`
	CourseModuleDescription *string                                     `json:"course_module_description"`
	ModuleOrder             *int                                        `json:"module_order"`
	ParentCategoryName      *string                                     `json:"parent_category_name"`
	CourseId                *int                                        `json:"course_id"`
	ContentType             *string                                     `json:"content_type"`
}

package bookmark

import (
	"multipie_ilearn_go/internal/db"

	"github.com/gin-gonic/gin"
)

type bookmarkController struct {
	db db.DBLayer
}

type BookmarkControllerGroup interface {
	GetBookmarks(ctx *gin.Context)
	GetBookmarksWithPagination(ctx *gin.Context)
	CreateBookmark(ctx *gin.Context)
	DeleteBookmark(ctx *gin.Context)
}

func NewBookmarkControllerGroup(db db.DBLayer) BookmarkControllerGroup {
	return &bookmarkController{
		db: db,
	}
}

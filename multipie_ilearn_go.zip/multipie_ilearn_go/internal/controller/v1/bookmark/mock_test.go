package bookmark

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"

	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db"

	dbModel "multipie_ilearn_go/internal/db/bookmark"
	dbModelCourse "multipie_ilearn_go/internal/db/course"
	dbModelCourseModule "multipie_ilearn_go/internal/db/courseModules"
	dbModelInfographic "multipie_ilearn_go/internal/db/infographic"
	dbModelInfographicImages "multipie_ilearn_go/internal/db/infographicImages"
	dbModelResource "multipie_ilearn_go/internal/db/resource"

	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockDB) GetBookmarks(ctx context.Context, p, ps int64, uid int64, mt string, st string) (*utils.Pagination, error) {
	args := m.Called(ctx, p, ps, uid, mt, st)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*utils.Pagination), args.Error(1)
}

func (m *MockDB) GetBookmarksWithPagination(ctx context.Context, p, ps int64, uid int64, mt string) (*utils.Pagination, error) {
	args := m.Called(ctx, p, ps, uid, mt)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*utils.Pagination), args.Error(1)
}

func (m *MockDB) CreateBookmark(ctx context.Context, b *dbModel.Bookmark) (*dbModel.Bookmark, error) {
	args := m.Called(ctx, b)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Bookmark), args.Error(1)
}

func (m *MockDB) DeleteBookmark(ctx context.Context, uid int64, bid *int64) error {
	return m.Called(ctx, uid, bid).Error(0)
}

func (m *MockDB) GetResourceByIdandType(ctx context.Context, id int, rType constants.ResourceTypeEnum, sType constants.SubTypeEnum, vis *bool) (*dbModelResource.Resource, error) {
	args := m.Called(ctx, id, rType, sType, vis)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModelResource.Resource), args.Error(1)
}

func (m *MockDB) GetResourceByIds(ctx context.Context, ids []*int64, v *bool, s *bool) ([]dbModelResource.Resource, error) {
	args := m.Called(ids, v, s)
	return args.Get(0).([]dbModelResource.Resource), args.Error(1)
}

func (m *MockDB) GetCourseModuleByID(ctx context.Context, id int64) (dbModelCourseModule.CourseModule, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return dbModelCourseModule.CourseModule{}, args.Error(1)
	}
	return args.Get(0).(dbModelCourseModule.CourseModule), args.Error(1)
}

func (m *MockDB) GetCourseByID(ctx context.Context, courseID int64, visibility *bool) (dbModelCourse.Course, error) {
	args := m.Called(ctx, courseID, visibility)
	if args.Get(0) == nil {
		return dbModelCourse.Course{}, args.Error(1)
	}
	return args.Get(0).(dbModelCourse.Course), args.Error(1)
}

func (m *MockDB) GetCourseModuleByIDs(ctx context.Context, moduleIDs []*int64, visible *bool) ([]dbModelCourseModule.CourseModuleInfo, error) {
	args := m.Called(ctx, moduleIDs)
	if args.Get(0) == nil {
		return []dbModelCourseModule.CourseModuleInfo{}, args.Error(1)
	}
	return args.Get(0).([]dbModelCourseModule.CourseModuleInfo), args.Error(1)
}

func (m *MockDB) GetInfographicByIDs(ctx context.Context, infographicIDs []*int64, visibility *bool) ([]dbModelInfographic.Infographic, error) {
	args := m.Called(ctx, infographicIDs, visibility)
	return args.Get(0).([]dbModelInfographic.Infographic), args.Error(1)
}

func (m *MockDB) GetInfographicImagesByInfographics(ctx context.Context, infograohicIds []int64) ([]dbModelInfographicImages.InfographicImage, error) {
	args := m.Called(ctx, infograohicIds)
	return args.Get(0).([]dbModelInfographicImages.InfographicImage), args.Error(1)
}

func (m *MockDB) GetInfographicByID(ctx context.Context, id int64, vis *bool) (dbModelInfographic.Infographic, error) {
	args := m.Called(ctx, id, vis)
	if args.Get(0) == nil {
		return dbModelInfographic.Infographic{}, args.Error(1)
	}
	return args.Get(0).(dbModelInfographic.Infographic), args.Error(1)
}

func ptr[T any](v T) *T {
	return &v
}

func TestBookmarkController_Unified(t *testing.T) {
	gin.SetMode(gin.TestMode)
	_ = logger.NewLogger("test", "error", "")
	const testUID = int64(123)
	t.Run("GetBookmarks_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			query    map[string]string
			body     interface{}
			userId   interface{}
			setup    func(*MockDB)
			expected int
		}{
			{
				name:   "Success_Video_HappyPath",
				query:  map[string]string{"model_type": "video", "page": "1", "page_size": "10"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, int64(1), int64(10), testUID, "video", "").
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(1))}}}, nil)
					m.On("GetResourceByIds", mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelResource.Resource{{ID: ptr(int(1)), Name: ptr("Video 1")}}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:   "Success_CourseModule_Branch",
				query:  map[string]string{"model_type": "course_module"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "course_module", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(2))}}}, nil)
					m.On("GetCourseModuleByIDs", mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelCourseModule.CourseModuleInfo{
							{CourseModuleId: ptr(int(2)), Name: ptr("Test Course")},
						}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Invalid_Request_Short_Logic",
				query:    map[string]string{"model_type": "podcast", "is_short": "true"},
				userId:   int64(100),
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Fail_Unauthorized",
				query:    map[string]string{"model_type": "video"},
				userId:   nil,
				setup:    func(m *MockDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:   "Fail_DB_Error_Causes_PanicFix",
				query:  map[string]string{"model_type": "video"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, mock.Anything, mock.Anything).
						Return((*utils.Pagination)(nil), errors.New("db disconnect")).Maybe()
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:   "Fail_Infographic_DB_Error",
				query:  map[string]string{"model_type": "infographic"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "infographic", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(3))}}}, nil)
					m.On("GetInfographicByIDs", mock.Anything, mock.Anything, mock.Anything).
						Return(([]dbModelInfographic.Infographic)(nil), errors.New("infographic db error"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:   "Fail_Infographic_Images_DB_Error",
				query:  map[string]string{"model_type": "infographic"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "infographic", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(3))}}}, nil)
					m.On("GetInfographicByIDs", mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelInfographic.Infographic{{ID: ptr(int(3)), Name: ptr("Info")}}, nil)
					m.On("GetInfographicImagesByInfographics", mock.Anything, mock.Anything).
						Return(([]dbModelInfographicImages.InfographicImage)(nil), errors.New("image fetch error"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:   "Success_Infographic_Empty_Results",
				query:  map[string]string{"model_type": "infographic"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "infographic", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{}}, nil)
					m.On("GetInfographicByIDs", mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelInfographic.Infographic{}, nil).Maybe()
					m.On("GetInfographicImagesByInfographics", mock.Anything, mock.Anything).
						Return([]dbModelInfographicImages.InfographicImage{}, nil).Maybe()
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Invalid_ModelType",
				query:    map[string]string{"model_type": "invalid_type"},
				userId:   testUID,
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:   "Fail_CourseModule_Metadata_Error",
				query:  map[string]string{"model_type": "course_module"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "course_module", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(22))}}}, nil)
					m.On("GetCourseModuleByIDs", mock.Anything, mock.Anything, mock.Anything).
						Return(([]dbModelCourseModule.CourseModuleInfo)(nil), errors.New("plural db error"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:   "Success_Video_No_Results_Safety",
				query:  map[string]string{"model_type": "video"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "video", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{}}, nil)
					m.On("GetResourceByIds", mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelResource.Resource{}, nil).Maybe()
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Enum_Parse_Error",
				query:    map[string]string{"model_type": "invalid_oneof_value"},
				userId:   testUID,
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:   "Success_Course_Branch_Coverage",
				query:  map[string]string{"model_type": "course"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "course", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(4))}}}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:   "Success_Video_Metadata_Missing_Continue",
				query:  map[string]string{"model_type": "video"},
				userId: testUID,
				setup: func(m *MockDB) {
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "video", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: ptr(int64(99))}}}, nil)
					m.On("GetResourceByIds", mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelResource.Resource{}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:   "Success_Infographic_With_Images_Loop",
				query:  map[string]string{"model_type": "infographic"},
				userId: testUID,
				setup: func(m *MockDB) {
					mID := int64(3)
					m.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, testUID, "infographic", mock.Anything).
						Return(&utils.Pagination{Data: []dbModel.Bookmark{{ModelId: &mID}}}, nil)
					m.On("GetInfographicByIDs", mock.Anything, mock.Anything, mock.Anything).
						Return([]dbModelInfographic.Infographic{{ID: ptr(int(3)), Name: ptr("Info")}}, nil)
					m.On("GetInfographicImagesByInfographics", mock.Anything, []int64{3}).
						Return([]dbModelInfographicImages.InfographicImage{
							{
								InfographicID: ptr(int(3)),
								ImageURL:      ptr("https://example.com/image.jpg"),
							},
						}, nil)
				},
				expected: http.StatusOK,
			},
		}
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &bookmarkController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				if tt.userId != nil {
					c.Set("userId", tt.userId)
				} else {
					delete(c.Keys, "userId")
				}
				q := url.Values{}
				for k, v := range tt.query {
					q.Add(k, v)
				}
				c.Request, _ = http.NewRequest(http.MethodGet, "/?"+q.Encode(), nil)
				tt.setup(mDB)
				ctrl.GetBookmarks(c)
				assert.Equal(t, tt.expected, w.Code, tt.name)
			})
		}
	})
	t.Run("GetBookmarksWithPagination_Scenarios", func(t *testing.T) {
		mDB := new(MockDB)
		ctrl := &bookmarkController{db: mDB}
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Set("userId", testUID)
		c.Request, _ = http.NewRequest("GET", "/?model_type=video&page=1&page_size=10", nil)
		mDB.On("GetBookmarksWithPagination", mock.Anything, int64(1), int64(10), testUID, "video").
			Return(&utils.Pagination{}, nil)
		ctrl.GetBookmarksWithPagination(c)
		assert.Equal(t, http.StatusOK, w.Code)
		tests := []struct {
			name     string
			setup    func(*MockDB)
			expected int
		}{
			{
				name: "Success_Pagination",
				setup: func(m *MockDB) {
					m.On("GetBookmarksWithPagination", mock.Anything, int64(1), int64(10), testUID, "video").
						Return(&utils.Pagination{}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_DB_Error",
				setup: func(m *MockDB) {
					m.On("GetBookmarksWithPagination", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
						Return(nil, errors.New("db fail"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Fail_Missing_UserId_Context",
				setup: func(m *MockDB) {

				},
				expected: http.StatusUnauthorized,
			},
			{
				name: "Fail_Invalid_Page_Format",
				setup: func(m *MockDB) {
				},
				expected: http.StatusBadRequest,
			},
			{
				name: "Success_Infographic_Pagination",
				setup: func(m *MockDB) {
					m.On("GetBookmarksWithPagination", mock.Anything, mock.Anything, mock.Anything, testUID, "infographic").
						Return(&utils.Pagination{Data: []interface{}{"item1"}}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Auth_Invalid_Type_In_Context",
				setup:    func(m *MockDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "Fail_Binding_Missing_ModelType",
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name: "Success_Empty_Data_From_DB",
				setup: func(m *MockDB) {
					m.On("GetBookmarksWithPagination", mock.Anything, mock.Anything, mock.Anything, testUID, "video").
						Return(&utils.Pagination{
							Data: []interface{}{},
						}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_Internal_Helper_Error",
				setup: func(m *MockDB) {
					m.On("GetBookmarksWithPagination", mock.Anything, mock.Anything, mock.Anything, testUID, "video").
						Return((*utils.Pagination)(nil), errors.New("helper logic failure"))
				},
				expected: http.StatusInternalServerError,
			},
		}
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &bookmarkController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				modelType := "video"
				if tt.name == "Success_Infographic_Pagination" {
					modelType = "infographic"
				} else if tt.name == "Fail_Binding_Missing_ModelType" {
					modelType = ""
				}
				pageParam := "1"
				if tt.name == "Fail_Invalid_Page_Format" {
					pageParam = "abc"
				}
				u := fmt.Sprintf("/?page=%s&page_size=10", pageParam)
				if modelType != "" {
					u += "&model_type=" + modelType
				}
				c.Request, _ = http.NewRequest("GET", u, nil)
				if tt.name == "Fail_Auth_Invalid_Type_In_Context" {
					c.Set("userId", "not-an-int64")
				} else if tt.name != "Fail_Missing_UserId_Context" {
					c.Set("userId", testUID)
				}
				tt.setup(mDB)
				ctrl.GetBookmarksWithPagination(c)
				assert.Equal(t, tt.expected, w.Code, tt.name)
			})
		}
	})
	t.Run("3._CreateBookmark_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			body     interface{}
			setup    func(*MockDB)
			expected int
		}{
			{
				name: "Success_Video_Creation",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(1)),
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetResourceByIdandType", mock.Anything, 1, mock.Anything, mock.Anything, mock.Anything).
						Return(&dbModelResource.Resource{Name: ptr("Test Name")}, nil)
					m.On("CreateBookmark", mock.Anything, mock.Anything).
						Return(&dbModel.Bookmark{ID: ptr(int64(555))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_Name_Lookup_Error",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(1)),
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetResourceByIdandType",
						mock.Anything, // context
						1,             // model_id
						mock.Anything, // ResourceTypeEnum
						mock.Anything, // SubTypeEnum
						mock.Anything, // visibility
					).Return((*dbModelResource.Resource)(nil), errors.New("resource not found"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Fail_Invalid_JSON_Body",
				body:     "this-is-not-json",
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name: "Fail_Validation_Missing_Required_Fields",
				body: CreateBookmarkRequest{
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
				},
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name: "Success_Infographic_Creation",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(3)),
					ModelType: ptr(constants.BookmarkModelTypeEnumInfographic),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetInfographicByID", mock.Anything, int64(3), mock.Anything).
						Return(dbModelInfographic.Infographic{
							ID:   ptr(int(3)),
							Name: ptr("Infographic Name"),
						}, nil)
					m.On("CreateBookmark", mock.Anything, mock.Anything).
						Return(&dbModel.Bookmark{ID: ptr(int64(777))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_Infographic_NotFound",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(404)),
					ModelType: ptr(constants.BookmarkModelTypeEnumInfographic),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetInfographicByID", mock.Anything, int64(404), mock.Anything).
						Return(nil, errors.New("not found"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Success_Infographic_Creation",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(3)),
					ModelType: ptr(constants.BookmarkModelTypeEnumInfographic),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetInfographicByID", mock.Anything, int64(3), mock.Anything).
						Return(dbModelInfographic.Infographic{
							ID:   ptr(int(3)),
							Name: ptr("Infographic Name"),
						}, nil)
					m.On("CreateBookmark", mock.Anything, mock.Anything).
						Return(&dbModel.Bookmark{ID: ptr(int64(777))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_CourseModule_NotFound",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(10)),
					ModelType: ptr(constants.BookmarkModelTypeEnumCourseModule),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetCourseModuleByID", mock.Anything, int64(10)).
						Return(nil, errors.New("db error"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Fail_Infographic_Name_Lookup_Error",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(3)),
					ModelType: ptr(constants.BookmarkModelTypeEnumInfographic),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetInfographicByID", mock.Anything, int64(3), mock.Anything).
						Return(nil, errors.New("not found"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Fail_DB_Create_Insert_Error",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(1)),
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetResourceByIdandType", mock.Anything, 1, mock.Anything, mock.Anything, mock.Anything).
						Return(&dbModelResource.Resource{Name: ptr("Test Name")}, nil)
					m.On("CreateBookmark", mock.Anything, mock.Anything).
						Return((*dbModel.Bookmark)(nil), errors.New("insert failed"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Fail_Resource_Name_Missing_In_DB",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(999)),
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetResourceByIdandType", mock.Anything, int(999), mock.Anything, mock.Anything, mock.Anything).
						Return((*dbModelResource.Resource)(nil), errors.New("db lookup failure"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Success_CourseModule_Creation",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(200)),
					ModelType: ptr(constants.BookmarkModelTypeEnumCourseModule),
					SubType:   ptr(constants.BookmarkSubTypeEnumPrimary),
				},
				setup: func(m *MockDB) {
					m.On("GetCourseModuleByID", mock.Anything, int64(200)).
						Return(dbModelCourseModule.CourseModule{
							CourseID: ptr(int(500)),
							Name:     ptr("Module 1"),
						}, nil)
					m.On("GetCourseByID", mock.Anything, int64(500), mock.Anything).
						Return(dbModelCourse.Course{
							ID:       ptr(int64(500)),
							Fullname: ptr("Complete Go Course"),
						}, nil)

					m.On("CreateBookmark", mock.Anything, mock.Anything).
						Return(&dbModel.Bookmark{ID: ptr(int64(888))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Success_Course_Standalone_Creation",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(300)),
					ModelType: ptr(constants.BookmarkModelTypeEnumCourse),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetCourseByID", mock.Anything, int64(300), mock.Anything).
						Return(dbModelCourse.Course{Fullname: ptr("Mastering Go")}, nil)
					m.On("CreateBookmark", mock.Anything, mock.Anything).
						Return(&dbModel.Bookmark{ID: ptr(int64(333))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_Resource_Name_Empty_String",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(1)),
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup: func(m *MockDB) {
					m.On("GetResourceByIdandType", mock.Anything, 1, mock.Anything, mock.Anything, mock.Anything).
						Return(&dbModelResource.Resource{Name: ptr("")}, nil)
				},
				expected: http.StatusInternalServerError,
			},
			{
				name: "Fail_GetModelName_Invalid_Type_Internal",
				body: map[string]interface{}{
					"model_id":   1,
					"model_type": "invalid_type",
					"sub_type":   "expert",
				},
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name: "Fail_Create_Auth_Invalid_Type",
				body: CreateBookmarkRequest{
					ModelId:   ptr(int64(1)),
					ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
					SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
				},
				setup:    func(m *MockDB) {},
				expected: http.StatusUnauthorized,
			},
		}
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &bookmarkController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				if tt.name == "Fail_Create_Auth_Invalid_Type" {
					c.Set("userId", "not-an-int64-string")
				} else if tt.name == "Fail_Create_Auth_Missing" {

				} else {
					c.Set("userId", testUID)
				}
				b, _ := json.Marshal(tt.body)
				c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(b))
				c.Request.Header.Set("Content-Type", "application/json")
				tt.setup(mDB)
				ctrl.CreateBookmark(c)
				assert.Equal(t, tt.expected, w.Code, tt.name)
			})
		}
	})
	t.Run("DeleteBookmark_test_cases", func(t *testing.T) {
		tests := []struct {
			name     string
			body     interface{}
			setup    func(*MockDB)
			expected int
		}{
			{
				name: "Success_Delete_Specific",
				body: DeleteBookmarkRequest{ID: ptr(int64(99))},
				setup: func(m *MockDB) {
					m.On("DeleteBookmark", mock.Anything, testUID, mock.MatchedBy(func(id *int64) bool {
						return id != nil && *id == 99
					})).Return(nil)
				},
				expected: http.StatusOK,
			},
			{
				name: "Fail_DB_Deletion_Error",
				body: DeleteBookmarkRequest{ID: ptr(int64(99))},
				setup: func(m *MockDB) {
					m.On("DeleteBookmark", mock.Anything, testUID, mock.Anything).Return(errors.New("db error"))
				},
				expected: http.StatusInternalServerError,
			},
			{
				name:     "Fail_Delete_Validation_Nil_ID",
				body:     DeleteBookmarkRequest{ID: nil},
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:     "Fail_Delete_Unauthorized_Missing_User",
				body:     DeleteBookmarkRequest{ID: ptr(int64(99))},
				setup:    func(m *MockDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "Fail_Delete_Malformed_JSON",
				body:     map[string]interface{}{"id": "not-a-number"},
				setup:    func(m *MockDB) {},
				expected: http.StatusBadRequest,
			},
		}
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockDB)
				ctrl := &bookmarkController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)
				if tt.name != "Fail_Delete_Unauthorized_Missing_User" {
					c.Set("userId", testUID)
				}
				b, _ := json.Marshal(tt.body)
				c.Request, _ = http.NewRequest("DELETE", "/", bytes.NewBuffer(b))
				c.Request.Header.Set("Content-Type", "application/json")
				tt.setup(mDB)
				ctrl.DeleteBookmark(c)
				assert.Equal(t, tt.expected, w.Code, tt.name)
			})
		}
	})
}

// --- BENCHMARKS ---
func BenchmarkBookmarkAPIs(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockDB)
	ctrl := &bookmarkController{db: mDB}
	uid := int64(123)

	mDB.On("GetBookmarks", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
		Return(&utils.Pagination{Data: []dbModel.Bookmark{}}, nil).Maybe()

	mDB.On("GetBookmarksWithPagination", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
		Return(&utils.Pagination{Data: []interface{}{}}, nil).Maybe()

	mDB.On("DeleteBookmark", mock.Anything, mock.Anything, mock.Anything).
		Return(nil).Maybe()

	mDB.On("GetResourceByIdandType", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).
		Return(&dbModelResource.Resource{Name: ptr("Benchmark Resource")}, nil).Maybe()

	mDB.On("CreateBookmark", mock.Anything, mock.Anything).
		Return(&dbModel.Bookmark{ID: ptr(int64(1))}, nil).Maybe()

	b.Run("Benchmark_GetBookmarks", func(b *testing.B) {
		for i := 0; i < b.N; i++ {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Set("userId", uid)
			c.Request, _ = http.NewRequest("GET", "/?model_type=video", nil)
			ctrl.GetBookmarks(c)
		}
	})

	b.Run("Benchmark_GetBookmarksWithPagination", func(b *testing.B) {
		for i := 0; i < b.N; i++ {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Set("userId", uid)
			c.Request, _ = http.NewRequest("GET", "/?model_type=video&page=1&page_size=10", nil)
			ctrl.GetBookmarksWithPagination(c)
		}
	})

	b.Run("Benchmark_CreateBookmark", func(b *testing.B) {
		bodyObj := CreateBookmarkRequest{
			ModelId:   ptr(int64(1)),
			ModelType: ptr(constants.BookmarkModelTypeEnumVideo),
			SubType:   ptr(constants.BookmarkSubTypeEnumExpert),
		}
		bodyJSON, _ := json.Marshal(bodyObj)

		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Set("userId", uid)
			c.Request, _ = http.NewRequest("POST", "/", bytes.NewBuffer(bodyJSON))
			c.Request.Header.Set("Content-Type", "application/json")
			ctrl.CreateBookmark(c)
		}
	})

	b.Run("Benchmark_DeleteBookmark", func(b *testing.B) {
		bodyObj := DeleteBookmarkRequest{ID: ptr(int64(1))}
		bodyJSON, _ := json.Marshal(bodyObj)

		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Set("userId", uid)
			c.Request, _ = http.NewRequest("DELETE", "/", bytes.NewBuffer(bodyJSON))
			c.Request.Header.Set("Content-Type", "application/json")
			ctrl.DeleteBookmark(c)
		}
	})
}

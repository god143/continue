package bookmark

import (
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *bookmarkController) GetBookmarks(ctx *gin.Context) {
	var (
		resp            *utils.Response
		getBookmarkResp *utils.Pagination
		request         GetBookmarksRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if request.ModelType != constants.MODEL_TYPE_VIDEO && request.IsShort != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("Invalid request"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	getBookmarkResp, err = c.getBookmarksHelper(ctx, request, uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}
	ctx.JSON(http.StatusOK, utils.NewV1Response(getBookmarkResp, nil))
}

func (c *bookmarkController) GetBookmarksWithPagination(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetBookmarksRequest
	)

	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}
	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	getUsersResp, err := c.getBookmarksWithPaginationHelper(ctx, request, uid)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getUsersResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *bookmarkController) CreateBookmark(ctx *gin.Context) {
	var (
		resp     *utils.Response
		request  CreateBookmarkRequest
		response CreateBookmarkResponse
	)

	if err := ctx.ShouldBind(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	users, err := c.createBookmarkHelper(ctx, uid, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	response = CreateBookmarkResponse{
		ID: int64(*users.ID),
	}
	resp = utils.NewV1Response(response, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *bookmarkController) DeleteBookmark(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request DeleteBookmarkRequest
	)

	if err := ctx.ShouldBindJSON(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	uid, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	err = c.deleteBookmarkHelper(ctx, uid, request)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response("Bookmark deleted successfully", nil)
	ctx.JSON(http.StatusOK, resp)
}

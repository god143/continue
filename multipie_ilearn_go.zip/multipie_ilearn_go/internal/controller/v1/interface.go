package v1

import (
	"multipie_ilearn_go/internal/config"
	activitytracker "multipie_ilearn_go/internal/controller/v1/activityTracking"
	"multipie_ilearn_go/internal/controller/v1/bookmark"
	"multipie_ilearn_go/internal/controller/v1/category"
	"multipie_ilearn_go/internal/controller/v1/certificate"
	"multipie_ilearn_go/internal/controller/v1/comments"
	mdlcourse "multipie_ilearn_go/internal/controller/v1/course"
	mdlcoursecontent "multipie_ilearn_go/internal/controller/v1/courseContent"
	"multipie_ilearn_go/internal/controller/v1/courseModules"
	"multipie_ilearn_go/internal/controller/v1/enrollment"
	"multipie_ilearn_go/internal/controller/v1/glossary"
	"multipie_ilearn_go/internal/controller/v1/health"
	"multipie_ilearn_go/internal/controller/v1/infographic"
	"multipie_ilearn_go/internal/controller/v1/login"
	"multipie_ilearn_go/internal/controller/v1/mutualFunds"
	"multipie_ilearn_go/internal/controller/v1/news"
	"multipie_ilearn_go/internal/controller/v1/notifications"
	"multipie_ilearn_go/internal/controller/v1/progressAchievement"
	"multipie_ilearn_go/internal/controller/v1/quiz"
	"multipie_ilearn_go/internal/controller/v1/quizAttempts"
	"multipie_ilearn_go/internal/controller/v1/resource"
	"multipie_ilearn_go/internal/controller/v1/stats"
	"multipie_ilearn_go/internal/controller/v1/tagMapping"
	"multipie_ilearn_go/internal/controller/v1/tags"
	"multipie_ilearn_go/internal/controller/v1/users"

	"multipie_ilearn_go/internal/db"
)

type v1 struct {
	health.HeathGroup
	mdlcourse.CourseControllerGroup
	mdlcoursecontent.CourseContentControllerGroup
	category.CategoryControllerGroup
	courseModules.CourseModuleControllerGroup
	infographic.InfographicControllerGroup
	enrollment.EnrollmentControllerLayer
	resource.ResourceControllerGroup
	quiz.QuizControllerGroup
	quizAttempts.QuizAttemptsControllerLayer
	glossary.GlossaryControllerGroup
	activitytracker.ActivityTrackerControllerGroup
	stats.StatsControllerGroup
	comments.CommentControllerGroup
	tagMapping.TagMappingControllerGroup
	tags.TagsControllerGroup
	bookmark.BookmarkControllerGroup
	users.UsersControllerGroup
	certificate.CertificateControllerGroup
	progressAchievement.ProgressAchievementControllerGroup
	news.NewsControllerGroup
	mutualFunds.MutualFundsControllerGroup
	login.LoginControllerGroup
	notifications.NotificationsControllerGroup
}

type V1ControllerLayer interface {
	health.HeathGroup
	mdlcourse.CourseControllerGroup
	mdlcoursecontent.CourseContentControllerGroup
	category.CategoryControllerGroup
	courseModules.CourseModuleControllerGroup
	infographic.InfographicControllerGroup
	enrollment.EnrollmentControllerLayer
	resource.ResourceControllerGroup
	quiz.QuizControllerGroup
	quizAttempts.QuizAttemptsControllerLayer
	activitytracker.ActivityTrackerControllerGroup
	stats.StatsControllerGroup
	comments.CommentControllerGroup
	glossary.GlossaryControllerGroup
	tagMapping.TagMappingControllerGroup
	tags.TagsControllerGroup
	bookmark.BookmarkControllerGroup
	users.UsersControllerGroup
	certificate.CertificateControllerGroup
	progressAchievement.ProgressAchievementControllerGroup
	news.NewsControllerGroup
	mutualFunds.MutualFundsControllerGroup
	login.LoginControllerGroup
	notifications.NotificationsControllerGroup
}

func NewV1ControllerLayer(db db.DBLayer, cfg *config.SecretConfig) V1ControllerLayer {
	return &v1{
		HeathGroup:                         health.NewHealthGroup(),
		CourseControllerGroup:              mdlcourse.NewCourseControllerGroup(db),
		CourseContentControllerGroup:       mdlcoursecontent.NewCourseContentControllerGroup(db),
		CategoryControllerGroup:            category.NewCategoryControllerGroup(db),
		CourseModuleControllerGroup:        courseModules.NewCourseModuleControllerGroup(db),
		InfographicControllerGroup:         infographic.NewInfographicControllerGroup(db),
		EnrollmentControllerLayer:          enrollment.NewControllerLayer(db),
		ResourceControllerGroup:            resource.NewResourceControllerGroup(db),
		QuizControllerGroup:                quiz.NewQuizController(db),
		QuizAttemptsControllerLayer:        quizAttempts.NewQuizAttemptsControllerLayer(db),
		ActivityTrackerControllerGroup:     activitytracker.NewActivityTrackerControllerGroup(db),
		StatsControllerGroup:               stats.NewStatsControllerGroup(db),
		CommentControllerGroup:             comments.NewCommentControllerGroup(db),
		GlossaryControllerGroup:            glossary.NewGlossaryControllerGroup(db),
		TagMappingControllerGroup:          tagMapping.NewTagMappingController(db),
		BookmarkControllerGroup:            bookmark.NewBookmarkControllerGroup(db),
		UsersControllerGroup:               users.NewUsersControllerGroup(db),
		CertificateControllerGroup:         certificate.NewCertificateControllerGroup(db),
		TagsControllerGroup:                tags.NewTagsControllerGroup(db),
		ProgressAchievementControllerGroup: progressAchievement.NewProgressAchievementGroup(db),
		NewsControllerGroup:                news.NewNewsGroup(db),
		MutualFundsControllerGroup:         mutualFunds.NewMutualFundsGroup(db),
		LoginControllerGroup:               login.NewLoginGroup(db),
		NotificationsControllerGroup:       notifications.NewNotificationsGroup(db),
	}
}

package certificate

type CertificateResult struct {
	ID        *int64  `json:"id"`         // Unique ID for the certificate
	UserID    *int64  `json:"user_id"`    // user_id of certificate
	URL       *string `json:"url"`        // url of certificate
	ModelType *string `json:"model_type"` // model_type of certificate
	ModelID   *int64  `json:"model_id"`   // model_id of certificate
}

type GetCertificateByModelTypeRequest struct {
	ModelType *string `form:"model_type" binding:"required"` // model_type of certificate
}

type GetCertificateURLRequest struct {
	ModelID   int64  `uri:"model_id" binding:"required"`
	ModelType string `uri:"model_type" binding:"required,oneof=course quiz"`
}

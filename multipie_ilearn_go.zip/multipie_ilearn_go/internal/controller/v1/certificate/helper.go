package certificate

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/certificate"
	"multipie_ilearn_go/internal/logger"

	"go.uber.org/zap"
)

func (c *certificateController) getCertificateByModelTypeHelper(ctx context.Context, request GetCertificateByModelTypeRequest, userId int64) (*[]dbModel.Certificate, error) {

	certificate, err := c.db.GetCertificateByModelType(ctx, request.ModelType, userId)

	if err != nil {
		logger.Error(ctx, "unable to fetch certificate from db", zap.Error(err))
		return nil, errors.New("unable to fetch certificate from db")
	}

	return certificate, nil
}

func (c *certificateController) getCertificateURLHelper(ctx context.Context, request *GetCertificateURLRequest, userID int64) (*dbModel.Certificate, error) {
	certificate, err := c.db.GetCertificateByModelIDModelType(ctx, &request.ModelID, &request.ModelType, userID)
	if err != nil {
		logger.Error(ctx, "failed to fetch certificate from DB", zap.Error(err))
		return nil, err
	}

	return certificate, nil
}

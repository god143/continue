package certificate

import (
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (c *certificateController) GetCertificateByModelType(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCertificateByModelTypeRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}
	if err := ctx.ShouldBindQuery(&request); err != nil {
		logger.Error(ctx, "invalid request body", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid request body"))
		ctx.JSON(http.StatusBadRequest, resp)
		ctx.Abort()
		return
	}

	getCertificateByModelTypeResp, err := c.getCertificateByModelTypeHelper(ctx, request, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusInternalServerError, resp)
		ctx.Abort()
		return
	}

	resp = utils.NewV1Response(getCertificateByModelTypeResp, nil)
	ctx.JSON(http.StatusOK, resp)
}

func (c *certificateController) GetCertificateDatabyId(ctx *gin.Context) {
	var (
		resp    *utils.Response
		request GetCertificateURLRequest
	)

	userID, err := utils.ExtractUserId(ctx)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer("unauthorized"))
		ctx.JSON(http.StatusUnauthorized, resp)
		return
	}

	if err := ctx.ShouldBindUri(&request); err != nil {
		logger.Error(ctx, "invalid URI parameters", zap.Error(err))
		resp = utils.NewV1Response(nil, utils.StringToPointer("invalid URI parameters"))
		ctx.JSON(http.StatusBadRequest, resp)
		return
	}

	certificate, err := c.getCertificateURLHelper(ctx, &request, userID)
	if err != nil {
		resp = utils.NewV1Response(nil, utils.StringToPointer(err.Error()))
		ctx.JSON(http.StatusNotFound, resp)
		return
	}

	resp = utils.NewV1Response(certificate, nil)
	ctx.JSON(http.StatusOK, resp)
}

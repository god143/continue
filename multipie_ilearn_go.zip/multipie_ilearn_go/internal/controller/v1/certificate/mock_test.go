package certificate

import (
	"context"
	"errors"
	"multipie_ilearn_go/internal/db"
	dbModel "multipie_ilearn_go/internal/db/certificate"
	"multipie_ilearn_go/internal/logger"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockCertificateDB struct {
	mock.Mock
	db.DBLayer
}

func (m *MockCertificateDB) GetCertificateByModelIDModelType(ctx context.Context, modelID *int64, modelType *string, userID int64) (*dbModel.Certificate, error) {
	args := m.Called(ctx, modelID, modelType, userID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*dbModel.Certificate), args.Error(1)
}

func (m *MockCertificateDB) GetCertificateByModelType(ctx context.Context, modelType *string, userID int64) (*[]dbModel.Certificate, error) {
	args := m.Called(ctx, modelType, userID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*[]dbModel.Certificate), args.Error(1)
}

func (m *MockCertificateDB) CreateCertificate(ctx context.Context, c *dbModel.Certificate) (*dbModel.Certificate, error) {
	return nil, nil
}
func (m *MockCertificateDB) UpdateCertificateURL(ctx context.Context, id int64, url string) error {
	return nil
}

func ptr[T any](v T) *T { return &v }

func TestCertificateController(t *testing.T) {
	_ = logger.NewLogger("test", "error", "")
	gin.SetMode(gin.TestMode)

	t.Run("NewControllerConstructor", func(t *testing.T) {
		mDB := new(MockCertificateDB)
		ctrl := NewCertificateControllerGroup(mDB)
		assert.NotNil(t, ctrl)
	})

	t.Run("GetCertificateByModelType_Scenarios", func(t *testing.T) {
		tests := []struct {
			name     string
			params   map[string]string
			userId   interface{}
			setup    func(*MockCertificateDB)
			expected int
		}{
			{
				name:   "Success_Standard",
				params: map[string]string{"model_type": "course"},
				userId: int64(1),
				setup: func(m *MockCertificateDB) {
					m.On("GetCertificateByModelType", mock.Anything, ptr("course"), int64(1)).
						Return(&[]dbModel.Certificate{{ID: ptr(int64(1))}}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:     "Fail_Unauthorized_Missing_User",
				params:   map[string]string{"model_type": "course"},
				userId:   nil,
				setup:    func(m *MockCertificateDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "Fail_Invalid_User_Type",
				params:   map[string]string{"model_type": "course"},
				userId:   "string-id",
				setup:    func(m *MockCertificateDB) {},
				expected: http.StatusUnauthorized,
			},
			{
				name:     "Fail_Binding_Missing_ModelType",
				params:   map[string]string{},
				userId:   int64(1),
				setup:    func(m *MockCertificateDB) {},
				expected: http.StatusBadRequest,
			},
			{
				name:   "Fail_DB_Error",
				params: map[string]string{"model_type": "course"},
				userId: int64(1),
				setup: func(m *MockCertificateDB) {
					m.On("GetCertificateByModelType", mock.Anything, ptr("course"), int64(1)).
						Return(nil, errors.New("db error"))
				},
				expected: http.StatusInternalServerError,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockCertificateDB)
				ctrl := &certificateController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				if tt.userId != nil {
					c.Set("userId", tt.userId)
				}

				q := url.Values{}
				for k, v := range tt.params {
					q.Add(k, v)
				}
				c.Request, _ = http.NewRequest(http.MethodGet, "/?"+q.Encode(), nil)

				tt.setup(mDB)
				ctrl.GetCertificateByModelType(c)
				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})

	t.Run("GetCertificateDatabyId_Scenarios", func(t *testing.T) {
		tests := []struct {
			name      string
			modelId   string
			modelType string
			userId    int64
			setup     func(*MockCertificateDB)
			expected  int
		}{
			{
				name:      "Success_URI_Binding",
				modelId:   "10",
				modelType: "quiz",
				userId:    int64(5),
				setup: func(m *MockCertificateDB) {
					m.On("GetCertificateByModelIDModelType", mock.Anything, ptr(int64(10)), ptr("quiz"), int64(5)).
						Return(&dbModel.Certificate{ID: ptr(int64(1))}, nil)
				},
				expected: http.StatusOK,
			},
			{
				name:      "Fail_Binding_Invalid_OneOf",
				modelId:   "10",
				modelType: "invalid",
				userId:    int64(5),
				setup:     func(m *MockCertificateDB) {},
				expected:  http.StatusBadRequest,
			},
			{
				name:      "Fail_Binding_Non_Numeric_ID",
				modelId:   "abc",
				modelType: "course",
				userId:    int64(5),
				setup:     func(m *MockCertificateDB) {},
				expected:  http.StatusBadRequest,
			},
			{
				name:      "Fail_DB_Not_Found",
				modelId:   "10",
				modelType: "course",
				userId:    int64(5),
				setup: func(m *MockCertificateDB) {
					m.On("GetCertificateByModelIDModelType", mock.Anything, ptr(int64(10)), ptr("course"), int64(5)).
						Return(nil, errors.New("record not found in DB"))
				},
				expected: http.StatusNotFound,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mDB := new(MockCertificateDB)
				ctrl := &certificateController{db: mDB}
				w := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(w)

				c.Set("userId", tt.userId)
				c.Params = []gin.Param{
					{Key: "model_id", Value: tt.modelId},
					{Key: "model_type", Value: tt.modelType},
				}
				c.Request, _ = http.NewRequest(http.MethodGet, "/", nil)

				tt.setup(mDB)
				ctrl.GetCertificateDatabyId(c)
				assert.Equal(t, tt.expected, w.Code)
			})
		}
	})
}

// --- PERFORMANCE BENCHMARKS ---

func BenchmarkGetCertificateByModelType(b *testing.B) {
	// Achieve optimal benchmark results by setting release mode and hoisting setup
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockCertificateDB)

	// Mock the expected DB call outcome once outside the loop
	mDB.On("GetCertificateByModelType", mock.Anything, mock.Anything, mock.Anything).
		Return(&[]dbModel.Certificate{}, nil)

	ctrl := &certificateController{db: mDB}

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Set("userId", int64(1))
	c.Request, _ = http.NewRequest("GET", "/?model_type=course", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetCertificateByModelType(c)
	}
}

func BenchmarkGetCertificateDatabyId(b *testing.B) {
	gin.SetMode(gin.ReleaseMode)
	mDB := new(MockCertificateDB)

	mDB.On("GetCertificateByModelIDModelType", mock.Anything, mock.Anything, mock.Anything, mock.Anything).
		Return(&dbModel.Certificate{}, nil)

	ctrl := &certificateController{db: mDB}
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)

	c.Set("userId", int64(1))
	c.Params = []gin.Param{
		{Key: "model_id", Value: "10"},
		{Key: "model_type", Value: "course"},
	}
	c.Request, _ = http.NewRequest(http.MethodGet, "/", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ctrl.GetCertificateDatabyId(c)
	}
}

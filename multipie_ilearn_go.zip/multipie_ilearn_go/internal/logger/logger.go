package logger

import (
	"context"
	"multipie_ilearn_go/internal/constants"
	"path/filepath"
	"time"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

var logger *zap.Logger

type Log interface {
	Debug(ctx context.Context, msg string, fields ...zapcore.Field)
	Info(ctx context.Context, msg string, fields ...zapcore.Field)
	Error(ctx context.Context, msg string, fields ...zapcore.Field)
	Warn(ctx context.Context, msg string, fields ...zapcore.Field)
	Flush()
	GetLogger() *zap.Logger
}

func NewLogger(env string, logLevel string, logLocation string) error {
	var err error
	loggerConfig := zap.NewProductionConfig()

	loggerConfig.Level = zap.NewAtomicLevelAt(getLogLevel(logLevel))
	loggerConfig.EncoderConfig.FunctionKey = "func"
	loggerConfig.EncoderConfig.EncodeTime = syslogTimeEncoder
	loggerConfig.EncoderConfig.ConsoleSeparator = "|"
	loggerConfig.EncoderConfig.EncodeCaller = myCaller
	if env == constants.ENV_PROD {
		loggerConfig.OutputPaths = append(loggerConfig.OutputPaths, filepath.Join(logLocation, env+".log"))
	}

	logger, err = loggerConfig.Build(zap.AddCallerSkip(1), zap.AddStacktrace(zap.FatalLevel))
	if err != nil {
		return err
	}

	return nil
}

func getLogLevel(level string) zapcore.Level {
	switch level {
	case "debug":
		return zap.DebugLevel
	case "info":
		return zap.InfoLevel
	case "error":
		return zap.ErrorLevel
	default:
		return zap.DebugLevel
	}
}

func syslogTimeEncoder(t time.Time, enc zapcore.PrimitiveArrayEncoder) {
	enc.AppendString(t.Format("Jan 2 15:04:05"))
}

func myCaller(caller zapcore.EntryCaller, enc zapcore.PrimitiveArrayEncoder) {
	enc.AppendString(filepath.Base(caller.FullPath()))
}

func Debug(ctx context.Context, msg string, fields ...zapcore.Field) {
	logger.With(zap.Any("requestId", ctx.Value("requestId")),
		zap.Any("userId", ctx.Value("userId"))).Debug(msg, fields...)
}

func Info(ctx context.Context, msg string, fields ...zapcore.Field) {
	logger.With(zap.Any("requestId", ctx.Value("requestId")),
		zap.Any("userId", ctx.Value("userId"))).Info(msg, fields...)
}

func Warn(ctx context.Context, msg string, fields ...zapcore.Field) {
	logger.With(zap.Any("requestId", ctx.Value("requestId")),
		zap.Any("userId", ctx.Value("userId"))).Warn(msg, fields...)
}

func Error(ctx context.Context, msg string, fields ...zapcore.Field) {
	logger.With(zap.Any("requestId", ctx.Value("requestId")),
		zap.Any("userId", ctx.Value("userId"))).Error(msg, fields...)
}

func Flush() {
	logger.Sync()
}

func GetLogger() *zap.Logger {
	return logger
}

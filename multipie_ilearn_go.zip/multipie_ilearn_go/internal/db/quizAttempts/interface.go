package quizAttempts

import (
	"context"

	"gorm.io/gorm"
)

type quizAttemptsRepo struct {
	db *gorm.DB
}

type QuizAttemptsRepo interface {
	GetQuizAttempts(ctx context.Context, userId int64, quizId int64) (*QuizAttempts, error)
	GetQuizScore(ctx context.Context, userId int64, quizId int64) (*QuizAttempts, error)
	CreateOrUpdateQuizAttempt(ctx context.Context, quizAttempts *QuizAttempts) (*QuizAttempts, error)
	UpdateQuizAttempt(ctx context.Context, quizAttempts *QuizAttempts) (*QuizAttempts, error)
	GetLastAttemptNumber(ctx context.Context, userId int64, quizId int64) (*QuizAttempts, error)
	GetQuizAttemptStatus(ctx context.Context, userId int64, quizId int64) (*QuizAttemptStatus, error)
	CreateQuizAttempt(ctx context.Context, quizAttempt *QuizAttempts) (*QuizAttempts, error)
	BatchCreateQuizAttempts(ctx context.Context, quizAttempt []QuizAttempts) error
}

func NewQuizAttemptsRepo(db *gorm.DB) QuizAttemptsRepo {
	return &quizAttemptsRepo{
		db: db,
	}
}

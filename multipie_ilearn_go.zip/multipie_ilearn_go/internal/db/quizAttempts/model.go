package quizAttempts

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type QuizAttempts struct {
	ID               *int64                            `json:"id,omitempty"`
	UserId           *int64                            `json:"user_id,omitempty"`
	QuizId           *int64                            `json:"quiz_id,omitempty"`
	AttemptNumber    *int64                            `json:"attempt_number,omitempty"`
	Score            *float64                          `json:"score,omitempty"`
	Status           *constants.QuizAttemptsStatusEnum `json:"status,omitempty"`
	HasCheckedAnswer *bool                             `json:"has_checked_answer,omitempty"`
	LastAttemptAt    *time.Time                        `json:"last_attempt_at,omitempty"`
	CreatedAt        *time.Time                        `json:"created_at,omitempty"`
	UpdatedAt        *time.Time                        `json:"updated_at,omitempty"`
}

type QuizAttemptStatus struct {
	HasUserPassed    bool
	HasCheckedAnswer bool
	HasAttempted     bool
	AttemptID        *int64
}

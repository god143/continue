package quizAttempts

import (
	"context"
	"errors"
	"multipie_ilearn_go/internal/constants"

	"gorm.io/gorm"
)

func (c *quizAttemptsRepo) CreateOrUpdateQuizAttempt(ctx context.Context, quizAttempt *QuizAttempts) (*QuizAttempts, error) {
	var existing QuizAttempts

	err := c.db.Where("user_id = ? AND quiz_id = ?", quizAttempt.UserId, quizAttempt.QuizId).First(&existing).Error
	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	if existing.ID != nil {
		// If user has checked answers, block further updates
		if existing.HasCheckedAnswer != nil && *existing.HasCheckedAnswer {
			return nil, errors.New("quiz already submitted and checked — no further attempts allowed")
		}

		// Increment attempt number
		newAttempt := *existing.AttemptNumber + 1
		existing.AttemptNumber = &newAttempt
		existing.Status = quizAttempt.Status
		existing.LastAttemptAt = quizAttempt.LastAttemptAt

		// Update score only if the new score is higher
		if quizAttempt.Score != nil && existing.Score != nil && *quizAttempt.Score > *existing.Score {
			existing.Score = quizAttempt.Score
		}

		if err := c.db.Save(&existing).Error; err != nil {
			return nil, err
		}
		return &existing, nil
	}

	// If no previous attempt, create a new one
	err = c.db.Create(quizAttempt).Error
	if err != nil {
		return nil, err
	}
	return quizAttempt, nil
}

func (c *quizAttemptsRepo) CreateQuizAttempt(ctx context.Context, quizAttempt *QuizAttempts) (*QuizAttempts, error) {
	// Check if attempt already exists (due to unique constraint)
	var existing QuizAttempts
	err := c.db.Where("user_id = ? AND quiz_id = ?", quizAttempt.UserId, quizAttempt.QuizId).First(&existing).Error

	if err == nil {
		return nil, errors.New("quiz attempt already exists for this user and quiz")
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	// Proceed with creation
	if err := c.db.Create(quizAttempt).Error; err != nil {
		return nil, err
	}
	return quizAttempt, nil
}

func (c *quizAttemptsRepo) UpdateQuizAttempt(ctx context.Context, quizAttempt *QuizAttempts) (*QuizAttempts, error) {
	// Fetch existing attempt
	var existing QuizAttempts

	if err := c.db.Where("id = ? AND user_id = ?", quizAttempt.ID, quizAttempt.UserId).First(&existing).Error; err != nil {
		return nil, err
	}

	// Block update if already checked
	if existing.HasCheckedAnswer != nil && *existing.HasCheckedAnswer {
		return nil, errors.New("cannot update quiz attempt after answers have been checked")
	}

	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	updates := map[string]interface{}{}

	// Only update score if new score is higher
	if quizAttempt.Score != nil && existing.Score != nil && *quizAttempt.Score > *existing.Score {
		updates["score"] = *quizAttempt.Score
	}

	// Only allow status change to "pass" or keep it same
	if quizAttempt.Status != nil {

		pass, _ := constants.ParseQuizAttemptsStatusEnum("pass")
		fail, _ := constants.ParseQuizAttemptsStatusEnum("fail")

		if existing.Status != nil && *existing.Status != pass {
			updates["status"] = *quizAttempt.Status
		} else if *existing.Status == pass && *quizAttempt.Status == pass {
			updates["status"] = *quizAttempt.Status
		} else if *existing.Status == fail && *quizAttempt.Status == pass {
			updates["status"] = *quizAttempt.Status
		}
		// else: prevent pass → fail
	}

	// Update has_checked_answer if provided
	if quizAttempt.HasCheckedAnswer != nil {
		updates["has_checked_answer"] = *quizAttempt.HasCheckedAnswer
	}

	// Always increment attempt_number
	if existing.AttemptNumber != nil {
		updates["attempt_number"] = *existing.AttemptNumber + 1
	}

	if len(updates) == 0 {
		tx.Rollback()
		return nil, errors.New("no valid fields to update")
	}

	if err := tx.Model(&QuizAttempts{}).
		Where("id = ? AND user_id = ?", quizAttempt.ID, quizAttempt.UserId).
		Updates(updates).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	// Optionally update the in-memory struct for return
	if val, ok := updates["attempt_number"].(int64); ok {
		existing.AttemptNumber = &val
	}
	if val, ok := updates["score"].(float64); ok {
		existing.Score = &val
	}
	if val, ok := updates["status"].(string); ok {

		status, _ := constants.ParseQuizAttemptsStatusEnum(val)
		existing.Status = &status
	}
	if val, ok := updates["has_checked_answer"].(bool); ok {
		existing.HasCheckedAnswer = &val
	}

	return &existing, nil
}

func (c *quizAttemptsRepo) GetLastAttemptNumber(ctx context.Context, userId int64, quizId int64) (*QuizAttempts, error) {
	var result QuizAttempts

	err := c.db.Model(&QuizAttempts{}).
		Where("user_id = ? AND quiz_id = ?", userId, quizId).
		Order("attempt_number DESC").Limit(1).
		Pluck("attempt_number", &result).Error

	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (c *quizAttemptsRepo) GetQuizScore(ctx context.Context, userId int64, quizId int64) (*QuizAttempts, error) {
	var result QuizAttempts

	err := c.db.Model(&QuizAttempts{}).
		Where("user_id = ? AND quiz_id = ?", userId, quizId).
		Order("attempt_number DESC").Limit(1).
		Pluck("score", &result).Error

	if err != nil {
		return nil, err
	}

	return &result, nil
}

func (c *quizAttemptsRepo) GetQuizAttempts(ctx context.Context, userId int64, quizId int64) (*QuizAttempts, error) {
	var attempt QuizAttempts

	err := c.db.Model(&QuizAttempts{}).
		Select("id, quiz_id, attempt_number, score, status, last_attempt_at, has_checked_answer").
		Where("user_id = ? AND quiz_id = ?", userId, quizId).
		Order("attempt_number DESC").
		Limit(1).
		Scan(&attempt).Error

	if err != nil {
		return nil, err
	}

	return &attempt, nil
}

func (c *quizAttemptsRepo) GetQuizAttemptStatus(ctx context.Context, userId int64, quizId int64) (*QuizAttemptStatus, error) {
	var result struct {
		ID               *int64
		Status           string
		HasCheckedAnswer bool
	}

	err := c.db.WithContext(ctx).
		Table("quiz_attempts").
		Select("id, status, has_checked_answer").
		Where("user_id = ? AND quiz_id = ?", userId, quizId).
		Order("attempt_number DESC").
		Limit(1).
		Scan(&result).Error

	if err != nil {
		return nil, err
	}

	hasAttempted := result.Status != ""

	return &QuizAttemptStatus{
		AttemptID:        result.ID,
		HasUserPassed:    result.Status == "pass",
		HasCheckedAnswer: result.HasCheckedAnswer,
		HasAttempted:     hasAttempted,
	}, nil
}

func (q *quizAttemptsRepo) BatchCreateQuizAttempts(ctx context.Context, quizAttempts []QuizAttempts) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(quizAttempts, len(quizAttempts)).Error; err != nil {
		return q.handleTransaction(tx, err)
	}

	return q.handleTransaction(tx, nil)
}

func (q *quizAttemptsRepo) handleTransaction(tx *gorm.DB, err error) error {
	if err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit().Error
}

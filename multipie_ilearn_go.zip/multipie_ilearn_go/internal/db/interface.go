package db

import (
	"multipie_ilearn_go/internal/db/activeStorage"
	activitytracking "multipie_ilearn_go/internal/db/activityTracking"
	"multipie_ilearn_go/internal/db/bookmark"
	"multipie_ilearn_go/internal/db/category"
	"multipie_ilearn_go/internal/db/certificate"
	"multipie_ilearn_go/internal/db/comments"
	mdlcourse "multipie_ilearn_go/internal/db/course"
	mdlcoursecontent "multipie_ilearn_go/internal/db/courseContent"
	"multipie_ilearn_go/internal/db/courseModules"
	enrollment "multipie_ilearn_go/internal/db/enrollment"
	"multipie_ilearn_go/internal/db/glossary"
	"multipie_ilearn_go/internal/db/infographic"
	"multipie_ilearn_go/internal/db/infographicImages"
	"multipie_ilearn_go/internal/db/likes"
	login "multipie_ilearn_go/internal/db/login"
	"multipie_ilearn_go/internal/db/notifications"
	"multipie_ilearn_go/internal/db/progressAchievement"
	"multipie_ilearn_go/internal/db/question"
	"multipie_ilearn_go/internal/db/quiz"
	"multipie_ilearn_go/internal/db/quizAttempts"
	"multipie_ilearn_go/internal/db/resource"
	"multipie_ilearn_go/internal/db/tagMapping"
	"multipie_ilearn_go/internal/db/tags"
	"multipie_ilearn_go/internal/db/users"

	"gorm.io/gorm"
)

type dbLayer struct {
	mdlcourse.CourseRepo
	mdlcoursecontent.CourseContentRepo
	category.CategoryRepo
	activeStorage.ActiveStorageRepo
	courseModules.CourseModuleRepo
	infographic.InfographicRepo
	infographicImages.InfographicImageRepo
	enrollment.EnrollmentRepo
	resource.ResourseRepo
	question.QuestionRepo
	quiz.QuizRepo
	quizAttempts.QuizAttemptsRepo
	bookmark.BookmarkRepo
	users.UsersRepo
	activitytracking.ActivityTrackingRepo
	comments.CommentRepo
	glossary.GlossaryRepo
	tags.TagsRepo
	tagMapping.TagMappingRepo
	likes.LikeRepo
	certificate.CertificateRepo
	progressAchievement.ProgressAchievementRepo
	login.LoginRepo
	notifications.NotificationsRepo
}

type DBLayer interface {
	mdlcourse.CourseRepo
	mdlcoursecontent.CourseContentRepo
	category.CategoryRepo
	activeStorage.ActiveStorageRepo
	courseModules.CourseModuleRepo
	infographic.InfographicRepo
	infographicImages.InfographicImageRepo
	enrollment.EnrollmentRepo
	resource.ResourseRepo
	question.QuestionRepo
	quiz.QuizRepo
	quizAttempts.QuizAttemptsRepo
	bookmark.BookmarkRepo
	users.UsersRepo
	activitytracking.ActivityTrackingRepo
	comments.CommentRepo
	glossary.GlossaryRepo
	tags.TagsRepo
	tagMapping.TagMappingRepo
	likes.LikeRepo
	certificate.CertificateRepo
	progressAchievement.ProgressAchievementRepo
	login.LoginRepo
	notifications.NotificationsRepo
}

func NewDbLayer(multipieIlearnDBClient *gorm.DB) DBLayer {
	return &dbLayer{
		mdlcourse.NewCourseRepo(multipieIlearnDBClient),
		mdlcoursecontent.NewCourseContentRepo(multipieIlearnDBClient),
		category.NewCategoryRepo(multipieIlearnDBClient),
		activeStorage.NewActiveStorageRepo(multipieIlearnDBClient),
		courseModules.NewCourseModuleRepo(multipieIlearnDBClient),
		infographic.NewInfographicRepo(multipieIlearnDBClient),
		infographicImages.NewInfographicImageRepo(multipieIlearnDBClient),
		enrollment.NewEnrollmentRepo(multipieIlearnDBClient),
		resource.NewResourseRepo(multipieIlearnDBClient),
		question.NewQuestionRepo(multipieIlearnDBClient),
		quiz.NewQuizRepo(multipieIlearnDBClient),
		quizAttempts.NewQuizAttemptsRepo(multipieIlearnDBClient),
		bookmark.NewBookmarkRepo(multipieIlearnDBClient),
		users.NewUsersRepo(multipieIlearnDBClient),
		activitytracking.NewActivityTrackingRepo(multipieIlearnDBClient),
		comments.NewCommentRepo(multipieIlearnDBClient),
		glossary.NewGlossaryRepo(multipieIlearnDBClient),
		tags.NewTagsRepo(multipieIlearnDBClient),
		tagMapping.NewTagMappingRepo(multipieIlearnDBClient),
		likes.NewLikeRepo(multipieIlearnDBClient),
		certificate.NewCertificateRepo(multipieIlearnDBClient),
		progressAchievement.NewProgressAchievementRepo(multipieIlearnDBClient),
		login.NewLoginRepo(multipieIlearnDBClient),
		notifications.NewNotificationsRepo(multipieIlearnDBClient),
	}
}

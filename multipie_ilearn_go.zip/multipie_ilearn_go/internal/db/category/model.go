package category

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

// Category represents the structure of the `categories` table in the database.
type Category struct {
	ID             *int                        `json:"id,omitempty"`          // Unique ID for the category
	Name           *string                     `json:"name,omitempty"`        // Name of the category
	Description    *string                     `json:"description,omitempty"` // Description of the category
	Parent         *int                        `json:"parent,omitempty"`      // Parent category ID (nullable)
	Type           *constants.CategoryTypeEnum `json:"type,omitempty"`        // Type of the category (nullable)
	Icon           *string                     `json:"icon,omitempty"`        // Icon URL
	Visible        *bool                       `json:"visible,omitempty"`     //toggle visibility of the category
	Banner         *string                     `json:"banner,omitempty"`      // Banner URL
	Category_order *int                        `json:"category_order,omitempty"`
	CreatedAt      *time.Time                  `json:"created_at"` // Timestamp when the category was created
	UpdatedAt      *time.Time                  `json:"updated_at"` // Timestamp when the category was last updated
}

type SubCategoryWithParent struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

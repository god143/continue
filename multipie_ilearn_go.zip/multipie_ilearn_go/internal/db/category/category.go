package category

import (
	"context"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/utils"
)

// Get all active categories
func (c *categoryRepo) GetParentCategories(ctx context.Context, visibility *bool) ([]Category, error) {
	var (
		result []Category
	)

	query := c.db.Where("parent is NULL AND type is NULL").Order("category_order ASC")

	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}

	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}
	return result, nil
}

// Fetch a category by its ID
func (c *categoryRepo) GetCategoryByID(ctx context.Context, id int, visibility *bool) (*Category, error) {
	var (
		result Category
	)

	query := c.db.Where("id = ?", id)

	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}

	if err := query.First(&result).Error; err != nil {
		return nil, err
	}

	return &result, nil
}

// Get all active sub categories of a parent
func (c *categoryRepo) GetSubCategoriesByParent(ctx context.Context, parentID int, visibility *bool) ([]Category, error) {
	var (
		result []Category
	)

	query := c.db.Where("parent = ?", parentID).Order("category_order ASC")

	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}

	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}

	return result, nil
}

// Get all subcategories by type
func (c *categoryRepo) GetSubCategoriesByType(ctx context.Context, subCategoriesType constants.CategoryTypeEnum, visibility *bool) ([]Category, error) {
	var (
		result []Category
	)

	query := c.db.Where("parent IS NULL AND type = ?", subCategoriesType).Order("category_order ASC")
	if visibility != nil {
		query = query.Where("visible = ?", visibility)

	}

	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}

	return result, nil
}

// Mark a category as deleted by setting visible = false
func (c *categoryRepo) DisbaleCategory(ctx context.Context, id int) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.Model(&Category{}).Where("id = ?", id).Updates(&Category{
		Visible: utils.BoolToPointer(false),
	}).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Update the properties of an existing category
func (c *categoryRepo) UpdateCategory(ctx context.Context, category Category) (*Category, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&Category{}).Where("id = ?", category.ID).Updates(&Category{
		Icon:           category.Icon,
		Name:           category.Name,
		Description:    category.Description,
		Parent:         category.Parent,
		Banner:         category.Banner,
		Type:           category.Type,
		Visible:        category.Visible,
		Category_order: category.Category_order,
	}).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return &category, nil

}

// Create a new category
func (c *categoryRepo) CreateCategory(ctx context.Context, category *Category) (*Category, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(category).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return category, nil

}

// Batch Insertion in categories table
func (c *categoryRepo) BatchCreateCategories(ctx context.Context, categories []Category) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(categories, len(categories)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Batch Updation in categories table
func (c *categoryRepo) BatchUpdateCategories(ctx context.Context, categories []Category) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, item := range categories {
		if err := tx.Model(&Category{}).Where("id = ?", item.ID).Updates(&Category{
			Icon:           item.Icon,
			Name:           item.Name,
			Description:    item.Description,
			Parent:         item.Parent,
			Banner:         item.Banner,
			Type:           item.Type,
			Visible:        item.Visible,
			Category_order: item.Category_order,
		}).Error; err != nil {
			tx.Rollback()
			return err
		}
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c *categoryRepo) GetSubCategoriesWithParent(ctx context.Context, subCategoriesType string, visibility *bool) ([]SubCategoryWithParent, error) {
	var results []SubCategoryWithParent

	query := c.db.Table("categories AS c").
		Select("c.id, p.name AS name").
		Joins("JOIN categories p ON c.parent = p.id").
		Where("c.type = ?", subCategoriesType).Order("p.category_order ASC, p.id ASC")

	if visibility != nil {
		query = query.Where("c.visible = ?", *visibility)
	}

	if err := query.Scan(&results).Error; err != nil {
		return nil, err
	}

	return results, nil
}

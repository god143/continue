package category

import (
	"context"
	"multipie_ilearn_go/internal/constants"

	"gorm.io/gorm"
)

type categoryRepo struct {
	db *gorm.DB
}

type CategoryRepo interface {
	GetParentCategories(ctx context.Context, visibility *bool) ([]Category, error)
	GetCategoryByID(ctx context.Context, id int, visibility *bool) (*Category, error)
	GetSubCategoriesByParent(ctx context.Context, parentID int, visibility *bool) ([]Category, error)
	GetSubCategoriesByType(ctx context.Context, subCategoriesType constants.CategoryTypeEnum, visibility *bool) ([]Category, error)
	DisbaleCategory(ctx context.Context, id int) error
	UpdateCategory(ctx context.Context, category Category) (*Category, error)
	CreateCategory(ctx context.Context, category *Category) (*Category, error)
	BatchUpdateCategories(ctx context.Context, categories []Category) error
	BatchCreateCategories(ctx context.Context, categories []Category) error
	GetSubCategoriesWithParent(ctx context.Context, subCategoriesType string, visibility *bool) ([]SubCategoryWithParent, error)
}

func NewCategoryRepo(db *gorm.DB) CategoryRepo {
	return &categoryRepo{
		db: db,
	}
}

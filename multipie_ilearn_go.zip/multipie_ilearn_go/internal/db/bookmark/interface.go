package bookmark

import (
	"context"
	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

type bookmarkRepo struct {
	db *gorm.DB
}

type BookmarkRepo interface {
	CreateBookmark(ctx context.Context, bookmark *Bookmark) (*Bookmark, error)
	GetBookmarks(ctx context.Context, page int64, pageSize int64, userID int64, modelType string, subType string) (*utils.Pagination, error)
	GetBookmarksWithPagination(ctx context.Context, page int64, pageSize int64, userID int64, modelType string) (*utils.Pagination, error)
	DeleteBookmark(ctx context.Context, userId int64, bookmarkId *int64) error
	GetBookmarkByCustomParams(ctx context.Context, resourceId []int, modelType []string, subType []string, userId int64) ([]Bookmark, error)
	BatchCreateBookmark(ctx context.Context, bookmark []Bookmark) error
}

func NewBookmarkRepo(db *gorm.DB) BookmarkRepo {
	return &bookmarkRepo{
		db: db,
	}
}

package bookmark

import (
	"context"
	"errors"
	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

// Get list of Bookmarks of a user
func (c *bookmarkRepo) GetBookmarks(ctx context.Context, page int64, pageSize int64, userID int64, modelType string, subType string) (*utils.Pagination, error) {
	var (
		result []Bookmark
	)

	pagination := utils.Pagination{
		Page:     int(page),
		PageSize: int(pageSize),
	}

	query := c.db.Where("user_id = ? AND model_type = ?", userID, modelType).Find(&result).Order("id DESC")

	if subType != "" {
		query = query.Where("sub_type =?", subType)
	}
	if err := utils.Paginate(c.db, &result, &pagination, query); err != nil {
		return nil, err
	}

	pagination.Data = result

	return &pagination, nil
}

// Get list of Bookmarks of a user
func (c *bookmarkRepo) GetBookmarksWithPagination(ctx context.Context, page int64, pageSize int64, userID int64, modelType string) (*utils.Pagination, error) {
	var (
		result []Bookmark
	)

	pagination := utils.Pagination{
		Page:     int(page),
		PageSize: int(pageSize),
	}
	query := c.db.Where("user_id = ? AND model_type = ?", userID, modelType).Find(&result).Order("id DESC")
	if err := utils.Paginate(c.db, &result, &pagination, query); err != nil {
		return nil, err
	}

	return &pagination, nil
}

// Create a new bookmark
func (c *bookmarkRepo) CreateBookmark(ctx context.Context, bookmark *Bookmark) (*Bookmark, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(bookmark).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return bookmark, nil

}

// Delete a bookmark if bookmarkId is provided delete that bookmark of particular user and if bookmarkId is not provided delete all bookmarks
func (c *bookmarkRepo) DeleteBookmark(ctx context.Context, userId int64, bookmarkId *int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	var result *gorm.DB
	if bookmarkId != nil {

		result = tx.Model(&Bookmark{}).Where("user_id = ? AND id = ?", userId, bookmarkId).Delete(&Bookmark{})
		if result.RowsAffected == 0 {
			tx.Rollback()
			return errors.New("no bookmark found with the given user_id and bookmark_id")
		}

	} else {
		result = tx.Model(&Bookmark{}).Where("user_id = ?", userId).Delete(&Bookmark{})
		if result.RowsAffected == 0 {
			tx.Rollback()
			return errors.New("no bookmark found with the given user_id")
		}

	}
	if result.Error != nil {
		tx.Rollback()
		return result.Error
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c *bookmarkRepo) GetBookmarkByCustomParams(ctx context.Context, resourceId []int, modelType []string, subType []string, userId int64) ([]Bookmark, error) {
	var bookmark []Bookmark

	query := c.db.Table("bookmarks").Where("model_type IN (?) AND model_id IN (?) AND user_id = ?", modelType, resourceId, userId)

	if len(subType) > 0 {
		query = query.Where("sub_type IN (?)", subType)
	}

	if err := query.Find(&bookmark).Error; err != nil {
		return nil, err
	}

	return bookmark, nil
}

func (c *bookmarkRepo) BatchCreateBookmark(ctx context.Context, bookmark []Bookmark) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(bookmark, len(bookmark)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

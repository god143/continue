package bookmark

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

// Bookmark represents the structure of the `bookmarks` table in the database.
type Bookmark struct {
	ID        *int64                           `json:"id,omitempty"`         // Unique ID for bookmark
	UserId    *int64                           `json:"user_id,omitempty"`    // user id in multipie auth
	ModelId   *int64                           `json:"model_id,omitempty"`   // model id in from different types of contents
	ModelType *constants.BookmarkModelTypeEnum `json:"model_type,omitempty"` // type of the model
	SubType   *constants.BookmarkSubTypeEnum   `json:"sub_type,omitempty"`
	Name      *string                          `json:"name,omitempty"` // Name of the model
	CreatedAt *time.Time                       `json:"-"`              // Timestamp when the user was created
	UpdatedAt *time.Time                       `json:"-"`              // Timestamp when the user was last updated
}

package likes

import (
	"context"
)

func (r *likeRepo) AddLike(ctx context.Context, userID, modelID int64, modelType string) error {
	like := &Like{
		UserID:    userID,
		ModelID:   modelID,
		ModelType: modelType,
	}

	err := r.db.WithContext(ctx).
		Where("user_id = ? AND model_id = ? AND model_type = ?", userID, modelID, modelType).
		FirstOrCreate(&like).Error

	return err
}

func (r *likeRepo) RemoveLike(ctx context.Context, userID, modelID int64, modelType string) error {
	err := r.db.WithContext(ctx).
		Where("user_id = ? AND model_id = ? AND model_type = ?", userID, modelID, modelType).
		Delete(&Like{}).Error

	return err
}

func (r *likeRepo) GetLikesCount(ctx context.Context, modelID int64, modelType string) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&Like{}).
		Where("model_id = ? AND model_type = ?", modelID, modelType).
		Count(&count).Error

	return count, err
}

func (r *likeRepo) HasUserLiked(ctx context.Context, userID, modelID int64, modelType string) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&Like{}).
		Where("user_id = ? AND model_id = ? AND model_type = ?", userID, modelID, modelType).
		Count(&count).Error

	return count > 0, err
}

func (c *likeRepo) BatchCreateLikes(ctx context.Context, like []Like) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(like, len(like)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

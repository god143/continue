package likes

import (
	"context"

	"gorm.io/gorm"
)

type likeRepo struct {
	db *gorm.DB
}

type LikeRepo interface {
	AddLike(ctx context.Context, userID, modelID int64, modelType string) error
	RemoveLike(ctx context.Context, userID, modelID int64, modelType string) error
	GetLikesCount(ctx context.Context, modelID int64, modelType string) (int64, error)
	HasUserLiked(ctx context.Context, userID, modelID int64, modelType string) (bool, error)
	BatchCreateLikes(ctx context.Context, course []Like) error
}

func NewLikeRepo(db *gorm.DB) LikeRepo {
	return &likeRepo{
		db: db,
	}
}

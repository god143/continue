package likes

import "time"

type Like struct {
	ID        int64     `json:"id"`
	UserID    int64     `json:"user_id"`
	ModelID   int64     `json:"model_id"`
	ModelType string    `json:"model_type"`
	CreatedAt time.Time `json:"-"`
	UpdatedAt time.Time `json:"-"`
}

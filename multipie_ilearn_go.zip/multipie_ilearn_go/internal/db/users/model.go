package users

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

// Users represents the structure of the `users` table in the database.
type Users struct {
	ID              *int64                    `json:"id,omitempty"`           // Unique ID for the user
	Username        *string                   `json:"username,omitempty"`     // UserName of the user
	DisplayName     *string                   `json:"display_name,omitempty"` // DisplayName of the user
	FirstName       *string                   `json:"first_name,omitempty"`   // First Name user ID
	LastName        *string                   `json:"last_name,omitempty"`    // Last Name of the user
	Mobile          *string                   `json:"mobile,omitempty"`       // Mobile no of the user
	Email           *string                   `json:"email,omitempty"`        // Email of the user
	Role            *constants.UserRoleEnum   `json:"role,omitempty"`         // Role of the user
	Status          *constants.UserStatusEnum `json:"status,omitempty"`       // Status of the user
	Uid             *int64                    `json:"uid,omitempty"`          // user id in multipie auth
	CreatedAt       *time.Time                `json:"-"`                      // Timestamp when the user was created
	UpdatedAt       *time.Time                `json:"-"`                      // Timestamp when the user was last updated
	FirstAccess     *time.Time                `json:"-"`
	LastAccess      *time.Time                `json:"-"`
	ViaLogin        *string                   `json:"via_login,omitempty"`
	SignInCount     *int64                    `json:"sign_in_count,omitempty"`
	IdirectUsername *string                   `json:"idirect_username,omitempty"`
	AccountSource   *string                   `json:"account_source,omitempty"`
}

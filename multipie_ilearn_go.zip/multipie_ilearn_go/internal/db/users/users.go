package users

import (
	"context"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/utils"
)

// Get all users
func (c *usersRepo) GetUsers(ctx context.Context, page int64, pageSize int64) (*utils.Pagination, error) {
	var (
		result []Users
	)

	pagination := utils.Pagination{
		Page:     int(page),
		PageSize: int(pageSize),
	}
	query := c.db.Order("id ASC")
	if err := utils.Paginate(c.db, &result, &pagination, query); err != nil {
		return nil, err
	}

	return &pagination, nil
}

func (c *usersRepo) GetUsersByMobile(ctx context.Context, mobile string) ([]Users, error) {
	var users []Users

	err := c.db.WithContext(ctx).Where("mobile = ?", mobile).Find(&users).Error
	if err != nil {
		return nil, err
	}

	return users, nil
}

// Fetch a user by its UID
func (c *usersRepo) GetUserByUID(ctx context.Context, uid int64) (*Users, error) {
	var (
		result Users
	)

	if err := c.db.Where("uid = ?", uid).First(&result).Error; err != nil {
		return nil, err
	}

	return &result, nil
}

func (c *usersRepo) UpdateIdirectUsernameByMobile(ctx context.Context, userid int64, newUsername string) (*Users, error) {
	var user Users

	// Updates the field and loads the updated record into the 'user' struct
	result := c.db.WithContext(ctx).
		Model(&user).
		Where("id = ?", userid).
		Update("idirect_username", newUsername).
		First(&user)

	if result.Error != nil {
		return nil, result.Error
	}

	return &user, nil
}

// func (c *usersRepo) GetUsersByEmail(ctx context.Context, email string, userId int64) (*Users, error) {
// 	var (
// 		result Users
// 	)

// 	if err := c.db.Where("email = ?", email).Where("uid = ?", userId).First(&result).Error; err != nil {
// 		return nil, err
// 	}

// 	return &result, nil
// }

// Update the existing user
func (c usersRepo) UpdateUsers(ctx context.Context, users Users) (*Users, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&Users{}).Where("id = ?", users.ID).Updates(&Users{
		DisplayName:     users.DisplayName,
		Username:        users.Username,
		FirstName:       users.FirstName,
		LastName:        users.LastName,
		Mobile:          users.Mobile,
		Email:           users.Email,
		ViaLogin:        users.ViaLogin,
		SignInCount:     users.SignInCount,
		IdirectUsername: users.IdirectUsername,
		Uid:             users.ID,
	}).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return &users, nil

}

func (c *usersRepo) GetUserByIDirectUsername(ctx context.Context, username string) (*Users, error) {
	var (
		result Users
	)

	if err := c.db.Where("idirect_username = ?", username).First(&result).Error; err != nil {
		return nil, err
	}

	return &result, nil
}

// Create a new user
func (c *usersRepo) CreateUsers(ctx context.Context, users *Users) (*Users, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(users).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return users, nil

}

// Lock a user
func (c usersRepo) LockUser(ctx context.Context, userID int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Users{}).Where("id = ?", userID).Update("status", constants.UserStatusEnumBlocked)
	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c usersRepo) UnLockUser(ctx context.Context, userID int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Users{}).Where("id = ?", userID).Update("status", constants.UserStatusEnumActive)
	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Lock a user
func (c usersRepo) UpdateStatus(ctx context.Context, userID int64, status string) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Users{}).Where("uid = ?", userID).Update("status", status)
	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Make user admin
func (c usersRepo) MakeAdmin(ctx context.Context, userID int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Users{}).Where("id = ?", userID).Update("role", constants.UserRoleEnumAdmin)
	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c *usersRepo) BatchCreateUser(ctx context.Context, user []Users) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(user, len(user)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

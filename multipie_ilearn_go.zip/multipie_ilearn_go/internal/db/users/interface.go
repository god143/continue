package users

import (
	"context"

	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

type usersRepo struct {
	db *gorm.DB
}

type UsersRepo interface {
	GetUserByUID(ctx context.Context, uid int64) (*Users, error)
	GetUserByIDirectUsername(ctx context.Context, username string) (*Users, error)
	UpdateIdirectUsernameByMobile(ctx context.Context, userid int64, newUsername string) (*Users, error)
	UpdateUsers(ctx context.Context, users Users) (*Users, error)
	CreateUsers(ctx context.Context, users *Users) (*Users, error)
	GetUsers(ctx context.Context, page int64, pageSize int64) (*utils.Pagination, error)
	LockUser(ctx context.Context, userID int64) error
	UnLockUser(ctx context.Context, userID int64) error
	MakeAdmin(ctx context.Context, userID int64) error
	BatchCreateUser(ctx context.Context, users []Users) error
	GetUsersByMobile(ctx context.Context, mobile string) ([]Users, error)
	// GetUsersByEmail(ctx context.Context, mobile string, userId int64) (*Users, error)
	UpdateStatus(ctx context.Context, userId int64, status string) error
}

func NewUsersRepo(db *gorm.DB) UsersRepo {
	return &usersRepo{
		db: db,
	}
}

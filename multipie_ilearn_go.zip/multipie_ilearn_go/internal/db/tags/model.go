package tags

import (
	"time"
)

type Tags struct {
	ID        *int64     `json:"id"`
	Key       *string    `json:"key"`
	CreatedAt *time.Time `json:"-"`
	UpdatedAt *time.Time `json:"-"`
}

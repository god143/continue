package tags

import (
	"context"

	"gorm.io/gorm"
)

type tagsRepo struct {
	db *gorm.DB
}

type TagsRepo interface {
	CreateTag(ctx context.Context, tag *Tags) error
	BatchCreateTag(ctx context.Context, tags []Tags) error
	BatchUpdateTag(ctx context.Context, tags []Tags) error
	UpdateTag(ctx context.Context, tag *Tags) error
	DeleteTag(ctx context.Context, tag *Tags) error
	GetTag(ctx context.Context) ([]Tags, error)
	GetTagKeysByModel(ctx context.Context, modelID int64) (*[]string, error)
}

func NewTagsRepo(db *gorm.DB) TagsRepo {
	return &tagsRepo{
		db: db,
	}
}

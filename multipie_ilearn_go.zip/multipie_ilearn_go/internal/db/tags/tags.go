package tags

import (
	"context"
	"errors"

	"gorm.io/gorm"
)

/*
CreateTag....creates key in database
*/
func (t *tagsRepo) CreateTag(ctx context.Context, tag *Tags) error {
	tx := t.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.Create(tag).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil

}

/*
UpdateTag....update key of particular id in database
*/
func (c *tagsRepo) UpdateTag(ctx context.Context, tags *Tags) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	result := tx.Model(&Tags{}).Where("id = ?", tags.ID).Updates(&Tags{
		Key: tags.Key,
	})

	if result.RowsAffected == 0 {
		tx.Rollback()
		return errors.New("no tag found with given id")
	}

	if result.Error != nil {
		tx.Rollback()
		return result.Error
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil

}

/*
DeleteTag....delete key of particular id in database
*/
func (c *tagsRepo) DeleteTag(ctx context.Context, tag *Tags) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	result := tx.Delete(tag)

	if result.RowsAffected == 0 {
		tx.Rollback()
		return errors.New("no tag found with given id")
	}

	if result.Error != nil {
		tx.Rollback()
		return result.Error
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil

}

/*
GetTag.... fetch all keys in ascending order from database
*/
func (c *tagsRepo) GetTag(ctx context.Context) ([]Tags, error) {

	var taglist []Tags

	if err := c.db.Model(&Tags{}).Order("`key` ASC").Find(&taglist).Error; err != nil {
		return nil, err
	}
	return taglist, nil
}

/*
BatchCreateTag....create keys in database through csv file
*/
func (t *tagsRepo) BatchCreateTag(ctx context.Context, tags []Tags) error {
	tx := t.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}
	if err := tx.CreateInBatches(tags, len(tags)).Error; err != nil {
		tx.Rollback()
		return err
	}
	if err := tx.Commit().Error; err != nil {
		return err
	}
	return nil
}

/*
BatchUpdateTag....update keys(of ids from csv file) in database
*/
func (t *tagsRepo) BatchUpdateTag(ctx context.Context, tags []Tags) error {
	tx := t.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}
	for _, item := range tags {
		if err := t.updateTag(tx, &item); err != nil {
			tx.Rollback()
			return err
		}
	}
	if err := tx.Commit().Error; err != nil {
		return err
	}
	return nil
}

func (t *tagsRepo) updateTag(tx *gorm.DB, tags *Tags) error {
	return tx.Model(&Tags{}).Where("id = ?", tags.ID).Updates(&Tags{
		Key: tags.Key,
	}).Error
}

func (r *tagsRepo) GetTagKeysByModel(ctx context.Context, modelID int64) (*[]string, error) {
	var tagKeys *[]string

	err := r.db.WithContext(ctx).
		Table("tags").
		Joins("INNER JOIN tag_mappings tm ON tm.tag_id = tags.id").
		Where("tm.model_id = ?", modelID).
		Pluck("tags.key", &tagKeys).Error

	if err != nil {
		return nil, err
	}
	return tagKeys, nil
}

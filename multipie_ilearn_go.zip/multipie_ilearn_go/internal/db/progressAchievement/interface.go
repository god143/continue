package progressAchievement

import (
	"context"

	"multipie_ilearn_go/internal/db/courseModules"

	"gorm.io/gorm"
)

type progressAchievementRepo struct {
	db *gorm.DB
}

type ProgressAchievementRepo interface {
	GetInProgressCourses(ctx context.Context, userID int64) ([]Enrollments, error)
	GetCourseRemainingTime(ctx context.Context, courseModuleId []courseModules.CourseModule, totalCourseTime int64, userID int64) (int64, int64, error)
	ProgressAndAchivement(ctx context.Context, userID int64) ([]CourseResult, error)
}

func NewProgressAchievementRepo(db *gorm.DB) ProgressAchievementRepo {
	return &progressAchievementRepo{
		db: db,
	}
}

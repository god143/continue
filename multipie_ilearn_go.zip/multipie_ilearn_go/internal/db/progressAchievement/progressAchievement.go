package progressAchievement

import (
	"context"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/db/courseModules"
)

func (ipc *progressAchievementRepo) GetInProgressCourses(ctx context.Context, userID int64) ([]Enrollments, error) {
	var courses []Enrollments

	query := ipc.db.Select("course_id").Where("status =?", constants.STATUS_IN_PROGRESS).Where("user_id=?", userID)

	if err := query.Find(&courses).Error; err != nil {
		return nil, err
	}
	return courses, nil
}

func (ipc *progressAchievementRepo) GetCourseRemainingTime(ctx context.Context, courseModuleIds []courseModules.CourseModule, totalCourseTime int64, userID int64) (int64, int64, error) {
	var details CourseTimeResult

	var courseModuleIdList []int
	for _, ids := range courseModuleIds {
		courseModuleIdList = append(courseModuleIdList, *ids.ID)
	}

	err := ipc.db.Table("user_activities AS ua").
		Select(`
		COALESCE(SUM(JSON_EXTRACT(ua.additional_data,'$.total_watch_time')),0)
		 AS TotalSpentTime, ua.updated_at AS RecentUpdatedTime`).
		Where("ua.course_module_id IN ?", courseModuleIdList).
		Where("ua.user_id = ?", userID).Scan(&details).Error

	if err != nil {
		return 0, 0, err
	}

	//	updatedTime := details.RecentUpdatedTime.Unix()
	updatedTime := details.RecentUpdatedTime.Unix()
	remainingTime := totalCourseTime - int64(details.TotalSpentTime)
	return remainingTime, updatedTime, nil
}

func (ipc *progressAchievementRepo) ProgressAndAchivement(ctx context.Context, userID int64) ([]CourseResult, error) {
	var results []CourseResult

	err := ipc.db.Table("enrollments AS e").
		Select(`
		c.id AS course_id,
		c.fullname AS course_name,
		c.summary,
		c.format,
		c.views,
		c.duration,
		(COUNT(DISTINCT cm.id) - 1) AS module_count,
		-- Calculate Remaining Time: Course Total - Sum of all module watch times
		(c.duration - COALESCE(SUM(JSON_EXTRACT(ua.additional_data, '$.total_watch_time')), 0)) AS remaining_time,
		-- Get the most recent activity timestamp
		UNIX_TIMESTAMP(MAX(ua.updated_at))AS updated_time`).
		Joins("JOIN courses AS c ON e.course_id = c.id").
		Joins("JOIN course_modules AS cm ON c.id = cm.course_id").
		// LEFT JOIN user_activities to include courses even if no time has been spent yet
		Joins("LEFT JOIN user_activities AS ua ON cm.id = ua.course_module_id AND ua.user_id = e.user_id").
		Where("e.status = ? AND e.user_id = ? AND c.visible=?", constants.STATUS_IN_PROGRESS, userID, 1).
		Group("c.id").
		Order("updated_time DESC"). // <--- Add this line to sort newest activity first
		Scan(&results).Error

	if err != nil {
		return results, err
	}
	return results, nil
}

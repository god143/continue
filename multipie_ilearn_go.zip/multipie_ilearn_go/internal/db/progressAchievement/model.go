package progressAchievement

import "time"

type Enrollment struct {
	ID            *int64  `json:"id"`
	Name          *string `json:"name"`
	RemainingTime *int64  `json:"duration"`
	VideoCount    *int64  `json:"video_count"`
}

type Enrollments struct {
	ID             *int64     `json:"id,omitempty"`              // Unique ID for the enrollment
	UserID         *int64     `json:"user_id,omitempty"`         // user_id of enrollment
	CourseID       *int64     `json:"course_id,omitempty"`       // Course_id of the Enrollment
	Status         *string    `json:"status,omitempty"`          // status (nullable)
	EnrollmentDate *time.Time `json:"enrollment_date,omitempty"` //enrollment_date
	CreatedAt      *time.Time `json:"-"`                         // Timestamp when the Enrollment was created
	UpdatedAt      *time.Time `json:"-"`                         // Timestamp when the Enrollment was last updated
}

type CourseTimeResult struct {
	TotalSpentTime    float64    `json:"totalspentTime"`
	RecentUpdatedTime *time.Time `json:"recentUpdatedTime"`
}

type CourseResult struct {
	CourseID      uint    `gorm:"column:course_id" json:"course_id"`
	CourseName    string  `gorm:"column:course_name" json:"course_name"`
	RemainingTime float64 `gorm:"column:remaining_time" json:"remaining_time"`
	ModuleCount   int     `gorm:"column:module_count" json:"module_count"`
	Format        string  `gorm:"column:format" json:"format"`
	Views         int     `gorm:"column:views" json:"views"`
	Duration      float64 `gorm:"column:duration" json:"duration"`
	Summary       string  `gorm:"column:summary" json:"summary"`
	UpdatedTime   int64   `gorm:"column:updated_time" json:"updated_time"`
}

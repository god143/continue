package notifications

import "time"

type Notifications struct {
	Id               int       `json:"id"`
	Title            string    `json:"title"`
	RedirectionLink  string    `json:"redirection_link"`
	PublishDate      time.Time `json:"publish_date"`
	AdminId          string    `json:"admin_id"`
	NotificationType string    `json:"notification_type"`
	IconUrl          string    `json:"icon_url"`
	ResourceId       int       `json:"resource_id"`
}

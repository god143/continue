package notifications

import (
	"context"

	"gorm.io/gorm"
)

type notificationsRepo struct {
	db *gorm.DB
}

type NotificationsRepo interface {
	GetAllNotifications(ctx context.Context) ([]Notifications, error)
}

func NewNotificationsRepo(db *gorm.DB) NotificationsRepo {
	return &notificationsRepo{
		db: db,
	}
}

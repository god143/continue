package notifications

import (
	"context"
)

func (n *notificationsRepo) GetAllNotifications(ctx context.Context) ([]Notifications, error) {
	var notifications []Notifications

	if err := n.db.Order("publish_date desc").Find(&notifications).Error; err != nil {
		return nil, err
	}
	return notifications, nil
}

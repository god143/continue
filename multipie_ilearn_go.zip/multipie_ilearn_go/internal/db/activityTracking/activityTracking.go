package activitytracking

import (
	"context"
	"errors"

	"gorm.io/gorm"
)

func (a *activityTrackingRepo) CreateUserActivityRecord(ctx context.Context, activity UserActivity, userID int64) (*UserActivity, error) {
	tx := a.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}
	activity.UserID = &userID

	if err := tx.Create(&activity).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	return &activity, nil
}

func (a *activityTrackingRepo) UpdateUserActivityRecord(ctx context.Context, activity UserActivity, userID int64) (*UserActivity, error) {
	tx := a.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if activity.ID == nil || *activity.ID == 0 {
		tx.Rollback()
		return nil, errors.New("invalid ID, cannot update record")
	}

	if err := tx.Model(&UserActivity{}).Where("id = ? AND user_id = ?", *activity.ID, userID).Updates(activity).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	var updatedActivity UserActivity
	if err := tx.Where("id = ? AND user_id = ?", *activity.ID, userID).First(&updatedActivity).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	return &updatedActivity, nil
}

func (a *activityTrackingRepo) GetActivityByUserIDAndResourceID(ctx context.Context, userID int64, resourceID int64) (*UserActivity, error) {
	var activity UserActivity
	if err := a.db.Where("user_id = ? AND resource_id = ?", userID, resourceID).First(&activity).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, err
	}
	return &activity, nil
}

func (a *activityTrackingRepo) GetActivityByUserIDAndCourseModuleID(ctx context.Context, userID int64, courseModuleID int64) (*UserActivity, error) {
	var activity UserActivity
	if err := a.db.Where("user_id = ? AND course_module_id = ?", userID, courseModuleID).First(&activity).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, err
	}
	return &activity, nil
}

func (a *activityTrackingRepo) GetActivitiesByUserIDAndCourseModuleIDs(ctx context.Context, userID int64, courseModuleIDs []int64) ([]UserActivityResponse, error) {

	var activities []UserActivityResponse
	if err := a.db.Table("user_activities").Where("user_id = ? AND course_module_id IN ?", userID, courseModuleIDs).Find(&activities).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, err
	}

	return activities, nil
}

func (a *activityTrackingRepo) GetActivitiesByUserIDAndResourceIDs(ctx context.Context, userID int64, resourceIDs []int64) ([]UserActivityResponse, error) {
	var activities []UserActivityResponse
	if err := a.db.Table("user_activities").Where("user_id = ? AND resource_id IN ?", userID, resourceIDs).Find(&activities).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, err
	}
	return activities, nil
}

func (a *activityTrackingRepo) GetActivitiesByUserIDAndCourseIDs(ctx context.Context, userID int64, courseIDs []int64) ([]UserActivityResponse, error) {
	var activities []UserActivityResponse

	err := a.db.
		Table("user_activities").
		Select("user_activities.*, course_modules.course_id").
		Joins("JOIN course_modules ON user_activities.course_module_id = course_modules.id").
		Where("user_activities.user_id = ? AND course_modules.course_id IN ?", userID, courseIDs).
		Find(&activities).Error

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, err
	}

	return activities, nil
}

func (c *activityTrackingRepo) BatchCreateUserActivity(ctx context.Context, userActivity []UserActivity) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(userActivity, len(userActivity)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

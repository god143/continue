package activitytracking

import (
	"context"

	"gorm.io/gorm"
)

type activityTrackingRepo struct {
	db *gorm.DB
}

type ActivityTrackingRepo interface {
	CreateUserActivityRecord(ctx context.Context, activity UserActivity, userID int64) (*UserActivity, error)
	UpdateUserActivityRecord(ctx context.Context, activity UserActivity, userID int64) (*UserActivity, error)
	GetActivityByUserIDAndResourceID(ctx context.Context, userID int64, resourceID int64) (*UserActivity, error)
	GetActivityByUserIDAndCourseModuleID(ctx context.Context, userID int64, courseModuleID int64) (*UserActivity, error)
	GetActivitiesByUserIDAndCourseModuleIDs(ctx context.Context, userID int64, courseModuleIDs []int64) ([]UserActivityResponse, error)
	GetActivitiesByUserIDAndResourceIDs(ctx context.Context, userID int64, resourceIDs []int64) ([]UserActivityResponse, error)
	GetActivitiesByUserIDAndCourseIDs(ctx context.Context, userID int64, courseIDs []int64) ([]UserActivityResponse, error)
	BatchCreateUserActivity(ctx context.Context, userActivity []UserActivity) error
}

func NewActivityTrackingRepo(db *gorm.DB) ActivityTrackingRepo {
	return &activityTrackingRepo{
		db: db,
	}
}

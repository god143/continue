package activitytracking

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"time"
)

type UserActivity struct {
	ID             *int64                        `json:"id,omitempty"`
	UserID         *int64                        `json:"user_id"`
	ActivityStatus *constants.ActivityStatusEnum `json:"activity_status"`
	AdditionalData *AdditionalData               `json:"additional_data"`
	ResourceID     *int64                        `json:"resource_id"`
	CourseModuleID *int64                        `json:"course_module_id"`
	CreatedAt      *time.Time                    `json:"-"`
	UpdatedAt      *time.Time                    `json:"-"`
}

type UserActivityResponse struct {
	ID             *int64                        `json:"id,omitempty"`
	UserID         *int64                        `json:"user_id"`
	ActivityStatus *constants.ActivityStatusEnum `json:"activity_status"`
	AdditionalData *AdditionalData               `json:"additional_data"`
	ResourceID     *int64                        `json:"resource_id"`
	CourseModuleID *int64                        `json:"course_module_id"`
	CourseID       *int64                        `json:"course_id"`
	CreatedAt      *time.Time                    `json:"-"`
	UpdatedAt      *time.Time                    `json:"-"`
}
type AdditionalData struct {
	TotalWatchTime *int `json:"total_watch_time"`
}

func (u *AdditionalData) Value() (driver.Value, error) {

	if u == nil {
		return nil, nil
	}

	jsonData, err := json.Marshal(u)
	if err != nil {
		fmt.Println("error with Value method:", err)
		return nil, err
	}
	return jsonData, nil
}

func (u *AdditionalData) Scan(src interface{}) error {
	if src == nil {
		*u = AdditionalData{}
		return nil
	}

	byteSlice, ok := src.([]byte)
	if !ok {
		return fmt.Errorf("expected []byte, got %T", src)
	}

	var metaData AdditionalData
	err := json.Unmarshal(byteSlice, &metaData)
	if err != nil {
		fmt.Println("error with Scan method:", err)
		return err
	}

	*u = metaData
	return nil
}

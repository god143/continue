package resource

import (
	"context"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

type resourseRepo struct {
	db *gorm.DB
}

type ResourseRepo interface {
	GetResourceById(ctx context.Context, id int, visible *bool) (*Resource, error)
	GetResourceByIds(ctx context.Context, id []*int64, visible *bool, isShort *bool) ([]Resource, error)
	GetResourceByIdandType(ctx context.Context, id int, resourceType constants.ResourceTypeEnum, subType constants.SubTypeEnum, visible *bool) (*Resource, error)
	GetResourcesByCategoryAndType(ctx context.Context, categoryId int, resourseType constants.ResourceTypeEnum, subType constants.SubTypeEnum, visible *bool, isShort *bool, pagination utils.Pagination, filter constants.FilterTypeEnum) ([]GetResourceByCategory, error)
	DisableResource(ctx context.Context, id int) error
	CreateResource(ctx context.Context, resource *Resource) (*Resource, error)
	UpdateResource(ctx context.Context, resource Resource) (*Resource, error)
	BatchCreateResources(ctx context.Context, resources []BatchCreateResource) error
	BatchCreateResourcesMapping(ctx context.Context, resources []BatchCreateResourceMapping) error
	BatchUpdateResources(ctx context.Context, resources []Resource) error
	UpdateViewsCountResource(ctx context.Context, resourceID int64) error
	UpdateLikesCountResource(ctx context.Context, resourceID int64, action string) error
	GetResourcesByType(ctx context.Context, resourceType constants.ResourceTypeEnum, subType constants.SubTypeEnum, pagination utils.Pagination, isShort *bool, filter constants.FilterTypeEnum) ([]GetResourceByCategory, error)
	GetRelatedResources(ctx context.Context, resourceID int64, modelType constants.RelatedResourcesTagEnum, subType constants.TagMappingSubTypeEnum, limit int64) ([]Resource, error)
	GetSecondaryRelatedResources(ctx context.Context, resourceID int64, modelType constants.RelatedResourcesTagEnum, limit int64) ([]Resource, error)
	CreateRelation(ctx context.Context, rr *RelatedResource) error
	DeleteRelation(ctx context.Context, resourceID, relatedResourceID int64) error
	GetParentCaregorybyResourceId(ctx context.Context, id int64) (*[]string, error)
}

func NewResourseRepo(db *gorm.DB) ResourseRepo {
	return &resourseRepo{
		db: db,
	}
}

package resource

import (
	"context"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

func (r *resourseRepo) GetResourceById(ctx context.Context, id int, visible *bool) (*Resource, error) {
	var result Resource
	query := r.db.Where("id = ?", id)
	if visible != nil {
		query = query.Where("visible = ?", visible)
	}
	if err := query.First(&result).Error; err != nil {
		return nil, err
	}
	return &result, nil
}

func (r *resourseRepo) GetResourceByIds(ctx context.Context, ids []*int64, visible *bool, isShort *bool) ([]Resource, error) {
	var result []Resource
	query := r.db.Where("id in (?)", ids)
	if visible != nil {
		query = query.Where("visible = ?", visible)
	}
	if isShort != nil {
		query = query.Where("is_short = ?", isShort)
	}
	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}
	return result, nil
}

func (r *resourseRepo) GetResourcesByCategoryAndType(ctx context.Context, categoryId int, resourseType constants.ResourceTypeEnum, subType constants.SubTypeEnum, visible *bool, isShort *bool, pagination utils.Pagination, filter constants.FilterTypeEnum) ([]GetResourceByCategory, error) {
	var result []GetResourceByCategory

	query := r.db.Table("resources").Where("type = ?", resourseType)

	if subType != "" {
		query = query.Where("sub_type", subType)
	}
	if categoryId != 0 {
		query = query.Where("category_id = ?", categoryId)
	}
	if visible != nil {
		query = query.Where("visible = ?", visible)
	}
	if isShort != nil {
		query = query.Where("is_short = ?", *isShort)
	}

	if filter == constants.FilterTypeEnumTrending {
		query = query.Where("views > ?", 100).Order("views DESC")
	} else {
		query = query.Order("created_at DESC")
	}

	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}

	if err := utils.Paginate(r.db, &result, &pagination, query); err != nil {
		return nil, err
	}
	return result, nil
}

func (r *resourseRepo) DisableResource(ctx context.Context, id int) error {
	tx := r.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}
	if err := tx.Model(&Resource{}).Where("id = ?", id).Updates(&Resource{
		Visible: utils.BoolToPointer(false),
	}).Error; err != nil {
		tx.Rollback()
		return err
	}
	if err := tx.Commit().Error; err != nil {
		return err
	}
	return nil
}

func (r *resourseRepo) CreateResource(ctx context.Context, resource *Resource) (*Resource, error) {
	tx := r.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(resource).Error; err != nil {
		tx.Rollback()
		return nil, err
	}
	if err := tx.Commit().Error; err != nil {
		return nil, err
	}
	return resource, nil
}

func (r *resourseRepo) UpdateResource(ctx context.Context, resource Resource) (*Resource, error) {

	tx := r.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&Resource{}).Where("id = ?", resource.ID).Updates(&resource).Error; err != nil {

		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return &resource, nil
}

func (r *resourseRepo) BatchCreateResources(ctx context.Context, resources []BatchCreateResource) error {
	tx := r.db.Table("resources").Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(resources, len(resources)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (r *resourseRepo) BatchCreateResourcesMapping(ctx context.Context, resource_mapping []BatchCreateResourceMapping) error {
	tx := r.db.Table("resource_mapping").Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(resource_mapping, len(resource_mapping)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (r *resourseRepo) BatchUpdateResources(ctx context.Context, resources []Resource) error {
	tx := r.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, resource := range resources {

		if err := tx.Model(&Resource{}).Where("id = ?", resource.ID).Updates(&resource).Error; err != nil {
			tx.Rollback()
			return err
		}
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (r *resourseRepo) UpdateViewsCountResource(ctx context.Context, resourceID int64) error {
	tx := r.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Resource{}).Where("id = ?", resourceID).
		Update("views", gorm.Expr("COALESCE(views, 0) + ?", 1))

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (r *resourseRepo) UpdateLikesCountResource(ctx context.Context, resourceID int64, action string) error {
	tx := r.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}
	query := tx.Model(&Resource{}).Where("id = ?", resourceID)

	if action == "like" {
		query = query.Update("likes", gorm.Expr("COALESCE(likes, 0) + ?", 1))
	} else if action == "unlike" {
		query = query.Update("likes", gorm.Expr("CASE WHEN COALESCE(likes, 0) > 0 THEN likes - 1 ELSE 0 END"))
	}

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (r *resourseRepo) GetResourcesByType(ctx context.Context, resourceType constants.ResourceTypeEnum, subType constants.SubTypeEnum, pagination utils.Pagination, isShort *bool, filter constants.FilterTypeEnum) ([]GetResourceByCategory, error) {
	var result []GetResourceByCategory
	query := r.db.Table("resources").WithContext(ctx).
		Where("type = ?", resourceType).
		Where("visible = ?", true).Where("course_module_id IS NULL")

	if subType != "" {
		query = query.Where("sub_type", subType)
	}

	if isShort != nil {
		query = query.Where("is_short = ?", *isShort)
	}

	switch filter {
	case constants.FilterTypeEnumTrending:
		query = query.Where("views > ?", 100).Order("views DESC")
	default:
		query = query.Order("created_at DESC")
	}

	if err := utils.Paginate(r.db, &result, &pagination, query); err != nil {
		return nil, err
	}

	return result, nil
}

func (r *resourseRepo) GetResourceByIdandType(ctx context.Context, id int, resourceType constants.ResourceTypeEnum, subType constants.SubTypeEnum, visible *bool) (*Resource, error) {
	var result Resource
	query := r.db.Where("id = ? AND type = ?  AND sub_type=?", id, resourceType, subType)
	// if subType != "" {
	// 	query = query.Where("sub_type", subType)
	// }

	if visible != nil {
		query = query.Where("visible = ?", visible)
	}
	if err := query.First(&result).Error; err != nil {
		return nil, err
	}
	return &result, nil
}

func (r *resourseRepo) CreateRelation(ctx context.Context, rr *RelatedResource) error {
	return r.db.WithContext(ctx).Create(rr).Error
}

func (r *resourseRepo) DeleteRelation(ctx context.Context, resourceID, relatedResourceID int64) error {
	return r.db.WithContext(ctx).
		Where("resource_id = ? AND related_resource_id = ?", resourceID, relatedResourceID).
		Delete(&RelatedResource{}).Error
}

func (r *resourseRepo) GetRelatedResources(ctx context.Context, resourceID int64, modelType constants.RelatedResourcesTagEnum, subType constants.TagMappingSubTypeEnum, limit int64) ([]Resource, error) {
	resources := []Resource{}

	if modelType == constants.RelatedResourcesTagEnumVideo {
		err := r.db.Table("tag_mappings tm1").
			Select("r.*"). // Only select resource fields
			Joins("JOIN tag_mappings tm2 ON tm1.tag_id = tm2.tag_id").
			Joins("JOIN resources r ON r.id = tm2.model_id AND r.type = tm2.model_type AND r.sub_type = tm2.sub_type").
			Where("tm1.model_id = ? AND tm1.model_type = ? AND tm1.sub_type=?", resourceID, modelType, subType).
			Where("NOT (tm2.model_id = ? AND tm2.model_type = ? AND tm2.sub_type=?)", resourceID, modelType, subType).
			Where("tm2.model_type = ?", modelType).
			Where("tm2.sub_type=?", subType).
			Where("r.visible = ?", true).
			Group("r.id, r.url, r.dark_mode_url, r.type, r.name, r.description, r.category_id, r.course_module_id, r.icon, r.views, r.likes, r.is_short, r.visible, r.metadata, r.content, r.created_at, r.updated_at").
			Order("COUNT(tm2.model_id) DESC"). // Order by the count of tm2.model_id directly
			Limit(int(limit)).
			Scan(&resources).Error // Scan directly into the slice of Resource structs

		if err != nil {
			return nil, err
		}
		return resources, nil

	} else {
		err := r.db.Table("tag_mappings tm1").
			Select("r.*"). // Only select resource fields
			Joins("JOIN tag_mappings tm2 ON tm1.tag_id = tm2.tag_id").
			Joins("JOIN resources r ON r.id = tm2.model_id AND r.type = tm2.model_type").
			Where("tm1.model_id = ? AND tm1.model_type = ? ", resourceID, modelType).
			Where("NOT (tm2.model_id = ? AND tm2.model_type = ?)", resourceID, modelType).
			Where("tm2.model_type = ?", modelType).
			Where("r.visible = ?", true).
			Group("r.id, r.url, r.dark_mode_url, r.type, r.name, r.description, r.category_id, r.course_module_id, r.icon, r.views, r.likes, r.is_short, r.visible, r.metadata, r.content, r.created_at, r.updated_at").
			Order("COUNT(tm2.model_id) DESC"). // Order by the count of tm2.model_id directly
			Limit(int(limit)).
			Scan(&resources).Error // Scan directly into the slice of Resource structs

		if err != nil {
			return nil, err
		}
		return resources, nil
	}
}

func (r *resourseRepo) GetSecondaryRelatedResources(ctx context.Context, resourceID int64, modelType constants.RelatedResourcesTagEnum, limit int64) ([]Resource, error) {
	resources := []Resource{}
	err := r.db.Table("tag_mappings tm1").
		Select("r.*"). // Only select resource fields
		Joins("JOIN tag_mappings tm2 ON tm1.tag_id = tm2.tag_id").
		Joins("JOIN auxiliary_video_resources r ON r.id = tm2.model_id AND r.model_type = tm2.model_type").
		Where("tm1.model_id = ? AND tm1.model_type = ?", resourceID, modelType).
		Where("NOT (tm2.model_id = ? AND tm2.model_type = ?)", resourceID, modelType).
		Where("tm2.model_type = ?", modelType).
		Where("r.visible = ?", true).
		Group("r.id, r.url, r.dark_mode_url, r.model_type, r.name, r.description, r.category_id, r.views, r.likes, r.is_short, r.visible, r.metadata, r.created_at, r.updated_at").
		Order("COUNT(tm2.model_id) DESC"). // Order by the count of tm2.model_id directly
		Limit(int(limit)).
		Scan(&resources).Error // Scan directly into the slice of Resource structs

	if err != nil {
		return nil, err
	}
	return resources, nil
}

func (r *resourseRepo) GetParentCaregorybyResourceId(ctx context.Context, id int64) (*[]string, error) {
	var result *[]string
	subQuery := r.db.Table("categories c").Select("c.parent").Joins("JOIN resources r ON c.id=r.category_id").Where("r.id= ?", id)

	query := r.db.Table("categories").
		Select("name").
		Where("id =(?)", subQuery)

	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}
	return result, nil
}

package resource

import (
	"encoding/json"
	"multipie_ilearn_go/internal/constants"
	"time"
)

type Resource struct {
	ID             *int                        `json:"id,omitempty"`
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	Likes          *int                        `json:"likes,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	Content        *string                     `json:"content"`
	IsBookmark     *bool                       `json:"is_bookmark" gorm:"-"`
	BookmarkId     *int64                      `json:"bookmark_id" gorm:"-"`
	Tags           *[]string                   `json:"tags" gorm:"-"`
	CreatedAt      *time.Time                  `json:"created_at"`
	UpdatedAt      *time.Time                  `json:"updated_at"`
}
type BatchCreateResource struct {
	ID             *int                        `json:"id,omitempty"`
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	Likes          *int                        `json:"likes,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	Content        *string                     `json:"content"`
	CreatedAt      *time.Time                  `json:"created_at"`
	UpdatedAt      *time.Time                  `json:"updated_at"`
}

type BatchCreateResourceMapping struct {
	MoodleResourceId   *int    `json:"moodle_resource_id,omitempty"`
	MoodleResourceType *string `json:"moodle_resorce_type"`
	IlearnResourceId   *int    `json:"ilearn_resource_id,omitempty"`
}

type GetResourceByCategory struct {
	ID             *int                        `json:"id,omitempty"`
	URL            *string                     `json:"url"`
	DarkModeURL    *string                     `json:"dark_mode_url,omitempty"`
	Type           *constants.ResourceTypeEnum `json:"type"`
	SubType        *constants.SubTypeEnum      `json:"sub_type"`
	Name           *string                     `json:"name,omitempty"`
	Description    *string                     `json:"description,omitempty"`
	CategoryID     *int                        `json:"category_id,omitempty"`
	CourseModuleID *int                        `json:"course_module_id,omitempty"`
	Icon           *string                     `json:"icon,omitempty"`
	Views          *int                        `json:"views,omitempty"`
	Likes          *int                        `json:"likes,omitempty"`
	IsShort        *bool                       `json:"is_short,omitempty"`
	Visible        *bool                       `json:"visible,omitempty"`
	Metadata       json.RawMessage             `json:"metadata,omitempty"`
	IsBookmark     *bool                       `json:"is_bookmark"`
	BookmarkId     *int64                      `json:"bookmark_id"`
	Content        *string                     `json:"-"`
	CreatedAt      *time.Time                  `json:"created_at"`
	UpdatedAt      *time.Time                  `json:"updated_at"`
}

type RelatedResource struct {
	ID                *int64     `json:"id,omitempty"`
	ResourceID        *int64     `json:"resource_id,omitempty"`
	RelatedResourceID *int64     `json:"related_resource_id,omitempty"`
	CreatedAt         *time.Time `json:"created_at,omitempty"`
	UpdatedAt         *time.Time `json:"updated_at,omitempty"`
}

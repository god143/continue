package mdlcourse

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type MdlCourse struct {
	ID                       int64   `json:"id" gorm:"column:id"`
	Category                 int64   `json:"category" gorm:"column:category"`
	Sortorder                int64   `json:"sortorder" gorm:"column:sortorder"`
	Fullname                 string  `json:"fullname" gorm:"column:fullname"`
	Shortname                string  `json:"shortname" gorm:"column:shortname"`
	IDNumber                 string  `json:"idnumber" gorm:"column:idnumber"`
	Summary                  string  `json:"summary" gorm:"column:summary"`
	SummaryFormat            int8    `json:"summaryformat" gorm:"column:summaryformat"`
	Format                   string  `json:"format" gorm:"column:format"`
	ShowGrades               bool    `json:"showgrades" gorm:"column:showgrades"`
	NewsItems                int32   `json:"newsitems" gorm:"column:newsitems"`
	StartDate                int64   `json:"startdate" gorm:"column:startdate"`
	EndDate                  int64   `json:"enddate" gorm:"column:enddate"`
	RelativeDatesMode        bool    `json:"relativedatesmode" gorm:"column:relativedatesmode"`
	Marker                   int64   `json:"marker" gorm:"column:marker"`
	MaxBytes                 int64   `json:"maxbytes" gorm:"column:maxbytes"`
	LegacyFiles              int16   `json:"legacyfiles" gorm:"column:legacyfiles"`
	ShowReports              int16   `json:"showreports" gorm:"column:showreports"`
	Visible                  bool    `json:"visible" gorm:"column:visible"`
	VisibleOld               bool    `json:"visibleold" gorm:"column:visibleold"`
	DownloadContent          *bool   `json:"downloadcontent" gorm:"column:downloadcontent"`
	GroupMode                int16   `json:"groupmode" gorm:"column:groupmode"`
	GroupModeForce           int16   `json:"groupmodeforce" gorm:"column:groupmodeforce"`
	DefaultGroupingID        int64   `json:"defaultgroupingid" gorm:"column:defaultgroupingid"`
	Lang                     string  `json:"lang" gorm:"column:lang"`
	CalendarType             string  `json:"calendartype" gorm:"column:calendartype"`
	Theme                    string  `json:"theme" gorm:"column:theme"`
	TimeCreated              int64   `json:"timecreated" gorm:"column:timecreated"`
	TimeModified             int64   `json:"timemodified" gorm:"column:timemodified"`
	Requested                bool    `json:"requested" gorm:"column:requested"`
	EnableCompletion         bool    `json:"enablecompletion" gorm:"column:enablecompletion"`
	CompletionNotify         bool    `json:"completionnotify" gorm:"column:completionnotify"`
	CacheRev                 int64   `json:"cacherev" gorm:"column:cacherev"`
	OriginalCourseID         *int64  `json:"originalcourseid" gorm:"column:originalcourseid"`
	ShowActivityDates        bool    `json:"showactivitydates" gorm:"column:showactivitydates"`
	ShowCompletionConditions bool    `json:"showcompletionconditions" gorm:"column:showcompletionconditions"`
	PDFExportFont            *string `json:"pdfexportfont" gorm:"column:pdfexportfont"`
}

func (MdlCourse) TableName() string {
	return "mdl_course"
}

type Course struct {
	ID              *int64                         `json:"id"`
	Fullname        *string                        `json:"fullname"`
	Shortname       *string                        `json:"shortname"`
	CategoryID      *int64                         `json:"category_id"`
	DifficultyLevel *constants.CourseDiffcultyEnum `json:"difficulty_level"`
	Summary         *string                        `json:"summary"`
	StartDate       *string                        `json:"startdate"`
	EndDate         *string                        `json:"enddate"`
	Format          *constants.CourseFormatEnum    `json:"format"`
	ModuleCount     *int64                         `json:"module_count"`
	Duration        *int64                         `json:"duration"`
	Views           *int64                         `json:"views"`
	Visible         *bool                          `json:"visible"`
	Banner          *string                        `json:"banner"`
	Likes           *int                           `json:"likes"`
	CreatedAt       *time.Time                     `json:"-"` // Timestamp when the category was created
	UpdatedAt       *time.Time                     `json:"-"` // Timestamp when the category was last updated
}

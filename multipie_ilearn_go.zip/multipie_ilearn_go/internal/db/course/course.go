package mdlcourse

import (
	"context"
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
	"gorm.io/gorm"
)

func (c *courseRepo) GetCourseByID(ctx context.Context, courseID int64, visibility *bool) (Course, error) {
	var course Course

	query := c.db.First(&course, courseID)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			logger.Error(ctx, "Course not found", zap.Int64("courseID", courseID))
			return course, fmt.Errorf("course not found: courseID %d", courseID)
		}
		logger.Error(ctx, "error fetching course by ID", zap.Error(err), zap.Int64("courseID", courseID))
		return course, err
	}
	return course, nil
}

func (c *courseRepo) GetCourseByCategory(ctx context.Context, categoryID int64, visibility *bool) ([]Course, error) {
	var courses []Course

	query := c.db.Where("category_id = ?", categoryID)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Find(&courses).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			logger.Error(ctx, "No courses found for the given category", zap.Int64("categoryID", categoryID))
			return nil, fmt.Errorf("no courses found for the given category: categoryID %d", categoryID)
		}
		logger.Error(ctx, "error fetching courses by category", zap.Error(err), zap.Int64("categoryID", categoryID))
		return nil, err
	}

	return courses, nil
}

func (c *courseRepo) CreateCourse(ctx context.Context, course *Course) (*Course, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(course).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return course, nil
}

func (c *courseRepo) UpdateCourse(ctx context.Context, course *Course) (*Course, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	query := tx.Model(&Course{}).Where("id = ?", course.ID).Updates(&Course{
		Fullname:        course.Fullname,
		Shortname:       course.Shortname,
		CategoryID:      course.CategoryID,
		DifficultyLevel: course.DifficultyLevel,
		Summary:         course.Summary,
		StartDate:       course.StartDate,
		EndDate:         course.EndDate,
		Format:          course.Format,
		ModuleCount:     course.ModuleCount,
		Duration:        course.Duration,
		Views:           course.Views,
		Banner:          course.Banner,
		Visible:         course.Visible,
	})

	if err := query.Error; err != nil {
		tx.Rollback()
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("course not found: courseID %d", course.ID)
		}
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return course, nil
}

// Mark a course as deleted by setting visible = false
func (c *courseRepo) DisbaleCourse(ctx context.Context, id int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Course{}).Where("id = ?", id).Updates(&Course{
		Visible: utils.BoolToPointer(false),
	})
	if err := query.Error; err != nil {
		tx.Rollback()
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return fmt.Errorf("course not found: courseID %d", id)
		}
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Batch Insertion in courses table
func (c *courseRepo) BatchCreateCourses(ctx context.Context, course []Course) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(course, len(course)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Batch Updation in course table
func (c *courseRepo) BatchUpdateCourses(ctx context.Context, course []Course) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, item := range course {
		query := tx.Model(&Course{}).Where("id = ?", item.ID).Updates(&Course{
			Fullname:        item.Fullname,
			Shortname:       item.Shortname,
			CategoryID:      item.CategoryID,
			DifficultyLevel: item.DifficultyLevel,
			Summary:         item.Summary,
			StartDate:       item.StartDate,
			EndDate:         item.EndDate,
			Format:          item.Format,
			ModuleCount:     item.ModuleCount,
			Duration:        item.Duration,
			Views:           item.Views,
			Banner:          item.Banner,
			Visible:         item.Visible,
		})
		if err := query.Error; err != nil {
			tx.Rollback()
			return err
		}
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c *courseRepo) UpdateViewsCountCourses(ctx context.Context, courseID int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Course{}).Where("id = ?", courseID).
		Update("views", gorm.Expr("COALESCE(views, 0) + ?", 1))

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c *courseRepo) UpdateLikesCountCourses(ctx context.Context, courseID int64, action string) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Course{}).Where("id = ?", courseID)

	if action == constants.STATS_ACTION_LIKE {
		query = query.Update("likes", gorm.Expr("COALESCE(likes, 0) + ?", 1))
	} else {
		query = query.Update("likes", gorm.Expr("CASE WHEN COALESCE(likes, 0) > 0 THEN likes - 1 ELSE 0 END"))
	}

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

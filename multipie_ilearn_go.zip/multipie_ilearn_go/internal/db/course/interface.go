package mdlcourse

import (
	"context"

	"gorm.io/gorm"
)

type courseRepo struct {
	db *gorm.DB
}

type CourseRepo interface {
	GetCourseByID(ctx context.Context, courseID int64, visibility *bool) (Course, error)
	GetCourseByCategory(ctx context.Context, categoryID int64, visibility *bool) ([]Course, error)
	CreateCourse(ctx context.Context, course *Course) (*Course, error)
	UpdateCourse(ctx context.Context, course *Course) (*Course, error)
	DisbaleCourse(ctx context.Context, id int64) error
	BatchCreateCourses(ctx context.Context, course []Course) error
	BatchUpdateCourses(ctx context.Context, course []Course) error
	UpdateLikesCountCourses(ctx context.Context, courseID int64, action string) error
	UpdateViewsCountCourses(ctx context.Context, courseID int64) error
}

func NewCourseRepo(db *gorm.DB) CourseRepo {
	return &courseRepo{
		db: db,
	}
}

package question

import (
	"context"

	"gorm.io/gorm"
)

type questionRepo struct {
	db *gorm.DB
}

type QuestionRepo interface {
	GetQuestionById(ctx context.Context, questionId int64) (Question, error)
	GetQuestionsByQuizId(ctx context.Context, quizId int64, numOfquestions *int64) ([]Question, error)
	GetQuestionAnswersByQuizId(ctx context.Context, quizId int64, numOfquestions *int64) ([]QuestionAnswer, error)
	CreateQuestion(ctx context.Context, question *Question) (*Question, error)
	UpdateQuestion(ctx context.Context, question *Question) (*Question, error)
	DeleteQuestion(ctx context.Context, questionId int64) error
	BatchCreateQuestions(ctx context.Context, questions []Question) error
	BatchUpdateQuestions(ctx context.Context, questions []Question) error
}

func NewQuestionRepo(db *gorm.DB) QuestionRepo {
	return &questionRepo{
		db: db,
	}
}

package question

import (
	"database/sql/driver"
	"encoding/json"
	"multipie_ilearn_go/internal/constants"
	"time"
)

type Question struct {
	ID            *int64                      `json:"id"`
	QuizID        *int64                      `json:"quiz_id"`
	QuestionText  *string                     `json:"question_text"`
	Type          *constants.QuestionTypeEnum `json:"question_type"`
	ImageURL      *string                     `json:"image_url,omitempty"`
	Answers       *Answer                     `json:"answers" gorm:"type:json"`
	CorrectAnswer *string                     `json:"-"`
	CreatedAt     *time.Time                  `json:"-"`
	UpdatedAt     *time.Time                  `json:"-"`
}

type QuestionAnswer struct {
	ID            *int64                      `json:"id"`
	QuizID        *int64                      `json:"quiz_id"`
	QuestionText  *string                     `json:"question_text"`
	Type          *constants.QuestionTypeEnum `json:"question_type"`
	ImageURL      *string                     `json:"image_url,omitempty"`
	Answers       *Answer                     `json:"answers" gorm:"type:json"`
	CorrectAnswer *string                     `json:"correct_answer"`
	CreatedAt     *time.Time                  `json:"-"`
	UpdatedAt     *time.Time                  `json:"-"`
}

type Answer struct {
	Options *[]string `json:"options"`
}

func (a *Answer) Value() (driver.Value, error) {

	jsonData, err := json.Marshal(a)
	if err != nil {
		return nil, err
	}

	return jsonData, nil
}

func (a *Answer) Scan(src interface{}) error {
	var metaData Answer

	err := json.Unmarshal(src.([]byte), &metaData)
	if err != nil {
		return err
	}

	*a = metaData
	return nil
}

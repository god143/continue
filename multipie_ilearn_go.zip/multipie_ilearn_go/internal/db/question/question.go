package question

import (
	"context"
	"errors"
	"fmt"

	"gorm.io/gorm"
)

func (q *questionRepo) GetQuestionById(ctx context.Context, questionId int64) (Question, error) {
	var question Question

	query := q.db.First(&question, questionId)
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return question, fmt.Errorf("question not found with ID: %v", questionId)
		}

		return question, err
	}

	return question, nil
}

func (q *questionRepo) GetQuestionsByQuizId(ctx context.Context, quizId int64, numOfquestions *int64) ([]Question, error) {
	var questions []Question

	query := q.db.Where("quiz_id = ?", quizId)

	if numOfquestions != nil {
		query = query.Limit(int(*numOfquestions))
	}

	query = query.Order("created_at DESC").Find(&questions)
	if err := query.Error; err != nil {
		return nil, err
	}

	return questions, nil
}

func (q *questionRepo) GetQuestionAnswersByQuizId(ctx context.Context, quizId int64, numOfquestions *int64) ([]QuestionAnswer, error) {
	var questions []QuestionAnswer

	query := q.db.Table("questions").Where("quiz_id = ?", quizId)

	if numOfquestions != nil {
		query = query.Limit(int(*numOfquestions))
	}

	query = query.Order("created_at DESC").Find(&questions)
	if err := query.Error; err != nil {
		return nil, err
	}

	return questions, nil
}

func (q *questionRepo) CreateQuestion(ctx context.Context, question *Question) (*Question, error) {
	tx := q.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(question).Error; err != nil {
		return nil, q.handleTransaction(tx, err)
	}

	return question, q.handleTransaction(tx, nil)
}

func (q *questionRepo) UpdateQuestion(ctx context.Context, question *Question) (*Question, error) {
	tx := q.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	// Update the question fields
	if err := q.updateQuestionFields(tx, question); err != nil {
		return nil, q.handleTransaction(tx, err)
	}

	return question, q.handleTransaction(tx, nil)
}

func (q *questionRepo) DeleteQuestion(ctx context.Context, questionId int64) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Where("id = ?", questionId).Delete(&Question{})
	if err := query.Error; err != nil {
		return q.handleTransaction(tx, err)
	}

	return q.handleTransaction(tx, nil)
}

func (q *questionRepo) BatchCreateQuestions(ctx context.Context, questions []Question) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(questions, len(questions)).Error; err != nil {
		return q.handleTransaction(tx, err)
	}

	return q.handleTransaction(tx, nil)
}

func (q *questionRepo) BatchUpdateQuestions(ctx context.Context, questions []Question) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, item := range questions {
		if err := q.updateQuestionFields(tx, &item); err != nil {
			return q.handleTransaction(tx, err)
		}
	}

	return q.handleTransaction(tx, nil)
}

// Helper method to update question fields
func (q *questionRepo) updateQuestionFields(tx *gorm.DB, question *Question) error {
	return tx.Model(&Question{}).Where("id = ?", question.ID).Updates(&Question{
		QuestionText:  question.QuestionText,
		Type:          question.Type,
		ImageURL:      question.ImageURL,
		Answers:       question.Answers,
		CorrectAnswer: question.CorrectAnswer,
	}).Error
}

func (q *questionRepo) handleTransaction(tx *gorm.DB, err error) error {
	if err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit().Error
}

package mdlcoursecontent

type MdlCourseContent struct {
	ID              int64  `json:"id" gorm:"column:id"`
	Course          int64  `json:"course" gorm:"column:course"`
	Name            string `json:"name" gorm:"column:name"`
	Intro           string `json:"intro" gorm:"column:intro"`
	IntroFormat     int    `json:"introformat" gorm:"column:introformat"`
	ExternalURL     string `json:"externalurl" gorm:"column:externalurl"`
	URLParamCheck   bool   `json:"urlparamcheck" gorm:"column:urlparamcheck"`
	Display         int    `json:"display" gorm:"column:display"`
	DisplayOptions  string `json:"displayoptions" gorm:"column:displayoptions"`
	Parameters      string `json:"parameters" gorm:"column:parameters"`
	TimeModified    int64  `json:"timemodified" gorm:"column:timemodified"`
	IsShort         *int64 `json:"isshort" gorm:"column:isshort"`
	ExternalURLDark string `json:"externalurl_dark" gorm:"column:externalurl_dark"`
}

func (MdlCourseContent) TableName() string {
	return "mdl_url"
}

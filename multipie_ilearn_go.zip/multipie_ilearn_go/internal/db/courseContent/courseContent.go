package mdlcoursecontent

import (
	"context"
)

func (c *courseContentRepo) GetCourseContent(ctx context.Context, course int64) ([]MdlCourseContent, error) {
	var contentData []MdlCourseContent

	if err := c.db.Where("course = ?", course).Find(&contentData).Error; err != nil {

		return nil, err
	}

	return contentData, nil
}

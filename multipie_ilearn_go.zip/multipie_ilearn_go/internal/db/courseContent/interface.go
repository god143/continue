package mdlcoursecontent

import (
	"context"

	"gorm.io/gorm"
)

type courseContentRepo struct {
	db *gorm.DB
}

type CourseContentRepo interface {
	GetCourseContent(ctx context.Context, course int64) ([]MdlCourseContent, error)
}

func NewCourseContentRepo(db *gorm.DB) CourseContentRepo {
	return &courseContentRepo{
		db: db,
	}
}

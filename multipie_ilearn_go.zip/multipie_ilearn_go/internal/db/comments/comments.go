package comments

import (
	"context"
	"time"
)

func (r *commentRepo) CreateComment(ctx context.Context, comment *Comment) (*Comment, error) {
	tx := r.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	newComment := &Comment{
		UserID:     comment.UserID,
		Content:    comment.Content,
		ParentID:   comment.ParentID,
		ModelType:  comment.ModelType,
		ModelID:    comment.ModelID,
		Visible:    comment.Visible,
		LikesCount: new(int64),
	}

	*newComment.LikesCount = 0

	if err := tx.Create(&newComment).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	return newComment, nil
}

func (r *commentRepo) DisableComment(ctx context.Context, commentID int64) error {
	err := r.db.WithContext(ctx).
		Model(&Comment{}).
		Where("id = ?", commentID).
		Update("visible", false).Error
	if err != nil {
		return err
	}
	return nil
}

func (r *commentRepo) EnableComment(ctx context.Context, commentID int64) error {
	err := r.db.WithContext(ctx).Model(&Comment{}).
		Where("id = ?", commentID).
		Update("visible", true).Error

	if err != nil {
		return err
	}

	return nil
}

func (r *commentRepo) GetCommentsByModelAndID(ctx context.Context, modelType string, modelID int64, userID *int64, visible *bool) ([]CommentWithUser, error) {
	var comments []CommentWithUser

	query := r.db.WithContext(ctx).
		Table("comments c").
		Joins("JOIN users u ON c.user_id = u.uid").
		Where("c.model_type = ? AND c.model_id = ?", modelType, modelID).
		Order("c.created_at ASC").
		Select("c.id, c.user_id, u.username, u.first_name, u.last_name, c.content, c.parent_id, c.model_type, c.model_id, c.visible, c.likes_count, '' AS picture_url, c.created_at, c.updated_at")

	// Apply filtering condition: (visible = true OR user_id = ?)
	if visible != nil || userID != nil {
		query = query.Where("(c.visible = ? OR c.user_id = ?)", visible == nil || *visible, userID)
	}

	err := query.Find(&comments).Error
	if err != nil {
		return nil, err
	}

	return comments, nil
}

func (r *commentRepo) HasCommented(ctx context.Context, modelType string, modelID int64, userID *int64, visible *bool, duration time.Duration) (bool, error) {
	var exists bool
	err := r.db.Raw(`
		SELECT EXISTS 
		(SELECT 1 FROM comments 
		where user_id = ? 
		AND model_id = ? 
		AND model_type = ? 
		AND created_at >= ?
	)`, userID, modelID, modelType, time.Now().Add(-duration)).Scan(&exists).Error

	if err != nil {
		return false, err
	}
	return exists, nil
}

func (c *commentRepo) BatchCreateComments(ctx context.Context, comment []Comment) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(comment, len(comment)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

package comments

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type Comment struct {
	ID     *int64 `json:"id"`
	UserID *int64 `json:"user_id"`

	Content    *string                          `json:"content"`
	ParentID   *int64                           `json:"parent_id"`
	ModelType  *constants.CommentsModelTypeEnum `json:"model_type"`
	ModelID    *int64                           `json:"model_id"`
	Visible    *bool                            `json:"visible"`
	LikesCount *int64                           `json:"likes_count"`
	CreatedAt  *time.Time                       `json:"-"`
	UpdatedAt  *time.Time                       `json:"-"`
}
type CommentWithUser struct {
	ID         *int64                           `json:"id"`
	UserID     *int64                           `json:"user_id"`
	Username   *string                          `json:"username"`
	FirstName  *string                          `json:"first_name"`
	LastName   *string                          `json:"last_name"`
	PictureURL *string                          `json:"picture_url"`
	Content    *string                          `json:"content"`
	ParentID   *int64                           `json:"parent_id"`
	ModelType  *constants.CommentsModelTypeEnum `json:"model_type"`
	ModelID    *int64                           `json:"model_id"`
	Visible    *bool                            `json:"visible"`
	LikesCount *int64                           `json:"likes_count"`
	CreatedAt  *time.Time                       `json:"created_at"`
	UpdatedAt  *time.Time                       `json:"-"`
}

type CommentWithReplies struct {
	Comment CommentWithUser   `json:"comment"`
	Replies []CommentWithUser `json:"replies"`
}

type User struct {
	ID        *int64  `json:"id"`
	Username  *string `json:"username"`
	FirstName *string `json:"first_name"`
	LastName  *string `json:"last_name"`
}

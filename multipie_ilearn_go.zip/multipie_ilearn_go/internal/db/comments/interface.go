package comments

import (
	"context"
	"time"

	"gorm.io/gorm"
)

type commentRepo struct {
	db *gorm.DB
}

type CommentRepo interface {
	CreateComment(ctx context.Context, comment *Comment) (*Comment, error)
	DisableComment(ctx context.Context, commentID int64) error
	EnableComment(ctx context.Context, commentID int64) error
	BatchCreateComments(ctx context.Context, course []Comment) error
	GetCommentsByModelAndID(ctx context.Context, modelType string, modelID int64, userID *int64, visible *bool) ([]CommentWithUser, error)
	HasCommented(ctx context.Context, modelType string, modelID int64, userID *int64, visible *bool, duration time.Duration) (bool, error)
}

func NewCommentRepo(db *gorm.DB) CommentRepo {
	return &commentRepo{
		db: db,
	}
}

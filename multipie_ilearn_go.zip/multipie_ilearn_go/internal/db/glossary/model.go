package glossary

import (
	"time"
)

// Glossary represents the structure of the `glossary` table in the database.
type Glossary struct {
	ID        *int64     `json:"id,omitempty"`    // Unique ID for the glossary
	Key       *string    `json:"key,omitempty"`   // key of glossary
	Value     *string    `json:"value,omitempty"` // value of the glossary
	CreatedAt *time.Time `json:"-"`               // Timestamp when the glossary was created
	UpdatedAt *time.Time `json:"-"`               // Timestamp when the glossary was last updated
}

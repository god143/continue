package glossary

import (
	"context"

	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

type glossaryRepo struct {
	db *gorm.DB
}

type GlossaryRepo interface {
	GetGlossaries(ctx context.Context, page int64, pageSize int64, searchtext string) (*utils.Pagination, error)
	GetAllGlossariesWithoutPagination(ctx context.Context, searchtext string) ([]Glossary, error)
	GetGlossaryByID(ctx context.Context, id int64) (*Glossary, error)
	UpdateGlossary(ctx context.Context, Glossary Glossary) (*Glossary, error)
	CreateGlossary(ctx context.Context, Glossary *Glossary) (*Glossary, error)
	DeleteGlossary(ctx context.Context, id int64) error
	BatchUpdateGlossary(ctx context.Context, glossaries []Glossary) error
	BatchInsertGlossary(ctx context.Context, glossaries []Glossary) error
}

func NewGlossaryRepo(db *gorm.DB) GlossaryRepo {
	return &glossaryRepo{
		db: db,
	}
}

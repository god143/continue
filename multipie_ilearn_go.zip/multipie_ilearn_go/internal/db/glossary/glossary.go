package glossary

import (
	"context"
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

// Get all active glossary
func (c *glossaryRepo) GetGlossaries(ctx context.Context, page int64, pageSize int64, searchText string) (*utils.Pagination, error) {
	var (
		result []Glossary
	)

	pagination := utils.Pagination{
		Page:     int(page),
		PageSize: int(pageSize),
	}

	query := c.db.Order("`key` ASC")

	if searchText != "" {
		fullTextSearchQuery := fmt.Sprintf("MATCH(`key`, `value`) AGAINST('%s*' IN BOOLEAN MODE)", searchText)
		query = query.Where(fullTextSearchQuery)
	}

	if err := utils.Paginate(c.db, &result, &pagination, query); err != nil {
		return nil, err
	}
	return &pagination, nil
}

// Get all active glossary
func (c *glossaryRepo) GetAllGlossariesWithoutPagination(ctx context.Context, searchText string) ([]Glossary, error) {

	var result []Glossary

	query := c.db.Order("`key` ASC")

	if searchText != "" {

		fullTextSearchQuery := fmt.Sprintf("MATCH(`key`, `value`) AGAINST('%s*' IN BOOLEAN MODE)", searchText)

		query = query.Where(fullTextSearchQuery)

	}

	if err := query.Find(&result).Error; err != nil {

		return nil, err

	}

	return result, nil

}

// Fetch a glossary by its ID
func (c *glossaryRepo) GetGlossaryByID(ctx context.Context, id int64) (*Glossary, error) {
	var (
		result Glossary
	)

	if err := c.db.Where("id = ?", id).First(&result).Error; err != nil {
		return nil, err
	}

	return &result, nil
}

// delete glossary based on id
func (c *glossaryRepo) DeleteGlossary(ctx context.Context, id int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	result := tx.Model(&Glossary{}).Where("id = ?", id).Delete(&Glossary{})
	if result.RowsAffected == 0 {
		tx.Rollback()
		return errors.New("no glossary found with the given id")
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Update the properties of an existing Glossary
func (c *glossaryRepo) UpdateGlossary(ctx context.Context, glossary Glossary) (*Glossary, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&glossary).Where("id = ?", glossary.ID).Updates(&Glossary{
		Key:   glossary.Key,
		Value: glossary.Value,
	}).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return &glossary, nil

}

func (c *glossaryRepo) CreateGlossary(ctx context.Context, glossary *Glossary) (*Glossary, error) {

	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(glossary).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return glossary, nil

}

//BATCH INSERT FUNCTION

func (q *glossaryRepo) BatchInsertGlossary(ctx context.Context, glossaries []Glossary) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(glossaries, len(glossaries)).Error; err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit().Error
}

func (q *glossaryRepo) BatchUpdateGlossary(ctx context.Context, glossaries []Glossary) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, item := range glossaries {
		if err := q.updateGlossaryFields(tx, &item); err != nil {
			tx.Rollback()
			return err

		}
	}
	return tx.Commit().Error
}

// updateGlossaryFields updates the fields of a glossary in the database.
func (q *glossaryRepo) updateGlossaryFields(tx *gorm.DB, glossary *Glossary) error {
	return tx.Model(&Glossary{}).Where("id = ?", glossary.ID).Updates(&Glossary{
		Key:   glossary.Key,
		Value: glossary.Value,
	}).Error
}

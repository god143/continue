package infographicImages

import "time"

type InfographicImage struct {
	ID            *int       `json:"id"`
	InfographicID *int       `json:"infographic_id"`
	ImageURL      *string    `json:"image_url"`
	ImageOrder    int        `json:"image_order"`
	CreatedAt     *time.Time `json:"created_at"`
	UpdatedAt     *time.Time `json:"updated_at"`
}

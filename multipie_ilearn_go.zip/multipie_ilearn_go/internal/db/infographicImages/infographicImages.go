package infographicImages

import (
	"context"
	"errors"
	"fmt"

	"gorm.io/gorm"
)

// GetInfographicImageByID retrieves a single InfographicImage by its ID.
func (i *infographicImageRepo) GetInfographicImageByID(ctx context.Context, imageID int64) (InfographicImage, error) {
	var image InfographicImage

	if err := i.db.First(&image, imageID).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return image, fmt.Errorf("infographic image not found: ID %d", imageID)
		}
		return image, err
	}

	return image, nil
}

// GetInfographicImagesByInfographicID retrieves all images associated with an infographic.
func (i *infographicImageRepo) GetInfographicImagesByInfographics(ctx context.Context, infographicIDs []int64) ([]InfographicImage, error) {
	var images []InfographicImage

	if err := i.db.Where("infographic_id IN ?", infographicIDs).
		Order("infographic_id DESC, image_order ASC").
		Find(&images).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("no infographic images found for infographicID %d", infographicIDs)
		}
		return nil, err
	}
	return images, nil
}

// CreateInfographicImage inserts a new InfographicImage into the database.
func (i *infographicImageRepo) CreateInfographicImage(ctx context.Context, image *InfographicImage) (*InfographicImage, error) {
	tx := i.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(image).Error; err != nil {
		return nil, i.handleTransaction(tx, fmt.Errorf("error in inserting images, error: %v", err))
	}

	return image, i.handleTransaction(tx, nil)
}

// UpdateInfographicImage updates an existing InfographicImage.
func (i *infographicImageRepo) UpdateInfographicImage(ctx context.Context, image *InfographicImage) (*InfographicImage, error) {
	tx := i.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&InfographicImage{}).Where("id = ?", image.ID).Updates(image).Error; err != nil {
		return nil, i.handleTransaction(tx, fmt.Errorf("error in updating infographic_image, error: %v", err))
	}

	return image, i.handleTransaction(tx, nil)
}

// DeleteInfographicImage marks an InfographicImage as deleted (soft delete).
func (i *infographicImageRepo) DeleteInfographicImage(ctx context.Context, id int64) error {
	var imageToDelete InfographicImage

	tx := i.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.First(&imageToDelete, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return i.handleTransaction(tx, fmt.Errorf("infographic image not found: %d", id))
		}
		return i.handleTransaction(tx, err)
	}

	if err := tx.Model(&InfographicImage{}).Where("id = ?", id).Delete(&InfographicImage{}).Error; err != nil {
		return i.handleTransaction(tx, fmt.Errorf("error in deleting the infographic_image, error: %v", err))
	}

	return i.handleTransaction(tx, nil)
}

// infographic_id
func (i *infographicImageRepo) handleTransaction(tx *gorm.DB, err error) error {
	if err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit().Error
}

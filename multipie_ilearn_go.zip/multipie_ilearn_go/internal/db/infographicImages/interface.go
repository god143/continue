package infographicImages

import (
	"context"
	//"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

type InfographicImageRepo interface {
	GetInfographicImageByID(ctx context.Context, imageID int64) (InfographicImage, error)
	GetInfographicImagesByInfographics(ctx context.Context, infographicIDs []int64) ([]InfographicImage, error)
	CreateInfographicImage(ctx context.Context, image *InfographicImage) (*InfographicImage, error)
	UpdateInfographicImage(ctx context.Context, image *InfographicImage) (*InfographicImage, error)
	DeleteInfographicImage(ctx context.Context, id int64) error
}

type infographicImageRepo struct {
	db *gorm.DB
}

func NewInfographicImageRepo(db *gorm.DB) InfographicImageRepo {
	return &infographicImageRepo{
		db: db,
	}
}

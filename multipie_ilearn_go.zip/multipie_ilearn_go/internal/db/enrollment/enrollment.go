package enrollment

import (
	"context"
)

// Get all active Enrollments
func (c *enrollmentRepo) GetEnrollments(ctx context.Context, userID int64) ([]Enrollment, error) {
	var (
		result []Enrollment
	)

	query := c.db.Where("user_id = ?", userID)

	if err := query.Find(&result).Error; err != nil {
		return nil, err
	}
	return result, nil
}

// Fetch a Enrollment by its ID
func (c *enrollmentRepo) GetEnrollmentByCourseID(ctx context.Context, userID int64, courseID *int64) (*Enrollment, error) {
	var (
		result Enrollment
	)

	query := c.db.Where("user_id = ?", userID).Where("course_id = ?", courseID)

	if err := query.First(&result).Error; err != nil {
		return nil, err
	}

	return &result, nil
}

// Update the properties of an existing Enrollment
func (c *enrollmentRepo) UpdateEnrollment(ctx context.Context, enrollment Enrollment) (*Enrollment, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&enrollment).Where("user_id = ?", enrollment.UserID).Where("course_id = ?", enrollment.CourseID).Updates(&Enrollment{
		Status: enrollment.Status,
	}).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return &enrollment, nil

}

func (c *enrollmentRepo) CreateEnrollment(ctx context.Context, enrollment *Enrollment) (*Enrollment, error) {

	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(enrollment).Error; err != nil {
		tx.Rollback()
		return &Enrollment{}, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return enrollment, nil
}

// Batch Insertion in courses table
func (c *enrollmentRepo) BatchCreateEnrollment(ctx context.Context, enrollment []Enrollment) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(enrollment, len(enrollment)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

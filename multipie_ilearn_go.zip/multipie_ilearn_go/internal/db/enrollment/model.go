package enrollment

import (
	"time"
)

// Enrollment represents the structure of the `enrollment` table in the database.
type Enrollment struct {
	ID             *int64     `json:"id,omitempty"`              // Unique ID for the enrollment
	UserID         *int64     `json:"user_id,omitempty"`         // user_id of enrollment
	CourseID       *int64     `json:"course_id,omitempty"`       // Course_id of the Enrollment
	Status         *string    `json:"status,omitempty"`          // status (nullable)
	EnrollmentDate *time.Time `json:"enrollment_date,omitempty"` //enrollment_date
	CreatedAt      *time.Time `json:"-"`                         // Timestamp when the Enrollment was created
	UpdatedAt      *time.Time `json:"-"`                         // Timestamp when the Enrollment was last updated
}

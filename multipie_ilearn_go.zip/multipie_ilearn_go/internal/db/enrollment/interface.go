package enrollment

import (
	"context"

	"gorm.io/gorm"
)

type enrollmentRepo struct {
	db *gorm.DB
}

type EnrollmentRepo interface {
	GetEnrollments(ctx context.Context, userID int64) ([]Enrollment, error)
	GetEnrollmentByCourseID(ctx context.Context, userID int64, courseID *int64) (*Enrollment, error)
	UpdateEnrollment(ctx context.Context, enrollment Enrollment) (*Enrollment, error)
	CreateEnrollment(ctx context.Context, enrollment *Enrollment) (*Enrollment, error)
	BatchCreateEnrollment(ctx context.Context, enrollment []Enrollment) error
}

func NewEnrollmentRepo(db *gorm.DB) EnrollmentRepo {
	return &enrollmentRepo{
		db: db,
	}
}

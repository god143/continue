package activeStorage

import (
	"context"

	"gorm.io/gorm"
)

type activeStorageRepo struct {
	db *gorm.DB
}

type ActiveStorageRepo interface {
	CreateActiveStorageRecord(ctx context.Context, record ActiveStorage) (*ActiveStorage, error)
	UpdateActiveStorageRecord(ctx context.Context, record ActiveStorage) (*ActiveStorage, error)
	DeleteActiveStorageRecord(ctx context.Context, modelType string, modelID int) error
	GetActiveStorageRecord(ctx context.Context, modelType string, modelID int, attachmentType string, isPrimary bool) (ActiveStorage, error)
	GetActiveStorageRecordById(ctx context.Context, id int64) (ActiveStorage, error)
	GetActiveStorageRecordByKey(ctx context.Context, key string, fileName string) (ActiveStorage, error)
	BatchCreateActiveStorageRecords(ctx context.Context, course []ActiveStorage) error
}

func NewActiveStorageRepo(db *gorm.DB) ActiveStorageRepo {
	return &activeStorageRepo{
		db: db,
	}
}

package activeStorage

import "context"

// CreateActiveStorageRecord... Create active_storage record entry
func (a *activeStorageRepo) CreateActiveStorageRecord(ctx context.Context, record ActiveStorage) (*ActiveStorage, error) {
	tx := a.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(&record).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return &record, nil
}

func (a *activeStorageRepo) UpdateActiveStorageRecord(ctx context.Context, record ActiveStorage) (*ActiveStorage, error) {
	tx := a.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Model(&ActiveStorage{}).Where("id = ?", record.ID).Updates(&ActiveStorage{
		Filename:    record.Filename,
		Metadata:    record.Metadata,
		ContentType: record.ContentType,
		ByteSize:    record.ByteSize,
		Checksum:    record.Checksum,
		ServiceName: record.ServiceName,
		ModelType:   record.ModelType,
		ModelID:     record.ModelID,
		Filekey:     record.Filekey,
	}).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}
	return &record, nil
}

func (a *activeStorageRepo) DeleteActiveStorageRecord(ctx context.Context, modelType string, modelID int) error {
	tx := a.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.Where("model_type = ?", modelType).Where("model_id = ?", modelID).Delete(&ActiveStorage{}).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (a *activeStorageRepo) GetActiveStorageRecord(ctx context.Context, modelType string, modelID int, attachmentType string, isPrimary bool) (ActiveStorage, error) {
	var activeStorage ActiveStorage

	if err := a.db.Where("model_type = ?", modelType).Where("model_id = ?", modelID).First(&activeStorage).Error; err != nil {
		return activeStorage, err
	}

	return activeStorage, nil
}

func (a *activeStorageRepo) GetActiveStorageRecordById(ctx context.Context, id int64) (ActiveStorage, error) {
	var activeStorage ActiveStorage

	if err := a.db.Where("id = ?", id).First(&activeStorage).Error; err != nil {
		return activeStorage, err
	}

	return activeStorage, nil
}

func (a *activeStorageRepo) GetActiveStorageRecordByKey(ctx context.Context, key string, fileName string) (ActiveStorage, error) {
	var activeStorage ActiveStorage

	if err := a.db.Where("filekey = ?", key).Where("fileName = ? ", fileName).First(&activeStorage).Error; err != nil {
		return activeStorage, err
	}

	return activeStorage, nil
}

func (c *activeStorageRepo) BatchCreateActiveStorageRecords(ctx context.Context, activeStorage []ActiveStorage) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(activeStorage, len(activeStorage)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

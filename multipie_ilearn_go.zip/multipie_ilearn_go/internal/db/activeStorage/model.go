package activeStorage

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"time"
)

type ActiveStorage struct {
	ID            *int64                 `json:"id"`
	Filekey       *string                `json:"Filekey"`
	Filename      *string                `json:"filename"`
	ContentType   *string                `json:"content_type"`
	Metadata      *ActiveStorageMetaData `json:"metadata" gorm:"type:json"`
	ByteSize      *int64                 `json:"byte_size"`
	Checksum      *string                `json:"check_sum"`
	CreatedAt     *time.Time             `json:"created_at"`
	ServiceName   *string                `json:"service_name"`
	UpdatedAt     *time.Time             `json:"updated_at"`
	ModelType     *string                `json:"model_type"` // Polymorphic association: model type (e.g., Category, Course)
	ModelID       *int64                 `json:"model_id"`   // Polymorphic association: model ID (e.g., Category ID, Course ID)
	AttachmentFor *string                `json:"attachment_for"`
	IsPrimary     *bool                  `json:"is_primary"`
}

type ActiveStorageMetaData struct {
	Height *int `json:"height"`
	Width  *int `json:"width"`
}

func (u *ActiveStorageMetaData) Value() (driver.Value, error) {

	jsonData, err := json.Marshal(u)
	if err != nil {
		fmt.Println("error with value method, error", err)
		return nil, err
	}

	return jsonData, nil
}

func (u *ActiveStorageMetaData) Scan(src interface{}) error {
	var metaData ActiveStorageMetaData

	err := json.Unmarshal(src.([]byte), &metaData)
	if err != nil {
		fmt.Println("error with scan method, error", err)
		return err
	}

	*u = metaData
	return nil
}

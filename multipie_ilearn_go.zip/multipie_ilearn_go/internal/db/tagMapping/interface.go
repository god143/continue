package tagMapping

import (
	"context"
	dbModel "multipie_ilearn_go/internal/db/tags"

	"gorm.io/gorm"
)

type tagMappingRepo struct {
	db *gorm.DB
}

type TagMappingRepo interface {
	CreateTagMapping(ctx context.Context, tagmap *TagMapping) error
	UpdateTagMapping(ctx context.Context, tagmap *TagMapping) error
	DeleteTagMapping(ctx context.Context, tagmap *TagMapping) error
	GetTagMapping(ctx context.Context, key *string) ([]TagMapping, error)
	GetTagsByModel(ctx context.Context, modelID int64, modelType string) ([]dbModel.Tags, error)
}

func NewTagMappingRepo(db *gorm.DB) TagMappingRepo {
	return &tagMappingRepo{
		db: db,
	}
}

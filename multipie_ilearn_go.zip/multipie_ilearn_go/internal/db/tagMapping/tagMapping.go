package tagMapping

import (
	"context"
	"errors"
	dbModel "multipie_ilearn_go/internal/db/tags"
)

/*
CreateTagMapping....creates tagMapping in database
*/
func (t *tagMappingRepo) CreateTagMapping(ctx context.Context, tag *TagMapping) error {
	tx := t.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.Create(tag).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil

}

/*
UpdateTagMapping....update tag mapping(model_id and model_type) of particular id in database
*/
func (c *tagMappingRepo) UpdateTagMapping(ctx context.Context, tagmapping *TagMapping) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	result := tx.Model(&TagMapping{}).Where("id = ?", tagmapping.ID).Updates(&TagMapping{
		ModelId:   tagmapping.ModelId,
		ModelType: tagmapping.ModelType,
	})

	if result.RowsAffected == 0 {
		tx.Rollback()
		return errors.New("no tag mapping found with given id")
	}

	if result.Error != nil {
		tx.Rollback()
		return result.Error
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil

}

/*
DeleteTagMapping....delete tag mapping of particular id in database
*/
func (c *tagMappingRepo) DeleteTagMapping(ctx context.Context, tag *TagMapping) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	result := tx.Delete(tag)
	if result.RowsAffected == 0 {
		tx.Rollback()
		return errors.New("no tag mapping found with given id")
	}

	if result.Error != nil {
		tx.Rollback()
		return result.Error
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil

}

/*
GetTagMapping.... fetch all tag mappings related to key from database
*/
func (c *tagMappingRepo) GetTagMapping(ctx context.Context, key *string) ([]TagMapping, error) {

	var tagMappinglist []TagMapping

	if err := c.db.Model(&TagMapping{}).Joins("JOIN tags ON tags.id=tag_mappings.tag_id").Select("tag_mappings.model_id, tag_mappings.model_type").
		Where("tags.key IN (?)", key).Find(&tagMappinglist).
		Error; err != nil {
		return nil, err
	}
	return tagMappinglist, nil
}

func (c *tagMappingRepo) GetTagsByModel(ctx context.Context, modelID int64, modelType string) ([]dbModel.Tags, error) {
	var tags []dbModel.Tags

	err := c.db.Table("tags").
		Select("tags.*").
		Joins("JOIN tag_mappings ON tag_mappings.tag_id = tags.id").
		Where("tag_mappings.model_id = ? AND tag_mappings.model_type = ?", modelID, modelType).
		Find(&tags).Error

	if err != nil {
		return nil, err
	}

	return tags, nil
}

package tagMapping

import (
	"time"
)

type TagMapping struct {
	ID        *int64     `json:"id,omitempty"`
	TagID     *int64     `json:"tag_id,omitempty"`
	ModelId   *int64     `json:"model_id"`
	ModelType *string    `json:"model_type"`
	CreatedAt *time.Time `json:"-"`
	UpdatedAt *time.Time `json:"-"`
}

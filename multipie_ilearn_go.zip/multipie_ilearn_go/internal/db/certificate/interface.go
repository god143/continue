package certificate

import (
	"context"

	"gorm.io/gorm"
)

type certificateRepo struct {
	db *gorm.DB
}

type CertificateRepo interface {
	GetCertificateByModelIDModelType(ctx context.Context, modelID *int64, modelType *string, userID int64) (*Certificate, error)
	CreateCertificate(ctx context.Context, certificate *Certificate) (*Certificate, error)
	UpdateCertificateURL(ctx context.Context, certificateID int64, url string) error
	GetCertificateByModelType(ctx context.Context, modelType *string, userID int64) (*[]Certificate, error)
	BatchCreateCertificate(ctx context.Context, course []Certificate) error
}

func NewCertificateRepo(db *gorm.DB) CertificateRepo {
	return &certificateRepo{
		db: db,
	}
}

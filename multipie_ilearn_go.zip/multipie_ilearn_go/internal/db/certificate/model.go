package certificate

import (
	"time"
)

// Certificate represents the structure of the `certificate` table in the database.
type Certificate struct {
	ID        *int64     `json:"id,omitempty"`         // Unique ID for the certificate
	UserID    *int64     `json:"user_id,omitempty"`    // user_id of certificate
	URL       *string    `json:"url"`                  // url of certificate
	ModelType *string    `json:"model_type,omitempty"` // model_type
	ModelID   *int64     `json:"model_id,omitempty"`   // model_id of certificate
	CreatedAt *time.Time `json:"-"`                    // Timestamp when the certificate was created
	UpdatedAt *time.Time `json:"-"`                    // Timestamp when the certificate was last updated
}

package certificate

import (
	"context"
)

// Fetch a Certificate by its ModelID and ModelType
func (c *certificateRepo) GetCertificateByModelIDModelType(ctx context.Context, modelID *int64, modelType *string, userID int64) (*Certificate, error) {

	var certificates Certificate

	query := c.db.Where("user_id=?", userID)

	if modelID != nil {
		query = query.Where("model_id=?", *modelID)
	}

	if modelType != nil {
		query = query.Where("model_type=?", *modelType)
	}

	if err := query.Find(&certificates).Error; err != nil {
		return nil, err
	}

	return &certificates, nil
}

// Fetch a Certificate by ModelType
func (c *certificateRepo) GetCertificateByModelType(ctx context.Context, modelType *string, userID int64) (*[]Certificate, error) {

	var certificates []Certificate

	query := c.db.Where("user_id=?", userID)

	query = query.Where("model_type=?", *modelType)

	if err := query.Find(&certificates).Error; err != nil {
		return nil, err
	}

	return &certificates, nil
}

// Create certificate
func (c *certificateRepo) CreateCertificate(ctx context.Context, certificate *Certificate) (*Certificate, error) {

	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(certificate).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return certificate, nil

}

func (c *certificateRepo) UpdateCertificateURL(ctx context.Context, certificateID int64, url string) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.Model(&Certificate{}).Where("id = ?", certificateID).Update("url", url).Error; err != nil {
		tx.Rollback()
		return err
	}

	return tx.Commit().Error
}

func (c *certificateRepo) BatchCreateCertificate(ctx context.Context, certificate []Certificate) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(certificate, len(certificate)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

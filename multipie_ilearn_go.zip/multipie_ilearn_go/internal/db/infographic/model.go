package infographic

import "time"

type Infographic struct {
	ID          *int       `json:"id"`
	Name        *string    `json:"name"`
	CategoryID  *int       `json:"category_id"`
	Description *string    `json:"description"`
	Likes       *int       `json:"likes"`
	Views       *int       `json:"views"`
	Visible     *bool      `json:"visible"`
	UploadTime  *time.Time `json:"upload_time"`
	IsBookmark  *bool      `json:"is_bookmark" gorm:"-"`
	BookmarkId  *int64     `json:"bookmark_id" gorm:"-"`
	CreatedAt   *time.Time `json:"-"`
	UpdatedAt   *time.Time `json:"-"`
}

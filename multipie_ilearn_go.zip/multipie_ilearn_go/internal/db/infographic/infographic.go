package infographic

import (
	"context"
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/utils"

	"go.uber.org/zap"
	"gorm.io/gorm"
)

func (i *infographicRepo) GetInfographicByID(ctx context.Context, infographicID int64, visibility *bool) (Infographic, error) {
	var infographic Infographic

	query := i.db.First(&infographic, infographicID)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return infographic, fmt.Errorf("infographic not found: ID %d", infographicID)
		}
		return infographic, err
	}
	return infographic, nil
}

func (i *infographicRepo) GetInfographicByIDs(ctx context.Context, infographicIDs []*int64, visibility *bool) ([]Infographic, error) {
	var infographic []Infographic

	query := i.db.Where("id in (?)", infographicIDs).Order("upload_time DESC")
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Find(&infographic).Error; err != nil {
		return nil, err
	}
	return infographic, nil
}

func (i *infographicRepo) GetInfographics(ctx context.Context, categoryID *int64, visibility *bool, page int, pageSize int, filter constants.FilterTypeEnum) ([]Infographic, error) {
	var infographics []Infographic

	pagination := utils.Pagination{
		Page:     int(page),
		PageSize: int(pageSize),
	}

	query := i.db.WithContext(ctx).Table("infographics")

	if categoryID != nil {
		query = query.Where("category_id = ?", categoryID)
	}
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}

	if filter == constants.FilterTypeEnumTrending {
		query = query.Where("views > ?", 100).Order("views DESC")
	}else{
		query = query.Order("upload_time DESC")
	}

	if err := query.Find(&infographics).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, errors.New("no infographics found matching the criteria")
		}
		return nil, fmt.Errorf("failed to fetch infographics: %v", err)
	}

	if err := utils.Paginate(i.db, &infographics, &pagination, query); err != nil {
		return nil, fmt.Errorf("pagination error: %v", err)
	}

	return infographics, nil
}

func (i *infographicRepo) CreateInfographic(ctx context.Context, infographic *Infographic) (*Infographic, error) {
	tx := i.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(infographic).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return infographic, nil
}

func (i *infographicRepo) UpdateInfographic(ctx context.Context, infographic *Infographic) (*Infographic, error) {
	tx := i.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	logger.Debug(ctx, "logging the request body of update infographic", zap.Any("infographic>uploadtime", infographic.UploadTime))
	if err := i.updateInfographicFields(tx, infographic); err != nil {
		tx.Rollback()
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("infographic not found: infographicID %d", *infographic.ID)
		}
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return infographic, nil
}

// Mark a course as deleted by setting visible = false
func (i *infographicRepo) DisbaleInfographic(ctx context.Context, id int64) error {
	tx := i.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Infographic{}).Where("id = ?", id).Updates(&Infographic{
		Visible: utils.BoolToPointer(false),
	})
	if err := query.Error; err != nil {
		tx.Rollback()
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return fmt.Errorf("infographic not found: infographicId %d", id)
		}
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Batch Insertion in courses table
func (i *infographicRepo) BatchCreateInfographic(ctx context.Context, infographics []Infographic) error {
	tx := i.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(infographics, len(infographics)).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

// Batch Updation in course table
func (i *infographicRepo) BatchUpdateInfographic(ctx context.Context, infographics []Infographic) error {
	tx := i.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, item := range infographics {

		if err := i.updateInfographicFields(tx, &item); err != nil {
			tx.Rollback()
			return err
		}
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (i *infographicRepo) updateInfographicFields(tx *gorm.DB, infographic *Infographic) error {

	if infographic.UploadTime.IsZero() {
		fmt.Printf("upload time field is nil")
		return nil

	}
	fmt.Println("uploaded time", infographic.UploadTime.UTC())

	return tx.Model(&Infographic{}).Where("id = ?", infographic.ID).Updates(&Infographic{
		Name:        infographic.Name,
		CategoryID:  infographic.CategoryID,
		Description: infographic.Description,
		Likes:       infographic.Likes,
		Views:       infographic.Views,
		UploadTime:  utils.TimeToPointer(infographic.UploadTime.UTC()),
	}).Error

}

func (i *infographicRepo) UpdateViewsCountInfographic(ctx context.Context, infographicID int64) error {
	tx := i.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Infographic{}).Where("id = ?", infographicID).
		Update("views", gorm.Expr("COALESCE(views, 0) + ?", 1))

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (i *infographicRepo) UpdateLikesCountInfographic(ctx context.Context, infographicID int64, action string) error {
	tx := i.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Infographic{}).Where("id = ?", infographicID)

	if action == "like" {
		query = query.Update("likes", gorm.Expr("COALESCE(likes, 0) + ?", 1))
	} else if action == "unlike" {
		query = query.Update("likes", gorm.Expr("CASE WHEN COALESCE(likes, 0) > 0 THEN likes - 1 ELSE 0 END"))
	}

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

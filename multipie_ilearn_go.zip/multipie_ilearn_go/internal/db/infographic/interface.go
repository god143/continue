package infographic

import (
	"context"
	"multipie_ilearn_go/internal/constants"

	"gorm.io/gorm"
)

type infographicRepo struct {
	db *gorm.DB
}

type InfographicRepo interface {
	GetInfographicByID(ctx context.Context, infographicID int64, visibility *bool) (Infographic, error)
	GetInfographicByIDs(ctx context.Context, infographicIDs []*int64, visibility *bool) ([]Infographic, error)
	GetInfographics(ctx context.Context, categoryID *int64, visibility *bool, page int, pageSize int, filter constants.FilterTypeEnum) ([]Infographic, error)
	CreateInfographic(ctx context.Context, infographic *Infographic) (*Infographic, error)
	UpdateInfographic(ctx context.Context, infographic *Infographic) (*Infographic, error)
	DisbaleInfographic(ctx context.Context, id int64) error
	BatchCreateInfographic(ctx context.Context, infographics []Infographic) error
	BatchUpdateInfographic(ctx context.Context, infographics []Infographic) error
	UpdateViewsCountInfographic(ctx context.Context, infographicID int64) error
	UpdateLikesCountInfographic(ctx context.Context, infographicID int64, action string) error
}

func NewInfographicRepo(db *gorm.DB) InfographicRepo {
	return &infographicRepo{
		db: db,
	}
}

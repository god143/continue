package courseModules

import (
	"context"

	"gorm.io/gorm"
)

type courseModuleRepo struct {
	db *gorm.DB
}

type CourseModuleRepo interface {
	GetCourseModuleByID(ctx context.Context, courseID int64) (CourseModule, error)
	GetCourseModuleByIDs(ctx context.Context, courseIDs []*int64, visible *bool) ([]CourseModuleInfo, error)
	GetCourseModules(ctx context.Context, courseID int64) ([]CourseModule, error)
	CreateCourseModule(ctx context.Context, courseModule *CourseModule) (*CourseModule, error)
	UpdateCourseModule(ctx context.Context, courseModule *CourseModule) (*CourseModule, error)
	DeleteCourseModule(ctx context.Context, id int64) error
	BatchCreateCourseModules(ctx context.Context, courseModules []CourseModule) error
	BatchUpdateCourseModules(ctx context.Context, courseModules []CourseModule) error
	GetCourseModuleByIDWithResource(ctx context.Context, courseID int64) (CourseModuleWithResource, error)
	GetCourseModulesWithResource(ctx context.Context, courseID int64) ([]CourseModuleWithResource, error)
	UpdateViewsCountCourseModule(ctx context.Context, moduleID int64) error
	UpdateLikesCountCourseModule(ctx context.Context, moduleID int64, action string) error
}

func NewCourseModuleRepo(db *gorm.DB) CourseModuleRepo {
	return &courseModuleRepo{
		db: db,
	}
}

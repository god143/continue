package courseModules

import (
	"context"
	"errors"
	"fmt"

	"gorm.io/gorm"
)

func (c *courseModuleRepo) GetCourseModuleByID(ctx context.Context, moduleID int64) (CourseModule, error) {
	var module CourseModule

	query := c.db.First(&module, moduleID)
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return module, fmt.Errorf("module not found, moduleID %d", moduleID)
		}
		return module, err
	}

	return module, nil
}

func (c *courseModuleRepo) GetCourseModuleByIDs(ctx context.Context, moduleIDs []*int64, visible *bool) ([]CourseModuleInfo, error) {
	var modules []CourseModuleInfo

	_ = c.db.Table("course_modules").
		Select(`
		categories.parent AS parent_id,
		parent_category.name AS parent_category_name,
		course_modules.duration AS duration, course_modules.content_type AS content_type, course_modules.id AS course_module_id, categories.type AS product_category, 
		courses.fullname AS course_name, courses.id AS course_id, course_modules.module_order, course_modules.name, course_modules.description,
		resources.url AS url, resources.dark_mode_url AS dark_mode_url`).
		Joins("JOIN courses ON course_modules.course_id = courses.id").
		Joins("JOIN categories ON courses.category_id = categories.id").
		Joins("LEFT JOIN categories AS parent_category ON categories.parent = parent_category.id").
		Joins("LEFT JOIN resources ON resources.course_module_id = course_modules.id").
		Where("course_modules.id IN ? AND resources.visible=? ", moduleIDs, visible).
		Find(&modules)

	if len(modules) == 0 {
		return nil, fmt.Errorf("no course modules found for the given moduleIDs")
	}

	return modules, nil
}

func (c *courseModuleRepo) GetCourseModuleByIDWithResource(ctx context.Context, moduleID int64) (CourseModuleWithResource, error) {
	var moduleWithURLs CourseModuleWithResource

	query := c.db.Table("course_modules").
		Select("course_modules.*, resources.url, resources.dark_mode_url").
		Joins("LEFT JOIN resources ON resources.course_module_id = course_modules.id").
		Where("course_modules.id = ?", moduleID).
		First(&moduleWithURLs)

	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return moduleWithURLs, fmt.Errorf("module not found, moduleID %d", moduleID)
		}
		return moduleWithURLs, err
	}

	return moduleWithURLs, nil
}

func (c *courseModuleRepo) GetCourseModules(ctx context.Context, courseID int64) ([]CourseModule, error) {
	var modules []CourseModule

	query := c.db.Where("course_id = ?", courseID).Find(&modules)
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("no modules found for the given course, courseID: %v", courseID)
		}
		return nil, err
	}

	return modules, nil
}

func (c *courseModuleRepo) GetCourseModulesWithResource(ctx context.Context, courseID int64) ([]CourseModuleWithResource, error) {
	var modulesWithURLs []CourseModuleWithResource

	query := c.db.Table("course_modules").
		Select("course_modules.*, resources.url, resources.dark_mode_url").
		Joins("LEFT JOIN resources ON resources.course_module_id = course_modules.id AND resources.visible = ?", true).
		Where("course_modules.course_id = ?", courseID).
		Find(&modulesWithURLs)

	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("no modules found for the given course, courseID: %v", courseID)
		}
		return nil, err
	}

	return modulesWithURLs, nil
}
func (c *courseModuleRepo) adjustExistingModulesOrder(tx *gorm.DB, courseID int64, newOrder int) error {
	// Shift modules with order greater than or equal to the new module order by 1
	return tx.Model(&CourseModule{}).
		Where("course_id = ? AND module_order >= ?", courseID, newOrder).
		Update("module_order", gorm.Expr("module_order + ?", 1)).Error
}

// Helper to adjust module order when creating or updating modules
func (c *courseModuleRepo) adjustModuleOrder(tx *gorm.DB, courseID int64, oldOrder, newOrder int) error {
	if newOrder > oldOrder { // Moving down the order
		return tx.Model(&CourseModule{}).
			Where("course_id = ? AND module_order >= ? AND module_order < ?", courseID, oldOrder, newOrder).
			Update("module_order", gorm.Expr("module_order - ?", 1)).Error
	} else if newOrder < oldOrder { // Moving up the order
		return tx.Model(&CourseModule{}).
			Where("course_id = ? AND module_order > ? AND module_order <= ?", courseID, newOrder, oldOrder).
			Update("module_order", gorm.Expr("module_order + ?", 1)).Error
	}
	return nil
}

// Helper to set the correct module_order during course module creation
func (c *courseModuleRepo) setModuleOrder(tx *gorm.DB, courseID int64, courseModule *CourseModule) error {
	if courseModule.ModuleOrder == nil || *courseModule.ModuleOrder <= 0 {
		var nextModuleOrder int
		if err := c.nextModuleOrderForCourse(tx, courseID, &nextModuleOrder); err != nil {
			return err
		}
		courseModule.ModuleOrder = &nextModuleOrder
	} else {
		// If module_order is specified, adjust existing modules
		err := c.adjustExistingModulesOrder(tx, courseID, *courseModule.ModuleOrder)
		if err != nil {
			return err
		}
	}
	return nil
}

// Helper to handle transaction commit/rollback
func (c *courseModuleRepo) handleTransaction(tx *gorm.DB, err error) error {
	if err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit().Error
}

func (c *courseModuleRepo) CreateCourseModule(ctx context.Context, courseModule *CourseModule) (*CourseModule, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := c.setModuleOrder(tx, int64(*courseModule.CourseID), courseModule); err != nil {
		return nil, c.handleTransaction(tx, err)
	}

	if err := tx.Create(courseModule).Error; err != nil {
		return nil, c.handleTransaction(tx, fmt.Errorf("error inserting module: %w", err))
	}

	if err := c.updateCourseModuleCount(tx, int64(*courseModule.CourseID)); err != nil {
		return nil, c.handleTransaction(tx, fmt.Errorf("error updating module count in course table: %w", err))
	}

	return courseModule, c.handleTransaction(tx, nil)
}

func (c *courseModuleRepo) UpdateCourseModule(ctx context.Context, courseModule *CourseModule) (*CourseModule, error) {
	tx := c.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if courseModule.ModuleOrder != nil {
		// Fetch current module data
		currCourseModule, err := c.GetCourseModuleByID(ctx, int64(*courseModule.ID))
		if err != nil {
			return nil, c.handleTransaction(tx, err)
		}

		// If the module_order has changed, adjust the order
		if *courseModule.ModuleOrder != *currCourseModule.ModuleOrder {
			if err := c.adjustModuleOrder(tx, int64(*courseModule.CourseID), *currCourseModule.ModuleOrder, *courseModule.ModuleOrder); err != nil {
				return nil, c.handleTransaction(tx, err)
			}
		}
	}

	// Update the module fields
	if err := c.updateCourseModuleFields(tx, courseModule); err != nil {
		return nil, c.handleTransaction(tx, fmt.Errorf("error updating module: %w", err))
	}

	return courseModule, c.handleTransaction(tx, nil)
}

func (c *courseModuleRepo) DeleteCourseModule(ctx context.Context, id int64) error {
	var moduleToDelete CourseModule
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.First(&moduleToDelete, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return c.handleTransaction(tx, fmt.Errorf("course module not found: %d", id))
		}
		return c.handleTransaction(tx, err)
	}

	if err := c.adjustModuleOrderOnDelete(tx, int64(*moduleToDelete.CourseID), *moduleToDelete.ModuleOrder); err != nil {
		return c.handleTransaction(tx, err)
	}

	query := tx.Delete(&CourseModule{}, "id = ?", id)
	if err := query.Error; err != nil {
		return c.handleTransaction(tx, fmt.Errorf("error deleting course module: %w", err))
	}

	return c.handleTransaction(tx, nil)
}

func (c *courseModuleRepo) adjustModuleOrderOnDelete(tx *gorm.DB, courseID int64, deletedModuleOrder int) error {
	return tx.Model(&CourseModule{}).
		Where("course_id = ? AND module_order > ?", courseID, deletedModuleOrder).
		Update("module_order", gorm.Expr("module_order - ?", 1)).Error
}

func (c *courseModuleRepo) BatchCreateCourseModules(ctx context.Context, courseModules []CourseModule) error {
	if len(courseModules) == 0 {
		return fmt.Errorf("no course modules to insert")
	}

	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, module := range courseModules {
		// Set the correct module order
		if err := c.setModuleOrder(tx, int64(*module.CourseID), &module); err != nil {
			tx.Rollback()
			return err
		}

		// Insert the module
		if err := tx.Create(&module).Error; err != nil {
			tx.Rollback()
			return fmt.Errorf("error inserting module: %w", err)
		}

		if err := c.updateCourseModuleCount(tx, int64(*module.CourseID)); err != nil {
			tx.Rollback()
			return fmt.Errorf("error updating module count: %w", err)
		}
	}

	return c.handleTransaction(tx, nil)
}

func (c *courseModuleRepo) BatchUpdateCourseModules(ctx context.Context, courseModules []CourseModule) error {
	if len(courseModules) == 0 {
		return fmt.Errorf("no course modules to update")
	}

	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, module := range courseModules {
		currModule, err := c.GetCourseModuleByID(ctx, int64(*module.ID))
		if err != nil {
			return c.handleTransaction(tx, fmt.Errorf("error fetching current module data: %w", err))
		}

		// If module_order has changed, adjust it
		if *module.ModuleOrder != *currModule.ModuleOrder {
			if err := c.adjustModuleOrder(tx, int64(*module.CourseID), *currModule.ModuleOrder, *module.ModuleOrder); err != nil {
				return c.handleTransaction(tx, err)
			}
		}

		// Update the module fields
		if err := c.updateCourseModuleFields(tx, &module); err != nil {
			return c.handleTransaction(tx, fmt.Errorf("error updating module: %w", err))
		}
	}

	return c.handleTransaction(tx, nil)
}

// Fetch next module order for a given course
func (c *courseModuleRepo) nextModuleOrderForCourse(tx *gorm.DB, courseID int64, nextModuleOrder *int) error {
	return tx.Model(&CourseModule{}).
		Where("course_id = ?", courseID).
		Select("IFNULL(MAX(module_order), 0) + 1").
		Scan(nextModuleOrder).Error
}

// Update course module fields
func (c *courseModuleRepo) updateCourseModuleFields(tx *gorm.DB, courseModule *CourseModule) error {
	return tx.Model(&CourseModule{}).Where("id = ?", courseModule.ID).Updates(&CourseModule{
		CourseID:       courseModule.CourseID,
		Type:           courseModule.Type,
		Name:           courseModule.Name,
		Duration:       courseModule.Duration,
		ContentType:    courseModule.ContentType,
		PassPercentage: courseModule.PassPercentage,
		Likes:          courseModule.Likes,
		View:           courseModule.View,
		ModuleOrder:    courseModule.ModuleOrder,
	}).Error
}

func (c *courseModuleRepo) updateCourseModuleCount(tx *gorm.DB, courseId int64) error {
	query := tx.Table("courses").Where("id = ?", courseId).
		Update("module_count", gorm.Expr("(SELECT COUNT(*) FROM course_modules WHERE course_id = ?)", courseId))

	if err := query.Error; err != nil {
		return err
	}

	return nil
}

func (c *courseModuleRepo) UpdateViewsCountCourseModule(ctx context.Context, moduleID int64) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&CourseModule{}).Where("id = ?", moduleID).
		Update("view", gorm.Expr("COALESCE(view, 0) + ?", 1))

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (c *courseModuleRepo) UpdateLikesCountCourseModule(ctx context.Context, moduleID int64, action string) error {
	tx := c.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&CourseModule{}).Where("id = ?", moduleID)

	if action == "like" {
		query = query.Update("likes", gorm.Expr("COALESCE(likes, 0) + ?", 1))
	} else if action == "unlike" {
		query = query.Update("likes", gorm.Expr("CASE WHEN COALESCE(likes, 0) > 0 THEN likes - 1 ELSE 0 END"))
	}

	if err := query.Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

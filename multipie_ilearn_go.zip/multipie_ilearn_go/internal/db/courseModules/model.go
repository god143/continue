package courseModules

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type CourseModule struct {
	ID             *int                                   `json:"id"`
	CourseID       *int                                   `json:"course_id"`
	Type           *constants.CourseModuleTypeEnum        `json:"type"`
	Name           *string                                `json:"name"`
	Description    *string                                `json:"description"`
	Duration       *int                                   `json:"duration,omitempty"`
	ContentType    *constants.CourseModuleContentTypeEnum `json:"content_type,omitempty"`
	PassPercentage *int                                   `json:"pass_percentage,omitempty"`
	Likes          *int                                   `json:"likes"`
	View           *int                                   `json:"view"`
	ModuleOrder    *int                                   `json:"module_order"`
	CreatedAt      *time.Time                             `json:"created_at"`
	UpdatedAt      *time.Time                             `json:"updated_at"`
}

type CourseModuleInfo struct {
	CourseModuleId     *int    `json:"course_module_id"`
	CourseId           *int    `json:"course_id"`
	ProductCategory    *string `json:"product_category"`
	CourseName         *string `json:"fullname"`
	ModuleOrder        *int    `json:"module_order"`
	Name               *string `json:"name"`
	Description        *string `json:"description"`
	Duration           *int    `json:"duration"`
	ParentCategoryName *string `json:"parent_category_name"`
	ContentType        *string `json:"content_type"`
	URL                *string `json:"url"`
	DarkModeURL        *string `json:"dark_mode_url"`
}

type CourseModuleWithResource struct {
	CourseModule
	ExternalUrl     string `json:"url" gorm:"column:url"`
	ExternalUrlDark string `json:"dark_mode_url" gorm:"column:dark_mode_url"`
	IsBookmark      *bool  `json:"is_bookmark"`
	BookmarkId      *int64 `json:"bookmark_id"`
}

package quiz

import (
	"context"
	"errors"
	"fmt"
	"multipie_ilearn_go/internal/utils"

	"gorm.io/gorm"
)

// for fetching quiz for a course
func (q *quizRepo) GetQuizCourseId(ctx context.Context, courseId int64, visibility *bool) (Quiz, error) {
	var quiz Quiz

	query := q.db.Where("course_id = ?", courseId).First(&quiz)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return quiz, fmt.Errorf("quiz not found with course_id: %v", courseId)
		}

		return quiz, err
	}

	return quiz, nil
}

// for fetching all the independent quiz
func (q *quizRepo) GetIndependentQuiz(ctx context.Context, visibility *bool) ([]Quiz, error) {
	var quiz []Quiz

	query := q.db.Where("course_id is null").Find(&quiz)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Error; err != nil {
		return quiz, err
	}

	return quiz, nil
}

// for fetching the quiz related to course
func (q *quizRepo) GetCourseQuiz(ctx context.Context, visibility *bool) ([]Quiz, error) {
	var quiz []Quiz

	query := q.db.Where("course_id IS NOT NULL").Find(&quiz)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Error; err != nil {
		return quiz, err
	}
	return quiz, nil
}

// to get quiz by ID
func (q *quizRepo) GetQuizById(ctx context.Context, quizId int64, visibility *bool) (Quiz, error) {
	var quiz Quiz

	query := q.db.First(&quiz, quizId)
	if visibility != nil {
		query = query.Where("visible = ?", visibility)
	}
	if err := query.Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return quiz, fmt.Errorf("quiz not found with ID: %v", quizId)
		}

		return quiz, err
	}

	return quiz, nil
}

func (q *quizRepo) CreateQuiz(ctx context.Context, quiz *Quiz) (*Quiz, error) {
	tx := q.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Create(quiz).Error; err != nil {
		return nil, q.handleTransaction(tx, err)
	}

	return quiz, q.handleTransaction(tx, nil)
}

func (q *quizRepo) UpdateQuiz(ctx context.Context, quiz *Quiz) (*Quiz, error) {
	tx := q.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := q.updateQuizFields(tx, quiz); err != nil {
		return nil, q.handleTransaction(tx, err)
	}

	return quiz, q.handleTransaction(tx, nil)
}

func (q *quizRepo) DisableQuiz(ctx context.Context, id int64) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	query := tx.Model(&Quiz{}).Where("id = ?", id).Updates(&Quiz{
		Visible: utils.BoolToPointer(false),
	})
	if err := query.Error; err != nil {
		return q.handleTransaction(tx, err)
	}

	return q.handleTransaction(tx, nil)
}

func (q *quizRepo) BatchCreateQuiz(ctx context.Context, quizzes []Quiz) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	if err := tx.CreateInBatches(quizzes, len(quizzes)).Error; err != nil {
		return q.handleTransaction(tx, err)
	}

	return q.handleTransaction(tx, nil)
}

func (q *quizRepo) BatchUpdateQuiz(ctx context.Context, quizzes []Quiz) error {
	tx := q.db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	for _, item := range quizzes {
		if err := q.updateQuizFields(tx, &item); err != nil {
			return q.handleTransaction(tx, err)
		}
	}

	return q.handleTransaction(tx, nil)
}

func (q *quizRepo) handleTransaction(tx *gorm.DB, err error) error {
	if err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit().Error
}

// updateQuizFields updates the fields of a quiz in the database.
func (q *quizRepo) updateQuizFields(tx *gorm.DB, quiz *Quiz) error {
	return tx.Model(&Quiz{}).Where("id = ?", quiz.ID).Updates(&Quiz{
		Name:            quiz.Name,
		CourseID:        quiz.CourseID,
		PassPercentage:  quiz.PassPercentage,
		NumQuestions:    quiz.NumQuestions,
		CertificateID:   quiz.CertificateID,
		Visible:         quiz.Visible,
		Duration:        quiz.Duration,
		DifficultyLevel: quiz.DifficultyLevel,
	}).Error
}

func (q *quizRepo) GetCourseNameByQuizID(ctx context.Context, quizID int64) (string, error) {
	var courseName string

	err := q.db.WithContext(ctx).
		Table("quizzes").
		Select("courses.fullname").
		Joins("JOIN courses ON quizzes.course_id = courses.id").
		Where("quizzes.id = ?", quizID).
		Scan(&courseName).Error

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return "", fmt.Errorf("no course found for quiz ID: %d", quizID)
		}
		return "", err
	}

	return courseName, nil
}

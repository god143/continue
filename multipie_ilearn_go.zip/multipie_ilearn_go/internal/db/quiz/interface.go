package quiz

import (
	"context"

	"gorm.io/gorm"
)

type quizRepo struct {
	db *gorm.DB
}

type QuizRepo interface {
	GetQuizCourseId(ctx context.Context, courseId int64, visibility *bool) (Quiz, error)
	GetIndependentQuiz(ctx context.Context, visibility *bool) ([]Quiz, error)
	GetCourseQuiz(ctx context.Context, visibility *bool) ([]Quiz, error)
	GetQuizById(ctx context.Context, quizId int64, visibility *bool) (Quiz, error)
	CreateQuiz(ctx context.Context, quiz *Quiz) (*Quiz, error)
	UpdateQuiz(ctx context.Context, quiz *Quiz) (*Quiz, error)
	DisableQuiz(ctx context.Context, id int64) error
	BatchCreateQuiz(ctx context.Context, quizzes []Quiz) error
	BatchUpdateQuiz(ctx context.Context, quizzes []Quiz) error
	GetCourseNameByQuizID(ctx context.Context, quizID int64) (string, error)
}

func NewQuizRepo(db *gorm.DB) QuizRepo {
	return &quizRepo{
		db: db,
	}
}

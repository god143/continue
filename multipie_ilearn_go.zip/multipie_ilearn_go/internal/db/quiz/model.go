package quiz

import (
	"multipie_ilearn_go/internal/constants"
	"time"
)

type Quiz struct {
	ID              *int64                       `json:"id"`
	Name            *string                      `json:"name"`
	CourseID        *int64                       `json:"course_id"`
	PassPercentage  *int64                       `json:"-"`
	NumQuestions    *int64                       `json:"-"`
	CertificateID   *int64                       `json:"certificate_id"`
	Visible         *bool                        `json:"visible"`
	Duration        *int64                       `json:"duration"`
	DifficultyLevel *constants.QuizDiffcultyEnum `json:"difficulty_level"`
	CreatedAt       *time.Time                   `json:"-"`
	UpdatedAt       *time.Time                   `json:"-"`
}

package login

import (
	"encoding/json"
	"time"
)

type CreateOtpRequest struct {
	UserId     int        `json:"user_id"`
	Mobile     string     `json:"mobile"`
	OtpHash    string     `json:"otp_hash"`
	ResendOtp  int        `json:"resend_otp"`
	Attempts   int        `json:"attempts"`
	ExpiresAt  time.Time  `json:"expires_at"`
	VerifiedAt *time.Time `json:"verified_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

type Otp struct {
	UserId     int        `json:"user_id"`
	Mobile     string     `json:"mobile"`
	OtpHash    string     `json:"otp_hash"`
	ResendOtp  int        `json:"resend_otp"`
	Attempts   int        `json:"attempts"`
	ExpiresAt  time.Time  `json:"expires_at"`
	VerifiedAt *time.Time `json:"verified_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

type GetOtpRequest struct {
	Id         int        `json:"id"`
	UserId     int        `json:"user_id"`
	Mobile     string     `json:"mobile"`
	OtpHash    string     `json:"otp_hash"`
	ResendOtp  int        `json:"resend_otp"`
	Attempts   int        `json:"attempts"`
	ExpiresAt  time.Time  `json:"expires_at"`
	VerifiedAt *time.Time `json:"verified_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

type CreateTokenRequest struct {
	UserId           int        `json:"user_id"`
	Token            string     `json:"token"`
	RefreshToken     string     `json:"refresh_token"`
	ExpiresAt        time.Time  `json:"expires_at"`
	RefreshExpiresAt time.Time  `json:"refresh_expires_at"`
	RevokedAt        *time.Time `json:"revoked_at"`
	CreatedAt        time.Time  `json:"created_at"`
	UpdatedAt        time.Time  `json:"updated_at"`
}

type UpdateTokenRequest struct {
	Id               int        `json:"id"`
	UserId           int        `json:"user_id"`
	Token            string     `json:"token"`
	RefreshToken     string     `json:"refresh_token"`
	ExpiresAt        time.Time  `json:"expires_at"`
	RefreshExpiresAt time.Time  `json:"refresh_expires_at"`
	RevokedAt        *time.Time `json:"revoked_at"`
	CreatedAt        time.Time  `json:"created_at"`
	UpdatedAt        time.Time  `json:"updated_at"`
}

type Token struct {
	Id               int        `json:"id"`
	UserId           int        `json:"user_id"`
	Token            string     `json:"token"`
	RefreshToken     string     `json:"refresh_token"`
	ExpiresAt        time.Time  `json:"expires_at"`
	RefreshExpiresAt time.Time  `json:"refresh_expires_at"`
	RevokedAt        *time.Time `json:"revoked_at"`
	CreatedAt        time.Time  `json:"created_at"`
	UpdatedAt        time.Time  `json:"updated_at"`
}

type CreateEmailOtpRequest struct {
	UserId     int        `json:"user_id"`
	Email      string     `json:"email"`
	OtpHash    string     `json:"otp_hash"`
	ResendOtp  int        `json:"resend_otp"`
	Attempts   int        `json:"attempts"`
	ExpiresAt  time.Time  `json:"expires_at"`
	VerifiedAt *time.Time `json:"verified_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

type EmailOtp struct {
	UserId     int        `json:"user_id"`
	Email      string     `json:"email"`
	OtpHash    string     `json:"otp_hash"`
	ResendOtp  int        `json:"resend_otp"`
	Attempts   int        `json:"attempts"`
	ExpiresAt  time.Time  `json:"expires_at"`
	VerifiedAt *time.Time `json:"verified_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

type GetEmailOtpRequest struct {
	Id         int        `json:"id"`
	UserId     int        `json:"user_id"`
	Email      string     `json:"email"`
	OtpHash    string     `json:"otp_hash"`
	ResendOtp  int        `json:"resend_otp"`
	Attempts   int        `json:"attempts"`
	ExpiresAt  time.Time  `json:"expires_at"`
	VerifiedAt *time.Time `json:"verified_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

func (t Token) MarshalJSON() ([]byte, error) {
	type alias Token

	return json.Marshal(&struct {
		alias
		ExpiresAt string `json:"expires_at"`
	}{
		alias:     alias(t),
		ExpiresAt: t.ExpiresAt.UTC().Format("2006-01-02T15:04:05.999Z"),
	})
}

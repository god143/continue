package login

import (
	"context"
	"errors"
	"fmt"
	"time"

	"gorm.io/gorm"
)

func (l *loginRepo) CreateOrUpdateOtp(ctx context.Context, otp CreateOtpRequest) (*Otp, error) {
	var result Otp
	query := l.db.Table("otp_verifications").Where("mobile = ?", otp.Mobile)
	err := query.First(&result).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		tx := l.db.Table("otp_verifications").Begin()
		if tx.Error != nil {
			return nil, tx.Error
		}

		if err := tx.Create(&otp).Error; err != nil {
			tx.Rollback()
			return nil, err
		}
		if err := tx.Commit().Error; err != nil {
			return nil, err
		}
		return &result, nil
	}
	if err != nil {
		return nil, err
	}

	tx := l.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Table("otp_verifications").Where("mobile = ?", otp.Mobile).Updates(map[string]interface{}{
		"user_id":     otp.UserId,
		"mobile":      otp.Mobile,
		"otp_hash":    otp.OtpHash,
		"resend_otp":  otp.ResendOtp,
		"attempts":    otp.Attempts,
		"expires_at":  otp.ExpiresAt,
		"verified_at": nil,
	}).Error; err != nil {

		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}
	return &result, nil
}

func (l *loginRepo) CreateOrUpdateEmailOtp(ctx context.Context, otp CreateEmailOtpRequest) (*EmailOtp, error) {
	var result EmailOtp
	query := l.db.Table("email_otp_verifications").Where("email = ?", otp.Email).Where("user_id = ?", otp.UserId)
	err := query.First(&result).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		tx := l.db.Table("email_otp_verifications").Begin()
		if tx.Error != nil {
			return nil, tx.Error
		}

		if err := tx.Create(&otp).Error; err != nil {
			tx.Rollback()
			return nil, err
		}
		if err := tx.Commit().Error; err != nil {
			return nil, err
		}
		return &result, nil
	}
	if err != nil {
		return nil, err
	}

	tx := l.db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	if err := tx.Table("email_otp_verifications").Where("email = ?", otp.Email).Where("user_id = ?", otp.UserId).Updates(map[string]interface{}{
		"user_id":     otp.UserId,
		"email":       otp.Email,
		"otp_hash":    otp.OtpHash,
		"resend_otp":  otp.ResendOtp,
		"attempts":    otp.Attempts,
		"expires_at":  otp.ExpiresAt,
		"verified_at": nil,
	}).Error; err != nil {

		tx.Rollback()
		return nil, err
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}
	return &result, nil
}

func (l *loginRepo) GetOtp(ctx context.Context, otp CreateOtpRequest) (*Otp, error) {
	var result Otp
	query := l.db.Table("otp_verifications").Where("mobile = ?", otp.Mobile)
	err := query.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (l *loginRepo) GetEmailOtp(ctx context.Context, otp CreateEmailOtpRequest) (*EmailOtp, error) {
	var result EmailOtp
	query := l.db.Table("email_otp_verifications").Where("email = ?", otp.Email).Where("user_id = ?", otp.UserId)
	err := query.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (l *loginRepo) VerifyOtp(ctx context.Context, mobile string, hashOtp string, attempts int) (*GetOtpRequest, error) {
	var result GetOtpRequest
	query := l.db.WithContext(ctx).Table("otp_verifications").
		Where("mobile = ?", mobile).
		Where("otp_hash = ?", hashOtp).
		Where("verified_at IS NULL").
		Where("expires_at > ?", time.Now())

	err := query.First(&result).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		if err := l.db.Table("otp_verifications").Where("mobile = ?", mobile).Updates(map[string]interface{}{
			"attempts": attempts + 1,
		}).Error; err != nil {
			return nil, err
		}
	}

	if err != nil {
		return nil, err
	}

	if err := l.db.Table("otp_verifications").Where("mobile = ?", result.Mobile).Updates(map[string]interface{}{
		"verified_at": time.Now(),
	}).Error; err != nil {
		return nil, err
	}

	return &result, nil
}

func (l *loginRepo) VerifyEmailOtp(ctx context.Context, email string, hashOtp string, attempts int, userId int64) (*GetEmailOtpRequest, error) {
	var result GetEmailOtpRequest

	query := l.db.WithContext(ctx).Table("email_otp_verifications").
		Where("email = ?", email).
		Where("user_id = ?", userId).
		Where("otp_hash = ?", hashOtp).
		Where("verified_at IS NULL")
		// Where("expires_at > ?", time.Now())

	err := query.First(&result).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		if err := l.db.Table("email_otp_verifications").Where("email = ?", email).Where("user_id = ?", userId).Updates(map[string]interface{}{
			"attempts": attempts + 1,
		}).Error; err != nil {
			fmt.Println("error--->", err)
			return nil, err
		}
	}

	if err != nil {
		fmt.Println("------->", err)
		return nil, err
	}

	if err := l.db.Table("email_otp_verifications").Where("email = ?", result.Email).Where("user_id = ?", result.UserId).Updates(map[string]interface{}{
		"verified_at": time.Now(),
	}).Error; err != nil {
		fmt.Println("error 2--->", err)
		return nil, err
	}

	return &result, nil
}

// func (l *loginRepo) FindOrCreateToken(ctx context.Context, token CreateTokenRequest, userid int) (*Token, error) {
// 	var result Token
// 	query := l.db.Table("auth_tokens").Where("user_id = ?", userid)
// 	err := query.First(&result).Error
// 	if errors.Is(err, gorm.ErrRecordNotFound) {
// 		tx := l.db.Table("auth_tokens").Begin()
// 		if tx.Error != nil {
// 			return nil, tx.Error
// 		}

// 		if err := tx.Create(&token).Error; err != nil {
// 			tx.Rollback()
// 			return nil, err
// 		}
// 		if err := tx.Commit().Error; err != nil {
// 			return nil, err
// 		}
// 		return &result, nil
// 	}
// 	if err != nil {
// 		return nil, err
// 	}
// 	return nil, nil
// }

func (l *loginRepo) FindOrCreateToken(ctx context.Context, tokenReq CreateTokenRequest, userid int) (*Token, error) {
	var result Token

	// 1. Try to find the existing token
	query := l.db.Table("auth_tokens").WithContext(ctx).Where("user_id = ?", userid).Where("expires_at > ?", time.Now()).Where("revoked_at IS NULL")
	err := query.First(&result).Error

	// 2. If found, return it directly
	if err == nil {
		return &result, nil
	}

	// 3. If it's a genuine database error, return it
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	// 4. Record not found: Initialize the token model using the request data
	// Adjust the field assignments based on your actual struct definitions
	newToken := Token{
		UserId:           userid,
		Token:            tokenReq.Token,
		RefreshToken:     tokenReq.RefreshToken,
		ExpiresAt:        tokenReq.ExpiresAt,
		RefreshExpiresAt: tokenReq.RefreshExpiresAt,
	}

	// 5. Run the transaction to insert and automatically fetch back database fields
	err = l.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Table("auth_tokens").Create(&newToken).Error; err != nil {
			return err
		}
		return nil
	})

	if err != nil {
		return nil, err
	}

	// newToken now contains database-generated values like ID, CreatedAt, etc.
	return &newToken, nil
}

func (l *loginRepo) UpdateToken(ctx context.Context, request UpdateTokenRequest, userid int, refreshToken string) (*Token, error) {
	if err := l.db.Table("auth_tokens").Where("user_id = ?", userid).Where("refresh_token = ?", refreshToken).Updates(map[string]interface{}{
		"token":              request.Token,
		"refresh_token":      request.RefreshToken,
		"expires_at":         request.ExpiresAt,
		"refresh_expires_at": request.RefreshExpiresAt,
	}).Error; err != nil {
		return nil, err
	}

	newToken := Token{
		UserId:           userid,
		Token:            request.Token,
		RefreshToken:     request.RefreshToken,
		ExpiresAt:        request.ExpiresAt,
		RefreshExpiresAt: request.RefreshExpiresAt,
	}

	return &newToken, nil
}

func (l *loginRepo) Logout(ctx context.Context, token string) error {
	if err := l.db.Table("auth_tokens").Where("token = ?", token).Updates(map[string]interface{}{
		"revoked_at": time.Now(),
	}).Error; err != nil {
		return err
	}
	return nil
}

func (l *loginRepo) GetToken(ctx context.Context, token string) (*Token, error) {
	var result Token
	query := l.db.Table("auth_tokens").WithContext(ctx).Where("token = ?", token)
	err := query.First(&result).Error

	if err != nil {
		return nil, err
	}

	return &result, nil
}

func (l *loginRepo) GetRefreshToken(ctx context.Context, token string) (*Token, error) {
	var result Token
	query := l.db.Table("auth_tokens").WithContext(ctx).Where("refresh_token = ?", token)
	err := query.First(&result).Error

	if err != nil {
		return nil, err
	}

	return &result, nil
}

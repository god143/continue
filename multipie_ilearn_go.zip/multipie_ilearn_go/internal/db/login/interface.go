package login

import (
	"context"

	"gorm.io/gorm"
)

type loginRepo struct {
	db *gorm.DB
}

type LoginRepo interface {
	CreateOrUpdateOtp(ctx context.Context, otp CreateOtpRequest) (*Otp, error)
	GetOtp(ctx context.Context, otp CreateOtpRequest) (*Otp, error)
	GetEmailOtp(ctx context.Context, otp CreateEmailOtpRequest) (*EmailOtp, error)
	VerifyOtp(ctx context.Context, mobile string, hashOtp string, attempts int) (*GetOtpRequest, error)
	VerifyEmailOtp(ctx context.Context, email string, hashOtp string, attempts int, userId int64) (*GetEmailOtpRequest, error)
	FindOrCreateToken(ctx context.Context, token CreateTokenRequest, userid int) (*Token, error)
	CreateOrUpdateEmailOtp(ctx context.Context, otp CreateEmailOtpRequest) (*EmailOtp, error)
	UpdateToken(ctx context.Context, token UpdateTokenRequest, userid int, refreshToken string) (*Token, error)
	GetToken(ctx context.Context, token string) (*Token, error)
	GetRefreshToken(ctx context.Context, token string) (*Token, error)
	Logout(ctx context.Context, token string) error
}

func NewLoginRepo(db *gorm.DB) LoginRepo {
	return &loginRepo{
		db: db,
	}
}

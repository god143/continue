package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/constants"
	"multipie_ilearn_go/internal/controller"
	"multipie_ilearn_go/internal/db"
	"multipie_ilearn_go/internal/logger"
	"multipie_ilearn_go/internal/router"
	"multipie_ilearn_go/internal/server"
	"multipie_ilearn_go/internal/service/queueService"
	"multipie_ilearn_go/internal/utils"

	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"go.uber.org/zap"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	gormLogger "gorm.io/gorm/logger"
)

func Run(env string) {
	var wg sync.WaitGroup

	// Create a clean background context for the initialization/boot phase
	baseCtx := context.Background()

	//Load Config
	cfg := config.AppSecrets

	//Set up Logger
	if err := logger.NewLogger(env, cfg.Log.Level, cfg.Log.Location); err != nil {
		log.Println("unable to initialize logger, error: ", err)
		return
	}

	//sync logger before exiting
	defer logger.Flush()

	//Database connection string - added 5s network connection timeout
	connection_string := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local&timeout=5s",
		cfg.MultipieILearnDb.Username, cfg.MultipieILearnDb.Password, cfg.MultipieILearnDb.Host,
		cfg.MultipieILearnDb.Port, cfg.MultipieILearnDb.Database)

	//TODO: Differentiate based on env
	newLogger := gormLogger.New(
		log.New(os.Stdout, "\r\n", log.LstdFlags),
		gormLogger.Config{
			SlowThreshold:        time.Second,     // Slow SQL threshold
			Colorful:             true,            // Enable color
			ParameterizedQueries: false,           // Don't log SQL parameter placeholders (for security reasons)
			LogLevel:             gormLogger.Info, // Log level
		},
	)

	multipieIlearnDBClient, err := gorm.Open(mysql.Open(connection_string), &gorm.Config{Logger: newLogger})
	if err != nil {
		logger.Error(baseCtx, "unable to make connection with mysql database", zap.Error(err))
		return
	}

	//Database layer
	dbLayer := db.NewDbLayer(multipieIlearnDBClient)

	//Redis connection - passing clean, unexpired baseCtx
	redisConn, err := utils.NewRedisConn(baseCtx, cfg.Redis.Host, cfg.Redis.Port)
	if err != nil {
		logger.Error(baseCtx, "unable to make connection with redis", zap.Error(err))
		return
	}

	//load controller layer
	controllerLayer := controller.NewControllerLayer(dbLayer, cfg)
	handler := router.Init(controllerLayer, dbLayer, cfg)
	server := server.NewServer(cfg, handler)

	//Set Queue service
	//Use a separate context for the queue worker, ensure it’s canceled when shutting down
	statsQueueService := queueService.NewQueueService(redisConn.GetClient(), dbLayer)
	queueCtx, queueCancelFunc := context.WithCancel(context.Background())
	if err := setUpStatsQueueService(queueCtx, statsQueueService, &wg); err != nil {
		queueCancelFunc()
		return
	}

	//Start Server
	go func() {
		if err := server.HttpServer.Run(); !errors.Is(err, http.ErrServerClosed) {
			logger.Error(baseCtx, "error occurred while running http server", zap.Error(err))
		}
	}()

	logger.Info(baseCtx, "Server started successfully")

	//Signal channel to listen for shutdown signal
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGTERM, syscall.SIGINT)

	<-quit

	// --- Graceful Shutdown Phase Commences Here ---
	const timeout = 5 * time.Second // timeout before shutting down the server
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), timeout)
	defer shutdownCancel()

	// Clean up the queue worker gracefully
	queueCancelFunc()

	wg.Wait() //wait for queue worker to stop

	if err := server.HttpServer.Stop(shutdownCtx); err != nil {
		logger.Error(shutdownCtx, "failed to stop server.", zap.Error(err))
	}

	//Shutdown database connection
	logger.Info(shutdownCtx, "shutting down database")
	dbConn, _ := multipieIlearnDBClient.DB()
	if err := dbConn.Close(); err != nil {
		logger.Error(shutdownCtx, "failed to stop the database connection")
	}

	//Shutdown Redis connection if needed.
	logger.Info(shutdownCtx, "shutting down redis connection")
	if err := redisConn.Close(shutdownCtx); err != nil {
		logger.Error(shutdownCtx, "failed to stop the redis connection")
	}
}

func setUpStatsQueueService(ctx context.Context, statsQueue queueService.QueueService, wg *sync.WaitGroup) error {
	cfg := config.AppSecrets

	if err := statsQueue.CreateConsumerGroup(ctx, constants.STATS_QUEUE, constants.STATS_GROUP); err != nil {
		logger.Error(ctx, "error in setting up consumer group", zap.Error(err))
		return err
	}
	for i := 0; i < cfg.QueueWorker.StatsQueueWorker; i++ {
		wg.Add(1)
		go statsQueue.StartWorker(ctx, constants.STATS_QUEUE, constants.STATS_GROUP, wg)
	}
	return nil
}

package httpServer

import (
	"context"
	"multipie_ilearn_go/internal/config"
	"net/http"
	"time"

	"golang.org/x/net/http2"
	"golang.org/x/net/http2/h2c"
)

type HttpServer struct {
	httpServer *http.Server
}

func NewHttpServer(cfg *config.HTTPConfig, handler http.Handler) *HttpServer {

	// Configure HTTP/2 options (e.g., max concurrent streams matching ALB limits)
	h2s := &http2.Server{
		MaxConcurrentStreams: 128, // ALB limit per HTTP/2 connection
	}

	// Wrap the standard handler (Gin) with h2c handler for cleartext HTTP/2 support
	h2cHandler := h2c.NewHandler(handler, h2s)

	return &HttpServer{
		httpServer: &http.Server{
			Addr:        cfg.Host + ":" + cfg.Port,
			Handler:     h2cHandler,
			ReadTimeout: cfg.ReadTimeout * time.Second,
			// WriteTimeout:   cfg.WriteTimeout * time.Second,
			MaxHeaderBytes: cfg.MaxHeaderMegabytes * 1024 * 1024, //convert MB into bytes
		},
	}

}

func (h *HttpServer) Run() error {
	return h.httpServer.ListenAndServe()
}

func (h *HttpServer) Stop(ctx context.Context) error {
	return h.httpServer.Shutdown(ctx)
}

package server

import (
	"multipie_ilearn_go/internal/config"
	"multipie_ilearn_go/internal/server/httpServer"
	"net/http"
)

type Server struct {
	HttpServer *httpServer.HttpServer
}

func NewServer(cfg *config.SecretConfig, handler http.Handler) *Server {
	return &Server{
		HttpServer: httpServer.NewHttpServer(&cfg.HTTP, handler),
	}
}

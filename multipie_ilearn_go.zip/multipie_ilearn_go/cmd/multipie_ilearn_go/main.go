package main

import (
	"log"
	"multipie_ilearn_go/internal/app"
	"multipie_ilearn_go/internal/config"
	"time"
)

func main() {

	// Load the .env file
	config.LoadEnv()

	envCfg := config.AppConfigs

	config.LoadSecrets()
	log.Printf("Secrets loaded for %s environment", envCfg.AppEnv)

	// Set the timezone to Asia/Kolkata
	loc, err := time.LoadLocation(envCfg.Timezone)
	if err != nil {
		log.Fatalf("Error loading time zone: %v", err)
	}

	// Set the global time zone
	time.Local = loc

	app.Run(envCfg.AppEnv)
}

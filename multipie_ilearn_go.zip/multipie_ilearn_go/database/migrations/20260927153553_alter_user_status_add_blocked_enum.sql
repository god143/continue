-- +goose Up
-- +goose StatementBegin
ALTER TABLE users 
MODIFY COLUMN status 
ENUM('active', 'inactive', 'blocked') 
NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE users 
MODIFY COLUMN status 
ENUM('active', 'inactive') 
NOT NULL;
-- +goose StatementEnd
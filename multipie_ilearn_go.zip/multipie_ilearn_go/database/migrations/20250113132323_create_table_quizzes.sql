-- +goose Up
-- +goose StatementBegin
CREATE TABLE `quizzes` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,            
    `course_id` INT DEFAULT NULL,            
    `pass_percentage` INT DEFAULT 70,        
    `num_questions` INT DEFAULT 0,           
    `certificate_id` INT DEFAULT NULL,
    `visible` BOOLEAN DEFAULT TRUE,       
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_course_id` (`course_id`),
    CONSTRAINT `fk_course_quiz` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE `quizzes`;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE bookmarks ADD CONSTRAINT unique_bookmark UNIQUE(user_id, model_id, model_type);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE bookmarks DROP CONSTRAINT unique_bookmark;
-- +goose StatementEnd

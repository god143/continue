-- +goose Up
-- +goose StatementBegin
ALTER TABLE comments 
MODIFY model_type ENUM('resource', 'infographics', 'course_module', 'secondary_resource') NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE comments 
MODIFY model_type ENUM('resource', 'infographics', 'course_module') NOT NULL;
-- +goose StatementEnd
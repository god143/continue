-- +goose Up
-- +goose StatementBegin
CREATE TABLE `otp_verifications` (
    `id` INT AUTO_INCREMENT PRIMARY KEY, 
    `user_id` INT NOT NULL,
    `mobile` VARCHAR(20) UNIQUE NULL,
    `otp_hash` VARCHAR(255) NULL,
    `attempts` INT NOT NULL DEFAULT 0,
    `expires_at` TIMESTAMP NOT NULL,
    `verified_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (`user_id`, `mobile`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE otp_verifications
-- +goose StatementEnd
-- +goose Up
-- +goose StatementBegin
CREATE TABLE users (

    `id` INT AUTO_INCREMENT PRIMARY KEY,  
    `username` VARCHAR(100) NOT NULL, 
    `first_name` VARCHAR(255) NOT NULL, 
    `last_name` VARCHAR(255) NOT NULL, 
    `mobile` VARCHAR(16),
    `email` VARCHAR(255), 
    `role` ENUM('admin','user') DEFAULT 'user' NOT NULL,
    `status` ENUM('active', 'inactive') DEFAULT 'active' NOT NULL,
    `uid` INT NOT NULL UNIQUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
    INDEX (`username`), 
    INDEX (`email`),
    INDEX (`mobile`)
);
 
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE users;
-- +goose StatementEnd

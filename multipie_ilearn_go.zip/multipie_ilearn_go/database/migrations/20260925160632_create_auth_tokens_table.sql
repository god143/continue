-- +goose Up
-- +goose StatementBegin
CREATE TABLE `auth_tokens` (
    `id` INT AUTO_INCREMENT PRIMARY KEY, 
    `user_id` INT NOT NULL,
    `token` VARCHAR(225) UNIQUE NULL,
    `refresh_token` VARCHAR(255) NULL,
    `expires_at` TIMESTAMP NULL,
    `refresh_expires_at` TIMESTAMP NULL,
    `revoked_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (`user_id`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE auth_tokens
-- +goose StatementEnd
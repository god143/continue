-- +goose Up
-- +goose StatementBegin
CREATE TABLE likes (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `model_id` INT NOT NULL,
    `model_type` ENUM('resource', 'infographic', 'course_module','course') NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES users(`uid`) ON DELETE CASCADE,
    INDEX (`user_id`),
    INDEX (`model_id`),
    INDEX (`model_type`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE likes;
-- +goose StatementEnd
-- +goose Up
-- +goose StatementBegin
ALTER TABLE tag_mappings 
ADD COLUMN sub_type ENUM('primary', 'expert', 'learn') NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE tag_mappings
DROP COLUMN sub_type;
-- +goose StatementEnd



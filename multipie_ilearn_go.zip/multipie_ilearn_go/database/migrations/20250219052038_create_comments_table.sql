-- +goose Up
-- +goose StatementBegin
CREATE TABLE comments (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,  
    `content` VARCHAR(255),
    `parent_id` INT,
    `model_type` ENUM('resource', 'infographics', 'course_module') NOT NULL,
    `model_id` INT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `visible` BOOLEAN DEFAULT FALSE,
    `likes_count` INT DEFAULT 0, 
    FOREIGN KEY (user_id) REFERENCES users(uid) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES comments(id),
    INDEX (`user_id`),
    INDEX (`model_id`),
    INDEX (`model_type`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE comments;
-- +goose StatementEnd
-- +goose Up
-- +goose StatementBegin
ALTER TABLE resources ADD COLUMN likes INT DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE resources DROP COLUMN likes;
-- +goose StatementEnd

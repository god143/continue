-- +goose Up
-- +goose StatementBegin
CREATE TABLE courses (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(255) NOT NULL,  
    `shortname` VARCHAR(100) NOT NULL UNIQUE,
    `category_id` INT NOT NULL,
    `difficulty_level` ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    `summary` TEXT,
    `start_date` TIMESTAMP,
    `end_date` TIMESTAMP,
    `format` ENUM('video', 'article') DEFAULT 'article',
    `visible` BOOLEAN DEFAULT TRUE,
    `module_count` INT,
    `banner` VARCHAR(255),
    `duration` INT, -- in minutes
    `views` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX(`category_id`, `id`),
    FOREIGN KEY (`category_id`) REFERENCES categories(id) ON DELETE CASCADE
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE courses;
-- +goose StatementEnd

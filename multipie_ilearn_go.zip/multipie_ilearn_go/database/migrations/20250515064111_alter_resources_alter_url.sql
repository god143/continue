-- +goose Up
-- +goose StatementBegin
ALTER TABLE resources
MODIFY COLUMN url VARCHAR(255) NULL;
-- +goose StatementEnd
 
-- +goose Down

-- First: replace NULLs with empty strings
-- +goose StatementBegin
UPDATE resources SET url = '' WHERE url IS NULL;
-- +goose StatementEnd
-- Then: alter column to NOT NULL

-- +goose StatementBegin
ALTER TABLE resources
MODIFY COLUMN url VARCHAR(255) NOT NULL;
-- +goose StatementEnd
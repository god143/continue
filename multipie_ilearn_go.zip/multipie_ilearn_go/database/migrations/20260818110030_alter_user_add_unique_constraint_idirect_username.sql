-- +goose Up
-- +goose StatementBegin
ALTER TABLE users
ADD CONSTRAINT uq_idirect_username UNIQUE(idirect_username);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE users 
DROP INDEX uq_idirect_username;
-- +goose StatementEnd
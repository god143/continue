-- +goose Up
-- +goose StatementBegin
CREATE TABLE infographic_images (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `infographic_id` INT NOT NULL,
    `image_url` VARCHAR(255),
    `image_order` INT DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`infographic_id`) REFERENCES infographics(`id`) ON DELETE CASCADE,
    INDEX idx_infographic_id (`infographic_id`),
    INDEX idx_image_order (`image_order`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE infographic_images;
-- +goose StatementEnd

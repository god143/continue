-- +goose Up
-- +goose StatementBegin
ALTER TABLE infographic_images
ADD CONSTRAINT unique_infographic_image_order UNIQUE(infographic_id, image_order);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE infographic_images 
DROP CONSTRAINT unique_infographic_image_order ;
-- +goose StatementEnd

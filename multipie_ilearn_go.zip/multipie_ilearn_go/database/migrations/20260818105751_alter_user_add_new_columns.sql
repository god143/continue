-- +goose Up
-- +goose StatementBegin
ALTER TABLE users 
    ADD COLUMN first_access TIMESTAMP,
    ADD COLUMN last_access TIMESTAMP,
    ADD COLUMN via_login VARCHAR(255),
    ADD COLUMN sign_in_count INT,
    ADD COLUMN idirect_username VARCHAR(255);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE users 
    DROP COLUMN first_access,
    DROP COLUMN last_access,
    DROP COLUMN via_login,
    DROP COLUMN sign_in_count,
    DROP COLUMN idirect_username;

-- +goose StatementEnd
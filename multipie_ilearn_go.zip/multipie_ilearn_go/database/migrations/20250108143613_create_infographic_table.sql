-- +goose Up
-- +goose StatementBegin

-- Creating the `infographics` table
CREATE TABLE infographics (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `category_id` INT NOT NULL,
    `description` TEXT,
    `likes` INT DEFAULT 0,
    `views` INT DEFAULT 0,
    `visible` BOOLEAN DEFAULT TRUE,
    `upload_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`category_id`) REFERENCES categories(`id`) ON DELETE CASCADE,
    -- Indexes
    INDEX idx_likes (`likes`),
    INDEX idx_views (`views`),
    INDEX idx_upload_time (`upload_time`),
    INDEX idx_category_id_time (`category_id`)
);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE infographics;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE quizzes ADD COLUMN `difficulty_level` ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE quizzes DROP COLUMN `difficulty_level`;
-- +goose StatementEnd

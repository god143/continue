-- +goose Up
-- +goose StatementBegin
CREATE TABLE glossaries (
      `id` int NOT NULL AUTO_INCREMENT,
      `key` varchar(255) NOT NULL,
      `value` varchar(255) NOT NULL,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
      PRIMARY KEY (`id`),
      UNIQUE KEY `glossaries_unique_key` (`key`),
     FULLTEXT (`key`, `value`)
    )
-- +goose StatementEnd
 
-- +goose Down
-- +goose StatementBegin
DROP TABLE glossaries;
-- +goose StatementEnd
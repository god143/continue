-- +goose Up
-- +goose StatementBegin
CREATE TABLE course_modules (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `course_id` INT,
    `type` ENUM('chapter', 'quiz', 'certificate') NOT NULL,
    `name` VARCHAR(255) NOT NULL,          -- Module name (chapter title, quiz name, certificate title)
    `description` TEXT,                    
    `duration` INT DEFAULT NULL,           -- Duration (in seconds) for chapters
    `content_type` ENUM('video', 'article') DEFAULT NULL,  -- For chapters only
    `pass_percentage` INT DEFAULT NULL,   -- Pass percentage for quizzes
    `likes` INT DEFAULT 0,                 -- Number of likes (for chapters)
    `view` INT DEFAULT 0,
    `module_order` INT NOT NULL,           -- Order of module in the course
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`course_id`) REFERENCES courses(`id`) ON DELETE CASCADE,
    -- Indexes
    INDEX idx_course_id (`course_id`),
    INDEX idx_module_order (`module_order`),
    INDEX idx_course_id_module_order (`course_id`, `module_order`)
);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE course_modules;
-- +goose StatementEnd

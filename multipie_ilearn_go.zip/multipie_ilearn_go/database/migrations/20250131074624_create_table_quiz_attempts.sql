-- +goose Up
-- +goose StatementBegin
CREATE TABLE quiz_attempts (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
   `user_id`INT NOT NULL,
    `quiz_id` INT NOT NULL,
    `attempt_number` INT NOT NULL,
    `score` FLOAT,
    `last_attempt_at` TIMESTAMP,
    `status` ENUM('pass', 'fail'),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(uid) ON DELETE CASCADE,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);
-- +goose StatementEnd
 
-- +goose Down
-- +goose StatementBegin
DROP TABLE quiz_attempts;
-- +goose StatementEnd
-- +goose Up
-- +goose StatementBegin
CREATE TABLE related_resources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    resource_id INT NOT NULL,
    related_resource_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_resource_id FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE,
    CONSTRAINT fk_related_resource_id FOREIGN KEY (related_resource_id) REFERENCES resources(id) ON DELETE CASCADE,

    UNIQUE (resource_id, related_resource_id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS related_resources;
-- +goose StatementEnd
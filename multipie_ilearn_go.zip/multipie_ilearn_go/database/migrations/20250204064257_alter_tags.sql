-- +goose Up
-- +goose StatementBegin
CREATE UNIQUE INDEX idx_unique_key ON tags(`key`);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP INDEX idx_unique_key ON tags;
-- +goose StatementEnd

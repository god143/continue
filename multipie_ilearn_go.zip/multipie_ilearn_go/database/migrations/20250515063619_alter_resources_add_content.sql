-- +goose Up
-- +goose StatementBegin
ALTER TABLE resources 
ADD COLUMN content LONGTEXT;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE resources
DROP COLUMN content;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE resources 
ADD COLUMN sub_type ENUM('primary', 'expert', 'learn') NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE resources
DROP COLUMN sub_type;
-- +goose StatementEnd



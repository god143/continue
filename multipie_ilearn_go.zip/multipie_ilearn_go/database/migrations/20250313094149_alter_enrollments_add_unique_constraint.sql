-- +goose Up
-- +goose StatementBegin
ALTER TABLE enrollments ADD CONSTRAINT unique_user_course UNIQUE (user_id, course_id);
-- +goose StatementEnd
 
-- +goose Down
-- +goose StatementBegin
ALTER TABLE enrollments DROP CONSTRAINT unique_user_course;
-- +goose StatementEnd
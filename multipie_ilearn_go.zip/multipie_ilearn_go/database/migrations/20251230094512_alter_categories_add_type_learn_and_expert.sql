-- +goose Up
-- +goose StatementBegin
ALTER TABLE categories 
MODIFY type ENUM('courses','videos','podcasts','articles','infographics','learn','expert') NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE categories 
MODIFY type ENUM('courses','videos','podcasts','articles','infographics') NULL;
-- +goose StatementEnd
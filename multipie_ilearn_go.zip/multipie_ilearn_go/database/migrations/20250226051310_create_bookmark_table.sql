-- +goose Up
-- +goose StatementBegin
CREATE TABLE bookmarks (
    `id` INT AUTO_INCREMENT PRIMARY KEY,  
    `user_id` INT NOT NULL,
    `model_id`INT NOT NULL,
    `model_type`ENUM('course','course_module','video','podcast','article','infographic'),
    `name`varchar(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(`uid`) ON DELETE CASCADE,
    INDEX (`user_id`),
    INDEX (`model_id`)
);
 
-- +goose StatementEnd
 
-- +goose Down
-- +goose StatementBegin
DROP TABLE bookmarks;
-- +goose StatementEnd
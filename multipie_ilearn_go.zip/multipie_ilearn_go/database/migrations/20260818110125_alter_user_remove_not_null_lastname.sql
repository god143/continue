-- +goose Up
-- +goose StatementBegin
ALTER TABLE users
MODIFY COLUMN last_name VARCHAR(255) NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE users
MODIFY COLUMN last_name VARCHAR(255) NOT NULL;
-- +goose StatementEnd
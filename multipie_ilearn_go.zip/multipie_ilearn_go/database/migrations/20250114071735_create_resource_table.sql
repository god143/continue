-- +goose Up
-- +goose StatementBegin
CREATE TABLE resources (
    id INT AUTO_INCREMENT PRIMARY KEY,  
    url VARCHAR(255) NOT NULL,  -- URL is mandatory
    dark_mode_url VARCHAR(255) NULL,  -- Dark mode URL is optional
    type ENUM('video', 'article', 'podcast') NOT NULL,  -- Updated enum types
    name VARCHAR(255) NULL, 
    description TEXT,  -- Description column
    category_id INT,
    course_module_id INT,
    icon VARCHAR(255),
    views INT,
    is_short BOOLEAN, 
    visible BOOLEAN,
    metadata JSON,  -- Store details like length, format, etc (duration, upload_date).
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    FOREIGN KEY (course_module_id) REFERENCES course_modules(id) ON DELETE CASCADE
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS resources;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
CREATE TABLE active_storages (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `filekey` VARCHAR(255) NOT NULL UNIQUE,
    `filename` VARCHAR(255) NOT NULL,
    `content_type` VARCHAR(255) DEFAULT NULL,
    `metadata` JSON DEFAULT NULL,
    `byte_size` BIGINT NOT NULL,
    `checksum` VARCHAR(64) DEFAULT NULL,  -- Adjusted for SHA256 checksum (if needed)
    `service_name` VARCHAR(255) DEFAULT 'local',
    `model_type` VARCHAR(255) DEFAULT NULL,  -- Can store which model this file is attached to (e.g., 'User', 'Post')
    `model_id` BIGINT DEFAULT NULL,           -- The model's ID this file is associated with
    `attachment_for` VARCHAR(255) DEFAULT NULL,
    `is_primary` BOOLEAN DEFAULT FALSE,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (model_type, model_id),
    INDEX (`filekey`)
);


-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE active_storages;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE bookmarks 
ADD COLUMN sub_type ENUM('primary', 'expert', 'learn') NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE bookmarks
DROP COLUMN sub_type;
-- +goose StatementEnd



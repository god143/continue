-- +goose Up
-- +goose StatementBegin
ALTER TABLE likes 
MODIFY COLUMN model_type 
ENUM('resource', 'infographic', 'course_module', 'course', 'secondary_resource') 
NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE likes 
MODIFY COLUMN model_type 
ENUM('resource', 'infographic', 'course_module', 'course') 
NOT NULL;
-- +goose StatementEnd
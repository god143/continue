-- +goose Up
-- +goose StatementBegin
ALTER TABLE quizzes ADD COLUMN `duration` INT DEFAULT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE quizzes DROP COLUMN `duration`;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE bookmarks 
MODIFY model_type ENUM('course', 'course_module', 'video', 'podcast', 'article', 'infographic', 'expert', 'learn') NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE bookmarks 
MODIFY model_type ENUM('course', 'course_module', 'video', 'podcast', 'article', 'infographic') NOT NULL;
-- +goose StatementEnd
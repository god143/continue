-- +goose Up
-- +goose StatementBegin
ALTER TABLE users 
MODIFY COLUMN via_login ENUM('mobile', 'idirect') NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE users 
MODIFY COLUMN via_login VARCHAR(255) NULL;
-- +goose StatementEnd

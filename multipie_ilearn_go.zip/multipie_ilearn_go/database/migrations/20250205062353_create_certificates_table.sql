-- +goose Up
-- +goose StatementBegin
CREATE TABLE certificates (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `url` VARCHAR(255),
  `model_type` ENUM('course', 'quiz') NOT NULL,
  `model_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(`uid`) ON DELETE CASCADE
)

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE certificates;
-- +goose StatementEnd

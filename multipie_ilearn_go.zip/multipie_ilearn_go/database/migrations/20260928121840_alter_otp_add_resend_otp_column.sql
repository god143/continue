-- +goose Up
-- +goose StatementBegin
ALTER TABLE otp_verifications ADD COLUMN resend_otp INT DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE otp_verifications DROP COLUMN resend_otp;
-- +goose StatementEnd
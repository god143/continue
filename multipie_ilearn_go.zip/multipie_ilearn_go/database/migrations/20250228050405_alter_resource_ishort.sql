-- +goose Up
-- +goose StatementBegin
ALTER TABLE resources 
MODIFY COLUMN is_short BOOLEAN DEFAULT FALSE;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE resources 
MODIFY COLUMN is_short BOOLEAN;
-- +goose StatementEnd
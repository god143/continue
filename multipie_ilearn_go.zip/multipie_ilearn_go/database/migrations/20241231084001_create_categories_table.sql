-- +goose Up
-- +goose StatementBegin
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL, 
    description TEXT,
    parent INT DEFAULT NULL,
    type ENUM('courses', 'videos', 'podcasts', 'articles', 'infographics') DEFAULT NULL,
    icon TEXT, -- icon url
    banner TEXT, -- banner url
    visible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent) REFERENCES categories(id) ON DELETE CASCADE, 
    INDEX (parent),
    CONSTRAINT chk_parent_type_not_null
        CHECK (
            (parent IS NOT NULL AND type IS NOT NULL) OR (parent IS NULL AND type IS NULL)
        )
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE categories;
-- +goose StatementEnd

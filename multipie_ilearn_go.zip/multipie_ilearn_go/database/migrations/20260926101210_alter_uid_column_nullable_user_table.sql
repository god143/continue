-- +goose Up
-- +goose StatementBegin
ALTER TABLE users MODIFY uid INT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE users MODIFY uid INT NOT NULL;
-- +goose StatementEnd

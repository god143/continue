-- +goose Up
-- +goose StatementBegin
CREATE TABLE `questions` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `quiz_id` INT NOT NULL,                    
    `question_text` TEXT NOT NULL,             
    `type` ENUM('mcq', 'boolean', 'graph', 'image_based') NOT NULL,
    `image_url` VARCHAR(255) DEFAULT NULL,
    `answers` JSON NOT NULL,              
    `correct_answer` TEXT NOT NULL,       
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_quiz_id` (`quiz_id`),
    CONSTRAINT `fk_quiz_question` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE `questions`;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE quiz_attempts
  MODIFY COLUMN score FLOAT NOT NULL DEFAULT 0,
  MODIFY COLUMN status ENUM('pass', 'fail') NOT NULL,
  ADD COLUMN has_checked_answer BOOLEAN NOT NULL DEFAULT FALSE,
  ADD CONSTRAINT uq_user_quiz UNIQUE (user_id, quiz_id),
  ADD INDEX idx_quiz_id (quiz_id),
  ADD INDEX idx_user_id (user_id);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE quiz_attempts
  MODIFY COLUMN score FLOAT,
  MODIFY COLUMN status ENUM('pass', 'fail'),
  DROP COLUMN has_checked_answer,
  DROP INDEX uq_user_quiz,
  DROP INDEX idx_quiz_id,
  DROP INDEX idx_user_id;
-- +goose StatementEnd






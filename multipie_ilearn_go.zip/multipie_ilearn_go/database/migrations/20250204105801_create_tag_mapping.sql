-- +goose Up
-- +goose StatementBegin
CREATE TABLE tag_mappings (
    `id` INT AUTO_INCREMENT PRIMARY KEY,  
    `tag_id` INT NOT NULL,   
    `model_id` INT NOT NULL,
    `model_type` varchar(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     CONSTRAINT `fk__tag_id_tag_mapping` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE tag_mappings;
-- +goose StatementEnd

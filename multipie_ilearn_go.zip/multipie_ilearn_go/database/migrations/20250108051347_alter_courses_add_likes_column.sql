-- +goose Up
-- +goose StatementBegin
ALTER TABLE courses ADD COLUMN likes INT DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE courses DROP COLUMN likes;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
CREATE TABLE `user_activities` (
    `id` INT AUTO_INCREMENT PRIMARY KEY, 
    `user_id` INT NOT NULL, 
    `activity_status` ENUM('in-progress', 'completed') NOT NULL,
    `additional_data` JSON,
    `resource_id` INT ,
    `course_module_id` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
    FOREIGN KEY (`user_id`) REFERENCES `users`(`uid`), 
    FOREIGN KEY (`resource_id`) REFERENCES `resources`(`id`),
    FOREIGN KEY (`course_module_id`) REFERENCES `course_modules`(`id`),
    INDEX (`id`, `resource_id`, `course_module_id`,`user_id`)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE user_activities
-- +goose StatementEnd

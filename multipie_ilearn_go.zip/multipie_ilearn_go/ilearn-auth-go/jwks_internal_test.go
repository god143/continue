package ilearnauth

import (
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"testing"
)

func jwkOf(t *testing.T, bits int, e []byte) jwk {
	t.Helper()
	k, err := rsa.GenerateKey(rand.Reader, bits)
	if err != nil {
		t.Fatal(err)
	}
	return jwk{Kty: "RSA", Kid: "k", N: base64.RawURLEncoding.EncodeToString(k.N.Bytes()), E: base64.RawURLEncoding.EncodeToString(e)}
}

func TestWeakOrOddKeysAreNotAccepted(t *testing.T) {
	if _, err := jwkOf(t, 2048, []byte{1, 0, 1}).public(); err != nil {
		t.Fatalf("a normal key was refused: %v", err)
	}
	if _, err := jwkOf(t, 1024, []byte{1, 0, 1}).public(); err == nil {
		t.Error("a 1024-bit key was accepted")
	}
	if _, err := jwkOf(t, 2048, []byte{1}).public(); err == nil {
		t.Error("exponent 1 was accepted")
	}
	if _, err := (jwk{Kty: "RSA", Kid: "k", N: "!!", E: "AQAB"}).public(); err == nil {
		t.Error("garbage was accepted")
	}
}

// Package authtest is an in-process fake of the auth service, for the tests of a service that uses
// ilearnauth. It issues genuine RS256 tokens and serves the JWKS, so the real middleware verifies them; it
// revokes sessions; and it serves the internal API (users, deletion acknowledgements) with the same answers
// as the real one. Nothing here is for production.
//
//	fake := authtest.New(t)
//	auth, _ := ilearnauth.New(ilearnauth.Config{Issuer: fake.Issuer(), Audience: "ilearn", Revoker: fake.Revoker()})
//	req.Header.Set("Authorization", "Bearer "+fake.Token("user-1"))
package authtest

import (
	"bytes"
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"ilearn-auth-go/directory"
	"ilearn-auth-go/events"
)

// Server is the fake auth service.
type Server struct {
	srv *httptest.Server
	t   testing.TB

	mu      sync.Mutex
	keys    []keyPair // the first is current
	users   map[string]directory.User
	clients map[string]client
	svcToks map[string]string // token -> client id
	acks    []Ack
	revoked map[string]string
	// RevokeError, when set, makes the Revoker fail, to test the fail-closed path.
	revokeErr error
	jwksDown  bool
	Now       func() time.Time
}

type keyPair struct {
	kid string
	key *rsa.PrivateKey
}

type client struct {
	secret string
	scopes map[string]bool
}

// Ack is a deletion acknowledgement the fake received.
type Ack struct {
	RequestID, Service, Status string
	Counts                     map[string]int
}

// New starts the fake. It is closed when the test ends.
func New(t testing.TB) *Server {
	t.Helper()
	s := &Server{t: t, users: map[string]directory.User{}, clients: map[string]client{}, svcToks: map[string]string{}, revoked: map[string]string{}, Now: time.Now}
	s.RotateKey()
	mux := http.NewServeMux()
	mux.HandleFunc("GET /auth/v1/jwks.json", s.serveJWKS)
	mux.HandleFunc("POST /internal/v1/token", s.serveToken)
	mux.HandleFunc("GET /internal/v1/users/{sub}", s.serveUser)
	mux.HandleFunc("POST /internal/v1/users:batchGet", s.serveBatch)
	mux.HandleFunc("POST /internal/v1/deletion-acks", s.serveAck)
	s.srv = httptest.NewServer(mux)
	t.Cleanup(s.srv.Close)
	return s
}

// ServeInternal serves the internal API routes from this fake, so a test can wrap it (to count or fail
// requests) in its own handler.
func (s *Server) ServeInternal(w http.ResponseWriter, r *http.Request) {
	s.srv.Config.Handler.ServeHTTP(w, r)
}

// URL is the fake's address; it serves both the public keys and the internal API.
func (s *Server) URL() string { return s.srv.URL }

// Issuer is the value for ilearnauth.Config.Issuer.
func (s *Server) Issuer() string { return s.srv.URL + "/auth" }

// RotateKey makes a new signing key current and keeps the old ones in the JWKS.
func (s *Server) RotateKey() {
	k, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		s.t.Fatal(err)
	}
	id := make([]byte, 4)
	_, _ = rand.Read(id)
	s.mu.Lock()
	s.keys = append([]keyPair{{"k" + hex.EncodeToString(id), k}}, s.keys...)
	s.mu.Unlock()
}

// RetireOldKeys removes every key but the current one from the JWKS.
func (s *Server) RetireOldKeys() { s.mu.Lock(); s.keys = s.keys[:1]; s.mu.Unlock() }

// SetJWKSDown makes the public key endpoint fail, to test outages.
func (s *Server) SetJWKSDown(down bool) { s.mu.Lock(); s.jwksDown = down; s.mu.Unlock() }

// TokenOption adjusts a token.
type TokenOption func(*tokenSpec)

type tokenSpec struct {
	sid      string
	aud      []string
	iss      string
	ttl      time.Duration
	issuedAt time.Time
	scope    string
	amr      []string
	alg      string
	badSig   bool
	kid      string
}

func Session(id string) TokenOption         { return func(t *tokenSpec) { t.sid = id } }
func Audience(aud ...string) TokenOption    { return func(t *tokenSpec) { t.aud = aud } }
func Issuer(iss string) TokenOption         { return func(t *tokenSpec) { t.iss = iss } }
func ExpiresIn(d time.Duration) TokenOption { return func(t *tokenSpec) { t.ttl = d } }
func IssuedAt(at time.Time) TokenOption     { return func(t *tokenSpec) { t.issuedAt = at } }
func Restricted(scope string) TokenOption   { return func(t *tokenSpec) { t.scope = scope } }
func Methods(m ...string) TokenOption       { return func(t *tokenSpec) { t.amr = m } }
func Algorithm(alg string) TokenOption      { return func(t *tokenSpec) { t.alg = alg } }
func TamperedSignature() TokenOption        { return func(t *tokenSpec) { t.badSig = true } }
func KeyID(kid string) TokenOption          { return func(t *tokenSpec) { t.kid = kid } }

// Token issues a token for a user. By default it is valid for 10 minutes, for every module, with a fresh
// session id.
func (s *Server) Token(sub string, opts ...TokenOption) string {
	sp := tokenSpec{aud: []string{"auth", "social", "markets", "portfolio", "notifications", "ilearn"}, iss: s.Issuer(), ttl: 10 * time.Minute, amr: []string{"otp"}, alg: "RS256"}
	for _, o := range opts {
		o(&sp)
	}
	if sp.sid == "" {
		b := make([]byte, 8)
		_, _ = rand.Read(b)
		sp.sid = "sid-" + hex.EncodeToString(b)
	}
	if sp.issuedAt.IsZero() {
		sp.issuedAt = s.Now()
	}
	s.mu.Lock()
	cur := s.keys[0]
	s.mu.Unlock()
	if sp.kid == "" {
		sp.kid = cur.kid
	}
	return sign(cur.key, sp, sub)
}

// SessionOf returns the session id inside a token made by Token.
func SessionOf(token string) string {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return ""
	}
	b, _ := base64.RawURLEncoding.DecodeString(parts[1])
	var p struct {
		Sid string `json:"sid"`
	}
	_ = json.Unmarshal(b, &p)
	return p.Sid
}

func sign(key *rsa.PrivateKey, sp tokenSpec, sub string) string {
	enc := func(v any) string { b, _ := json.Marshal(v); return base64.RawURLEncoding.EncodeToString(b) }
	h := enc(map[string]string{"alg": sp.alg, "typ": "JWT", "kid": sp.kid})
	claims := map[string]any{"iss": sp.iss, "sub": sub, "aud": sp.aud, "iat": sp.issuedAt.Unix(), "nbf": sp.issuedAt.Unix(),
		"exp": sp.issuedAt.Add(sp.ttl).Unix(), "jti": "t-" + sp.sid, "sid": sp.sid, "amr": sp.amr}
	if sp.scope != "" {
		claims["scope"] = sp.scope
	}
	signingInput := h + "." + enc(claims)
	var sig []byte
	if sp.alg == "RS256" {
		sum := sha256.Sum256([]byte(signingInput))
		sig, _ = rsa.SignPKCS1v15(rand.Reader, key, crypto.SHA256, sum[:])
	} else {
		sig = []byte("not a real signature")
	}
	if sp.badSig {
		sig[len(sig)-1] ^= 0xff
	}
	return signingInput + "." + base64.RawURLEncoding.EncodeToString(sig)
}

func (s *Server) serveJWKS(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	down := s.jwksDown
	keys := append([]keyPair(nil), s.keys...)
	s.mu.Unlock()
	if down {
		http.Error(w, "down", http.StatusServiceUnavailable)
		return
	}
	var set []map[string]string
	for _, k := range keys {
		set = append(set, map[string]string{
			"kty": "RSA", "use": "sig", "alg": "RS256", "kid": k.kid,
			"n": base64.RawURLEncoding.EncodeToString(k.key.N.Bytes()),
			"e": base64.RawURLEncoding.EncodeToString([]byte{1, 0, 1}),
		})
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"keys": set})
}

// Revoker returns the fake's revocation list as an ilearnauth.Revoker.
func (s *Server) Revoker() *Revoker { return &Revoker{s: s} }

// Revoker is the fake revocation list.
type Revoker struct{ s *Server }

func (r *Revoker) Revoked(_ context.Context, sid string) (string, bool, error) {
	r.s.mu.Lock()
	defer r.s.mu.Unlock()
	if r.s.revokeErr != nil {
		return "", false, r.s.revokeErr
	}
	reason, ok := r.s.revoked[sid]
	return reason, ok, nil
}

// Revoke ends a session ("logout", "replaced", "locked").
func (s *Server) Revoke(sid, reason string) { s.mu.Lock(); s.revoked[sid] = reason; s.mu.Unlock() }

// FailRevocationChecks makes the revocation list unreadable, as if Redis were down.
func (s *Server) FailRevocationChecks(on bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if on {
		s.revokeErr = errors.New("authtest: the revocation list is down")
	} else {
		s.revokeErr = nil
	}
}

// AddUser registers a user for the internal API.
func (s *Server) AddUser(u directory.User) {
	if u.Status == "" {
		u.Status = "active"
	}
	if u.CreatedAt.IsZero() {
		u.CreatedAt = s.Now().UTC()
	}
	s.mu.Lock()
	s.users[u.Sub] = u
	s.mu.Unlock()
}

// DeleteUser removes a user: the internal API then answers not found.
func (s *Server) DeleteUser(sub string) { s.mu.Lock(); delete(s.users, sub); s.mu.Unlock() }

// AddClient registers a service client. Scopes: "users:read", "users:read_contact", "deletion:ack".
func (s *Server) AddClient(id, secret string, scopes ...string) {
	m := map[string]bool{}
	for _, sc := range scopes {
		m[sc] = true
	}
	s.mu.Lock()
	s.clients[id] = client{secret, m}
	s.mu.Unlock()
}

// Acks returns the deletion acknowledgements received so far.
func (s *Server) Acks() []Ack { s.mu.Lock(); defer s.mu.Unlock(); return append([]Ack(nil), s.acks...) }

func jsonError(w http.ResponseWriter, status int, code string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]any{"error": map[string]string{"code": code, "message": code}})
}

func (s *Server) serveToken(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil || r.PostForm.Get("grant_type") != "client_credentials" {
		jsonError(w, http.StatusBadRequest, "invalid_request")
		return
	}
	s.mu.Lock()
	c, ok := s.clients[r.PostForm.Get("client_id")]
	s.mu.Unlock()
	if !ok || c.secret != r.PostForm.Get("client_secret") || r.PostForm.Get("audience") != "auth-internal" {
		jsonError(w, http.StatusUnauthorized, "invalid_client")
		return
	}
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	tok := hex.EncodeToString(b)
	s.mu.Lock()
	s.svcToks[tok] = r.PostForm.Get("client_id")
	s.mu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"access_token": tok, "token_type": "Bearer", "expires_in": 300})
}

// caller returns the registered client behind a bearer token.
func (s *Server) caller(w http.ResponseWriter, r *http.Request) (string, client, bool) {
	tok := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	s.mu.Lock()
	id, ok := s.svcToks[tok]
	c := s.clients[id]
	s.mu.Unlock()
	if !ok {
		jsonError(w, http.StatusUnauthorized, "invalid_credentials")
		return "", client{}, false
	}
	return id, c, true
}

func (s *Server) userJSON(u directory.User, contact bool) directory.User {
	if !contact {
		u.Mobile, u.Email, u.EmailVerified = nil, nil, nil
	}
	return u
}

func (s *Server) serveUser(w http.ResponseWriter, r *http.Request) {
	_, c, ok := s.caller(w, r)
	if !ok {
		return
	}
	if !c.scopes["users:read"] && !c.scopes["users:read_contact"] {
		jsonError(w, http.StatusForbidden, "forbidden")
		return
	}
	s.mu.Lock()
	u, found := s.users[r.PathValue("sub")]
	s.mu.Unlock()
	if !found {
		jsonError(w, http.StatusNotFound, "not_found")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(s.userJSON(u, c.scopes["users:read_contact"]))
}

func (s *Server) serveBatch(w http.ResponseWriter, r *http.Request) {
	_, c, ok := s.caller(w, r)
	if !ok {
		return
	}
	if !c.scopes["users:read"] && !c.scopes["users:read_contact"] {
		jsonError(w, http.StatusForbidden, "forbidden")
		return
	}
	var body struct {
		Subs []string `json:"subs"`
	}
	if json.NewDecoder(r.Body).Decode(&body) != nil || len(body.Subs) == 0 || len(body.Subs) > 100 {
		jsonError(w, http.StatusUnprocessableEntity, "invalid_request")
		return
	}
	var users []directory.User
	s.mu.Lock()
	for _, sub := range body.Subs {
		if u, found := s.users[sub]; found {
			users = append(users, s.userJSON(u, c.scopes["users:read_contact"]))
		}
	}
	s.mu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"users": users})
}

func (s *Server) serveAck(w http.ResponseWriter, r *http.Request) {
	id, c, ok := s.caller(w, r)
	if !ok {
		return
	}
	if !c.scopes["deletion:ack"] {
		jsonError(w, http.StatusForbidden, "forbidden")
		return
	}
	var b struct {
		RequestID string         `json:"request_id"`
		Service   string         `json:"service"`
		Status    string         `json:"status"`
		Counts    map[string]int `json:"counts"`
	}
	if json.NewDecoder(r.Body).Decode(&b) != nil || b.RequestID == "" || (b.Status != "completed" && b.Status != "failed") {
		jsonError(w, http.StatusUnprocessableEntity, "invalid_request")
		return
	}
	if b.Service != id {
		jsonError(w, http.StatusForbidden, "forbidden")
		return
	}
	s.mu.Lock()
	s.acks = append(s.acks, Ack{b.RequestID, b.Service, b.Status, b.Counts})
	s.mu.Unlock()
	w.WriteHeader(http.StatusNoContent)
}

// Deliver sends a signed event to a webhook URL (your events.Receiver) the way the auth service does, and
// returns the response status. data is marshalled as the event's payload.
func (s *Server) Deliver(url, secret string, typ events.Type, sub string, data any) (int, error) {
	id := make([]byte, 16)
	_, _ = rand.Read(id)
	return s.DeliverWithID(url, secret, hex.EncodeToString(id), typ, sub, data)
}

// DeliverWithID is Deliver with a chosen event id, to send the same event twice.
func (s *Server) DeliverWithID(url, secret, id string, typ events.Type, sub string, data any) (int, error) {
	payload, err := json.Marshal(data)
	if err != nil {
		return 0, err
	}
	body, _ := json.Marshal(map[string]any{"id": id, "type": string(typ), "occurred_at": s.Now().UTC().Format(time.RFC3339), "sub": sub, "data": json.RawMessage(payload), "schema_version": 1})
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return 0, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set(events.SignatureHeader, events.Sign(secret, s.Now(), body))
	req.Header.Set("X-Ilearn-Event-Id", id)
	req.Header.Set("X-Ilearn-Event-Type", string(typ))
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	return resp.StatusCode, nil
}

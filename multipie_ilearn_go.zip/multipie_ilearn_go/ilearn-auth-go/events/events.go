// Package events receives the signed user events the auth service sends to registered services: a user was
// created, changed their profile, verified an email, changed their mobile, or has to be erased.
//
// Delivery is "at least once": the same event can arrive more than once, and a few seconds late or hours
// late after an outage. The Receiver therefore checks the signature and the timestamp, drops duplicates
// (give it a Store), and answers the way the sender's retry rules expect:
//
//	204  handled, or already handled, or a type this version does not know (so a new event type never
//	     makes the sender retry for hours)
//	401  the signature or timestamp is not valid (nothing else is said)
//	500  your handler returned an error: the sender retries, with growing waits, up to 25 times
//
// Register the receiver at the URL given to `authadmin subscriber add`, with the signing secret it printed.
package events

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strconv"
	"strings"
	"time"
)

// Type is an event type.
type Type string

const (
	UserCreated       Type = "user.created"
	ProfileUpdated    Type = "user.profile_updated"
	MobileChanged     Type = "user.mobile_changed"
	EmailVerified     Type = "user.email_verified"
	DeletionRequested Type = "user.deletion_requested"
)

// Event is one delivery. Data holds the type's payload; use the helper methods.
type Event struct {
	ID            string          `json:"id"`
	Type          Type            `json:"type"`
	OccurredAt    time.Time       `json:"occurred_at"`
	Sub           string          `json:"sub"`
	Data          json.RawMessage `json:"data"`
	SchemaVersion int             `json:"schema_version"`
}

// Profile is the public profile in user.created and user.profile_updated. A user's mobile number and email
// are never in an event.
type Profile struct {
	Username    string `json:"username"`
	DisplayName string `json:"display_name"`
	Bio         string `json:"bio"`
	AvatarURL   string `json:"avatar_url"`
	CoverURL    string `json:"cover_url"`
}

// Deletion is the payload of user.deletion_requested: erase this user's data, then acknowledge.
type Deletion struct {
	RequestID   string    `json:"request_id"`
	EffectiveAt time.Time `json:"effective_at"`
}

// Profile decodes the payload of user.created and user.profile_updated.
func (e Event) Profile() (Profile, error) {
	var p Profile
	err := json.Unmarshal(e.Data, &p)
	return p, err
}

// Deletion decodes the payload of user.deletion_requested.
func (e Event) Deletion() (Deletion, error) {
	var d Deletion
	err := json.Unmarshal(e.Data, &d)
	return d, err
}

// Handler handles one event. Return an error to have the sender retry later. It must be safe to run twice
// for the same event (a Store makes that rare, not impossible).
type Handler func(ctx context.Context, e Event) error

// SignatureHeader carries "t=<unix seconds>,v1=<hex HMAC-SHA256 of the timestamp, a dot and the raw body>".
const SignatureHeader = "X-Ilearn-Signature"

// ErrBadSignature is returned for every kind of signature failure, so a forger learns nothing.
var ErrBadSignature = errors.New("events: signature not valid")

// Verify checks a delivery's signature against a secret. tolerance bounds how old (or how far in the future)
// the timestamp may be.
func Verify(secret, header string, body []byte, now time.Time, tolerance time.Duration) error {
	var t int64
	var sig string
	for _, part := range strings.Split(header, ",") {
		k, v, ok := strings.Cut(strings.TrimSpace(part), "=")
		if !ok {
			continue
		}
		switch k {
		case "t":
			n, err := strconv.ParseInt(v, 10, 64)
			if err != nil {
				return ErrBadSignature
			}
			t = n
		case "v1":
			sig = v
		}
	}
	if t == 0 || sig == "" {
		return ErrBadSignature
	}
	if d := now.Sub(time.Unix(t, 0)); d > tolerance || d < -tolerance {
		return ErrBadSignature
	}
	got, err := hex.DecodeString(sig)
	if err != nil || !hmac.Equal(mac(secret, t, body), got) {
		return ErrBadSignature
	}
	return nil
}

// Sign makes the header value for a body; it is what the sender does, exported for tests of your own.
func Sign(secret string, at time.Time, body []byte) string {
	t := at.Unix()
	return "t=" + strconv.FormatInt(t, 10) + ",v1=" + hex.EncodeToString(mac(secret, t, body))
}

func mac(secret string, t int64, body []byte) []byte {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write([]byte(strconv.FormatInt(t, 10)))
	h.Write([]byte("."))
	h.Write(body)
	return h.Sum(nil)
}

// Config configures a Receiver.
type Config struct {
	// Secret is the signing secret printed by `authadmin subscriber add`.
	Secret string
	// PreviousSecret is accepted too, so a rotation needs no downtime. Optional.
	PreviousSecret string
	// Tolerance for the timestamp. Default 5 minutes.
	Tolerance time.Duration
	// Store drops duplicates. Without one every delivery is handled, so your handlers must be idempotent.
	Store Store
	// MaxBody is the largest accepted body. Default 64 KiB.
	MaxBody int64
	Logger  *slog.Logger
	Now     func() time.Time
}

// Receiver is an http.Handler for the webhook URL.
type Receiver struct {
	cfg      Config
	handlers map[Type]Handler
	log      *slog.Logger
}

// New validates the configuration.
func New(cfg Config) (*Receiver, error) {
	if len(cfg.Secret) < 16 {
		return nil, errors.New("events: Secret is the signing secret printed by authadmin subscriber add")
	}
	if cfg.Tolerance <= 0 {
		cfg.Tolerance = 5 * time.Minute
	}
	if cfg.MaxBody <= 0 {
		cfg.MaxBody = 64 << 10
	}
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	log := cfg.Logger
	if log == nil {
		log = slog.New(slog.NewTextHandler(io.Discard, nil))
	}
	return &Receiver{cfg: cfg, handlers: map[Type]Handler{}, log: log}, nil
}

// On registers the handler for a type; a type with no handler is acknowledged and ignored.
func (r *Receiver) On(t Type, h Handler) *Receiver { r.handlers[t] = h; return r }

// OnProfile registers one handler for user.created and user.profile_updated: the usual reason to keep a
// copy of a name or picture.
func (r *Receiver) OnProfile(h func(ctx context.Context, sub string, p Profile) error) *Receiver {
	f := func(ctx context.Context, e Event) error {
		p, err := e.Profile()
		if err != nil {
			return err
		}
		return h(ctx, e.Sub, p)
	}
	return r.On(UserCreated, f).On(ProfileUpdated, f)
}

// ServeHTTP verifies and dispatches one delivery.
func (r *Receiver) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		w.Header().Set("Allow", "POST")
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	body, err := io.ReadAll(http.MaxBytesReader(w, req.Body, r.cfg.MaxBody))
	if err != nil {
		http.Error(w, "body too large", http.StatusRequestEntityTooLarge)
		return
	}
	header, now := req.Header.Get(SignatureHeader), r.cfg.Now()
	if Verify(r.cfg.Secret, header, body, now, r.cfg.Tolerance) != nil &&
		(r.cfg.PreviousSecret == "" || Verify(r.cfg.PreviousSecret, header, body, now, r.cfg.Tolerance) != nil) {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	var e Event
	if json.Unmarshal(body, &e) != nil || e.ID == "" || e.Type == "" {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	h, known := r.handlers[e.Type]
	if !known {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	ctx := req.Context()
	if r.cfg.Store != nil {
		first, err := r.cfg.Store.Begin(ctx, e.ID)
		if err != nil {
			r.log.Error("events: store failed", "error", err.Error())
			http.Error(w, "unavailable", http.StatusServiceUnavailable)
			return
		}
		if !first {
			w.WriteHeader(http.StatusNoContent)
			return
		}
	}
	if err := h(ctx, e); err != nil {
		if r.cfg.Store != nil {
			_ = r.cfg.Store.Abort(ctx, e.ID)
		}
		r.log.Error("events: handler failed", "type", string(e.Type), "event_id", e.ID, "error", err.Error())
		http.Error(w, "handler failed", http.StatusInternalServerError)
		return
	}
	if r.cfg.Store != nil {
		if err := r.cfg.Store.Done(ctx, e.ID); err != nil {
			r.log.Error("events: store failed", "error", err.Error())
		}
	}
	w.WriteHeader(http.StatusNoContent)
}

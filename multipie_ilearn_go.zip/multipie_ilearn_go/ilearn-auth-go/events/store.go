package events

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"sync"
	"time"
)

// Store remembers which events have been handled, to drop duplicates.
//
// Begin claims an event: it returns true the first time (or after an Abort), and false when the event is
// already handled or being handled right now. Done keeps the claim; Abort releases it, so the sender's retry
// is handled again.
type Store interface {
	Begin(ctx context.Context, eventID string) (first bool, err error)
	Done(ctx context.Context, eventID string) error
	Abort(ctx context.Context, eventID string) error
}

// MemoryStore keeps handled event ids in memory for a while. Fine for one process and for tests; several
// copies of your service need SQLStore.
type MemoryStore struct {
	TTL time.Duration // default 48 hours
	Now func() time.Time

	mu   sync.Mutex
	seen map[string]time.Time
}

func (m *MemoryStore) now() time.Time {
	if m.Now != nil {
		return m.Now()
	}
	return time.Now()
}

func (m *MemoryStore) Begin(_ context.Context, id string) (bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.seen == nil {
		m.seen = map[string]time.Time{}
	}
	ttl := m.TTL
	if ttl <= 0 {
		ttl = 48 * time.Hour
	}
	now := m.now()
	for k, exp := range m.seen { // forget what is old enough that the sender will not repeat it
		if !now.Before(exp) {
			delete(m.seen, k)
		}
	}
	if _, ok := m.seen[id]; ok {
		return false, nil
	}
	m.seen[id] = now.Add(ttl)
	return true, nil
}

func (m *MemoryStore) Done(context.Context, string) error { return nil }

func (m *MemoryStore) Abort(_ context.Context, id string) error {
	m.mu.Lock()
	delete(m.seen, id)
	m.mu.Unlock()
	return nil
}

// Dialect says which SQL to write.
type Dialect int

const (
	Postgres Dialect = iota + 1
	MySQL
)

// SQLStore keeps handled event ids in a table, so every copy of your service shares them. Create the table
// with Schema. Rows older than the sender's longest retry window (a few days) can be deleted by a job of
// yours: DELETE FROM <table> WHERE received_at < now() - interval '7 days'.
type SQLStore struct {
	DB      *sql.DB
	Dialect Dialect
	Table   string // default "auth_events_handled"
}

func (s SQLStore) table() string {
	if s.Table != "" {
		return s.Table
	}
	return "auth_events_handled"
}

// Schema is the DDL for the table.
func (s SQLStore) Schema() string {
	if s.Dialect == MySQL {
		return fmt.Sprintf("CREATE TABLE IF NOT EXISTS %s (event_id VARCHAR(64) NOT NULL PRIMARY KEY, received_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3))", s.table())
	}
	return fmt.Sprintf("CREATE TABLE IF NOT EXISTS %s (event_id text PRIMARY KEY, received_at timestamptz NOT NULL DEFAULT now())", s.table())
}

// Begin inserts the id; a duplicate key means another delivery has it.
func (s SQLStore) Begin(ctx context.Context, id string) (bool, error) {
	var q string
	switch s.Dialect {
	case Postgres:
		q = fmt.Sprintf("INSERT INTO %s (event_id) VALUES ($1) ON CONFLICT DO NOTHING", s.table())
	case MySQL:
		q = fmt.Sprintf("INSERT IGNORE INTO %s (event_id) VALUES (?)", s.table())
	default:
		return false, errors.New("events: SQLStore needs a Dialect")
	}
	res, err := s.DB.ExecContext(ctx, q, id)
	if err != nil {
		return false, err
	}
	n, err := res.RowsAffected()
	return n == 1, err
}

func (s SQLStore) Done(context.Context, string) error { return nil }

func (s SQLStore) Abort(ctx context.Context, id string) error {
	q := fmt.Sprintf("DELETE FROM %s WHERE event_id = ?", s.table())
	if s.Dialect == Postgres {
		q = fmt.Sprintf("DELETE FROM %s WHERE event_id = $1", s.table())
	}
	_, err := s.DB.ExecContext(ctx, q, id)
	return err
}

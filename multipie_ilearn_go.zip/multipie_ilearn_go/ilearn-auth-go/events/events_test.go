package events_test

import (
	"bytes"
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"ilearn-auth-go/directory"
	"ilearn-auth-go/events"
)

const secret = "a-signing-secret-of-some-length"

func body(id, typ, data string) []byte {
	return []byte(`{"id":"` + id + `","type":"` + typ + `","occurred_at":"2026-11-05T10:00:00Z","sub":"0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d","data":` + data + `,"schema_version":1}`)
}

func post(r http.Handler, b []byte, header string) *httptest.ResponseRecorder {
	req := httptest.NewRequest("POST", "/hooks/auth", bytes.NewReader(b))
	if header != "" {
		req.Header.Set(events.SignatureHeader, header)
	}
	rec := httptest.NewRecorder()
	r.ServeHTTP(rec, req)
	return rec
}

func signed(b []byte) string { return events.Sign(secret, time.Now(), b) }

func TestAValidDeliveryIsHandledAndAnswered204(t *testing.T) {
	var got events.Event
	recv, _ := events.New(events.Config{Secret: secret})
	recv.On(events.ProfileUpdated, func(_ context.Context, e events.Event) error { got = e; return nil })
	b := body("e1", "user.profile_updated", `{"username":"mayank","display_name":"Mayank","bio":"b","avatar_url":"","cover_url":""}`)
	if rec := post(recv, b, signed(b)); rec.Code != 204 {
		t.Fatalf("%d", rec.Code)
	}
	p, err := got.Profile()
	if got.ID != "e1" || got.Type != events.ProfileUpdated || p.DisplayName != "Mayank" || err != nil || got.OccurredAt.IsZero() {
		t.Fatalf("%+v %+v %v", got, p, err)
	}
}

func TestEveryKindOfBadSignatureIsAnswered401AndNothingRuns(t *testing.T) {
	var ran atomic.Int32
	recv, _ := events.New(events.Config{Secret: secret})
	recv.On(events.UserCreated, func(context.Context, events.Event) error { ran.Add(1); return nil })
	b := body("e2", "user.created", `{}`)
	now := time.Now()
	for name, header := range map[string]string{
		"none":              "",
		"garbage":           "hello",
		"wrong secret":      events.Sign("another-secret-of-some-length", now, b),
		"body changed":      events.Sign(secret, now, []byte("other")),
		"too old":           events.Sign(secret, now.Add(-10*time.Minute), b),
		"too far ahead":     events.Sign(secret, now.Add(10*time.Minute), b),
		"no timestamp":      "v1=" + strings.Split(signed(b), "v1=")[1],
		"no signature":      "t=" + strings.Split(strings.Split(signed(b), "t=")[1], ",")[0],
		"timestamp as text": "t=abc,v1=00",
		"signature not hex": "t=" + strings.Split(strings.Split(signed(b), "t=")[1], ",")[0] + ",v1=zz",
	} {
		if rec := post(recv, b, header); rec.Code != 401 {
			t.Errorf("%s: %d", name, rec.Code)
		}
	}
	if ran.Load() != 0 {
		t.Fatalf("a handler ran for a forged delivery")
	}
}

func TestARotatedSecretIsAcceptedUntilThePreviousOneIsDropped(t *testing.T) {
	recv, _ := events.New(events.Config{Secret: secret, PreviousSecret: "the-old-secret-of-some-length"})
	recv.On(events.UserCreated, func(context.Context, events.Event) error { return nil })
	b := body("e3", "user.created", `{}`)
	if rec := post(recv, b, events.Sign("the-old-secret-of-some-length", time.Now(), b)); rec.Code != 204 {
		t.Errorf("old secret: %d", rec.Code)
	}
	if rec := post(recv, b, events.Sign(secret, time.Now(), b)); rec.Code != 204 {
		t.Errorf("new secret: %d", rec.Code)
	}
	only, _ := events.New(events.Config{Secret: secret})
	if rec := post(only, b, events.Sign("the-old-secret-of-some-length", time.Now(), b)); rec.Code != 401 {
		t.Errorf("after the old secret is dropped: %d", rec.Code)
	}
}

func TestDuplicatesAreDroppedAndAFailureIsRetriedNotLost(t *testing.T) {
	var calls atomic.Int32
	fail := true
	recv, _ := events.New(events.Config{Secret: secret, Store: &events.MemoryStore{}})
	recv.On(events.UserCreated, func(context.Context, events.Event) error {
		calls.Add(1)
		if fail {
			return errors.New("database down")
		}
		return nil
	})
	b := body("e4", "user.created", `{}`)
	if rec := post(recv, b, signed(b)); rec.Code != 500 {
		t.Fatalf("a failing handler must make the sender retry: %d", rec.Code)
	}
	fail = false
	if rec := post(recv, b, signed(b)); rec.Code != 204 || calls.Load() != 2 {
		t.Fatalf("the retry must run the handler again: %d, %d calls", rec.Code, calls.Load())
	}
	if rec := post(recv, b, signed(b)); rec.Code != 204 || calls.Load() != 2 {
		t.Fatalf("a duplicate must not run the handler: %d, %d calls", rec.Code, calls.Load())
	}
}

func TestAnUnknownTypeIsAcknowledgedSoItIsNotRetriedForHours(t *testing.T) {
	recv, _ := events.New(events.Config{Secret: secret})
	b := body("e5", "user.something_new", `{}`)
	if rec := post(recv, b, signed(b)); rec.Code != 204 {
		t.Fatalf("%d", rec.Code)
	}
}

func TestOnlyPostWithAReasonableBodyIsAccepted(t *testing.T) {
	recv, _ := events.New(events.Config{Secret: secret, MaxBody: 100})
	req := httptest.NewRequest("GET", "/", nil)
	rec := httptest.NewRecorder()
	recv.ServeHTTP(rec, req)
	if rec.Code != 405 {
		t.Errorf("GET: %d", rec.Code)
	}
	big := []byte(strings.Repeat("x", 500))
	if rec := post(recv, big, signed(big)); rec.Code != 413 {
		t.Errorf("a large body: %d", rec.Code)
	}
	bad := []byte(`{"not":"an event"}`)
	if rec := post(recv, bad, signed(bad)); rec.Code != 400 {
		t.Errorf("not an event: %d", rec.Code)
	}
}

func TestOnProfileCoversCreatedAndUpdated(t *testing.T) {
	var subs []string
	recv, _ := events.New(events.Config{Secret: secret})
	recv.OnProfile(func(_ context.Context, sub string, p events.Profile) error {
		subs = append(subs, sub+":"+p.Username)
		return nil
	})
	for _, typ := range []string{"user.created", "user.profile_updated"} {
		b := body("id-"+typ, typ, `{"username":"u"}`)
		if rec := post(recv, b, signed(b)); rec.Code != 204 {
			t.Fatal(rec.Code)
		}
	}
	if len(subs) != 2 {
		t.Fatalf("%v", subs)
	}
}

func TestMemoryStoreForgetsOldEvents(t *testing.T) {
	now := time.Now()
	s := &events.MemoryStore{TTL: time.Hour, Now: func() time.Time { return now }}
	ctx := context.Background()
	if first, _ := s.Begin(ctx, "a"); !first {
		t.Fatal("first")
	}
	if first, _ := s.Begin(ctx, "a"); first {
		t.Fatal("duplicate")
	}
	now = now.Add(2 * time.Hour)
	if first, _ := s.Begin(ctx, "a"); !first {
		t.Fatal("after the TTL")
	}
}

type fakeAcker struct {
	status directory.AckStatus
	counts map[string]int
	req    string
	err    error
}

func (f *fakeAcker) AckDeletion(_ context.Context, req string, st directory.AckStatus, c map[string]int) error {
	f.req, f.status, f.counts = req, st, c
	return f.err
}

func TestDeletionErasesThenAcknowledges(t *testing.T) {
	ack := &fakeAcker{}
	h := events.EraseOnDeletion(ack, func(_ context.Context, sub string) (map[string]int, error) {
		return map[string]int{"progress": 7}, nil
	})
	e := events.Event{ID: "d1", Type: events.DeletionRequested, Sub: "s", Data: []byte(`{"request_id":"req-1","effective_at":"2026-11-05T10:00:00Z"}`)}
	if err := h(context.Background(), e); err != nil || ack.status != directory.AckCompleted || ack.req != "req-1" || ack.counts["progress"] != 7 {
		t.Fatalf("%+v %v", ack, err)
	}
}

func TestAFailedErasureIsAcknowledgedAsFailedAndRetried(t *testing.T) {
	ack := &fakeAcker{}
	h := events.EraseOnDeletion(ack, func(context.Context, string) (map[string]int, error) { return nil, errors.New("disk") })
	e := events.Event{ID: "d2", Type: events.DeletionRequested, Sub: "s", Data: []byte(`{"request_id":"req-2"}`)}
	if err := h(context.Background(), e); err == nil || ack.status != directory.AckFailed {
		t.Fatalf("auth must be told it failed, and the sender must retry: %+v %v", ack, err)
	}
	ack.err = errors.New("auth down")
	if err := h(context.Background(), e); err == nil {
		t.Fatal("an acknowledgement that could not be sent must be retried")
	}
	bad := events.Event{ID: "d3", Type: events.DeletionRequested, Data: []byte(`{}`)}
	if err := h(context.Background(), bad); err == nil {
		t.Fatal("an event without a request id was accepted")
	}
}

func TestNewNeedsARealSecret(t *testing.T) {
	if _, err := events.New(events.Config{Secret: "short"}); err == nil {
		t.Fatal("a short secret was accepted")
	}
}

package events

import (
	"context"
	"errors"
	"fmt"

	"ilearn-auth-go/directory"
)

// Eraser erases everything your service holds about one user and says how much it removed (for the audit
// trail: {"progress": 41, "certificates": 2}; never personal data). It must be safe to run twice. Return an
// error if anything could not be erased.
type Eraser func(ctx context.Context, sub string) (counts map[string]int, err error)

// Acknowledger is the part of directory.Client this needs.
type Acknowledger interface {
	AckDeletion(ctx context.Context, requestID string, status directory.AckStatus, counts map[string]int) error
}

// EraseOnDeletion returns the handler for user.deletion_requested: it runs your Eraser and tells the auth
// service the result. Until every service has acknowledged, the user is not deleted, so this is the one handler
// that must work.
//
//	recv.On(events.DeletionRequested, events.EraseOnDeletion(dir, eraseLearner))
//
// If the Eraser fails, "failed" is acknowledged (so auth reports it) and the error is returned, which makes
// the sender retry; a later success replaces the failure. If the acknowledgement itself cannot be sent the
// error is returned too, so the delivery is retried and the (idempotent) erasure runs again.
func EraseOnDeletion(ack Acknowledger, erase Eraser) Handler {
	return func(ctx context.Context, e Event) error {
		d, err := e.Deletion()
		if err != nil || d.RequestID == "" {
			return errors.New("events: a deletion event without a request id")
		}
		counts, eraseErr := erase(ctx, e.Sub)
		status := directory.AckCompleted
		if eraseErr != nil {
			status = directory.AckFailed
		}
		if err := ack.AckDeletion(ctx, d.RequestID, status, counts); err != nil {
			return fmt.Errorf("events: acknowledging the deletion: %w", err)
		}
		if eraseErr != nil {
			return fmt.Errorf("events: erasing the user's data: %w", eraseErr)
		}
		return nil
	}
}

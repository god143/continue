# ilearn-auth-go: sign-in for the iLearn Go service

What your service gets, with no auth code of its own:

| You need | You call | Package |
|---|---|---|
| Only signed-in users reach your routes | `auth.Require(handler)` | `ilearnauth` |
| Public pages that show more to a signed-in user | `auth.Optional(handler)` | `ilearnauth` |
| Who is calling | `ilearnauth.UserID(ctx)`, `ilearnauth.FromContext(ctx)` | `ilearnauth` |
| Websockets, queues (no HTTP middleware) | `auth.Check(ctx, token)` | `ilearnauth` |
| A person's name and picture, for comments, quizzes, certificates | `dir.Get(ctx, sub)`, `dir.BatchGet(ctx, subs)` | `directory` |
| To hear that a profile changed | `events.New(...).OnProfile(...)` | `events` |
| To erase a learner's data when they delete their account | `events.EraseOnDeletion(dir, yourEraser)` | `events` |
| Your own user id for a `sub`; re-keying old iLearn users | `usermap.Resolver`, `usermap.ReadLegacyCSV` | `usermap` |
| Tests that need no network and no auth service | `authtest.New(t)` | `authtest` |

## Add it to your project

Unzip next to your code (for example into `third_party/ilearn-auth-go`) and in your `go.mod`:

```
require ilearn-auth-go v0.0.0
replace ilearn-auth-go => ./third_party/ilearn-auth-go
```

Go 1.22 or newer. The only dependency is `go-redis` (for the revocation check).

## 1. Protect your routes

```go
rdb := redis.NewClient(&redis.Options{Addr: cfg.AuthRedisAddr, Username: cfg.AuthRedisUser, Password: cfg.AuthRedisPassword, TLSConfig: &tls.Config{MinVersion: tls.VersionTLS12}})

auth, err := ilearnauth.New(ilearnauth.Config{
    Issuer:   "https://api-ilearn.icicidirect.com/auth", // UAT: https://api-ilearn-uat.icicidirect.com/auth
    Audience: "ilearn",
    Revoker:  redisrevoker.New(rdb),
})
if err != nil { log.Fatal(err) }
if err := auth.Warm(ctx); err != nil { log.Fatal(err) } // fail at start if auth cannot be reached

mux.Handle("/ilearn/v1/", auth.Require(learnRoutes))

func myHandler(w http.ResponseWriter, r *http.Request) {
    userID := ilearnauth.UserID(r.Context()) // the "sub": the same UUID in every service
}
```

- The **issuer** is exactly the auth service's public host plus `/auth`; it never changes once tokens exist.
- **Revocation** is checked against the auth service's Redis, read-only. Ask the auth team for a Redis user that may only `GET revoked_sid:*`. If Redis is unreachable the middleware answers **503** and lets nobody through: a logged-out session must not keep working.
- The middleware answers with the auth service's own error body: `401 invalid_credentials`, `401 token_expired` (the app refreshes and retries), `401 session_replaced` (signed in on another device), `401 token_revoked` (logged out), `503 unavailable`.
- Tokens for the account-deletion cool-off (restricted sessions) are refused: they are for the auth service only.

## 2. Look up people

Register your service once (the auth team runs this): `authadmin client add -id ilearn -scopes users:read,deletion:ack`. You get a secret, once.

```go
dir, _ := directory.New(directory.Config{
    BaseURL:      "https://10.1.2.3:8081", // the auth service's INTERNAL address, not the public one
    ClientID:     "ilearn",
    ClientSecret: secret,
    HTTPClient:   httpClientTrustingTheInternalCA,
})
u, err := dir.Get(ctx, sub)                // errors.Is(err, directory.ErrNotFound) when deleted or unknown
users, err := dir.BatchGet(ctx, subs)      // any number of subs; missing ones are absent from the map
```

The service token is fetched, reused and renewed for you; results are cached for a minute (`CacheTTL`). A wrong secret is reported once as `directory.ErrInvalidClient` and is not retried (the auth service throttles guessing).

## 3. Events and account deletion

The auth team registers your URL: `authadmin subscriber add -id ilearn -url https://learn.internal/hooks/auth -events user.*`. You get a signing secret, once.

```go
recv, _ := events.New(events.Config{
    Secret: signingSecret,
    Store:  events.SQLStore{DB: db, Dialect: events.MySQL}, // run store.Schema() once to create the table
})
recv.OnProfile(func(ctx context.Context, sub string, p events.Profile) error {
    dir.Forget(sub) // and update any copy of the name or picture you keep
    return nil
})
recv.On(events.DeletionRequested, events.EraseOnDeletion(dir, func(ctx context.Context, sub string) (map[string]int, error) {
    n, err := eraseLearner(ctx, sub) // progress, certificates, quiz answers, comments, bookmarks...
    return map[string]int{"records": n}, err
}))
mux.Handle("POST /hooks/auth", recv)
```

- Delivery is **at least once**, and late after an outage. The `Store` drops duplicates; write the handlers so that running twice is harmless anyway.
- **Deletion is the one that must work.** The user is deleted only after every service in the auth service's `DELETION_ACK_SERVICES` has acknowledged. `EraseOnDeletion` runs your function and acknowledges; if your function fails it acknowledges `failed` and returns an error so the sender retries. Your eraser must be safe to run twice.
- Answers: `204` handled, duplicate, or an event type this version does not know; `401` bad signature or timestamp; `500` your handler failed (the sender retries up to 25 times over about two days).
- An event never contains a mobile number or an email.

## 4. Existing iLearn users

The auth team sends a CSV `source,source_id,sub` (header included) of your old users and their new ids:

```go
usermap.ReadLegacyCSV(f, func(r usermap.LegacyRow) error {
    return db.Exec(`UPDATE learners SET auth_sub = ? WHERE legacy_id = ?`, r.Sub, r.SourceID)
})
```

For new users, `usermap.Resolver{Store: yourStore}.Resolve(ctx, sub)` finds or creates your local user and remembers it.

## 5. Test without the auth service

```go
fake := authtest.New(t)
auth, _ := ilearnauth.New(ilearnauth.Config{Issuer: fake.Issuer(), Audience: "ilearn", Revoker: fake.Revoker()})
req.Header.Set("Authorization", "Bearer "+fake.Token("user-uuid"))

fake.Revoke(authtest.SessionOf(tok), "logout")   // the next call answers token_revoked
fake.FailRevocationChecks(true)                  // the next call answers 503
fake.AddClient("ilearn", "secret", "users:read", "deletion:ack")
fake.AddUser(directory.User{Sub: "user-uuid", DisplayName: "Test User"})
status, _ := fake.Deliver(hookURL, secret, events.ProfileUpdated, "user-uuid", events.Profile{DisplayName: "New"})
```

`authtest` signs genuine RS256 tokens and serves the JWKS, so your real middleware verifies them.

## Settings your service needs (all from the auth team)

| Setting | Example |
|---|---|
| Issuer | `https://api-ilearn.icicidirect.com/auth` |
| Audience | `ilearn` |
| Redis (read-only) address, user, password | |
| Internal API address, client id, secret | `https://10.1.2.3:8081`, `ilearn`, `...` |
| Webhook signing secret | |
| The internal CA certificate | to trust the internal address |

## Forced update and maintenance

The auth service refuses, on every `/auth/v1/` call, an app version below its minimum (`426 upgrade_required`) and everyone during maintenance (`503 maintenance`). Your Go service is not an app and needs nothing for this. If your own routes must also stop during maintenance, answer `503` with `{"error":{"code":"maintenance"}}` when `GET <auth>/auth/v1/app-config` reports `maintenance.active` (cache it for a few seconds); the app already treats any `503 maintenance` from a module as the maintenance screen.

## Compatibility

This library speaks auth API **v1**. A breaking change ships as `/auth/v2` with both supported for an announced period. Changes are listed in `CHANGELOG.md`.

package ilearnauth

import (
	"context"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"math/big"
	"net/http"
	"sync"
	"time"
)

// jwksCache fetches and caches the auth service's public keys. A fetched set is trusted for ttl. An unknown
// key id triggers a refetch, but never more often than minRefresh, so a flood of tokens with random key ids
// cannot make this service hammer auth. Keys already fetched keep working through an auth outage.
type jwksCache struct {
	url        string
	client     *http.Client
	ttl        time.Duration
	minRefresh time.Duration
	now        func() time.Time

	mu      sync.Mutex
	keys    map[string]*rsa.PublicKey
	fetched time.Time
	lastTry time.Time
}

func (c *jwksCache) key(ctx context.Context, kid string) (*rsa.PublicKey, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	now := c.now()
	fresh := c.keys != nil && now.Sub(c.fetched) < c.ttl
	if k, ok := c.keys[kid]; ok && fresh {
		return k, nil
	}
	if c.keys == nil || !fresh || now.Sub(c.lastTry) >= c.minRefresh {
		c.lastTry = now
		if err := c.fetch(ctx, now); err != nil {
			if k, ok := c.keys[kid]; ok { // an outage must not stop sign-ins with a key we already know
				return k, nil
			}
			return nil, ErrInvalid
		}
	}
	if k, ok := c.keys[kid]; ok {
		return k, nil
	}
	return nil, ErrInvalid
}

type jwk struct {
	Kty string `json:"kty"`
	Kid string `json:"kid"`
	Use string `json:"use"`
	Alg string `json:"alg"`
	N   string `json:"n"`
	E   string `json:"e"`
}

func (c *jwksCache) fetch(ctx context.Context, now time.Time) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.url, nil)
	if err != nil {
		return err
	}
	resp, err := c.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return errors.New("jwks: unexpected status")
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	if err != nil {
		return err
	}
	var set struct {
		Keys []jwk `json:"keys"`
	}
	if err := json.Unmarshal(body, &set); err != nil {
		return err
	}
	keys := make(map[string]*rsa.PublicKey, len(set.Keys))
	for _, k := range set.Keys {
		// Only RS256 signing keys count; anything else in the set is ignored.
		if k.Kty != "RSA" || k.Kid == "" || (k.Use != "" && k.Use != "sig") || (k.Alg != "" && k.Alg != "RS256") {
			continue
		}
		pub, err := k.public()
		if err != nil {
			continue
		}
		keys[k.Kid] = pub
	}
	if len(keys) == 0 {
		return errors.New("jwks: no usable keys")
	}
	c.keys, c.fetched = keys, now
	return nil
}

func (k jwk) public() (*rsa.PublicKey, error) {
	nb, err := base64.RawURLEncoding.DecodeString(k.N)
	if err != nil {
		return nil, err
	}
	eb, err := base64.RawURLEncoding.DecodeString(k.E)
	if err != nil {
		return nil, err
	}
	n := new(big.Int).SetBytes(nb)
	e := new(big.Int).SetBytes(eb)
	if n.BitLen() < 2048 || !e.IsInt64() || e.Int64() < 3 || e.Int64() > 1<<31-1 {
		return nil, errors.New("jwks: unacceptable key")
	}
	return &rsa.PublicKey{N: n, E: int(e.Int64())}, nil
}

# Changelog

## 0.1.0

First release: token verification and middleware, revocation (Redis), user directory, event receiver and deletion helper, legacy-user mapping, test fake.

## 0.1.1

Documentation: how forced update and maintenance interact with a Go service. No code change.

## 0.3.0

No code change; the version follows the Flutter library (which now sends `X-Device-Id`). Go services are not apps and send no app headers.

## 0.4.0

No code change; the version follows the Flutter library (operating system minimum).

## 0.5.0

No code change; the version follows the Flutter library (consent). A restricted `consent` token carries the audience `auth` only, so `Require` already refuses it in every other service.

## 0.6.0

No code change; the version follows the Flutter library (the firm update nudge).

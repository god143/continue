package ilearnauth

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
)

// Require wraps a handler so that only requests with a valid, unrevoked bearer token reach it. It answers
// the way the auth service does, with a JSON body {"error":{"code","message"}}:
//
//	401 invalid_credentials  no token, or a token that does not verify
//	401 token_expired        a genuine token that has expired: the app refreshes and retries
//	401 session_replaced     the user signed in on another device
//	401 token_revoked        the user logged out
//	503 unavailable          revocation cannot be checked (fail closed)
//
// The verified claims are in the request context (FromContext, UserID).
func (a *Auth) Require(next http.Handler) http.Handler { return a.middleware(next, false) }

// Optional is Require for public pages that show more to a signed-in user: with no Authorization header the
// request goes through anonymously; with one it must be valid, and a bad token is refused, not ignored.
func (a *Auth) Optional(next http.Handler) http.Handler { return a.middleware(next, true) }

func (a *Auth) middleware(next http.Handler, optional bool) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, present := bearer(r)
		if !present {
			if optional && r.Header.Get("Authorization") == "" {
				next.ServeHTTP(w, r)
				return
			}
			writeError(w, http.StatusUnauthorized, "invalid_credentials")
			return
		}
		c, err := a.Check(r.Context(), raw)
		switch {
		case err == nil:
			next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), ctxKey{}, c)))
		case errors.Is(err, ErrExpired):
			writeError(w, http.StatusUnauthorized, "token_expired")
		case errors.Is(err, ErrReplaced):
			writeError(w, http.StatusUnauthorized, "session_replaced")
		case errors.Is(err, ErrRevoked):
			writeError(w, http.StatusUnauthorized, "token_revoked")
		case errors.Is(err, ErrInvalid):
			a.log.Debug("ilearnauth: token refused")
			writeError(w, http.StatusUnauthorized, "invalid_credentials")
		default:
			a.log.Error("ilearnauth: cannot check revocation", "error", err.Error())
			writeError(w, http.StatusServiceUnavailable, "unavailable")
		}
	})
}

func bearer(r *http.Request) (string, bool) {
	h := r.Header.Get("Authorization")
	const prefix = "Bearer "
	if len(h) <= len(prefix) || !strings.EqualFold(h[:len(prefix)], prefix) {
		return "", false
	}
	return strings.TrimSpace(h[len(prefix):]), true
}

var messages = map[string]string{"unavailable": "Please try again shortly."}

func writeError(w http.ResponseWriter, status int, code string) {
	msg := messages[code]
	if msg == "" {
		msg = "Authentication is required."
	}
	w.Header().Set("Content-Type", "application/json")
	if status == http.StatusUnauthorized {
		w.Header().Set("WWW-Authenticate", `Bearer realm="ilearn"`)
	}
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]any{"error": map[string]string{"code": code, "message": msg}})
}

package ilearnauth

import "context"

// Revoker answers whether a session has been revoked. The reason is why: "logout", "replaced", "locked".
// An implementation must return an error, never "not revoked", when it cannot tell; the middleware then
// answers 503, so a Redis outage cannot let a logged-out session through.
type Revoker interface {
	Revoked(ctx context.Context, sessionID string) (reason string, revoked bool, err error)
}

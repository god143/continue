package ilearnauth

import (
	"context"
	"time"
)

// Claims is what a verified token tells a service.
type Claims struct {
	Subject   string   // the user's id (sub): an opaque UUID, the same in every service
	SessionID string   // the session (sid)
	Methods   []string // how the user proved who they are: "otp" or "idirect"
	Audience  []string
	TokenID   string
	IssuedAt  time.Time
	ExpiresAt time.Time
}

type ctxKey struct{}

// FromContext returns the claims the middleware verified for this request.
func FromContext(ctx context.Context) (*Claims, bool) {
	c, ok := ctx.Value(ctxKey{}).(*Claims)
	return c, ok
}

// UserID returns the signed-in user's id, or "" when the request is anonymous (Optional middleware).
func UserID(ctx context.Context) string {
	if c, ok := FromContext(ctx); ok {
		return c.Subject
	}
	return ""
}

// WithClaims returns a context carrying claims. It exists for tests of your own handlers; production code
// gets claims only from the middleware.
func WithClaims(ctx context.Context, c *Claims) context.Context {
	return context.WithValue(ctx, ctxKey{}, c)
}

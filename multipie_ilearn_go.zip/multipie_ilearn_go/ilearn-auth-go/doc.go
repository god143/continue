// Package ilearnauth lets a Go service accept the iLearn app's sign-in. It verifies the access tokens
// issued by the auth service, checks that the session has not been revoked, and hands the request the
// signed-in user. Everything else a service needs from auth lives in the sub-packages:
//
//	directory      look up users (names, pictures) and acknowledge account deletions
//	events         receive the signed user events (profile changed, deletion requested)
//	redisrevoker   the revocation check, against the auth service's Redis
//	authtest       an in-process fake of the auth service, for your own tests
//
// Minimal use:
//
//	auth, err := ilearnauth.New(ilearnauth.Config{
//		Issuer:   "https://api-ilearn.icicidirect.com/auth",
//		Audience: "ilearn",
//		Revoker:  redisrevoker.New(redisClient),
//	})
//	mux.Handle("/ilearn/v1/", auth.Require(learnRoutes))
//	// in a handler:
//	userID := ilearnauth.UserID(r.Context())
package ilearnauth

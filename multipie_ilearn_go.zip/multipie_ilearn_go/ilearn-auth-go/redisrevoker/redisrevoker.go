// Package redisrevoker checks session revocation against the auth service's Redis. Give your service a
// read-only Redis user that may run GET on keys starting with revoked_sid: and nothing else.
package redisrevoker

import (
	"context"
	"errors"

	"github.com/redis/go-redis/v9"
)

// keyPrefix is how the auth service names a revoked session. It is part of the contract with auth.
const keyPrefix = "revoked_sid:"

// Revoker satisfies ilearnauth.Revoker.
type Revoker struct{ c redis.Cmdable }

// New wraps a Redis client (a *redis.Client, or a cluster/ring client).
func New(c redis.Cmdable) *Revoker { return &Revoker{c: c} }

// Revoked reports whether the session was ended, and why. A Redis failure is an error, not "not revoked".
func (r *Revoker) Revoked(ctx context.Context, sessionID string) (string, bool, error) {
	reason, err := r.c.Get(ctx, keyPrefix+sessionID).Result()
	if errors.Is(err, redis.Nil) {
		return "", false, nil
	}
	if err != nil {
		return "", false, err
	}
	return reason, true, nil
}

package ilearnauth_test

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"ilearn-auth-go"
	"ilearn-auth-go/authtest"
)

const user = "0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d"

func setup(t *testing.T) (*authtest.Server, *ilearnauth.Auth) {
	t.Helper()
	fake := authtest.New(t)
	a, err := ilearnauth.New(ilearnauth.Config{Issuer: fake.Issuer(), Audience: "ilearn", Revoker: fake.Revoker()})
	if err != nil {
		t.Fatal(err)
	}
	return fake, a
}

func TestAGenuineTokenVerifiesAndCarriesTheUser(t *testing.T) {
	fake, a := setup(t)
	tok := fake.Token(user, authtest.Session("s1"), authtest.Methods("idirect"))
	c, err := a.Verify(context.Background(), tok)
	if err != nil {
		t.Fatal(err)
	}
	if c.Subject != user || c.SessionID != "s1" || len(c.Methods) != 1 || c.Methods[0] != "idirect" || c.ExpiresAt.Before(time.Now()) {
		t.Fatalf("%+v", c)
	}
}

func TestEveryKindOfBadTokenIsRefused(t *testing.T) {
	fake, a := setup(t)
	ctx := context.Background()
	good := fake.Token(user)
	parts := strings.Split(good, ".")
	cases := map[string]struct {
		token string
		want  error
	}{
		"empty":                {"", ilearnauth.ErrInvalid},
		"not a jwt":            {"abc", ilearnauth.ErrInvalid},
		"two parts":            {parts[0] + "." + parts[1], ilearnauth.ErrInvalid},
		"too long":             {strings.Repeat("a", 5000), ilearnauth.ErrInvalid},
		"tampered signature":   {fake.Token(user, authtest.TamperedSignature()), ilearnauth.ErrInvalid},
		"payload swapped":      {parts[0] + "." + strings.Split(fake.Token("someone-else"), ".")[1] + "." + parts[2], ilearnauth.ErrInvalid},
		"alg none":             {fake.Token(user, authtest.Algorithm("none")), ilearnauth.ErrInvalid},
		"alg HS256":            {fake.Token(user, authtest.Algorithm("HS256")), ilearnauth.ErrInvalid},
		"unknown key id":       {fake.Token(user, authtest.KeyID("nobody")), ilearnauth.ErrInvalid},
		"wrong issuer":         {fake.Token(user, authtest.Issuer("https://evil.example/auth")), ilearnauth.ErrInvalid},
		"wrong audience":       {fake.Token(user, authtest.Audience("markets", "social")), ilearnauth.ErrInvalid},
		"restricted session":   {fake.Token(user, authtest.Restricted("cancel_deletion")), ilearnauth.ErrInvalid},
		"expired":              {fake.Token(user, authtest.IssuedAt(time.Now().Add(-time.Hour))), ilearnauth.ErrExpired},
		"issued in the future": {fake.Token(user, authtest.IssuedAt(time.Now().Add(time.Hour))), ilearnauth.ErrInvalid},
	}
	for name, c := range cases {
		if _, err := a.Verify(ctx, c.token); !errors.Is(err, c.want) {
			t.Errorf("%s: %v, want %v", name, err, c.want)
		}
	}
	// Within the leeway an almost-expired token still works; just past it, it does not.
	if _, err := a.Verify(ctx, fake.Token(user, authtest.IssuedAt(time.Now().Add(-10*time.Minute-10*time.Second)))); err != nil {
		t.Errorf("a token 10 seconds past expiry should be inside the 30-second leeway: %v", err)
	}
	if _, err := a.Verify(ctx, fake.Token(user, authtest.IssuedAt(time.Now().Add(-10*time.Minute-40*time.Second)))); !errors.Is(err, ilearnauth.ErrExpired) {
		t.Errorf("40 seconds past expiry: %v", err)
	}
}

func TestNewRefusesMissingSettings(t *testing.T) {
	fake := authtest.New(t)
	for name, c := range map[string]ilearnauth.Config{
		"no issuer":      {Audience: "ilearn", Revoker: fake.Revoker()},
		"no audience":    {Issuer: fake.Issuer(), Revoker: fake.Revoker()},
		"no revoker":     {Issuer: fake.Issuer(), Audience: "ilearn"},
		"issuer no http": {Issuer: "api-ilearn.example", Audience: "ilearn", Revoker: fake.Revoker()},
	} {
		if _, err := ilearnauth.New(c); err == nil {
			t.Errorf("%s was accepted", name)
		}
	}
}

func call(h http.Handler, token string) *httptest.ResponseRecorder {
	req := httptest.NewRequest("GET", "/ilearn/v1/me", nil)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	return rec
}

func code(rec *httptest.ResponseRecorder) string {
	var b struct {
		Error struct {
			Code string `json:"code"`
		} `json:"error"`
	}
	_ = json.Unmarshal(rec.Body.Bytes(), &b)
	return b.Error.Code
}

func TestTheMiddlewareAnswersLikeTheAuthService(t *testing.T) {
	fake, a := setup(t)
	var seen string
	h := a.Require(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seen = ilearnauth.UserID(r.Context())
		w.WriteHeader(204)
	}))
	if rec := call(h, fake.Token(user)); rec.Code != 204 || seen != user {
		t.Fatalf("%d %q", rec.Code, seen)
	}
	for name, c := range map[string]struct {
		token  string
		status int
		code   string
	}{
		"no token":   {"", 401, "invalid_credentials"},
		"bad token":  {"junk", 401, "invalid_credentials"},
		"wrong aud":  {fake.Token(user, authtest.Audience("markets")), 401, "invalid_credentials"},
		"expired":    {fake.Token(user, authtest.IssuedAt(time.Now().Add(-time.Hour))), 401, "token_expired"},
		"restricted": {fake.Token(user, authtest.Restricted("cancel_deletion")), 401, "invalid_credentials"},
	} {
		rec := call(h, c.token)
		if rec.Code != c.status || code(rec) != c.code || rec.Header().Get("WWW-Authenticate") == "" {
			t.Errorf("%s: %d %s", name, rec.Code, code(rec))
		}
	}
	// Revocation: logout and a newer sign-in elsewhere are told apart, and take effect at once.
	tok := fake.Token(user, authtest.Session("s-logout"))
	if rec := call(h, tok); rec.Code != 204 {
		t.Fatal(rec.Code)
	}
	fake.Revoke("s-logout", "logout")
	if rec := call(h, tok); rec.Code != 401 || code(rec) != "token_revoked" {
		t.Errorf("after logout: %d %s", rec.Code, code(rec))
	}
	tok2 := fake.Token(user, authtest.Session("s-moved"))
	fake.Revoke("s-moved", "replaced")
	if rec := call(h, tok2); rec.Code != 401 || code(rec) != "session_replaced" {
		t.Errorf("after sign-in elsewhere: %d %s", rec.Code, code(rec))
	}
	// Fail closed: if revocation cannot be read the request is not let through.
	fake.FailRevocationChecks(true)
	if rec := call(h, fake.Token(user)); rec.Code != 503 || code(rec) != "unavailable" {
		t.Errorf("revocation list down: %d %s", rec.Code, code(rec))
	}
	fake.FailRevocationChecks(false)
}

func TestOptionalLetsAnonymousThroughButNeverABadToken(t *testing.T) {
	fake, a := setup(t)
	var who string
	h := a.Optional(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { who = ilearnauth.UserID(r.Context()); w.WriteHeader(204) }))
	if rec := call(h, ""); rec.Code != 204 || who != "" {
		t.Fatalf("anonymous: %d %q", rec.Code, who)
	}
	if rec := call(h, fake.Token(user)); rec.Code != 204 || who != user {
		t.Fatalf("signed in: %d %q", rec.Code, who)
	}
	if rec := call(h, "junk"); rec.Code != 401 {
		t.Fatalf("a bad token was ignored: %d", rec.Code)
	}
	req := httptest.NewRequest("GET", "/", nil)
	req.Header.Set("Authorization", "Basic abc")
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != 401 {
		t.Errorf("a non-bearer Authorization header was ignored: %d", rec.Code)
	}
}

// Keys: fetched once and cached; a rotation is picked up for a new key id but no more often than every
// 30 seconds; an outage does not stop tokens signed with a key already known.
func TestKeysAreCachedRotatedAndSurviveAnOutage(t *testing.T) {
	fake := authtest.New(t)
	var fetches atomic.Int32
	counting := http.NewServeMux()
	counting.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fetches.Add(1)
		resp, err := http.Get(fake.URL() + r.URL.Path)
		if err != nil || resp.StatusCode != 200 {
			http.Error(w, "down", 503)
			return
		}
		defer resp.Body.Close()
		w.Header().Set("Content-Type", "application/json")
		buf := make([]byte, 1<<16)
		n, _ := resp.Body.Read(buf)
		_, _ = w.Write(buf[:n])
	})
	proxy := httptest.NewServer(counting)
	defer proxy.Close()
	clock := time.Now()
	a, err := ilearnauth.New(ilearnauth.Config{Issuer: fake.Issuer(), JWKSURL: proxy.URL + "/auth/v1/jwks.json", Audience: "ilearn", Revoker: fake.Revoker(), Now: func() time.Time { return clock }})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	for i := 0; i < 5; i++ {
		if _, err := a.Verify(ctx, fake.Token(user)); err != nil {
			t.Fatal(err)
		}
	}
	if fetches.Load() != 1 {
		t.Fatalf("%d fetches for five tokens", fetches.Load())
	}
	fake.RotateKey()
	if _, err := a.Verify(ctx, fake.Token(user)); err == nil {
		t.Fatal("a new key id was accepted within 30 seconds of the last fetch: the refetch limit is not working")
	}
	clock = clock.Add(31 * time.Second)
	if _, err := a.Verify(ctx, fake.Token(user)); err != nil {
		t.Fatalf("after the refetch window the rotated key should be known: %v", err)
	}
	// A flood of unknown key ids causes at most one fetch per 30 seconds.
	before := fetches.Load()
	for i := 0; i < 50; i++ {
		_, _ = a.Verify(ctx, fake.Token(user, authtest.KeyID("random"+string(rune('a'+i%26)))))
	}
	if fetches.Load()-before > 1 {
		t.Errorf("%d fetches for a flood of unknown key ids", fetches.Load()-before)
	}
	// An outage after the cache expires: known keys keep working.
	clock = clock.Add(11 * time.Minute)
	fake.SetJWKSDown(true)
	if _, err := a.Verify(ctx, fake.Token(user, authtest.IssuedAt(clock))); err != nil {
		t.Errorf("during an outage a known key should still verify: %v", err)
	}
}

func TestWarmFailsFastWhenAuthIsUnreachable(t *testing.T) {
	fake, a := setup(t)
	if err := a.Warm(context.Background()); err != nil {
		t.Fatal(err)
	}
	fake.SetJWKSDown(true)
	a2, _ := ilearnauth.New(ilearnauth.Config{Issuer: fake.Issuer(), Audience: "ilearn", Revoker: fake.Revoker()})
	if err := a2.Warm(context.Background()); err == nil {
		t.Fatal("Warm did not notice that the keys cannot be fetched")
	}
}

func TestCheckServesWebsocketsAndQueues(t *testing.T) {
	fake, a := setup(t)
	tok := fake.Token(user, authtest.Session("ws1"))
	if _, err := a.Check(context.Background(), tok); err != nil {
		t.Fatal(err)
	}
	fake.Revoke("ws1", "replaced")
	if _, err := a.Check(context.Background(), tok); !errors.Is(err, ilearnauth.ErrReplaced) {
		t.Fatalf("%v", err)
	}
	fake.Revoke("ws2", "logout")
	if _, err := a.Check(context.Background(), fake.Token(user, authtest.Session("ws2"))); !errors.Is(err, ilearnauth.ErrRevoked) {
		t.Fatalf("%v", err)
	}
}

func TestUserIDIsEmptyForAnonymousContexts(t *testing.T) {
	if ilearnauth.UserID(context.Background()) != "" {
		t.Error("an anonymous context has a user")
	}
	ctx := ilearnauth.WithClaims(context.Background(), &ilearnauth.Claims{Subject: user})
	if ilearnauth.UserID(ctx) != user {
		t.Error("WithClaims does not carry the user")
	}
}

package usermap_test

import (
	"context"
	"strings"
	"sync"
	"sync/atomic"
	"testing"

	"ilearn-auth-go/usermap"
)

type store struct {
	mu      sync.Mutex
	ids     map[string]string
	finds   atomic.Int32
	creates atomic.Int32
}

func (s *store) Find(_ context.Context, sub string) (string, bool, error) {
	s.finds.Add(1)
	s.mu.Lock()
	defer s.mu.Unlock()
	id, ok := s.ids[sub]
	return id, ok, nil
}

func (s *store) Create(_ context.Context, sub string) (string, error) {
	s.creates.Add(1)
	s.mu.Lock()
	defer s.mu.Unlock()
	if id, ok := s.ids[sub]; ok { // idempotent, as the interface demands
		return id, nil
	}
	id := "local-" + sub[:4]
	s.ids[sub] = id
	return id, nil
}

func TestResolveFindsOrCreatesOnceAndRemembers(t *testing.T) {
	st := &store{ids: map[string]string{"aaaa0000-0000-7000-8000-000000000001": "existing"}}
	r := &usermap.Resolver{Store: st}
	ctx := context.Background()
	if id, err := r.Resolve(ctx, "aaaa0000-0000-7000-8000-000000000001"); err != nil || id != "existing" {
		t.Fatalf("%q %v", id, err)
	}
	for i := 0; i < 3; i++ {
		if id, _ := r.Resolve(ctx, "bbbb0000-0000-7000-8000-000000000002"); id != "local-bbbb" {
			t.Fatalf("%q", id)
		}
	}
	if st.creates.Load() != 1 || st.finds.Load() != 2 {
		t.Errorf("%d creates, %d finds: the mapping never changes and must be remembered", st.creates.Load(), st.finds.Load())
	}
	if _, err := r.Resolve(ctx, ""); err == nil {
		t.Error("an empty sub was accepted")
	}
}

func TestResolveStaysBounded(t *testing.T) {
	st := &store{ids: map[string]string{}}
	r := &usermap.Resolver{Store: st, Max: 3}
	for i := 0; i < 20; i++ {
		sub := strings.Repeat("c", 4) + "0000-0000-7000-8000-" + strings.Repeat("0", 11) + string(rune('a'+i))
		if _, err := r.Resolve(context.Background(), sub); err != nil {
			t.Fatal(err)
		}
	}
}

func TestLegacyExportIsReadStrictly(t *testing.T) {
	good := "source,source_id,sub\nmultipie,123,0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d\nilearn,u-9,0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d\n"
	var rows []usermap.LegacyRow
	if err := usermap.ReadLegacyCSV(strings.NewReader(good), func(r usermap.LegacyRow) error { rows = append(rows, r); return nil }); err != nil || len(rows) != 2 || rows[1].Source != "ilearn" || rows[0].SourceID != "123" {
		t.Fatalf("%+v %v", rows, err)
	}
	for name, bad := range map[string]string{
		"wrong header":   "a,b,c\nmultipie,1,0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d\n",
		"unknown source": "source,source_id,sub\nfacebook,1,0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d\n",
		"empty id":       "source,source_id,sub\nmultipie,,0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d\n",
		"short sub":      "source,source_id,sub\nmultipie,1,abc\n",
		"extra column":   "source,source_id,sub\nmultipie,1,0192e8a0-7c3b-7e5a-9b1f-3d2c4a5b6c7d,x\n",
		"empty file":     "",
	} {
		if err := usermap.ReadLegacyCSV(strings.NewReader(bad), func(usermap.LegacyRow) error { return nil }); err == nil {
			t.Errorf("%s was accepted", name)
		}
	}
}

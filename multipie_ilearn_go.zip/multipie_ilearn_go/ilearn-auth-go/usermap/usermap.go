// Package usermap maps the auth service's user id (sub, a UUID that is the same in every service) to your
// service's own user id, and reads the export that re-keys the users you had before the new auth service.
package usermap

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"strings"
	"sync"
)

// Store is your service's table of users.
type Store interface {
	// Find returns the local id for a sub, if there is one.
	Find(ctx context.Context, sub string) (localID string, ok bool, err error)
	// Create makes the local user for a sub and returns its id. It must be idempotent: if two requests race,
	// both get the same id (use INSERT ... ON CONFLICT DO NOTHING / ON DUPLICATE KEY, then read back).
	Create(ctx context.Context, sub string) (localID string, err error)
}

// Resolver finds or creates the local user for a sub. A mapping never changes, so it is remembered for good
// (up to Max entries).
type Resolver struct {
	Store Store
	Max   int // default 100000

	mu    sync.Mutex
	cache map[string]string
}

// Resolve returns the local id for a sub, creating the user on first sight.
func (r *Resolver) Resolve(ctx context.Context, sub string) (string, error) {
	if sub == "" {
		return "", errors.New("usermap: empty sub")
	}
	r.mu.Lock()
	id, ok := r.cache[sub]
	r.mu.Unlock()
	if ok {
		return id, nil
	}
	id, ok, err := r.Store.Find(ctx, sub)
	if err != nil {
		return "", err
	}
	if !ok {
		if id, err = r.Store.Create(ctx, sub); err != nil {
			return "", err
		}
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.cache == nil {
		r.cache = map[string]string{}
	}
	if max := r.Max; len(r.cache) >= max && max > 0 || len(r.cache) >= 100000 && r.Max <= 0 {
		for k := range r.cache { // stay bounded
			delete(r.cache, k)
			break
		}
	}
	r.cache[sub] = id
	return id, nil
}

// LegacyRow is one line of the legacy export: a user of an earlier system and the sub they now have.
type LegacyRow struct {
	Source   string // "multipie" or "ilearn"
	SourceID string // the id in that system
	Sub      string // the new id
}

// ReadLegacyCSV reads the export file the auth team sends (a CSV with the header source,source_id,sub) and
// calls fn for each row, stopping at the first error. Several legacy ids can map to one sub (the same person
// in two systems).
func ReadLegacyCSV(r io.Reader, fn func(LegacyRow) error) error {
	cr := csv.NewReader(r)
	cr.FieldsPerRecord = 3
	head, err := cr.Read()
	if err != nil {
		return fmt.Errorf("usermap: reading the header: %w", err)
	}
	if strings.Join(head, ",") != "source,source_id,sub" {
		return errors.New("usermap: the header must be source,source_id,sub")
	}
	line := 1
	for {
		rec, err := cr.Read()
		if errors.Is(err, io.EOF) {
			return nil
		}
		line++
		if err != nil {
			return fmt.Errorf("usermap: line %d: %w", line, err)
		}
		row := LegacyRow{Source: rec[0], SourceID: rec[1], Sub: rec[2]}
		if (row.Source != "multipie" && row.Source != "ilearn") || row.SourceID == "" || len(row.Sub) != 36 {
			return fmt.Errorf("usermap: line %d: not a valid row", line)
		}
		if err := fn(row); err != nil {
			return fmt.Errorf("usermap: line %d: %w", line, err)
		}
	}
}

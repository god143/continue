package ilearnauth

import (
	"context"
	"crypto"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"strings"
	"time"
)

const maxTokenLen = 4096

// Config configures an Auth.
type Config struct {
	// Issuer is the auth service's public host plus /auth, for example https://api-ilearn.icicidirect.com/auth.
	// Tokens from any other issuer are refused.
	Issuer string
	// Audience is this module's name in the token's aud claim: "ilearn" for the learning service.
	Audience string
	// JWKSURL is where the public keys are. Default: Issuer + "/v1/jwks.json".
	JWKSURL string
	// Revoker checks that the session was not ended. Required: logout must take effect at once.
	Revoker Revoker
	// HTTPClient is used to fetch the keys. Default: a client with a 5 second timeout.
	HTTPClient *http.Client
	// Leeway tolerates clock differences between the services. Default 30 seconds.
	Leeway time.Duration
	// Logger receives debug lines about refused tokens (never the token). Default: discarded.
	Logger *slog.Logger
	// Now is the clock, for tests.
	Now func() time.Time
}

// Auth verifies tokens and protects handlers.
type Auth struct {
	cfg  Config
	keys *jwksCache
	log  *slog.Logger
}

// New validates the configuration. It makes no request; call Warm at startup to fail fast when the auth
// service cannot be reached.
func New(cfg Config) (*Auth, error) {
	switch {
	case !strings.HasPrefix(cfg.Issuer, "https://") && !strings.HasPrefix(cfg.Issuer, "http://"):
		return nil, errors.New("ilearnauth: Issuer must be the auth service's address, for example https://api-ilearn.icicidirect.com/auth")
	case cfg.Audience == "":
		return nil, errors.New("ilearnauth: Audience is required (\"ilearn\" for the learning service)")
	case cfg.Revoker == nil:
		return nil, errors.New("ilearnauth: Revoker is required: without it a logged-out session would keep working until its token expires")
	}
	cfg.Issuer = strings.TrimRight(cfg.Issuer, "/")
	if cfg.JWKSURL == "" {
		cfg.JWKSURL = cfg.Issuer + "/v1/jwks.json"
	}
	if cfg.HTTPClient == nil {
		cfg.HTTPClient = &http.Client{Timeout: 5 * time.Second}
	}
	if cfg.Leeway <= 0 {
		cfg.Leeway = 30 * time.Second
	}
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	log := cfg.Logger
	if log == nil {
		log = slog.New(slog.NewTextHandler(discard{}, nil))
	}
	return &Auth{cfg: cfg, log: log, keys: &jwksCache{url: cfg.JWKSURL, client: cfg.HTTPClient, ttl: 10 * time.Minute, minRefresh: 30 * time.Second, now: cfg.Now}}, nil
}

type discard struct{}

func (discard) Write(p []byte) (int, error) { return len(p), nil }

// Warm fetches the keys now, so a wrong address or an unreachable auth service stops the start of your
// service and not its first request.
func (a *Auth) Warm(ctx context.Context) error {
	a.keys.mu.Lock()
	defer a.keys.mu.Unlock()
	a.keys.lastTry = a.cfg.Now()
	if err := a.keys.fetch(ctx, a.cfg.Now()); err != nil {
		return fmt.Errorf("ilearnauth: fetching the signing keys from %s: %w", a.cfg.JWKSURL, err)
	}
	return nil
}

type header struct {
	Alg string `json:"alg"`
	Kid string `json:"kid"`
}

type numericDate float64

func (n numericDate) time() time.Time { return time.Unix(int64(n), 0) }

type audience []string

func (a *audience) UnmarshalJSON(b []byte) error {
	var one string
	if json.Unmarshal(b, &one) == nil {
		*a = audience{one}
		return nil
	}
	var many []string
	if err := json.Unmarshal(b, &many); err != nil {
		return err
	}
	*a = many
	return nil
}

type payload struct {
	Iss   string       `json:"iss"`
	Sub   string       `json:"sub"`
	Aud   audience     `json:"aud"`
	Exp   *numericDate `json:"exp"`
	Nbf   *numericDate `json:"nbf"`
	Iat   *numericDate `json:"iat"`
	Jti   string       `json:"jti"`
	Sid   string       `json:"sid"`
	AMR   []string     `json:"amr"`
	Scope string       `json:"scope"`
}

// Verify checks a token's signature, issuer, audience and times. It does not check revocation; the
// middleware does. Only RS256 is accepted, so a token cannot choose a weaker algorithm or "none". A token
// with a scope (the restricted session of a pending account deletion) is refused: it is meant for the auth
// service alone.
func (a *Auth) Verify(ctx context.Context, raw string) (*Claims, error) {
	if raw == "" || len(raw) > maxTokenLen {
		return nil, ErrInvalid
	}
	parts := strings.Split(raw, ".")
	if len(parts) != 3 {
		return nil, ErrInvalid
	}
	var h header
	if !decode(parts[0], &h) || h.Alg != "RS256" || h.Kid == "" {
		return nil, ErrInvalid
	}
	pub, err := a.keys.key(ctx, h.Kid)
	if err != nil {
		return nil, ErrInvalid
	}
	sig, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil {
		return nil, ErrInvalid
	}
	sum := sha256.Sum256([]byte(parts[0] + "." + parts[1]))
	if rsa.VerifyPKCS1v15(pub, crypto.SHA256, sum[:], sig) != nil {
		return nil, ErrInvalid
	}
	var p payload
	if !decode(parts[1], &p) {
		return nil, ErrInvalid
	}
	if p.Exp == nil || p.Iat == nil || p.Sub == "" || p.Sid == "" || p.Iss != a.cfg.Issuer || p.Scope != "" {
		return nil, ErrInvalid
	}
	okAud := false
	for _, x := range p.Aud {
		if x == a.cfg.Audience {
			okAud = true
		}
	}
	if !okAud {
		return nil, ErrInvalid
	}
	now := a.cfg.Now()
	if p.Nbf != nil && now.Add(a.cfg.Leeway).Before(p.Nbf.time()) {
		return nil, ErrInvalid
	}
	if now.Add(a.cfg.Leeway).Before(p.Iat.time()) {
		return nil, ErrInvalid
	}
	if !now.Before(p.Exp.time().Add(a.cfg.Leeway)) {
		return nil, ErrExpired
	}
	return &Claims{
		Subject: p.Sub, SessionID: p.Sid, Methods: p.AMR, Audience: []string(p.Aud), TokenID: p.Jti,
		IssuedAt: p.Iat.time(), ExpiresAt: p.Exp.time(),
	}, nil
}

func decode(seg string, v any) bool {
	b, err := base64.RawURLEncoding.DecodeString(seg)
	if err != nil {
		return false
	}
	return json.Unmarshal(b, v) == nil
}

// Check is Verify plus the revocation check, for code that does not go through the middleware (a websocket,
// a queue consumer). It returns ErrRevoked or ErrReplaced for an ended session, and a plain error when the
// revocation list cannot be read: treat that as "try again", never as "allowed".
func (a *Auth) Check(ctx context.Context, raw string) (*Claims, error) {
	c, err := a.Verify(ctx, raw)
	if err != nil {
		return nil, err
	}
	reason, revoked, err := a.cfg.Revoker.Revoked(ctx, c.SessionID)
	if err != nil {
		return nil, fmt.Errorf("ilearnauth: cannot check revocation: %w", err)
	}
	if revoked {
		if reason == "replaced" {
			return nil, ErrReplaced
		}
		return nil, ErrRevoked
	}
	return c, nil
}

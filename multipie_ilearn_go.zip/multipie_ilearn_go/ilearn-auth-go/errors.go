package ilearnauth

import "errors"

var (
	// ErrExpired means the token is genuine but has expired; the app answers it by refreshing.
	ErrExpired = errors.New("ilearnauth: token expired")
	// ErrInvalid covers every other failure. It never says which check failed.
	ErrInvalid = errors.New("ilearnauth: token invalid")
	// ErrRevoked means the session was ended (logout, or a newer sign-in on another device).
	ErrRevoked = errors.New("ilearnauth: session revoked")
	// ErrReplaced is ErrRevoked for the case where the user signed in somewhere else.
	ErrReplaced = errors.New("ilearnauth: session replaced")
)

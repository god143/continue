// Package directory is the client for the auth service's internal API: look up users (their name, picture
// and bio, for comments, quizzes and certificates) and acknowledge account deletions. The calls go to the
// internal listener, which is on a private address and uses a service client you register with
// `authadmin client add`.
package directory

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	// ErrNotFound means there is no such user (or the user has been deleted).
	ErrNotFound = errors.New("directory: no such user")
	// ErrForbidden means the client lacks the scope for the call.
	ErrForbidden = errors.New("directory: the service client may not do that")
	// ErrInvalidClient means the client id or secret was refused. It is not retried: repeated wrong
	// secrets are throttled by the auth service. Check the registration with authadmin.
	ErrInvalidClient = errors.New("directory: the service client was refused")
)

// User is a person as the auth service knows them. Contact fields are set only when the service client has
// the users:read_contact scope.
type User struct {
	Sub         string    `json:"sub"`
	Username    string    `json:"username"`
	DisplayName string    `json:"display_name"`
	Bio         string    `json:"bio"`
	AvatarURL   string    `json:"avatar_url"`
	CoverURL    string    `json:"cover_url"`
	Status      string    `json:"status"`
	CreatedAt   time.Time `json:"created_at"`

	Mobile        *string `json:"mobile,omitempty"`
	Email         *string `json:"email,omitempty"`
	EmailVerified *bool   `json:"email_verified,omitempty"`
}

// Config configures a Client.
type Config struct {
	// BaseURL is the internal listener, for example https://10.1.2.3:8081. https is required unless
	// AllowPlaintext is set (the auth service allows a plaintext internal listener only by explicit choice).
	BaseURL        string
	AllowPlaintext bool
	ClientID       string // the id given to `authadmin client add`
	ClientSecret   string // printed once by `authadmin client add`; keep it in your secret store
	// Audience of the service token. Default "auth-internal".
	Audience string
	// HTTPClient is used for every call. Give it a transport that trusts the internal CA. Default: 5 s timeout.
	HTTPClient *http.Client
	// CacheTTL is how long a user is remembered. Default 60 s; 0 keeps the default, a negative value turns the
	// cache off. A profile change reaches you by event (package events); the cache only bounds the staleness
	// when you do not subscribe.
	CacheTTL time.Duration
	// CacheSize is the most users remembered. Default 10000.
	CacheSize int
	Now       func() time.Time
}

// Client talks to the internal API. It is safe for concurrent use.
type Client struct {
	cfg  Config
	base string

	mu       sync.Mutex
	token    string
	tokenExp time.Time
	cache    map[string]cached
}

type cached struct {
	u       *User // nil caches "not found" briefly
	expires time.Time
}

// New validates the configuration. It makes no request.
func New(cfg Config) (*Client, error) {
	u, err := url.Parse(cfg.BaseURL)
	if err != nil || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return nil, errors.New("directory: BaseURL must be the internal listener's address")
	}
	if u.Scheme != "https" && !(u.Scheme == "http" && cfg.AllowPlaintext) {
		return nil, errors.New("directory: BaseURL must be https (set AllowPlaintext only where the auth service itself runs the internal listener without TLS)")
	}
	if cfg.ClientID == "" || cfg.ClientSecret == "" {
		return nil, errors.New("directory: ClientID and ClientSecret are required")
	}
	if cfg.Audience == "" {
		cfg.Audience = "auth-internal"
	}
	if cfg.HTTPClient == nil {
		cfg.HTTPClient = &http.Client{Timeout: 5 * time.Second}
	}
	if cfg.CacheTTL == 0 {
		cfg.CacheTTL = 60 * time.Second
	}
	if cfg.CacheSize <= 0 {
		cfg.CacheSize = 10000
	}
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	return &Client{cfg: cfg, base: strings.TrimRight(cfg.BaseURL, "/"), cache: map[string]cached{}}, nil
}

// Get returns one user, or ErrNotFound.
func (c *Client) Get(ctx context.Context, sub string) (*User, error) {
	if u, hit := c.fromCache(sub); hit {
		if u == nil {
			return nil, ErrNotFound
		}
		return u, nil
	}
	var u User
	status, err := c.call(ctx, http.MethodGet, "/internal/v1/users/"+url.PathEscape(sub), nil, &u)
	switch {
	case status == http.StatusNotFound:
		c.put(sub, nil)
		return nil, ErrNotFound
	case err != nil:
		return nil, err
	}
	c.put(sub, &u)
	return &u, nil
}

// BatchGet returns the users that exist, keyed by sub; an id that is unknown or deleted is simply absent.
// Any number of ids may be given: they are fetched 100 at a time, and only the ones not cached are asked for.
func (c *Client) BatchGet(ctx context.Context, subs []string) (map[string]*User, error) {
	out := make(map[string]*User, len(subs))
	var missing []string
	seen := map[string]bool{}
	for _, s := range subs {
		if seen[s] {
			continue
		}
		seen[s] = true
		if u, hit := c.fromCache(s); hit {
			if u != nil {
				out[s] = u
			}
			continue
		}
		missing = append(missing, s)
	}
	for len(missing) > 0 {
		n := min(100, len(missing))
		chunk := missing[:n]
		missing = missing[n:]
		var resp struct {
			Users []*User `json:"users"`
		}
		if _, err := c.call(ctx, http.MethodPost, "/internal/v1/users:batchGet", map[string]any{"subs": chunk}, &resp); err != nil {
			return nil, err
		}
		found := map[string]bool{}
		for _, u := range resp.Users {
			out[u.Sub] = u
			found[u.Sub] = true
			c.put(u.Sub, u)
		}
		for _, s := range chunk {
			if !found[s] {
				c.put(s, nil)
			}
		}
	}
	return out, nil
}

// Forget drops a user from the cache; call it when an event says the profile changed.
func (c *Client) Forget(sub string) {
	c.mu.Lock()
	delete(c.cache, sub)
	c.mu.Unlock()
}

// AckStatus is the outcome of erasing a user's data in your service.
type AckStatus string

const (
	AckCompleted AckStatus = "completed"
	AckFailed    AckStatus = "failed"
)

// AckDeletion tells the auth service that this service has (or has failed to) erase a user's data. requestID
// is the id in the user.deletion_requested event; service must be your client id. counts is optional, for the
// audit trail (for example {"progress": 41, "certificates": 2}); never put personal data in it.
func (c *Client) AckDeletion(ctx context.Context, requestID string, status AckStatus, counts map[string]int) error {
	body := map[string]any{"request_id": requestID, "service": c.cfg.ClientID, "status": string(status), "counts": counts}
	st, err := c.call(ctx, http.MethodPost, "/internal/v1/deletion-acks", body, nil)
	if st == http.StatusNoContent {
		return nil
	}
	return err
}

func (c *Client) fromCache(sub string) (*User, bool) {
	if c.cfg.CacheTTL < 0 {
		return nil, false
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	e, ok := c.cache[sub]
	if !ok || !c.cfg.Now().Before(e.expires) {
		delete(c.cache, sub)
		return nil, false
	}
	return e.u, true
}

func (c *Client) put(sub string, u *User) {
	if c.cfg.CacheTTL < 0 {
		return
	}
	ttl := c.cfg.CacheTTL
	if u == nil && ttl > 10*time.Second {
		ttl = 10 * time.Second // a user who does not exist yet may be created a moment later
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if len(c.cache) >= c.cfg.CacheSize {
		now := c.cfg.Now()
		for k, e := range c.cache { // drop what has expired, then anything, to stay bounded
			if !now.Before(e.expires) {
				delete(c.cache, k)
			}
		}
		for k := range c.cache {
			if len(c.cache) < c.cfg.CacheSize {
				break
			}
			delete(c.cache, k)
		}
	}
	c.cache[sub] = cached{u, c.cfg.Now().Add(ttl)}
}

// APIError is an unexpected answer from the auth service.
type APIError struct {
	Status int
	Code   string
}

func (e *APIError) Error() string {
	return fmt.Sprintf("directory: auth answered %d %s", e.Status, e.Code)
}

// call makes an authenticated request. It refreshes the service token once if the service says it expired,
// and retries a 429 or 5xx on a GET (or a safe POST) twice with a short wait.
func (c *Client) call(ctx context.Context, method, path string, in, out any) (int, error) {
	var payload []byte
	if in != nil {
		var err error
		if payload, err = json.Marshal(in); err != nil {
			return 0, err
		}
	}
	refreshed := false
	var lastStatus int
	for attempt := 0; attempt < 3; attempt++ {
		tok, err := c.serviceToken(ctx, !refreshed && attempt > 0 && lastStatus == http.StatusUnauthorized)
		if err != nil {
			return 0, err
		}
		req, err := http.NewRequestWithContext(ctx, method, c.base+path, bytes.NewReader(payload))
		if err != nil {
			return 0, err
		}
		req.Header.Set("Authorization", "Bearer "+tok)
		if payload != nil {
			req.Header.Set("Content-Type", "application/json")
		}
		resp, err := c.cfg.HTTPClient.Do(req)
		if err != nil {
			if attempt == 2 || ctx.Err() != nil {
				return 0, fmt.Errorf("directory: %w", err)
			}
			sleep(ctx, backoff(attempt, ""))
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		resp.Body.Close()
		lastStatus = resp.StatusCode
		switch {
		case resp.StatusCode == http.StatusUnauthorized && !refreshed:
			refreshed = true // the service token may have been revoked or expired early; get a new one once
			c.dropToken()
			continue
		case resp.StatusCode == http.StatusTooManyRequests || resp.StatusCode >= 500:
			if attempt == 2 {
				return resp.StatusCode, &APIError{resp.StatusCode, errorCode(body)}
			}
			sleep(ctx, backoff(attempt, resp.Header.Get("Retry-After")))
			continue
		case resp.StatusCode == http.StatusForbidden:
			return resp.StatusCode, ErrForbidden
		case resp.StatusCode >= 400:
			return resp.StatusCode, &APIError{resp.StatusCode, errorCode(body)}
		}
		if out != nil && len(body) > 0 {
			if err := json.Unmarshal(body, out); err != nil {
				return resp.StatusCode, fmt.Errorf("directory: unreadable answer: %w", err)
			}
		}
		return resp.StatusCode, nil
	}
	return lastStatus, &APIError{lastStatus, ""}
}

func errorCode(body []byte) string {
	var e struct {
		Error struct {
			Code string `json:"code"`
		} `json:"error"`
	}
	_ = json.Unmarshal(body, &e)
	return e.Error.Code
}

func backoff(attempt int, retryAfter string) time.Duration {
	if n, err := strconv.Atoi(retryAfter); err == nil && n > 0 && n <= 10 {
		return time.Duration(n) * time.Second
	}
	return time.Duration(200*(attempt+1)) * time.Millisecond
}

func sleep(ctx context.Context, d time.Duration) {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
	case <-t.C:
	}
}

func (c *Client) dropToken() {
	c.mu.Lock()
	c.token = ""
	c.mu.Unlock()
}

// serviceToken returns a valid service token, fetching one when none is held or it is within 30 seconds of
// expiring. Concurrent callers share one fetch (the mutex is held across it).
func (c *Client) serviceToken(ctx context.Context, force bool) (string, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if !force && c.token != "" && c.cfg.Now().Add(30*time.Second).Before(c.tokenExp) {
		return c.token, nil
	}
	form := url.Values{"grant_type": {"client_credentials"}, "client_id": {c.cfg.ClientID}, "client_secret": {c.cfg.ClientSecret}, "audience": {c.cfg.Audience}}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.base+"/internal/v1/token", strings.NewReader(form.Encode()))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := c.cfg.HTTPClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("directory: fetching a service token: %w", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<16))
	switch {
	case resp.StatusCode == http.StatusUnauthorized:
		return "", ErrInvalidClient
	case resp.StatusCode != http.StatusOK:
		return "", &APIError{resp.StatusCode, errorCode(body)}
	}
	var t struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int    `json:"expires_in"`
	}
	if err := json.Unmarshal(body, &t); err != nil || t.AccessToken == "" || t.ExpiresIn <= 0 {
		return "", errors.New("directory: unreadable token answer")
	}
	c.token, c.tokenExp = t.AccessToken, c.cfg.Now().Add(time.Duration(t.ExpiresIn)*time.Second)
	return c.token, nil
}

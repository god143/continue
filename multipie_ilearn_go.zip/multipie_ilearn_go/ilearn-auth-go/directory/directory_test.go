package directory_test

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strconv"
	"sync/atomic"
	"testing"
	"time"

	"ilearn-auth-go/authtest"
	"ilearn-auth-go/directory"
)

func setup(t *testing.T, scopes ...string) (*authtest.Server, *directory.Client) {
	t.Helper()
	fake := authtest.New(t)
	fake.AddClient("ilearn", "s3cret", scopes...)
	c, err := directory.New(directory.Config{BaseURL: fake.URL(), AllowPlaintext: true, ClientID: "ilearn", ClientSecret: "s3cret"})
	if err != nil {
		t.Fatal(err)
	}
	return fake, c
}

func sub(i int) string { return "00000000-0000-7000-8000-" + pad(i) }
func pad(i int) string {
	s := strconv.Itoa(i)
	for len(s) < 12 {
		s = "0" + s
	}
	return s
}

func TestGetReturnsTheUserWithoutContactDetailsUnlessAllowed(t *testing.T) {
	fake, c := setup(t, "users:read")
	mobile, email, verified := "+919876543210", "a@example.com", true
	fake.AddUser(directory.User{Sub: sub(1), Username: "mayank", DisplayName: "Mayank", Bio: "b", Mobile: &mobile, Email: &email, EmailVerified: &verified})
	u, err := c.Get(context.Background(), sub(1))
	if err != nil || u.DisplayName != "Mayank" || u.Username != "mayank" || u.Status != "active" {
		t.Fatalf("%+v %v", u, err)
	}
	if u.Mobile != nil || u.Email != nil {
		t.Fatalf("contact details leaked to a client without users:read_contact: %+v", u)
	}
	fake2, c2 := setup(t, "users:read_contact")
	fake2.AddUser(directory.User{Sub: sub(1), DisplayName: "M", Mobile: &mobile, Email: &email, EmailVerified: &verified})
	u2, err := c2.Get(context.Background(), sub(1))
	if err != nil || u2.Mobile == nil || *u2.Mobile != mobile || u2.EmailVerified == nil || !*u2.EmailVerified {
		t.Fatalf("%+v %v", u2, err)
	}
}

func TestAnUnknownUserIsNotFoundAndAClientWithoutAScopeIsForbidden(t *testing.T) {
	_, c := setup(t, "users:read")
	if _, err := c.Get(context.Background(), sub(9)); !errors.Is(err, directory.ErrNotFound) {
		t.Errorf("%v", err)
	}
	_, none := setup(t, "deletion:ack")
	if _, err := none.Get(context.Background(), sub(1)); !errors.Is(err, directory.ErrForbidden) {
		t.Errorf("%v", err)
	}
}

func TestTheServiceTokenIsFetchedOnceAndReusedAndRefreshedWhenItExpires(t *testing.T) {
	fake := authtest.New(t)
	fake.AddClient("ilearn", "s3cret", "users:read")
	fake.AddUser(directory.User{Sub: sub(1), DisplayName: "A"})
	var tokens atomic.Int32
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/internal/v1/token" {
			tokens.Add(1)
		}
		fake.ServeInternal(w, r)
	}))
	defer proxy.Close()
	clock := time.Now()
	c, _ := directory.New(directory.Config{BaseURL: proxy.URL, AllowPlaintext: true, ClientID: "ilearn", ClientSecret: "s3cret", CacheTTL: -1, Now: func() time.Time { return clock }})
	for i := 0; i < 5; i++ {
		if _, err := c.Get(context.Background(), sub(1)); err != nil {
			t.Fatal(err)
		}
	}
	if tokens.Load() != 1 {
		t.Fatalf("%d token requests for five calls", tokens.Load())
	}
	clock = clock.Add(280 * time.Second) // inside the last 30 seconds of a 300-second token
	if _, err := c.Get(context.Background(), sub(1)); err != nil || tokens.Load() != 2 {
		t.Fatalf("the token should be renewed before it expires: %d %v", tokens.Load(), err)
	}
}

func TestAWrongSecretIsReportedOnceAndNotRetried(t *testing.T) {
	fake := authtest.New(t)
	fake.AddClient("ilearn", "right", "users:read")
	var tokens atomic.Int32
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/internal/v1/token" {
			tokens.Add(1)
		}
		fake.ServeInternal(w, r)
	}))
	defer proxy.Close()
	c, _ := directory.New(directory.Config{BaseURL: proxy.URL, AllowPlaintext: true, ClientID: "ilearn", ClientSecret: "wrong"})
	if _, err := c.Get(context.Background(), sub(1)); !errors.Is(err, directory.ErrInvalidClient) {
		t.Fatalf("%v", err)
	}
	if tokens.Load() != 1 {
		t.Errorf("%d attempts with a wrong secret: guessing is throttled by auth and must not be repeated", tokens.Load())
	}
}

func TestUsersAreCachedAndAMissIsRememberedBriefly(t *testing.T) {
	fake, c := setup(t, "users:read")
	fake.AddUser(directory.User{Sub: sub(1), DisplayName: "Before"})
	ctx := context.Background()
	u, _ := c.Get(ctx, sub(1))
	fake.AddUser(directory.User{Sub: sub(1), DisplayName: "After"})
	if u2, _ := c.Get(ctx, sub(1)); u2.DisplayName != "Before" {
		t.Errorf("not cached: %q", u2.DisplayName)
	}
	c.Forget(sub(1))
	if u3, _ := c.Get(ctx, sub(1)); u3.DisplayName != "After" {
		t.Errorf("Forget did not drop the entry: %q", u3.DisplayName)
	}
	_ = u
	if _, err := c.Get(ctx, sub(2)); !errors.Is(err, directory.ErrNotFound) {
		t.Fatal(err)
	}
	fake.AddUser(directory.User{Sub: sub(2), DisplayName: "Late"})
	if _, err := c.Get(ctx, sub(2)); !errors.Is(err, directory.ErrNotFound) {
		t.Error("a miss should be remembered for a few seconds")
	}
}

func TestBatchGetChunksByHundredSkipsCachedAndOmitsTheMissing(t *testing.T) {
	fake := authtest.New(t)
	fake.AddClient("ilearn", "s3cret", "users:read")
	var batches atomic.Int32
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/internal/v1/users:batchGet" {
			batches.Add(1)
		}
		fake.ServeInternal(w, r)
	}))
	defer proxy.Close()
	c, _ := directory.New(directory.Config{BaseURL: proxy.URL, AllowPlaintext: true, ClientID: "ilearn", ClientSecret: "s3cret"})
	var subs []string
	for i := 1; i <= 250; i++ {
		subs = append(subs, sub(i))
		if i%10 != 0 { // every tenth does not exist
			fake.AddUser(directory.User{Sub: sub(i), DisplayName: "U" + strconv.Itoa(i)})
		}
	}
	subs = append(subs, subs[0], subs[1]) // duplicates are fine
	got, err := c.BatchGet(context.Background(), subs)
	if err != nil || len(got) != 225 || batches.Load() != 3 {
		t.Fatalf("%d users in %d calls, %v", len(got), batches.Load(), err)
	}
	if got[sub(10)] != nil || got[sub(11)].DisplayName != "U11" {
		t.Errorf("wrong content")
	}
	before := batches.Load()
	if _, err := c.BatchGet(context.Background(), subs); err != nil || batches.Load() != before {
		t.Errorf("a second identical batch called auth again: %d calls", batches.Load()-before)
	}
}

func TestATransientFailureIsRetriedButAPersistentOneIsReported(t *testing.T) {
	fake := authtest.New(t)
	fake.AddClient("ilearn", "s3cret", "users:read")
	fake.AddUser(directory.User{Sub: sub(1), DisplayName: "A"})
	var failures atomic.Int32
	failFirst := int32(1)
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/internal/v1/token" && failures.Load() < failFirst {
			failures.Add(1)
			w.Header().Set("Retry-After", "1")
			http.Error(w, "busy", http.StatusTooManyRequests)
			return
		}
		fake.ServeInternal(w, r)
	}))
	defer proxy.Close()
	c, _ := directory.New(directory.Config{BaseURL: proxy.URL, AllowPlaintext: true, ClientID: "ilearn", ClientSecret: "s3cret", CacheTTL: -1})
	if u, err := c.Get(context.Background(), sub(1)); err != nil || u.DisplayName != "A" {
		t.Fatalf("a single 429 should be retried: %v", err)
	}
	failures.Store(0)
	failFirst = 100
	var apiErr *directory.APIError
	if _, err := c.Get(context.Background(), sub(1)); !errors.As(err, &apiErr) || apiErr.Status != 429 {
		t.Fatalf("%v", err)
	}
}

func TestAckDeletionReportsForItselfOnly(t *testing.T) {
	fake, c := setup(t, "deletion:ack")
	if err := c.AckDeletion(context.Background(), "req-1", directory.AckCompleted, map[string]int{"progress": 4}); err != nil {
		t.Fatal(err)
	}
	acks := fake.Acks()
	if len(acks) != 1 || acks[0].Service != "ilearn" || acks[0].Status != "completed" || acks[0].Counts["progress"] != 4 {
		t.Fatalf("%+v", acks)
	}
	_, noScope := setup(t, "users:read")
	if err := noScope.AckDeletion(context.Background(), "req-1", directory.AckCompleted, nil); !errors.Is(err, directory.ErrForbidden) {
		t.Errorf("%v", err)
	}
}

func TestConfigIsChecked(t *testing.T) {
	for name, c := range map[string]directory.Config{
		"http without opt-in": {BaseURL: "http://10.0.0.1:8081", ClientID: "a", ClientSecret: "b"},
		"no secret":           {BaseURL: "https://10.0.0.1:8081", ClientID: "a"},
		"no id":               {BaseURL: "https://10.0.0.1:8081", ClientSecret: "b"},
		"credentials in url":  {BaseURL: "https://u:p@10.0.0.1:8081", ClientID: "a", ClientSecret: "b"},
		"no host":             {BaseURL: "https://", ClientID: "a", ClientSecret: "b"},
	} {
		if _, err := directory.New(c); err == nil {
			t.Errorf("%s was accepted", name)
		}
	}
}

func TestAMissIsRememberedForTenSecondsNotLonger(t *testing.T) {
	fake := authtest.New(t)
	fake.AddClient("ilearn", "s3cret", "users:read")
	clock := time.Now()
	c, _ := directory.New(directory.Config{BaseURL: fake.URL(), AllowPlaintext: true, ClientID: "ilearn", ClientSecret: "s3cret", CacheTTL: 5 * time.Minute, Now: func() time.Time { return clock }})
	if _, err := c.Get(context.Background(), sub(5)); !errors.Is(err, directory.ErrNotFound) {
		t.Fatal(err)
	}
	fake.AddUser(directory.User{Sub: sub(5), DisplayName: "New"})
	clock = clock.Add(11 * time.Second)
	if u, err := c.Get(context.Background(), sub(5)); err != nil || u.DisplayName != "New" {
		t.Fatalf("a user created after a miss should be found after 10 seconds, not 5 minutes: %v", err)
	}
}

package main

// import (
// 	"fmt"
// 	"multipie_ilearn_go/internal/config"
// 	"multipie_ilearn_go/internal/utils"
// )

// func main() {
// 	config.LoadEnv()
// 	envCfg := config.AppConfigs

// 	// fmt.Println("env: ", env)

// 	plaintext := utils.DecryptFile(config.AppConfigs.KeyPath, envCfg.KeyName, envCfg.SecretsFilePath, envCfg.AppEnv)
// 	fmt.Println(string(plaintext))
// }

package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"fmt"
	"io"
	"log"
	"multipie_ilearn_go/internal/config"
	"os"
	"strings"
	// "github.com/ProtonMail/go-crypto/openpgp"
)

func main() {
	config.LoadEnv()
	envCfg := config.AppConfigs

	// fmt.Println("env: ", env)

	EncryptFile(envCfg.KeyName, envCfg.SecretsFilePath, envCfg.AppEnv)
}

func EncryptFile(keyName, credPath, env string) {

	encUtilPath := "encryptionUtil"
	keyFile := fmt.Sprintf("%s/%s.key", encUtilPath, keyName)

	// Read the entire file content into a byte slice
	keyContent, err := os.ReadFile(keyFile)
	if err != nil {
		log.Fatalf("Failed to read the key file: %v", err)
	}

	key := []byte(strings.TrimSpace(string(keyContent)))

	plaintext, err := os.ReadFile(fmt.Sprintf("%s/%s.yaml", encUtilPath, env))
	if err != nil {
		log.Fatalf("failed to read yaml: %v", err)
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		log.Fatalf("failed to create cipher: %v", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		log.Fatalf("failed to create gcm: %v", err)
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		log.Fatalf("failed to generate nonce: %v", err)
	}

	ciphertext := gcm.Seal(nonce, nonce, plaintext, nil)

	err = os.WriteFile(fmt.Sprintf("%s/%s.yaml.enc", credPath, env), ciphertext, 0644)
	if err != nil {
		log.Fatalf("failed to write encrypted file: %v", err)
	}

	fmt.Println("Successfully created enc file at path: ", fmt.Sprintf("%s/%s.yaml.enc", credPath, env))
}

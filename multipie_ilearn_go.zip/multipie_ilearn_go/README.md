# multipie_ilearn_go

# TODO:
- Add Pagination in all fetch APIs. 
- ADD 404 status code for not found case
- remove pass_percentage from course table
## Database Schema
#### 1. **Role Table**
Role table.
```sql
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE, -- Name of the role (e.g., 'student', 'instructor', 'admin')
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
#### 2. **User Table**
User table.

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,  
    username VARCHAR(100) NOT NULL UNIQUE, 
    email VARCHAR(255) NOT NULL UNIQUE, 
    first_name VARCHAR(255) NOT NULL, 
    last_name VARCHAR(255) NOT NULL,  
    profile_picture_url VARCHAR(255),
    role int NOT NULL,
    status ENUM('active', 'suspended', 'deleted') DEFAULT 'active',
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
    deleted_at TIMESTAMP,  
    FOREIGN KEY (role) REFERENCES roles(id), 
    INDEX (username), 
    INDEX (email) 
);
```
#### 3. **Course Resources Table**
This table stores different resources associated with each course, such as articles, videos, and podcasts.

```sql
CREATE TABLE resources (
    id INT AUTO_INCREMENT PRIMARY KEY,  
    url VARCHAR(255),
    file_path VARCHAR(255),
    description TEXT,
    metadata JSON, -- will have details like length of video, podcast and article and other details
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (id)
);
```

#### 4. **Categories Table**
The **categories** table holds all the course categories, such as "Stocks", "Mathematics", etc.

```sql
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE, 
    description TEXT,
    parent int,
    type ENUM('Category', 'Sub-Category') DEFAULT 'Category',
    icon TEXT, -- icon url
    banner TEXT, -- banner url
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

#### 4. **Courses Table**
This table stores information about the courses. It includes the **category_id** and **difficulty level**, and it ensures courses are associated with a category.

```sql
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(255) NOT NULL,  
    shortname VARCHAR(100) NOT NULL UNIQUE,
    category_id INT NOT NULL,
    difficulty_level ENUM('Beginner', 'Intermediate', 'Advanced') DEFAULT 'Beginner',
    summary TEXT,
    startdate TIMESTAMP,
    enddate TIMESTAMP,
    format ENUM('Video', 'Article') DEFAULT 'Article',
    visible BOOLEAN DEFAULT TRUE,
    timecreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    timemodified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);
```

#### 5. **Course Modules Table**
Stores all activities or modules in a course, like assignments, quizzes, and discussions.

```sql
CREATE TABLE course_modules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL, 
    resource_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100), -- can be quiz, video, article, 
    instance_id INT, 
    completion_criteria JSON, -- if quiz, score>= 70, video: must_watch: true, article: must_read
    timecreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    timemodified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE
    INDEX (id, course_id),
    INDEX (id, resource_id) 
);
```

#### 6. **Enrollments Table**
This table manages user enrollments in courses, with information on the enrollment type, status, and dates.

```sql
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL, 
    course_id INT NOT NULL, 
    enrolment_type ENUM('self', 'external') DEFAULT 'self', -- it will be self/manual always
    status ENUM('active', 'suspended', 'completed') DEFAULT 'active',
    timecreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    timestart TIMESTAMP,
    timeend TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX (user_id, course_id),  -
    INDEX (course_id) 
);
```

#### 7. **Course Completions Table**
Tracks the completion status of a course or module for each user.

```sql
CREATE TABLE course_completions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL, 
    course_id INT NOT NULL,
    status ENUM('completed', 'in_progress', 'not_started') DEFAULT 'not_started',
    completion_date TIMESTAMP, -- if completion_date is null, course module
    progress_percentage DECIMAL(5,2) DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX (user_id, course_id) 
);
```
#### 8. **Module Completion**
Role table.
```sql
CREATE TABLE module_completion (
    id INT AUTO_INCREMENT PRIMARY KEY,            
    user_id INT NOT NULL,                         
    course_id INT NOT NULL,                        
    module_id INT NOT NULL,                        
    is_completed BOOLEAN DEFAULT FALSE,            
    progress_percentage DECIMAL(5,2) DEFAULT 0,    
    metadata JSON, -- watched time/read time/etc                       
    timecreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    timemodified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE CASCADE,
    INDEX (user_id),
    INDEX (course_id),
    INDEX (module_id)
);
```

#### 9. **Course Module Grades Table**
Tracks grades for each user and each module within a course.

```sql
CREATE TABLE course_module_grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,  
    module_id INT NOT NULL,
    grade DECIMAL(5,2), 
    grade_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE CASCADE,
    INDEX (user_id, module_id)  
);
```

## Quiz Module
1. quiz table
```sql
CREATE TABLE `quizzes` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,            -- Name of the quiz
    `course_id` INT DEFAULT NULL,            -- Can be null for independent quizzes
    `pass_percentage` INT DEFAULT 70,        -- Passing percentage (default is 70%)
    `num_questions` INT DEFAULT 0,           -- Number of questions in the quiz
    `certificate_id` INT DEFAULT NULL,       -- ID of the certificate (can be null)
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_course_id` (`course_id`),
    CONSTRAINT `fk_course_quiz` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_certificate_quiz` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`id`) ON DELETE SET NULL
);
```

2. questions table
```sql
CREATE TABLE `questions` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `quiz_id` INT NOT NULL,                    -- Foreign Key to quiz
    `question_text` TEXT NOT NULL,             -- The text for the question
    `question_type` ENUM('mcq', 'boolean', 'graph', 'image_based') NOT NULL,   -- Type of the question (mcq, boolean, etc.)
    `image_url` VARCHAR(255) DEFAULT NULL,     -- URL or path to the image (optional)
    `answers` JSON NOT NULL,                   -- Store answers as a JSON array, e.g. ["Paris", "Berlin", "Madrid", "London"]
    `correct_answer` TEXT NOT NULL,            -- Store the actual correct answer value (e.g., "Paris", "TRUE")
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_quiz_id` (`quiz_id`),
    CONSTRAINT `fk_quiz_question` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

```
4. User attempts (for next phase)
```sql
CREATE TABLE `quiz_attempts` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `user_id` INT NOT NULL,       -- Foreign key to the user table
    `quiz_id` INT NOT NULL,       -- Foreign key to the quiz
    `attempted_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `score` INT DEFAULT 0,
    `completed` BOOLEAN DEFAULT FALSE, -- Whether the quiz was completed or not
    `passed` BOOLEAN DEFAULT FALSE,    -- Whether the user passed the quiz
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_user_quiz_attempt` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
    CONSTRAINT `fk_quiz_quiz_attempt` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`)
);

```

5. To randomize the question and answer
```sql
SELECT * FROM `questions`
WHERE `quiz_id` = ?
ORDER BY RAND();  -- Randomizes the order of questions
```
```sql
SELECT * FROM `answers`
WHERE `question_id` = ?
ORDER BY RAND();  -- Randomizes the order of answers
```



USER_ACTIVITY_TRACKING

id
user_id
module_id
activity_status - (viewed, in_progress, completed)
    - viewed - for articels
    - in-progress, completed - video
activity_timestamp - 
additional_data > json
    - total video watch time


APIs:

- create activity
- update activity
    - courses all related modules or chapter is completed then course completed.
- get_activity
- get_course_activity - > for all the modules of course

USER
Id
username
firstname
lastname
mobile
email
status - (active, inactive)
role - (admin, user)
uid -> refer to user table in multipie auth
created_at
updated_at

APIs

create user - ADMIN - will be deprecated going forward
update user - ADMIN - will be deprecated going forward
get users - ADMIN
get user by ID - ADMIN
Lock User - update user status to inactive -ADMIN
Make Admin - update user role to admin -ADMIN

Middleware

role check weather its admin or not. if admin then admin route is allowed

Enrollments
ID
user_id - refer user table
course_id -refer course table
status - (started, in-progress, completed) -> default started
enrollment_date
created_at
updated_at

APIs

create enrollment - take user_id from context (userId, ok := ctx.Value("userId").(int64))
update enrollment - only status will updated
get enrollments


Quiz attempts
ID
user_id - refer user table
quiz_id - refer quiz table
attempt_number
score 
last_attempt_at 
status (pass, fail) dafult null
create_at
updated_at

APIs:

create_quiz_attempt
update_quiz_attempt
get_quiz_score -> return score of last attempt of the quiz
get_quiz_attempts -> return all the attempts of quiz with score and status


### Glossary - ADMIN level

1. key - value pairs

## APIs
1. create, update, delete, list (sort by key with pagination), search (each match first and then order by keys with pagination)
2. batch insert, batch update
3. list (sort by key), search (each match first and then order by keys) - will be in v1 directory
## Table:
id -
key
value
created_at
updated_at
combined index on key, value


### Tags - Admin

1. tags (key) to be stored in table

## APIs
1. create, update, delete, list (sort by key), search (filter by key/id)
2. batch insert, batch update

## Table
1. id
2. key
3. created_at
4. updated_at


### Bookmarks

1. User can add any content to bookmark
2. List down all the bookmarked content
3. content can be course, chapter, video, podcast, article, infographic
## APIs
1. create , delete, delete all
2. list (get api) - (content id, content type, name - (if content type == chapter, return name + (course name)) - with pagination

## Table
1. id
2. user id
3. content_id - foreign key (dont make foreign in table schema)
4. content_type - (course, chapter, video, podcast, article, infographic)
5. name 
6. created_at
7. updated_at
index on user_id, content_id




CREATE TABLE tag_mapping (
    `id` INT AUTO_INCREMENT PRIMARY KEY,  
    `tag_id` INT NOT NULL,     --Foreign key to the tags
    `model_id` INT NOT NULL,
    `model_type` varchar(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
     CONSTRAINT `fk__id_tag_mapping` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`),
);
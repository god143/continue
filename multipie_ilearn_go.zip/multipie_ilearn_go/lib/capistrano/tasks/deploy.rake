namespace :deploy do
    task :deploy_from_local_repo do
      set :repo_url,  "file:///tmp/.git"
      run_locally do
        execute "tar -zcvf /tmp/repo.tgz .git"
      end
      on roles(:all) do
        upload! '/tmp/repo.tgz', '/tmp/repo.tgz'
        execute 'tar -zxvf /tmp/repo.tgz -C /tmp'
      end
    end

    desc 'Run database migrations'
    task :run_migrations do
      database_url = fetch(:database_url)
      migrations_dir = fetch(:migrations_dir)
      db_driver = fetch(:db_driver)

      on roles(:migrator) do
        within release_path do
          begin
            execute("goose -dir #{release_path}/#{migrations_dir} #{db_driver} '#{database_url}' up -allow-missing")

          rescue SSHKit::Command::Failed => e
            info "Goose command failed, ignorring it. error: #{e.message}"
          end
        end
      end
    end

    desc 'Create go build'
    task :build do
      binary_name = fetch(:binary_name)
      main_package_path = fetch(:main_package_path)

      on roles(:app) do
        within release_path do
          execute :go, "build -o #{binary_name} #{main_package_path}"
        end
      end
    end

    desc 'Start application'
    task :server_restart do
      on roles(:app) do
        execute 'sudo service multipie_ilearn_go restart'
      end
    end

    desc 'deploy application'
    task :deploy do
      on roles(:app) do
        invoke 'deploy:run_migrations'
        invoke 'deploy:build'
        invoke 'deploy:server_restart'
      end
    end
    
end
